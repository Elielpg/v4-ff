import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventHub} from '../server/core.js';
import {DEFAULT_GIFT_RULES,normalizeGiftRules,normalizeCommandRules,mergeGiftSuggestions,EngagementDirector,buildEngagementPrompt} from '../public/audience.js';

test('presentes usam regra configurada, preservam zero pontos e só disparam no fim do streak',()=>{
 const hub=new EventHub();hub.giftRules=normalizeGiftRules([{name:'Rosa',points:0,action:'blaze',power:true}]);
 assert.equal(hub.ingest({id:'streak',type:'gift',gift:'Rosa',repeatEnd:false}),null);
 const event=hub.ingest({id:'streak',type:'gift',gift:'Rosa',repeatEnd:true,count:4,user:'Ana'});
 assert.equal(event.power,true);assert.equal(event.action,'blaze');assert.equal(event.points,0);assert.match(event.reaction.text,/Ana/);
 assert.equal(hub.ingest({id:'streak',type:'gift',gift:'Rosa'}),null);
 const like=hub.ingest({type:'like',gift:'Rosa'});assert.equal(like.action,null);assert.equal(like.power,false);
});

test('migração só adiciona poder aos presentes antigos conhecidos e respeita opção explícita',()=>{
 const rules=normalizeGiftRules([{name:'Rose',action:'blaze',points:10},{name:'Galaxy',action:'nova',points:100,power:false},{name:'Meu presente',action:'rock',points:2}],{upgradeLegacy:true});
 assert.equal(rules[0].power,true);assert.equal(rules[1].power,false);assert.equal(rules[2].power,false);
  assert.equal(normalizeGiftRules(DEFAULT_GIFT_RULES).length,28);
 assert.throws(()=>normalizeGiftRules([{name:'Rósa',action:'rock',points:1},{name:'rosa',action:'volt',points:2}]),/duplicado/);
 assert.throws(()=>normalizeGiftRules([{name:'Teste',action:'rock',movement:'dash',points:1}]),/XLR8/);
});

test('comandos de poder e missão funcionam sem transformação e perguntas ficam na conversa',()=>{
 const hub=new EventHub();hub.commandRules=normalizeCommandRules([{command:'/poder',power:true},{command:'/busca',missionKind:'search'}]);
 assert.equal(hub.ingest({type:'comment',text:'/poder'}).power,true);
 assert.equal(hub.ingest({type:'comment',text:'/busca'}).missionKind,'search');
 const race=hub.ingest({type:'comment',text:'missão corrida'});assert.equal(race.missionKind,'race');assert.equal(race.movement,null);
 const question=hub.ingest({type:'comment',text:'Como o XLR8 usa o poder?'});assert.equal(question.action,null);assert.equal(question.power,false);
 const gwen=hub.ingest({type:'comment',text:'Gwen, me fala sobre a missão resgate'});assert.equal(gwen.speaker,'gwen');assert.equal(gwen.mission,false);
});

test('gestos podem ser pedidos em linguagem natural ou por comando, sem capturar perguntas',()=>{
 const hub=new EventHub();
 assert.equal(hub.ingest({type:'comment',user:'Ana',text:'/acenar'}).gesture,'wave');
 assert.equal(hub.ingest({type:'comment',user:'Bia',text:'Comemore aí!'}).gesture,'cheer');
 assert.equal(hub.ingest({type:'comment',user:'Caio',text:'Pule!'}).gesture,'jump');
 assert.equal(hub.ingest({type:'comment',user:'Dani',text:'Como faço para pular?'}).gesture,null);
 assert.equal(hub.ingest({type:'comment',user:'Eli',text:'não pule'}).gesture,null);
 assert.equal(normalizeCommandRules([{command:'/aceno',gesture:'wave'}])[0].gesture,'wave');
 assert.throws(()=>normalizeCommandRules([{command:'/girar',gesture:'teleport'}]),/Gesto/);
});

test('nível do poder do presente cresce com os pontos e respeita o limite',()=>{
 const hub=new EventHub();hub.giftRules=normalizeGiftRules([{name:'Pequeno',points:10,action:'blaze',power:true},{name:'Grande',points:100,action:'nova',power:true}]);
 assert.equal(hub.ingest({type:'gift',gift:'Pequeno',count:1}).powerLevel,1);
 assert.equal(hub.ingest({type:'gift',gift:'Grande',count:1}).powerLevel,4);
 assert.equal(hub.ingest({type:'gift',gift:'Grande',count:1000}).powerLevel,5);
});

test('catálogo inclui GG, Rosa Branca e outros presentes sem substituir regras personalizadas',()=>{
 const names=new Set(DEFAULT_GIFT_RULES.map(rule=>rule.name));for(const name of ['GG','Rosa Branca','White Rose','Perfume','Heart Me','Finger Heart','Lightning Bolt','Lion','Galaxy','TikTok Universe'])assert(names.has(name),name);
 const custom={name:'Meu Presente',points:42,action:'rock',power:false},merged=mergeGiftSuggestions([custom]);assert.equal(merged.find(rule=>rule.name===custom.name).points,42);assert.equal(merged.find(rule=>rule.name===custom.name).power,false);assert.equal(merged.find(rule=>rule.name==='Rosa Branca').action,'tide');
 const hub=new EventHub();hub.giftRules=DEFAULT_GIFT_RULES;assert.equal(hub.ingest({type:'gift',gift:'GG'}).action,'base');assert.equal(hub.ingest({type:'gift',gift:'Rosa Branca'}).action,'tide');assert.equal(hub.ingest({type:'gift',gift:'TikTok Universe'}).missionKind,'rescue');
});

test('convites ao público respeitam silêncio, fala ativa, treino e intervalo mínimo',()=>{
 let now=0;const director=new EngagementDirector({now:()=>now});const opts={audioEnabled:true,giftRules:DEFAULT_GIFT_RULES};
 now=44000;assert.equal(director.next(opts),null);now=46000;assert.equal(director.next({...opts,busy:true}),null);assert.equal(director.next({...opts,previewActive:true}),null);
 assert(director.next(opts));now+=50000;assert.equal(director.next(opts),null);now+=80000;director.noteActivity();assert.equal(director.next(opts),null);now+=46000;assert(director.next(opts));
 assert.match(buildEngagementPrompt({cursor:5,giftRules:[{name:'Meu Presente',action:'rock',power:true}]}).text,/Meu Presente/);
});
