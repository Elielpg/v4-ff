import {createAlternativeClient,normalizeAlternativeError,normalizedGiftFinal} from './live-alternative.js';
// Community read-only TikTok connector. A room ID is not a confirmed event socket.
export function normalizeUsername(value){
 const username=String(value).trim().replace(/^@/,'').toLowerCase();
 if(!/^[\w.]{2,24}$/.test(username))throw Error('Digite apenas o @ do TikTok, sem link ou espaços (2 a 24 caracteres).');
 return username;
}
function safeMessage(value){return String(value||'Erro de rede desconhecido').replace(/https?:\/\/[^\s]+/gi,'[destino de rede]').replace(/\b(sessionid|sid_tt|ttwid|cookie|token|signature|x-bogus)\s*[=:]\s*[^\s;,]+/gi,'$1=[oculto]').replace(/[\r\n]+/g,' ').slice(0,220);}
export function liveDiagnostic(error){
 const parts=[];let current=error;for(let i=0;current&&i<4;i++,current=current.cause){const code=String(current.code||current.name||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,60);parts.push((code?code+': ':'')+safeMessage(current.message||current));}
 return parts.join(' · ').slice(0,650);
}
export function liveError(error){
 const message=liveDiagnostic(error);
 if(/not.?live|offline|not currently live|not.?found|does not exist|not streaming|no active|no live/i.test(message))return 'A conta não está ao vivo ou o @ não foi encontrado. Abra uma LIVE pública nessa conta e tente novamente. Detalhe: '+message;
 if(/age.restricted|18\+|private|session.required/i.test(message))return 'A sala exige acesso autenticado ou é privada. Este modo por @ recebe LIVE pública. Detalhe: '+message;
 if(/429|rate.limit/i.test(message))return 'O TikTok limitou as consultas. Aguarde antes de tentar novamente. Detalhe: '+message;
 if(/403|blocked|forbidden|captcha/i.test(message))return 'O TikTok ou a rede bloqueou a conexão. Confirme que a LIVE é pública e confira a rede. Detalhe: '+message;
 if(/timeout|timed out|handshake|socket|ECONNRESET|EAI_AGAIN|ENOTFOUND/i.test(message))return 'Não foi possível manter o WebSocket da LIVE. Confira a rede e se a transmissão continua ativa. Detalhe: '+message;
 return error?.message==='Rede indisponível'?'Rede indisponível':message;
}
function stopClient(client){try{const closing=client?.disconnect?.();closing?.catch?.(()=>{});}catch{/* A detached transport must not crash a new connection. */}}
const ENDPOINTS={global:'webcast-ws.tiktok.com',us:'webcast-ws.us.tiktok.com',eu:'webcast-ws.eu.tiktok.com'};
export function unsignedUpgradeRejected(error){const detail=liveDiagnostic(error);return !/proxy|tunnel|captcha|DEVICE_BLOCKED|forbidden|age.restricted|private|session.required/i.test(detail)&&/(?:WSS handshake rejected:\s*HTTP|Unexpected server response:)\s*(?:401|403)\b/i.test(detail);}
const terminal=error=>/not currently live|not.?live|offline|does not exist|not.?found|18\+|age.restricted|private|session.required|401|402|403|429|forbidden|blocked|captcha|PremiumFeatureError|ERR_MODULE_NOT_FOUND|Adaptador inválido/i.test(liveDiagnostic(error));
export class LiveAdapter {
 constructor(onEvent,onStatus,{load=name=>import(name),connectTimeoutMs=30000,maxAttempts=4,retryDelay=attempt=>Math.min(15000,1000*2**(attempt-1)),now=Date.now,healthyMs=30000}={}){
  this.onEvent=onEvent;this.onStatus=onStatus;this.load=load;this.connectTimeoutMs=connectTimeoutMs;this.maxAttempts=maxAttempts;this.retryDelay=retryDelay;this.now=now;this.healthyMs=healthyMs;this.client=null;this.generation=0;this.timer=null;this.attempt=0;this.cancelWait=null;this.cancelConnect=null;
  this.state={status:'desconectado',provider:null,error:null,stage:'parado',events:0};
 }
 status(status,extra={}){this.state={...this.state,status,...extra};this.onStatus({...this.state});}
 async connect(username,provider='auto',options={}){
  const normalized=normalizeUsername(username),endpoint=options.endpoint||process.env.TIKTOK_CDN||'auto';
  if(!['auto',...Object.keys(ENDPOINTS)].includes(endpoint))throw Error('Região de conexão inválida');
  await this.disconnect();this.username=normalized;this.provider=provider;this.endpoint=endpoint;this.attempt=0;this.preferredProvider='piratetok';
  this.status('conectando',{provider,requestedProvider:provider,username:normalized,roomId:null,events:0,lastEventAt:null,error:null,detail:null,connectedAt:null,stage:'resolvendo sala',maxAttempts:this.maxAttempts,nextRetryAt:null});
  await this.run(this.generation);return this.state;
 }
 retire(client){
  if(!client)return;client.removeAllListeners?.();stopClient(client);
  // checkOnline() has its own HTTP timeout. If it finishes after cancellation,
  // stop the session synchronously when it eventually announces the room.
  client.on?.('connected',()=>stopClient(client));client.on?.('error',()=>{});
 }
 async waitRetry(generation,error){
  if(generation!==this.generation)return false;
  const signedFallback=this.provider==='auto'&&this.state.provider==='piratetok'&&unsignedUpgradeRejected(error);
  if(this.attempt>=this.maxAttempts||(terminal(error)&&!signedFallback)){this.status('erro',{stage:'falhou',error:liveError(error),detail:liveDiagnostic(error),nextRetryAt:null});return false;}
  const delay=Math.max(0,this.retryDelay(this.attempt));this.status('reconectando',{stage:signedFallback?'alternando para protocolo assinado':'aguardando nova tentativa',error:signedFallback?'O WebSocket direto recusou a abertura. Tentando o protocolo público assinado.':liveError(error),detail:liveDiagnostic(error),connectedAt:null,nextRetryAt:Date.now()+delay});
  let finishWait,timer;await new Promise(resolve=>{finishWait=resolve;this.cancelWait=resolve;timer=this.timer=setTimeout(resolve,delay);});clearTimeout(timer);if(this.timer===timer)this.timer=null;if(this.cancelWait===finishWait)this.cancelWait=null;return generation===this.generation;
 }
 async run(generation){
  while(generation===this.generation){
   this.attempt++;let client=null,opened=false,closed=false,openedAt=0,timeout,rawError=null,cancelAttempt;
   const activeProvider=this.provider==='auto'?(this.attempt%2?this.preferredProvider:this.preferredProvider==='piratetok'?'alternative':'piratetok'):this.provider;
   const endpoint=this.endpoint==='auto'?['global','us','eu','global'][(this.attempt-1)%4]:this.endpoint;
   this.status('conectando',{stage:activeProvider==='alternative'?'abrindo transporte assinado':'resolvendo sala',provider:activeProvider,endpoint,attempt:this.attempt,nextRetryAt:null});
   try{
    if(!['auto','piratetok','alternative'].includes(this.provider))throw Error('Adaptador inválido');
    const pirate=activeProvider==='piratetok',mod=await this.load(pirate?'piratetok-live-js':'tiktok-live-connector');if(generation!==this.generation)return;
    client=pirate?new mod.TikTokLiveClient(this.username).timeout(12000).maxRetries(0):await createAlternativeClient(mod,this.username);if(generation!==this.generation){this.retire(client);return;}this.client=client;
    // One retry owner: maxRetries(0) prevents overlapping package/game loops.
    if(pirate){client.cdn?.(ENDPOINTS[endpoint]);client.language?.('pt');client.region?.('BR');client.staleTimeout?.(90000);const proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY;if(proxy)client.proxy(proxy);}
    const current=()=>generation===this.generation&&client===this.client;
    for(const [raw,type] of Object.entries({chat:'comment',gift:'gift',like:'like',follow:'follow',share:'share',join:'join',...(!pirate?{member:'join'}:{})}))client.on(raw,e=>{
     if(!current())return;this.status('recebendo eventos',{stage:'recebendo eventos',events:(this.state.events||0)+1,lastEventAt:Date.now(),error:null,detail:null,nextRetryAt:null});
     try{this.onEvent({id:e.common?.msgId||e.msgId,type,user:e.user?.uniqueId||e.user?.displayId||e.user?.nickname||e.uniqueId,text:e.content||e.comment,gift:e.gift?.name||e.giftName,count:e.repeatCount||e.count||e.likeCount,repeatEnd:pirate?(e.isStreakOver??mod.isStreakOver?.(e)??(Number(e.gift?.type)!==1||Number(e.repeatEnd)===1)):normalizedGiftFinal(e)},'tiktok');}catch(error){this.status(this.state.status,{error:'Evento inválido: '+safeMessage(error.message)});}
    });
    client.on('connected',e=>{if(current())this.status('sala resolvida',{stage:'abrindo WebSocket',roomId:String(e?.roomId||'')});});
    client.on('reconnecting',info=>{if(current())this.status('reconectando',{stage:'reconectando transporte',retry:info?.attempt||0});});
    client.on('disconnected',()=>{
     closed=true;if(!current()||!opened)return;
     this.client=null;this.retire(client);if(this.now()-openedAt>=this.healthyMs){this.attempt=0;this.preferredProvider=activeProvider;}
     // Re-establish a fresh promise/handshake after socket loss, even if no
     // comments arrive. The library emits `connected` only for room lookup.
     void (async()=>{const error=rawError||Error('WebSocket encerrado; aguardando reconexão');if(await this.waitRetry(generation,error))await this.run(generation);})().catch(error=>{if(generation===this.generation)this.status('erro',{error:liveError(error),stage:'falhou'});});
    });
    const ended=()=>{if(current()){void this.disconnect();this.status('desconectado',{error:'LIVE encerrada',stage:'LIVE encerrada'});}};client.on('liveEnded',ended);if(!pirate)client.on('streamEnd',ended);
    client.on('error',input=>{const error=normalizeAlternativeError(input);rawError=error;if(current())this.status(this.state.status,{error:liveError(error),detail:liveDiagnostic(error)});});
    const connecting=Promise.resolve(pirate?client.connect():client.connect(this.state.roomId||undefined));connecting.then(()=>{if(!current()){stopClient(client);client.removeAllListeners?.();}},()=>{if(!current())client.removeAllListeners?.();});
    const cancelled=new Promise((_,reject)=>{cancelAttempt=()=>reject(Error('Conexão cancelada'));this.cancelConnect=cancelAttempt;});
    const result=await Promise.race([connecting,cancelled,new Promise((_,reject)=>{timeout=setTimeout(()=>reject(Error('Timeout de '+Math.round(this.connectTimeoutMs/1000)+'s aguardando o handshake WebSocket')),this.connectTimeoutMs);})]);
    clearTimeout(timeout);if(this.cancelConnect===cancelAttempt)this.cancelConnect=null;if(!current()){this.retire(client);return;}if(closed)throw rawError||Error('Socket encerrou antes da confirmação');
    if(!pirate&&!result?.isConnected)throw Error('Adaptador encontrou sala mas não confirmou o WebSocket');
    opened=true;openedAt=this.now();this.status('websocket confirmado',{stage:'socket ativo',roomId:String(pirate?result:result.roomId||''),error:null,detail:null,connectedAt:openedAt,nextRetryAt:null});return;
   }catch(error){
    clearTimeout(timeout);if(this.cancelConnect===cancelAttempt)this.cancelConnect=null;if(generation!==this.generation)return;
    this.client=null;this.retire(client);
    if(error.code==='ERR_MODULE_NOT_FOUND')error=Object.assign(Error('Conector alternativo não instalado. Reinstale as dependências com bash install.sh.'),{code:'ERR_MODULE_NOT_FOUND'});
    if(!await this.waitRetry(generation,error))return;
   }
  }
 }
 async disconnect(){
  this.generation++;clearTimeout(this.timer);this.cancelWait?.();this.cancelWait=null;this.cancelConnect?.();this.cancelConnect=null;const client=this.client;this.client=null;this.retire(client);
  this.status('desconectado',{roomId:null,events:0,lastEventAt:null,error:null,detail:null,nextRetryAt:null,connectedAt:null,stage:'parado'});
 }
}
