# Ben 10 · Arena Omnitrix LIVE · V34

**V34:** arena natural inspirada nos prints, câmera de ação, energia Omnitrix, nove estilos de presentes 3D, novos sons locais e sentinela de treino. Começa em Modo LIVE; use Controles para abrir a interface completa. [Guia V34](docs/V34_NOVIDADES.md) · [Referências](docs/PESQUISA_V34.md).

Jogo interativo para Node/Termux e Chrome, com avenida procedural contínua, quatro temas de cidade, oito tipos de missão, onze formas, NPCs e participação do chat/presentes. A V33 acrescenta um painel visual animado para as interações da LIVE, melhora a leitura das missões e dá mais presença à caminhada. A V32 preservou melhor as silhuetas dos modelos, acrescentou três poderes selecionáveis por forma e atualizou suas poses e efeitos. Assets Babylon licenciados são servidos localmente. Projeto de fã sem afiliação oficial.

```sh
bash install.sh
bash start.sh
```

Use o endereço exibido no terminal, no Chrome do mesmo aparelho. Para iniciar depois da instalação, execute `bash start.sh` na pasta `game` e confira **v34.0.0** no topo da tela. [Novidades e instruções da V34](docs/V34_NOVIDADES.md).

Abra **Missões** para escolher um dos 10 pedidos da cidade; Ben continua avançando por novos quarteirões. O botão de poder alterna entre três habilidades da forma ativa a cada uso; presentes também podem selecionar variações. O chat aceita nomes de aliens, “poder”, “dash”, “correr”, “voar”, “acene”, “comemore”, “pule” e “missão resgate/entrega/corrida/busca”. Em **Laboratório → Presentes**, ajuste nomes, pontos e ações; a atualização acrescenta sugestões novas sem substituir regras personalizadas. Os pontos são do jogo e definem a força do efeito, não representam cotação oficial de moedas do TikTok.

**IA e voz** permite cadastrar várias chaves Gemini e selecionar uma, além de ElevenLabs opcional e vozes por personagem. Chaves ficam no servidor, em data/private, fora dos ZIPs/backup; não são retornadas ao navegador. Sem chave, missões locais e respostas locais continuam disponíveis. Toque no botão de áudio para liberar a reprodução. As vozes e animações são interpretadas/procedurais; não são a dublagem ou clipes oficiais.

O usuário confirmou que a conexão TikTok pelo@ funcionou no celular. Esta versão preserva o transporte. Conectores não oficiais dependem da disponibilidade do TikTok e a cloud não substitui o teste no aparelho. Para transmitir o jogo no mesmo celular, veja [LIVE_CELULAR.md](docs/LIVE_CELULAR.md).

## Desenvolvimento

Node>=22.19 e Python para empacotamento/atualização. Use o checkout existente.

- `npm ci`: instalação pelo lockfile.
- `npm test`: domínio,40 missões, integração HTTP/SSE, fila de presentes, rigs/efeitos e conectores com transporte controlado.
- `npm run lint`: verificação de sintaxe JavaScript.
- `npm run build`: prepara Babylon e licenças locais, copia public/ para dist/public.
- `npm run package`: executa verificações e gera `BEN10_LIVE_V34_TERMUX.zip`, sem `data/`, `.env` ou `node_modules`.
- `bash doctor.sh`: diagnóstico do servidor sem expor chaves.
- `bash backup.sh`: exporta configuração/modelos locais sem chaves.

O jogo contém nove GLBs de terceiros com licençaCCBY4 e duas formas procedurais. Veja [créditos](docs/MODEL_CREDITS.md), [animações](docs/ANIMACOES.md) e third_party/NOTICE.md. Código do jogo sob AGPL3; fontes correspondentes do conector incluídas em third_party. Personalizações GLB em data/models continuam prevalecendo; o treino usa as formas incluídas.

A jornada percorre distância sem limite fixo, com quatro temas reutilizados em trechos variados; não representa um mapa geográfico infinito. Progresso de missão é da sessão do servidor. Performance Android, vozes de serviços externos e cada condição de rede devem ser verificados no aparelho.
