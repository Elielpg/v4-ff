export const BUILD_ID='34.0.0';
export const BUILD_LABEL='Ben 10 · Arena Omnitrix LIVE · 34.0.0';
