import {FORM_IDS,POWERS,clean} from './transformations.js';
import {SPEAKERS} from './characters.js';
export const MISSION_KINDS=['rescue','escort','delivery','race','repair','fire','defense','search'];
export const DEFAULT_GIFT_RULES=[
 {name:'GG',points:10,action:'base',power:true},
 {name:'Rose',points:10,action:'blaze',power:true},
 {name:'Rosa',points:10,action:'blaze',power:true},
 {name:'White Rose',points:15,action:'tide',power:true},
 {name:'Rosa Branca',points:15,action:'tide',power:true},
 {name:'Ice Cream',points:15,action:'tide',power:true},
 {name:'Sorvete',points:15,action:'tide',power:true},
 {name:'Finger Heart',points:20,action:'volt',power:false,movement:'dash'},
 {name:'Perfume',points:25,action:'shade',power:true,movement:'fly'},
 {name:'Heart Me',points:25,action:'wildvine',power:true,missionKind:'rescue'},
 {name:'Hand Heart',points:25,action:'fourarms',power:true},
 {name:'Sunglasses',points:30,action:'shade',power:true},
 {name:'Cap',points:30,action:'rock',power:true},
 {name:'TikTok',points:30,action:'volt',power:true,movement:'dash'},
 {name:'Lightning Bolt',points:40,action:'volt',power:true,movement:'dash'},
 {name:'Doughnut',points:40,action:'cannon',power:true},
 {name:'Swan',points:50,action:'shade',power:true,movement:'fly'},
 {name:'Money Gun',points:50,action:'volt',power:true,movement:'dash'},
 {name:'Metralhadora de Dinheiro',points:50,action:'volt',power:true,movement:'dash'},
 {name:'Lion',points:100,action:'fourarms',power:true,missionKind:'defense'},
 {name:'Leão',points:100,action:'fourarms',power:true,missionKind:'defense'},
 {name:'Galaxy',points:100,action:'nova',power:true},
 {name:'Galáxia',points:100,action:'nova',power:true},
 {name:'Confetti',points:15,action:'base',power:true},
 {name:'Confete',points:15,action:'base',power:true},
 {name:'Coração',points:25,action:'wildvine',power:true},
 {name:'TikTok Universe',points:500,action:'nova',power:true,missionKind:'rescue'},
 {name:'Universo TikTok',points:500,action:'nova',power:true,missionKind:'rescue'}
];
export const DEFAULT_COMMAND_RULES=[
 {command:'/chama',action:'blaze'},
 {command:'/humano',action:'base'},
 {command:'/xlr8',action:'volt'},
 {command:'/poder',power:true},
 {command:'/missao',mission:true},
 {command:'/dash',movement:'dash'},
 {command:'/correr',movement:'run'},
 {command:'/voar',movement:'fly'},
 {command:'/acenar',gesture:'wave'},
 {command:'/comemorar',gesture:'cheer'},
 {command:'/pular',gesture:'jump'}
];
export const giftKey=value=>clean(value).replace(/ /g,'');
const validText=(value,max)=>typeof value==='string'&&value.trim().length>0&&value.trim().length<=max&&!/[<>\x00-\x1f]/.test(value);
function validateActions(rule,{requiredForm=false}={}){
 if(requiredForm&&!FORM_IDS.includes(rule.action)||rule.action!==undefined&&rule.action!==null&&!FORM_IDS.includes(rule.action))throw Error('Forma da regra inválida');
 if(rule.power!==undefined&&typeof rule.power!=='boolean')throw Error('Poder da regra precisa ser verdadeiro ou falso');
 if(rule.movement!==undefined&&rule.movement!==null&&!['run','dash','fly'].includes(rule.movement))throw Error('Movimento da regra inválido');
 if(rule.movement==='dash'&&rule.action&&rule.action!=='volt')throw Error('Dash por presente precisa de XLR8');
 if(rule.movement==='fly'&&rule.action&&!['blaze','shade','nova'].includes(rule.action))throw Error('A forma da regra não pode voar');
 if(rule.mission!==undefined&&typeof rule.mission!=='boolean')throw Error('Missão da regra precisa ser verdadeira ou falsa');
 if(rule.missionKind!==undefined&&rule.missionKind!==null&&!MISSION_KINDS.includes(rule.missionKind))throw Error('Tipo de missão da regra inválido');
}
export function normalizeGiftRules(rules,{upgradeLegacy=false}={}){
 if(!Array.isArray(rules)||rules.length>50)throw Error('Lista de presentes inválida');const seen=new Set();
 return rules.map(rule=>{
  if(!rule||typeof rule!=='object'||!validText(rule.name,80)||!Number.isFinite(rule.points)||rule.points<0||rule.points>10000)throw Error('Regra de presente inválida');
  validateActions(rule,{requiredForm:true});const name=rule.name.trim(),key=giftKey(name);if(!key||seen.has(key))throw Error('Presente duplicado');seen.add(key);
  // Only the two old built-in rules gain a power during migration. A custom
  // saved transform rule keeps its old behavior unless the operator opts in.
  const builtIn=key==='rose'&&rule.action==='blaze'||key==='galaxy'&&rule.action==='nova';
  const result={name,points:rule.points,action:rule.action,power:rule.power===undefined?!!(upgradeLegacy&&builtIn):rule.power};
  if(rule.movement)result.movement=rule.movement;
  if(rule.mission===true||rule.missionKind){result.mission=true;if(rule.missionKind)result.missionKind=rule.missionKind;}
  return result;
 });
}
export function mergeGiftSuggestions(rules,suggestions=DEFAULT_GIFT_RULES){
 const merged=normalizeGiftRules(rules),seen=new Set(merged.map(rule=>giftKey(rule.name)));
 for(const suggestion of suggestions){const key=giftKey(suggestion.name);if(seen.has(key)||merged.length>=50)continue;const normalized=normalizeGiftRules([suggestion])[0];merged.push(normalized);seen.add(key);}
 return merged;
}
export function normalizeCommandRules(rules){
 if(!Array.isArray(rules)||rules.length>50)throw Error('Lista de comandos inválida');const seen=new Set();
 return rules.map(rule=>{if(!rule||typeof rule!=='object'||!validText(rule.command,60)||!rule.command.trim().startsWith('/'))throw Error('Comando inválido');validateActions(rule);if(rule.gesture!==undefined&&!['wave','cheer','jump'].includes(rule.gesture))throw Error('Gesto do comando inválido');const command=rule.command.trim(),key=command.toLowerCase();if(seen.has(key))throw Error('Comando duplicado');seen.add(key);const result={command};if(rule.action)result.action=rule.action;if(rule.power===true)result.power=true;if(rule.movement)result.movement=rule.movement;if(rule.mission===true||rule.missionKind){result.mission=true;if(rule.missionKind)result.missionKind=rule.missionKind;}if(rule.gesture)result.gesture=rule.gesture;if(!result.action&&!result.power&&!result.movement&&!result.mission&&!result.gesture)throw Error('Comando sem ação');return result;});
}
export function ruleActionLabel(rule,names={}){
 const parts=[];if(rule.action)parts.push(names[rule.action]||SPEAKERS[rule.action]?.name||rule.action);
 if(rule.power)parts.push(POWERS[rule.action]?.name||'poder da forma atual');
 if(rule.movement)parts.push({run:'corrida',dash:'dash',fly:'voo'}[rule.movement]);
 if(rule.mission||rule.missionKind)parts.push('nova missão');
 if(rule.gesture)parts.push({wave:'aceno',cheer:'comemoração',jump:'pulo'}[rule.gesture]||'gesto');
 return parts.join(' + ');
}
export function giftReaction(event){
 const actionLabel=ruleActionLabel(event);return {kind:event.movement?'movement':event.power?'power':'transform',title:(event.count>1?event.count+'× ':'')+event.gift,text:event.user+' ativou '+actionLabel+'!',form:event.action||null,power:!!event.power,movement:event.movement||null};
}
export function buildEngagementPrompt({cursor=0,form='base',quest=null,cityName='',giftRules=[]}={}){
 const index=Math.abs(Math.trunc(Number(cursor)||0))%7;
 if(index===2&&quest?.status==='active')return {speaker:'base',kind:'mission',text:quest.stage==='travel'?'Estou a caminho da próxima missão! Que alien vocês escolheriam para chegar mais rápido? Podem mandar perguntas enquanto eu avanço.':'Temos um pedido de ajuda: '+String(quest.title||'a missão da cidade').slice(0,80)+'. Qual poder vocês usariam? Escrevam no chat!'};
 if(index===5&&giftRules.length){const rule=giftRules.find(r=>r.power||r.movement)||giftRules[0];return {speaker:'base',kind:'gift-tip',text:'Vocês também podem participar com os presentes configurados: '+String(rule.name).slice(0,80)+' ativa '+ruleActionLabel(rule)+'. Ou escolham um alien escrevendo o nome no chat!'};}
 const prompts=[
  {speaker:'base',kind:'question',text:'Pessoal, qual alien vocês escolheriam agora? Escrevam o nome no chat, ou me façam uma pergunta sobre qualquer assunto!'},
  {speaker:'gwen',kind:'question',text:'Gwen aqui! Quero ver quem conhece o Omnitrix: qual alien do Ben vocês mais gostam e por quê? Vou ler as perguntas com ele.'},
  {speaker:'base',kind:'question',text:'Enquanto a gente segue em frente'+(cityName?' por '+String(cityName).slice(0,60):'')+', mandem uma pergunta! Pode ser sobre minhas aventuras, jogos ou uma curiosidade aleatória.'},
  {speaker:'max',kind:'question',text:'Aqui é o vô Max. Uma boa equipe escuta todo mundo. Vocês preferem resgate, entrega, corrida ou investigação? Peçam o tipo de missão no chat.'},
  {speaker:'base',kind:'question',text:'Estou na forma '+(SPEAKERS[form]?.name||'Ben')+'. Qual habilidade vocês querem ver? Comentem poder ou escolham outro alien!'},
  {speaker:'base',kind:'question',text:'Qual é a pergunta mais difícil que vocês têm para mim? Pode mandar no chat. Se eu não souber, a Gwen provavelmente vai querer tentar!'},
  {speaker:'gwen',kind:'question',text:'Uma escolha para o público: buscar pistas, apagar um incêndio ou acompanhar um morador? Escrevam missão busca, missão incêndio ou missão escolta.'}
 ];return prompts[index];
}
export class EngagementDirector{
 constructor({now=Date.now,idleMs=45000,cooldownMs=120000}={}){this.now=now;this.idleMs=idleMs;this.cooldownMs=cooldownMs;this.lastActivity=now();this.lastPrompt=-Infinity;this.cursor=0;}
 noteActivity(now=this.now()){this.lastActivity=Math.max(this.lastActivity,now);}
 next({now=this.now(),audioEnabled=false,busy=false,previewActive=false,actionBusy=false,enabled=true,...state}={}){
  if(!enabled||!audioEnabled||busy||previewActive||actionBusy||now-this.lastActivity<this.idleMs||now-this.lastPrompt<this.cooldownMs)return null;
  const prompt=buildEngagementPrompt({...state,cursor:this.cursor++});this.lastPrompt=now;return prompt;
 }
}
