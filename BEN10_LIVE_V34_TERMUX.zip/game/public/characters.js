// Original performance directions; these are not the voices of the TV cast.
export const SPEAKERS={
 base:{name:'Ben Tennyson',voice:'Puck',pitch:1.12,rate:1.06,direction:'Menino de dez anos, confiante, brincalhão, brasileiro.'},
 blaze:{name:'Chama',voice:'Fenrir',pitch:.82,rate:1.01,direction:'Voz enérgica, áspera e quente, com articulação clara.'},
 volt:{name:'XLR8',voice:'Zephyr',pitch:1.25,rate:1.20,direction:'Voz leve, rápida e elétrica; fale com clareza.'},
 rock:{name:'Diamante',voice:'Charon',pitch:.74,rate:.94,direction:'Voz firme e grave, ressonância mineral.'},
 shade:{name:'Fantasmático',voice:'Enceladus',pitch:.8,rate:.89,direction:'Voz baixa e espectral, sussurrada mas inteligível.'},
 tide:{name:'Aquático',voice:'Iapetus',pitch:.88,rate:.98,direction:'Voz rouca e borbulhante, sem perder a clareza.'},
 nova:{name:'Alien X · extra',voice:'Algenib',pitch:.70,rate:.86,direction:'Voz cósmica, muito grave, solene e pausada.'},
 beast:{name:'Besta',voice:'Algieba',pitch:.65,rate:.91,direction:'Narrador grave do tradutor do Omnitrix. Besta não fala na série; diga que é tradução quando apropriado.'},
 fourarms:{name:'Quatro Braços',voice:'Gacrux',pitch:.68,rate:.95,direction:'Voz forte, grave, heroica, sem gritar.'},
 cannon:{name:'Bola de Canhão',voice:'Orus',pitch:.85,rate:1.03,direction:'Voz encorpada, entusiasmada e bem humorada.'},
 wildvine:{name:'Cipó Selvagem',voice:'Alnilam',pitch:.92,rate:.94,direction:'Voz orgânica, calma, com leve rouquidão.'},
 gwen:{name:'Gwen Tennyson',voice:'Leda',pitch:1.22,rate:1.04,direction:'Menina inteligente e direta, com humor e determinação.'},
 max:{name:'Vô Max',voice:'Sadaltager',pitch:.76,rate:.90,direction:'Homem mais velho, acolhedor, experiente, calmo e firme.'},
 lia:{name:'Lia',voice:'Kore',pitch:1.15,rate:.98,direction:'Florista gentil, voz feminina calorosa.'},
 caio:{name:'Caio',voice:'Achird',pitch:.97,rate:1.08,direction:'Comerciante animado, voz masculina amigável.'},
 bia:{name:'Bia',voice:'Aoede',pitch:1.08,rate:1.01,direction:'Guia curiosa, voz feminina clara e bem disposta.'}
};
export const speakerId=value=>Object.hasOwn(SPEAKERS,value)?value:'base';
export function npcSpeaker(name=''){const n=name.toLowerCase();return n.includes('gwen')?'gwen':/max/.test(n)?'max':n.includes('lia')?'lia':n.includes('caio')?'caio':'bia';}
