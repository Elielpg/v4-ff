import {GIFT_SHOWS,giftShowKind} from './show-catalog.js';
export class GiftSpectacle{
 constructor(world){this.world=world;this.active=null;this.queue=[];this.seen=new Set();this.completed=0;this.dropped=0;}
 enqueue(event){if(event.type!=='gift')return false;if(event.id&&this.seen.has(event.id))return false;if(event.id){this.seen.add(event.id);if(this.seen.size>512)this.seen.delete(this.seen.values().next().value);}if(this.queue.length>=6){this.dropped++;return false;}this.queue.push({...event});return true;}
 start(event){const B=BABYLON,w=this.world,kind=giftShowKind(event.gift),spec=GIFT_SHOWS[kind],root=new B.TransformNode('gift-show-'+kind,w.scene),materials=[];
 const mat=(name,color)=>{const m=new B.StandardMaterial('gift-'+name,w.scene);m.diffuseColor=new B.Color3(...color);m.emissiveColor=new B.Color3(...color).scale(.65);m.specularColor=new B.Color3(.12,.12,.12);materials.push(m);return m;};
 const glow=mat('glow',spec.color),core=mat('core',[1,.96,.78]),stem=mat('stem',[.12,.6,.22]),pink=mat('pink',[1,.25,.55]);
 const count=w.quality==='economy'?16:32,parts=[];
 const mesh=(name,options,material=glow)=>{const m=B.MeshBuilder[name]('gift-'+kind,options,w.scene);m.parent=root;m.material=material;m.isPickable=false;return m;};
 const heart=(parent,scale=1)=>{const positions=[],indices=[],segments=32;for(const z of [0,.16*scale]){positions.push(0,.05*scale,z);for(let i=0;i<segments;i++){const t=i/segments*Math.PI*2;positions.push(Math.sin(t)**3*.7*scale,(13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t))/24*scale,z);}}for(let i=0;i<segments;i++){const j=(i+1)%segments,a=1+i,b=1+j,c=a+segments+1,d=b+segments+1;indices.push(0,b,a,segments+1,c,d,a,b,c,b,d,c);}const normals=[];B.VertexData.ComputeNormals(positions,indices,normals);const m=new B.Mesh('gift-heart',w.scene),data=new B.VertexData();data.positions=positions;data.indices=indices;data.normals=normals;data.applyToMesh(m);m.material=pink;m.parent=parent;m.isPickable=false;return m;};
 for(let i=0;i<count;i++){const node=new B.TransformNode('gift-particle-'+i,w.scene);node.parent=root;
  if(kind==='rose'){const s=mesh('CreateCylinder',{height:.6,diameter:.025},stem);s.parent=node;s.position.y=-.28;for(let j=0;j<4;j++){const p=mesh('CreateSphere',{diameter:.25,segments:6},j%2?pink:glow);p.parent=node;p.position.set(Math.cos(j*1.57)*.06,.05+j*.015,Math.sin(j*1.57)*.06);p.scaling.y=.55;}const leaf=mesh('CreateSphere',{diameter:.18,segments:4},stem);leaf.parent=node;leaf.position.set(.09,-.3,0);leaf.scaling.set(1,.3,.5);}
  else if(kind==='heart')heart(node,.36);
  else if(kind==='money'){const m=mesh('CreateBox',{width:.34,height:.16,depth:.012},i%2?glow:core);m.parent=node;const stripe=mesh('CreateBox',{width:.08,height:.12,depth:.016},stem);stripe.parent=node;}
  else{const m=mesh(kind==='ice'?'CreatePolyhedron':kind==='confetti'?'CreateBox':'CreateSphere',kind==='ice'?{type:1,size:.14}:kind==='confetti'?{width:.07,height:.16,depth:.025}:{diameter:.06+(i%3)*.035,segments:6},i%3===0?core:kind==='confetti'&&i%3===1?pink:glow);m.parent=node;}
  parts.push(node);
 }
 const rings=Array.from({length:3},(_,i)=>mesh('CreateTorus',{diameter:2+i*.5,thickness:.025+(i===0?.025:0),tessellation:48},i===1?core:glow));
 let emblem=null;if(kind==='heart'){emblem=new B.TransformNode('giant-heart',w.scene);emblem.parent=root;heart(emblem,1.7);}
 if(kind==='galaxy'){emblem=mesh('CreateSphere',{diameter:.8,segments:16},core);}
 if(kind==='lion'){emblem=new B.TransformNode('lion-totem',w.scene);emblem.parent=root;const mane=mesh('CreateTorus',{diameter:2,thickness:.4,tessellation:12});mane.parent=emblem;mane.rotation.x=Math.PI/2;const head=mesh('CreateSphere',{diameter:1.4,segments:8},core);head.parent=emblem;for(const side of [-1,1]){const ear=mesh('CreateSphere',{diameter:.4,segments:6});ear.parent=emblem;ear.position.set(side*.52,.58,0);const eye=mesh('CreateSphere',{diameter:.12,segments:6},stem);eye.parent=emblem;eye.position.set(side*.25,.13,.65);}const muzzle=mesh('CreateSphere',{diameter:.5,segments:6});muzzle.parent=emblem;muzzle.position.set(0,-.25,.64);}
 this.active={root,kind,spec,event,parts,rings,emblem,materials,time:0};this.world.onGiftShow?.(event,kind,spec);
 }
 update(dt){if(!this.active&&this.queue.length)this.start(this.queue.shift());const a=this.active;if(!a)return;const B=BABYLON,w=this.world;a.time+=Math.min(.12,dt);const t=a.time,p=t/a.spec.duration,fade=Math.min(1,t*2,(a.spec.duration-t)*1.8),boost=1+Math.min(1,Math.log2(Math.max(1,a.event.count||1))/8);a.root.position.copyFrom(w.avatar.root.position);a.root.position.y=0;
 for(const [i,node] of a.parts.entries()){const k=i/a.parts.length,angle=k*Math.PI*2+t*(a.kind==='galaxy'?1.6:.55),r=(a.kind==='galaxy'?1.2+k*2:1.4+k*1.8)*boost;
  if(['rose','confetti','money','ice'].includes(a.kind)){node.position.set(Math.cos(angle)*r,5-((t*(a.kind==='rose'?.85:1.4)+k*5)%5),Math.sin(angle)*r);node.rotation.set(Math.sin(t+i)*.6,t+i,Math.sin(t*1.5+i)*.45);}
  else if(a.kind==='lightning'){node.position.set(Math.cos(angle)*(.7+k),k*4,Math.sin(angle)*(.7+k));node.scaling.set(.8,5+Math.sin(t*20+i)*3,.8);}
  else{node.position.set(Math.cos(angle)*r,1.5+Math.sin(t*1.5+k*10)*(a.kind==='galaxy'?1.4:.8),Math.sin(angle)*r);node.rotation.y=-w.camera.rotation.y;}
  if(a.kind!=='lightning')node.scaling.setAll(Math.max(.001,fade));
 }
 for(const [i,r] of a.rings.entries()){r.position.y=.06+i*.04;r.scaling.setAll(Math.max(.001,(.6+p*2.5+i*.25)*boost));r.rotation.set(a.kind==='galaxy'?.45+i*.35:0,t*(i%2?1:-1),a.kind==='galaxy'?i*.4:0);}
 if(a.emblem){a.emblem.position.set(0,3.2+Math.sin(t*2)*.15,0);a.emblem.rotation.y=w.camera.rotation.y;a.emblem.scaling.setAll(Math.max(.001,fade*(.9+Math.sin(t*3)*.06)));}
 for(const m of a.materials)m.alpha=Math.max(0,fade*.9);
 if(p>=1){a.root.dispose();for(const m of a.materials)m.dispose();this.active=null;this.completed++;}
 }
 dispose(){if(this.active){this.active.root.dispose();for(const m of this.active.materials)m.dispose();this.active=null;}this.queue=[];}
}
