import {readdir} from 'node:fs/promises';import {spawnSync} from 'node:child_process';
for(const dir of ['server','public','scripts','tests'])for(const name of await readdir(dir))if(name.endsWith('.js')){const result=spawnSync(process.execPath,['--check',dir+'/'+name],{stdio:'inherit'});if(result.status)process.exit(result.status);}console.log('Sintaxe JavaScript válida');
