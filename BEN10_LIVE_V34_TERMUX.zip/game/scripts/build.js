import {copyFile} from 'node:fs/promises';
await mkdir('public/vendor',{recursive:true});
for(const [src,dst] of [['node_modules/babylonjs/babylon.js','babylon.js'],['node_modules/babylonjs-loaders/babylonjs.loaders.min.js','babylonjs.loaders.min.js'],['node_modules/babylonjs/license.md','BABYLON-LICENSE.md'],['node_modules/babylonjs-loaders/license.md','LOADERS-LICENSE.md']])await copyFile(src,'public/vendor/'+dst);
import {mkdir,cp,readFile} from 'node:fs/promises';
const html=await readFile('public/index.html','utf8'),app=await readFile('public/app.js','utf8');for(const file of ['app.js','world.js','style.css','live-overlay.css'])await readFile('public/'+file);if(!html.includes('app.js')||!app.includes('live-overlay.css'))throw Error('Asset ausente: live overlay ou app.js');
await mkdir('dist',{recursive:true});await cp('public','dist/public',{recursive:true});console.log('Build local concluído. Nenhum CDN ou segredo no frontend.');
