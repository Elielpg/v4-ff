#!/usr/bin/env bash
set -euo pipefail
task_game_root="$(pwd -P)"
task_update_root="$(cd -- "$(dirname -- "$0")" && pwd)"
[[ -f "$task_game_root/package.json" ]] || { printf 'Entre na pasta do jogo: cd ~/ben10-v34/game\n' >&2; exit 1; }
node --input-type=module - "$task_update_root/files" "$task_game_root" <<'BEN44_UPDATE_JS'
import path from 'node:path';
import {pathToFileURL} from 'node:url';
try {
 const [payload,root]=process.argv.slice(2);
 const {applyEvolutionUpdate}=await import(pathToFileURL(path.join(payload,'scripts/evolution-update.js')));
 const result=await applyEvolutionUpdate(payload,root);
 console.log('V44.1 aplicada. Backup: '+result.backup);
 console.log('Voz, modelos, referência, chaves e progresso foram preservados.');
 console.log('Reversão: consulte COMO_REVERTER.txt dentro do backup.');
 console.log('Agora execute: bash local-ai.sh start');
 console.log('Abra http://127.0.0.1:3000/?v=44.1.0 e toque em ♫.');
} catch(error) {console.error('Atualização não concluída: '+error.message);process.exitCode=1;}
BEN44_UPDATE_JS
