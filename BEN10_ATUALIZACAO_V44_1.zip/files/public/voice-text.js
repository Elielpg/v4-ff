import {spokenNumber} from './spoken-number.js';
// Orthographic normalization, not a change of voice or global R/L substitution.
export function normalizeVoiceText(value){
 let text=String(value||'').normalize('NFKC').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u200b-\u200d\ufeff]/g,'');
 text=text.replace(/^\s*(?:\[(?:voz|tom|emoção|emocao|sorrindo|rindo)[^\]]{0,100}\]|\((?:voz|tom|sorrindo|rindo)[^)]{0,100}\))\s*:?\s*/i,'');
 text=text.replace(/https?:\/\/\S+/gi,'link').replace(/[\p{Extended_Pictographic}\uFE0F]/gu,'').replace(/[*#`_]/g,'');
 text=text.replace(/(?<![\p{L}\p{N}])(-?\d{1,3}(?:\.\d{3})+(?:,\d{1,6})?|-?\d{1,12}(?:[,.]\d{1,6})?)(?![\p{L}\p{N}])/gu,raw=>{const n=Number((raw.includes(',')?raw.replace(/\./g,'').replace(',','.'): /^-?\d{1,3}(?:\.\d{3})+$/.test(raw)?raw.replace(/\./g,''):raw));return Number.isFinite(n)&&Math.abs(n)<=1e12?spokenNumber(n):raw;});
 return text.replace(/%/g,' por cento').replace(/×/g,' vezes ').replace(/÷/g,' dividido por ').replace(/\bkg\b/gi,'quilogramas').replace(/\bkm\b/gi,'quilômetros').replace(/\s+/g,' ').trim();
}
