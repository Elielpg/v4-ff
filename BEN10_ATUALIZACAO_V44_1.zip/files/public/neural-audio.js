import {MouthEnvelope} from './mouth-envelope.js';
// A context unlocked by the entry tap also plays replies that arrive much later.
export async function resumeVoiceContext(context) {
 if(!context||context.state==='closed')throw Object.assign(Error('Toque em ♫ para ativar o som novamente.'),{code:'audio_gesture_required'});
 if(context.state==='running')return;
 let timer;
 try{await Promise.race([context.resume(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Object.assign(Error('Toque em ♫ para liberar o áudio no navegador.'),{code:'audio_gesture_required'})),2500);})]);}
 finally{clearTimeout(timer);}
 if(context.state!=='running')throw Object.assign(Error('Toque em ♫ para liberar o áudio no navegador.'),{code:'audio_gesture_required'});
}

export async function playNeuralAudio(context,tts,{volume=1,onStart=()=>{},onMouth=()=>{}}={}) {
 if(!Number.isFinite(volume)||volume<=0)throw Object.assign(Error('O volume da voz está zerado. Aumente em IA e voz.'),{code:'voice_volume_zero'});
 await resumeVoiceContext(context);
 const binary=atob(tts.audio),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 let buffer;
 try{buffer=await context.decodeAudioData(bytes.buffer);}catch{throw Error('O navegador não conseguiu decodificar o áudio da voz IA.');}
 if(!Number.isFinite(buffer.duration)||buffer.duration<=0||buffer.duration>300)throw Error('Duração de áudio inválida.');
 await resumeVoiceContext(context);
 return new Promise((resolve,reject)=>{
  const source=context.createBufferSource(),gain=context.createGain(),analyser=context.createAnalyser();
  source.buffer=buffer;gain.gain.value=Math.min(1,volume);analyser.fftSize=256;
  source.connect(analyser).connect(gain).connect(context.destination);
  const envelope=new MouthEnvelope(),samples=new Uint8Array(analyser.fftSize);let frame,timer,settled=false;
  const done=error=>{if(settled)return;settled=true;clearTimeout(timer);cancelAnimationFrame(frame);context.removeEventListener('statechange',stateChanged);source.onended=null;try{source.stop();}catch{}source.disconnect();gain.disconnect();analyser.disconnect();onMouth(0);error?reject(error):resolve();};
  const stateChanged=()=>{if(context.state!=='running')done(Object.assign(Error('O navegador pausou o som. Volte ao jogo e toque em ♫ para repetir a fala.'),{code:'audio_interrupted'}));};
  const meter=()=>{if(settled)return;analyser.getByteTimeDomainData(samples);let energy=0;for(const value of samples)energy+=((value-128)/128)**2;onMouth(envelope.sample(Math.sqrt(energy/samples.length),performance.now()));frame=requestAnimationFrame(meter);};
  source.onended=()=>done();context.addEventListener('statechange',stateChanged);
  timer=setTimeout(()=>done(Error('A reprodução da voz não terminou. Toque em ♫ para tentar de novo.')),Math.max(10000,(buffer.duration+10)*1000));
  try{source.start();onStart();meter();}catch(error){done(error);}
 });
}
