import {deviceMetrics,runtimeProfile} from './device-metrics.js';
import {createConnection} from 'node:net';
import {readFile,mkdir,access,open} from 'node:fs/promises';
import {constants,existsSync,appendFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {localHealth,loopbackRequest,localSettings,LocalTextClient} from '../../server/local-ai.js';
import {AtomicJson} from '../../server/atomic-json.js';
import {BUILD_ID} from '../../public/release.js';
import {ProcessSupervisor} from './process-supervisor.js';
import {RuntimeLog,ServiceLog} from './runtime-log.js';

const gameRoot=fileURLToPath(new URL('../../',import.meta.url)).replace(/\/$/,''),localRoot=path.resolve(process.env.BEN10_LOCAL_ROOT||path.join(os.homedir(),'.local/share/ben10-local-ai'));
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let supervisor,heartbeat,metrics,store,log,stopping=false;const handles=[];
process.on('uncaughtExceptionMonitor',(error,origin)=>{lifecycle('Falha fatal do supervisor: '+origin+' '+error.message);log?.event('supervisor-fatal',{origin,message:error.message,stack:String(error.stack||'').slice(0,4000)});});
process.on('exit',code=>{if(!stopping&&process.argv[2]==='start'){lifecycle('Supervisor saiu inesperadamente: código='+code);log?.event('supervisor-unexpected-exit',{code});}});
function lifecycle(message){try{appendFileSync(path.join(localRoot,'logs/inicializacao.log'),new Date().toISOString()+' '+message+'\n');}catch{}}
async function cleanup(){if(stopping)return;stopping=true;clearInterval(heartbeat);clearInterval(metrics);await supervisor?.stop();await store?.flush();for(const handle of handles)await handle.close().catch(()=>{});}
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{lifecycle('Encerramento solicitado: '+signal);log?.event('supervisor-stop-request',{signal});void cleanup().then(()=>process.exit(0));});
function portOpen(port){return new Promise(resolve=>{const socket=createConnection({host:'127.0.0.1',port});const done=value=>{socket.destroy();resolve(value);};socket.setTimeout(700,()=>done(false));socket.once('connect',()=>done(true));socket.once('error',()=>done(false));});}
async function get(port,route='/health'){const r=await loopbackRequest(port,route,{timeout:2000,limit:262144});return r.status===200?JSON.parse(r.data):null;}
async function voicePlan(manifest,settings){
 const fast=manifest.voiceEngine==='openvoice',cloned=manifest.voiceEngine==='qwen3-clone';
 for(const file of [...(cloned?['cloning/config.json','cloning/reference.wav','qwen3-tts.cpp/build/libqwen3tts.so'].map(n=>path.join(localRoot,n)):[manifest.voiceModel,manifest.voiceModel+'.json']),...(fast?['cloning/reference.wav','openvoice/config.json','openvoice/checkpoint.pth'].map(n=>path.join(localRoot,n)):[])])await access(file);
 const args=['--build-id',BUILD_ID,'--port',String(settings.voicePort)];
 if(cloned)return {command:'python3',args:[path.join(gameRoot,'scripts/local-ai/clone_voice.py'),'--root',localRoot,...args]};
 const relative=path.relative(localRoot,path.resolve(manifest.voiceModel));if(relative.startsWith('..')||path.isAbsolute(relative)||!relative.endsWith('.onnx'))throw Error('Modelo de voz precisa estar na raiz local da IA.');
 if(fast&&manifest.openvoicePython){if(!path.isAbsolute(manifest.openvoicePython))throw Error('Python local precisa ser absoluto');await access(manifest.openvoicePython,constants.X_OK);return {command:manifest.openvoicePython,args:[path.join(gameRoot,'scripts/local-ai/openvoice_voice.py'),'--root',localRoot,...args]};}
 return {command:'proot-distro',args:['login','--bind',localRoot+':/ben10-data','--bind',path.join(gameRoot,'scripts/local-ai')+':/opt/ben10-worker','ben10-ai','--',fast?'/opt/ben10-clone-convert/bin/python':'/opt/ben10-voice/bin/python','/opt/ben10-worker/'+(fast?'openvoice_voice.py':'tts_server.py'),...(fast?['--root','/ben10-data']:['--model','/ben10-data/'+relative.split(path.sep).join('/'),'--cache-dir','/ben10-data/voice-cache']),...args]};
}
async function main(){
 const command=process.argv[2]||'status';let config={},manifest=null;try{config=JSON.parse(await readFile(path.join(gameRoot,'data/config.json'),'utf8'));}catch{}try{manifest=JSON.parse(await readFile(path.join(localRoot,'install.json'),'utf8'));}catch{}
 const settings=localSettings(config.localAi||{});
 if(command==='status'){let runtime=null;try{runtime=JSON.parse(await readFile(path.join(localRoot,'runtime-status.json'),'utf8'));}catch{}console.log(JSON.stringify({installed:!!manifest,model:manifest?.textRepo||null,modelsDirectory:localRoot,...await localHealth(settings),runtime},null,2));return;}
 if(command!=='start')throw Error('Use start ou status');if(!manifest)throw Error('Instale primeiro: bash local-ai.sh install');if(manifest.voiceEngine==='qwen3-clone')settings.voiceTimeoutSeconds=180;
 const port=Number(process.env.PORT||3000);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('PORT do jogo inválida');
 for(const value of [port,settings.textPort,settings.voicePort])if(await portOpen(value))throw Error('Porta '+value+' ocupada. Use bash local-ai.sh start para conferir e reiniciar somente esta instalação.');
 await mkdir(path.join(localRoot,'logs'),{recursive:true});log=new RuntimeLog(path.join(localRoot,'logs'));store=new AtomicJson(path.join(localRoot,'runtime-status.json'));let configured=false,configuring=false,announced=false,warmed=false;let device=deviceMetrics();const resources=runtimeProfile(config.runtimeProfile||'gt3');
 const backoff=Number(process.env.BEN10_RESTART_BACKOFF_MS||1000);if(!Number.isInteger(backoff)||backoff<50||backoff>10000)throw Error('Intervalo de recuperação inválido');
 supervisor=new ProcessSupervisor({log,backoffMs:backoff,onChange:s=>{void store.save({build:BUILD_ID,gameRoot,runtimeProfile:resources.id,device,updatedAt:Date.now(),...s});if(!s.stopping&&s.services.game?.state==='ready'&&!configured&&!configuring){configuring=true;const pid=s.services.game.pid;void loopbackRequest(port,'/api/config',{body:{conversationProvider:'local',voiceProvider:'local',localAi:settings}}).then(response=>{if(response.status!==200)throw Error('Configuração local não confirmada');if(supervisor.snapshot().services.game?.pid===pid){configured=true;supervisor.changed();}}).catch(error=>log.event('configuration-pending',{message:error.message})).finally(()=>{if(supervisor.snapshot().services.game?.pid===pid)configuring=false;});}if(configured&&!announced&&['game','text','voice'].every(k=>s.services[k]?.state==='ready')){announced=true;console.log('Conversa e voz locais prontas, sem chave. Abra http://127.0.0.1:'+port+'/?v='+BUILD_ID+' e toque em ♫.');}}});
 const output=filename=>{const sink=new ServiceLog(path.join(localRoot,'logs'),filename);return {stdio:['ignore','pipe','pipe'],output:chunk=>sink.write(chunk)};};
 supervisor.add({id:'game',command:process.execPath,args:[...(existsSync(path.join(gameRoot,'.env'))?['--env-file=.env']:[]),'server/index.js'],cwd:gameRoot,probe:async()=>{const h=await get(port,'/api/health');return h?.build===BUILD_ID&&h.runtime?.root===gameRoot;},onExit:()=>{configured=false;configuring=false;}});
 try{const llama=path.join(localRoot,'llama.cpp/build/bin/llama-server');await access(llama,constants.X_OK);await access(manifest.textModel);supervisor.add({id:'text',command:llama,args:['--model',manifest.textModel,'--alias',settings.model,'--host','127.0.0.1','--port',String(settings.textPort),'--ctx-size','4096','--threads',String(resources.textThreads),'--threads-batch',String(resources.textThreads),'--batch-size','128','--ubatch-size','128','--parallel','1','--threads-http','2','--no-webui','--reasoning','off'],cwd:gameRoot,...output('conversa.log'),probe:async()=>(await get(settings.textPort))?.status==='ok',onReady:()=>{if(warmed)return;warmed=true;void new LocalTextClient().warmup(settings).then(()=>log.event('text-context-ready')).catch(()=>{warmed=false;});},onExit:exit=>{warmed=false;lifecycle('Conversa encerrou: código='+exit.code+' sinal='+exit.signal);}});}catch(error){log.event('service-unavailable',{service:'text',reason:error.message});console.error('Conversa indisponível: '+error.message);}
 try{const voice=await voicePlan(manifest,settings);supervisor.add({id:'voice',...voice,cwd:gameRoot,...output('voz.log'),probe:async()=>{const h=await get(settings.voicePort);return h?.ready===true&&h.build===BUILD_ID;},onExit:exit=>lifecycle('Voz encerrou: código='+exit.code+' sinal='+exit.signal)});}catch(error){log.event('service-unavailable',{service:'voice',reason:error.message});console.error('Voz indisponível; o jogo continuará: '+error.message);}
 lifecycle('Supervisão independente iniciada; até 3 recuperações por serviço.');log.event('supervisor-start',{build:BUILD_ID,pid:process.pid});supervisor.startAll();
 console.log('Jogo em http://127.0.0.1:'+port+'/?v='+BUILD_ID+'. IA carrega separadamente; mantenha esta sessão aberta.');
 heartbeat=setInterval(()=>void supervisor.health(),1500);metrics=setInterval(()=>{device=deviceMetrics();log.event('heartbeat',{...supervisor.snapshot(),device});},15000);await supervisor.health();
 while(!stopping)await pause(500);
}
main().catch(async error=>{console.error(error.message);lifecycle('Falha do iniciador: '+error.message);log?.event('supervisor-error',{message:error.message});await cleanup();process.exitCode=1;});
