# Ben 10 · Clareira LIVE · V44

Evolução da V43.8 em Babylon.js, preservando personagens, cenário, Omnitrix, ranking, presentes, comandos e os motores de voz existentes.

A auditoria e o backup precederam as mudanças. A V44 adiciona supervisão por serviço com limite de recuperação, fila/respostas/recibos persistentes, memória social local, ranking persistido, catálogo de 33 habilidades, vigor, defesa e combos. Regras por tipo de evento separam ações determinísticas de respostas da IA. Há perfis gráficos 30/45/60 FPS, ajuste de resolução, orçamento de efeitos, vegetação leve, água animada, luz, cel shading e câmera gradual.

A voz atual não foi substituída. Foram acrescentados normalização textual, números por extenso, envelope labial e um corpus de avaliação. A clareza e o timbre ainda precisam de avaliação no motor do aparelho.

- [Instalação, atualização, execução e reversão](docs/INSTALACAO_E_REVERSAO_V44.md)
- [Auditoria anterior às mudanças](docs/AUDITORIA_V43_8_PARA_V44.md)
- [Relatório técnico e alterações](docs/RELATORIO_V44_BEN10.md)
- [Problemas pendentes](docs/PENDENCIAS_V44.md)
- Evidências e benchmarks: `reports/v44/`.

Para iniciar uma instalação atualizada: `bash local-ai.sh start`. Abra http://127.0.0.1:3000/?v=44.0.0 e toque em ♫.

O código completo é mantido no workspace de desenvolvimento. O pacote público de atualização contém código e relatórios; não inclui áudio de referência, implementação dos clonadores, pesos ou dados privados. Esses arquivos da sua instalação são preservados. A publicação do pacote completo com áudio/clonagem continua bloqueada pela revisão automática da etapa anterior.

Não há validação de LIVE prolongada em GT3 físico nesta nuvem. O LOCAL-010 teve o encerramento em cascata corrigido em testes, mas a causa inicial da parada no telefone segue aberta. Consulte as pendências antes de considerar a versão validada para uma sessão longa.
