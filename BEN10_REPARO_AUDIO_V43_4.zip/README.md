# Ben 10 · Clareira LIVE · V43.4

Corrige perda de áudio durante geração lenta do clonador. O worker guarda cada WAV pronto e o jogo acompanha a geração por consultas curtas. Uma conexão interrompida não exige sintetizar novamente a mesma fala. O cache local é separado por modelo e referência, limitado a 32 clipes/24 MB e 30 minutos.

A falha foi reproduzida na V43.3: a conexão expirava durante a síntese e a tentativa seguinte gerava a mesma fala novamente. O tempo padrão legado era 60 segundos; o log fornecido pelo usuário mediu 69,5 segundos para gerar 5,1 segundos. O print mostra o estado PREPARANDO VOZ, mas sozinho não confirma qual timeout ocorreu no telefone.

A nova versão mostra o tempo real de geração, mantém a mensagem na fila durante a espera e confirma o término somente depois da reprodução. O teste salvo não é bloqueado pela fila e há um player dentro de LIVE → IA e voz. Copiar diagnóstico de voz reúne estados dos serviços, volume e estado de áudio do navegador, sem chaves de API.

Frases espontâneas e chamadas passivas de TAP TAP aguardam uma primeira síntese rápida antes de ocupar o clonador. Comentários, presentes, chegadas e agradecimentos continuam ativos. A personalidade do Ben clássico é mantida, com respostas mais curtas para reduzir o trabalho da voz. Nenhum fallback usa voz do aparelho ou troca o clone pelo Piper.

## Aplicar o reparo

Pare a sessão antiga com Ctrl+C. Baixe BEN10_REPARO_AUDIO_V43_4.zip. Execute dentro de ~/ben10-v34/game:

```bash
python3 -m zipfile -e ~/storage/downloads/BEN10_REPARO_AUDIO_V43_4.zip "$TMPDIR/ben10-audio-43-4" &&
bash "$TMPDIR/ben10-audio-43-4/REPARAR_AUDIO_V43_4.sh" &&
bash local-ai.sh start
```

Mantenha a sessão aberta e abra http://127.0.0.1:3000/?v=43.4.0. Toque em Entrar ou ♫. LIVE → IA e voz permite ouvir o teste salvo e copiar o diagnóstico.

Não é necessário baixar ou converter os modelos novamente. O reparo preserva GGUF, ONNX, referência, chaves, .env, progresso e fontes APT; cria backup dos arquivos alterados em data/installer-backups.

## Aceleração do motor já instalado

Com os serviços parados, `bash local-ai.sh clone repair-native` recompila somente o motor. FP16 e dotprod são usados apenas se HWCAP do Android confirmar suporte; SVE, SME, i8mm e flags native continuam desativados. Depois execute `bash local-ai.sh start`. Não há novo download de pesos. Para o perfil básico: `BEN10_CLONE_BASELINE=1 bash local-ai.sh clone repair-native`.

## Validação e limites

Regressões exercitam a perda de conexão, a recuperação do WAV após reinício, a separação por referência, cache corrompido, limites do cache e a manutenção da fila. O teste de navegador usa o worker Python de produção com um gerador de tom de 12 segundos, acima do timeout legado de 10 segundos configurado no teste. Ele simula uma consulta interrompida e verifica reprodução WebAudio, ACK depois da fala, preview durante geração e ausência de voz do aparelho.

Não há inferência Qwen real nesta máquina de testes. O usuário confirmou anteriormente que o preview do aparelho contém fala compreensível. A nova entrega não torna a inferência instantânea; a velocidade do perfil ARM precisa ser medida no telefone.
