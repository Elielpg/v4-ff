export const CAGE_RULES=Object.freeze({capacity:50,likes:500,comments:10,dropMs:3200,maxRecords:1500,maxFeasts:12,maxGrowth:600,maxOverflow:50000,feedCooldownMs:1200,shareMs:9000,dayCycleMs:480000});
export const CENTER_CELLS=Object.freeze([101,102,113,114]);
export function dayPhase(now,epoch=now,mode='auto'){const daylight=mode==='day'?1:mode==='night'?0:.5+.5*Math.cos((now-epoch)/CAGE_RULES.dayCycleMs*Math.PI*2);return {daylight,label:daylight>.65?'DIA':daylight<.3?'NOITE':'ENTARDECER'};}
