export const VERSION='0.3.0';
export const RULES=Object.freeze({cols:12,rows:18,startLength:8,minLength:3,maxPlayers:1500,maxFood:32,maxBombs:18,maxPending:180,likesPerFood:20,likesPerShield:100,heroCooldown:6500,villainCooldown:11000,shareCooldown:20000,resultMs:6000,bombDamage:4});
export const GIFTS=Object.freeze([
 {id:'rose',name:'Rosa',image:'rose.webp',team:'villain',effect:'bomb',amount:1,label:'FUGA + BOMBA',hint:'Sai da gaiola e sabota'},
 {id:'gg',name:'GG',image:'gg.webp',team:'hero',effect:'food',amount:3,label:'+3 COMIDAS',hint:'Ajude a crescer'},
 {id:'heart',name:'Heart Me',image:'heart_me.webp',team:'hero',effect:'shield',amount:3,label:'ESCUDO ×3',hint:'Bloqueie explosões'},
 {id:'galaxy',name:'Galáxia',image:'galaxy.webp',team:'hero',effect:'rescue',amount:8,label:'RESGATE +8',hint:'Limpa as bombas'},
 {id:'confetti',name:'Confete',image:'confetti.webp',team:'villain',effect:'bomb',amount:8,label:'+8 BOMBAS',hint:'Caos no caminho'},
 {id:'lion',name:'Leão',image:'lion.webp',team:'villain',effect:'bite',amount:8,label:'MORDIDA −8',hint:'Escudo pode defender'}
]);
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const hash=s=>{let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return h>>>0;};
export function giftRule(value,id){const s=String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();const key=/^(rose|rosa)$/.test(s)||Number(id)===5655?'rose':/^(gg)$/.test(s)?'gg':/heart\s*me/.test(s)?'heart':/galax/.test(s)?'galaxy':/confett?i|confete/.test(s)?'confetti':/^(lion|leao)$/.test(s)?'lion':null;return GIFTS.find(g=>g.id===key)||null;}
