import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile,mkdir,appendFile,stat,rename} from 'node:fs/promises';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {SnakeEngine,avatarURL} from './engine.mjs';
import {Store} from './storage.mjs';
import {TikTokAdapter} from './live.mjs';
import {ShowHost,settings} from './host.mjs';
import {StreamStudio} from './studio.mjs';
import {RhythmBridge} from './rhythm.mjs';
import {VERSION} from '../public/rules.js';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),PORT=Number(process.env.PORT||3500),DATA=process.env.COBRA_DATA_DIR||path.join(ROOT,'data'),store=new Store(DATA),clients=new Set();
const bootId=randomBytes(8).toString('hex');
await mkdir(DATA,{recursive:true,mode:0o700});await mkdir(path.join(ROOT,'logs'),{recursive:true});
let mode='demo',running=false,closing=false,demoTimer=null,bridgeAt=0,speech=null,lastPulse=null;

const session=await store.read('session');if(session?.project==='cobra-do-caos'&&session.mode==='live')mode='live';
running=!!session?.running;
const config=await store.read('config');
let hostConfig;try{hostConfig=settings(config?.host);}catch{hostConfig=settings();}
const rhythm=new RhythmBridge(),engines={};
const emit=(name,data)=>{const msg=`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`;for(const c of clients)if(c.writableLength>256000){c.destroy();clients.delete(c);}else c.write(msg);};
async function log(kind,data={}){try{const f=path.join(ROOT,'logs/server.jsonl');if((await stat(f).catch(()=>({size:0}))).size>1e6)await rename(f,f+'.1').catch(()=>{});await appendFile(f,JSON.stringify({at:new Date().toISOString(),kind,...data})+'\n');}catch{}}
const studio=new StreamStudio({onLog:entry=>{void log('studio',entry);}});
const host=new ShowHost({dir:path.join(DATA,'voice-cache'),config:hostConfig,getState:user=>{const e=engines[mode];return {...e.public(),viewer:user?e.cage.records.get(user):null,memory:Object.fromEntries([...e.players.values()].filter(p=>p.history?.length).map(p=>[p.id,p.history]))};},onSpeech:a=>{speech=a;emit('speech',a);if(a.kind==='local-ai'&&a.user){const p=engines[mode].players.get(a.user);if(p){p.history=[...(p.history||[]),{q:a.prompt,a:a.text}].slice(-3);void save();}}}});
for(const name of ['demo','live'])engines[name]=new SnakeEngine({mode:name,saved:await store.read(name),onAction:a=>{if(name===mode){emit('action',a);host.event(a);}if(['win','loss','gift','hero','villain','cageEnter','cageEscape','cageBanquet','banquetEat','cageReset'].includes(a.kind)&&engines[name])void store.save(name,engines[name].save()).catch(e=>log('save-error',{message:e.message}));}});
let bridgeToken;try{bridgeToken=JSON.parse(await readFile(path.join(DATA,'bridge.json'),'utf8')).token;}catch{}if(!/^[a-f0-9]{64}$/.test(bridgeToken||'')){bridgeToken=randomBytes(32).toString('hex');await writeFile(path.join(DATA,'bridge.json'),JSON.stringify({token:bridgeToken}),{mode:0o600});}
const adapter=new TikTokAdapter(e=>{engines.live.ingest(e);},s=>{emit('connection',s);void log('connection',{status:s.status,message:s.message});});
const connection=()=>Date.now()-bridgeAt<30000?{status:'connected',message:'Ponte local recebendo eventos',provider:'bridge'}:adapter.state;
const snapshot=()=>({...engines[mode].public(),bootId,running,connection:connection(),host:{...host.status,enabled:host.config.enabled},speech: speech?.until>Date.now()?speech:null,rhythm:rhythm.status(),storageError:store.error});
async function save(){await Promise.all(Object.entries(engines).map(([n,e])=>store.save(n,e.save())));}
const saveSession=()=>store.save('session',{project:'cobra-do-caos',mode,running});
const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data));};
async function body(req){if(!String(req.headers['content-type']||'').startsWith('application/json'))throw Object.assign(Error('Use JSON'),{status:415});const origin=req.headers.origin;if(origin&&!['http://127.0.0.1:'+PORT,'http://localhost:'+PORT].includes(origin))throw Object.assign(Error('Origem recusada'),{status:403});let b='';for await(const v of req){b+=v;if(Buffer.byteLength(b)>32768)throw Object.assign(Error('Requisição muito grande'),{status:413});}try{return JSON.parse(b||'{}');}catch{throw Object.assign(Error('JSON inválido'),{status:400});}}
async function switchMode(next){if(!['demo','live'].includes(next))throw Error('Modo inválido');clearInterval(demoTimer);demoTimer=null;await adapter.disconnect();bridgeAt=0;rhythm.revoke();await save();mode=next;running=false;speech=null;host.reset();await saveSession();emit('mode',{mode});}
function startDemo(){clearInterval(demoTimer);const e=engines.demo;for(const name of ['Luna','Pixel','Bia','Nando'])e.ingest({type:'join',user:'demo_'+name.toLowerCase(),name:name+' · DEMO'});let step=0;demoTimer=setInterval(()=>{if(mode!=='demo'||!running)return;step++;const name=['Luna','Pixel','Bia','Nando'][step%4],user='demo_'+name.toLowerCase();if(step%2===0)e.ingest({type:'join',user:'demo_visitante_'+step,name:'Visitante '+step+' · DEMO',id:'join-demo-'+step});e.ingest({type:step%11===0?'gift':step%4===0?'comment':'like',user,name:name+' · DEMO',text:step%8===0?'VILÃO':'HERÓI',gift:'Rosa',count:step%11===0?1:20,id:'demo-'+randomBytes(6).toString('hex'),repeatEnd:true});},1800);demoTimer.unref();}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.wav':'audio/wav','.mp3':'audio/mpeg','.json':'application/json','.ttf':'font/ttf','.apk':'application/vnd.android.package-archive'};
const server=http.createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://127.0.0.1'),p=url.pathname;
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
 if(req.method==='GET'&&p==='/api/health')return json(res,200,{ok:true,project:'cobra-do-caos',version:VERSION,pid:process.pid,mode,running});
 if(req.method==='GET'&&p==='/api/state')return json(res,200,snapshot());
 if(req.method==='GET'&&p==='/api/studio')return json(res,200,{...studio.status(),capability:await studio.capability()});
 if(req.method==='GET'&&p==='/api/host')return json(res,200,await host.health());
 if(req.method==='GET'&&p==='/api/backup'){res.setHeader('content-disposition','attachment; filename="COBRA_BACKUP.json"');return json(res,200,engines[mode].save());}
 if(req.method==='GET'&&p==='/api/events'){
  if(clients.size>=12)return json(res,429,{error:'Muitas telas abertas'});
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});res.write('retry: 1800\n\n');clients.add(res);res.write('event: state\ndata: '+JSON.stringify(snapshot())+'\n\n');req.on('close',()=>clients.delete(res));return;
 }
 if(req.method==='POST'&&p==='/api/studio/chunk'){
  const origin=req.headers.origin;if(origin&&!['http://127.0.0.1:'+PORT,'http://localhost:'+PORT].includes(origin))throw Object.assign(Error('Origem recusada'),{status:403});
  if(!String(req.headers['content-type']||'').startsWith('video/webm'))throw Object.assign(Error('Use um gravador WebM compatível.'),{status:415});
  const parts=[];let size=0;for await(const part of req){size+=part.length;if(size>2e6)throw Object.assign(Error('Imagem excede limite.'),{status:413});parts.push(part);}return json(res,200,await studio.chunk(req.headers['x-studio-session'],Number(req.headers['x-studio-seq']),Buffer.concat(parts)));
 }
 if(req.method==='POST'&&p.startsWith('/api/')){
  const b=await body(req);
  if(p==='/api/studio/start')return json(res,200,await studio.start(b));
  if(p==='/api/studio/stop')return json(res,200,await studio.stop());
  if(p==='/api/mode'){await switchMode(b.mode);return json(res,200,snapshot());}
  if(p==='/api/start'){if(!running){running=true;engines[mode].lastTick=Date.now();host.say('start',{priority:3});if(mode==='demo'&&b.simulate!==false)startDemo();await saveSession();}return json(res,200,snapshot());}
  if(p==='/api/stop'){running=false;clearInterval(demoTimer);demoTimer=null;host.reset();speech=null;await saveSession();return json(res,200,snapshot());}
  if(p==='/api/cage/reset'){engines[mode].cage.reset();await save();return json(res,200,snapshot());}
  if(p==='/api/test-cage-fill'){if(mode!=='demo')return json(res,403,{error:'Simulação disponível somente na demonstração'});const n=50-engines.demo.cage.members.length;for(let i=0;i<n;i++){const id='demo_cage_'+randomBytes(6).toString('hex');engines.demo.ingest({type:'join',user:id,name:'Visitante '+(i+1)+' · DEMO',id});}return json(res,200,snapshot());}
  if(p==='/api/test-mission'){if(mode!=='demo')return json(res,403,{error:'Simulação disponível somente na demonstração'});const user=String(b.user||'demo_missao').slice(0,64),name=String(b.name||'Missão · DEMO').slice(0,36);if(b.kind==='comments'){for(let i=0;i<10;i++)engines.demo.ingest({type:'comment',user,name,text:'HERÓI',id:'mission-'+randomBytes(6).toString('hex')});}else if(b.kind==='likes')engines.demo.ingest({type:'like',user,name,count:500,id:'mission-'+randomBytes(6).toString('hex')});else throw Error('Missão de teste inválida');return json(res,200,snapshot());}
  if(p==='/api/test-event'){if(mode!=='demo')return json(res,403,{error:'Simulação disponível somente na demonstração'});engines.demo.ingest(b);return json(res,200,snapshot());}
  if(p==='/api/connect'){const username=String(b.username||'').replace(/^@/,'').trim();if(!/^[a-z0-9_.]{2,24}$/i.test(username))throw Error('Informe somente o @ da conta');if(mode!=='live')await switchMode('live');void adapter.connect(username).catch(e=>log('connect-error',{message:e.message}));return json(res,202,{ok:true,message:'Conexão solicitada; aguarde confirmação'});}
  if(p==='/api/disconnect'){await adapter.disconnect();bridgeAt=0;return json(res,200,{ok:true});}
  if(p==='/api/host-config'){host.configure(b);await store.save('config',{host:host.config});return json(res,200,{ok:true,config:host.config});}
  if(p==='/api/ask'){const user=String(b.user||'operador').slice(0,64),name=String(b.name||'Você').slice(0,36);engines[mode].get(user,name);const accepted=host.ask({user,name,text:String(b.text||'').slice(0,180)});return json(res,202,{accepted,status:host.status});}
  if(p==='/api/rhythm/code')return json(res,200,rhythm.issue());
  if(p==='/api/rhythm/pair')return json(res,200,rhythm.pair(b.code));
  if(p==='/api/rhythm/config'){if(!Number.isInteger(b.offset)||b.offset<0||b.offset>400)throw Error('Compensação deve estar entre 0 e 400 ms.');rhythm.offset=b.offset;return json(res,200,rhythm.status());}
  if(p==='/api/rhythm/frame'){const frames=b.frames===undefined?[b]:b.frames;if(!Array.isArray(frames)||frames.length<1||frames.length>24)throw Error('Lote de áudio deve ter de 1 a 24 quadros.');let accepted=0,hits=0;for(const frame of frames){const r=rhythm.frame(req.headers.authorization,frame);if(r.accepted)accepted++;if(r.hit){hits++;lastPulse={at:r.at+rhythm.offset,strength:r.strength||.6};emit('beat',lastPulse);}}return json(res,200,{accepted:accepted>0,frames:accepted,hits});}
  if(p==='/api/rhythm/disconnect'){rhythm.revoke();return json(res,200,{ok:true});}
  if(p==='/api/bridge'){
   const token=String(req.headers.authorization||'').replace(/^Bearer /,'');if(!/^[a-f0-9]{64}$/.test(token)||!timingSafeEqual(Buffer.from(token),Buffer.from(bridgeToken)))return json(res,403,{error:'Token de ponte necessário'});
   if(mode!=='live')return json(res,409,{error:'Ative o modo LIVE antes da ponte'});bridgeAt=Date.now();engines.live.ingest(b);return json(res,200,{ok:true});
  }
  return json(res,404,{error:'Ação não encontrada'});
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Método não permitido'});
 if(p.startsWith('/api/'))return json(res,404,{error:'API não encontrada'});
 const decoded=decodeURIComponent(p);let file;
 if(/^\/voice-cache\/[a-f0-9]{64}\.wav$/.test(decoded))file=path.join(DATA,'voice-cache',path.basename(decoded));
 else{if(decoded.includes('\0')||decoded.split('/').some(x=>x==='..'||x.startsWith('.')))return json(res,403,{error:'Caminho recusado'});file=path.join(ROOT,'public',decoded==='/'?'index.html':decoded);if(!file.startsWith(path.join(ROOT,'public')+path.sep))return json(res,403,{error:'Caminho recusado'});}
 const bytes=await readFile(file);res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':/\.(js|css|html)$/.test(file)?'no-cache':'public, max-age=3600'});res.end(req.method==='HEAD'?undefined:bytes);
 }catch(e){if(!res.headersSent)json(res,e.status||((e.code==='ENOENT'||e.code==='EISDIR')?404:400),{error:e.code==='ENOENT'?'Arquivo não encontrado':String(e.message).slice(0,180)});else res.end();}});
server.on('error',e=>{void log('listen-error',{code:e.code});console.error(e.code==='EADDRINUSE'?'Porta '+PORT+' ocupada. Use bash stop.sh na instalação correspondente.':e.message);process.exitCode=e.code==='EADDRINUSE'?78:1;clearInterval(tick);clearInterval(broadcast);clearInterval(autosave);clearInterval(metrics);clearInterval(heartbeat);host.close();});
const tick=setInterval(()=>{if(running)engines[mode].tick();},50),broadcast=setInterval(()=>{if(clients.size)emit('state',snapshot());},200),autosave=setInterval(()=>{void save().catch(e=>log('save-error',{message:e.message}));},1500),metrics=setInterval(()=>{void log('health',{rss:process.memoryUsage().rss,mode,phase:engines[mode].phase,clients:clients.size,running,connection:connection().status});},60000),heartbeat=setInterval(()=>{for(const c of clients)c.write(': ping\n\n');},10000);
server.listen(PORT,'127.0.0.1',()=>{console.log('COBRA DO CAOS · v'+VERSION+'\nAbra http://127.0.0.1:'+PORT);void log('start',{version:VERSION,pid:process.pid,mode});});
async function shutdown(signal){if(closing)return;closing=true;running=false;host.close();await studio.close();clearInterval(demoTimer);for(const t of [tick,broadcast,autosave,metrics,heartbeat])clearInterval(t);await adapter.disconnect();await save().catch(()=>{});await store.flush();await log('stop',{signal});for(const c of clients)c.end();server.close();setTimeout(()=>process.exit(0),500).unref();}
process.on('SIGINT',()=>void shutdown('SIGINT'));process.on('SIGTERM',()=>void shutdown('SIGTERM'));
