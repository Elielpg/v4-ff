export const BUILD_ID='40.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 40.0.0';
