import {geminiResponseError,geminiNetworkError} from './gemini-errors.js';
import {parseArenaCommand} from '../public/arena-commands.js';
import {DEFAULT_GIFT_RULES,DEFAULT_COMMAND_RULES,giftKey,giftReaction} from '../public/audience.js';
import {addressedSpeaker,guardIdentity,personaSystem} from './personas.js';
import {classicContext,classicSystem,localClassicReply} from './classic.js';
import {SPEAKERS,speakerId} from '../public/characters.js';
import {namedTransformation,asksPower,asksMovement,asksGesture,missionRequest} from '../public/transformations.js';
import { randomUUID } from 'node:crypto';
export const FORMS=['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'];
export const DISTRICTS=['Praça Aurora','Jardim das Águas','Mercado Solar','Vila Cristal','Parque das Estrelas','Centro Cultural'];
const LIVE_RANKS=[{name:'Novato',minimum:0},{name:'Fã',minimum:25},{name:'Apoiador',minimum:100},{name:'Guardião',minimum:300},{name:'Lenda',minimum:750},{name:'Mítico',minimum:2000}];
export function liveRankForPoints(points){
 const score=Math.max(0,Number(points)||0);let index=0;
 for(let i=1;i<LIVE_RANKS.length;i++)if(score>=LIVE_RANKS[i].minimum)index=i;
 const current=LIVE_RANKS[index],next=LIVE_RANKS[index+1];
 return {rankName:current.name,rankLevel:index+1,nextRank:next?.name||null,nextRankAt:next?.minimum||null,rankProgress:next?Math.round(Math.min(1,(score-current.minimum)/(next.minimum-current.minimum))*100):100};
}
export class EventHub {
 constructor(){this.seen=new Map();this.ranking=new Map();this.totalEnergy=0;this.giftRules=DEFAULT_GIFT_RULES.map(rule=>({...rule}));this.commandRules=DEFAULT_COMMAND_RULES.map(rule=>({...rule}));this.listeners=new Set();}
 ingest(input,source='demo'){
  if(!['comment','gift','like','follow','share','join'].includes(input.type))throw Error('Tipo de evento inválido');
  if(input.type==='gift'&&input.repeatEnd===false)return null;
  const id=String(input.id||randomUUID());if(this.seen.has(id))return null;
  if(this.seen.size>5000)this.seen.delete(this.seen.keys().next().value);this.seen.set(id,Date.now());
  const user=String(input.user||'Visitante').slice(0,40).replace(/[<>]/g,'');const text=String(input.text||'').slice(0,500);
  const count=Math.min(1000,Math.max(1,Number(input.count)||1));
  const rule=input.type==='gift'?this.giftRules.find(r=>giftKey(r.name)===giftKey(input.gift||'')):null;
  const points=input.type==='gift'?(rule?.points??5)*count:input.type==='like'?count:input.type==='follow'?5:1;
  const entry=this.ranking.get(user)||{user,points:0,giftCredit:0,gifts:0,likes:0,follows:0,shares:0,comments:0,visits:0,events:0};
  this.totalEnergy=Math.min(Number.MAX_SAFE_INTEGER,this.totalEnergy+points);entry.points+=points;entry.events++;entry.lastEventType=input.type;entry.lastSeen=Date.now();
  if(input.type==='gift'){entry.gifts+=count;entry.giftCredit=Math.min(3,entry.giftCredit+1);}
  if(input.type==='like')entry.likes+=count;
  if(input.type==='follow')entry.follows++;
  if(input.type==='share')entry.shares++;
  if(input.type==='comment')entry.comments++;
  if(input.type==='join')entry.visits++;
  this.ranking.set(user,entry);
  const command=input.type==='comment'?this.commandRules.find(r=>r.command.toLowerCase()===text.trim().toLowerCase()):null;
  const mission=input.type==='comment'?missionRequest(text):null;
  const event={id,type:input.type,user,text,gift:String(input.gift||'').slice(0,80),count,points,powerLevel:input.type==='gift'?Math.max(1,Math.min(5,1+Math.floor(Math.log2(Math.max(1,points/10))))):1,action:command?.action||rule?.action||(input.type==='comment'?namedTransformation(text):null),movement:command?.movement||rule?.movement||(input.type==='comment'?asksMovement(text):null),gesture:command?.gesture||(input.type==='comment'?asksGesture(text):null),speaker:input.type==='comment'?addressedSpeaker(text):null,mission:!!(command?.mission||command?.missionKind||rule?.mission||rule?.missionKind||mission),missionKind:command?.missionKind||rule?.missionKind||mission?.kind||null,power:!!(command?.power||rule?.power||input.type==='comment'&&asksPower(text)),source,time:Date.now()};
  event.direction=rule?.direction||command?.direction||null;event.powerVariant=rule?.powerVariant??command?.powerVariant??null;event.energy=this.totalEnergy;event.training=input.type==='comment'&&/^(?:\/)?(?:treinar|treino)$/.test(text.trim().toLowerCase());
  event.control=input.type==='comment'?parseArenaCommand(text):null;
  if(event.mission)event.movement=null;
  if(event.speaker){event.action=null;event.power=false;event.mission=false;event.missionKind=null;event.movement=null;event.gesture=null;}
  if(input.type==='gift'&&(event.action||event.power||event.movement||event.mission))event.reaction=giftReaction(event);
  for(const f of this.listeners)f(event);return event;
 }
 leaders(){return [...this.ranking.values()].sort((a,b)=>b.points-a.points||b.events-a.events||a.user.localeCompare(b.user)).slice(0,20).map((entry,index)=>({...entry,position:index+1,...liveRankForPoints(entry.points)}));}
}
export class SpeechQueue {
 constructor({onChange=()=>{},timeout=45000}={}){this.items=[];this.active=null;this.onChange=onChange;this.timeout=timeout;this.timer=null;this.completed=0;this.turn=0;}
 enqueue(item){if(this.items.length>=50)return false;this.items.push({...item,id:randomUUID(),created:Date.now()});this.next();this.onChange(this.snapshot());return true;}
 next(){if(this.active||!this.items.length)return;this.turn++;this.items.sort((a,b)=>this.turn%3===0?a.created-b.created:(b.priority||0)-(a.priority||0)||a.created-b.created);this.active=this.items.shift();this.timer=setTimeout(()=>this.ack(this.active?.id),this.timeout);this.timer.unref?.();this.onChange(this.snapshot());}
 ack(id){if(!this.active||this.active.id!==id)return false;clearTimeout(this.timer);this.active=null;this.completed++;this.next();this.onChange(this.snapshot());return true;}
 snapshot(){return {active:this.active,waiting:this.items,completed:this.completed};}
 close(){clearTimeout(this.timer);}
}
export function wav(pcm){const b=Buffer.alloc(44);b.write('RIFF');b.writeUInt32LE(pcm.length+36,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(24000,24);b.writeUInt32LE(48000,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(pcm.length,40);return Buffer.concat([b,pcm]);}
let proxyDispatcher;
export async function providerFetch(url,options){if(!process.env.HTTPS_PROXY&&!process.env.HTTP_PROXY)return fetch(url,options);const {fetch:proxyFetch,EnvHttpProxyAgent}=await import('undici');proxyDispatcher??=new EnvHttpProxyAgent();return proxyFetch(url,{...options,dispatcher:proxyDispatcher});}
export async function gemini(text,{tts=false,fetcher=providerFetch,key=process.env.GEMINI_API_KEY,speaker='base',context={},system,json=false,model:chosenModel}={}){
 if(!key)throw Error('GEMINI_API_KEY ausente no servidor');
 const model=tts?(process.env.GEMINI_TTS_MODEL||'gemini-2.5-flash-preview-tts'):(chosenModel||process.env.GEMINI_MODEL||'gemini-2.5-flash');
 const profile=SPEAKERS[speakerId(speaker)];
 const body=tts?{contents:[{parts:[{text:'Fale em português brasileiro. Direção de voz: '+profile.direction+'\nTexto: '+text}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:profile.voice}}}}}:{systemInstruction:{parts:[{text:system||personaSystem(context.speaker)||classicSystem(context)}]},contents:[{role:'user',parts:[{text:system?text:'Referência local de continuidade (se relevante):\n'+classicContext(text)+'\nPergunta do espectador:\n'+text}]}],...(json?{generationConfig:{responseMimeType:'application/json',temperature:.95}}:{})};
 const start=Date.now();let r;try{r=await fetcher('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model)+':generateContent',{method:'POST',headers:{'content-type':'application/json','x-goog-api-key':key},body:JSON.stringify(body),signal:AbortSignal.timeout(25000)});}catch{throw geminiNetworkError();}
 if(!r.ok)throw await geminiResponseError(r);const data=await r.json();const parts=data.candidates?.[0]?.content?.parts||[];
 if(tts){const audio=parts.find(p=>p.inlineData)?.inlineData;if(!audio||!audio.mimeType?.startsWith('audio/'))throw Error('Resposta sem áudio');const pcm=Buffer.from(audio.data,'base64');return {audio:(audio.mimeType.includes('L16')||audio.mimeType.includes('pcm')?wav(pcm):pcm).toString('base64'),mime:audio.mimeType.includes('L16')||audio.mimeType.includes('pcm')?'audio/wav':audio.mimeType,model,latency:Date.now()-start};}
 const answer=parts.filter(p=>!p.thought).map(p=>p.text||'').join('').trim();if(!answer)throw Object.assign(Error(data.promptFeedback?.blockReason?'O Google bloqueou esta resposta. Tente reformular a pergunta.':'O Google respondeu sem texto. Tente novamente ou use outro modelo disponível.'),{code:data.promptFeedback?.blockReason?'gemini_blocked':'gemini_empty',category:'response'});return {text:system?answer:guardIdentity(answer,context.speaker||context.form),model,latency:Date.now()-start};
}
export const localReply=localClassicReply;
