import {createHash} from 'node:crypto';
import {GeminiTextClient} from './gemini-text.js';
import {answerComment} from './conversation.js';
export class AISession{
 constructor({keys,getConfig=()=>({}),client=new GeminiTextClient(),onChange=()=>{},now=Date.now}={}){this.keys=keys;this.getConfig=getConfig;this.client=client;this.onChange=onChange;this.now=now;this.last=null;this.answers=new Map();}
 selection(){const key=this.keys.key(),state=this.keys.status(),model=this.getConfig().conversationModel||'auto',token=createHash('sha256').update((key||'')+':'+model+':'+(this.keys.revision||0)).digest('hex');return {key,keyLabel:state.selectedLabel,model,token};}
 status(){const selected=this.selection(),same=this.last?.token===selected.token;return {keyConfigured:!!selected.key,keyLabel:selected.keyLabel,requestedModel:selected.model,state:!selected.key?'missing':same?this.last.state:'configured',...(same?{model:this.last.model||null,verifiedAt:this.last.verifiedAt||null,code:this.last.code||null,message:this.last.message||null}:{}),serverTime:this.now()};}
 invalidate(){this.last=null;this.answers.clear();this.onChange(this.status());}
 record(selection,answer){if(selection.token!==this.selection().token)return;this.last={token:selection.token,state:answer.mode==='gemini'?'ready':'error',model:answer.model,verifiedAt:answer.mode==='gemini'?this.now():null,code:answer.code,message:answer.mode==='gemini'?'Gemini respondeu com a chave selecionada.':answer.warning};this.onChange(this.status());}
 async answer(item,context={}){const selected=this.selection(),cacheId=String(item.id||'')+':'+selected.token,cached=item.id&&this.answers.get(cacheId);if(cached&&this.now()-cached.at<120000)return cached.promise;const promise=answerComment(item,{key:selected.key,keyLabel:selected.keyLabel,model:selected.model,context,generate:(text,options)=>this.client.generate(text,options)}).then(answer=>{this.record(selected,answer);return {...answer,keyConfigured:!!selected.key};});if(item.id){this.answers.set(cacheId,{at:this.now(),promise});if(this.answers.size>64)this.answers.delete(this.answers.keys().next().value);}return promise;}
 async test(prompt='Qual é o seu nome?',context={}){const answer=await this.answer({prompt,user:'Teste',speaker:'base'},context);return {ok:answer.mode==='gemini',...answer,status:this.status()};}
 async models(){const {key}=this.selection();return this.client.models(key,{refresh:true});}
}
