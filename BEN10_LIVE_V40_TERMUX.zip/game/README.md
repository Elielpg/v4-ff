# Ben 10 · Clareira LIVE · V40

**V40:** correções na seleção/teste de chaves Gemini, modelo automático e avisos corretos de falha. TAP TAP gera esferas verdes e curtidas acumuladas desbloqueiam as transformações, com barra do próximo alien e progresso salvo.

Uma clareira inspirada no acampamento do clássico, controlada por chat e presentes. Missões de interação da comunidade, sem tarefas de cidade: movimento livre em dois eixos, onze formas com três poderes cada e um Omnitrix com seleção, transformação, tempo restante e recarga verde/vermelha.

O DNA começa com Ben humano. Chama libera com 100 curtidas acumuladas. Ajuste as metas ou ative o modo livre em **LIVE → Laboratório → DNA por TAP TAP**.

```sh
bash install.sh
bash start.sh
```

Abra no Chrome do mesmo aparelho o endereço indicado e toque em **♫ Ativar som**. Confira **40.0.0**. [IA, energia verde e desbloqueios](docs/V40_IA_E_DNA.md).

Se instalou a versão anterior em `~/ben10-v34/game`, atualize preservando dados:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V40_TERMUX.zip --start
```

Comandos: `andar esquerda`, `correr direita`, `frente`, `trás`, `pular`, `girar`, `parar`, nome de um alien, `voar`, `pousar`, `dash` com XLR8 e `poder 1/2/3`. Também: `sentar`, `levantar`, `sorrir`, `acenar` e `comemorar`. O painel de comandos mantém o padrão anterior. Perguntas continuam na conversa.

## Desenvolvimento

Node >=22.19, npm e Python 3. Use o checkout existente; cada tarefa cloud já é isolada.

- `npm ci`: dependências fixadas no lockfile.
- `npm test`: testes de domínio, HTTP/SSE, relógio, filas, modelos e atualizador.
- `npm run lint`: sintaxe JavaScript.
- `npm run build`: assets e licenças Babylon locais, sem CDN.
- `npm run package`: verificações e ZIP, sem `data/`, `.env` pessoal ou `node_modules`.
- `node scripts/v40-isolated-check.js`: integração em uma cópia temporária, com provedor Gemini offline e sem dados pessoais da instalação.
- `node scripts/v36-clock-check.js`: ciclo real do Omnitrix no navegador.
- `node scripts/archive-smoke.js ../BEN10_LIVE_V40_TERMUX.zip`: extrai e inicia o pacote usando as dependências locais do mesmo lockfile.

Código AGPL-3.0 e fontes correspondentes do conector incluídos. Nove GLBs de terceiros e seus créditos/licenças permanecem no pacote; Quatro Braços, Alien X e Cipó Selvagem usam novas formas procedurais por padrão. [Créditos](docs/MODEL_CREDITS.md), `third_party/NOTICE.md`. Projeto de fã, sem afiliação oficial. Efeitos e vozes não são os arquivos/gravações oficiais.

A conversa livre exige uma chave Gemini com acesso e cota. A voz grátis usa Web Speech e as vozes em português do aparelho, com tom/ritmo ajustáveis; não usa chave TTS. Leia o guia da V38 para ativar a voz após atualizar uma instalação antiga. Vozes externas e LIVE dependem de credenciais/acesso no aparelho. A validação cloud usa eventos simulados e não substitui teste em Android físico.
