import {mkdirSync,existsSync,statSync,renameSync,appendFileSync} from 'node:fs';
import path from 'node:path';
export function renderDiagnostic(value={}){if(!['context-lost','context-restored','frame-error'].includes(value.kind))throw Error('Diagnóstico inválido');const data={kind:value.kind,message:String(value.message||'').slice(0,400)};for(const key of ['meshes','materials','textures','recoveries'])if(Number.isFinite(value[key]))data[key]=Math.max(0,Math.min(100000,value[key]));return data;}
export class RenderLog {
 constructor(root){this.root=root;}
 event(type,data){try{mkdirSync(this.root,{recursive:true,mode:0o700});const file=path.join(this.root,'render.jsonl');if(existsSync(file)&&statSync(file).size>=1024*1024)renameSync(file,file+'.1');appendFileSync(file,JSON.stringify({at:new Date().toISOString(),type,...data})+'\n',{mode:0o600});}catch{}}
}
