// Narrow, verifiable answers. Unrecognized or compound questions go to the LLM.
import {clean} from '../public/transformations.js';
import {spokenNumber} from '../public/spoken-number.js';
const units={zero:0,um:1,uma:1,dois:2,duas:2,tres:3,quatro:4,cinco:5,seis:6,sete:7,oito:8,nove:9,dez:10,onze:11,doze:12,treze:13,catorze:14,quatorze:14,quinze:15,dezesseis:16,dezasseis:16,dezessete:17,dezoito:18,dezenove:19,vinte:20,trinta:30,quarenta:40,cinquenta:50,sessenta:60,setenta:70,oitenta:80,noventa:90,cem:100};
function number(text){
 text=text.trim();if(/^-?\d{1,3}(?:\.\d{3})+(?:,\d+)?$/.test(text))text=text.replace(/\./g,'');text=text.replace(',','.');if(/^-?\d{1,7}(?:\.\d{1,6})?$/.test(text))return Number(text);
 if(Object.hasOwn(units,text))return units[text];
 const parts=text.split(' e ');if(parts.length===2&&units[parts[0]]>=20&&units[parts[0]]%10===0&&units[parts[1]]>0&&units[parts[1]]<10)return units[parts[0]]+units[parts[1]];
 return null;
}
export function directAnswer(input,context={}){
 const original=String(input||'').trim();if(original.length>220)return null;
 const text=original.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/^\s*(?:oi[,! ]+|ola[,! ]+)?(?:ben(?: 10| tennyson)?[,!: ]+)*/,'').replace(/[?!.]+$/,'').trim();
 const math=text.replace(/^(?:quanto (?:e|da|faz)|calcule|quanto e que da)\s+/,'').match(/^([\w,. -]+?)\s*(vezes|multiplicado por|dividido por|mais|menos|\+|\*|×|x|\/|÷|-)\s*([\w,. -]+)$/);
 if(math){const a=number(math[1]),b=number(math[3]),op=math[2];if(a!==null&&b!==null){if(['/','÷','dividido por'].includes(op)&&b===0)return {text:'Não dá para dividir por zero!',reason:'arithmetic'};const value=['+','mais'].includes(op)?a+b:['-','menos'].includes(op)?a-b:['/','÷','dividido por'].includes(op)?a/b:a*b;if(Number.isFinite(value)&&Math.abs(value)<=1e12){const formatted=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:6}).format(value);const approximate=Math.abs(value-Number(value.toFixed(6)))>1e-10;return {text:'Dá '+(approximate?'aproximadamente ':'')+formatted+'!',spokenText:'Dá '+(approximate?'aproximadamente ':'')+spokenNumber(value)+'!',reason:'arithmetic'};}}}
 const q=clean(text).replace(/^(?:me diga|me fala|me fale) /,'');
 const known=[
  [/^(?:por que chove|como (?:se forma|acontece) a chuva)$/,'A água evapora, esfria nas nuvens e vira gotinhas. Quando ficam pesadas, caem como chuva!'],
  [/^(?:por que (?:o )?ceu e azul)$/,'O ar espalha mais a luz azul do Sol que a vermelha. Por isso o céu parece azul!'],
  [/^(?:por que anoitece|por que existe (?:o )?dia e (?:a )?noite)$/,'A Terra gira. Quando nosso lado fica virado para longe do Sol, é noite!']
 ];
 for(const [pattern,text] of known)if(pattern.test(q))return {text,reason:'knowledge'};

 const facts=[
  [/^(?:quem e voce|qual e (?:o )?seu nome|qual seu nome|como voce se chama)$/,'Sou Ben Tennyson! O cara do Omnitrix.'],
  [/^(?:quantos anos voce tem|qual (?:e )?(?:a )?sua idade)$/,'Tenho dez anos! E aventura não falta nas férias.'],
  [/^(?:quem (?:criou|inventou|fez) (?:o )?omnitrix|quem e (?:o )?criador do omnitrix)$/,'Foi o Azmuth, um galvan. O relógio dele mudou minhas férias!'],
  [/^(?:quem e (?:a )?gwen|(?:a )?gwen e sua prima)$/,'A Gwen é minha prima. Ela tem dez anos e adora provar que está certa!'],
  [/^(?:quem e (?:o )?(?:vo |avo )?max|seu avo era (?:um )?encanador)$/,'Meu vô Max foi um Encanador, agente que enfrenta ameaças alienígenas. E dirige o Lata Velha!'],
  [/^(?:qual (?:foi|e) (?:o )?(?:seu )?primeiro alien|qual foi sua primeira transformacao)$/,'Foi o Chama! Encontrei o Omnitrix no acampamento e virei um pyronita.'],
  [/^(?:quem e (?:o )?vilgax)$/,'Vilgax vive atrás do meu Omnitrix. Mas entregar o relógio para ele está fora de questão!'],
  [/^(?:quantos aliens (?:tem|existem|havia) (?:no )?(?:omnitrix )?(?:original|inicial|classico)|quantas formas (?:iniciais|originais) voce tinha)$/,'Comecei com dez formas alienígenas. Outras foram desbloqueadas depois!'],
  [/^(?:xlr8 (?:e|solta|usa) (?:raio|raios|eletricidade)|o poder do xlr8 e eletricidade)$/,'O poder principal do XLR8 é supervelocidade, não eletricidade!'],
  [/^(?:alien x (?:e|faz parte) do classico|alien x (?:aparece|existe) no classico)$/,'Alien X apareceu em Força Alienígena. No nosso jogo, ele é uma forma extra!'],
  [/^(?:qual e (?:o )?(?:seu )?alien favorito|qual seu alien favorito)$/,'Quatro Braços é demais! Às vezes resolver na força parece uma boa ideia.']
 ];
 for(const [pattern,text] of facts)if(pattern.test(q))return {text,reason:'classic'};
 if(/^(?:quantas curtidas faltam|quanto falta de curtidas|quantos likes faltam)(?: para (?:o )?proximo alien)?$/.test(q)&&context.alienUnlocks){if(context.alienUnlocks.enabled===false)return {text:'As formas estão livres! Não precisa juntar curtidas para escolher um alien.',reason:'game'};const next=context.alienUnlocks.next;return {text:next?'Faltam '+next.remaining+' curtidas para liberar '+next.name+'!':'Todos os DNAs dessa coleção já foram liberados!',reason:'game'};}
 return null;
}
