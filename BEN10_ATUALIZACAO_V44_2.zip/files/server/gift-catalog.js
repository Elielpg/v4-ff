import {createHash} from 'node:crypto';
import {AtomicJson} from './atomic-json.js';
import {AvatarProxy} from './avatar-proxy.js';
import {safeGiftImage,giftPhotoKey} from '../public/gift-photos.js';
// Only URLs observed in TikTok event/catalog data can be requested by opaque ID.
export class GiftCatalog {
 constructor(file,{onChange=()=>{},fetcher}={}){this.store=new AtomicJson(file);this.entries=new Map();this.onChange=onChange;this.images=new AvatarProxy({fetcher,validate:safeGiftImage});this.pending=new Map();}
 async load(){const entries=await this.store.read([]);for(const e of Array.isArray(entries)?entries:[]){if(e&&typeof e.name==='string'&&safeGiftImage(e.url))this.add(e,false);}return this;}
 add(event,save=true){const name=String(event.gift||event.name||'').replace(/[<>\x00-\x1f]/g,'').slice(0,60).trim(),url=safeGiftImage(event.giftImage||event.url);if(!name||!url)return false;const key=giftPhotoKey(name),old=this.entries.get(key);if(old?.url===url)return false;const id=createHash('sha256').update(url).digest('hex').slice(0,24);this.entries.set(key,{name,url,id,giftId:String(event.giftId||'').slice(0,40)});if(this.entries.size>256)this.entries.delete(this.entries.keys().next().value);if(save){void this.store.save([...this.entries.values()]);this.onChange(this.snapshot());}return true;}
 snapshot(){return [...this.entries.values()].map(({name,id,giftId})=>({name,giftId,image:'/api/gifts/image/'+id}));}
 async image(id){const item=[...this.entries.values()].find(e=>e.id===id);if(!item)throw Error('Imagem não disponível');if(this.pending.has(id))return this.pending.get(id);if(this.pending.size>=3)throw Error('Aguarde o catálogo');const task=this.images.get(item.url).finally(()=>this.pending.delete(id));this.pending.set(id,task);return task;}
 flush(){return this.store.flush();}
}
