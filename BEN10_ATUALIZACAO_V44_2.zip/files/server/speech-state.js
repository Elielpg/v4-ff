import {AtomicJson} from './atomic-json.js';
const knownModes=new Set(['scripted','social','direct','local-ai','gemini','local']);
function item(value){if(!value||typeof value!=='object'||typeof value.id!=='string'||value.id.length>100||typeof value.user!=='string')return null;const result={};for(const key of ['id','user','displayName','prompt','scriptedText','kind','source','speaker','viewerId','gift'])if(typeof value[key]==='string')result[key]=value[key].slice(0,key==='prompt'||key==='scriptedText'?600:100);result.priority=Math.min(6,Math.max(0,Number(value.priority)||0));result.created=Number.isFinite(value.created)?value.created:Date.now();result.played=value.played===true;if(value.answer&&knownModes.has(value.answer.mode)&&typeof value.answer.text==='string'){result.answer={...value.answer,text:value.answer.text.slice(0,2000)};delete result.answer.usage;result.answerSelection=String(value.answerSelection||'').slice(0,80);}return result;}
export class SpeechState {
 constructor(file,options){this.store=new AtomicJson(file,options);}
 async load(){const data=await this.store.read({});const seen=new Set();const take=v=>{const x=item(v);if(!x||seen.has(x.id)||x.scriptedText&&['join','ambient','tap','command'].includes(x.kind)&&Date.now()-x.created>20000)return null;seen.add(x.id);return x;};return {active:take(data.active),waiting:(Array.isArray(data.waiting)?data.waiting:[]).slice(0,50).map(take).filter(Boolean),completed:Math.max(0,Number(data.completed)||0),receipts:(Array.isArray(data.receipts)?data.receipts:[]).filter(v=>typeof v==='string'&&v.length<=100).slice(-256)};}
 save(queue){return this.store.save({...queue.snapshot(),receipts:[...(queue.receipts||[])].slice(-256),version:1});}
 flush(){return this.store.flush();}
}
