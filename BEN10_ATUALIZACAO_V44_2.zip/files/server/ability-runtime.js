import {abilityConfig,normalizeAbilitySettings,MOVEMENT_ABILITIES} from '../public/ability-catalog.js';
export class AbilityRuntime {
 constructor(now=Date.now()){this.energy=100;this.last=now;this.cooldowns=new Map();this.overrides={};this.combo=0;this.lastAttack=null;this.defenseUntil=0;this.guardReadyAt=0;}
 configure(value){this.overrides=normalizeAbilitySettings(value);}
 tick(now){const dt=Math.max(0,Math.min(60,(now-this.last)/1000));this.energy=Math.min(100,this.energy+dt*10);this.last=Math.max(this.last,now);}
 spend(cost,now){this.tick(now);if(this.energy+1e-6<cost)throw Object.assign(Error('Vigor insuficiente; aguarde a recuperação.'),{code:'ability_energy'});this.energy=Math.max(0,this.energy-cost);}
 trigger(form,variant,now){const ability=abilityConfig(form,variant,this.overrides);if(ability.enabled===false)throw Error('Habilidade desativada pelo operador');if(now<(this.cooldowns.get(ability.id)||0))throw Error('Esta habilidade ainda está recarregando');this.spend(ability.energyCost,now);this.cooldowns.set(ability.id,now+ability.cooldownMs);this.combo=this.lastAttack&&this.lastAttack.id!==ability.id&&now-this.lastAttack.at<=5000?Math.min(3,this.combo+1):1;this.lastAttack={id:ability.id,at:now};if(ability.category==='defense')this.defenseUntil=now+Math.min(3500,ability.durationMs);return {...ability,combo:this.combo};}
 move(mode,now){this.spend(MOVEMENT_ABILITIES[mode]?.energyCost||0,now);}
 defend(now){if(now<this.guardReadyAt)throw Error('Guarda recarregando');this.spend(18,now);this.defenseUntil=now+2200;this.guardReadyAt=now+8000;}
 mitigate(damage,now){return Math.max(0,Number(damage)||0)*(now<this.defenseUntil?0.35:1);}
 snapshot(now){return {energy:Math.round(this.energy),maximum:100,regenerationPerSecond:10,combo:this.lastAttack&&now-this.lastAttack.at<=5000?this.combo:0,defending:now<this.defenseUntil,defenseUntil:this.defenseUntil,guardReadyAt:this.guardReadyAt,cooldowns:Object.fromEntries([...this.cooldowns].filter(([,at])=>at>now))};}
}
