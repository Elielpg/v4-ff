import {AtomicJson} from './atomic-json.js';
const finite=n=>Math.max(0,Math.min(Number.MAX_SAFE_INTEGER,Number(n)||0));
export class EngagementState {
 constructor(file,options){this.store=new AtomicJson(file,{...options,maxBytes:16*1024*1024});this.timer=null;this.hub=null;}
 async load(hub){this.hub=hub;const data=await this.store.read({});for(const value of (Array.isArray(data.ranking)?data.ranking:[]).slice(0,50000)){if(!value||typeof value.user!=='string')continue;const entry={user:value.user.slice(0,40),lastEventType:['like','gift','comment','follow','share','join'].includes(value.lastEventType)?value.lastEventType:'like'};for(const key of ['points','giftCredit','gifts','likes','follows','shares','comments','visits','events','lastSeen'])entry[key]=finite(value[key]);hub.ranking.set(entry.user,entry);}hub.totalEnergy=finite(data.totalEnergy);for(const pair of (Array.isArray(data.seen)?data.seen:[]).slice(-5000))if(Array.isArray(pair)&&typeof pair[0]==='string'&&pair[0].length<300)hub.seen.set(pair[0],finite(pair[1]));return this;}
 schedule(){if(this.timer)return;this.timer=setTimeout(()=>{this.timer=null;void this.save();},1000);this.timer.unref?.();}
 save(){const hub=this.hub;if(!hub)return Promise.resolve();if(hub.ranking.size>50000){const kept=[...hub.ranking.values()].sort((a,b)=>b.points-a.points||b.lastSeen-a.lastSeen).slice(0,50000);hub.ranking=new Map(kept.map(v=>[v.user,v]));}return this.store.save({version:1,totalEnergy:hub.totalEnergy,ranking:[...hub.ranking.values()],seen:[...hub.seen].slice(-5000)});}
 async flush(){clearTimeout(this.timer);this.timer=null;await this.save();return this.store.flush();}
}
