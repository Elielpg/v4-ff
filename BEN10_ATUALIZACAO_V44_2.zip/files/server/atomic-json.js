import {mkdir,readFile,writeFile,rename,stat} from 'node:fs/promises';
import path from 'node:path';

// Private, ordered writes. A failed write never replaces the last good snapshot.
export class AtomicJson {
 constructor(file,{onError=()=>{},maxBytes=2*1024*1024}={}){this.file=file;this.onError=onError;this.maxBytes=maxBytes;this.pending=Promise.resolve();this.error=null;}
 async read(fallback){try{if((await stat(this.file)).size>this.maxBytes)throw Error('Arquivo de estado excede o limite');return JSON.parse(await readFile(this.file,'utf8'));}catch(error){if(error.code!=='ENOENT')this.onError(error);return fallback;}}
 save(value){const bytes=JSON.stringify(value);if(Buffer.byteLength(bytes)>this.maxBytes){const error=Error('Estado excede o limite');this.error=error;this.onError(error);return Promise.resolve(false);}const task=this.pending.then(async()=>{await mkdir(path.dirname(this.file),{recursive:true,mode:0o700});const temporary=this.file+'.'+process.pid+'.tmp';await writeFile(temporary,bytes,{mode:0o600});await rename(temporary,this.file);this.error=null;return true;});this.pending=task.catch(error=>{this.error=error;this.onError(error);return false;});return this.pending;}
 async flush(){await this.pending;return !this.error;}
}
