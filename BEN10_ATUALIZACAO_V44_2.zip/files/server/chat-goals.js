import {CHAT_GOALS,normalizeGoalSettings,goalForRound} from '../public/chat-goal-catalog.js';
import {likeCount} from '../public/like-count.js';
const laneId=source=>source==='tiktok'?'tiktok':'demo';
export class ChatGoals{
 constructor({settings={},now=Date.now(),onChange=()=>{},onComplete=()=>{}}={}){this.settings=normalizeGoalSettings(settings);this.onChange=onChange;this.onComplete=onComplete;this.sequence=0;this.revision=0;this.lanes={};this.reset('demo',now,false);this.reset('tiktok',now,false);}
 reset(source,now=Date.now(),emit=true){source=laneId(source);this.lanes[source]={goals:Object.fromEntries(CHAT_GOALS.map(g=>[g.id,{id:g.id,progress:0,round:1,completed:0,cooldownUntil:null}])),seen:new Set(),recent:new Map(),followers:new Set(),rewards:[],completed:0};if(emit)this.emit(source,now);return this.snapshot(source,now);}
 snapshot(source='demo',now=Date.now()){source=laneId(source);const lane=this.lanes[source];return {source,serverTime:now,revision:this.revision,enabled:this.settings.enabled,settings:{...this.settings},completed:lane.completed,goals:CHAT_GOALS.map(g=>({...goalForRound(g,lane.goals[g.id].round),...lane.goals[g.id],target:this.settings[g.id]})),rewards:lane.rewards.map(r=>({...r}))};}
 emit(source,now){this.revision++;this.onChange(this.snapshot(source,now));}
 configure(settings,now=Date.now()){const next=normalizeGoalSettings(settings);if(JSON.stringify(next)===JSON.stringify(this.settings))return;for(const source of ['demo','tiktok'])for(const g of CHAT_GOALS)if(next[g.id]!==this.settings[g.id]){const state=this.lanes[source].goals[g.id];state.progress=0;state.cooldownUntil=null;}this.settings=next;this.emit('demo',now);this.emit('tiktok',now);}
 ingest(event,now=Date.now()){
  if(!this.settings.enabled||!CHAT_GOALS.some(g=>g.id===event.type))return false;const source=laneId(event.source),lane=this.lanes[source],state=lane.goals[event.type];
  if(event.id&&lane.seen.has(event.id))return false;if(event.id){lane.seen.add(event.id);if(lane.seen.size>2048)lane.seen.delete(lane.seen.values().next().value);}
  this.tick(now);if(state.cooldownUntil)return false;const user=String(event.user||'Visitante').slice(0,40),key=event.type+':'+user;
  if(event.type==='comment'&&!String(event.text||'').trim())return false;
  if(event.type==='follow'){if(lane.followers.has(user))return false;lane.followers.add(user);if(lane.followers.size>20000)lane.followers.delete(lane.followers.values().next().value);}
  if(event.type==='comment'||event.type==='share'){const gap=event.type==='comment'?3000:10000;if(now-(lane.recent.get(key)??-Infinity)<gap)return false;lane.recent.set(key,now);if(lane.recent.size>4096)lane.recent.delete(lane.recent.keys().next().value);}
  const amount=event.type==='like'?likeCount(event.count):1;if(!amount)return false;state.progress=Math.min(this.settings[event.type],state.progress+amount);
  if(state.progress===this.settings[event.type]){state.cooldownUntil=now+12000;state.completed++;lane.completed++;const meta=goalForRound(CHAT_GOALS.find(g=>g.id===event.type),state.round),reward={id:source+'-'+(++this.sequence),source,type:event.type,title:meta.reward,effect:meta.effect,mission:meta.title,user,round:state.round,at:now};lane.rewards.push(reward);if(lane.rewards.length>12)lane.rewards.shift();this.onComplete(reward);}
  this.emit(source,now);return true;
 }
 tick(now=Date.now()){for(const source of ['demo','tiktok']){let changed=false;for(const state of Object.values(this.lanes[source].goals))if(state.cooldownUntil&&now>=state.cooldownUntil){state.progress=0;state.round++;state.cooldownUntil=null;changed=true;}if(changed)this.emit(source,now);}}
}
export function localGoalReply(text,snapshot){const q=String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(!snapshot||!/\b(meta|metas|missao|missoes|tap tap|curtidas|compartilhamentos|seguidores)\b/.test(q))return null;if(!snapshot.enabled)return 'As metas do chat estão desligadas por enquanto! Ainda dá pra escolher um alien e testar os poderes comigo.';const rest=snapshot.goals.map(g=>Math.max(0,g.target-g.progress)+' '+g.action).join(', ');return (snapshot.source==='demo'?'No nosso teste local, ':'Bora, equipe! ')+ 'faltam '+rest+'. Cada meta libera uma celebração 3D. É hora de juntar a turma!';}
