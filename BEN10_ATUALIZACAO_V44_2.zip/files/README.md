# Ben 10 · Clareira LIVE V44.2

Qwen local preservado. Voz padrão Piper brasileira, sem referência clonada, com preferência pela Cadu, ritmo ajustado e pausas entre frases. Interlúdios sobre aventuras e o clássico são interrompidos para atender espectadores. Layout compacto com opção de expandir os painéis.

Instalação, execução, limites e reversão: docs/ATUALIZACAO_V44_2.md.

Iniciar: `bash local-ai.sh start`. Para preparar a voz neutra: `node scripts/local-ai/plain-voice-plan.js --ensure`. A preparação pode baixar cerca de 63 MB uma vez; não baixa novamente o Qwen.

Resultados: reports/v44_2/. A voz foi medida em CPU Linux sem clonagem. Qualidade percebida e LIVE prolongada no GT3 precisam de validação no aparelho.
