#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node scripts/check.js
node --test --test-concurrency=2 tests/*.test.js
node scripts/build.js
python3 scripts/package.py
