import {EventHub} from '../server/core.js';import {directAnswer} from '../server/quick-answer.js';import {writeFile,mkdir} from 'node:fs/promises';
const iterations=20000,hub=new EventHub(),rssBefore=process.memoryUsage().rss,cpuBefore=process.cpuUsage();let began=performance.now();
for(let i=0;i<iterations;i++)hub.ingest({id:'cpu-'+i,type:'like',user:'Fixture'+i%500,count:17},'demo');
const eventsMs=performance.now()-began;began=performance.now();for(let i=0;i<iterations;i++){const answer=directAnswer('Ben, quanto é sete vezes oito?');if(!answer.text.includes('56'))throw Error('Conta incorreta');}const arithmeticMs=performance.now()-began;
if(hub.totalEnergy!==iterations*17)throw Error('Contagem de curtidas incorreta');
const report={version:'44.0.0',limits:'Laço Node isolado em CPU Linux. Sem 3D, modelos neurais, rede TikTok ou medições do GT3. Não representa throughput da LIVE completa.',iterations,viewers:hub.ranking.size,likes:hub.totalEnergy,eventHandling:{elapsedMs:eventsMs,operationsPerSecond:iterations/eventsMs*1000},directArithmetic:{elapsedMs:arithmeticMs,operationsPerSecond:iterations/arithmeticMs*1000},cpuMicroseconds:process.cpuUsage(cpuBefore),rssBefore,rssAfter:process.memoryUsage().rss};
await mkdir('reports/v44',{recursive:true});await writeFile('reports/v44/cpu-benchmark.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
