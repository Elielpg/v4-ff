import {chromium} from 'playwright-core';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,cp,symlink,writeFile,readFile,rm,mkdir} from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {BUILD_ID} from '../public/release.js';
const temp=await mkdtemp(path.join(os.tmpdir(),'ben44-browser-'));
const report={version:BUILD_ID,limits:'Functional browser test with a synthetic tone and a mock text service. No voice cloning, voice quality or phone performance is tested.'};
let game,worker,browser;
const llmRequests=[];
const llm=http.createServer(async(req,res)=>{let raw='';for await(const part of req)raw+=part;if(raw)llmRequests.push(JSON.parse(raw));res.setHeader('content-type','application/json');res.end(JSON.stringify({status:'ok',model:'fixture-text',choices:[{message:{content:'Um vulcão se forma quando o magma sobe e alcança a superfície.'}}]}));});
await new Promise(r=>llm.listen(0,'127.0.0.1',r));
try{
 const cache=path.join(temp,'tone-cache');
 worker=spawn('python3',[path.resolve('tests/fixtures/slow-local-voice.py'),'--worker-dir',path.resolve('scripts/local-ai'),'--cache-dir',cache,'--delay','0.2','--duration','1'],{stdio:['ignore','pipe','pipe']});
 const [ready]=await once(worker.stdout,'data'),voicePort=JSON.parse(ready.toString()).port;
 const root=path.join(temp,'game');await mkdir(root);for(const name of ['server','public'])await cp(name,path.join(root,name),{recursive:true});
 await symlink(path.resolve('node_modules'),path.join(root,'node_modules'));await writeFile(path.join(root,'package.json'),'{"type":"module"}');
 const socket=http.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const base='http://127.0.0.1:'+port;
 const post=async(route,data)=>{const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});assert(r.ok,await r.clone().text());return r.json();};
 const health=()=>fetch(base+'/api/health').then(r=>r.json());
 game=spawn(process.execPath,['server/index.js'],{cwd:root,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await once(game.stdout,'data');
 await post('config',{hostSpeech:false,conversationProvider:'local',voiceProvider:'local',quality:'economy',localAi:{textPort:llm.address().port,voicePort},voice:1,sfx:0,music:0});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=document-user-activation-required']});
 const page=await browser.newPage({viewport:{width:412,height:915},isMobile:true,hasTouch:true,deviceScaleFactor:3}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(build=>{localStorage.setItem('benWelcomeBuild',build);window.deviceVoiceCalls=0;speechSynthesis.speak=()=>{window.deviceVoiceCalls++;throw Error('Device voice must remain unused');};},BUILD_ID);
 await page.goto(base);await page.waitForFunction(()=>window.benArena&&window.arenaStream?.readyState===1);await page.touchscreen.tap(210,650);await page.waitForFunction(()=>window.linelAudio.enabled);
 await post('event',{type:'comment',user:'Marina',text:'Ben, quanto é sete vezes oito?'});
 await page.waitForFunction(()=>window.linelAudio.speaking&&window.linelAudio.lastTiming?.mode==='direct');
 assert.match(await page.locator('#conversation-status').textContent(),/RESPOSTA DIRETA/);
 assert.equal(llmRequests.length,0);
 let calls=(await readFile(path.join(cache,'calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(calls[0].text,'Marina, Dá cinquenta e seis!');
 report.mathBypassesModel=true;report.numbersSentAsWords=true;
 await page.waitForFunction(()=>window.linelAudio.lastTiming?.playbackMs>0&&!window.linelAudio.speaking);
 for(let i=0;i<20&&(await health()).queue.active;i++)await new Promise(r=>setTimeout(r,100));assert.equal((await health()).queue.active,null);
 report.mathTiming=await page.evaluate(()=>window.linelAudio.lastTiming);
 await post('config',{hostSpeech:true,hostAmbientSeconds:12});
 await page.waitForFunction(()=>window.linelAudio.speaking&&window.linelAudio.activeSpeechID&&document.querySelector('#subtitles').textContent.startsWith('Ben · '),null,{timeout:25000});
 const ambient=(await health()).queue.active;assert.equal(ambient.kind,'ambient');await page.evaluate(()=>window.testAmbientController=window.linelAudio.voiceController);const preemptedAt=Date.now();
 await post('event',{type:'comment',user:'Cheguei',text:'Quanto é sete vezes oito?'});
 await page.waitForFunction(()=>window.testAmbientController.signal.aborted&&window.linelAudio.speaking&&window.linelAudio.lastTiming?.user==='Cheguei',null,{timeout:15000});report.ambientInterruptedForViewer=true;report.interruptionToViewerAudioMs=Date.now()-preemptedAt;
 await post('config',{hostSpeech:false});await page.waitForFunction(()=>window.linelAudio.lastTiming?.user==='Cheguei'&&window.linelAudio.lastTiming.playbackMs>0&&!window.linelAudio.speaking);for(let i=0;i<25&&(await health()).queue.active;i++)await new Promise(r=>setTimeout(r,100));assert.equal((await health()).queue.active,null);
 assert(await page.locator('body').evaluate(body=>body.classList.contains('compact-hud')));const goalBounds=await page.locator('#chat-goals').boundingBox();assert(goalBounds.y+goalBounds.height<=360);await page.locator('#hud-detail-toggle').tap();assert(await page.locator('body').evaluate(body=>!body.classList.contains('compact-hud')));await page.locator('#hud-detail-toggle').tap();report.compactAndExpandedControls=true;

 for(const user of ['Ana','Bia']){
  await post('event',{type:'comment',user,text:'Como nasce um vulcão?'});
  await page.waitForFunction(u=>window.linelAudio.lastTiming?.user===u&&window.linelAudio.speaking,user);
  await page.waitForFunction(u=>window.linelAudio.lastTiming?.user===u&&window.linelAudio.lastTiming.playbackMs>0&&!window.linelAudio.speaking,user);
  for(let i=0;i<20&&(await health()).queue.active;i++)await new Promise(r=>setTimeout(r,100));assert.equal((await health()).queue.active,null);
 }
 assert.equal(llmRequests.length,1);assert.equal(await page.evaluate(()=>window.linelAudio.lastTiming.cachedAnswer),true);
 calls=(await readFile(path.join(cache,'calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert(calls.some(c=>c.text.startsWith('Ana, ')));assert(calls.some(c=>c.text.startsWith('Bia, ')));assert(!calls.some(c=>/Ana, Ana|Bia, Bia/.test(c.text)));
 report.generalQuestionUsesModel=true;report.repeatUsesTextCache=true;report.namesDoNotLeakAcrossUsers=true;report.audioCompletionAcknowledgesQuestion=true;report.lastTiming=await page.evaluate(()=>window.linelAudio.lastTiming);
 
 await post('config',{quality:'balanced',alienUnlocks:{enabled:false}});
 await post('adventure',{action:'configure',options:{idleLife:false,autoWander:false,durationSeconds:120}});
 await page.evaluate(()=>{const w=window.linelWorld;w.audienceView.current=null;w.audienceView.pending=[];});
 await page.waitForTimeout(4500);
 const duplicateIds=await page.evaluate(()=>{const ids=[...document.querySelectorAll('[id]')].map(n=>n.id);return [...new Set(ids.filter((id,i)=>ids.indexOf(id)!==i))];});assert.deepEqual(duplicateIds,[]);report.noDuplicateDOMids=true;
 assert.equal(await page.locator('#music-volume').getAttribute('max'),'1');assert.equal(await page.locator('#music-player-volume').getAttribute('max'),'100');report.separateMusicControls=true;
 await page.locator('#panel-toggle').tap();await page.locator('#tabs [data-tab="settings"]').tap();await page.locator('#quality').selectOption('balanced');await page.waitForFunction(()=>window.linelWorld.graphics.quality==='balanced');await page.locator('.v44-settings > summary').tap();assert(await page.getByText('Lembrar conversas e espectadores neste aparelho',{exact:false}).isVisible());
 const checkbox=page.locator('.v44-settings label').filter({hasText:'Ajustar resolução quando o desempenho cair'}).locator('input');await checkbox.uncheck();await page.waitForFunction(()=>window.linelWorld.graphics.adaptive===false);await checkbox.check();await page.waitForFunction(()=>window.linelWorld.graphics.adaptive===true);report.adaptiveControlsWork=true;
 await page.locator('#close').tap();await page.screenshot({scale:'css',path:'reports/v44_2/camp-day-412.png',fullPage:true});
 await post('world-clock',{settings:{mode:'night',minutes:12,hour:9}});await page.waitForFunction(()=>window.linelWorld.dayCycle.day<.15,null,{timeout:15000});await page.screenshot({scale:'css',path:'reports/v44_2/camp-night-412.png',fullPage:true});report.nightStars=await page.evaluate(()=>window.linelWorld.dayCycle.stars.isEnabled());assert(report.nightStars);
 await post('world-clock',{settings:{mode:'sunset',minutes:12,hour:9}});await page.waitForFunction(()=>window.linelWorld.dayCycle.sunset>.6,null,{timeout:15000});await page.screenshot({scale:'css',path:'reports/v44_2/camp-sunset-412.png',fullPage:true});
 await post('world-clock',{settings:{mode:'day',minutes:12,hour:9}});
 await post('adventure',{action:'transform',form:'blaze'});await page.waitForFunction(()=>window.linelWorld.adventureState?.form==='blaze'&&window.linelWorld.imported?.formId==='blaze',null,{timeout:20000});
 await post('adventure',{action:'combo'});await page.waitForFunction(()=>window.linelWorld.adventureState?.power?.combo>=2,null,{timeout:12000});await page.screenshot({scale:'css',path:'reports/v44_2/combo-412.png',fullPage:true});
 await page.waitForFunction(()=>window.linelWorld.adventureState?.comboSequence===null&&Date.now()>window.linelWorld.adventureState.nextPower,null,{timeout:12000});
 await post('adventure',{action:'defense'});await page.waitForFunction(()=>window.linelWorld.campLook.guard.isEnabled(),null,{timeout:3000});await page.screenshot({scale:'css',path:'reports/v44_2/defense-412.png',fullPage:true});report.defenseAndComboRender=true;
 const before=await page.evaluate(()=>{const w=window.linelWorld;return {meshes:w.scene.meshes.length,materials:w.scene.materials.length,textures:w.scene.textures.length};});
 await page.evaluate(async()=>{const w=window.linelWorld;for(let i=0;i<3;i++)await w.importGLB(w.modelSources.blaze);});
 const after=await page.evaluate(()=>{const w=window.linelWorld;return {meshes:w.scene.meshes.length,materials:w.scene.materials.length,textures:w.scene.textures.length};});assert(after.materials<=before.materials+8,JSON.stringify({before,after}));assert(after.textures<=before.textures+4,JSON.stringify({before,after}));report.modelReloadResources={before,after};
 const photos=await page.locator('.gift-slide-card img').evaluateAll(images=>images.map(img=>({src:img.getAttribute('src'),loaded:img.complete&&img.naturalWidth>0})));
 assert(photos.length>0&&photos.every(p=>p.loaded),JSON.stringify(photos));report.realGiftPhotos=photos;
 assert.match(await page.locator('.omni-command-card p').textContent(),/Pergunte qualquer coisa/);
 assert.match(await page.locator('#goal-hint').textContent(),/TAP TAP|Pergunte|Compartilhe|Siga/);report.guidanceVisible=true;
 const stress=await page.evaluate(()=>{const w=window.linelWorld;w.giftSpectacle.dispose();w.toonDirector.dispose();w.powerUntil=0;const giftBefore=w.giftSpectacle.completed,goalBefore=w.toonDirector.completed;const counts=()=>({meshes:w.scene.meshes.length,materials:w.scene.materials.length,textures:w.scene.textures.length,nodes:w.scene.transformNodes.length});const before=counts();const kinds=['Rose','Heart Me','Galaxy','Confetti','Lion','TikTok','Money Gun','Ice Cream','Meteor Shower','Fireworks'];for(let i=0;i<80;i++){w.giftSpectacle.enqueue({type:'gift',id:'stress-'+i,gift:kinds[i%kinds.length],user:'Fixture',count:1});for(let k=0;k<180;k++)w.giftSpectacle.update(.05);w.toonDirector.enqueue({id:'goal-'+i,title:'Celebração de teste',mission:'Missão de teste',round:1,effect:['omni','crystal','speed','signal'][i%4],at:Date.now(),source:'demo'});for(let k=0;k<180;k++)w.toonDirector.update(.05);}w.giftSpectacle.dispose();w.toonDirector.dispose();return {before,after:counts(),iterations:80,giftShows:w.giftSpectacle.completed-giftBefore,goalShows:w.toonDirector.completed-goalBefore};});
 assert.equal(stress.giftShows,80);assert.equal(stress.goalShows,80);for(const key of ['meshes','materials','textures','nodes'])assert(stress.after[key]<=stress.before[key]+2,JSON.stringify(stress));report.effectStress=stress;
 await post('config',{quality:'balanced',adaptiveQuality:false});await page.waitForFunction(()=>window.linelWorld.graphics.quality==='balanced');
 await page.waitForTimeout(1000);report.buffer=await page.evaluate(()=>{const w=window.linelWorld;return {dpr:devicePixelRatio,width:w.engine.getRenderWidth(),height:w.engine.getRenderHeight(),cssWidth:w.canvas.clientWidth,cssHeight:w.canvas.clientHeight,scale:w.engine.getHardwareScalingLevel(),fxaa:w.campLook.fxaa.getEffect().isReady()};});assert(report.buffer.fxaa);assert(report.buffer.scale<1.35);assert(report.buffer.width*report.buffer.height<=1201000);
 await page.screenshot({scale:'css',path:'reports/v44_2/layout-412.png',fullPage:true});
 // Exercise WebGL context loss and Babylon's restoration without reloading the game.
 report.contextRecovery=await page.evaluate(async()=>{const w=window.linelWorld,extension=w.engine._gl.getExtension('WEBGL_lose_context');if(!extension)return {supported:false};extension.loseContext();await new Promise(r=>setTimeout(r,400));const detected=!!w.contextLost;extension.restoreContext();for(let i=0;i<80&&w.contextLost;i++)await new Promise(r=>setTimeout(r,100));return {supported:true,detected,restored:!w.contextLost};});
 if(report.contextRecovery.supported){assert(report.contextRecovery.detected);assert(report.contextRecovery.restored);}
 report.renderSamples=[];for(const quality of ['economy','balanced','high']){await post('config',{adaptiveQuality:false});await page.locator('#panel-toggle').tap();await page.locator('#tabs [data-tab="settings"]').tap();await page.locator('#quality').selectOption(quality);await page.waitForFunction(q=>window.linelWorld.graphics.quality===q,quality);await page.locator('#close').tap();const sample=await page.evaluate(async quality=>{const w=window.linelWorld,started=performance.now(),before=w.scene.getFrameId();await new Promise(r=>setTimeout(r,5000));return {quality,elapsedMs:performance.now()-started,renderedFrames:w.scene.getFrameId()-before,...w.graphics.stats(),meshes:w.scene.meshes.length,activeMeshes:w.scene.getActiveMeshes().length};},quality);report.renderSamples.push(sample);}
 report.renderLimits='Chromium with SwiftShader/software rendering in Linux. Not the GT3 GPU. Samples are separate from CPU/LLM/voice benchmarks; text and voice here are fixtures.';
 assert(await page.evaluate(()=>window.linelWorld.campLook.toon?.getEffect()?.isReady()));report.celShaderCompiled=true;
 await post('config',{adaptiveQuality:true});await page.locator('#panel-toggle').tap();await page.locator('#tabs [data-tab="settings"]').tap();await page.locator('#quality').selectOption('balanced');await page.locator('#close').tap();

assert.equal(await page.evaluate(()=>window.deviceVoiceCalls),0);assert.deepEqual(errors,[]);report.errors=errors;
 await mkdir('reports/v44_2',{recursive:true});await page.screenshot({scale:'css',path:'reports/v44_2/conversation-412.png',fullPage:true});
 console.log(JSON.stringify(report,null,2));
}catch(error){report.error=error.message;throw error;}
finally{await mkdir('reports/v44_2',{recursive:true});await writeFile('reports/v44_2/browser.json',JSON.stringify(report,null,2));await browser?.close();for(const child of [game,worker])if(child?.exitCode===null){child.kill('SIGTERM');await once(child,'exit');}llm.closeAllConnections();await new Promise(r=>llm.close(r));await rm(temp,{recursive:true,force:true});}
