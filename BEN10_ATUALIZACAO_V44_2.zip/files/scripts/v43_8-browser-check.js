import {chromium} from 'playwright-core';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,cp,symlink,writeFile,readFile,rm,mkdir} from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {BUILD_ID} from '../public/release.js';
const temp=await mkdtemp(path.join(os.tmpdir(),'ben438-browser-'));
const report={version:BUILD_ID,limits:'Functional browser test with a synthetic tone and a mock text service. No voice cloning, voice quality or phone performance is tested.'};
let game,worker,browser;
const llmRequests=[];
const llm=http.createServer(async(req,res)=>{let raw='';for await(const part of req)raw+=part;if(raw)llmRequests.push(JSON.parse(raw));res.setHeader('content-type','application/json');res.end(JSON.stringify({status:'ok',model:'fixture-text',choices:[{message:{content:'Um vulcão se forma quando o magma sobe e alcança a superfície.'}}]}));});
await new Promise(r=>llm.listen(0,'127.0.0.1',r));
try{
 const cache=path.join(temp,'tone-cache');
 worker=spawn('python3',[path.resolve('tests/fixtures/slow-local-voice.py'),'--worker-dir',path.resolve('scripts/local-ai'),'--cache-dir',cache,'--delay','0.2','--duration','1'],{stdio:['ignore','pipe','pipe']});
 const [ready]=await once(worker.stdout,'data'),voicePort=JSON.parse(ready.toString()).port;
 const root=path.join(temp,'game');await mkdir(root);for(const name of ['server','public'])await cp(name,path.join(root,name),{recursive:true});
 await symlink(path.resolve('node_modules'),path.join(root,'node_modules'));await writeFile(path.join(root,'package.json'),'{"type":"module"}');
 const socket=http.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const base='http://127.0.0.1:'+port;
 const post=async(route,data)=>{const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});assert(r.ok,await r.clone().text());return r.json();};
 const health=()=>fetch(base+'/api/health').then(r=>r.json());
 game=spawn(process.execPath,['server/index.js'],{cwd:root,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await once(game.stdout,'data');
 await post('config',{hostSpeech:false,conversationProvider:'local',voiceProvider:'local',quality:'economy',localAi:{textPort:llm.address().port,voicePort},voice:1,sfx:0,music:0});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=document-user-activation-required']});
 const page=await browser.newPage({viewport:{width:412,height:915},isMobile:true,hasTouch:true}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(build=>{localStorage.setItem('benWelcomeBuild',build);window.deviceVoiceCalls=0;speechSynthesis.speak=()=>{window.deviceVoiceCalls++;throw Error('Device voice must remain unused');};},BUILD_ID);
 await page.goto(base);await page.waitForFunction(()=>window.benArena&&window.arenaStream?.readyState===1);await page.touchscreen.tap(210,650);await page.waitForFunction(()=>window.linelAudio.enabled);
 await post('event',{type:'comment',user:'Marina',text:'Ben, quanto é sete vezes oito?'});
 await page.waitForFunction(()=>window.linelAudio.speaking&&window.linelAudio.lastTiming?.mode==='direct');
 assert.match(await page.locator('#conversation-status').textContent(),/RESPOSTA DIRETA/);
 assert.equal(llmRequests.length,0);
 let calls=(await readFile(path.join(cache,'calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(calls[0].text,'Marina, Dá cinquenta e seis!');
 report.mathBypassesModel=true;report.numbersSentAsWords=true;
 await page.waitForFunction(()=>window.linelAudio.lastTiming?.playbackMs>0&&!window.linelAudio.speaking);
 for(let i=0;i<20&&(await health()).queue.active;i++)await new Promise(r=>setTimeout(r,100));assert.equal((await health()).queue.active,null);
 report.mathTiming=await page.evaluate(()=>window.linelAudio.lastTiming);
 for(const user of ['Ana','Bia']){
  await post('event',{type:'comment',user,text:'Como nasce um vulcão?'});
  await page.waitForFunction(u=>window.linelAudio.lastTiming?.user===u&&window.linelAudio.speaking,user);
  await page.waitForFunction(u=>window.linelAudio.lastTiming?.user===u&&window.linelAudio.lastTiming.playbackMs>0&&!window.linelAudio.speaking,user);
  for(let i=0;i<20&&(await health()).queue.active;i++)await new Promise(r=>setTimeout(r,100));assert.equal((await health()).queue.active,null);
 }
 assert.equal(llmRequests.length,1);assert.equal(await page.evaluate(()=>window.linelAudio.lastTiming.cachedAnswer),true);
 calls=(await readFile(path.join(cache,'calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert(calls.some(c=>c.text.startsWith('Ana, ')));assert(calls.some(c=>c.text.startsWith('Bia, ')));assert(!calls.some(c=>/Ana, Ana|Bia, Bia/.test(c.text)));
 report.generalQuestionUsesModel=true;report.repeatUsesTextCache=true;report.namesDoNotLeakAcrossUsers=true;report.audioCompletionAcknowledgesQuestion=true;report.lastTiming=await page.evaluate(()=>window.linelAudio.lastTiming);
 assert.equal(await page.evaluate(()=>window.deviceVoiceCalls),0);assert.deepEqual(errors,[]);report.errors=errors;
 await mkdir('reports/v43_8',{recursive:true});await page.screenshot({path:'reports/v43_8/conversation-412.png',fullPage:true});
 console.log(JSON.stringify(report,null,2));
}catch(error){report.error=error.message;throw error;}
finally{await mkdir('reports/v43_8',{recursive:true});await writeFile('reports/v43_8/browser.json',JSON.stringify(report,null,2));await browser?.close();for(const child of [game,worker])if(child?.exitCode===null){child.kill('SIGTERM');await once(child,'exit');}llm.closeAllConnections();await new Promise(r=>llm.close(r));await rm(temp,{recursive:true,force:true});}
