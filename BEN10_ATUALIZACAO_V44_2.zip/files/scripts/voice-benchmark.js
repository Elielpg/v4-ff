import {writeFile,mkdir} from 'node:fs/promises';import path from 'node:path';
import {loopbackRequest,LocalVoice} from '../server/local-ai.js';
import {normalizeVoiceText} from '../public/voice-text.js';
import {VOICE_CORPUS,humanVoiceAssessment} from '../public/voice-evaluation.js';
const args=process.argv.slice(2),portIndex=args.indexOf('--port'),outIndex=args.indexOf('--output'),port=portIndex>=0?Number(args[portIndex+1]):8082,out=path.resolve(outIndex>=0?args[outIndex+1]:'data/diagnostics/voice-benchmark.json');
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Porta inválida');
const health=JSON.parse((await loopbackRequest(port,'/health',{timeout:4000})).data);if(!health.ready)throw Error('Inicie a voz selecionada antes do benchmark');
const synthetic=/fixture|synthetic|test-tone/i.test(String(health.model)),report={at:new Date().toISOString(),engine:health.model||'unknown',provider:health.provider||'local',synthetic,limits:synthetic?'Som sintético; tempos só validam o instrumento.':'Medição local do motor já selecionado, sem troca de voz; timbre e clareza exigem avaliação humana.',humanAssessment:humanVoiceAssessment(),samples:[]};
const voice=new LocalVoice();
for(const item of VOICE_CORPUS){const started=Date.now(),job=await voice.startJob(normalizeVoiceText(item.text),{settings:{voicePort:port,textPort:port===8081?8083:8081}});let result;
 for(let i=0;i<600;i++){result=await voice.job(job.id,{settings:{voicePort:port,textPort:port===8081?8083:8081}});if(result.state==='ready')break;if(result.state==='failed')throw Error(result.message);await new Promise(r=>setTimeout(r,1000));}
 if(result.state!=='ready')throw Error('Benchmark excedeu dez minutos na frase '+item.id);
 report.samples.push({id:item.id,category:item.category,text:normalizeVoiceText(item.text),wallMs:Date.now()-started,generationSeconds:result.generationSeconds,audioSeconds:result.audioSeconds,cached:!!result.cached,rtf:result.audioSeconds?result.generationSeconds/result.audioSeconds:null});
 await mkdir(path.dirname(out),{recursive:true});await writeFile(out,JSON.stringify(report,null,2));console.log(item.id+': '+report.samples.at(-1).wallMs+' ms'+(synthetic?' · SIMULADO':''));
}
console.log('Resultado em '+out+'. Motor selecionado preservado.');
