"""Fetch a public neutral Piper voice; never select or load a cloning engine."""
import argparse
from pathlib import Path
from download_models import voice_plan, download, VOICE_REPO

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    info, files = voice_plan('cadu')
    target = args.root / 'voices' / 'cadu'
    for filename, entry in files:
        download(VOICE_REPO, info['sha'], entry, target / filename)
    print('Voz Cadu preparada com hashes verificados. Manifesto e modelos de conversa preservados.', flush=True)

if __name__ == '__main__':
    main()
