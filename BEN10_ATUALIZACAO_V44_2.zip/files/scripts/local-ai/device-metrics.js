import {readFileSync} from 'node:fs';
export function deviceMetrics(read=file=>readFileSync(file,'utf8')){let temperature=null;for(const file of ['/sys/class/power_supply/battery/temp','/sys/class/power_supply/Battery/temp']){try{const raw=Number(String(read(file)).trim());if(Number.isFinite(raw)&&raw>=100&&raw<=900){temperature=raw/10;break;}}catch{}}
 return {batteryTemperatureC:temperature,temperatureSource:temperature===null?'unavailable':'battery-sysfs-tenths-C',cpuTemperatureC:null,note:'Temperatura da bateria quando disponível; não representa a temperatura da CPU.'};
}
export function runtimeProfile(value='gt3'){if(!['gt3','quiet'].includes(value))throw Error('Perfil de CPU inválido');return {id:value,textThreads:value==='quiet'?2:4,contextTokens:4096};}
