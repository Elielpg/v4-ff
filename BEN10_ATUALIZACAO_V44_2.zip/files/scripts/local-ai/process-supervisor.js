import {spawn} from 'node:child_process';
import {residentBytes} from './runtime-log.js';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));

// Each service owns its retry budget; another service's failure cannot spend it.
export class ProcessSupervisor {
 constructor({log={event(){}},onChange=()=>{},maxRestarts=3,backoffMs=1000,stopTimeoutMs=8000}={}){this.log=log;this.onChange=onChange;this.maxRestarts=maxRestarts;this.backoffMs=backoffMs;this.stopTimeoutMs=stopTimeoutMs;this.services=new Map();this.stopping=false;}
 add(spec){if(this.services.has(spec.id))throw Error('Serviço duplicado');const state={id:spec.id,state:'stopped',pid:null,restarts:0,exits:0,lastExit:null,readyAt:null,lastHealth:null};this.services.set(spec.id,{spec,state,child:null,timer:null,healthBusy:false,launch:0});return state;}
 snapshot(){return {pid:process.pid,rssBytes:residentBytes(process.pid),stopping:this.stopping,services:Object.fromEntries([...this.services].map(([id,x])=>[id,{...x.state,rssBytes:x.state.pid?residentBytes(x.state.pid):null}]))};}
 changed(){this.onChange(this.snapshot());}
 start(id){const service=this.services.get(id);if(!service||this.stopping||service.child||service.state.state==='failed')return;const {spec,state}=service;state.state='starting';state.startedAt=Date.now();state.lastHealth=null;service.launch++;const generation=service.launch;let child;
  try{child=spawn(spec.command,spec.args,{cwd:spec.cwd,env:spec.env||process.env,detached:true,stdio:spec.stdio||'inherit'});}catch(error){this.exited(service,null,null,error.message);return;}
  service.child=child;state.pid=child.pid||null;if(spec.output){child.stdout?.on('data',chunk=>spec.output(chunk));child.stderr?.on('data',chunk=>spec.output(chunk));}this.log.event('service-start',{service:id,pid:state.pid,restart:state.restarts});this.changed();let ended=false;
  const endedOnce=(code,signal,error)=>{if(ended||generation!==service.launch)return;ended=true;this.exited(service,code,signal,error);};
  child.once('error',error=>endedOnce(null,null,error.code||error.message));child.once('exit',(code,signal)=>endedOnce(code,signal));
 }
 exited(service,code,signal,error){const {spec,state}=service;service.child=null;state.pid=null;state.exits++;state.lastExit={at:Date.now(),code,signal,error:error||null};state.state=this.stopping?'stopped':'backoff';this.log.event('service-exit',{service:spec.id,...state.lastExit});spec.onExit?.(state.lastExit);
  if(!this.stopping){if(state.restarts>=this.maxRestarts){state.state='failed';this.log.event('retry-budget-exhausted',{service:spec.id,restarts:state.restarts});}else{const wait=this.backoffMs*2**state.restarts;state.restarts++;state.retryAt=Date.now()+wait;service.timer=setTimeout(()=>{service.timer=null;this.start(spec.id);},wait);}}
  this.changed();
 }
 async health(){if(this.stopping)return;await Promise.all([...this.services.values()].map(async service=>{const {spec,state,child}=service;if(!child||service.healthBusy||!spec.probe)return;service.healthBusy=true;const generation=service.launch;try{const ready=await spec.probe();if(this.stopping||generation!==service.launch||!service.child)return;state.lastHealth=Date.now();if(ready){if(state.state!=='ready'){state.state='ready';state.readyAt=Date.now();this.log.event('service-ready',{service:spec.id,pid:state.pid});spec.onReady?.();}}else if(state.state==='ready')state.state='degraded';}catch{if(generation===service.launch&&state.state==='ready')state.state='degraded';}finally{service.healthBusy=false;}}));this.changed();}
 startAll(){for(const id of this.services.keys())this.start(id);}
 async stop(){if(this.stopping)return;this.stopping=true;for(const service of this.services.values()){clearTimeout(service.timer);service.timer=null;const child=service.child;if(child){service.state.state='stopping';try{process.kill(-child.pid,'SIGTERM');}catch{child.kill('SIGTERM');}}}const deadline=Date.now()+this.stopTimeoutMs;while(Date.now()<deadline&&[...this.services.values()].some(x=>x.child))await delay(40);for(const service of this.services.values())if(service.child){this.log.event('service-stop-timeout',{service:service.spec.id,pid:service.child.pid});try{process.kill(-service.child.pid,'SIGKILL');}catch{service.child.kill('SIGKILL');}}this.changed();}
}
