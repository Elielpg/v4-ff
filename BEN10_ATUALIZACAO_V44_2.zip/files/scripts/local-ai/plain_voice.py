"""Neutral, non-cloning Brazilian Piper speech with short clauses and pauses."""
import argparse
import io
import json
import re
import wave
from pathlib import Path
from tts_server import make_server

def spoken_text(text):
    text = re.sub(r'\bXLR8\b', 'Acelerado', str(text), flags=re.I)
    return re.sub(r'\bTAP\s+TAP\b', 'toques na tela', text, flags=re.I)

def speech_chunks(text, limit=160):
    text = re.sub(r'\s+', ' ', str(text)).strip()
    result = []
    for sentence in re.split(r'(?<=[.!?;])\s+', text):
        while len(sentence) > limit:
            split = max(sentence.rfind(', ', 40, limit), sentence.rfind(' ', 40, limit))
            if split < 1:
                split = limit
            result.append(sentence[:split].strip())
            sentence = sentence[split:].lstrip(' ,')
        if sentence:
            result.append(sentence)
    return result

class ClearVoice:
    def __init__(self, voice, silence=.18):
        self.voice, self.silence = voice, silence

    def synthesize_wav(self, text, output, syn_config=None):
        params = None
        for index, chunk in enumerate(speech_chunks(spoken_text(text))):
            buffer = io.BytesIO()
            with wave.open(buffer, 'wb') as target:
                self.voice.synthesize_wav(chunk, target, syn_config=syn_config)
            with wave.open(io.BytesIO(buffer.getvalue()), 'rb') as source:
                current = (source.getnchannels(), source.getsampwidth(), source.getframerate())
                if params is None:
                    params = current
                    output.setnchannels(params[0]); output.setsampwidth(params[1]); output.setframerate(params[2])
                elif params != current:
                    raise ValueError('Formato de áudio inconsistente')
                if index:
                    output.writeframesraw(b'\0' * int(params[2] * self.silence) * params[0] * params[1])
                output.writeframesraw(source.readframes(source.getnframes()))

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', type=Path, required=True); p.add_argument('--port', type=int, default=8082)
    p.add_argument('--cache-dir', type=Path); p.add_argument('--build-id'); p.add_argument('--style', choices=['clear', 'lively'], default='clear')
    args = p.parse_args()
    import onnxruntime
    from piper import PiperVoice, SynthesisConfig
    from piper.config import PiperConfig
    config = json.loads(Path(str(args.model)+'.json').read_text())
    if config.get('espeak', {}).get('voice', '').lower() != 'pt-br':
        raise ValueError('Use uma voz Piper brasileira')
    options = onnxruntime.SessionOptions(); options.intra_op_num_threads = 2; options.inter_op_num_threads = 1
    voice = PiperVoice(config=PiperConfig.from_dict(config), session=onnxruntime.InferenceSession(str(args.model), sess_options=options, providers=['CPUExecutionProvider']))
    clear = args.style == 'clear'
    settings = SynthesisConfig(length_scale=1.08 if clear else 1.02, noise_scale=.6 if clear else .65, noise_w_scale=.7 if clear else .75, normalize_audio=True)
    server = make_server(ClearVoice(voice, .18 if clear else .15), args.port, model_name=args.model.stem+'-'+args.style, syn_config=settings, cache_dir=args.cache_dir, build_id=args.build_id, namespace='plain-v442-'+args.style+'-'+str(args.model.stat().st_mtime_ns))
    print('Piper brasileiro sem clonagem pronto em 127.0.0.1:'+str(args.port), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
