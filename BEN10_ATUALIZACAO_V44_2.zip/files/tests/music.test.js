import {test} from 'node:test';
import assert from 'node:assert/strict';
import {MusicQueue} from '../server/music.js';
import {musicCommand,youtubeVideo} from '../public/music-catalog.js';

test('pedidos por nome/link, segurança de URL, prioridade e confirmação de fim sem consumir outra faixa',()=>{
 let now=0;const music=new MusicQueue({now:()=>now});assert.equal(musicCommand('!música Chase Atlantic - Swim'),'Chase Atlantic - Swim');assert.equal(musicCommand('por que chove?'),null);
 for(const url of ['https://youtube.com.evil.test/watch?v=abcdefghijk','javascript:alert(1)','http://youtube.com/watch?v=abcdefghijk','https://user@youtube.com/watch?v=abcdefghijk'])assert.equal(youtubeVideo(url),null);
 const a=music.request({user:'Ana',query:'Chase Atlantic - Swim'});assert.equal(a.videoId,null);music.resolve(a.id,'https://youtu.be/abcdefghijk');
 now=11000;const b=music.request({user:'Bia',query:'https://www.youtube.com/watch?v=lmnopqrstuv',priority:5});music.start();assert.equal(music.active.id,b.id);assert(music.running);music.finish('stale');assert.equal(music.active.id,b.id);music.finish(b.id);assert.equal(music.active.id,a.id);music.finish(a.id);assert.equal(music.active,null);
});
test('limites de pedidos, teste separado da LIVE, pausa e próximo item preservam estado',()=>{
 let now=0;const q=new MusicQueue({now:()=>now});q.request({user:'Ana',query:'um'});assert.throws(()=>q.request({user:'Ana',query:'dois'}),/dez segundos/);now+=11000;q.request({user:'Ana',query:'dois'});now+=11000;assert.throws(()=>q.request({user:'Ana',query:'três'}),/dois pedidos/);assert.throws(()=>q.request({user:'Bia',query:'https://evil.test/song.mp3'}),/link público/);
 q.selectSource('tiktok');assert.equal(q.snapshot().waiting.length,0);const item=q.request({user:'Real',query:'https://youtu.be/abcdefghijk'});q.start(item.id);q.pause();assert(!q.running);assert.equal(q.active.id,item.id);q.start();assert(q.running);q.setVolume(20);assert.equal(q.volume,20);assert.throws(()=>q.setVolume(300));q.remove(item.id);assert.equal(q.active,null);
});
