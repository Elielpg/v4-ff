import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventHub,SpeechQueue} from '../server/core.js';
import {parseArenaCommand} from '../public/arena-commands.js';
import {classicContext} from '../server/classic.js';
import {LocalTextClient} from '../server/local-ai.js';

test('perguntas e assuntos comuns com palavras de ação chegam intactos à conversa',()=>{
 const questions=['Ben, me conta como o XLR8 corre tão rápido','Você gosta de correr','Você pode explicar o poder do Chama','Será que você consegue voar','Me fala sobre o episódio The Visitor','O que acontece quando transforma no Quatro Braços','Me explica direita e esquerda','Quanto tempo o relógio leva para recarregar','Por que o carro anda para frente'];
 for(const text of questions){const event=new EventHub().ingest({type:'comment',text,user:'Ana'},'tiktok');assert.equal(event.text,text);assert.equal(event.source,'tiktok');for(const key of ['action','movement','gesture','control'])assert.equal(event[key],null,text+' / '+key);assert.equal(event.power,false);assert.equal(parseArenaCommand(text),null);}
 for(const text of ['XLR8 dash','Ben, corre para lá','andar esquerda','poder 3','Chama','girar'])assert(parseArenaCommand(text),text);
});

test('a geração protege a fala ativa até o ACK, sem apagar a próxima pergunta',{timeout:3000},async()=>{
 const queue=new SpeechQueue({timeout:20});try{queue.enqueue({prompt:'Por que chove?',user:'Ana'});const first=queue.active.id;queue.enqueue({prompt:'E as nuvens?',user:'Bia'});assert.equal(queue.hold('outro'),false);assert(queue.hold(first));await new Promise(r=>setTimeout(r,65));assert.equal(queue.active.id,first);assert.equal(queue.items.length,1);assert(queue.ack(first));assert.equal(queue.active.user,'Bia');}finally{queue.close();}
});

test('pergunta tem prioridade sobre saudação, presente mantém prioridade e não interrompe',()=>{
 const queue=new SpeechQueue();try{queue.enqueue({kind:'join',user:'Primeiro',priority:1});queue.enqueue({kind:'join',user:'Novo',priority:1});queue.enqueue({kind:'comment',user:'Ana',priority:3});queue.enqueue({kind:'gift',user:'Bia',priority:5});assert.equal(queue.active.user,'Primeiro');queue.ack(queue.active.id);assert.equal(queue.active.user,'Bia');queue.ack(queue.active.id);assert.equal(queue.active.user,'Ana');}finally{queue.close();}
});

test('referências de episódios e memória acompanham a pergunta sem substituir seu assunto',async()=>{
 assert(classicContext('Me conta sobre Ghostfreaked Out').includes('Zs’Skayr'));assert(classicContext('The Visitor e Xylene').includes('destinada ao Max'));
 let body;const client=new LocalTextClient({request:async(_port,_route,options)=>{body=options.body;return {status:200,data:Buffer.from(JSON.stringify({choices:[{message:{content:'A água evapora, forma nuvens e depois cai como chuva. 😎'}}]}))};}});
 const result=await client.generate('Por que chove?',{history:[{prompt:'Meu nome é Ana',answer:'E aí, Ana!'},{prompt:'Eu gosto de ciências',answer:'Ciência é demais!'}]});assert.equal(body.messages.length,2);assert(body.messages.at(-1).content.includes('Por que chove?'));assert(!body.messages.at(-1).content.includes('Vilgax'));assert(!result.text.includes('😎'));assert.equal(body.max_tokens,96);
});

test('erro de contexto orienta reinício e não se disfarça de resposta da IA',async()=>{
 const client=new LocalTextClient({request:async()=>({status:400,data:Buffer.from('{"error":{"message":"request exceeds context size"}}')})});await assert.rejects(()=>client.generate('oi'),error=>error.code==='local_text_response'&&error.message.includes('4096'));
});
