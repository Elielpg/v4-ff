import {test} from 'node:test';
import assert from 'node:assert/strict';
import {SpeechConsumer} from '../public/speech-consumer.js';
import {socialReply} from '../server/social-reply.js';
import {AISession} from '../server/ai-session.js';

test('falha na voz preserva a pergunta e repete somente o áudio antes do ACK',async()=>{
 let now=0,answers=0,voices=0,acks=0;const stages=[];
 const c=new SpeechConsumer({now:()=>now,answer:async()=>{answers++;return {text:'Ana, oi!'};},speak:async()=>{if(++voices===1)throw Error('voz indisponível');},ack:async()=>{acks++;},onState:s=>stages.push(s)});
 const item={id:'oi',user:'Ana'};assert.equal(await c.step(item),false);assert.equal(acks,0);assert.equal(answers,1);
 now=6000;assert.equal(await c.step(item),true);assert.equal(answers,1);assert.equal(voices,2);assert.equal(acks,1);assert(stages.includes('retry'));
});

test('ACK perdido não faz Ben falar duas vezes e três falhas pedem nova tentativa explícita',async()=>{
 let now=0,voices=0,acks=0;const c=new SpeechConsumer({now:()=>now,answer:async()=>({text:'Olá!'}),speak:async()=>{voices++;},ack:async()=>{if(++acks===1)throw Error('rede caiu');}});
 await c.step({id:'one'});now=6000;assert(await c.step({id:'one'}));assert.equal(voices,1);assert.equal(acks,2);
 const fail=new SpeechConsumer({now:()=>now,answer:async()=>{throw Error('indisponível');},speak:async()=>{},ack:async()=>assert.fail('Não pode confirmar')});
 for(let i=0;i<3;i++){await fail.step({id:'two'});now+=35000;}assert(fail.paused);fail.resume();assert(!fail.paused);
});

test('saudações completas têm resposta pertinente; saudação com pergunta continua na IA',async()=>{
 for(const text of ['oi','Olá','Oii!','Ben, oi','olá Ben','bom dia','tudo bem?'])assert(socialReply(text),text);
 for(const text of ['Oi, por que chove?','Olá qual seu alien favorito','Oi meu nome é Ana','qual o poder do Chama'])assert.equal(socialReply(text),null,text);
 let calls=0;const session=new AISession({keys:{key:()=>null,status:()=>({})},getConfig:()=>({conversationProvider:'local'}),localClient:{generate:async()=>{calls++;return {text:'A água evapora e forma nuvens.',model:'fixture'};}}});
 const hello=await session.answer({id:'hi',user:'Ana',prompt:'oi'},{arena:true});assert.equal(hello.mode,'social');assert(hello.text.startsWith('Ana,'));assert.equal(calls,0);assert.equal(session.status().state,'configured');
 const general=await session.answer({id:'why',user:'Ana',prompt:'Oi, como nasce um vulcão?'},{arena:true});assert.equal(general.mode,'local-ai');assert.equal(calls,1);
 const diagnostic=await session.test('oi');assert.equal(diagnostic.mode,'local-ai');assert.equal(calls,2);
});

test('texto de uma fala cancelada não é reproduzido e áudio desativado preserva a fila',async()=>{
 let voices=0,answers=0;const c=new SpeechConsumer({answer:async()=>{answers++;return {text:'Oi'};},speak:async()=>{voices++;},ack:async()=>assert.fail(),isCurrent:()=>false});
 assert.equal(await c.step({id:'one'},{enabled:false}),false);assert.equal(answers,0);await c.step({id:'one'});assert.equal(voices,0);
});

test('queda temporária da voz tenta novamente depois de três falhas sem descartar a resposta',async()=>{
 let now=0,voices=0,answers=0,acks=0;const c=new SpeechConsumer({now:()=>now,answer:async()=>{answers++;return {text:'Oi, Ana!'};},speak:async()=>{if(++voices<=4)throw Object.assign(Error('voz offline'),{code:'local_voice_offline'});},ack:async()=>acks++});
 for(let i=0;i<4;i++){assert.equal(await c.step({id:'retomar'}),false);assert(!c.paused);now+=31000;}
 assert(await c.step({id:'retomar'}));assert.equal(answers,1);assert.equal(acks,1);assert.equal(voices,5);
});

test('bloqueio real do navegador pausa imediatamente até um novo toque',async()=>{
 const c=new SpeechConsumer({answer:async()=>({text:'Oi!'}),speak:async()=>{throw Object.assign(Error('toque'),{code:'audio_interrupted'});},ack:async()=>assert.fail()});
 await c.step({id:'foco'});assert(c.paused);c.resume();assert(!c.paused);
});
