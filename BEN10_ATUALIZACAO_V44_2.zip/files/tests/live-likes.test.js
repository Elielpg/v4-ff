import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {EventHub} from '../server/core.js';
import {LiveAdapter} from '../server/live.js';
import {normalizeLiveEvent} from '../server/live-events.js';
import {ChatGoals} from '../server/chat-goals.js';
import {AlienUnlocks} from '../server/alien-unlocks.js';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

test('protobuf real do PirateTok com Common.msgId padrão zero mantém todos os likes',async()=>{
 const {root}=await import(pathToFileURL(path.resolve('node_modules/piratetok-live-js/dist/proto/schema.js')));
 const {decode}=await import(pathToFileURL(path.resolve('node_modules/piratetok-live-js/dist/events/router.js')));
 const type=root.lookupType('WebcastLikeMessage'),hub=new EventHub();
 for(const count of [17,23]){const bytes=type.encode(type.fromObject({common:{msgId:'0'},count,total:'500',user:{uniqueId:'Ana'}})).finish();const packets=decode('WebcastLikeMessage',bytes);assert.equal(packets[0].type,'like');hub.ingest(normalizeLiveEvent(packets[0].data,'like'),'tiktok');}
 assert.equal(hub.leaders()[0].likes,40);
});

test('ID ausente/zero não descarta TAP TAP; ID real repetido não duplica e lotes não são truncados',()=>{
 const hub=new EventHub(),goals=new ChatGoals({settings:{like:5000}}),dna=new AlienUnlocks();hub.listeners.add(e=>{goals.ingest(e);dna.ingest(e);});
 hub.ingest({id:'0',type:'join',user:'Ana'},'tiktok');
 for(const id of ['0',0,'000',null,undefined])hub.ingest({id,type:'like',user:'Ana',count:12},'tiktok');
 const real=normalizeLiveEvent({common:{msgId:'123'},count:2345,user:{uniqueId:'Bia'}},'like');hub.ingest(real,'tiktok');assert.equal(hub.ingest(real,'tiktok'),null);
 assert.equal(dna.snapshot('tiktok').totalLikes,2405);assert.equal(goals.snapshot('tiktok').goals[0].progress,2405);
 assert.equal(hub.leaders().reduce((n,u)=>n+u.likes,0),2405);assert.equal(dna.snapshot('demo').totalLikes,0);
 assert.equal(hub.ingest({type:'like',count:0},'tiktok'),null);assert.equal(hub.ingest({type:'like',count:-3},'tiktok'),null);
});

test('os dois adaptadores entregam lotes de likes e contabilizam apenas eventos aceitos',async()=>{
 for(const provider of ['piratetok','alternative']){
  let client;class Transport extends EventEmitter{constructor(){super();client=this;}timeout(){return this;}maxRetries(){return this;}proxy(){return this;}async connect(){return provider==='piratetok'?'123':{isConnected:true,roomId:'123'};}disconnect(){}}
  const hub=new EventHub(),adapter=new LiveAdapter((e,s)=>hub.ingest(e,s),()=>{},{load:async()=>({TikTokLiveClient:Transport,TikTokLiveConnection:Transport})});
  try{await adapter.connect('teste',provider);client.emit('join',{common:{msgId:'0'},user:{uniqueId:'Ana'}});client.emit('like',{common:{msgId:'0'},count:9,total:'1009',user:{uniqueId:'Ana'}});client.emit('like',{msgId:'0',likeCount:6,totalLikeCount:'1015',uniqueId:'Ana'});client.emit('like',{common:{msgId:'real'},count:4,user:{uniqueId:'Ana'}});client.emit('like',{common:{msgId:'real'},count:4,user:{uniqueId:'Ana'}});client.emit('like',{count:0,user:{uniqueId:'Ana'}});
   assert.equal(adapter.state.likesReceived,19);assert.equal(hub.leaders()[0].likes,19);assert(adapter.state.lastLikeAt);
  }finally{await adapter.disconnect();}
 }
});
