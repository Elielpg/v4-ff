import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {ProcessSupervisor} from '../scripts/local-ai/process-supervisor.js';
import {SpeechQueue} from '../server/core.js';
import {SpeechState} from '../server/speech-state.js';
import {SpeechConsumer} from '../public/speech-consumer.js';
import {PlaybackReceipts} from '../public/playback-receipts.js';
import {supervisorAlive} from '../scripts/local-ai/runtime-log.js';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
test('V44: serviços órfãos não passam por uma sessão supervisionada saudável',()=>{const state={pid:12,gameRoot:'/game',build:'44.0.0',updatedAt:1000};assert(supervisorAlive(state,'/game','44.0.0',{now:2000,alive:()=>true}));assert(!supervisorAlive(state,'/game','44.0.0',{now:2000,alive:()=>{throw Error('ESRCH');}}));assert(!supervisorAlive(state,'/game','44.0.0',{now:20000,alive:()=>true}));assert(!supervisorAlive(state,'/other','44.0.0',{now:2000,alive:()=>true}));});

test('V44: queda repetida da voz esgota três recuperações sem encerrar nem reiniciar o jogo',{timeout:10000},async()=>{
 const events=[],supervisor=new ProcessSupervisor({backoffMs:30,stopTimeoutMs:1000,log:{event:(type,data)=>events.push({type,...data})}});
 supervisor.add({id:'game',command:process.execPath,args:['-e','setInterval(()=>{},1000)'],stdio:'ignore'});
 supervisor.add({id:'voice',command:process.execPath,args:['-e','process.exit(7)'],stdio:'ignore'});
 try{supervisor.startAll();const pid=supervisor.snapshot().services.game.pid;for(let i=0;i<150&&supervisor.snapshot().services.voice.state!=='failed';i++)await pause(20);const state=supervisor.snapshot();assert.equal(state.services.voice.state,'failed');assert.equal(state.services.voice.restarts,3);assert.equal(state.services.voice.exits,4);assert.equal(state.services.voice.lastExit.code,7);assert.equal(state.services.game.pid,pid);assert.equal(state.services.game.restarts,0);process.kill(pid,0);supervisor.startAll();await pause(100);assert.equal(supervisor.snapshot().services.voice.exits,4);assert.equal(events.filter(e=>e.type==='retry-budget-exhausted').length,1);}finally{await supervisor.stop();}
});
test('V44: fila, resposta pronta e recibo sobrevivem a uma nova instância sem perder IDs',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben44-durable-'));let q,next;
 try{const state=new SpeechState(path.join(temp,'state.json'));q=new SpeechQueue({durable:true,onChange:()=>void state.save(q)});q.enqueue({user:'Ana',prompt:'Quanto é 7 vezes 8?',kind:'comment',source:'tiktok'});q.enqueue({user:'Bia',prompt:'oi',kind:'comment',source:'tiktok'});const first=q.active.id,second=q.items[0].id;q.saveAnswer(first,{mode:'direct',text:'Ana, Dá 56!'},'selection');q.markPlayed(first);await state.flush();q.close();next=new SpeechQueue({durable:true});next.restore(await state.load());assert.equal(next.active.id,first);assert.equal(next.active.answer.text,'Ana, Dá 56!');assert.equal(next.active.played,true);assert.equal(next.items[0].id,second);assert(next.ack(first));await state.save(next);const saved=await state.load();assert(saved.receipts.includes(first));assert.equal(saved.active.id,second);assert(!JSON.stringify(saved).includes('GEMINI_API_KEY'));assert.equal(JSON.parse(await readFile(path.join(temp,'state.json'))).version,1);}finally{q?.close();next?.close();await rm(temp,{recursive:true,force:true});}
});
test('V44: ausência de navegador não confirma nem descarta pergunta por timeout',async()=>{
 const q=new SpeechQueue({durable:true,timeout:10});try{q.enqueue({user:'Ana',prompt:'Pergunta importante',kind:'comment'});const id=q.active.id;await pause(35);assert.equal(q.active.id,id);assert.equal(q.completed,0);assert.equal(q.active.interrupted,true);}finally{q.close();}
});
test('V44: recibo local evita repetir áudio se a página recarrega antes do ACK',async()=>{
 const data=new Map(),storage={getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v)};let plays=0,acks=0;
 const receipts=new PlaybackReceipts(storage),first=new SpeechConsumer({receipts,answer:async()=>({text:'Oi!'}),speak:async()=>plays++,ack:async()=>{throw TypeError('Rede caiu');}});
 await first.step({id:'durable-id'});assert.equal(plays,1);assert(receipts.has('durable-id'));
 const second=new SpeechConsumer({receipts:new PlaybackReceipts(storage),answer:async()=>({text:'Oi!'}),speak:async()=>plays++,ack:async()=>acks++});assert(await second.step({id:'durable-id'}));assert.equal(plays,1);assert.equal(acks,1);
});
