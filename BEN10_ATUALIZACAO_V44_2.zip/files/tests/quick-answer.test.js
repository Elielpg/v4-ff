import {test} from 'node:test';import assert from 'node:assert/strict';
import {directAnswer} from '../server/quick-answer.js';import {AISession} from '../server/ai-session.js';
import {classicContext} from '../server/classic.js';import {LocalTextClient,localClassicPrompt,localQuestion} from '../server/local-ai.js';
import {spokenNumber} from '../public/spoken-number.js';
import {addressBenReply,withoutSpokenAddress} from '../public/ben-dialogue.js';
import {SpeechQueue} from '../server/core.js';

test('contas simples são calculadas com segurança; expressões fora do escopo vão para o modelo',()=>{
 for(const [q,result] of [['Ben, quanto é sete vezes oito?',56],['quanto é 7+8?',15],['quanto é -4 menos 2?',-6],['quanto é 1.000 mais 2?',1002],['quanto é vinte e três vezes dois?',46],['quanto é 1,2 mais 0,3?',1.5]]){const a=directAnswer(q);assert.equal(a.reason,'arithmetic');assert(a.text.includes(new Intl.NumberFormat('pt-BR',{maximumFractionDigits:6}).format(result)),q);}
 assert.match(directAnswer('quanto é 8 dividido por 0?').text,/zero/);assert.match(directAnswer('quanto é 1 dividido por 3?').text,/aproximadamente/);
 for(const q of ['Calcule (7+8)*2','tenho 7 anos e 8 amigos','quanto é sete vezes oito e por que chove?','quanto é 7 + process.exit()'])assert.equal(directAnswer(q),null,q);
});
test('respostas verificadas não inventam estado nem completam perguntas compostas',()=>{
 assert.match(directAnswer('quem criou o Omnitrix?').text,/Azmuth/);assert.match(directAnswer('por que chove?').text,/evapora/);
 assert.equal(directAnswer('Quem criou o Omnitrix e qual foi seu primeiro alien?'),null);
 assert.equal(directAnswer('quantas curtidas faltam?'),null);
 assert.match(directAnswer('quantas curtidas faltam?',{alienUnlocks:{enabled:false,next:null}}).text,/livres/);
 assert.match(directAnswer('quantas curtidas faltam?',{alienUnlocks:{enabled:true,next:{name:'Chama',remaining:23}}}).text,/23.*Chama/);
 assert.equal(classicContext('Ben, por que chove?'),'');assert.equal(classicContext('Qual alien vem depois?'),'');assert.equal(classicContext('Por que o gelo flutua na água?'),'');assert.match(classicContext('Quem é Alien X?'),/Força Alienígena/);
});
test('resposta direta não chama o modelo; o teste de IA continua forçando uma consulta real',async()=>{
 let calls=0;const ai=new AISession({keys:{key:()=>null,status:()=>({})},getConfig:()=>({conversationProvider:'local'}),localClient:{generate:async()=>{calls++;return {text:'A capital é Tóquio.',model:'fixture'};}}});
 const a=await ai.answer({id:'math',user:'Marina',prompt:'quanto é 7 vezes 8?'});assert.equal(a.mode,'direct');assert.equal(calls,0);assert.equal(ai.status().state,'configured');assert.equal(ai.memory.get('demo:Marina').turns[0].answer,'Dá 56!');
 assert.equal(a.spokenText,'Marina, Dá cinquenta e seis!');
 const b=await ai.test('quanto é 7 vezes 8?');assert.equal(b.mode,'local-ai');assert.equal(calls,1);
});
test('números calculados são falados por extenso sem alterar o resultado visível',()=>{
 for(const [n,text] of [[0,'zero'],[56,'cinquenta e seis'],[100,'cem'],[101,'cento e um'],[1002,'mil e dois'],[-23,'menos vinte e três'],[1.5,'um vírgula cinco'],[0.03,'zero vírgula zero três'],[1e6,'um milhão'],[1e12,'um trilhão']])assert.equal(spokenNumber(n),text);
 const a=directAnswer('quanto é 1 dividido por 3?');assert.equal(a.text,'Dá aproximadamente 0,333333!');assert.equal(a.spokenText,'Dá aproximadamente zero vírgula três três três três três três!');
});
test('estado do jogo e contexto de seguimento reconhecem acentos do português',async()=>{
 assert.match(localQuestion('Como está a missão?',{chatGoals:{goals:[{id:'likes',progress:23,target:500}]}}),/23/);
 assert.match(localQuestion('O relógio está carregado?',{watch:{phase:'cooldown'}}),/cooldown/);
 let body;const c=new LocalTextClient({request:async(_p,_r,o)=>{body=o.body;return {status:200,data:Buffer.from('{"choices":[{"message":{"content":"Tudo certo."}}]}')};}});
 await c.generate('Também quero saber disso',{history:[{prompt:'Primeira dúvida',answer:'Resposta'}]});assert.equal(body.messages.length,4);
});
test('histórico não duplica o nome e só acompanha perguntas que dependem do contexto',async()=>{
 assert.equal(addressBenReply('Marina, Marina, bora nessa!','Marina'),'Marina, bora nessa!');assert.equal(withoutSpokenAddress('Marina, Dá 56!','Marina'),'Dá 56!');
 const bodies=[];const client=new LocalTextClient({request:async(_p,_r,o)=>{bodies.push(o.body);return {status:200,data:Buffer.from(JSON.stringify({choices:[{message:{content:'Resposta clara.'}}]}))};}});
 const history=[{prompt:'Falei uma coisa pessoal',answer:'Resposta privada.'}];await client.generate('Como nasce um vulcão?',{history});assert.equal(bodies[0].messages.length,2);await client.generate('E como isso acontece?',{history});assert.equal(bodies[1].messages.length,4);
 assert.equal(bodies[0].messages[0].content,bodies[1].messages[0].content);assert.equal(bodies[0].cache_prompt,true);
});
test('cache evita repetir inferência geral, mas não serve perguntas pessoais nem testes forçados',async()=>{
 let calls=0;const c=new LocalTextClient({request:async()=>{calls++;return {status:200,data:Buffer.from(JSON.stringify({choices:[{message:{content:'Uma resposta.'}}]}))};}});
 await c.generate('Como nasce um vulcão?');assert((await c.generate('Como nasce um vulcão?')).cached);assert.equal(calls,1);await c.generate('Como nasce um vulcão?',{forceFresh:true});assert.equal(calls,2);
 await c.generate('Qual é meu aniversário?');await c.generate('Qual é meu aniversário?');assert.equal(calls,4);
});
test('preparação inicial usa o mesmo prefixo estável da conversa e não fala o teste ao público',async()=>{
 let body;const c=new LocalTextClient({request:async(_p,_r,o)=>{body=o.body;return {status:200,data:Buffer.from('{}')};}});await c.warmup();assert.equal(body.messages[0].content,localClassicPrompt());assert.equal(body.cache_prompt,true);assert.equal(body.max_tokens,1);
});
test('avisos automáticos velhos saem da fila sem descartar perguntas ou presentes',()=>{
 const q=new SpeechQueue();try{q.enqueue({kind:'comment',user:'Atual',priority:3});q.enqueue({kind:'join',scriptedText:'Oi!',user:'Antigo',priority:1});q.enqueue({kind:'comment',prompt:'Pergunta',user:'Ana',priority:3});q.enqueue({kind:'gift',scriptedText:'Valeu!',user:'Bia',priority:5});for(const x of q.items)x.created-=60000;assert.equal(q.peek().user,'Bia');assert(!q.items.some(i=>i.kind==='join'));assert(q.items.some(i=>i.user==='Ana'));q.ack(q.active.id);assert.equal(q.active.user,'Bia');}finally{q.close();}
});
