import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,symlink,writeFile,readFile,mkdir,rm,chmod} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import {LocalVoice} from '../server/local-ai.js';
import {wav} from '../server/core.js';

test('bash start.sh inicia conversa e voz locais paradas, serve o jogo e encerra seus filhos',{timeout:20000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben433-start-')),game=path.join(temp,'game'),local=path.join(temp,'local');let child,log='';
 const freePort=async()=>{const server=http.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;await new Promise(r=>server.close(r));return port;};
 const ports=[await freePort(),await freePort(),await freePort()];
 try{
  await mkdir(game,{recursive:true});await cp('server',path.join(game,'server'),{recursive:true});await cp('public',path.join(game,'public'),{recursive:true});await cp('scripts',path.join(game,'scripts'),{recursive:true});await cp('start.sh',path.join(game,'start.sh'));await symlink(path.resolve('node_modules'),path.join(game,'node_modules'),'dir');await writeFile(path.join(game,'package.json'),'{"type":"module"}');
  await mkdir(path.join(game,'data'),{recursive:true});await writeFile(path.join(game,'data/config.json'),JSON.stringify({localVoiceMode:'legacy',conversationProvider:'local',voiceProvider:'local',hostSpeech:false,localAi:{textPort:ports[0],voicePort:ports[1]}}));
  for(const folder of ['llama.cpp/build/bin','qwen3-tts.cpp/build','cloning'])await mkdir(path.join(local,folder),{recursive:true});
  await writeFile(path.join(local,'install.json'),JSON.stringify({textModel:path.join(local,'text.gguf'),voiceModel:path.join(local,'voice.onnx'),voiceEngine:'qwen3-clone'}));
  for(const file of ['text.gguf','cloning/config.json','cloning/reference.wav','qwen3-tts.cpp/build/libqwen3tts.so'])await writeFile(path.join(local,file),'fixture');
  const llama=path.join(local,'llama.cpp/build/bin/llama-server');await writeFile(llama,`#!/usr/bin/env node
const http=require('node:http');const p=Number(process.argv[process.argv.indexOf('--port')+1]);http.createServer((q,s)=>s.end(JSON.stringify({status:'ok'}))).listen(p,'127.0.0.1');`);await chmod(llama,0o755);
  await writeFile(path.join(game,'scripts/local-ai/clone_voice.py'),`import argparse,json
from http.server import BaseHTTPRequestHandler,HTTPServer
p=argparse.ArgumentParser();p.add_argument('--root');p.add_argument('--port',type=int);p.add_argument('--build-id');a=p.parse_args()
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'ready':True,'model':'Qwen3-TTS-fixture','build':a.build_id,'provider':'qwen3-clone','jobsSupported':True}).encode())
HTTPServer(('127.0.0.1',a.port),H).serve_forever()
`);
  child=spawn('bash',['start.sh'],{cwd:game,env:{...process.env,BEN10_LOCAL_ROOT:local,PORT:String(ports[2])},stdio:['ignore','pipe','pipe']});for(const stream of [child.stdout,child.stderr])stream.on('data',part=>log+=part);
  let healthy=false;for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error(log);try{const h=await fetch('http://127.0.0.1:'+ports[2]+'/api/local-ai/health').then(r=>r.json());if(h.ready&&log.includes('Conversa e voz locais prontas')){healthy=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}
  assert(healthy,log);assert(log.includes('IA local selecionada'));const config=await fetch('http://127.0.0.1:'+ports[2]+'/api/config').then(r=>r.json());assert.equal(config.localAi.voiceTimeoutSeconds,180);
  child.kill('SIGTERM');await once(child,'exit');assert((await readFile(path.join(local,'logs/inicializacao.log'),'utf8')).includes('Encerramento solicitado: SIGTERM'));
  for(const port of ports)await assert.rejects(()=>fetch('http://127.0.0.1:'+port+'/health'));
 }finally{if(child?.exitCode===null){child.kill('SIGTERM');await once(child,'exit');}await rm(temp,{recursive:true,force:true});}
});
test('teste salvo usa GET local e não manda uma nova fala para síntese',async()=>{
 const audio=wav(Buffer.alloc(240));let calls=0;
 const voice=new LocalVoice({request:async(port,route,options)=>{calls++;assert.equal(route,'/preview');assert.equal(options.body,undefined);return {status:200,headers:{'content-type':'audio/wav','x-ben10-voice':'Qwen3-TTS-0.6B-clone-pt'},data:audio};}});
 const response=await voice.preview();assert.equal(response.preview,true);assert.deepEqual(Buffer.from(response.audio,'base64'),audio);assert.equal(calls,1);
 await assert.rejects(()=>new LocalVoice({request:async()=>({status:404})}).preview(),error=>error.code==='local_preview_missing');
});
