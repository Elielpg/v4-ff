# Auditoria antes da evolução V44

Base: Ben 10 Clareira LIVE 43.8.0. Executada antes de alterar o projeto.

## Evidências

435 arquivos distribuíveis; inspeção estática de 282 arquivos JavaScript, Python, HTML, JSON, shell e CSS, incluindo dependências distribuídas; 96 módulos JavaScript em public/ e server/ e 23 módulos Python. Imports relativos existentes, JSON e sintaxe Python conferidos. 235 testes existentes passaram; lint JavaScript passou. Os testes de voz usam fixtures e não demonstram timbre, qualidade vocal ou desempenho no GT3.

## Arquitetura preservada

Babylon.js 9.32.1, acampamento procedural e modelos GLB existentes. Servidor Node >=22.19 coordena estado e SSE; llama.cpp/Qwen na porta local 8081 e voz selecionada na 8082. TikTok usa PirateTok e conector alternativo, com orçamento limitado de reconexão. Nenhuma migração de engine ou substituição de modelo é proposta. Arquivos legados de cidade/missões permanecem para compatibilidade; a sessão ativa da clareira é server/arena-session.js.

## Achados e alterações propostas

| Prioridade | Achado confirmado / risco | Arquivos | Impacto esperado e prova necessária |
| --- | --- | --- | --- |
| P0 | run.js encerra todos os filhos quando voz/texto sai | scripts/local-ai/run.js; novo process-supervisor.js; project-processes.js; restart.js | Isolar falha por serviço, manter jogo, tentativas finitas, testes com processo real morrendo e logs de saída |
| P0 | Fila ativa/espera apenas em memória; temporizador confirma fala sem áudio | server/core.js; novo speech-state.js; server/index.js; public/speech-consumer.js | Persistir IDs/respostas/progresso e ACK idempotente; recuperação conservadora; testar queda/reabertura sem perder pergunta |
| P0 | Logs de ciclo de vida sem rotação ou métricas de saúde | novo runtime-log.js; supervisor; /api/runtime | Diagnóstico com PID, sinal, tentativas, RSS e estado, sem prometer sobreviver ao Android matar todo o aplicativo |
| P1 | Memória social desaparece ao reiniciar | server/ai-session.js; novo audience-memory.js | Memória limitada, atômica e por origem/espectador; retenção controlada e teste de isolamento entre pessoas |
| P1 | Habilidades têm nomes/timings separados; não há energia, defesa e combo modulares | public/transformations.js; novo ability-catalog.js; server/arena-session.js; arena-commands.js | Catálogo declarativo mantendo IDs, três poderes e mecânicas atuais; testes de recarga e ações da LIVE |
| P1 | Perfis gráficos mudam basicamente escala e refresh de sombra | public/world.js; novo graphics-profile.js; camp-world.js; toon-vfx.js | Perfis ajustáveis, orçamento de efeitos e adaptação com histerese; medir renderização separadamente |
| P1 | Cenário já mescla geometria, mas água é material plano e luz pouco dirigida | camp-world.js; world.js; day-cycle.js; novo camp-look.js | Luz gradual, água animada leve, material cartoon e auras/impactos sem trocar personagens |
| P1 | Voz inteira precisa estar pronta antes de tocar; normalização textual limitada | novo voice-text.js; local-ai.js; neural-audio.js; corpus de comparação | Melhorar texto e envelope da boca sem trocar o motor; comparar motores com corpus e resultados honestamente pendentes quando não executados |
| P1 | Eventos e gameplay/social estão acoplados em callback grande | server/index.js; novo live-action-router.js; painel | Regras declarativas por tipo, execução determinística independente do modelo e testes de controles desativados |
| P2 | HTML possui ID music-volume duplicado | public/index.html; public/music-ui.js; arena-app.js | Separar controles e verificar DOM/volume em navegador |
| P2 | Há scripts/reparos históricos que podem reverter arquivos | package.py; README; guia de reversão | Pacote/reparo V44 com backup manifestado e reversão; não aplicar reparos antigos |

## Riscos e limites

A causa inicial da queda no telefone não está provada. Android pode encerrar todo o Termux e SIGKILL não é interceptável; supervisão dentro do app não elimina esse risco. Qwen 4B, voz, conversor e cenário competem por CPU, RAM e calor. Não há medição física de temperatura nesta nuvem. Emissão de partículas deve ter teto e descarte. Memória social e filas podem conter textos de espectadores: dados persistentes ficam locais em data/, fora da distribuição. O modelo de linguagem não terá ponte para shell nem interpretador de comandos do sistema. O motor de voz atual e a referência serão preservados.

## Ordem de execução e aceitação

1. Backup imutável e manifesto SHA-256; trabalho isolado V44.
2. Persistência e supervisão com recuperação limitada; provar que falha da voz não derruba jogo.
3. Memória social/estado comportamental e separação do gameplay determinístico.
4. Catálogo de habilidades e regras LIVE preservando comandos/presentes atuais.
5. Perfis gráficos, ajustes de cenário, câmera e efeitos; provas no Chromium.
6. Normalização/voz, corpus comparativo e sincronização labial; sem ativar alternativa automaticamente.
7. Suíte de regressão, benchmarks separados, relatório final, backup/reversão e distribuição.

A publicação de pacote completo com áudio/clonagem sofreu rejeição de revisão automática na etapa anterior. Não será repetida nem contornada; o trabalho de código autorizado, as evidências e uma entrega permitida serão concluídos antes de tratar qualquer bloqueio de publicação restante.
