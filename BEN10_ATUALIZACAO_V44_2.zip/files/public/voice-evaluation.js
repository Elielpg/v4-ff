export const VOICE_CORPUS=[
 {id:'r-initial',category:'R',text:'Rápido, o relógio recarregou. Vamos correr pela clareira.'},
 {id:'r-middle',category:'R e L',text:'Quatro Braços corre rápido. Clara e Larissa olharam o relógio.'},
 {id:'r-final',category:'R final',text:'Eu vou pular, correr e transformar para ajudar.'},
 {id:'proper-names',category:'Nomes próprios',text:'Ben Tennyson, Gwen e o vô Max chegaram a Bellwood.'},
 {id:'numbers',category:'Números',text:'Faltam 23 curtidas. Sete vezes oito dá 56. Já conseguimos 1.250 pontos.'},
 {id:'brazilian',category:'Português brasileiro',text:'Você chegou! Pega uma cadeira, porque a aventura está só começando.'},
 {id:'short',category:'Latência curta',text:'Oi, Marina! Que bom te ver!'},
 {id:'long',category:'Continuidade',text:'O Omnitrix está carregado, a equipe está reunida e a próxima transformação depende de vocês. Quem vai escolher a aventura?'}
];
export const humanVoiceAssessment=()=>({clarity:null,brazilianPronunciation:null,rAndL:null,numbers:null,names:null,timbre:null,notes:'Avaliação humana pendente; WAV válido e velocidade não demonstram timbre ou clareza.'});
