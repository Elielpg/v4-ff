export const AUDIENCE_TIPS=Object.freeze([
 ['PERGUNTE QUALQUER COISA PRO BEN','Escreva sua pergunta no chat.','Ex.: Ben, qual é seu alien favorito?'],
 ['VOCÊ CONTROLA A AVENTURA','Comente PULAR, CORRER ou PODER.','Experimente também: DEFENDER e COMBO.'],
 ['TAP TAP CARREGA O OMNITRIX','Toque na tela da LIVE para dar curtidas.','A barra mostra quanto falta para o próximo alien.'],
 ['FAÇA PARTE DA EQUIPE','Siga a LIVE e diga oi no chat.','Compartilhe para chamar reforços!']
]);
export class AudienceTips {
 constructor(root){this.root=root;this.index=0;root.replaceChildren();this.title=document.createElement('strong');this.text=document.createElement('span');this.detail=document.createElement('small');root.append(this.title,this.text,this.detail);this.render();this.timer=setInterval(()=>{if(!document.hidden){this.index=(this.index+1)%AUDIENCE_TIPS.length;this.render();}},10000);}
 render(){const tip=AUDIENCE_TIPS[this.index];this.title.textContent=tip[0];this.text.textContent=tip[1];this.detail.textContent=tip[2];}
 dispose(){clearInterval(this.timer);}
}
