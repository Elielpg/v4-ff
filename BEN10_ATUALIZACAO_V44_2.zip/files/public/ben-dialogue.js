import {clean} from './transformations.js';
const safe=value=>String(value||'Visitante').replace(/[<>\x00-\x1f]/g,'').replace(/[^\p{L}\p{N} _.-]/gu,'').slice(0,32).trim()||'Visitante';
export const spokenName=value=>safe(value).replace(/[\d_.-]+/g,' ').trim().split(/\s+/).slice(0,2).join(' ').slice(0,24).trim()||'herói';
const lines={
 goal:[(n,g)=>`Meta batida! Vocês liberaram ${g}!`,(n,g)=>`Boa, equipe! Bora mostrar ${g}!`],
 join:[n=>`E aí, ${n}! Bora nessa?`,n=>`${n}, chegou na hora!`,n=>`Fala, ${n}! Bem-vindo à equipe!`,n=>`Oi, ${n}! O Omnitrix tá pronto!`],
 follow:[n=>`Valeu por seguir, ${n}! Agora é da equipe!`,n=>`${n}, valeu! Vilgax que se cuide!`,n=>`Boa, ${n}! Mais um herói com a gente!`],
 gift:[(n,g)=>`Valeu, ${n}! Esse ${g} foi demais!`,(n,g)=>`${n} mandou ${g}! Bora virar herói!`,(n,g)=>`Boa, ${n}! Valeu pelo ${g}!`,(n,g)=>`Uau, ${n}! Valeu pelo ${g}!`],
 share:[n=>`Valeu, ${n}! Chamou reforços pra aventura!`,n=>`Boa, ${n}! Valeu por compartilhar!`],
 command:[n=>`${n}, desafio aceito!`,n=>`Boa ideia, ${n}! Bora nessa!`,n=>`Pode deixar, ${n}! É hora de herói!`]
};
export function benEventLine(event,index=0){if(event.controlRejected)return event.controlWarning||'';let kind=event.type;if(kind==='comment'){if(!(event.action||event.power||event.gesture||event.movement||event.training||event.control))return '';kind='command';}const options=lines[kind];if(!options)return '';const n=spokenName(event.user),g=safe(event.type==='goal'?event.title||'uma celebração':event.gift||'presente');return options[Math.abs(index)%options.length](n,g);}
export class LiveDialogueQueue{
 constructor({now=Date.now,capacity=8,gap=4500,ttl=45000}={}){this.now=now;this.capacity=capacity;this.gap=gap;this.ttl=ttl;this.items=[];this.cursors={};this.seen=new Map();this.lastSpoken=-Infinity;this.sequence=0;this.completed=0;}
 enqueue(event){const now=this.now(),kind=event.type,key=kind+':'+clean(event.user||'Visitante');const cooldown=kind==='join'?60000:kind==='gift'?1500:3500;if(now-(this.seen.get(key)??-Infinity)<cooldown)return false;const text=benEventLine(event,this.cursors[kind]||0);if(!text)return false;this.seen.set(key,now);if(this.seen.size>512)this.seen.delete(this.seen.keys().next().value);this.cursors[kind]=(this.cursors[kind]||0)+1;this.items=this.items.filter(i=>now-i.at<this.ttl);const item={text,kind,user:safe(event.user),at:now,order:this.sequence++,priority:kind==='gift'?3:kind==='follow'||kind==='share'||kind==='goal'?2:1};if(this.items.length>=this.capacity){const worst=this.items.reduce((best,i)=>i.priority<best.priority?i:best);if(worst.priority>item.priority)return false;this.items.splice(this.items.indexOf(worst),1);}this.items.push(item);return true;}
 next({enabled=true,audioEnabled=false,busy=false,hidden=false}={}){const now=this.now();this.items=this.items.filter(i=>now-i.at<this.ttl);if(!enabled){this.items=[];return null;}if(!audioEnabled||busy||hidden||now-this.lastSpoken<this.gap)return null;this.items.sort((a,b)=>b.priority-a.priority||a.order-b.order);const item=this.items.shift();if(!item)return null;this.lastSpoken=now;this.completed++;return item;}
}
export function withoutSpokenAddress(text,user){const name=spokenName(user).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');let result=String(text).trim();const prefix=new RegExp('^'+name+'\\s*[,!:]\\s*','i');for(let i=0;i<3&&prefix.test(result);i++){const next=result.replace(prefix,'');if(!next)break;result=next;}return result;}
export function addressBenReply(text,user){const name=spokenName(user),body=withoutSpokenAddress(text,user);return name==='Visitante'?body:name+', '+body;}
