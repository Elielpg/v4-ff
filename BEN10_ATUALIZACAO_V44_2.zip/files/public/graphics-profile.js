export const GRAPHICS_PROFILES=Object.freeze({
 economy:Object.freeze({name:'Econômico · LIVE prolongada',fps:30,scale:1.8,maxScale:2.6,shadowSize:256,shadowRefresh:6,effectParts:10,energyOrbs:10,fireflies:0,celStrength:0}),
 balanced:Object.freeze({name:'Equilibrado · GT3',fps:45,scale:1.35,maxScale:2.2,shadowSize:512,shadowRefresh:3,effectParts:20,energyOrbs:18,fireflies:8,celStrength:.22}),
 high:Object.freeze({name:'Alto · mais detalhe',fps:60,scale:1,maxScale:1.8,shadowSize:1024,shadowRefresh:2,effectParts:32,energyOrbs:24,fireflies:12,celStrength:.28})
});
// Render in device pixels within a fixed budget, then smooth the final cel pass.
// Babylon's default Engine uses CSS pixels unless explicitly scaled for DPR.
export function renderBufferScale(scale=1.35,dpr=1,width=412,height=915,quality='balanced'){
 const ratio=Math.min(Math.max(1,Number(dpr)||1),quality==='high'?2:quality==='economy'?1:1.5);
 const pixels=Math.max(1,Number(width)||1)*Math.max(1,Number(height)||1);
 return Math.max(Math.max(.5,Number(scale)||1)/ratio,Math.sqrt(pixels/(quality==='high'?2000000:1200000)));
}
export class GraphicsPolicy {
 constructor(quality='balanced'){this.quality=null;this.adaptive=true;this.frames=0;this.windowAt=0;this.lastRender=-Infinity;this.scaleChanges=0;this.slowWindows=0;this.fastWindows=0;this.fps=0;this.cpuFrameMs=0;this.configure(quality);}
 configure(quality){const id=Object.hasOwn(GRAPHICS_PROFILES,quality)?quality:'balanced';if(id===this.quality)return false;this.quality=id;this.profile=GRAPHICS_PROFILES[id];this.scale=this.profile.scale;this.windowAt=0;this.frames=0;this.slowWindows=0;this.fastWindows=0;return true;}
 shouldRender(now){const interval=1000/this.profile.fps;if(!Number.isFinite(this.lastRender)){this.lastRender=now;return true;}const elapsed=now-this.lastRender;if(elapsed<interval-.4)return false;this.lastRender+=interval*Math.max(1,Math.floor(elapsed/interval));return true;}
 record(now,cpuMs=0){this.cpuFrameMs=this.cpuFrameMs*.85+Math.max(0,cpuMs)*.15;if(!this.windowAt){this.windowAt=now;this.frames=0;}this.frames++;const elapsed=now-this.windowAt;if(elapsed<2500)return false;this.fps=this.frames*1000/elapsed;this.frames=0;this.windowAt=now;if(!this.adaptive)return false;if(this.fps<this.profile.fps*.74){this.slowWindows++;this.fastWindows=0;}else if(this.fps>this.profile.fps*.91){this.fastWindows++;this.slowWindows=0;}else{this.slowWindows=0;this.fastWindows=0;}let next=this.scale;if(this.slowWindows>=2){next=Math.min(this.profile.maxScale,this.scale+.15);this.slowWindows=0;}else if(this.fastWindows>=5){next=Math.max(this.profile.scale,this.scale-.1);this.fastWindows=0;}if(Math.abs(next-this.scale)<.001)return false;this.scale=next;this.scaleChanges++;return true;}
 setTemperature(value){this.batteryTemperatureC=Number.isFinite(value)?value:null;if(!this.adaptive||this.batteryTemperatureC===null)return;if(value>=43)this.scale=Math.min(this.profile.maxScale,Math.max(this.scale,this.profile.scale+.3));}
 setAdaptive(value){const enabled=value!==false;if(this.adaptive&&!enabled){this.scale=this.profile.scale;this.frames=0;this.windowAt=0;this.slowWindows=0;this.fastWindows=0;}this.adaptive=enabled;}
 stats(){return {profile:this.quality,targetFps:this.profile.fps,measuredFps:Math.round(this.fps*10)/10,renderCpuMs:Math.round(this.cpuFrameMs*10)/10,resolutionScale:this.scale,bufferScale:this.bufferScale??null,antialias:'FXAA após cel shading',adaptive:this.adaptive,batteryTemperatureC:this.batteryTemperatureC??null,scaleChanges:this.scaleChanges,particleBudget:this.profile.effectParts+this.profile.energyOrbs};}
}
