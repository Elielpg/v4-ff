export class CompactHUD {
 constructor(button,{storage=globalThis.localStorage}={}){this.button=button;this.storage=storage;let expanded=false;try{expanded=storage.getItem('benHudExpanded442')==='true';}catch{}this.setExpanded(expanded);button.onclick=()=>this.setExpanded(!this.expanded);}
 setExpanded(expanded){this.expanded=!!expanded;document.body.classList.toggle('compact-hud',!this.expanded);this.button.textContent=this.expanded?'Reduzir painéis':'Expandir painéis';this.button.setAttribute('aria-expanded',String(this.expanded));try{this.storage.setItem('benHudExpanded442',String(this.expanded));}catch{}}
}
