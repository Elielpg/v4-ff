const small=['zero','um','dois','três','quatro','cinco','seis','sete','oito','nove','dez','onze','doze','treze','catorze','quinze','dezesseis','dezessete','dezoito','dezenove'];
const tens=['','','vinte','trinta','quarenta','cinquenta','sessenta','setenta','oitenta','noventa'];
const hundreds=['','cento','duzentos','trezentos','quatrocentos','quinhentos','seiscentos','setecentos','oitocentos','novecentos'];
function integer(n){
 if(n<20)return small[n];if(n<100)return tens[Math.floor(n/10)]+(n%10?' e '+integer(n%10):'');if(n===100)return 'cem';if(n<1000)return hundreds[Math.floor(n/100)]+(n%100?' e '+integer(n%100):'');
 for(const [size,one,many] of [[1e12,'trilhão','trilhões'],[1e9,'bilhão','bilhões'],[1e6,'milhão','milhões'],[1e3,'mil','mil']])if(n>=size){const q=Math.floor(n/size),rest=n%size,prefix=size===1000&&q===1?'mil':integer(q)+' '+(q===1?one:many);return prefix+(rest?(rest<100||rest%100===0?' e ':' ')+integer(rest):'');}
}
export function spokenNumber(value){if(!Number.isFinite(value)||Math.abs(value)>1e12)return String(value);const absolute=Math.abs(value).toFixed(6).replace(/0+$/,'').replace(/\.$/,'');const [whole,fraction]=absolute.split('.');return (value<0?'menos ':'')+integer(Number(whole))+(fraction?' vírgula '+[...fraction].map(n=>small[Number(n)]).join(' '):'');}
