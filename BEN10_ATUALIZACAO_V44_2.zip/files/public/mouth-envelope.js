export class MouthEnvelope {
 constructor(){this.value=0;this.last=0;}
 sample(rms,now){const dt=this.last?Math.min(.15,Math.max(.001,(now-this.last)/1000)):1/60;this.last=now;const target=Math.min(1,Math.max(0,(rms-.009)*7));const seconds=target>this.value?0.035:0.11;this.value+=(target-this.value)*(1-Math.exp(-dt/seconds));return this.value;}
 reset(){this.value=0;this.last=0;}
}
