import {DARK_ROMANCE,musicSearch} from './music-catalog.js';
const $=id=>document.getElementById(id);
let youtubePromise;
function youtube(){
 if(window.YT?.Player)return Promise.resolve(window.YT);
 if(!youtubePromise)youtubePromise=new Promise((resolve,reject)=>{
  const previous=window.onYouTubeIframeAPIReady,timer=setTimeout(()=>{youtubePromise=null;reject(Error('O player não carregou. Use Abrir no app ou tente novamente.'));},15000);
  window.onYouTubeIframeAPIReady=()=>{clearTimeout(timer);previous?.();resolve(window.YT);};
  const script=document.createElement('script');script.src='https://www.youtube.com/iframe_api';script.onerror=()=>{clearTimeout(timer);youtubePromise=null;script.remove();reject(Error('Sem conexão com o player. Use Abrir no app.'));};document.head.append(script);
 });return youtubePromise;
}
const button=(text,action)=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=action;return b;};
export class MusicUI{
 constructor({request,notify=()=>{}}){this.request=request;this.notify=notify;this.state=null;this.player=null;this.playerReady=false;this.current=null;this.ducked=false;this.initializing=null;this.locallyActivated=false;
  const open=()=>{$('quick-actions').hidden=true;$('music-panel').showModal();};$('open-music').onclick=open;$('music-chip').onclick=open;$('close-music').onclick=()=>$('music-panel').close();
  $('music-request').onsubmit=e=>{e.preventDefault();this.act({action:'request',query:$('music-query').value}).then(()=>$('music-query').value='').catch(()=>{});};
  $('music-play').onclick=()=>{this.locallyActivated=true;this.act({action:'start'}).then(()=>this.applyPlayback()).catch(()=>{});};$('music-pause').onclick=()=>this.act({action:'pause'}).catch(()=>{});$('music-next').onclick=()=>this.act({action:'next'}).catch(()=>{});
  $('music-player-volume').onchange=()=>this.act({action:'volume',volume:Number($('music-player-volume').value)}).catch(()=>{});
  $('music-player-close').onclick=()=>this.act({action:'pause'}).then(()=>$('music-player-shell').hidden=true).catch(()=>{});
  for(const query of DARK_ROMANCE)$('music-suggestions').append(button(query,()=>$('music-query').value=query));
 }
 async act(body){try{const s=await this.request('music',body);this.sync(s);return s;}catch(e){$('music-status').textContent=e.message;this.notify(e.message);throw e;}}
 sync(state){if(!state)return;this.state=state;$('music-player-volume').value=state.volume;const count=state.waiting.length+Number(!!state.active);$('music-chip').hidden=!count;$('music-chip').textContent=state.active?'♫ '+state.active.title:'♫ '+count+' pedido'+(count===1?'':'s');$('music-current').textContent=state.active?state.active.title+' · pedido de '+state.active.user:'Peça no chat: !musica artista - nome da música';$('music-list').replaceChildren();
  for(const item of state.waiting){const row=document.createElement('li'),title=document.createElement('strong'),by=document.createElement('small'),actions=document.createElement('div');title.textContent=item.title;by.textContent='Pedido de '+item.user+(item.priority?' · prioridade':'');row.append(title,by);
   const open=document.createElement('a');open.textContent=item.url?'Abrir no app':'Buscar no app/YouTube';open.href=item.url||musicSearch(item.query);open.target='_blank';open.rel='noopener noreferrer';actions.append(open);
   if(!item.videoId){const field=document.createElement('input');field.type='url';field.placeholder='Cole o link compartilhado pelo app';field.setAttribute('aria-label','Link de '+item.title);actions.append(field,button('Usar link',()=>this.act({action:'resolve',id:item.id,url:field.value}).catch(()=>{})));}
   else actions.append(button('Tocar',()=>{this.locallyActivated=true;this.act({action:'start',id:item.id}).catch(()=>{});}));
   actions.append(button('Remover',()=>this.act({action:'remove',id:item.id}).catch(()=>{})));row.append(actions);$('music-list').append(row);
  }
  $('music-empty').hidden=!!state.waiting.length;$('music-active-link').hidden=!state.active;if(state.active)$('music-active-link').href=state.active.url;
  this.applyPlayback().catch(e=>{$('music-status').textContent=e.message;});
 }
 async ensurePlayer(){if(this.playerReady)return;if(this.initializing)return this.initializing;
  this.initializing=(async()=>{const YT=await youtube();await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Toque em reproduzir no player ou abra a música no app.')),20000);this.player=new YT.Player('youtube-player',{width:'204',height:'204',host:'https://www.youtube.com',playerVars:{playsinline:1,controls:1,origin:location.origin},events:{onReady:()=>{clearTimeout(timer);this.playerReady=true;resolve();},onStateChange:e=>{if(e.data===0&&this.current){const id=this.current;this.act({action:'ended',id}).catch(()=>{});}},onAutoplayBlocked:()=>{$('music-status').textContent='Toque em ▶ no vídeo para liberar a música.';},onError:()=>{$('music-status').textContent='Este vídeo não pôde tocar aqui. Abra no app, escolha outro link ou avance a fila.';}}});});})();
  try{await this.initializing;}finally{this.initializing=null;}
 }
 async applyPlayback(){const s=this.state;if(!s)return;if(!s.running||!s.active){this.player?.pauseVideo?.();if(!s.active){this.current=null;$('music-player-shell').hidden=true;}return;}
  if(!this.locallyActivated){$('music-status').textContent='Toque em Tocar fila para ativar a música neste navegador.';return;}
  $('music-player-shell').hidden=false;await this.ensurePlayer();if(this.state!==s){return this.applyPlayback();}
  this.volume();if(this.current!==s.active.id){this.current=s.active.id;this.player.loadVideoById(s.active.videoId);}else this.player.playVideo();$('music-status').textContent='O volume diminui quando o Ben fala.';
 }
 volume(){if(this.playerReady&&this.state)this.player.setVolume(Math.round(this.state.volume*(this.ducked?0.2:1)));}
 duck(value){this.ducked=!!value;this.volume();}
}
