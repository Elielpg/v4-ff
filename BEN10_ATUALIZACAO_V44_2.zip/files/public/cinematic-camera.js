export class CinematicCamera {
 constructor(){this.widen=0;this.pan=0;}
 sample(state,dt,now=Date.now(),reducedMotion=false){const power=state?.power,age=power?(now-power.at)/Math.max(1,power.duration):2;const active=age>=0&&age<1;const target=reducedMotion?0:state?.watch?.phase==='transforming'?0.1:active?Math.sin(age*Math.PI)*.055:0;const blend=1-Math.exp(-Math.min(.12,dt)*5);this.widen+=(target-this.widen)*blend;const pan=reducedMotion||!active?0:Math.sin(age*Math.PI*2)*.012;this.pan+=(pan-this.pan)*blend;return {radiusMultiplier:1+Math.max(0,this.widen),pan:this.pan};}
}
