export class PlaybackReceipts {
 constructor(storage=globalThis.localStorage,key='ben44-played'){this.storage=storage;this.key=key;try{this.items=new Map(JSON.parse(storage?.getItem(key)||'[]'));}catch{this.items=new Map();}this.trim();}
 trim(){for(const [id,at] of this.items)if(typeof id!=='string'||!Number.isFinite(at)||Date.now()-at>86400000)this.items.delete(id);while(this.items.size>256)this.items.delete(this.items.keys().next().value);}
 has(id){return this.items.has(id);}
 mark(id){this.items.set(id,Date.now());this.trim();try{this.storage?.setItem(this.key,JSON.stringify([...this.items]));}catch{}}
}
