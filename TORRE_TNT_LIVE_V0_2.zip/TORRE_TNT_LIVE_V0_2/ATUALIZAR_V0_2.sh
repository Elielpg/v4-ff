#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
TARGET_TORRE="${1:-$HOME/TORRE_TNT_LIVE_V0_1}"
python3 scripts/update.py "$TARGET_TORRE"
