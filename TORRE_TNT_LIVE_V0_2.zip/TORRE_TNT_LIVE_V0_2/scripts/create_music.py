"""Original loopable chiptune; no sampled music."""
from pathlib import Path
import numpy as np,wave
root=Path(__file__).resolve().parent.parent;sr=32000;beat=60/112;duration=beat*64;n=round(sr*duration);out=np.zeros(n,np.float64)
def note(freq,at,length,level=.08,kind='pluck'):
 t=np.arange(round(sr*length))/sr
 if kind=='bass':sound=(np.sin(2*np.pi*freq*t)+.17*np.sin(2*np.pi*freq*2*t))*np.exp(-t*6)
 elif kind=='bell':sound=(np.sin(2*np.pi*freq*t)+.16*np.sin(2*np.pi*freq*3*t))*np.exp(-t*8)
 else:sound=(np.sin(2*np.pi*freq*t)+.23*np.sin(2*np.pi*freq*3*t)+.08*np.sin(2*np.pi*freq*5*t))*np.exp(-t*12)
 fade=min(160,len(t)//2);sound[:fade]*=np.linspace(0,1,fade);sound[-fade:]*=np.linspace(1,0,fade)
 idx=(np.arange(len(sound))+round(at*sr))%n;np.add.at(out,idx,sound*level)
melody=[72,76,79,76,74,77,81,77,71,74,79,74,72,76,79,83]
for i in range(64):
 chord=[48,53,55,48][(i//4)%4];note(440*2**((chord-69)/12),i*beat,beat*.8,.075,'bass')
 m=melody[i%16];note(440*2**((m-69)/12),i*beat+beat*.05,beat*1.2,.045,'pluck')
 if i%2==0:note(440*2**((m+12-69)/12),i*beat+beat*.5,beat*.7,.012,'bell')
 # Soft original percussion.
 t=np.arange(round(sr*.12))/sr;k=np.sin(2*np.pi*(74*t-60*t*t))*np.exp(-t*45);idx=(np.arange(len(k))+round(i*beat*sr))%n;np.add.at(out,idx,k*.07)
 rng=np.random.default_rng(317+i);h=rng.normal(0,1,round(sr*.035))*np.exp(-np.arange(round(sr*.035))/sr*160);idx=(np.arange(len(h))+round((i+.5)*beat*sr))%n;np.add.at(out,idx,h*.008)
out*=.66/max(.01,np.max(np.abs(out)));p=root/'public/assets/bloco-a-bloco.wav'
with wave.open(str(p),'wb')as f:f.setparams((1,2,sr,0,'NONE','not compressed'));f.writeframes((out*32767).astype('<i2').tobytes())
print(p.name,round(duration,3),p.stat().st_size)
