"""Build the complete distributable with file hashes, excluding runtime/private data."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
output = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / 'output' / 'release_v02'
output.mkdir(parents=True, exist_ok=True)
version = json.loads((root / 'package.json').read_text())['version']
prefix = 'TORRE_TNT_LIVE_V' + '_'.join(version.split('.')[:2])
include = ['package.json','package-lock.json','.gitignore','README.md','install.sh','start.sh','stop.sh','diagnose.sh','ATUALIZAR_V0_2.sh','public','server','scripts','tests','docs']
files = []
for name in include:
    path = root / name
    candidates = sorted(path.rglob('*')) if path.is_dir() else [path]
    for file in candidates:
        if '__pycache__' in file.parts or file.suffix == '.pyc':
            continue
        if file.is_symlink():
            raise ValueError('Symlink not allowed: ' + str(file))
        if file.is_file():
            files.append(file)
records = [{'path':file.relative_to(root).as_posix(),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()} for file in sorted(files)]
manifest = {'project':'torre-tnt-live','version':version,'prefix':prefix,'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excluded':['node_modules','data','logs','output','backups','.env'],'files':records}
(root / 'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(root / 'MANIFEST.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
files += [root / 'MANIFEST.json',root / 'MANIFEST.sha256']
archive = output / (prefix + '.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as package:
    for file in sorted(files):
        info = zipfile.ZipInfo(prefix+'/'+file.relative_to(root).as_posix(),date_time=datetime.datetime.now().timetuple()[:6])
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o100755 if file.suffix == '.sh' else 0o100644) << 16
        package.writestr(info,file.read_bytes())
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for record in records:
        assert hashlib.sha256(package.read(prefix+'/'+record['path'])).hexdigest() == record['sha256']
    assert not any(set(Path(name).parts)&{'data','logs','node_modules','output','backups','.env'} for name in package.namelist())
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
(output / (prefix+'.sha256')).write_text(sha+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'version':version,'bytes':archive.stat().st_size,'files':len(files),'sha256':sha},indent=2))
