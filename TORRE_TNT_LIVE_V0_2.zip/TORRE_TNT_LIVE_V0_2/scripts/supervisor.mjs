import { spawn } from "node:child_process";
import {
  mkdir,
  appendFile,
  writeFile,
  unlink,
  readFile,
  realpath,
  stat,
  rename,
} from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
await mkdir(path.join(root, "logs"), { recursive: true });
await mkdir(path.join(root, "data"), { recursive: true });
const pidfile = path.join(root, "data", "supervisor.pid");
try {
  const old = Number(await readFile(pidfile, "utf8"));
  if (old > 0) {
    const cmd = await readFile("/proc/" + old + "/cmdline", "utf8").catch(
      () => "",
    );
    if (
      cmd.includes("supervisor.mjs") &&
      (cmd.includes(root) ||
        (await realpath("/proc/" + old + "/cwd").catch(() => "")) === root)
    ) {
      console.error(
        "Esta instalação já está em execução. Abra http://127.0.0.1:" +
          (process.env.PORT || 3300),
      );
      process.exit(78);
    }
  }
} catch {}
await writeFile(pidfile, String(process.pid));
let child,
  stopping = false,
  timer,
  stopTimer;
const exits = [];
const configuredMax = Number(process.env.TORRE_MAX_RESTARTS ?? 4);
const max =
    Number.isInteger(configuredMax) && configuredMax >= 0 && configuredMax <= 8
      ? configuredMax
      : 4,
  windowMs = 15 * 60 * 1000;
async function record(data) {
  try {
    const file = path.join(root, "logs", "supervisor.jsonl");
    if ((await stat(file).catch(() => ({ size: 0 }))).size > 1e6)
      await rename(file, file + ".1").catch(() => {});
    await appendFile(
      file,
      JSON.stringify({ at: new Date().toISOString(), ...data }) + "\n",
    );
  } catch (error) {
    console.error(
      "Não foi possível gravar o diagnóstico do supervisor:",
      error.message,
    );
  }
}
function start() {
  child = spawn(process.execPath, [path.join(root, "server/index.mjs")], {
    cwd: root,
    stdio: "inherit",
    env: process.env,
  });
  void record({ event: "spawn", pid: child.pid });
  child.on(
    "error",
    (e) => void record({ event: "spawn-error", message: e.message }),
  );
  child.on("exit", (code, signal) => {
    clearTimeout(stopTimer);
    void record({ event: "exit", code, signal, requested: stopping });
    if (code === 78) {
      console.error(
        "Porta ocupada ou instalação já aberta. Recuperação não será repetida.",
      );
      void unlink(pidfile).catch(() => {});
      process.exitCode = 78;
      return;
    }
    if (stopping) {
      void unlink(pidfile).catch(() => {});
      return;
    }
    const now = Date.now();
    exits.push(now);
    while (exits[0] < now - windowMs) exits.shift();
    if (exits.length > max) {
      console.error(
        "Limite de recuperação atingido. Confira logs/supervisor.jsonl.",
      );
      void unlink(pidfile).catch(() => {});
      process.exitCode = 1;
      return;
    }
    const delay = Math.min(20000, 1000 * 2 ** exits.length);
    console.error(
      `Servidor encerrou (${signal || code}). Recuperação ${exits.length}/${max} em ${delay / 1000}s.`,
    );
    timer = setTimeout(start, delay);
  });
}
function stop(s) {
  if (stopping) return;
  stopping = true;
  clearTimeout(timer);
  if (child?.exitCode === null) {
    child.kill(s);
    stopTimer = setTimeout(() => {
      if (child?.exitCode === null) {
        void record({ event: "forced-stop", pid: child.pid });
        child.kill("SIGKILL");
      }
    }, 8000);
    stopTimer.unref();
  } else void unlink(pidfile).catch(() => {});
}
process.on("SIGINT", () => stop("SIGINT"));
process.on("SIGTERM", () => stop("SIGTERM"));
start();
