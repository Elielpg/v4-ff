import { TowerEngine } from "../server/engine.mjs";
import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
let clock = 100000;
const engine = new TowerEngine({ now: () => clock, mode: "live" });
let seed = 223;
const random = () => {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return seed / 4294967296;
};
const start = performance.now(),
  cpu = process.cpuUsage();
let events = 0,
  likes = 0;
for (let second = 0; second < 3600; second++) {
  for (let i = 0; i < 10; i++) {
    const user = "viewer_" + Math.floor(random() * 1000),
      choice = random(),
      id = String(++events);
    let e;
    if (choice < 0.64) {
      const count = 1 + Math.floor(random() * 100);
      likes += count;
      e = { type: "like", count };
    } else if (choice < 0.82)
      e = {
        type: "comment",
        text: ["BLOCO", "DEFESA", "TNT", "Vamos construir!"][
          Math.floor(random() * 4)
        ],
      };
    else if (choice < 0.95)
      e = {
        type: "gift",
        gift: ["Rosa", "GG", "TikTok", "Perfume", "Galáxia"][
          Math.floor(random() * 5)
        ],
        count: 1,
        repeatEnd: true,
      };
    else e = { type: random() < 0.5 ? "share" : "follow" };
    engine.ingest({ id, user, ...e });
  }
  for (let frame = 0; frame < 20; frame++) {
    clock += 50;
    engine.tick();
  }
}
const elapsed = performance.now() - start,
  usage = process.cpuUsage(cpu),
  saved = JSON.parse(JSON.stringify(engine.save()));
const restored = new TowerEngine({ now: () => clock, mode: "live", saved });
assert.equal(restored.totals.likes, likes);
assert.equal(restored.blocks, engine.blocks);
assert.equal(restored.wins, engine.wins);
assert.equal(restored.queuedBlocks, engine.queuedBlocks);
assert.equal(restored.public().grid, engine.public().grid);
assert.equal(restored.players.size, 1000);
assert(engine.blocks >= 0 && engine.blocks < 1800);
assert(engine.seen.size <= 4096);
assert(engine.streaks.size <= 4096);
const report = {
  checkedAt: new Date().toISOString(),
  environment: {
    platform: process.platform,
    arch: process.arch,
    node: process.version,
  },
  scope:
    "CPU game engine only; one hour of virtual events, not a real-time LIVE or a phone benchmark",
  virtualSeconds: 3600,
  events,
  players: engine.players.size,
  elapsedMs: Math.round(elapsed * 100) / 100,
  cpuMs: Math.round((usage.user + usage.system) / 1000),
  eventsPerSecond: Math.round(events / (elapsed / 1000)),
  rssMB: Math.round((process.memoryUsage().rss / 1048576) * 10) / 10,
  peakRssMB: Math.round((process.resourceUsage().maxRSS / 1024) * 10) / 10,
  snapshotBytes: Buffer.byteLength(JSON.stringify(saved)),
  wins: engine.wins,
  queuedBlocks: engine.queuedBlocks,
  queueOwners: engine.queue.length,
  gridCells: engine.cells.length,
  blocks: engine.blocks,
  likes: engine.totals.likes,
  saveRestoreMatches: true,
  realTimeDurationTested: false,
  physicalAndroidTested: false,
};
await mkdir(new URL("../output/", import.meta.url), { recursive: true });
await writeFile(
  new URL("../output/BENCHMARK.json", import.meta.url),
  JSON.stringify(report, null, 2),
);
console.log(JSON.stringify(report, null, 2));
