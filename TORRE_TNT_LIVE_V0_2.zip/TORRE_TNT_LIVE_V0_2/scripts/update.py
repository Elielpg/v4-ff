"""Update this installation only, with a verified file list and a local rollback ZIP."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
import zipfile

source = Path(__file__).resolve().parent.parent

def own_processes(target):
    found = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            args = (proc / 'cmdline').read_bytes().decode(errors='replace').split('\0')
            cwd = (proc / 'cwd').resolve()
            for rel in ['server/index.mjs', 'scripts/supervisor.mjs']:
                if str(target / rel) in args or (cwd == target and (rel in args or './' + rel in args)):
                    found.append(int(proc.name))
                    break
        except OSError:
            pass
    return found

def apply(target):
    if source == target:
        raise ValueError('Para uma instalação nova, use bash install.sh e bash start.sh.')
    old = json.loads((target / 'package.json').read_text())
    new = json.loads((source / 'package.json').read_text())
    if old.get('name') != 'torre-tnt-live' or new.get('name') != 'torre-tnt-live':
        raise ValueError('A pasta indicada não é uma instalação Torre TNT.')
    files = []
    protected = {'data', 'logs', 'backups', 'node_modules', '.git', '.env'}
    for line in (source / 'MANIFEST.sha256').read_text().splitlines():
        digest, name = line.split('  ', 1)
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts or rel.parts[0] in protected:
            raise ValueError('Caminho não permitido no manifesto: ' + name)
        file = source / rel
        if file.is_symlink() or not file.resolve().is_relative_to(source) or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise ValueError('Arquivo alterado ou incompleto: ' + name)
        if not (target / rel).resolve().is_relative_to(target):
            raise ValueError('Destino fora da instalação: ' + name)
        files.append(rel)
    subprocess.run(['bash', str(target / 'stop.sh')], check=True, cwd=target)
    # A manually started server may have no supervisor PID file. Match its exact
    # entry script/cwd, never the port or all Node processes on the phone.
    pending = own_processes(target)
    for pid in pending:
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    for _ in range(120):
        if not own_processes(target):
            break
        time.sleep(.1)
    else:
        raise ValueError('O processo anterior não terminou. Nenhum arquivo foi substituído; pare a sessão original.')
    backups = target / 'backups'
    backups.mkdir(exist_ok=True)
    backup = backups / ('antes-' + new['version'] + '-' + time.strftime('%Y%m%d-%H%M%S') + '.zip')
    excluded = {'node_modules', 'backups', 'output', '.git', '__pycache__'}
    with zipfile.ZipFile(backup, 'x', zipfile.ZIP_DEFLATED) as archive:
        for file in target.rglob('*'):
            rel = file.relative_to(target)
            if file.is_file() and not file.is_symlink() and not set(rel.parts) & excluded:
                archive.write(file, rel.as_posix())
    with zipfile.ZipFile(backup) as archive:
        if archive.testzip():
            raise ValueError('O backup não passou na verificação de integridade.')
    print('Backup verificado: ' + str(backup), flush=True)
    for rel in files + [Path('MANIFEST.sha256'), Path('MANIFEST.json')]:
        dest = target / rel
        if not dest.resolve().is_relative_to(target):
            raise ValueError('Destino fora da instalação: ' + str(rel))
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / rel, dest)
    subprocess.run(['bash', str(target / 'install.sh')], check=True, cwd=target)
    print('Atualizado para ' + new['version'] + '. Progresso, configurações e logs preservados.')
    print('Backup da versão anterior: ' + str(backup))
    print('Para iniciar: cd ' + shlex.quote(str(target)) + ' && bash start.sh')

if __name__ == '__main__':
    try:
        if len(sys.argv) != 2:
            raise ValueError('Informe a pasta da instalação atual.')
        apply(Path(sys.argv[1]).expanduser().resolve())
    except Exception as error:
        print('Atualização interrompida: ' + str(error), file=sys.stderr)
        sys.exit(1)
