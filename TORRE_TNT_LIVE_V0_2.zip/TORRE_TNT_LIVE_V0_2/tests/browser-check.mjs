// Optional Chromium/Playwright verification; uses only isolated demo data.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { TowerEngine } from "../server/engine.mjs";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const { chromium } = await import(
  process.env.PLAYWRIGHT_MODULE || "playwright-core"
);
const data = await mkdtemp(path.join(tmpdir(), "torre-browser-"));
const port = Number(process.env.TEST_PORT || 34731),
  base = "http://127.0.0.1:" + port;
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
let child,
  browser,
  log = "";
function start() {
  child = spawn(process.execPath, ["server/index.mjs"], {
    cwd: root,
    env: { ...process.env, PORT: String(port), TORRE_DATA_DIR: data },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stderr.on("data", (d) => (log += d));
  child.stdout.on("data", (d) => (log += d));
}
async function stop() {
  if (!child || child.exitCode !== null) return;
  const ended = new Promise((r) => child.once("exit", r));
  child.kill("SIGTERM");
  await ended;
}
const state = () => fetch(base + "/api/state").then((r) => r.json());
async function ready() {
  for (let i = 0; i < 100; i++) {
    try {
      return await state();
    } catch {
      if (child.exitCode !== null) throw Error(log);
      await delay(50);
    }
  }
  throw Error("Server unavailable");
}
async function post(p, d = {}) {
  const r = await fetch(base + "/api/" + p, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(d),
  });
  assert(r.ok, await r.clone().text());
  return r.json();
}
const event = (d) =>
  post("demo/event", {
    id: crypto.randomUUID(),
    user: "teste_lua",
    name: "Lua",
    ...d,
  });
async function waitCount(n) {
  for (let i = 0; i < 200; i++) {
    const s = await state();
    if (s.blocks === n && s.construction.queued === 0) return s;
    await delay(70);
  }
  throw Error("Queue did not reach " + n);
}
async function seedProgress(blocks) {
  await stop();
  const e = new TowerEngine({ mode: "demo" });
  e.configure({ autoBuild: false, boostIntervalMs: 80 });
  e.build(blocks, null, "fixture");
  await writeFile(path.join(data, "demo.json"), JSON.stringify(e.save()));
  start();
  await ready();
}
try {
  start();
  await ready();
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({
    viewport: { width: 450, height: 960 },
    deviceScaleFactor: 1,
  });
  const errors = [],
    failed = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("response", (r) => {
    if (r.status() >= 400) failed.push({ url: r.url(), status: r.status() });
  });
  await page.goto(base);
  await page.waitForFunction(() => window.TORRE?.state);
  await page.locator("#demo-start").click();
  await post("demo/stop");
  await post("settings", { autoBuild: false, boostIntervalMs: 80 });
  await post("demo/reset");
  await delay(300);
  const sound = await page.evaluate(async () => {
    const a = TORRE.audio,
      an = a.ctx.createAnalyser();
    a.master.connect(an);
    a.sfx("explosion");
    await new Promise((r) => setTimeout(r, 110));
    const b = new Float32Array(an.fftSize);
    an.getFloatTimeDomainData(b);
    a.master.disconnect(an);
    an.disconnect();
    return {
      context: a.ctx.state,
      musicPaused: a.music.paused,
      musicReady: a.music.readyState,
      effectRms: Math.sqrt(b.reduce((s, x) => s + x * x, 0) / b.length),
    };
  });
  assert.equal(sound.context, "running");
  assert.equal(sound.musicPaused, false);
  assert(sound.musicReady >= 2);
  assert(sound.effectRms > 0.0001);
  await page.evaluate(() => {
    window.placements = [];
    const run = TORRE.world.action.bind(TORRE.world);
    TORRE.world.action = (e) => {
      if (e.kind === "build")
        placements.push({ index: e.index, amount: e.amount, at: e.at });
      run(e);
    };
  });
  await event({ type: "like", count: 720 });
  const immediate = await state();
  assert(immediate.blocks <= 1);
  assert(immediate.construction.queued >= 35);
  await waitCount(36);
  await delay(300);
  const placements = await page.evaluate(() => placements.slice());
  assert.equal(placements.length, 36);
  assert(placements.every((a) => a.amount === 1));
  assert.equal(new Set(placements.map((a) => a.index)).size, 36);
  assert(placements.every((a, i) => !i || a.at > placements[i - 1].at));
  await event({ type: "gift", gift: "Rosa", count: 1, repeatEnd: true });
  await delay(450);
  assert.equal((await state()).blocks, 26);
  assert.equal(await page.locator("#gift-alert-name").textContent(), "Rosa");
  await mkdir(path.join(root, "docs/previas"), { recursive: true });
  await page.screenshot({ path: path.join(root, "docs/previas/TNT.png") });
  await delay(900);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 26);
  await event({ type: "comment", text: "DEFESA" });
  await event({ type: "gift", gift: "Rosa", count: 1, repeatEnd: true });
  await delay(1400);
  assert.equal((await state()).blocks, 19);
  await event({ type: "gift", gift: "GG", count: 1, repeatEnd: true });
  await waitCount(99);
  assert.equal(
    (await state()).wins,
    0,
    "100 blocks no longer represent the entire room",
  );
  await page.locator("#gift-pause").click();
  assert(
    await page
      .locator("#gift-cards img")
      .evaluateAll((imgs) =>
        imgs.every((i) => i.complete && i.naturalWidth > 0),
      ),
  );
  // Restored progress fixtures exercise the actual save format and camera at height.
  await seedProgress(720);
  await page.waitForFunction(() => TORRE.state.blocks === 720);
  await delay(1700);
  assert((await page.evaluate(() => TORRE.world.metrics())).cameraOffset > 200);
  await page.screenshot({ path: path.join(root, "docs/previas/JOGO.png") });
  await event({ type: "gift", gift: "Rosa", count: 1, repeatEnd: true });
  await delay(800);
  assert.equal((await state()).blocks, 710);
  await page.screenshot({ path: path.join(root, "docs/previas/BURACOS.png") });
  await event({ type: "like", count: 200 });
  await waitCount(720);
  await delay(300);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 720);
  await page.screenshot({ path: path.join(root, "docs/previas/REPARADO.png") });
  await page.locator("#view-toggle").click();
  await delay(400);
  assert(await page.evaluate(() => TORRE.world.overview));
  const overview = await page.evaluate(() => TORRE.world.metrics());
  assert(overview.towerBounds.top >= overview.worldTop);
  assert.equal(overview.visibleCells, 720);
  await page.screenshot({ path: path.join(root, "docs/previas/MAPA.png") });
  await page.locator("#view-toggle").click();
  await delay(1100);
  const layouts = [];
  for (const size of [
    { width: 360, height: 800 },
    { width: 450, height: 960 },
    { width: 916, height: 2040 },
    { width: 1280, height: 720 },
  ]) {
    await page.setViewportSize(size);
    await delay(1600);
    const m = await page.evaluate(() => ({
      ...TORRE.world.metrics(),
      hud: document.getElementById("hud").getBoundingClientRect().toJSON(),
      footer: document.querySelector("footer").getBoundingClientRect().toJSON(),
      scroll: document.body.scrollWidth,
      screen: innerWidth,
    }));
    assert.equal(m.columns, 18);
    assert.equal(m.rows, 100);
    assert.equal(m.capacity, 1800);
    assert.equal(m.visualBlocks, 720);
    assert(m.hud.bottom < m.footer.top);
    assert(m.scroll <= m.screen);
    assert(m.builder.y < m.worldFloor + 2);
    assert(m.builder.y - m.tile * 4 > m.worldTop - 3);
    assert(m.worldFloor < (m.footer.top / size.width) * 360);
    assert(m.visibleCells < 720, "offscreen cells should be culled");
    layouts.push({ viewport: size, ...m });
  }
  await page.setViewportSize({ width: 450, height: 960 });
  await seedProgress(1795);
  await page.waitForFunction(() => TORRE.state.blocks === 1795);
  await delay(1700);
  assert.equal((await state()).wins, 0);
  assert.equal(await page.locator("#percent").textContent(), "99%");
  assert.equal(await page.locator("#floor-count").textContent(), "99");
  await page.screenshot({ path: path.join(root, "docs/previas/TETO.png") });
  await event({ type: "gift", gift: "TikTok", count: 1, repeatEnd: true });
  await page.waitForFunction(() => TORRE.state.wins === 1);
  await delay(350);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 1800);
  assert(await page.locator("#win-banner").isVisible());
  assert.equal((await state()).construction.queued, 15);
  await page.screenshot({ path: path.join(root, "docs/previas/VITORIA.png") });
  await waitCount(15);
  assert.equal((await state()).wins, 1);
  await post("mode", { mode: "live" });
  await delay(350);
  const before = (await state()).totals.likes;
  await page.locator("#game").click({ position: { x: 110, y: 600 } });
  await delay(300);
  assert.equal((await state()).totals.likes, before);
  assert(await page.locator("#quick-gift").isDisabled());
  await page.locator("#demo-start").click();
  assert(await page.locator("#drawer").isVisible());
  assert.deepEqual(errors, []);
  assert.deepEqual(failed, []);
  const report = {
    checkedAt: new Date().toISOString(),
    browser: browser.version(),
    version: "0.2.0",
    checks: [
      "AudioContext and original WAV playing after a real click",
      "Explosion samples contain audio",
      "36 actual sequential placements, one per action",
      "Rose removes 10 cells",
      "Shield absorbs 3 damage",
      "GG supplies 80 blocks without an early 100-block victory",
      "Restored floor 40 follows camera",
      "Overview shows all 100 floors",
      "Four viewport layouts fit and cull hidden cells",
      "1795 cells do not win: only the last five reach 1800",
      "15 excess materials survive celebration",
      "Demo taps cannot become real LIVE likes",
    ],
    placements,
    sound,
    overview,
    layouts,
    pageErrors: errors,
    failedResponses: failed,
    fixtureNote:
      "Camera screenshots use restored deterministic DEMO progress; no real LIVE or real-time full-room benchmark is claimed",
    realTikTokLiveTested: false,
    physicalAndroidTested: false,
  };
  await mkdir(path.join(root, "output"), { recursive: true });
  await writeFile(
    path.join(root, "output/BROWSER_V02.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  await browser?.close();
  await stop();
  await rm(data, { recursive: true, force: true });
}
