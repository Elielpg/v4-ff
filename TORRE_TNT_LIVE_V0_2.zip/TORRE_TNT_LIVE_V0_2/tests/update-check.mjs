// Supply the released 0.1 ZIP to verify a real migration without touching user data.
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import {
  mkdtemp,
  mkdir,
  writeFile,
  readFile,
  readdir,
  rm,
  cp,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
const run = promisify(execFile),
  root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."),
  oldZip = process.argv[2];
if (!oldZip)
  throw Error(
    "Usage: node tests/update-check.mjs /path/TORRE_TNT_LIVE_V0_1.zip",
  );
assert.equal(
  createHash("sha256")
    .update(await readFile(oldZip))
    .digest("hex"),
  "95bec67cf539f2cac4d469aec759370d70878169341432ce31af975810f74f8d",
);
const temp = await mkdtemp(path.join(tmpdir(), "torre-upgrade-")),
  port = 34893,
  base = "http://127.0.0.1:" + port,
  target = path.join(temp, "TORRE_TNT_LIVE_V0_1");
let child,
  output = "";
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitState() {
  for (let i = 0; i < 160; i++) {
    try {
      return await (await fetch(base + "/api/state")).json();
    } catch {
      await delay(50);
    }
  }
  throw Error("Migration server unavailable");
}
function start(script) {
  child = spawn(
    script === "manual" ? process.execPath : "bash",
    script === "manual" ? ["server/index.mjs"] : ["start.sh"],
    { cwd: target, env: { ...process.env, PORT: String(port) }, stdio: "pipe" },
  );
  child.stdout.on("data", (d) => (output += d));
  child.stderr.on("data", (d) => (output += d));
  return child;
}
try {
  await run("python3", ["-m", "zipfile", "-e", oldZip, temp]);
  await run("bash", ["install.sh"], { cwd: target });
  const { TowerEngine: Old } = await import(
      pathToFileURL(target + "/server/engine.mjs").href
    ),
    old = new Old({ mode: "live" }),
    p = old.player("ana", "Ana");
  old.build(63, p, "fixture");
  old.wins = 3;
  old.round = 4;
  old.totals.likes = 3450;
  old.likeCarry = 10;
  p.followed = true;
  old.configure({
    giftMap: { 77: { effect: "build", amount: 5, name: "Teste", icon: "gg" } },
  });
  await mkdir(target + "/data", { recursive: true });
  await writeFile(target + "/data/live.json", JSON.stringify(old.save()));
  await writeFile(
    target + "/data/session.json",
    JSON.stringify({ project: "torre-tnt-live", mode: "live", username: null }),
  );
  await writeFile(
    target + "/data/bridge.json",
    JSON.stringify({ token: "a".repeat(64) }),
  );
  const manual = start("manual");
  assert.equal((await waitState()).version, "0.1.0");
  const updated = await run("bash", [root + "/ATUALIZAR_V0_2.sh", target], {
    cwd: root,
    maxBuffer: 1e6,
  });
  output += updated.stdout + updated.stderr;
  assert.equal(
    manual.exitCode,
    0,
    "updater should gracefully stop the verified manual server",
  );
  assert.equal(
    JSON.parse(await readFile(target + "/package.json")).version,
    "0.2.0",
  );
  const backups = (await readdir(target + "/backups")).filter((n) =>
    n.endsWith(".zip"),
  );
  assert.equal(backups.length, 1);
  await run("python3", [
    "-c",
    'import zipfile,json,sys; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; assert json.loads(z.read("package.json"))["version"]=="0.1.0"; assert json.loads(z.read("data/live.json"))["schema"]==1',
    target + "/backups/" + backups[0],
  ]);
  start("supervisor");
  const s = await waitState();
  assert.equal(s.version, "0.2.0");
  assert.equal(s.blocks, 63);
  assert.equal(s.goal, 1800);
  assert.equal(s.geometry.columns, 18);
  assert.equal(s.grid.length, 1800);
  assert.equal(s.wins, 3);
  assert.equal(s.totals.likes, 3450);
  assert.equal(s.likeCarry, 10);
  assert.equal(s.players[0].followed, true);
  assert.equal(s.players[0].score, 63);
  assert.equal(s.settings.giftMap["77"].amount, 5);
  await run("bash", ["stop.sh"], { cwd: target });
  if (child.exitCode === null) await new Promise((r) => child.once("exit", r));
  assert.equal(
    JSON.parse(await readFile(target + "/data/live.json")).schema,
    2,
  );
  assert.equal(
    JSON.parse(await readFile(target + "/data/bridge.json")).token,
    "a".repeat(64),
  );
  const foreign = temp + "/foreign";
  await mkdir(foreign);
  await writeFile(
    foreign + "/package.json",
    JSON.stringify({ name: "another-project", version: "1.0.0" }),
  );
  let refused = false;
  try {
    await run("bash", [root + "/ATUALIZAR_V0_2.sh", foreign]);
  } catch {
    refused = true;
  }
  assert(refused);
  assert.equal(
    JSON.parse(await readFile(foreign + "/package.json")).name,
    "another-project",
  );
  const altered = temp + "/altered";
  await mkdir(altered);
  for (const name of ["scripts", "public", "server", "tests", "docs"])
    await cp(root + "/" + name, altered + "/" + name, { recursive: true });
  for (const name of [
    "ATUALIZAR_V0_2.sh",
    "package.json",
    "package-lock.json",
    ".gitignore",
    "README.md",
    "install.sh",
    "start.sh",
    "stop.sh",
    "diagnose.sh",
    "MANIFEST.sha256",
    "MANIFEST.json",
  ])
    await cp(root + "/" + name, altered + "/" + name);
  await writeFile(altered + "/public/catalog.js", "// changed");
  let rejected = false;
  try {
    await run("bash", [altered + "/ATUALIZAR_V0_2.sh", target]);
  } catch (e) {
    rejected = String(e.stderr).includes("Arquivo alterado");
  }
  assert(rejected);
  assert.equal((await readdir(target + "/backups")).length, 1);
  const report = {
    checkedAt: new Date().toISOString(),
    oldVersion: "0.1.0",
    newVersion: s.version,
    manualServerStopped: true,
    backupCrcChecked: true,
    preserved: {
      blocks: s.blocks,
      wins: s.wins,
      likes: s.totals.likes,
      likeCarry: s.likeCarry,
      score: s.players[0].score,
      followed: s.players[0].followed,
      customGiftAmount: s.settings.giftMap["77"].amount,
      bridgeToken: true,
    },
    geometry: s.geometry,
    schema: 2,
    otherProjectRefused: true,
    changedSourceRefused: true,
    physicalAndroidTested: false,
    output,
  };
  await mkdir(root + "/output", { recursive: true });
  await writeFile(
    root + "/output/ATUALIZACAO_V02.json",
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  if (child && child.exitCode === null) {
    await run("bash", ["stop.sh"], { cwd: target }).catch(() => {});
    if (child.exitCode === null) {
      child.kill("SIGTERM");
      await new Promise((r) => child.once("exit", r));
    }
  }
  await rm(temp, { recursive: true, force: true });
}
