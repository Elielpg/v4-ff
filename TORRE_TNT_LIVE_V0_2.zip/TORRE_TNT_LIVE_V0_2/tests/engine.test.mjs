import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { TowerEngine, safeImage } from "../server/engine.mjs";
import { GIFTS, giftRule } from "../public/catalog.js";
const fixture = () => {
  let now = 100000;
  const actions = [],
    e = new TowerEngine({ now: () => now, onAction: (a) => actions.push(a) });
  e.configure({ autoBuild: false });
  return {
    e,
    actions,
    step(ms) {
      now += ms;
      e.tick();
    },
    freeze(ms) {
      now += ms;
      e.freeze();
    },
    now: () => now,
  };
};
// Legacy interaction assertions wait for the virtual builder instead of granting instant blocks.
const settle = (f) => {
  let guard = 0;
  while (f.e.queuedBlocks) {
    if (++guard > 100000) throw Error("Queue did not drain");
    const wait = f.e.celebration
      ? 3500
      : Math.max(90, f.e.stunnedUntil - f.now() + 1);
    f.step(wait);
  }
};
const evt = (f, type, data = {}) => {
  const result = f.e.ingest({ type, user: "ana", name: "Ana", ...data });
  settle(f);
  return result;
};
const build = (f, n) => f.e.build(n, f.e.player("ana"), "test");
test("the game starts with an empty 18-column, hundred-floor tower and a ten-win target", () => {
  const f = fixture();
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.settings.goal, 1800);
  assert.equal(f.e.settings.winGoal, 10);
  assert.equal(f.e.public().mode, "demo");
});
test("twenty likes build one block and retain the partial meter", () => {
  const f = fixture();
  evt(f, "like", { count: 19 });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.likeCarry, 19);
  evt(f, "like", { count: 4 });
  assert.equal(f.e.blocks, 1);
  assert.equal(f.e.likeCarry, 3);
  assert.equal(f.e.totals.likes, 23);
});
test("unattributed likes help the community without manufacturing a viewer", () => {
  const f = fixture();
  f.e.ingest({ type: "like", count: 100 });
  settle(f);
  assert.equal(f.e.blocks, 5);
  assert.equal(f.e.players.size, 0);
  assert.equal(f.e.totals.likes, 100);
});
test("historical room totals are baselined and later increments are counted once", () => {
  const f = fixture();
  f.e.ingest({ type: "like", roomTotal: 11700 });
  assert.equal(f.e.totals.likes, 0);
  f.e.ingest({ type: "like", roomTotal: 11740 });
  settle(f);
  assert.equal(f.e.totals.likes, 40);
  assert.equal(f.e.blocks, 2);
  f.e.ingest({ type: "like", roomTotal: 11740 });
  settle(f);
  assert.equal(f.e.totals.likes, 40);
  f.e.ingest({ type: "like", roomTotal: 10 });
  f.e.ingest({ type: "like", roomTotal: 30 });
  assert.equal(f.e.totals.likes, 40);
  f.e.ingest({ type: "like", roomTotal: 11760 });
  settle(f);
  assert.equal(f.e.totals.likes, 60);
});
test("individual counts and accompanying room totals are not added together", () => {
  const f = fixture();
  evt(f, "like", { count: 20, roomTotal: 5000 });
  assert.equal(f.e.blocks, 1);
  f.e.ingest({ type: "like", roomTotal: 5000 });
  assert.equal(f.e.blocks, 1);
  f.e.ingest({ type: "like", roomTotal: 5020 });
  settle(f);
  assert.equal(f.e.blocks, 2);
});
test("duplicate event IDs cannot grant extra likes or follow bonuses", () => {
  const f = fixture();
  evt(f, "like", { id: "a", count: 100 });
  evt(f, "like", { id: "a", count: 100 });
  assert.equal(f.e.blocks, 5);
  evt(f, "follow", { id: "b" });
  evt(f, "follow", { id: "c" });
  assert.equal(f.e.blocks, 10);
  assert.equal(f.e.totals.followers, 1);
});
test("BLOCO has a separate cooldown per viewer and accepts accents/case normalization", () => {
  const f = fixture();
  evt(f, "comment", { text: "BLOCO" });
  evt(f, "comment", { text: "bloco" });
  assert.equal(f.e.blocks, 1);
  evt(f, "comment", { user: "bia", text: "construir" });
  assert.equal(f.e.blocks, 2);
  f.step(6000);
  evt(f, "comment", { text: "BLOCO" });
  assert.equal(f.e.blocks, 3);
});
test("ordinary comments do not trigger hidden building or arbitrary commands", () => {
  const f = fixture();
  evt(f, "comment", { text: "oi, bloco é legal" });
  evt(f, "comment", { text: "process.exit()" });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.players.get("ana").chat.text, "process.exit()");
});
test("share adds three blocks and two shield charges, with a twenty-second interval", () => {
  const f = fixture();
  evt(f, "share");
  evt(f, "share");
  assert.equal(f.e.blocks, 3);
  assert.equal(f.e.shield, 2);
  f.step(20000);
  evt(f, "share");
  assert.equal(f.e.blocks, 6);
  assert.equal(f.e.totals.shares, 2);
});
test("chat TNT is free but limited independently of build and shield commands", () => {
  const f = fixture();
  build(f, 20);
  evt(f, "comment", { text: "TNT" });
  evt(f, "comment", { text: "TNT" });
  assert.equal(f.e.blocks, 19);
  evt(f, "comment", { text: "DEFESA" });
  evt(f, "comment", { text: "BLOCO" });
  assert.equal(f.e.shield, 3);
  assert.equal(f.e.blocks, 20);
  f.step(12000);
  evt(f, "comment", { text: "TNT" });
  assert.equal(f.e.blocks, 20);
  assert.equal(f.e.shield, 2);
});
test("Rosa supplies ten units of TNT and cannot make tower height negative", () => {
  const f = fixture();
  build(f, 25);
  evt(f, "gift", { gift: "Rosa", count: 2 });
  assert.equal(f.e.blocks, 5);
  evt(f, "gift", { gift: "Rose", count: 1 });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.totals.destroyed, 25);
});
test("the shield absorbs damage first, then excess power removes blocks", () => {
  const f = fixture();
  build(f, 50);
  f.e.protect(15, null, "test");
  f.e.blast(10, null);
  assert.equal(f.e.blocks, 50);
  assert.equal(f.e.shield, 5);
  f.e.blast(12, null);
  assert.equal(f.e.blocks, 43);
  assert.equal(f.e.shield, 0);
  assert.equal(f.actions.at(-1).absorbed, 5);
});
test("shield expires after thirty seconds and is capped", () => {
  const f = fixture();
  f.e.protect(1000, null);
  assert.equal(f.e.shield, 60);
  f.step(30001);
  assert.equal(f.e.shield, 0);
});
test("offline freeze preserves remaining protection rather than applying unseen expiration", () => {
  const f = fixture();
  f.e.protect(20, null);
  const until = f.e.shieldUntil;
  f.freeze(20000);
  assert.equal(f.e.shieldUntil, until + 20000);
  assert.equal(f.e.shield, 20);
});
test("building past a goal awards victories and carries all overflow into the next tower", () => {
  const f = fixture();
  build(f, 75);
  build(f, 3580);
  assert.equal(f.e.wins, 2);
  assert.equal(f.e.round, 3);
  assert.equal(f.e.blocks, 55);
  assert.equal(f.e.totals.built, 3655);
  assert.equal(f.e.players.get("ana").built, 3655);
});
test("interactions during the celebration stay queued for the next tower", () => {
  const f = fixture();
  build(f, 1800);
  assert.ok(f.e.celebration);
  f.e.queueBuild(80, f.e.players.get("ana"), "gift");
  evt(f, "gift", { gift: "Rosa" });
  assert.equal(f.e.blocks, 80);
  assert.equal(f.e.queuedBlocks, 0);
  assert.equal(f.e.wins, 1);
});
test("Hand Hearts completes the current tower and each additional gift earns another completion", () => {
  const f = fixture();
  build(f, 40);
  evt(f, "gift", { gift: "Hand Hearts", count: 2 });
  assert.equal(f.e.wins, 2);
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.totals.built, 3600);
});
test("reset clears the present tower and shield without removing wins or the ranking", () => {
  const f = fixture();
  build(f, 1830);
  f.e.protect(40, null);
  const before = f.e.players.get("ana").score;
  evt(f, "gift", { gift: "TikTok Universe" });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.shield, 0);
  assert.equal(f.e.wins, 1);
  assert.ok(f.e.players.get("ana").score > before);
});
test("an unknown gift remains visible and turns into bounded shield power", () => {
  const f = fixture();
  const r = evt(f, "gift", { gift: "Novo presente", count: 2 });
  assert.equal(r.unknown, true);
  assert.equal(f.e.shield, 2);
  assert.equal(f.e.totals.gifts, 2);
  assert.ok(
    f.actions.some((a) => a.kind === "gift" && a.gift === "Novo presente"),
  );
});
test("a cumulative streak applies deltas, accepts increasing totals with one ID, and ignores duplicate final totals", () => {
  const f = fixture();
  build(f, 90);
  const e = {
    type: "gift",
    user: "ana",
    id: "same",
    gift: "Rosa",
    giftId: "5655",
    isStreak: true,
    streakId: "888",
    repeatEnd: false,
  };
  f.e.ingest({ ...e, count: 1 });
  f.e.ingest({ ...e, count: 2 });
  f.e.ingest({ ...e, id: "final", repeatEnd: true, count: 2 });
  assert.equal(f.e.blocks, 70);
  assert.equal(f.e.totals.gifts, 2);
  assert.equal(f.e.players.get("ana").gifts, 2);
});
test("without a streak group only the final total is accepted, even with the same event ID", () => {
  const f = fixture();
  build(f, 60);
  const e = {
    type: "gift",
    user: "ana",
    gift: "Rosa",
    isStreak: true,
    id: "a",
    count: 3,
  };
  f.e.ingest({ ...e, repeatEnd: false });
  assert.equal(f.e.blocks, 60);
  f.e.ingest({ ...e, repeatEnd: true });
  assert.equal(f.e.blocks, 30);
  assert.equal(f.e.totals.gifts, 3);
});
test("streak deduplication survives process recovery", () => {
  const f = fixture();
  build(f, 60);
  const e = {
    type: "gift",
    user: "ana",
    gift: "Rosa",
    isStreak: true,
    streakId: "long",
    count: 2,
    id: "a",
    repeatEnd: false,
  };
  f.e.ingest(e);
  const copy = new TowerEngine({
    now: f.now,
    saved: JSON.parse(JSON.stringify(f.e.save())),
  });
  copy.ingest({ ...e, id: "b", repeatEnd: true });
  assert.equal(copy.blocks, 40);
  copy.ingest({ ...e, id: "c", count: 3 });
  assert.equal(copy.blocks, 30);
});
test("supported names are matched exactly and ID mappings are configurable without eval", () => {
  assert.equal(giftRule({ gift: "Rose Bear" }), null);
  assert.equal(giftRule({ giftId: 5655, gift: "qualquer" }).id, "rose");
  const f = fixture();
  f.e.configure({
    giftMap: {
      99: { effect: "build", amount: 12, name: "Personalizado", icon: "gg" },
    },
  });
  evt(f, "gift", { gift: "x", giftId: "99", count: 2 });
  assert.equal(f.e.blocks, 24);
  assert.throws(() =>
    f.e.configure({ giftMap: { 8: { effect: "exec", amount: 2 } } }),
  );
  assert.throws(() =>
    f.e.configure({
      giftMap: JSON.parse('{"__proto__":{"effect":"build","amount":2}}'),
    }),
  );
  assert.equal(giftRule({ gift: "constructor" }), null);
});
test("configuration rejects invalid amounts and adjusts the like carry safely", () => {
  const f = fixture();
  assert.throws(() => f.e.configure({ likesPerBlock: 0 }));
  assert.throws(() => f.e.configure({ likesPerBlock: 1.5 }));
  evt(f, "like", { count: 19 });
  f.e.configure({ likesPerBlock: 10 });
  assert.equal(f.e.likeCarry, 9);
  evt(f, "like", { count: 1 });
  assert.equal(f.e.blocks, 1);
});
test("saved games preserve progress, wins, ranking, followers, custom effects and like credit", () => {
  const f = fixture();
  evt(f, "follow");
  evt(f, "like", { count: 123 });
  build(f, 135);
  f.e.protect(22, null);
  const copy = new TowerEngine({
    now: f.now,
    saved: JSON.parse(JSON.stringify(f.e.save())),
  });
  assert.equal(copy.blocks, f.e.blocks);
  assert.equal(copy.wins, f.e.wins);
  assert.equal(copy.likeCarry, f.e.likeCarry);
  assert.equal(copy.players.get("ana").score, f.e.players.get("ana").score);
  assert.equal(copy.players.get("ana").followed, true);
  assert.equal(copy.shield, 22);
  assert.equal(copy.public().project, "torre-tnt-live");
});
test("a different project cannot be loaded into this game", () => {
  const e = new TowerEngine({
    saved: { project: "jujutsu-live", schema: 1, blocks: 99, wins: 50 },
  });
  assert.equal(e.blocks, 0);
  assert.equal(e.wins, 0);
});
test("avatar URLs allow only HTTPS media hosts and no local or script targets", () => {
  assert.equal(safeImage("https://p16.tiktokcdn.com/img/a.webp"), true);
  for (const s of [
    "http://127.0.0.1/a",
    "https://localhost/a",
    "javascript:alert(1)",
    "https://tiktokcdn.com.evil.invalid/a",
    "data:image/png;base64,a",
  ])
    assert.equal(safeImage(s), false);
});
test("all gift guide images are packaged WEBP photos", async () => {
  for (const g of GIFTS) {
    const b = await readFile(
      new URL("../public/assets/gifts/" + g.icon + ".webp", import.meta.url),
    );
    assert.equal(b.toString("ascii", 0, 4), "RIFF");
    assert.equal(b.toString("ascii", 8, 12), "WEBP");
  }
});
test("a burst remains bounded, finite and fully counted through save/restore", () => {
  const f = fixture();
  for (let i = 0; i < 10000; i++) {
    const user = "u" + (i % 40);
    f.e.ingest({
      type: i % 9 ? "like" : "gift",
      user,
      id: String(i),
      count: i % 9 ? 30 : 1,
      gift: i % 18 ? "Rosa" : "TikTok",
    });
    if (i % 25 === 0) f.step(100);
  }
  const s = f.e.public(),
    copy = new TowerEngine({
      now: f.now,
      saved: JSON.parse(JSON.stringify(f.e.save())),
    });
  assert.equal(copy.blocks, f.e.blocks);
  assert.equal(copy.totals.likes, f.e.totals.likes);
  assert.ok(f.e.seen.size <= 4096);
  assert.ok(s.recent.length <= 40);
  assert.ok(s.ranking.length <= 8);
  assert.ok(s.players.length <= 12);
  assert.ok(Number.isFinite(s.wins) && s.blocks >= 0 && s.blocks < 1800);
});
