import { spawn } from "node:child_process";
import {
  mkdtemp,
  writeFile,
  mkdir,
  readFile,
  realpath,
  rm,
  cp,
  symlink,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import path from "node:path";
import assert from "node:assert/strict";
import { TowerEngine } from "../server/engine.mjs";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."),
  temp = await mkdtemp(path.join(tmpdir(), "torre-recovery-"));
const port = 34250 + Math.floor(Math.random() * 200),
  base = `http://127.0.0.1:${port}`,
  delay = (ms) => new Promise((r) => setTimeout(r, ms));
const waitFor = async (fn) => {
  let result;
  for (let i = 0; i < 200; i++) {
    try {
      result = await fn();
      if (result) return result;
    } catch {}
    await delay(40);
  }
  throw Error("Timed out waiting for isolated recovery");
};
let supervisor,
  output = "";
try {
  for (const name of ["server", "scripts", "public"])
    await cp(path.join(root, name), path.join(temp, name), { recursive: true });
  await cp(root + "/package.json", temp + "/package.json");
  await symlink(root + "/node_modules", temp + "/node_modules", "dir");
  await mkdir(temp + "/data");
  const e = new TowerEngine({ mode: "live" }),
    p = e.player("lua", "Lua");
  e.build(240, p, "test");
  e.ingest({ type: "like", user: "lua", count: 240 });
  e.ingest({ type: "gift", user: "lua", gift: "Rosa", count: 1 });
  e.protect(10, p, "test");
  e.ingest({ type: "follow", user: "lua" });
  await writeFile(temp + "/data/live.json", JSON.stringify(e.save()));
  await writeFile(
    temp + "/data/session.json",
    JSON.stringify({ project: "torre-tnt-live", mode: "live", username: null }),
  );
  const expected = {
    blocks: e.blocks,
    wins: e.wins,
    likes: e.totals.likes,
    score: p.score,
    gifts: p.gifts,
    shield: e.shield,
    queued: e.queuedBlocks,
    grid: e.public().grid,
  };
  supervisor = spawn(process.execPath, ["scripts/supervisor.mjs"], {
    cwd: temp,
    env: {
      ...process.env,
      PORT: String(port),
      TORRE_MAX_RESTARTS: "1",
      TORRE_DATA_DIR: temp + "/data",
    },
    stdio: "pipe",
  });
  supervisor.stdout.on("data", (d) => (output += d));
  supervisor.stderr.on("data", (d) => (output += d));
  const get = () => fetch(base + "/api/state").then((r) => r.json()),
    logs = async () =>
      (await readFile(temp + "/logs/supervisor.jsonl", "utf8"))
        .trim()
        .split("\n")
        .map(JSON.parse);
  assert.equal((await waitFor(get)).mode, "live");
  const first = (await logs()).findLast((x) => x.event === "spawn").pid;
  assert.equal(await realpath("/proc/" + first + "/cwd"), temp);
  assert(
    (await readFile("/proc/" + first + "/cmdline", "utf8")).includes(
      temp + "/server/index.mjs",
    ),
  );
  const duplicate = spawn(process.execPath, ["scripts/supervisor.mjs"], {
    cwd: temp,
    env: { ...process.env, PORT: String(port) },
    stdio: "pipe",
  });
  const duplicateExit = await new Promise((r) => duplicate.once("exit", r));
  assert.equal(duplicateExit, 78);
  assert.equal(
    Number(await readFile(temp + "/data/supervisor.pid", "utf8")),
    supervisor.pid,
  );
  const at = Date.now();
  process.kill(first, "SIGKILL");
  const second = await waitFor(async () => {
    const pid = (await logs()).findLast((x) => x.event === "spawn")?.pid;
    return pid && pid !== first ? pid : null;
  });
  const s = await waitFor(get),
    player = s.players.find((x) => x.id === "lua"),
    restored = {
      blocks: s.blocks,
      wins: s.wins,
      likes: s.totals.likes,
      score: player.score,
      gifts: player.gifts,
      shield: s.shield,
      queued: s.construction.queued,
      grid: s.grid,
    };
  assert.equal(s.mode, "live");
  assert.deepEqual(restored, expected);
  const restartMs = Date.now() - at;
  assert.equal(await realpath("/proc/" + second + "/cwd"), temp);
  process.kill(second, "SIGKILL");
  await waitFor(() => supervisor.exitCode !== null);
  assert.equal(supervisor.exitCode, 1);
  assert.equal((await logs()).filter((x) => x.event === "spawn").length, 2);
  const report = {
    checkedAt: new Date().toISOString(),
    signal: "SIGKILL, twice, only on verified isolated server children",
    restartMs,
    restored: { ...restored, grid: undefined, gridCells: restored.grid.length },
    mode: s.mode,
    duplicateSupervisorExit: duplicateExit,
    maxRestarts: 1,
    spawnCount: 2,
    stoppedAtLimit: true,
    limit: "Does not simulate Android killing the entire Termux application",
    output,
  };
  await mkdir(root + "/output", { recursive: true });
  await writeFile(
    root + "/output/RECUPERACAO.json",
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  if (supervisor && supervisor.exitCode === null) {
    supervisor.kill("SIGTERM");
    await new Promise((r) => supervisor.once("exit", r));
  }
  await rm(temp, { recursive: true, force: true });
}
