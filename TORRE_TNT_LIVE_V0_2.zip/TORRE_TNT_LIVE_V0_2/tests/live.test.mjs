import test from "node:test";
import assert from "node:assert/strict";
import { normalize, TikTokAdapter } from "../server/live.mjs";
test("likes use individual increments and not room totals", () => {
  const e = normalize(
    {
      msgId: "9007199254740993123",
      user: { uniqueId: "ana", nickname: "Ana" },
      likeCount: 23,
      totalLikeCount: 40000,
    },
    "like",
  );
  assert.equal(e.count, 23);
  assert.equal(e.user, "ana");
  assert.equal(e.id, "9007199254740993123");
});
test("the installed SDK count/total schema preserves individual likes and room total", () => {
  const e = normalize(
    {
      common: { msgId: "sdk-like-1" },
      count: 23,
      total: "40000",
      user: { uniqueId: "ana" },
    },
    "like",
  );
  assert.equal(e.count, 23);
  assert.equal(e.roomTotal, 40000);
  assert.equal(e.id, "sdk-like-1");
  assert.equal(normalize({ total: "40020" }, "like").roomTotal, 40020);
});
test("gift streak final state is normalized conservatively", () => {
  assert.equal(
    normalize(
      { gift: { name: "Rose", id: 5655, type: 1 }, repeatEnd: 0 },
      "gift",
    ).repeatEnd,
    false,
  );
  assert.equal(
    normalize(
      { gift: { name: "Rose", id: 5655, type: 1 }, repeatEnd: 1 },
      "gift",
    ).repeatEnd,
    true,
  );
});
test("public account validation refuses links", async () => {
  const a = new TikTokAdapter(
    () => {},
    () => {},
  );
  await assert.rejects(a.connect("https://tiktok.com/@ana"), /somente/);
});
import { EventEmitter } from "node:events";
test("late old connection cannot replace a newer confirmed stream", async () => {
  const clients = [];
  class Fake extends EventEmitter {
    constructor(name) {
      super();
      this.name = name;
      clients.push(this);
    }
    timeout() {
      return this;
    }
    maxRetries() {
      return this;
    }
    connect() {
      return new Promise((r) => (this.resolve = r));
    }
    disconnect() {
      this.closed = true;
      return Promise.resolve();
    }
  }
  const a = new TikTokAdapter(
    () => {},
    () => {},
    { load: async () => ({ TikTokLiveClient: Fake }) },
  );
  const first = a.connect("primeira");
  await new Promise((r) => setTimeout(r, 0));
  const second = a.connect("segunda");
  await new Promise((r) => setTimeout(r, 0));
  clients[1].resolve("room-2");
  await second;
  clients[0].resolve("room-1");
  await first;
  await new Promise((r) => setTimeout(r, 0));
  assert.equal(a.state.username, "segunda");
  assert.equal(a.state.status, "connected");
  assert.ok(clients[0].closed);
  await a.disconnect();
});
test("normalizer preserves streak IDs, running totals and photo metadata", () => {
  const e = normalize(
    {
      common: { msgId: { low: 3, high: 1 } },
      groupId: { low: 5, high: 2 },
      repeatCount: 4,
      repeatEnd: 0,
      user: {
        uniqueId: "lua",
        avatarThumb: { urlList: ["https://p16.tiktokcdn.com/a"] },
      },
      gift: {
        id: 5655,
        type: 1,
        name: "Rose",
        image: { urlList: ["https://p16.tiktokcdn.com/gift"] },
      },
    },
    "gift",
  );
  assert.equal(e.id, "4294967299");
  assert.equal(e.streakId, "8589934597");
  assert.equal(e.isStreak, true);
  assert.equal(e.count, 4);
  assert.equal(e.avatar, "https://p16.tiktokcdn.com/a");
  assert.equal(e.giftImage, "https://p16.tiktokcdn.com/gift");
});
test("room-total-only events are not normalized as historical individual likes", () => {
  const e = normalize({ totalLikeCount: 12000 }, "like");
  assert.equal(e.count, 0);
  assert.equal(e.roomTotal, 12000);
  assert.equal(e.user, null);
});
test("the adapter forwards room totals so the engine can count later deltas", async () => {
  let client;
  const received = [];
  class Fake extends EventEmitter {
    constructor() {
      super();
      client = this;
    }
    timeout() {
      return this;
    }
    maxRetries() {
      return this;
    }
    connect() {
      return Promise.resolve("confirmed");
    }
    disconnect() {
      return Promise.resolve();
    }
  }
  const a = new TikTokAdapter(
    (e) => received.push(e),
    () => {},
    { load: async () => ({ TikTokLiveClient: Fake }) },
  );
  await a.connect("teste");
  client.emit("like", { totalLikeCount: 12000 });
  client.emit("like", { totalLikeCount: 12020 });
  client.emit("like", {});
  assert.equal(received.length, 2);
  assert.equal(received[0].count, 0);
  assert.equal(received[1].roomTotal, 12020);
  await a.disconnect();
});
