import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
test("HTTP: real/demo separation, bridge auth, backups, music, photos and origin validation", async () => {
  const dir = await mkdtemp(tmpdir() + "/torre-http-"),
    port = 35000 + Math.floor(Math.random() * 4000),
    base = `http://127.0.0.1:${port}`,
    child = spawn(process.execPath, ["server/index.mjs"], {
      cwd: import.meta.dirname + "/..",
      env: { ...process.env, PORT: String(port), TORRE_DATA_DIR: dir },
      stdio: "pipe",
    });
  let logs = "";
  child.stderr.on("data", (x) => (logs += x));
  const post = async (p, data = {}, headers = {}) => {
      const r = await fetch(base + "/api/" + p, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...headers },
        body: JSON.stringify(data),
      });
      return { status: r.status, data: await r.json() };
    },
    state = async () => await (await fetch(base + "/api/state")).json();
  try {
    let up = false;
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base)).ok) {
          up = true;
          break;
        }
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    assert.ok(up, logs);
    await post("settings", { autoBuild: false, boostIntervalMs: 80 });
    await post("demo/reset");
    await post("demo/event", { type: "like", user: "ana", count: 200 });
    const queued = await state();
    assert.equal(queued.goal, 1800);
    assert.equal(queued.geometry.columns, 18);
    assert.ok(queued.construction.queued >= 9);
    const waitBlocks = async (n) => {
      for (let i = 0; i < 100; i++) {
        const s = await state();
        if (s.blocks === n && s.construction.queued === 0) return s;
        await new Promise((r) => setTimeout(r, 40));
      }
      throw Error("Construction did not drain");
    };
    await waitBlocks(10);
    assert.equal((await state()).blocks, 10);
    const save = JSON.parse(await readFile(dir + "/demo.json", "utf8"));
    assert.equal(
      save.blocks + (save.queue || []).reduce((n, q) => n + q.remaining, 0),
      10,
    );
    assert.equal(
      (await (await fetch(base + "/api/backup")).json()).project,
      "torre-tnt-live",
    );
    const wav = await fetch(base + "/assets/bloco-a-bloco.wav");
    assert.equal(wav.status, 200);
    assert.match(wav.headers.get("content-type"), /audio/);
    assert.equal(
      Buffer.from(await wav.arrayBuffer()).toString("ascii", 0, 4),
      "RIFF",
    );
    const image = await fetch(base + "/assets/gifts/rose.webp");
    assert.equal(image.status, 200);
    assert.equal(image.headers.get("content-type"), "image/webp");
    assert.equal((await fetch(base + "/server/index.mjs")).status, 404);
    assert.equal((await post("settings", { likesPerBlock: 0 })).status, 400);
    assert.equal((await post("settings", { likesPerBlock: 10 })).status, 200);
    assert.equal((await state()).settings.likesPerBlock, 10);
    assert.equal(
      (
        await post(
          "demo/event",
          { type: "like", count: 20 },
          { Origin: "https://evil.invalid" },
        )
      ).status,
      403,
    );
    assert.equal(
      (await post("live/connect", { username: "https://tiktok.com/@ana" }))
        .status,
      400,
    );
    assert.equal((await state()).mode, "demo");
    const key = await post("bridge/token");
    assert.equal(key.data.token.length, 64);
    assert.ok(!JSON.stringify(await state()).includes(key.data.token));
    await post("mode", { mode: "live" });
    await post("settings", { autoBuild: false });
    assert.equal((await state()).blocks, 0);
    assert.equal(
      (await post("demo/event", { type: "like", count: 1000 })).status,
      409,
    );
    assert.equal((await post("demo/reset")).status, 409);
    assert.equal(
      (await post("live/event", { type: "like", count: 20 })).status,
      401,
    );
    assert.equal(
      (
        await post(
          "live/event",
          { type: "like", user: "real", count: 40 },
          { Authorization: "Bearer " + key.data.token },
        )
      ).status,
      200,
    );
    await waitBlocks(2);
    assert.equal((await state()).blocks, 2);
    assert.equal((await state()).connection.provider, "bridge");
    await post("mode", { mode: "demo" });
    assert.equal((await state()).blocks, 10);
  } finally {
    child.kill("SIGTERM");
    await new Promise((r) =>
      child.exitCode !== null ? r() : child.once("exit", r),
    );
    await rm(dir, { recursive: true, force: true });
  }
});
