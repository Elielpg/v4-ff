import test from "node:test";
import assert from "node:assert/strict";
import { TowerEngine } from "../server/engine.mjs";
import {
  COLUMNS,
  ROWS,
  CAPACITY,
  cellInOrder,
  nextGap,
  fullFloors,
  encodeGrid,
} from "../public/grid.js";
function fixture(autoBuild = false) {
  let now = 100000;
  const actions = [],
    e = new TowerEngine({ now: () => now, onAction: (a) => actions.push(a) });
  e.configure({ autoBuild });
  return {
    e,
    actions,
    step(ms = 90) {
      now += ms;
      e.tick();
    },
    time: () => now,
  };
}
test("the room has 18×100 unique cells in adjacent serpentine order", () => {
  assert.equal(COLUMNS, 18);
  assert.equal(ROWS, 100);
  assert.equal(CAPACITY, 1800);
  const order = Array.from({ length: CAPACITY }, (_, i) => cellInOrder(i));
  assert.equal(new Set(order).size, 1800);
  assert.deepEqual(
    order.slice(0, 20),
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 35, 34],
  );
  for (let i = 1; i < order.length; i++) {
    const a = order[i - 1],
      b = order[i];
    assert.equal(
      Math.abs((a % 18) - (b % 18)) +
        Math.abs(Math.floor(a / 18) - Math.floor(b / 18)),
      1,
    );
  }
});
test("a build gift queues material and each tick places exactly one block", () => {
  const f = fixture();
  f.e.ingest({ type: "gift", user: "ana", gift: "GG", count: 1 });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.queuedBlocks, 80);
  f.step(89);
  assert.equal(f.e.blocks, 0);
  f.step(1);
  assert.equal(f.e.blocks, 1);
  assert.equal(f.e.queuedBlocks, 79);
  assert.equal(f.actions.filter((a) => a.kind === "build").length, 1);
  assert.equal(f.actions.find((a) => a.kind === "build").amount, 1);
  f.step(60000);
  assert.equal(f.e.blocks, 2, "a delayed tick must never flush a whole batch");
});
test("all eighteen gaps close before the builder starts the next floor", () => {
  const f = fixture();
  f.e.queueBuild(40);
  for (let i = 0; i < 18; i++) f.step();
  assert.equal(fullFloors(f.e.cells), 1);
  assert.equal(f.e.lastPlaced.row, 0);
  assert.equal(f.e.blocks, 18);
  f.step();
  assert.equal(f.e.lastPlaced.row, 1);
  assert.equal(f.e.lastPlaced.col, 17);
  for (let i = 0; i < 17; i++) f.step();
  assert.equal(fullFloors(f.e.cells), 2);
  assert.equal(f.e.lastPlaced.col, 0);
});
test("the ceiling wins only after all 1800 cells have been placed", () => {
  const f = fixture();
  f.e.queueBuild(1801);
  for (let i = 0; i < 1799; i++) f.step();
  assert.equal(f.e.wins, 0);
  assert.equal(f.e.blocks, 1799);
  f.step();
  assert.equal(f.e.wins, 1);
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.queuedBlocks, 1);
  assert.ok(f.e.celebration);
  const builds = f.actions.filter((a) => a.kind === "build");
  assert.equal(builds.length, 1800);
  assert.equal(new Set(builds.map((a) => a.index)).size, 1800);
  assert.equal(builds.at(-1).row, 99);
  f.step(1000);
  assert.equal(f.e.blocks, 0);
  f.step(2500);
  assert.equal(f.e.blocks, 0);
  f.step(220);
  assert.equal(f.e.blocks, 1);
});
test("reaching floor 100 with holes cannot award a win", () => {
  const f = fixture();
  for (let row = 0; row < 100; row++) f.e.cells[row * 18] = 1;
  f.e.blocks = 100;
  f.e.queueBuild(1700);
  for (let i = 0; i < 1699; i++) f.step();
  assert.equal(f.e.wins, 0);
  assert.equal(f.e.blocks, 1799);
  f.step();
  assert.equal(f.e.wins, 1);
});
test("TNT creates real holes; the builder repairs the lowest gaps before climbing again", () => {
  const f = fixture();
  f.e.build(400);
  const oldNext = nextGap(f.e.cells);
  f.e.blast(7, null);
  const removed = f.actions.at(-1).removed;
  assert.equal(removed.length, 7);
  assert.ok(removed.every((i) => !f.e.cells[i]));
  assert.ok(nextGap(f.e.cells) !== oldNext);
  f.e.queueBuild(7);
  f.step(90);
  assert.equal(
    f.e.blocks,
    393,
    "blast stun prevents visual repair before impact",
  );
  f.step(1000);
  for (let i = 0; i < 6; i++) f.step();
  assert.equal(f.e.blocks, 400);
  assert.ok(removed.every((i) => f.e.cells[i]));
  assert.equal(nextGap(f.e.cells), oldNext);
});
test("automatic construction continues without paid gifts and may be paused", () => {
  const f = fixture(true);
  f.step(220);
  assert.equal(f.e.blocks, 1);
  f.step(220);
  assert.equal(f.e.blocks, 2);
  f.e.configure({ autoBuild: false });
  f.step(10000);
  assert.equal(f.e.blocks, 2);
  f.e.queueBuild(2);
  f.step();
  f.step();
  assert.equal(f.e.blocks, 4);
});
test("freeze preserves queued materials, protection, and the build clock", () => {
  const f = fixture();
  f.e.queueBuild(3);
  const due = f.e.nextBuildAt;
  let now = f.time();
  f.step(1);
  const before = f.e.queuedBlocks;
  f.e.lastTick -= 10000;
  f.e.freeze();
  assert.equal(f.e.queuedBlocks, before);
  assert.ok(f.e.nextBuildAt >= due + 10000);
});
test("queue, holes, attribution and sequence progress survive JSON save and restore", () => {
  const f = fixture();
  f.e.build(100);
  f.e.blast(4, null);
  f.e.ingest({ type: "gift", id: "gg-1", user: "ana", gift: "GG" });
  f.step(1000);
  const copy = new TowerEngine({
    now: f.time,
    saved: JSON.parse(JSON.stringify(f.e.save())),
  });
  assert.equal(copy.save().schema, 2);
  assert.equal(encodeGrid(copy.cells), encodeGrid(f.e.cells));
  assert.equal(copy.queuedBlocks, 79);
  assert.equal(copy.players.get("ana").queued, 79);
  assert.equal(
    copy.ingest({ type: "gift", id: "gg-1", user: "ana", gift: "GG" }).accepted,
    false,
  );
  assert.equal(copy.queuedBlocks, 79);
});
test("old 0.1 saves keep exact progress, trophies, ranking and follows in the new grid", () => {
  const f = fixture();
  f.e.build(63, f.e.player("ana"));
  f.e.players.get("ana").followed = true;
  const old = f.e.save();
  old.schema = 1;
  old.wins = 3;
  old.celebration = { remaining: 3000, wins: 1 };
  old.settings.goal = 100;
  delete old.grid;
  delete old.queue;
  delete old.lastPlaced;
  delete old.settings.autoBuild;
  const copy = new TowerEngine({ saved: JSON.parse(JSON.stringify(old)) });
  assert.equal(copy.settings.goal, 1800);
  assert.equal(copy.settings.autoBuild, true);
  assert.equal(copy.public().construction.last.row, 3);
  assert.equal(copy.blocks, 63);
  assert.equal(
    copy.cells.reduce((n, c) => n + c, 0),
    63,
  );
  assert.equal(copy.wins, 3);
  assert.equal(copy.celebration, null);
  assert.equal(copy.players.get("ana").score, 63);
  assert.equal(copy.players.get("ana").followed, true);
  assert.equal(copy.save().schema, 2);
});
test("repeated supply is coalesced by viewer without losing material", () => {
  const f = fixture();
  for (let i = 0; i < 10000; i++) f.e.queueBuild(1, f.e.player("ana"), "gift");
  assert.equal(f.e.queue.length, 1);
  assert.equal(f.e.queuedBlocks, 10000);
  assert.equal(f.e.players.get("ana").queued, 10000);
});
test("a growing community queue cannot starve another viewers gift", () => {
  const f = fixture();
  f.e.queueBuild(1000);
  const ana = f.e.player("ana");
  f.e.queueBuild(2, ana, "gift");
  f.step();
  assert.equal(ana.built, 0);
  f.e.queueBuild(1000);
  f.step();
  assert.equal(ana.built, 1);
  assert.equal(ana.queued, 1);
});
test("resetting the visible tower preserves paid supplies; demo reset can clear them", () => {
  const f = fixture();
  f.e.build(20);
  f.e.queueBuild(80, f.e.player("ana"));
  f.e.ingest({ type: "gift", user: "ana", gift: "TikTok Universe" });
  assert.equal(f.e.blocks, 0);
  assert.equal(f.e.queuedBlocks, 80);
  f.e.resetBoard(true);
  assert.equal(f.e.queuedBlocks, 0);
  assert.equal(f.e.players.get("ana").queued, 0);
});
test("construction timing accepts only bounded numeric settings and a boolean toggle", () => {
  const f = fixture();
  for (const data of [
    { autoBuild: "false" },
    { buildIntervalMs: 79 },
    { boostIntervalMs: 2001 },
  ])
    assert.throws(() => f.e.configure(data));
  f.e.configure({
    autoBuild: true,
    buildIntervalMs: 300,
    boostIntervalMs: 100,
  });
  assert.equal(f.e.settings.buildIntervalMs, 300);
});
