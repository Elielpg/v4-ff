import {
  COLUMNS,
  ROWS,
  CAPACITY,
  decodeGrid,
  cellInOrder,
  nextGap,
  highestRow,
} from "./grid.js";
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const ease = (x) => {
  x = clamp(x, 0, 1);
  return x * x * (3 - 2 * x);
};
const colors = {
  green: "#b3e775",
  red: "#ff846c",
  blue: "#8adaed",
  gold: "#ffda7a",
};
export class MineWorld {
  constructor(canvas, { onImpact = () => {}, onCount = () => {} } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.onImpact = onImpact;
    this.onCount = onCount;
    this.cells = new Uint8Array(CAPACITY);
    this.state = null;
    this.pending = [];
    this.particles = [];
    this.labels = [];
    this.born = new Map();
    this.quality = "balanced";
    this.overview = false;
    this.cameraOffset = 0;
    this.reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.shakeAt = -100;
    this.victoryAt = -100;
    this.lastFrame = 0;
    this.frames = 0;
    this.fps = 0;
    this.fpsAt = performance.now();
    this.lastCountAt = 0;
    this.lastTime = performance.now() / 1000;
    this.resize();
    window.addEventListener("resize", () => this.resize());
    document.fonts.ready.then(() => this.resize());
    requestAnimationFrame((t) => this.loop(t));
  }
  resize() {
    this.W = 360;
    this.H = (innerHeight / innerWidth) * this.W;
    const scale =
      this.quality === "high" ? 1.5 : this.quality === "low" ? 0.8 : 1;
    this.canvas.width = Math.round(this.W * scale);
    this.canvas.height = Math.round(this.H * scale);
    this.scale = this.canvas.width / this.W;
    this.desktop = innerWidth >= 700 && innerWidth / innerHeight >= 1.2;
    const footer = document.querySelector("footer")?.getBoundingClientRect(),
      hud = document.getElementById("hud")?.getBoundingClientRect();
    this.top = this.desktop
      ? 31
      : ((hud?.bottom || 310) / innerWidth) * this.W + 12;
    this.floor =
      (footer?.top ? (footer.top / innerWidth) * this.W : this.H - 105) - 25;
    this.available = Math.max(60, this.floor - this.top);
    this.left = this.desktop ? 162 : 20;
    this.right = 310;
    const normal = Math.min(18, (this.right - this.left) / COLUMNS);
    this.tile = this.overview
      ? Math.min(normal, this.available / (ROWS + 5))
      : normal;
    this.tx = this.overview
      ? (this.left + this.right - COLUMNS * this.tile) / 2
      : this.left;
    this.cameraOffset = clamp(this.cameraOffset, 0, this.maxCamera());
    this.mapBounds = {
      x: 325,
      y: this.top + 20,
      width: 19,
      height: Math.min(200, this.available - 25),
    };
    this.makeBackground();
  }
  maxCamera() {
    return this.overview
      ? 0
      : Math.max(0, ROWS * this.tile - this.available + this.tile * 4);
  }
  setQuality(q) {
    this.quality = q;
    this.resize();
  }
  setOverview(on) {
    this.overview = on;
    this.builderX = undefined;
    this.builderY = undefined;
    this.cameraOffset = 0;
    this.resize();
  }
  hitMap(x, y) {
    const r = this.mapBounds;
    return (
      x >= r.x - 6 &&
      x <= r.x + r.width + 6 &&
      y >= r.y - 16 &&
      y <= r.y + r.height + 15
    );
  }
  makeBackground() {
    this.bg = document.createElement("canvas");
    this.bg.width = 360;
    this.bg.height = Math.ceil(this.H);
    const c = this.bg.getContext("2d");
    c.fillStyle = "#242b35";
    c.fillRect(0, 0, 360, this.H);
    let seed = 317;
    const rnd = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    for (let y = 0; y < this.H; y += 20)
      for (let x = 0; x < 360; x += 20) {
        const k = Math.floor(rnd() * 8);
        c.fillStyle = `rgb(${36 + k},${44 + k},${55 + k})`;
        c.fillRect(x, y, 20, 20);
        c.fillStyle = "#171f2a";
        c.fillRect(x, y, 20, 1);
        c.fillRect(x, y, 1, 20);
        for (let i = 0; i < 6; i++) {
          c.fillStyle = rnd() < 0.5 ? "#b2c4b00a" : "#00000014";
          c.fillRect(
            x + 2 + Math.floor(rnd() * 16),
            y + 2 + Math.floor(rnd() * 16),
            2,
            2,
          );
        }
      }
  }
  clear() {
    this.cells.fill(0);
    this.pending = [];
    this.particles = [];
    this.labels = [];
    this.born.clear();
    this.state = null;
    this.lastIndex = null;
    this.builderX = undefined;
    this.builderY = undefined;
    this.cameraOffset = 0;
  }
  update(s) {
    const old = this.state;
    this.state = s;
    if (!this.pending.length) {
      const grid = decodeGrid(s.grid);
      if (grid) this.cells = grid;
      this.lastIndex = s.construction?.last?.index ?? null;
    }
    if (old?.celebration && !s.celebration) {
      this.cells = decodeGrid(s.grid) || new Uint8Array(CAPACITY);
      this.pending = [];
      this.born.clear();
      this.lastIndex = s.construction?.last?.index ?? null;
    } else if (!old) this.lastIndex = s.construction?.last?.index ?? null;
  }
  isCelebrating() {
    return (
      !!this.state?.celebration &&
      this.state.celebration.until > this.state.serverTime
    );
  }
  get displayCount() {
    return this.isCelebrating()
      ? CAPACITY
      : this.cells.reduce((n, c) => n + c, 0);
  }
  cell(index) {
    return {
      x: this.tx + (index % COLUMNS) * this.tile,
      y:
        this.floor -
        (Math.floor(index / COLUMNS) + 1) * this.tile +
        this.cameraOffset,
    };
  }
  topPoint() {
    return this.cell(Math.max(0, this.lastIndex ?? nextGap(this.cells)));
  }
  particle(x, y, color, kind = "dust", power = 1) {
    const max = this.quality === "low" ? 90 : 240;
    if (this.particles.length >= max) this.particles.shift();
    const a = Math.random() * Math.PI * 2,
      fast = kind === "confetti" ? 75 : 45;
    this.particles.push({
      x,
      y,
      vx: Math.cos(a) * fast * power,
      vy: -25 - Math.random() * fast * power,
      life: kind === "confetti" ? 2 : 0.6 + Math.random() * 0.5,
      age: 0,
      color,
      kind,
      size: 2 + Math.random() * 2,
    });
  }
  float(text, x, y, color) {
    if (this.labels.length >= 10) this.labels.shift();
    this.labels.push({ text, x, y, color, at: performance.now() / 1000 });
  }
  action(a) {
    const t = performance.now() / 1000;
    if (a.kind === "build" && Number.isInteger(a.index)) {
      this.cells[a.index] = 1;
      this.lastIndex = a.index;
      this.born.set(a.index, t);
      this.hammerUntil = t + 0.2;
      const row = Math.floor(a.index / COLUMNS);
      if (this.cells.slice(row * COLUMNS, (row + 1) * COLUMNS).every(Boolean)) {
        const p = this.cell(a.index);
        this.float(
          "ANDAR " + (row + 1) + " FECHADO",
          this.tx + (COLUMNS * this.tile) / 2,
          p.y - 10,
          colors.green,
        );
      }
    }
    if (a.kind === "blast") {
      const wait =
        a.kindEffect === "lightning"
          ? 0.18
          : a.kindEffect === "airstrike"
            ? 0.85
            : 0.65;
      const wave = { ...a, at: t, impact: t + wait, end: t + wait + 0.25 };
      if (this.pending.length >= 24) {
        const last = this.pending.at(-1);
        last.removed = [
          ...new Set([...(last.removed || []), ...(a.removed || [])]),
        ];
        last.damage = last.removed.length;
        last.amount += a.amount;
      } else this.pending.push(wave);
    }
    if (a.kind === "likes") {
      const to = this.topPoint(),
        max = this.quality === "low" ? 90 : 240;
      for (let i = 0; i < Math.min(8, Math.ceil(a.count / 12)); i++) {
        if (this.particles.length >= max) this.particles.shift();
        this.particles.push({
          kind: "heart",
          from: { x: 300, y: this.floor + 8 },
          to: { x: to.x + this.tile / 2, y: to.y },
          age: -i * 0.04,
          life: 0.9,
          color: colors.green,
          x: 300,
          y: this.floor,
          size: 3,
        });
      }
    }
    if (a.kind === "supply") {
      this.float(
        "FILA +" + a.amount,
        this.tx + (COLUMNS * this.tile) / 2,
        this.floor - 22,
        colors.green,
      );
    }
    if (a.kind === "shield") {
      const p = this.topPoint();
      this.float("ESCUDO +" + a.amount, p.x, p.y - 15, colors.blue);
      for (let i = 0; i < 12; i++)
        this.particle(p.x, p.y, colors.blue, "spark");
    }
    if (a.kind === "victory") {
      this.victoryAt = t;
      for (let i = 0; i < 90; i++)
        this.particle(
          this.tx + (COLUMNS * this.tile) / 2,
          this.top + this.available * 0.4,
          [colors.gold, colors.green, colors.red, colors.blue][i % 4],
          "confetti",
          1.5,
        );
    }
    if (a.kind === "round") {
      this.cells = decodeGrid(this.state?.grid) || new Uint8Array(CAPACITY);
      this.pending = [];
      this.lastIndex = null;
      this.born.clear();
    }
    if (a.kind === "reset" || a.kind === "boardReset") {
      this.cells.fill(0);
      this.pending = [];
      this.lastIndex = null;
      this.born.clear();
      this.shakeAt = t;
      this.float(
        "TORRE ZERADA",
        this.tx + (COLUMNS * this.tile) / 2,
        this.top + 35,
        colors.red,
      );
    }
  }
  rect(x, y, w, h, c) {
    this.ctx.fillStyle = c;
    this.ctx.fillRect(
      Math.round(x),
      Math.round(y),
      Math.max(1, Math.ceil(w)),
      Math.max(1, Math.ceil(h)),
    );
  }
  text(s, x, y, size, c, align = "center") {
    const q = this.ctx;
    q.font = `${size}px VT, monospace`;
    q.textAlign = align;
    q.textBaseline = "middle";
    q.lineWidth = size <= 11 ? 1 : 2;
    q.strokeStyle = "#111922";
    q.strokeText(s, Math.round(x), Math.round(y));
    q.fillStyle = c;
    q.fillText(s, Math.round(x), Math.round(y));
  }
  block(i, x, y, size, at, t) {
    const q = this.ctx;
    let dy = 0;
    if (at && t < at + 0.22) dy = -Math.max(0, 1 - ease((t - at) / 0.22)) * 18;
    const row = Math.floor(i / COLUMNS),
      palette =
        row < 8
          ? ["#727c87", "#a0a9ad", "#454e5a"]
          : row < 45
            ? ["#ad6850", "#d49772", "#6b443c"]
            : row < 80
              ? ["#5e9c86", "#93c6a0", "#345e5e"]
              : ["#c89c45", "#f4d17a", "#806a38"];
    y += dy;
    this.rect(x, y, size - 1, size - 1, palette[0]);
    this.rect(x, y, size - 1, 1, palette[1]);
    this.rect(x, y, 1, size - 1, palette[1]);
    this.rect(x, y + size - 2, size - 1, 1, palette[2]);
    const yy = y + size * 0.5;
    this.rect(x + 1, yy, size - 3, 1, palette[2]);
    this.rect(
      x + size * (row % 2 ? 0.65 : 0.35),
      y + 1,
      1,
      size * 0.48,
      palette[2],
    );
    this.rect(x + size * (row % 2 ? 0.3 : 0.7), yy, 1, size * 0.4, palette[2]);
    if (size > 9) {
      this.rect(x + 3, y + 3, 2, 1, palette[1]);
      this.rect(x + size - 5, y + size - 4, 2, 1, palette[2]);
    }
  }
  tnt(x, y, t, scale = 1) {
    const q = this.ctx;
    q.save();
    q.translate(x, y);
    q.rotate(Math.sin(t * 4) * 0.25);
    q.scale(scale, scale);
    this.rect(-6, -7, 12, 14, "#9b302f");
    this.rect(-5, -6, 10, 12, "#e45949");
    this.rect(-5, -1, 10, 5, "#f4e6c1");
    this.rect(-6, 6, 12, 2, "#712b32");
    this.rect(-3, -6, 1, 4, "#ff8a64");
    this.text("TNT", 0, 1.7, 6, "#20232a");
    this.rect(0, -10, 2, 4, "#bd9b65");
    this.rect(0, -12, 2, 2, "#ffe195");
    this.rect(Math.sin(t * 17) > 0 ? 2 : -2, -14, 2, 2, "#ff8f53");
    q.restore();
  }
  miner(
    x,
    y,
    t,
    working = false,
    celebrate = false,
    color = "#e7bd55",
    small = false,
    moving = false,
    facing = 1,
  ) {
    const q = this.ctx,
      u = small ? 0.8 : this.tile / 8;
    q.save();
    q.translate(x, y + (celebrate ? -Math.abs(Math.sin(t * 10)) * 6 : 0));
    q.scale(u * facing, u);
    const walk = moving ? Math.sin(t * 20) * 2 : 0;
    this.rect(-4 + walk, -8, 3, 8, "#304b6a");
    this.rect(1 - walk, -8, 3, 8, "#304b6a");
    this.rect(-5 + walk, -1, 5, 2, "#111e2e");
    this.rect(1 - walk, -1, 5, 2, "#111e2e");
    this.rect(-5, -17, 10, 10, "#416e8c");
    this.rect(-4, -16, 8, 3, "#85a8a2");
    this.rect(-2, -17, 4, 7, "#426184");
    this.rect(-4, -26, 8, 9, "#d49b71");
    this.rect(-5, -29, 10, 5, color);
    this.rect(-6, -26, 12, 2, color);
    this.rect(-1, -28, 2, 2, "#fff0b9");
    this.rect(1, -22, 1, 2, "#172732");
    this.rect(3, -22, 1, 2, "#172732");
    this.rect(1, -18, 3, 1, "#704d43");
    this.rect(-7, -16, 3, 7, "#d49b71");
    q.save();
    q.translate(6, -15);
    q.rotate(celebrate ? -2.1 : working ? Math.sin(t * 16) * 1.1 - 0.9 : -0.25);
    this.rect(0, 0, 3, 7, "#d49b71");
    this.rect(1, -7, 2, 10, "#805c43");
    this.rect(-2, -8, 9, 3, "#a9b7ba");
    this.rect(-2, -9, 9, 1, "#e6e6c9");
    q.restore();
    q.restore();
  }
  heart(x, y, size, color) {
    const q = this.ctx;
    q.save();
    q.translate(Math.round(x), Math.round(y));
    q.scale(size, size);
    this.rect(-2, -1, 2, 1, color);
    this.rect(1, -1, 2, 1, color);
    this.rect(-3, 0, 7, 2, color);
    this.rect(-2, 2, 5, 1, color);
    this.rect(-1, 3, 3, 1, color);
    this.rect(0, 4, 1, 1, color);
    q.restore();
  }
  loop(ms) {
    requestAnimationFrame((t) => this.loop(t));
    if (ms - this.lastFrame < (this.quality === "low" ? 32 : 15)) return;
    const t = ms / 1000,
      dt = clamp(t - this.lastTime, 0, 0.06);
    this.lastTime = t;
    this.lastFrame = ms;
    this.frames++;
    if (ms - this.fpsAt > 1500) {
      this.fps = Math.round((this.frames * 1000) / (ms - this.fpsAt));
      this.frames = 0;
      this.fpsAt = ms;
    }
    this.render(t, dt);
    if (ms - this.lastCountAt > 80) {
      this.onCount(this.displayCount);
      this.lastCountAt = ms;
    }
  }
  render(t, dt) {
    const c = this.ctx;
    c.setTransform(this.scale, 0, 0, this.scale, 0, 0);
    c.imageSmoothingEnabled = false;
    c.clearRect(0, 0, this.W, this.H);
    c.drawImage(this.bg, 0, 0);
    const completed = this.isCelebrating(),
      index = completed
        ? CAPACITY - 1
        : (this.lastIndex ?? this.state?.construction?.last?.index ?? 0);
    const row = Math.floor(index / COLUMNS),
      targetCamera = this.overview
        ? 0
        : clamp(
            (row + 1) * this.tile - this.available * 0.46,
            0,
            this.maxCamera(),
          );
    this.cameraOffset +=
      (targetCamera - this.cameraOffset) * Math.min(1, dt * 7);
    c.save();
    c.beginPath();
    c.rect(
      this.left - 7,
      this.top,
      this.right - this.left + 14,
      this.available + 5,
    );
    c.clip();
    if (!this.reduceMotion && t - this.shakeAt < 0.22 && t >= this.shakeAt)
      c.translate(Math.sin(t * 80) * 2, Math.cos(t * 70));
    const base = this.floor + this.cameraOffset,
      ceiling = base - ROWS * this.tile;
    this.rect(
      this.tx - 3,
      ceiling - 3,
      COLUMNS * this.tile + 6,
      ROWS * this.tile + 6,
      "#151e29",
    );
    for (let r = 0; r <= ROWS; r++) {
      const y = base - r * this.tile;
      if (y < this.top - 4 || y > this.floor + 4) continue;
      this.rect(
        this.tx,
        y,
        COLUMNS * this.tile,
        1,
        r % 10 === 0 ? "#63705b88" : "#71807727",
      );
      if (r > 0 && r % 10 === 0)
        this.text(String(r), this.tx + 4, y + 5, 8, "#97ad91", "left");
    }
    for (let col = 0; col <= COLUMNS; col++)
      this.rect(
        this.tx + col * this.tile,
        Math.max(this.top, ceiling),
        1,
        Math.min(this.floor, base) - Math.max(this.top, ceiling),
        "#71807720",
      );
    // Draw only visible floors. The complete 18×100 grid remains authoritative.
    let visibleCells = 0;
    for (let i = 0; i < CAPACITY; i++) {
      if (!completed && !this.cells[i]) continue;
      const p = this.cell(i);
      if (p.y + this.tile < this.top || p.y > this.floor) continue;
      this.block(i, p.x, p.y, this.tile, this.born.get(i), t);
      visibleCells++;
    }
    this.visibleCells = visibleCells;
    this.rect(this.tx - 3, ceiling - 4, 3, ROWS * this.tile + 8, "#728078");
    this.rect(
      this.tx + COLUMNS * this.tile,
      ceiling - 4,
      3,
      ROWS * this.tile + 8,
      "#728078",
    );
    this.rect(this.tx - 3, base + 1, COLUMNS * this.tile + 6, 5, "#b29a64");
    if (ceiling > this.top - 12 && ceiling < this.floor) {
      this.rect(
        this.tx - 3,
        ceiling - 5,
        COLUMNS * this.tile + 6,
        5,
        completed ? "#caed83" : "#bdcaac",
      );
      this.text(
        "TETO · ANDAR 100",
        this.tx + (COLUMNS * this.tile) / 2,
        ceiling - 14,
        14,
        colors.gold,
      );
    }
    const p = this.cell(index),
      goalX = p.x + this.tile * 0.5,
      goalY = p.y;
    if (this.builderX === undefined) {
      this.builderX = goalX;
      this.builderY = goalY;
    }
    const moving =
      Math.abs(goalX - this.builderX) > 0.3 ||
      Math.abs(goalY - this.builderY) > 1;
    if (Math.abs(goalX - this.builderX) > 0.2)
      this.facing = goalX > this.builderX ? 1 : -1;
    this.builderX += (goalX - this.builderX) * Math.min(1, dt * 18);
    this.builderY += (goalY - this.builderY) * Math.min(1, dt * 16);
    this.rect(
      this.builderX - this.tile * 0.6,
      this.builderY + 1,
      this.tile * 1.2,
      3,
      "#e3c575",
    );
    this.miner(
      this.builderX,
      this.builderY,
      t,
      this.hammerUntil > t,
      completed,
      "#e7bd55",
      false,
      moving,
      this.facing || 1,
    );
    this.builderScreen = {
      x: this.builderX,
      y: this.builderY,
      row,
      col: index % COLUMNS,
    };
    if (!completed && this.state?.construction?.next >= 0) {
      const q = this.cell(this.state.construction.next);
      c.strokeStyle = "#d2ed9888";
      c.lineWidth = 1;
      c.strokeRect(q.x + 1, q.y + 1, this.tile - 3, this.tile - 3);
    }
    if (this.state?.shield > 0) {
      c.strokeStyle = "#82d7ec";
      c.globalAlpha = this.reduceMotion ? 0.7 : 0.5 + Math.sin(t * 3) * 0.1;
      c.lineWidth = 2;
      c.strokeRect(
        this.tx - 2,
        this.top + 2,
        COLUMNS * this.tile + 4,
        this.available - 3,
      );
      c.globalAlpha = 1;
    }
    for (const wave of this.pending) {
      const a = t - wave.at,
        duration = wave.impact - wave.at,
        target = this.cell(Number.isInteger(wave.target) ? wave.target : index);
      target.x += this.tile / 2;
      target.y += this.tile / 2;
      if (t < wave.impact) {
        if (wave.kindEffect === "lightning") {
          c.strokeStyle = "#c1efff";
          c.lineWidth = 2;
          c.beginPath();
          c.moveTo(target.x, this.top);
          for (let i = 1; i <= 6; i++)
            c.lineTo(
              target.x + (i % 2 ? -7 : 7),
              this.top + ((target.y - this.top) * i) / 6,
            );
          c.stroke();
        } else {
          const count =
            wave.kindEffect === "airstrike"
              ? 6
              : Math.min(7, Math.ceil(Math.log2(wave.amount + 1)) + 1);
          for (let i = 0; i < count; i++) {
            const u = clamp(a / duration - i * 0.025, 0, 1),
              sx = this.tx + ((i + 0.5) / count) * COLUMNS * this.tile;
            this.tnt(
              sx + (target.x - sx) * ease(u),
              this.top - 12 + (target.y - this.top + 12) * u * u,
              t + i,
              0.85,
            );
          }
          this.text(
            "TNT ×" + wave.amount,
            this.tx + (COLUMNS * this.tile) / 2,
            this.top + 17,
            17,
            colors.red,
          );
        }
      } else if (!wave.done) {
        wave.done = true;
        for (const removed of wave.removed || []) this.cells[removed] = 0;
        const fragments = (wave.removed || []).slice(0, 45);
        for (const id of fragments) {
          const q = this.cell(id);
          this.particle(q.x + this.tile / 2, q.y, colors.red, "dust", 1.3);
          this.particle(q.x, q.y, colors.gold, "dust");
        }
        this.float(
          wave.damage ? "−" + wave.damage : "DEFENDIDO!",
          target.x,
          target.y - 15,
          wave.damage ? colors.red : colors.blue,
        );
        this.shakeAt = t;
        this.onImpact(
          wave.kindEffect === "lightning"
            ? "lightning"
            : wave.damage
              ? "explosion"
              : "shield",
          wave.amount,
        );
      }
    }
    const hadPending = this.pending.length;
    this.pending = this.pending.filter((w) => t < w.end);
    if (hadPending && !this.pending.length && this.state && !completed)
      this.cells = decodeGrid(this.state.grid) || this.cells;
    for (const q of this.particles) {
      q.age += dt;
      if (q.age < 0) continue;
      const life = clamp(q.age / q.life, 0, 1);
      if (q.kind === "heart") {
        const u = ease(life),
          x = q.from.x + (q.to.x - q.from.x) * u,
          y = q.from.y + (q.to.y - q.from.y) * u - Math.sin(u * Math.PI) * 30;
        c.globalAlpha = 1 - life * 0.6;
        this.heart(x, y, 1.1, q.color);
      } else {
        q.vy += dt * (q.kind === "confetti" ? 45 : 100);
        q.x += q.vx * dt;
        q.y += q.vy * dt;
        c.globalAlpha = 1 - life;
        this.rect(
          q.x,
          q.y,
          q.size,
          q.kind === "confetti" ? q.size * 0.5 : q.size,
          q.color,
        );
      }
      c.globalAlpha = 1;
    }
    this.particles = this.particles.filter((q) => q.age < q.life);
    this.labels = this.labels.filter((l) => t - l.at < 1.2);
    for (const l of this.labels) {
      const age = t - l.at;
      c.globalAlpha = 1 - age / 1.2;
      this.text(l.text, l.x, l.y - age * 15, 13, l.color);
      c.globalAlpha = 1;
    }
    if (this.cameraOffset < 30)
      for (const [i, user] of (this.state?.players || [])
        .slice(0, 4)
        .entries()) {
        const x = this.tx + 12 + i * 20;
        this.miner(
          x,
          this.floor + this.cameraOffset - 2,
          t,
          false,
          false,
          ["#9dd17a", "#c39bde", "#d99c6c", "#8fcbd4"][i],
          true,
          false,
          1,
        );
      }
    c.restore();
    const map = this.mapBounds;
    c.fillStyle = "#0c1723ed";
    c.fillRect(map.x - 5, map.y - 12, map.width + 10, map.height + 28);
    this.text("100", map.x + map.width / 2, map.y - 7, 9, colors.gold);
    const h = map.height / ROWS,
      w = map.width / COLUMNS;
    for (let r = 0; r < ROWS; r++)
      for (let col = 0; col < COLUMNS; col++) {
        const id = r * COLUMNS + col;
        this.rect(
          map.x + col * w,
          map.y + (ROWS - 1 - r) * h,
          w,
          h,
          completed || this.cells[id]
            ? r >= 80
              ? "#d5b35d"
              : "#a9cb77"
            : "#263540",
        );
      }
    const viewTop = clamp(
        (this.floor + this.cameraOffset - this.top) / this.tile,
        0,
        ROWS,
      ),
      viewBottom = clamp(this.cameraOffset / this.tile, 0, ROWS);
    c.strokeStyle = "#9bdff0";
    c.lineWidth = 1;
    c.strokeRect(
      map.x - 2,
      map.y + (ROWS - viewTop) * h,
      map.width + 4,
      Math.max(3, (viewTop - viewBottom) * h),
    );
    this.rect(
      map.x - 2,
      map.y + (ROWS - 1 - row) * h,
      map.width + 4,
      2,
      colors.red,
    );
    this.text(
      "BASE",
      map.x + map.width / 2,
      map.y + map.height + 8,
      8,
      "#a8bbb5",
    );
  }
  metrics() {
    return {
      fps: this.fps,
      visualBlocks: this.displayCount,
      pending: this.pending.length,
      particles: this.particles.length,
      profile: this.quality,
      overview: this.overview,
      columns: COLUMNS,
      rows: ROWS,
      capacity: CAPACITY,
      visibleCells: this.visibleCells || 0,
      cameraOffset: this.cameraOffset,
      builder: this.builderScreen,
      tile: this.tile,
      canvasWidth: this.canvas.width,
      canvasHeight: this.canvas.height,
      towerBounds: {
        left: this.tx,
        right: this.tx + COLUMNS * this.tile,
        top: this.floor - ROWS * this.tile + this.cameraOffset,
        bottom: this.floor + this.cameraOffset,
      },
      worldTop: this.top,
      worldFloor: this.floor,
      worldHeight: this.H,
      map: this.mapBounds,
    };
  }
}
