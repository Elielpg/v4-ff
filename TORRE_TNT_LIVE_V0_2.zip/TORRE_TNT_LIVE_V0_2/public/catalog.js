export const VERSION = "0.2.0";
export const DEFAULTS = {
  goal: 1800,
  columns: 18,
  rows: 100,
  autoBuild: true,
  buildIntervalMs: 220,
  boostIntervalMs: 90,
  winGoal: 10,
  likesPerBlock: 20,
  chatCooldown: 6000,
  chatTntCooldown: 12000,
  shieldSeconds: 30,
  maxShield: 60,
};
export const GIFTS = [
  {
    id: "tiktok",
    name: "TikTok",
    aliases: ["tiktok", "tik tok"],
    icon: "tiktok",
    effect: "build",
    amount: 20,
    label: "+20 BLOCOS",
    tone: "green",
  },
  {
    id: "rose",
    name: "Rosa",
    aliases: ["rosa", "rose"],
    ids: ["5655"],
    icon: "rose",
    effect: "tnt",
    amount: 10,
    label: "TNT ×10",
    tone: "red",
  },
  {
    id: "finger",
    name: "Finger Heart",
    aliases: [
      "finger heart",
      "fingerheart",
      "coração de dedo",
      "coracao de dedo",
    ],
    icon: "finger_heart",
    effect: "tnt",
    amount: 60,
    label: "TNT ×60",
    tone: "red",
  },
  {
    id: "perfume",
    name: "Perfume",
    aliases: ["perfume"],
    icon: "perfume",
    effect: "airstrike",
    amount: 30,
    label: "6 BOMBAS",
    detail: "6 bombas · até 30 blocos",
    tone: "blue",
  },
  {
    id: "gg",
    name: "GG",
    aliases: ["gg"],
    icon: "gg",
    effect: "build",
    amount: 80,
    label: "+80 BLOCOS",
    tone: "green",
  },
  {
    id: "doughnut",
    name: "Doughnut",
    aliases: ["doughnut", "donut", "rosquinha", "doughnut party"],
    icon: "doughnut",
    effect: "lightning",
    amount: 20,
    label: "RAIO −20",
    tone: "yellow",
  },
  {
    id: "hands",
    name: "Hand Hearts",
    aliases: [
      "hand hearts",
      "hand heart",
      "coração com as mãos",
      "coracao com as maos",
    ],
    icon: "hand_heart",
    effect: "fill",
    amount: 1,
    label: "ATÉ O TETO",
    tone: "pink",
  },
  {
    id: "galaxy",
    name: "Galáxia",
    aliases: ["galaxy", "galaxia", "galáxia"],
    icon: "galaxy",
    effect: "shield",
    amount: 40,
    label: "ESCUDO +40",
    detail: "Proteção por 30s",
    tone: "purple",
  },
  {
    id: "lightning",
    name: "Lightning Bolt",
    aliases: ["lightning bolt", "relampago", "relâmpago"],
    icon: "lightning_bolt",
    effect: "lightning",
    amount: 40,
    label: "RAIO −40",
    tone: "yellow",
  },
  {
    id: "universe",
    name: "TikTok Universe",
    aliases: ["tiktok universe", "universo tiktok"],
    icon: "tiktok_universe",
    effect: "reset",
    amount: 1,
    label: "RESET DA TORRE",
    tone: "purple",
  },
];
export const EFFECTS = [
  "build",
  "tnt",
  "airstrike",
  "lightning",
  "fill",
  "shield",
  "reset",
];
export const normalizeText = (v) =>
  String(v ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
export function giftRule(event, custom = {}) {
  const id = String(event.giftId ?? ""),
    name = normalizeText(event.gift);
  let rule =
    (Object.hasOwn(custom, id) ? custom[id] : null) ||
    (Object.hasOwn(custom, name) ? custom[name] : null);
  if (rule) {
    const base = GIFTS.find((g) => g.id === rule.id);
    return base ? { ...base, ...rule } : rule;
  }
  return (
    GIFTS.find(
      (g) =>
        g.ids?.includes(id) || g.aliases.some((a) => normalizeText(a) === name),
    ) || null
  );
}
