import { MineWorld } from "./mine.js";
import { GameAudio } from "./audio.js";
import { GIFTS, VERSION } from "./catalog.js";
const $ = (id) => document.getElementById(id);
let state = null,
  lastMode = null,
  cursor = 0,
  toastTimer,
  page = 0,
  slidesPaused = false,
  alertTimer,
  activityTimer;
const notices = [];
let showingGift = false;
const audio = new GameAudio($("music"));
const world = new MineWorld($("game"), {
  onImpact: (kind, n) => audio.sfx(kind, n),
  onCount: (n) => {
    if (!state) return;
    $("block-count").textContent = n.toLocaleString("pt-BR");
    $("percent").textContent = Math.floor((n / state.goal) * 100) + "%";
    $("progress").style.width = (n / state.goal) * 100 + "%";
  },
});
const api = async (path, data = {}) => {
  const r = await fetch("/api/" + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }),
    j = await r.json();
  if (!r.ok) throw Error(j.error || "Comando recusado");
  return j;
};
function toast(text) {
  $("toast").textContent = text;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($("toast").textContent = ""), 4500);
}
function activity(text) {
  $("activity").textContent = text;
  clearTimeout(activityTimer);
  activityTimer = setTimeout(() => {
    if (state)
      $("activity").textContent = state.celebration
        ? `Próxima torre: ${state.blocks}/${state.goal} · interações preservadas`
        : "Preencha 18 × 100 espaços. Proteja a construção da TNT.";
  }, 4200);
}
function setMode(mode) {
  if (lastMode === mode) return;
  lastMode = mode;
  cursor = 0;
  world.clear();
  notices.length = 0;
  showingGift = false;
  clearTimeout(alertTimer);
  $("gift-alert").classList.add("hidden");
}
function imageFor(e) {
  return e.image || "/assets/gifts/" + (e.icon || "heart_me") + ".webp";
}
function giftAlert(e) {
  if (notices.length >= 8) notices.shift();
  notices.push(e);
  nextGift();
}
function positionGiftAlert() {
  const r = $("gift-cards").getBoundingClientRect();
  Object.assign($("gift-alert").style, {
    left: r.left + "px",
    top: r.top + "px",
    width: r.width + "px",
    height: r.height + "px",
    transform: "none",
  });
}
window.addEventListener("resize", () => {
  if (showingGift) positionGiftAlert();
});
function nextGift() {
  if (showingGift || !notices.length) return;
  showingGift = true;
  positionGiftAlert();
  const e = notices.shift();
  $("gift-alert-image").src = imageFor(e);
  $("gift-alert-image").onerror = () => {
    $("gift-alert-image").onerror = null;
    $("gift-alert-image").src =
      "/assets/gifts/" + (e.icon || "heart_me") + ".webp";
  };
  $("gift-alert-user").textContent = "@" + e.name;
  $("gift-alert-name").textContent = e.gift;
  $("gift-alert-count").textContent = "×" + e.count;
  const label = {
    build: "BLOCOS NA FILA",
    tnt: "TNT NA TORRE",
    airstrike: "BOMBARDEIO",
    lightning: "RAIO NA TORRE",
    fill: "MATERIAIS ATÉ O TETO",
    shield: "ESCUDO ATIVADO",
    reset: "RESET DA TORRE",
  };
  $("gift-alert-power").textContent = label[e.effect] || "BÔNUS DE ESCUDO";
  $("gift-alert").classList.remove("hidden", "enter");
  void $("gift-alert").offsetWidth;
  $("gift-alert").classList.add("enter");
  alertTimer = setTimeout(() => {
    $("gift-alert").classList.add("hidden");
    showingGift = false;
    nextGift();
  }, 2100);
}
function action(a) {
  if (a.mode) setMode(a.mode);
  if (a.id <= cursor) return;
  cursor = a.id;
  world.action(a);
  if (a.kind === "welcome") {
    audio.sfx("join");
    activity("@" + a.name + " entrou para a equipe!");
  }
  if (a.kind === "build") {
    audio.sfx("build", a.amount);
    if (a.source === "chat") activity("@" + a.name + " colocou um bloco!");
  }
  if (a.kind === "supply")
    activity("@" + a.name + " colocou " + a.amount + " bloco(s) na fila");
  if (a.kind === "blast")
    audio.sfx(a.kindEffect === "lightning" ? "lightning" : "fuse");
  if (a.kind === "shield") audio.sfx("shield");
  if (a.kind === "follow") {
    audio.sfx("follow");
    activity("@" + a.name + " seguiu! +5 blocos para a torre");
  }
  if (a.kind === "gift") {
    giftAlert(a);
    activity("@" + a.name + " enviou " + a.gift + " ×" + a.count);
  }
  if (a.kind === "victory") {
    audio.sfx("win");
    activity("TORRE CONCLUÍDA! +" + a.won + " vitória(s)");
  }
  if (
    a.kind === "chat" &&
    !["bloco", "defesa", "tnt"].includes(a.text.toLowerCase())
  )
    activity("@" + a.name + ": " + a.text);
}
function render(s) {
  setMode(s.mode);
  state = s;
  world.update(s);
  if (!cursor) cursor = s.lastAction;
  $("wins").replaceChildren(
    document.createTextNode(String(s.wins)),
    Object.assign(document.createElement("em"), { textContent: "/10" }),
  );
  $("mode").textContent =
    s.mode === "demo"
      ? "DEMONSTRAÇÃO LOCAL"
      : s.connection.status === "connected"
        ? "LIVE · CONECTADA"
        : "LIVE · SEM CONEXÃO";
  $("connection").textContent =
    s.mode === "demo"
      ? "EVENTOS DE TESTE"
      : s.connection.status === "connected"
        ? "● " + s.connection.events + " EVENTOS"
        : s.connection.status === "connecting"
          ? "CONECTANDO…"
          : "DESCONECTADO";
  $("live-detail").textContent = s.connection.message || "LIVE não conectada";
  $("likes").textContent = s.totals.likes.toLocaleString("pt-BR");
  $("like-meter").textContent =
    s.likeCarry + "/" + s.settings.likesPerBlock + " PARA +1";
  $("viewers").textContent = s.totalPlayers + " NA EQUIPE";
  $("goal-count").textContent = "/" + s.goal.toLocaleString("pt-BR");
  $("floor-count").textContent = s.celebration
    ? 100
    : s.construction.fullFloors;
  $("queue-count").textContent = s.construction.queued.toLocaleString("pt-BR");
  $("builder-status").textContent = s.celebration
    ? "TETO ALCANÇADO!"
    : s.construction.stunnedUntil > s.serverTime
      ? "REPARANDO A TNT"
      : s.construction.queued
        ? "BÔNUS ATIVO"
        : s.settings.autoBuild
          ? "CONSTRUINDO"
          : "AGUARDANDO";
  for (const [id, key] of [
    ["build-interval", "buildIntervalMs"],
    ["boost-interval", "boostIntervalMs"],
  ])
    if (document.activeElement !== $(id)) $(id).value = s.settings[key];
  if (document.activeElement !== $("auto-build"))
    $("auto-build").checked = s.settings.autoBuild;
  const hints = [
    s.settings.likesPerBlock + " TAP TAP = +1 BLOCO",
    "COMENTE BLOCO PARA AJUDAR",
    "DEFESA PROTEGE · TNT DESAFIA",
    "SIGA = +5 BLOCOS · COMPARTILHE = +3",
  ];
  $("tip").textContent = hints[Math.floor(s.serverTime / 6500) % hints.length];
  $("shield").classList.toggle("hidden", s.shield <= 0);
  $("shield-count").textContent = s.shield;
  $("shield-time").textContent =
    Math.max(0, Math.ceil((s.shieldUntil - s.serverTime) / 1000)) + "s";
  $("win-banner").classList.toggle("hidden", !s.celebration);
  if (s.celebration)
    $("win-detail").textContent =
      `+${s.celebration.wins} vitória(s) · próxima torre: ${s.blocks}/${s.goal}`;
  $("ranking").replaceChildren(
    ...s.ranking
      .slice(0, 5)
      .filter((p) => p.score > 0)
      .map((p, i) => {
        const li = document.createElement("li"),
          span = document.createElement("span"),
          b = document.createElement("b");
        span.textContent = i + 1 + ". " + p.name;
        b.textContent = p.score + " pts";
        li.append(span, b);
        return li;
      }),
  );
  $("rank-empty").classList.toggle(
    "hidden",
    s.ranking.some((p) => p.score > 0),
  );
  document
    .querySelectorAll(
      "[data-event],[data-chat],[data-gift],#demo-reset,#chat-send,#quick-gift",
    )
    .forEach((b) => (b.disabled = s.mode !== "demo"));
  $("demo-start").textContent =
    s.mode === "demo" ? "▶︎ TESTAR O JOGO" : "☰ COMANDOS DA LIVE";
  $("demo-stop").disabled = s.mode !== "demo";
  $("demo-auto").disabled = s.mode !== "demo";
  $("save-status").textContent = s.storageError
    ? "Não foi possível salvar: " + s.storageError
    : "Progresso salvo automaticamente no servidor.";
  if (document.activeElement !== $("likes-per-block"))
    $("likes-per-block").value = s.settings.likesPerBlock;
}
const events = new EventSource("/api/events");
events.addEventListener("state", (e) => render(JSON.parse(e.data)));
events.addEventListener("action", (e) => action(JSON.parse(e.data)));
events.onerror = () => {
  $("connection").textContent = "RECONECTANDO…";
};
const showMenu = () => {
  $("drawer").classList.remove("hidden");
};
$("menu").onclick = showMenu;
$("close").onclick = () => $("drawer").classList.add("hidden");
async function unlock() {
  try {
    await audio.unlock();
    $("sound").classList.add("green");
    return true;
  } catch (e) {
    toast("Toque em ♫ para liberar a música. " + e.message);
    return false;
  }
}
$("sound").onclick = () =>
  unlock().then((ok) => {
    if (ok) {
      audio.sfx("join");
      toast("Som ligado · música e efeitos liberados.");
    }
  });
$("sound-test").onclick = $("sound").onclick;
$("demo-start").onclick = () => {
  if (state?.mode === "live") {
    showMenu();
    return;
  }
  const sound = unlock();
  api("demo/start")
    .then(() => {
      activity("DEMO: construa com TAP TAP e teste os presentes.");
    })
    .catch((e) => toast(e.message));
};
$("demo-auto").onclick = () => {
  unlock();
  api("demo/start").catch((e) => toast(e.message));
};
$("demo-stop").onclick = () =>
  api("demo/stop")
    .then(() => toast("Teste automático pausado. Você pode usar os botões."))
    .catch((e) => toast(e.message));
const user = () => $("test-user").value.replace(/^@/, "").trim() || "demo_lua";
async function testEvent(data) {
  unlock();
  try {
    const j = await api("demo/event", {
      id: crypto.randomUUID(),
      user: user(),
      name: user().replace(/^demo_/, ""),
      ...data,
    });
    if (!j.accepted && !j.limited) toast(j.reason || "Evento não aplicado.");
  } catch (e) {
    toast(e.message);
  }
}
function gift(name) {
  return testEvent({ type: "gift", gift: name, count: 1, repeatEnd: true });
}
document.querySelectorAll("[data-event]").forEach(
  (b) =>
    (b.onclick = () =>
      testEvent({
        type: b.dataset.event,
        count: b.dataset.event === "like" ? 100 : 1,
      })),
);
document
  .querySelectorAll("[data-chat]")
  .forEach(
    (b) =>
      (b.onclick = () => testEvent({ type: "comment", text: b.dataset.chat })),
  );
$("chat-send").onclick = () =>
  testEvent({ type: "comment", text: $("chat-text").value });
$("quick-gift").onclick = () => gift("Rosa");
$("demo-reset").onclick = () =>
  api("demo/reset").catch((e) => toast(e.message));
$("view-toggle").onclick = () => {
  world.setOverview(!world.overview);
  $("view-toggle").textContent = world.overview ? "↕ SEGUIR" : "↕ MAPA";
};
$("game").addEventListener("pointerdown", (event) => {
  if (
    world.hitMap(
      (event.clientX / innerWidth) * 360,
      (event.clientY / innerWidth) * 360,
    )
  ) {
    $("view-toggle").click();
    return;
  }
  if (state?.mode === "demo") testEvent({ type: "like", count: 20 });
});
$("connect").onclick = () => {
  unlock();
  api("live/connect", { username: $("username").value }).catch((e) =>
    toast(e.message),
  );
};
$("disconnect").onclick = () =>
  api("live/disconnect").catch((e) => toast(e.message));
$("switch-demo").onclick = () =>
  api("mode", { mode: "demo" })
    .then(() => toast("Demonstração selecionada. Progresso LIVE preservado."))
    .catch((e) => toast(e.message));
$("sfx-enabled").onchange = (e) => (audio.sfxEnabled = e.target.checked);
$("music-enabled").onchange = (e) => {
  audio
    .toggleMusic(e.target.checked)
    .catch(() => toast("Toque em Ligar som para retomar a música."));
};
$("music-volume").oninput = (e) =>
  audio.setMusicVolume(Number(e.target.value) / 100);
$("sfx-volume").oninput = (e) =>
  (audio.effectsVolume = Number(e.target.value) / 100);
$("music-file").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  unlock();
  audio
    .load(f)
    .then(() => {
      $("music-name").textContent = f.name;
    })
    .catch((err) => toast(err.message));
};
$("save-builder").onclick = () =>
  api("settings", {
    autoBuild: $("auto-build").checked,
    buildIntervalMs: Number($("build-interval").value),
    boostIntervalMs: Number($("boost-interval").value),
  })
    .then(() => toast("Construtor atualizado."))
    .catch((e) => toast(e.message));
$("save-likes").onclick = () =>
  api("settings", { likesPerBlock: Number($("likes-per-block").value) })
    .then(() => toast("Regra de curtidas salva neste modo."))
    .catch((e) => toast(e.message));
$("save-gifts").onclick = () => {
  try {
    const giftMap = JSON.parse($("gift-map").value || "{}");
    api("settings", { giftMap })
      .then(() => toast("Mapa de presentes salvo."))
      .catch((e) => toast(e.message));
  } catch {
    toast("Confira o JSON do mapa de presentes.");
  }
};
$("quality").onchange = (e) => world.setQuality(e.target.value);
$("reduce-motion").checked = world.reduceMotion;
$("reduce-motion").onchange = (e) => (world.reduceMotion = e.target.checked);
$("rank-toggle").onclick = () => $("ranking-box").classList.toggle("hidden");
$("fullscreen").onclick = () =>
  document.fullscreenElement
    ? document.exitFullscreen?.()
    : document.documentElement.requestFullscreen?.().catch(() => {});
$("export-save").onclick = async () => {
  const r = await fetch("/api/backup"),
    j = await r.json();
  if (!r.ok) return toast(j.error);
  const a = document.createElement("a"),
    blob = URL.createObjectURL(
      new Blob([JSON.stringify(j, null, 2)], { type: "application/json" }),
    );
  a.href = blob;
  a.download = "torre-tnt-" + state.mode + "-backup.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(blob), 1000);
};
$("bridge-token").onclick = () =>
  api("bridge/token")
    .then((j) => {
      $("bridge-value").value = j.token;
      $("bridge-value").type = "text";
    })
    .catch((e) => toast(e.message));
function slides() {
  const items = Array.from(
    { length: 4 },
    (_, i) => GIFTS[(page * 4 + i) % GIFTS.length],
  );
  $("gift-cards").replaceChildren(
    ...items.map((g) => {
      const div = document.createElement("div");
      div.className = "gift-card";
      div.style.setProperty(
        "--accent",
        {
          green: "#b2e77d",
          red: "#ff8d79",
          yellow: "#f4d377",
          blue: "#8ed8ed",
          purple: "#cea1f3",
          pink: "#f4acc8",
        }[g.tone],
      );
      const img = document.createElement("img");
      img.src = "/assets/gifts/" + g.icon + ".webp";
      img.alt = g.name;
      const b = document.createElement("strong"),
        small = document.createElement("small");
      b.textContent = g.label;
      small.textContent = g.name;
      div.title = g.detail || g.label;
      div.append(img, b, small);
      div.onclick = () => {
        if (state?.mode === "demo") gift(g.name);
      };
      return div;
    }),
  );
  $("page").textContent = page + 1 + "/" + Math.ceil(GIFTS.length / 4);
}
$("gift-prev").onclick = () => {
  page = (page + 2) % 3;
  slides();
};
$("gift-next").onclick = () => {
  page = (page + 1) % 3;
  slides();
};
$("gift-pause").onclick = () => {
  slidesPaused = !slidesPaused;
  $("gift-pause").textContent = slidesPaused ? "▶" : "Ⅱ";
};
setInterval(() => {
  if (!slidesPaused && document.visibilityState === "visible") {
    page = (page + 1) % 3;
    slides();
  }
}, 6000);
slides();
for (const g of GIFTS) {
  const b = document.createElement("button");
  b.dataset.gift = g.name;
  const img = document.createElement("img");
  img.src = "/assets/gifts/" + g.icon + ".webp";
  img.alt = "";
  const span = document.createElement("span");
  span.textContent = g.name + " · " + g.label;
  b.append(img, span);
  b.onclick = () => gift(g.name);
  $("gift-tests").append(b);
}
setInterval(() => {
  const m = world.metrics();
  $("performance").textContent =
    `${m.fps} FPS · ${m.visibleCells} blocos visíveis · ${m.profile} · 18 × 100`;
}, 1500);
window.TORRE = {
  world,
  audio,
  api,
  get state() {
    return state;
  },
  version: VERSION,
};
