export class GameAudio {
  constructor(element) {
    this.music = element;
    this.enabled = false;
    this.sfxEnabled = true;
    this.musicEnabled = true;
    this.musicVolume = 0.18;
    this.effectsVolume = 0.55;
    this.last = new Map();
    this.active = 0;
    this.blob = null;
  }
  async unlock() {
    const A = window.AudioContext || window.webkitAudioContext;
    if (!this.ctx) {
      this.ctx = new A();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.7;
      this.limiter = this.ctx.createDynamicsCompressor();
      this.limiter.threshold.value = -12;
      this.limiter.knee.value = 16;
      this.limiter.ratio.value = 5;
      this.master.connect(this.limiter);
      this.limiter.connect(this.ctx.destination);
      this.noise = this.ctx.createBuffer(
        1,
        this.ctx.sampleRate,
        this.ctx.sampleRate,
      );
      const b = this.noise.getChannelData(0);
      for (let i = 0; i < b.length; i++) b[i] = Math.random() * 2 - 1;
    }
    const resume = this.ctx.resume();
    this.enabled = true;
    this.music.volume = this.musicVolume;
    const play = this.musicEnabled ? this.music.play() : Promise.resolve();
    await Promise.all([resume, play]);
    return true;
  }
  tone(
    freq,
    duration = 0.12,
    type = "square",
    volume = 0.2,
    finish = freq * 0.6,
  ) {
    if (!this.enabled || this.ctx?.state !== "running" || this.active >= 14)
      return;
    const now = this.ctx.currentTime,
      o = this.ctx.createOscillator(),
      g = this.ctx.createGain();
    this.active++;
    o.type = type;
    o.frequency.setValueAtTime(freq, now);
    o.frequency.exponentialRampToValueAtTime(
      Math.max(25, finish),
      now + duration,
    );
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(volume * this.effectsVolume, now + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    o.connect(g);
    g.connect(this.master);
    o.start(now);
    o.stop(now + duration + 0.02);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
      this.active--;
    };
  }
  hiss(duration = 0.25, volume = 0.3, filter = 1000) {
    if (!this.enabled || this.ctx?.state !== "running" || this.active >= 14)
      return;
    const source = this.ctx.createBufferSource(),
      f = this.ctx.createBiquadFilter(),
      g = this.ctx.createGain(),
      now = this.ctx.currentTime;
    this.active++;
    source.buffer = this.noise;
    f.type = "lowpass";
    f.frequency.value = filter;
    g.gain.setValueAtTime(volume * this.effectsVolume, now);
    g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    source.connect(f);
    f.connect(g);
    g.connect(this.master);
    source.start();
    source.stop(now + duration);
    source.onended = () => {
      source.disconnect();
      f.disconnect();
      g.disconnect();
      this.active--;
    };
  }
  sfx(kind, amount = 1) {
    if (!this.sfxEnabled) return;
    const now = performance.now();
    if (now - (this.last.get(kind) || -1e9) < (kind === "build" ? 65 : 100))
      return;
    this.last.set(kind, now);
    if (kind === "build") {
      this.tone(260, 0.075, "triangle", 0.35, 140);
      this.hiss(0.045, 0.13, 1600);
    }
    if (kind === "fuse") this.hiss(0.25, 0.09, 3500);
    if (kind === "explosion") {
      this.hiss(0.45, 0.35, 1700);
      this.tone(85, 0.4, "sine", 0.65, 28);
    }
    if (kind === "lightning") {
      this.hiss(0.25, 0.22, 6500);
      this.tone(1350, 0.13, "sawtooth", 0.16, 75);
    }
    if (kind === "shield") {
      this.tone(660, 0.23, "triangle", 0.22, 990);
      setTimeout(() => this.tone(990, 0.25, "sine", 0.18, 1320), 80);
    }
    if (kind === "join") {
      this.tone(620, 0.13, "triangle", 0.19, 920);
    }
    if (kind === "follow") {
      this.tone(440, 0.14, "square", 0.13, 660);
      setTimeout(() => this.tone(880, 0.18, "triangle", 0.2, 880), 90);
    }
    if (kind === "win") {
      for (let i = 0; i < 5; i++)
        setTimeout(
          () =>
            this.tone(
              [523, 659, 784, 1046, 1318][i],
              0.3,
              "triangle",
              0.21,
              [523, 659, 784, 1046, 1318][i],
            ),
          i * 95,
        );
    }
  }
  toggleMusic(on) {
    this.musicEnabled = on;
    if (on && this.enabled) return this.music.play();
    this.music.pause();
    return Promise.resolve();
  }
  setMusicVolume(v) {
    this.musicVolume = v;
    this.music.volume = v;
  }
  load(file) {
    if (this.blob) URL.revokeObjectURL(this.blob);
    this.blob = URL.createObjectURL(file);
    this.music.src = this.blob;
    return this.enabled && this.musicEnabled
      ? this.music.play()
      : Promise.resolve();
  }
}
