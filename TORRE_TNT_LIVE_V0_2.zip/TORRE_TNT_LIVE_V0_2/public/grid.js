export const COLUMNS = 18;
export const ROWS = 100;
export const CAPACITY = COLUMNS * ROWS;

// Alternate direction on each floor so the builder never jumps across the room.
export function cellInOrder(step) {
  const row = Math.floor(step / COLUMNS),
    x = step % COLUMNS;
  return row * COLUMNS + (row % 2 ? COLUMNS - 1 - x : x);
}
export function nextGap(cells) {
  for (let step = 0; step < CAPACITY; step++) {
    const index = cellInOrder(step);
    if (!cells[index]) return index;
  }
  return -1;
}
export function highestRow(cells) {
  for (let i = CAPACITY - 1; i >= 0; i--)
    if (cells[i]) return Math.floor(i / COLUMNS) + 1;
  return 0;
}
export function fullFloors(cells) {
  let floors = 0;
  for (let row = 0; row < ROWS; row++) {
    let full = true;
    for (let col = 0; col < COLUMNS; col++)
      if (!cells[row * COLUMNS + col]) {
        full = false;
        break;
      }
    if (!full) break;
    floors++;
  }
  return floors;
}
export const encodeGrid = (cells) => Array.from(cells).join("");
export function decodeGrid(value) {
  return typeof value === "string" &&
    value.length === CAPACITY &&
    /^[01]+$/.test(value)
    ? Uint8Array.from(value, (c) => Number(c))
    : null;
}
