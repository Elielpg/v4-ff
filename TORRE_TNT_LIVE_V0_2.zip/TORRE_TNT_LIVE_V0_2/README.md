# Torre TNT · LIVE — 0.2.0

Um construtor percorre 18 colunas e sobe 100 andares, colocando os 1.800 blocos um por um. O chat ajuda a construir ou tenta abrir buracos com explosões. Cada torre completa rende uma vitória; a meta da sessão é 10. Há trilha original, sons de construção e explosão, fotos de presentes, ranking e demonstração local.

## Instalar no Termux

Baixe `TORRE_TNT_LIVE_V0_2.zip` para Downloads. Se ainda não liberou o armazenamento do Termux, execute `termux-setup-storage` e conceda a permissão no Android.

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/TORRE_TNT_LIVE_V0_2.zip . &&
cd ~/TORRE_TNT_LIVE_V0_2 &&
bash install.sh &&
bash start.sh
```

Requer Node.js 22.19 ou mais recente e Python apenas para extrair esse ZIP. Se `python3` não existir: `pkg install python`. O instalador usa `npm ci` para baixar o conector de LIVE. Não exige modelos de IA, chave, compilador, GPU ou assinatura de serviço. Abra **http://127.0.0.1:3300** no Chrome e toque em **TESTAR O JOGO** para iniciar a demonstração com som.

Nas próximas vezes:

```bash
cd ~/TORRE_TNT_LIVE_V0_2 && bash start.sh
```

Para encerrar, use Ctrl+C na sessão original ou `bash stop.sh` nessa pasta. Este jogo usa sua própria pasta e porta; não altera Ben 10, Pulso Arena ou Jujutsu.

## Jogar e conectar

- **20 curtidas = +1 bloco na fila rápida**, com quantidade ajustável nos controles.
- O construtor também trabalha automaticamente, termina cada fileira e repara os buracos da TNT antes de subir. A câmera acompanha e o botão MAPA mostra a área inteira.
- Comentar **BLOCO** constrói; **DEFESA** protege; **TNT** provoca uma pequena explosão. Os comandos são gratuitos e têm intervalo por usuário.
- Seguir fornece **+5 blocos na fila** uma vez por espectador reconhecido. Compartilhar fornece **+3 blocos na fila e +2 de escudo**, com intervalo de 20 segundos.
- Rosa e alguns presentes desafiam a construção; outros constroem, completam ou protegem a torre. As fotos e efeitos passam em slides.
- A vitória só ocorre com **todos os 1.800 espaços preenchidos**. Materiais excedentes e novas interações aguardam na fila para a próxima torre.

Em ☰, digite o **@ da conta que já está ao vivo** e toque em **Conectar LIVE**. A tarja indica se o WebSocket foi confirmado; não mostra conexão falsa. O conector é comunitário e depende do acesso público que o TikTok disponibiliza. A conta e os eventos reais precisam ser validados no seu celular.

Na LIVE, toques na página e botões de teste não geram curtidas ou presentes. A demonstração tem progresso separado. Depois de instalar, a DEMO, as imagens e a trilha funcionam sem internet.

## Música, desempenho e progresso

Toque em **♫** para liberar áudio. Em ☰ você pode ajustar volumes, desligar a trilha ou escolher um arquivo de música do celular. A trilha incluída é original. A transmissão precisa capturar o áudio do navegador; este jogo não configura a captura do aplicativo de LIVE.

O visual pixelado é intencional. Há perfis Leve, Equilibrado e Detalhado, além de redução de movimento. Os números de FPS do painel são medidos no navegador que está aberto, não uma promessa de desempenho no Realme GT3.

O servidor salva automaticamente em `data/`, com cópia `.bak`. O supervisor tenta recuperar o servidor até 4 vezes em 15 minutos e registra as saídas; não consegue permanecer ativo se o Android encerrar o aplicativo Termux inteiro. Consulte [instalação e backup](docs/INSTALACAO_E_BACKUP.md), [arquitetura e regras](docs/ARQUITETURA_E_REGRAS.md), [testes e pendências](docs/TESTES_E_PENDENCIAS.md) e [créditos](docs/ORIGENS_E_CREDITOS.md).

## Atualizar quem já tem a 0.1

Não precisa começar o progresso de novo. Extraia o novo ZIP numa pasta temporária e execute seu atualizador:

```bash
python3 -m zipfile -e ~/storage/downloads/TORRE_TNT_LIVE_V0_2.zip "$TMPDIR/torre-v02" &&
bash "$TMPDIR/torre-v02/TORRE_TNT_LIVE_V0_2/ATUALIZAR_V0_2.sh" "$HOME/TORRE_TNT_LIVE_V0_1" &&
cd ~/TORRE_TNT_LIVE_V0_1 && bash start.sh
```

O atualizador confere o manifesto, para apenas os processos dessa instalação, cria um backup local e preserva `data/`. A pasta pode continuar com o nome V0_1; a versão em execução será **0.2.0**. A migração mantém a quantidade exata de blocos, vitórias, ranking e configurações, agora numa grade de 18×100. Consulte [a pesquisa no GitHub](docs/PESQUISA_GITHUB.md) e [as alterações](docs/ALTERACOES_0_2.md).
