import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  readFile,
  mkdir,
  appendFile,
  stat,
  rename,
  writeFile,
} from "node:fs/promises";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { TowerEngine } from "./engine.mjs";
import { Store } from "./storage.mjs";
import { TikTokAdapter } from "./live.mjs";
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."),
  PORT = Number(process.env.PORT || 3300),
  HOST = "127.0.0.1",
  DATA = process.env.TORRE_DATA_DIR || path.join(ROOT, "data"),
  store = new Store(DATA),
  clients = new Set();
let mode = "demo",
  demoTimer = null,
  closing = false,
  lastBridgeAt = 0;
const session = await store.read("session");
if (session?.project === "torre-tnt-live" && session.mode === "live")
  mode = "live";
let liveUsername =
  mode === "live" && /^[a-z0-9_.]{2,24}$/i.test(session?.username || "")
    ? session.username
    : null;
const saveSession = () =>
  store.save("session", {
    project: "torre-tnt-live",
    mode,
    username: liveUsername,
  });
await mkdir(path.join(ROOT, "logs"), { recursive: true });
await mkdir(DATA, { recursive: true, mode: 0o700 });
async function log(kind, data = {}) {
  try {
    const f = path.join(ROOT, "logs/server.jsonl");
    if ((await stat(f).catch(() => ({ size: 0 }))).size > 1e6)
      await rename(f, f + ".1").catch(() => {});
    await appendFile(
      f,
      JSON.stringify({ at: new Date().toISOString(), kind, ...data }) + "\n",
    );
  } catch {}
}
let bridgeToken;
try {
  bridgeToken = JSON.parse(
    await readFile(path.join(DATA, "bridge.json"), "utf8"),
  ).token;
} catch {}
if (!/^[a-f0-9]{64}$/.test(bridgeToken || "")) {
  bridgeToken = randomBytes(32).toString("hex");
  await writeFile(
    path.join(DATA, "bridge.json"),
    JSON.stringify({ token: bridgeToken }),
    { mode: 0o600 },
  );
}
const emit = (event, data) => {
  const text = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of clients) {
    if (c.writableLength > 256000) {
      c.destroy();
      clients.delete(c);
    } else c.write(text);
  }
};
const engines = {};
for (const name of ["demo", "live"]) {
  engines[name] = new TowerEngine({
    mode: name,
    saved: await store.read(name),
    onAction: (a) => {
      if (mode === name) emit("action", { ...a, mode: name });
      if (["gift", "victory", "reset"].includes(a.kind)) {
        void log(a.kind, { mode: name, player: a.player });
        if (engines[name] && a.kind !== "gift")
          void store
            .save(name, engines[name].save())
            .catch((e) => log("save-error", { message: e.message }));
      }
    },
  });
}
const adapter = new TikTokAdapter(
  (e) => {
    engines.live.ingest(e);
    if (e.type === "gift")
      void store
        .save("live", engines.live.save())
        .catch((err) => log("save-error", { message: err.message }));
  },
  (s) => {
    emit("connection", s);
    void log("connection", { status: s.status, message: s.message });
  },
);
const connection = () =>
  Date.now() - lastBridgeAt < 30000
    ? {
        status: "connected",
        provider: "bridge",
        message: "Ponte local de eventos conectada",
        events: 0,
      }
    : adapter.state;
const ready = () => connection().status === "connected";
const snapshot = () => ({
  ...engines[mode].public(),
  connection: connection(),
  storageError: store.error,
  automaticDemo: !!demoTimer,
});
const json = (res, status, data) => {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(data));
};
async function body(req) {
  if (!String(req.headers["content-type"] || "").startsWith("application/json"))
    throw Object.assign(Error("Use application/json"), { status: 415 });
  if (
    req.headers.origin &&
    ![`http://127.0.0.1:${PORT}`, `http://localhost:${PORT}`].includes(
      req.headers.origin,
    )
  )
    throw Object.assign(Error("Origem recusada"), { status: 403 });
  let b = "";
  for await (const x of req) {
    b += x;
    if (b.length > 32768)
      throw Object.assign(Error("Evento grande demais"), { status: 413 });
  }
  return JSON.parse(b || "{}");
}
async function startDemo() {
  clearInterval(demoTimer);
  await adapter.disconnect();
  lastBridgeAt = 0;
  mode = "demo";
  liveUsername = null;
  await saveSession();
  const e = engines.demo;
  const users = [
    "demo_lua",
    "demo_solar",
    "demo_panda",
    "demo_lina",
    "demo_pixel",
  ];
  for (const u of users)
    e.ingest({ type: "join", user: u, name: u.replace("demo_", "") });
  let i = 0;
  demoTimer = setInterval(() => {
    const u = users[i % users.length];
    i++;
    if (i % 7 === 0)
      e.ingest({
        type: "gift",
        user: u,
        gift: "Rosa",
        id: randomBytes(8).toString("hex"),
        repeatEnd: true,
      });
    else if (i % 5 === 0)
      e.ingest({ type: "comment", user: u, text: "DEFESA" });
    else
      e.ingest({
        type: "like",
        user: u,
        count: 80,
        id: randomBytes(8).toString("hex"),
      });
  }, 1300);
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${HOST}`);
    if (req.method === "GET" && url.pathname === "/api/backup")
      return json(res, 200, engines[mode].save());
    if (req.method === "GET" && url.pathname === "/api/state")
      return json(res, 200, snapshot());
    if (req.method === "GET" && url.pathname === "/api/events") {
      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      });
      res.write("retry: 1500\n\n");
      clients.add(res);
      res.write("event: state\ndata: " + JSON.stringify(snapshot()) + "\n\n");
      req.on("close", () => clients.delete(res));
      return;
    }
    if (req.method === "POST" && url.pathname.startsWith("/api/")) {
      const data = await body(req),
        e = engines[mode];
      if (url.pathname === "/api/demo/start") {
        await startDemo();
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/demo/stop") {
        clearInterval(demoTimer);
        demoTimer = null;
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/demo/event") {
        if (mode !== "demo")
          return json(res, 409, {
            error: "Simulação disponível apenas no modo DEMO.",
          });
        const result = e.ingest(data);
        await store.save(mode, e.save());
        return json(res, 200, result);
      }
      if (url.pathname === "/api/demo/reset") {
        if (mode !== "demo")
          return json(res, 409, {
            error: "Use a demonstração para testar o reset.",
          });
        e.resetBoard(true);
        e.action("boardReset", { source: "host" });
        await store.save(mode, e.save());
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/settings") {
        try {
          e.configure(data);
        } catch (err) {
          return json(res, 400, { error: err.message });
        }
        await store.save(mode, e.save());
        return json(res, 200, { ok: true, settings: e.settings });
      }
      if (url.pathname === "/api/live/connect") {
        if (
          !/^[a-z0-9_.]{2,24}$/i.test(
            String(data.username || "")
              .replace(/^@/, "")
              .trim(),
          )
        )
          return json(res, 400, {
            error: "Digite somente o @ da conta, sem link.",
          });
        clearInterval(demoTimer);
        demoTimer = null;
        mode = "live";
        lastBridgeAt = 0;
        liveUsername = String(data.username).replace(/^@/, "").trim();
        await saveSession();
        engines.live.roomLikeBaseline = null;
        void adapter.connect(liveUsername).catch((err) => {
          void log("connect-error", { message: err.message });
        });
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/live/disconnect") {
        await adapter.disconnect();
        lastBridgeAt = 0;
        liveUsername = null;
        await saveSession();
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/mode") {
        if (!["demo", "live"].includes(data.mode))
          return json(res, 400, { error: "Modo inválido" });
        clearInterval(demoTimer);
        demoTimer = null;
        await adapter.disconnect();
        lastBridgeAt = 0;
        mode = data.mode;
        liveUsername = null;
        await saveSession();
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/bridge/token")
        return json(res, 200, { token: bridgeToken, port: PORT });
      if (url.pathname === "/api/live/event") {
        const token = String(req.headers.authorization || "").replace(
          /^Bearer /,
          "",
        );
        if (
          Buffer.byteLength(token) !== Buffer.byteLength(bridgeToken) ||
          !timingSafeEqual(Buffer.from(token), Buffer.from(bridgeToken))
        )
          return json(res, 401, { error: "Token da ponte inválido." });
        if (mode !== "live")
          return json(res, 409, { error: "Selecione modo LIVE." });
        lastBridgeAt = Date.now();
        const result = e.ingest(data);
        await store.save(mode, e.save());
        return json(res, 200, result);
      }
      return json(res, 404, { error: "Rota não encontrada" });
    }
    if (req.method !== "GET")
      return json(res, 405, { error: "Método não aceito" });
    const rel = decodeURIComponent(
        url.pathname === "/" ? "/index.html" : url.pathname,
      ),
      file = path.resolve(ROOT, "public", "." + rel);
    if (!file.startsWith(path.join(ROOT, "public") + path.sep))
      return json(res, 403, { error: "Caminho recusado" });
    const bytes = await readFile(file),
      ext = path.extname(file);
    res.writeHead(200, {
      "Content-Type":
        {
          ".html": "text/html; charset=utf-8",
          ".js": "text/javascript",
          ".css": "text/css",
          ".json": "application/json",
          ".webp": "image/webp",
          ".png": "image/png",
          ".svg": "image/svg+xml",
          ".ttf": "font/ttf",
          ".wav": "audio/wav",
        }[ext] || "application/octet-stream",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(bytes);
  } catch (err) {
    json(res, err.status || (err.code === "ENOENT" ? 404 : 400), {
      error: String(err.message || err).slice(0, 200),
    });
  }
});
const tick = setInterval(() => {
    const e = engines[mode];
    if (mode === "demo" || ready()) e.tick();
    else e.freeze();
  }, 50),
  broadcast = setInterval(() => emit("state", snapshot()), 250),
  save = setInterval(() => {
    for (const name of ["demo", "live"])
      void store
        .save(name, engines[name].save())
        .catch((e) => log("save-error", { message: e.message }));
  }, 1000),
  heart = setInterval(() => {
    void log("health", {
      rss: process.memoryUsage().rss,
      uptime: process.uptime(),
      clients: clients.size,
      players: engines.live.players.size,
    });
    for (const c of clients) c.write(": heartbeat\n\n");
  }, 30000);
server.listen(PORT, HOST, () => {
  console.log(`TORRE TNT · LIVE 0.2.0 · http://${HOST}:${PORT}`);
  void log("started", { pid: process.pid, port: PORT });
  if (mode === "live" && liveUsername) {
    engines.live.roomLikeBaseline = null;
    void adapter
      .connect(liveUsername)
      .catch((err) => log("connect-error", { message: err.message }));
  }
});
server.on("error", (e) => {
  console.error(e.message);
  process.exitCode = e.code === "EADDRINUSE" ? 78 : 1;
  shutdown();
});
async function shutdown() {
  if (closing) return;
  closing = true;
  clearInterval(tick);
  clearInterval(broadcast);
  clearInterval(save);
  clearInterval(heart);
  clearInterval(demoTimer);
  await adapter.disconnect();
  for (const c of clients) c.end();
  clients.clear();
  for (const name of ["demo", "live"])
    await store
      .save(name, engines[name].save())
      .catch((e) => log("save-error", { message: e.message }));
  await store.flush();
  server.close();
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
