# Torre TNT — alterações 0.2.0

- A área deixou de ser uma coluna de 100 blocos: agora tem **18 colunas × 100 andares = 1.800 células**.
- O construtor coloca um bloco por passo, atravessa cada fileira alternando a direção e sobe. Existe construção automática sem exigir presentes.
- Curtidas, BLOCO, seguidores e presentes abastecem uma fila de materiais. O rodízio por espectador evita que uma fila da comunidade esconda os bônus de outras pessoas.
- Explosões abrem buracos reais na grade. O construtor repara os vãos inferiores antes de avançar. Escudo, raios, bombardeio, reset e demais presentes foram preservados.
- A câmera acompanha o trabalho. Há minimapa dos 100 andares e botão MAPA para ver tudo. Os andares fora da tela não são desenhados.
- O HUD informa andares fechados, quantidade colocada e material na fila. O percentual só chega a 100% com todos os espaços preenchidos.
- O aviso do presente aparece no próprio painel de presentes para deixar o construtor visível.
- A fila, a grade e o passo do construtor são salvos. Os dados da 0.1 são migrados com a mesma quantidade de blocos, vitórias, ranking e configurações.
- Há um atualizador com manifesto, backup e encerramento apenas dos processos da instalação escolhida. Música, sons, fotos de presentes e integração TikTok permanecem.

O backup do código anterior foi criado antes das alterações. Testes, limites e observações estão em `TESTES_E_PENDENCIAS.md`. O jogo continua em Node.js e Canvas 2D no navegador do Termux.
