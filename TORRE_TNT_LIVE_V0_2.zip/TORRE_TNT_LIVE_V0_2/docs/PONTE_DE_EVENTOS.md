# Ponte local de eventos

Alternativa para um integrador de LIVE que já esteja no mesmo celular. Em ☰, selecione o modo LIVE e mostre o token da ponte. Use `POST http://127.0.0.1:3300/api/live/event`, `Content-Type: application/json` e `Authorization: Bearer TOKEN_LOCAL`. O token é privado, não é chave do TikTok e não deve ser publicado.

Exemplo de corpo:

```json
{"id":"evento-unico-001","type":"like","user":"visitante","name":"Visitante","count":40}
```

Tipos: `join`, `like`, `comment`, `follow`, `share`, `gift`. Comentários usam `text`. Presentes usam `gift`, `giftId`, `count`, `isStreak`, `streakId` e `repeatEnd`. IDs dos eventos devem ser estáveis para evitar repetição. Em sequências, `count` é o total acumulado do mesmo `streakId`, não um incremento adicional. Para presente não sequencial, use `isStreak: false`.

```json
{"id":"presente-001","type":"gift","user":"visitante","gift":"Rosa","giftId":"5655","count":2,"isStreak":false,"repeatEnd":true}
```

`roomTotal` pode acompanhar curtidas. Se apenas o total agregado estiver disponível, omita `count`: a primeira leitura define a base e as próximas concedem apenas o incremento. Não converta o total da sala em curtidas individuais de um espectador.

A ponte confirma atividade durante 30 segundos após um evento válido. Ao ficar sem conexão, o estado é preservado e os temporizadores do modo LIVE são pausados. Os recursos de teste não se misturam ao progresso LIVE. A ponte só é acessível no próprio dispositivo; não abre uma porta pública na rede.

Na 0.2, os bônus de construção abastecem uma fila. `count: 40` curtidas fornece dois materiais, que serão colocados em passos separados. A resposta HTTP confirma o evento; `construction.queued` e `blocks` no estado mostram, respectivamente, os materiais restantes e as células já colocadas. O modo LIVE desconectado conserva os temporizadores e não constrói sozinho fora de uma sessão confirmada.
