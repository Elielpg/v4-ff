# Origens e créditos

- **Código e arte do jogo:** Torre TNT é uma implementação nova de construção/resistência com Canvas 2D, torre, mina, personagens, TNT, texturas e partículas desenhados por código para este projeto. O visual foi inspirado na mecânica e apresentação da referência fornecida pelo usuário. Não inclui texturas, trilha ou código de Minecraft.
- **Áudio:** “Bloco a Bloco”, loop original de aproximadamente 34,3 segundos a 112 BPM, sintetizado para o projeto. O gerador está em `scripts/create_music.py`; usa NumPy somente para recriar a trilha, não para jogar. Efeitos são sintetizados em Web Audio. Não foram extraídas músicas do vídeo de referência.
- **Fonte:** VT323, Peter Hull, SIL Open Font License 1.1, disponibilizada pelo Google Fonts. O arquivo e a licença estão incluídos (`public/assets/VT323-Regular.ttf`, `docs/OFL-VT323.txt`).
- **Fotos de presentes:** arquivos reaproveitados byte a byte do pacote do usuário `BEN10_ATUALIZACAO_V44_2.zip`, com a procedência registrada em `public/assets/gifts/ORIGEM.json`. A origem anterior declarada é `nick-acchione/tiktok-gift-icons`, commit `63e2cb17aa518d250f983c67b3986b8ee7154e33`. Marcas e imagens dos presentes pertencem aos respectivos titulares. Não se atribui autoria ou licença própria a essas imagens; são identificadores dos presentes. O evento real pode fornecer uma imagem atualizada de um host de mídia do TikTok, com fallback local.
- **Conector:** `piratetok-live-js` 0.3.0, Zmole Cristian, licença incluída em `docs/PIRATETOK-LICENSE.txt`. As dependências e versões estão no `package-lock.json`.

O jogo não é um produto oficial do TikTok. Sua lógica e arquivos funcionam localmente; a conexão com a plataforma depende de serviços externos e pode precisar de manutenção quando o protocolo mudar.

Na evolução 0.2 foram consultados projetos semelhantes no GitHub, documentados em `PESQUISA_GITHUB.md`. A colocação por célula, a fila e o novo acompanhamento de câmera foram implementados neste código, sem copiar os jogos ou seus recursos.
