# Arquitetura e regras — 0.2.0

## Fluxo

```text
TikTok LIVE → conector → normalizador → TowerEngine → salvamento
Ponte HTTP autenticada ────────────────────┘              │
Botões DEMO → motor DEMO separado                         │
                                                         ↓
                             SSE → HUD + Canvas 2D + áudio
```

O servidor é a autoridade dos blocos, escudo, vitórias e ranking. A grade tem 18×100 células e a vitória exige 1.800 preenchidas; apenas alcançar a altura 100 não basta. O navegador anima resultados já registrados; efeitos visuais não bloqueiam ações do chat. Não há IA generativa, voz clonada ou execução de código recebido em mensagens.

## Estrutura

| Arquivo | Responsabilidade |
|---|---|
| `server/engine.mjs` | Eventos, regras, sequências de presentes, deduplicação, pontuação e estado |
| `server/live.mjs` | Conexão, normalização de IDs, curtidas individuais e total da sala |
| `server/index.mjs` | HTTP local, SSE, ponte, modos, sessão e diagnóstico |
| `server/storage.mjs` | Gravação substituída por rename, coalescência e recuperação de `.bak` |
| `public/grid.js` | Geometria 18×100, ordem de colocação, detecção de vãos e contagem de andares fechados |
| `public/catalog.js` | Catálogo de presentes, nomes reconhecidos e valores padrão |
| `public/mine.js` | Mina, torre, construtor, TNT, raios, partículas e resolução adaptável |
| `public/audio.js` | Web Audio, limitador de efeitos e reprodução da trilha local |
| `public/app.js` | HUD, slides, conexão, controles, testes e liberação de áudio |
| `scripts/supervisor.mjs` | Processo supervisor, limite de recuperação e logs |
| `scripts/instance.mjs` | Identificação da própria instalação para iniciar e parar |
| `tests/` | Testes unitários, HTTP, navegador e recuperação isolada |

## Presentes padrão

| Presente | Efeito por unidade |
|---|---|
| TikTok | +20 blocos |
| Rosa / Rose | TNT com potência de 10 blocos |
| Finger Heart | TNT com potência de 60 blocos |
| Perfume | 6 bombas visuais, potência total de 30 blocos |
| GG | +80 blocos |
| Doughnut | Raio com potência de 20 blocos |
| Hand Hearts | Abastece a fila com material para alcançar o teto; unidades extras abastecem novas torres |
| Galáxia | +40 cargas de escudo |
| Lightning Bolt | Raio com potência de 40 blocos |
| TikTok Universe | Zera os blocos colocados e o escudo; preserva vitórias, ranking e materiais ainda na fila |

Escudo absorve potência antes de atingir os blocos. Dura 30 segundos, pode ser renovado e acumula no máximo 60 cargas. Um presente desconhecido aparece no aviso e concede escudo limitado, em vez de desaparecer. Nomes variam por região; configure IDs/nome e efeito no painel se necessário. O mapa só aceita efeitos e quantidades permitidos, sem `eval` ou comandos do sistema. As fotos padrão representam os presentes; não são as animações oficiais do aplicativo.

## Participação gratuita e ranking

`BLOCO`: +1 material na fila, a cada 6 segundos por pessoa. `DEFESA`: +3 cargas, a cada 15 segundos. `TNT`: potência 1, a cada 12 segundos. Curtidas da comunidade somam os restos até formar um bloco. O primeiro total agregado da sala cria a linha de base; não concede retroativamente todas as curtidas históricas. Eventos individuais acompanhados de total não são somados duas vezes. Totais atrasados de outros servidores não reduzem a linha de base nem geram curtidas falsas ao subir novamente.

Ranking mostra **pontos do jogo**: blocos construídos, participação em presentes, potência que efetivamente destruiu blocos e créditos individuais de curtidas. Não representa moedas, diamantes ou dinheiro. Há até 4.000 espectadores em memória; ao atingir o limite, apenas espectadores sem pontos podem dar lugar a novos participantes. Curtidas sem usuário identificado ainda ajudam a comunidade.

## Consistência

Sequências de presentes com grupo usam apenas o incremento da quantidade acumulada e conservam o total final para não repetir o prêmio. Sem grupo, sequências só são aplicadas na confirmação final. IDs e registros de grupos são limitados a 4.096 entradas; grupos expiram após 10 minutos. IDs grandes do protocolo são preservados como texto.

O laço de construção coloca **no máximo uma célula por tick**, sem despejar o atraso inteiro de uma vez. Os intervalos padrão são 220 ms na construção automática e 90 ms com materiais na fila, sujeitos à resolução de 50 ms do laço e à carga do aparelho. O construtor alterna a direção a cada fileira e só avança depois de reparar o menor vão disponível. Filas são agrupadas por espectador e atendidas em rodízio; uma rajada de curtidas não prende para sempre os presentes de outros usuários. A fila e sua atribuição persistem no salvamento.

TNT, bombardeio e raios removem células próximas do impacto, criando buracos reais. O escudo absorve potência antes do dano. Há uma curta pausa de 0,5 a 1,15 segundo para o impacto antes de retomar a obra. A animação de explosão não controla a regra: o servidor já registrou o resultado. A comemoração dura 3,4 segundos e exibe a construção completa; a fila excedente aguarda a próxima torre.

A câmera acompanha a altura do construtor, com teto, minimapa dos 100 andares e visão geral pelo botão MAPA. A renderização ignora os andares fora da tela. Ondas visuais ficam limitadas a 24, partículas a 90–240 e sons simultâneos a 14; rajadas podem agrupar efeitos sem remover materiais da fila.

`data/demo.json` e `data/live.json` não se misturam. `session.json` guarda o modo e o @ público para recuperar a sessão após reinício; uma desconexão manual limpa esse @. `bridge.json` contém um token local exclusivo e fica fora do ZIP. O serviço escuta somente `127.0.0.1`.

Salvamento **schema 2**: grade explícita, fila por espectador, célula atual e tempo restante do construtor. `schema 1` da versão 0.1 é migrado sem multiplicar créditos: 63 blocos antigos continuam sendo 63 blocos na nova grade. Contadores de vitórias e ranking são mantidos. O arquivo `scripts/update.py` aplica a atualização com backup e identificação dos processos pela pasta/arquivo de entrada, sem encerrar outros programas por porta.
