# Instalação, uso prolongado e reversão

## Pasta e dependências

Extraia o ZIP para a pasta pessoal do Termux, não execute o projeto dentro do armazenamento compartilhado do Android. A pasta resultante é `~/TORRE_TNT_LIVE_V0_2`. Execute `bash install.sh` uma vez e `bash start.sh` para iniciar. A porta padrão é 3300; se precisar usar outra, `PORT=3301 bash start.sh` e abra esse número no navegador.

O pacote inclui todos os recursos de tela e música. O `node_modules/` é instalado pelo `npm ci`, usando o lockfile. Não há download de modelos ou conversão de voz. O instalador não troca repositórios APT, não ignora assinaturas e não altera seus projetos anteriores.

## Som e transmissão

O Chrome exige interação para liberar áudio. Toque em TESTAR O JOGO ou ♫. Há volumes separados de trilha e efeitos, teste sonoro, escolha de música local e redução de movimento. Escolher música apenas carrega o arquivo no navegador; não o envia para o servidor. Ao recarregar a página, selecione novamente a música escolhida.

No TikTok ou aplicativo de transmissão, habilite a captura de áudio do dispositivo/navegador se disponível. Faça uma transmissão de teste para conferir a mixagem. A detecção de áudio de outro aplicativo e o controle do Green Tube não fazem parte desta versão.

## Parar e iniciar

```bash
cd ~/TORRE_TNT_LIVE_V0_2
bash stop.sh
```

Aguarde a sessão original encerrar. Para iniciar novamente:

```bash
cd ~/TORRE_TNT_LIVE_V0_2 && bash start.sh
```

O supervisor identifica apenas os processos desta instalação. Não usa `pkill node`. Uma tentativa de abrir uma segunda instância informa que o jogo já está rodando. Um conflito de porta encerra a tentativa em vez de criar um ciclo de reinícios.

## Backup e restauração

O botão **Baixar backup deste modo** exporta o estado do modo aberto. Para um backup completo, pare o jogo e copie `data/`:

```bash
cd ~/TORRE_TNT_LIVE_V0_2
bash stop.sh
# Aguarde o encerramento antes de continuar.
cp -a data "backup-data-$(date +%Y%m%d-%H%M%S)"
```

Para restaurar um arquivo exportado, com o jogo parado, faça primeiro uma cópia do `data/` atual e substitua `data/demo.json` ou `data/live.json`, conforme o modo de origem. O arquivo precisa conter `project: torre-tnt-live` e `schema: 2` (ou `schema: 1` para migrar um backup da 0.1). Não restaure estados de outros jogos. `.json.bak` contém o estado anterior recuperável; o programa o consulta se o arquivo principal tiver JSON corrompido. O token de ponte não está no backup exportado; fica em `data/bridge.json`.

Antes de uma atualização futura, pare e copie a pasta inteira. Para reverter, volte à cópia anterior, preserve o respectivo `data/`, execute `bash install.sh` e inicie. Não extraia versões sobre uma sessão em execução.

## Se parar sozinho

Execute na pasta do jogo:

```bash
bash diagnose.sh
```

O supervisor registra código/sinal e tenta até 4 recuperações em 15 minutos, com espera crescente de 2 a 20 segundos. Você pode reduzir esse limite com `TORRE_MAX_RESTARTS=1 bash start.sh`. Valores inválidos usam o padrão; não há recuperação infinita. Um encerramento pedido por Ctrl+C ou stop não é reiniciado. O servidor tem até 8 segundos para encerrar antes de o supervisor terminar somente o próprio filho.

`start.sh` solicita wake lock quando o Termux oferece esse comando. Para uma LIVE longa, permita atividade em segundo plano ao Termux nas configurações do Realme. Ainda assim, Android, falta de memória, temperatura ou encerramento completo do aplicativo podem derrubar também o supervisor. Esta versão registra falhas observáveis, mas não determina a causa de um encerramento antigo sem seus logs. Mantenha uma captura dos diagnósticos e observe se o Termux voltou ao prompt ou fechou inteiro.

## Atualização no lugar da versão 0.1

Depois de extrair o novo pacote, execute `bash ATUALIZAR_V0_2.sh "$HOME/TORRE_TNT_LIVE_V0_1"` a partir da pasta nova. O atualizador identifica e encerra somente o servidor/supervisor dessa instalação, verifica os arquivos e cria `backups/antes-0.2.0-DATA-HORA.zip` antes de substituir o código. Os arquivos de `data/` e logs são preservados. Na primeira abertura, a grade antiga é migrada para 18×100 com a mesma quantidade de blocos, vitórias, ranking e configurações.

A instalação antiga pode continuar se chamando V0_1. Inicie por ela e confirme **0.2.0** no painel. Para reverter, pare a instalação, faça uma cópia do estado atual e extraia o backup anterior completo sobre a pasta. Ele inclui código e dados compatíveis com a 0.1; não substitua esses dados pelos novos arquivos schema 2 ao voltar ao código antigo. O backup também guarda configurações privadas da instalação, por isso mantenha-o local.
