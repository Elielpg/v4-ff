#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
node --version
node --input-type=module - <<'JS'
try {
  const port=process.env.PORT||3300;
  const r=await fetch('http://127.0.0.1:'+port+'/api/state',{signal:AbortSignal.timeout(4000)});
  const s=await r.json();
  console.log(JSON.stringify({version:s.version,mode:s.mode,connection:s.connection?.status,blocks:s.blocks,wins:s.wins,likes:s.totals?.likes,players:s.totalPlayers,storageError:s.storageError},null,2));
} catch(error) { console.log('Servidor indisponível:',error.message); }
JS
if [ -f logs/supervisor.jsonl ]; then tail -n 12 logs/supervisor.jsonl; fi
if [ -f logs/server.jsonl ]; then tail -n 12 logs/server.jsonl; fi
