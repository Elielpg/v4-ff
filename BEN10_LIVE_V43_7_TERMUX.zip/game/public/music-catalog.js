export const DARK_ROMANCE=[
 'Chase Atlantic - Swim','Chris Grey - LET THE WORLD BURN',
 'Arctic Monkeys - I Wanna Be Yours','The Weeknd - After Hours','Isabel LaRosa - i’m yours'
];
export const safeMusicText=(v,max=180)=>String(v||'').replace(/[<>\x00-\x1f]/g,'').replace(/\s+/g,' ').trim().slice(0,max);
export function musicCommand(text){const match=String(text||'').trim().match(/^[!/]?(?:m[uú]sica|music|song)(?:\s+([\s\S]*))?$/i);return match?safeMusicText(match[1]):null;}
export function youtubeVideo(value){
 try{const url=new URL(String(value).trim());if(url.protocol!=='https:'||url.username||url.password||url.port)return null;
 const host=url.hostname.toLowerCase(),id=host==='youtu.be'?url.pathname.slice(1).split('/')[0]:['youtube.com','www.youtube.com','m.youtube.com','music.youtube.com'].includes(host)?url.pathname==='/watch'?url.searchParams.get('v'):/^\/(?:shorts|live|embed)\//.test(url.pathname)?url.pathname.split('/')[2]:null:null;
 return /^[a-zA-Z0-9_-]{11}$/.test(id||'')?id:null;
 }catch{return null;}
}
export const musicSearch=query=>'https://www.youtube.com/results?search_query='+encodeURIComponent(safeMusicText(query));
