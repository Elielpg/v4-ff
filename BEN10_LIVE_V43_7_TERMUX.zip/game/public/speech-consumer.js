// Keep text and played state until the server acknowledges completion.
// A failed voice request must never consume a viewer's question.
export class SpeechConsumer{
 constructor({answer,speak,ack,touch=async()=>{},isCurrent=()=>true,onAnswer=()=>{},onState=()=>{},onError=()=>{},onDone=()=>{},now=Date.now}={}){Object.assign(this,{answer,speak,ack,touch,isCurrent,onAnswer,onState,onError,onDone,now});this.busy=false;this.entries=new Map();this.retryAt=0;this.failures=0;this.paused=false;}
 resume(){this.retryAt=0;this.failures=0;this.paused=false;}
 async step(item,{enabled=true}={}){
  if(!item||!enabled||this.busy||this.paused||this.now()<this.retryAt)return false;
  this.busy=true;let entry=this.entries.get(item.id)||{answer:null,played:false};this.entries.set(item.id,entry);
  try{
   await this.touch(item.id);
   if(!entry.answer){this.onState('thinking',item);entry.answer=await this.answer(item.id);}
   if(!this.isCurrent(item.id)){this.entries.delete(item.id);return false;}
   this.onAnswer(entry.answer,item);
   if(!entry.played){this.onState('voice',item);await this.speak(entry.answer,item);entry.played=true;}
   this.onState('ack',item);await this.ack(item.id);
   this.entries.delete(item.id);this.failures=0;this.retryAt=this.now()+300;this.onDone(item);return true;
  }catch(error){
   if(error.status===409){this.entries.delete(item.id);this.retryAt=this.now()+1000;}
   else{this.failures++;const transient=['local_voice_offline','local_voice_busy','local_voice_job_missing','local_text_offline','local_text_loading','gemini_429'].includes(error.code)||['TypeError','AbortError','TimeoutError'].includes(error.name);const gesture=['audio_gesture_required','audio_interrupted','voice_volume_zero'].includes(error.code);this.retryAt=this.now()+Math.min(30000,5000*2**Math.min(4,this.failures-1));this.paused=gesture||!transient&&this.failures>=3;}
   this.onState(this.paused?'paused':'retry',item);this.onError(error,item);return false;
  }finally{this.busy=false;for(const id of this.entries.keys())if(id!==item.id)this.entries.delete(id);}
 }
}
