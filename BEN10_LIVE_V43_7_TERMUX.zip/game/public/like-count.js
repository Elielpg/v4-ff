// A network batch can contain many taps. Visual particle limits are separate.
export function likeCount(value,{fallback=1}={}){
 const n=Number(value);
 if(value===undefined||value===null||value==='')return fallback;
 return Number.isFinite(n)?Math.min(1000000,Math.max(0,Math.floor(n))):0;
}
export function eventIdentifier(value){
 if(value===undefined||value===null)return null;
 const id=String(value).trim();
 return !id||/^0+$/.test(id)||id==='undefined'||id==='null'?null:id.slice(0,180);
}
