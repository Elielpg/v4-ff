from pathlib import Path
import zipfile
root=Path(__file__).resolve().parent.parent
out=root.parent/'BEN10_LIVE_V43_7_TERMUX.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if rel.parts[0]=='reports' and (len(rel.parts)<2 or rel.parts[1]!='v43_7' or p.name.endswith(('-preview.png','-bind.png'))): continue
  if not p.is_file() or any(x in ('node_modules','data','dist','.git','__pycache__') for x in rel.parts) or (p.name.startswith('.env') and p.name!='.env.example') or p.suffix in ('.zip','.gguf','.onnx','.part') or p.name.endswith('.onnx.json'): continue
  z.write(p,Path('game')/rel)
print(out)
