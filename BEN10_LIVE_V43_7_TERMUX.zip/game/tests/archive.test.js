import {test} from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,mkdir,writeFile,copyFile,rm} from 'node:fs/promises';import {spawnSync} from 'node:child_process';import path from 'node:path';import os from 'node:os';
test('ZIP de distribuição e backup excluem chaves privadas e .env',async()=>{const dir=await mkdtemp(path.join(os.tmpdir(),'linel-archive-')),root=path.join(dir,'game');try{await mkdir(path.join(root,'scripts'),{recursive:true});await mkdir(path.join(root,'data/private'),{recursive:true});await copyFile('scripts/package.py',path.join(root,'scripts/package.py'));await copyFile('backup.sh',path.join(root,'backup.sh'));await writeFile(path.join(root,'.env'),'GEMINI_API_KEY=test-only');await writeFile(path.join(root,'.env.example'),'GEMINI_API_KEY=');await writeFile(path.join(root,'data/private/gemini-keys.json'),'{"key":"test-only"}');await writeFile(path.join(root,'data/config.json'),'{}');for(const [cmd,args] of [['python3',['scripts/package.py']],['bash',['backup.sh']]]){const r=spawnSync(cmd,args,{cwd:root});assert.equal(r.status,0,r.stderr.toString());}const r=spawnSync('python3',['-c',`import zipfile,pathlib
root=pathlib.Path('.')
with zipfile.ZipFile('../BEN10_LIVE_V43_7_TERMUX.zip') as z:
 names=z.namelist()
 assert 'game/.env.example' in names
 assert 'game/.env' not in names
 assert not any('/data/' in n for n in names)
with zipfile.ZipFile(next(root.glob('backup-*.zip'))) as z:
 assert 'data/config.json' in z.namelist()
 assert not any('/private/' in n or '.env' in n for n in z.namelist())
`],{cwd:root});assert.equal(r.status,0,r.stderr.toString());}finally{await rm(dir,{recursive:true,force:true});}});
