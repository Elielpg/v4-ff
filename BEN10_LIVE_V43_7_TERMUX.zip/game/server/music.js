import {randomUUID} from 'node:crypto';
import {musicCommand,youtubeVideo,safeMusicText} from '../public/music-catalog.js';

export class MusicQueue{
 constructor({onChange=()=>{},now=Date.now}={}){this.onChange=onChange;this.now=now;this.items=[];this.active=null;this.running=false;this.source='demo';this.volume=35;this.revision=0;this.recent=new Map();}
 snapshot(){return {revision:this.revision,source:this.source,running:this.running,volume:this.volume,active:this.active,waiting:this.items.filter(i=>i.source===this.source),capacity:20};}
 emit(){this.revision++;this.onChange(this.snapshot());return this.snapshot();}
 selectSource(source){this.source=source==='tiktok'?'tiktok':'demo';if(this.active&&this.active.source!==this.source){this.active=null;this.running=false;}this.emit();}
 request({query,user='Equipe',source=this.source,priority=0,owner=false}){
  query=safeMusicText(query);user=safeMusicText(user,40)||'Visitante';source=source==='tiktok'?'tiktok':'demo';
  if(!query)throw Error('Peça assim: !musica artista - nome da música ou link do YouTube.');
  const videoId=youtubeVideo(query),key=source+':'+user.toLowerCase(),pending=this.items.filter(i=>i.source===source);
  if(pending.length>=20)throw Error('A fila de músicas está cheia. Aguarde uma faixa terminar.');
  if(!owner&&pending.filter(i=>i.user===user).length>=2)throw Error('Você já tem dois pedidos de música aguardando.');
  if(!owner&&this.now()-(this.recent.get(key)??-Infinity)<10000)throw Error('Aguarde dez segundos entre pedidos de música.');
  if(pending.some(i=>videoId?i.videoId===videoId:i.query.toLowerCase()===query.toLowerCase())||(this.active?.source===source&&(videoId?this.active.videoId===videoId:this.active.query.toLowerCase()===query.toLowerCase())))throw Error('Essa música já está na fila.');
  if(/^https?:\/\//i.test(query)&&!videoId)throw Error('Use um link público do YouTube ou escreva artista e nome da música.');
  const item={id:randomUUID(),query,title:videoId?'Vídeo pedido por '+user:query,videoId,url:videoId?'https://www.youtube.com/watch?v='+videoId:null,user,source,priority:Math.max(0,Math.min(5,priority)),at:this.now()};
  this.recent.set(key,this.now());if(this.recent.size>1000)this.recent.delete(this.recent.keys().next().value);this.items.push(item);this.emit();return item;
 }
 ingest(e){const command=e.type==='comment'?musicCommand(e.text):null;if(command===null)return false;this.request({query:command,user:e.displayName||e.user,source:e.source,priority:e.musicPriority||0});return true;}
 resolve(id,url){const item=this.items.find(i=>i.id===id);if(!item)throw Error('Pedido de música não encontrado.');const videoId=youtubeVideo(url);if(!videoId)throw Error('Cole um link válido do YouTube para esse pedido.');item.videoId=videoId;item.url='https://www.youtube.com/watch?v='+videoId;this.emit();return item;}
 promote(user){for(const item of this.items)if(item.user===user)item.priority=5;this.emit();}
 start(id){if(id){const item=this.items.find(i=>i.id===id&&i.source===this.source);if(!item?.videoId)throw Error('Esse pedido ainda precisa do link da música.');this.active=this.items.splice(this.items.indexOf(item),1)[0];}else if(!this.active)this.advance();if(!this.active)throw Error(this.items.some(i=>i.source===this.source)?'Escolha a faixa e cole o link do YouTube no pedido antes de tocar.':'Ainda não há músicas na fila.');this.running=true;return this.emit();}
 advance(){const candidate=this.items.filter(i=>i.source===this.source&&i.videoId).sort((a,b)=>b.priority-a.priority||a.at-b.at)[0];this.active=candidate?this.items.splice(this.items.indexOf(candidate),1)[0]:null;return this.active;}
 finish(id){if(!this.active||this.active.id!==id)return this.snapshot();this.active=null;if(this.running)this.advance();return this.emit();}
 pause(){this.running=false;return this.emit();}
 next(){this.active=null;this.advance();return this.emit();}
 remove(id){if(this.active?.id===id){this.active=null;if(this.running)this.advance();}else this.items=this.items.filter(i=>i.id!==id);return this.emit();}
 setVolume(value){if(!Number.isFinite(value)||value<0||value>100)throw Error('Volume da música inválido.');this.volume=Math.round(value);return this.emit();}
}
