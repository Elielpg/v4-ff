import {viewerProfile} from '../public/viewer-profile.js';
import {eventIdentifier,likeCount} from '../public/like-count.js';

export function normalizeLiveEvent(e,type,repeatEnd){
 const id=eventIdentifier(e.common?.msgId??e.msgId??e.messageId);
 const count=type==='like'?([e.likeCount,e.count,e.likes].map(v=>likeCount(v,{fallback:0})).find(n=>n>0)||0):e.repeatCount||e.count;
 return {...viewerProfile(e),id:id||undefined,type,
  user:e.user?.uniqueId||e.user?.displayId||e.user?.nickname||e.uniqueId,
  text:e.content||e.comment,gift:e.gift?.name||e.giftName,count,repeatEnd};
}
