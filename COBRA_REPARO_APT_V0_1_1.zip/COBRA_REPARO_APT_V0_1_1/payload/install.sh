#!/data/data/com.termux/files/usr/bin/bash
# Installer repair 0.1.1: preserve configured signed main source; FFmpeg is optional for gameplay.
set -euo pipefail
cd "$(dirname "$0")"
bash scripts/termux-packages.sh nodejs-lts
npm ci --omit=dev --ignore-scripts
if ! bash scripts/termux-packages.sh ffmpeg; then
  printf '\nO jogo foi instalado. O FFmpeg ainda está pendente: a transmissão RTMP ficará indisponível.\n' >&2
  printf 'Para tentar novamente: bash scripts/termux-packages.sh ffmpeg\n' >&2
fi
printf '\nCobra instalada. Execute bash start.sh e abra http://127.0.0.1:3500\n'
