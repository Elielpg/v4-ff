#!/usr/bin/env bash
# Reparo 0.1.1 somente do instalador da Cobra do Caos.
set -euo pipefail
umask 077
task_bundle="$(cd "$(dirname "$0")" && pwd -P)"
task_target="$(cd "${1:-$PWD}" && pwd -P)"
node - "$task_bundle" "$task_target" <<'NODE'
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const [bundle,target]=process.argv.slice(2);const pkg=JSON.parse(fs.readFileSync(path.join(target,'package.json'),'utf8'));
if(pkg.name!=='cobra-do-caos'||!fs.existsSync(path.join(target,'server/index.mjs')))throw Error('Execute o reparo na pasta da Cobra do Caos.');
const payload=path.join(bundle,'payload'),manifest=fs.readFileSync(path.join(payload,'MANIFEST.sha256'),'utf8');
for(const file of ['install.sh','scripts/termux-packages.sh']){const sum=crypto.createHash('sha256').update(fs.readFileSync(path.join(payload,file))).digest('hex');if(!manifest.split('\n').includes(sum+'  '+file))throw Error('Reparo incompleto ou corrompido: '+file);}
NODE
mkdir -p "$task_target/data/installer-backups" "$task_target/scripts"
task_backup="$(mktemp -d "$task_target/data/installer-backups/apt-0.1.1.XXXXXXXX")"
mkdir -p "$task_backup/scripts"
for task_file in install.sh scripts/termux-packages.sh; do
  if [[ -e "$task_target/$task_file" || -L "$task_target/$task_file" ]]; then
    cp -pP -- "$task_target/$task_file" "$task_backup/$task_file"
  fi
done
for task_file in scripts/termux-packages.sh install.sh; do
  task_temp="$(mktemp "$task_target/$(dirname "$task_file")/.cobra-installer.XXXXXXXX")"
  cp -- "$task_bundle/payload/$task_file" "$task_temp"
  mv -f -- "$task_temp" "$task_target/$task_file"
done
printf 'Reparo aplicado. Instalador anterior guardado em: %s\n' "$task_backup"
printf 'Fontes APT, chaves, progresso, configurações e modelos foram preservados.\n'
printf 'Agora execute: bash install.sh && bash start.sh\n'
