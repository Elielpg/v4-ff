from pathlib import Path
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT.parent/'artifacts';OUT.mkdir(exist_ok=True)
NAME='COBRA_DO_CAOS_V0_1';stage=OUT/(NAME+'_stage')
if stage.exists():shutil.rmtree(stage)
dest=stage/NAME;dest.mkdir(parents=True)
for name in ['README.md','package.json','package-lock.json','start.sh','stop.sh','install.sh','ia-local.sh','.gitignore']:shutil.copy2(ROOT/name,dest/name)
for folder in ['public','server','scripts','tests','android']:
 shutil.copytree(ROOT/folder,dest/folder,ignore=shutil.ignore_patterns('node_modules','build','.gradle','__pycache__','*.pyc','*.jks','*.keystore','*.pem','local.properties'))
(dest/'tools').mkdir()
for name in ['tts_worker.py','soak.mjs','browser-check.mjs','voice-flow-check.mjs','studio-check.mjs','make-audio.py','voice-lines.json','voice-lines.mjs','build-release.py']:shutil.copy2(ROOT/'tools'/name,dest/'tools'/name)
(dest/'docs').mkdir()
for p in (ROOT/'docs').iterdir():
 if p.suffix.lower() in ('.md','.txt','.json','.png') or p.name=='unit-tests.log':shutil.copy2(p,dest/'docs'/p.name)
files=sorted(p for p in dest.rglob('*') if p.is_file());manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(dest).as_posix()+'\n' for p in files);(dest/'MANIFEST.sha256').write_text(manifest)
archive=OUT/(NAME+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(dest.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(stage).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 assert not any('/data/' in n or '/node_modules/' in n or n.endswith(('.onnx','.jks','.keystore','.pem')) for n in z.namelist())
report={'archive':archive.name,'bytes':archive.stat().st_size,'files':len(files)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(OUT/(NAME+'.sha256')).write_text(report['sha256']+'  '+archive.name+'\n');(OUT/(NAME+'_PACKAGE.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
