# Cobra do Caos · v0.1.0

Jogo original para TikTok LIVE em tela vertical: a cobra Zig tenta preencher um tabuleiro 3D de 12 × 18 casas. O público escolhe ajudar ou sabotar. Inclui estúdio de transmissão RTMP com prévia e enquadramento. Compatível com navegador/WebGL e servidor Node no Termux. Instalação independente dos projetos anteriores; porta **3500**.

## Começar no Termux

Salve `COBRA_DO_CAOS_V0_1.zip` na pasta Downloads. Se necessário, execute `termux-setup-storage` uma vez para liberar essa pasta. Com Python disponível:

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/COBRA_DO_CAOS_V0_1.zip . &&
cd ~/COBRA_DO_CAOS_V0_1 &&
bash install.sh &&
bash start.sh
```

Se faltar Python/Node: `pkg install python nodejs-lts ffmpeg`. Use Node 22.19 ou mais recente. A primeira instalação do conector TikTok e do FFmpeg usa internet; imagens, fontes, músicas, efeitos e falas incluídos são locais. O jogo de demonstração funciona sem conexão com TikTok ou IA.

Abra **http://127.0.0.1:3500** no Chrome e toque em **TESTAR COM SOM**. A demonstração usa nomes e eventos fictícios, com progresso separado da LIVE.

Para abrir novamente:

```bash
cd ~/COBRA_DO_CAOS_V0_1 && bash start.sh
```

Para parar, Ctrl+C na sessão original ou `bash stop.sh` nesta pasta. O script encerra somente o supervisor desta instalação.

## Regras visíveis ao público

| Interação | Efeito |
|---|---|
| Comentar **HERÓI** | 1 comida, intervalo individual de 6,5 segundos |
| Comentar **VILÃO** | 1 bomba, intervalo individual de 11 segundos |
| 20 curtidas acumuladas | 1 comida |
| 100 curtidas acumuladas | 1 carga de escudo |
| Seguir, primeira vez reconhecida | 3 comidas |
| Compartilhar | 2 comidas, intervalo de 20 segundos |
| **Rosa** | 1 bomba |
| **GG** | 3 comidas |
| **Heart Me** | 3 cargas de escudo |
| **Galáxia** | Limpa bombas e agenda crescimento de 8 segmentos |
| **Confete / Confetti** | 8 bombas |
| **Leão / Lion** | Mordida de 8 segmentos, limitada a 12 por evento agrupado |

Comida no caminho aumenta o corpo em uma casa ao ser consumida. Bombas tiram quatro segmentos; o escudo absorve uma ocorrência por carga. Escudos duram 20 segundos e acumulam no máximo seis cargas. Com 216 segmentos, os heróis vencem. Com três segmentos após dano, os vilões vencem. Há revanche automática após seis segundos.

O piloto evita paredes e o próprio corpo; **não evita bombas**. O público muda o resultado pelas ajudas e sabotagens. A velocidade não depende da música. Fotos e nomes dos colaboradores aparecem em trechos do corpo quando seu crescimento é aplicado.

Presentes desconhecidos colocam uma comida ou bomba conforme o último lado escolhido pela pessoa. Catálogos e nomes dos presentes podem variar por região. As imagens conhecidas estão no carrossel e a tabela é a regra deste jogo, sem conversão monetária.

Combos são aplicados somente no término da sequência. Repetições identificadas são descartadas. Para manter a memória limitada: até 32 comidas, 18 bombas no tabuleiro, 180 créditos por fila e até 64 grupos de efeitos durante o resultado; excessos são agrupados/limitados. Presentes recebidos na tela de resultado seguem para a revanche, inclusive após reinício. Créditos ainda não consumidos no término normal de uma rodada pertencem àquela rodada.

## Conectar a LIVE

1. Inicie sua transmissão pelo estúdio RTMP integrado, descrito abaixo, ou pelo seu aplicativo habitual.
2. No menu **☰ → LIVE**, informe o @ da conta ao vivo e toque em **Conectar LIVE**.
3. Aguarde a confirmação do WebSocket no indicador. Toque em **INICIAR COBRINHA**.
4. Faça um comentário de teste **HERÓI** com outra conta e confirme o evento.

O conector recebe eventos públicos; não pede senha ou chave do TikTok. Mudanças do serviço podem exigir manutenção do adaptador. Não foi validada uma transmissão real nesta entrega. Se o servidor recuperar uma falha, confira o estado da conexão e reconecte a LIVE no painel. O envio de vídeo e a leitura do chat são conexões separadas: inicie o RTMP na aba Transmitir e conecte os eventos na aba LIVE.

## Transmitir diretamente por RTMP

**Pré-requisito:** sua conta precisa ter endereço de servidor e chave de transmissão liberados pelo TikTok. O jogo não cria essa liberação nem gera uma chave. Preencha a chave apenas no painel local, nunca em mensagens ou capturas de tela.

1. Abra **☰ → Transmitir**. O painel verifica se o FFmpeg suporta H.264/AAC.
2. Veja a composição vertical, com tabuleiro, placar, colaboradores e presentes. Arraste para posicionar o jogo ou use **Zoom / Horizontal / Vertical**. **Centralizar jogo** restaura a área completa.
3. Toque em **Gravar teste · 10s** para baixar uma amostra WEBM com som, sem entrar ao vivo e sem precisar de chave.
4. Comece com **Equilibrada: 720 × 1280, 30 FPS alvo, 2,5 Mbps**. Leve usa 540 × 960, 24 FPS e 1,4 Mbps. Alta configura saída 1080 × 1920, 30 FPS e 4,5 Mbps; seu desempenho ainda precisa ser verificado no celular.
5. Preencha **endereço do servidor** e **chave** nos campos separados e toque em **Iniciar transmissão RTMP**. Aguarde o indicador de quadros enviados pelo FFmpeg. A confirmação de que a LIVE chegou ao público deve ser verificada no TikTok.
6. Para parar, use **Encerrar**. O jogo continua. O botão vermelho no topo reabre o estúdio durante o envio.

O vídeo é uma composição limpa do jogo, sem menus do operador, barra do Chrome ou notificações do celular. A mistura inclui a música selecionada no jogo, efeitos e voz do Zig. O captador externo de batidas não fornece áudio musical ao estúdio: para a música sair na transmissão, carregue um arquivo no painel Música.

**Mantenha o jogo visível no Chrome.** Este modo usa a renderização do navegador; bloquear a tela ou colocá-lo em segundo plano encerra o envio para evitar uma transmissão congelada. O perfil é a configuração de saída; FPS efetivo e qualidade dependem do aparelho, renderização e rede. Há recodificação de vídeo, portanto não há promessa de perda zero nem de qualidade superior ao PRISM. RTMP por si só não aumenta a distribuição da LIVE.

A URL e a chave ficam em memória durante o envio, sem gravação em configurações, backup ou logs. A sessão não é retomada automaticamente após queda do servidor; reconecte manualmente para voltar a transmitir. Existem limites de fila e prazos para parar se o navegador parar de enviar quadros. Falha do codificador não encerra a cobra.

O fluxo é **Babylon/Canvas + WebAudio → MediaRecorder → HTTP local → FFmpeg → RTMP/RTMPS**. O relatório `docs/STUDIO_CHECK.json` registra um envio real a um receptor RTMP local, H.264/AAC, verificação do áudio, encerramento e continuidade do jogo. Isso não substitui teste no TikTok e no GT3.

## Som e música

Inclui trilha instrumental original de 132 BPM, efeitos sintetizados e 12 falas neurais PT-BR. Toque no botão inicial para liberar áudio no Chrome. O botão ♫ pausa ou retoma a música; o painel permite desligar a narração. A cobra continua com música e voz pausadas.

Use arquivos de áudio em **Música → Música do celular**. Para GreenTube ou outro aplicativo, há o captador Android **Pulso Batida 0.2.1**: instale o APK incluído, configure a porta **3500**, gere um código no jogo e autorize a captura no Android. A captura de outro app depende de ele permitir esse recurso. Com fone/Bluetooth, ajuste a compensação de 0 a 400 ms. As batidas controlam luzes discretas, sem interferir no piloto.

## Conversar com a IA local existente

As falas prontas funcionam sem modelo ou chave. Para perguntas livres, inicie o jogo e, em outra sessão do Termux:

```bash
cd ~/COBRA_DO_CAOS_V0_1 && bash ia-local.sh
```

Esse comando reutiliza a instalação anterior em `~/.local/share/ben10-local-ai`, o Qwen/llama.cpp e o Piper disponíveis. Não baixa modelos, não ativa o clonador e não altera os arquivos da instalação anterior. Se você ainda não tiver esses serviços, use as falas prontas ou configure serviços compatíveis em **Apresentador**. O nome `ben-classico-local` é somente o alias do servidor anterior; a personalidade enviada ao modelo é a do Zig.

Há limite de duas frases, fila de quatro perguntas, memória persistente das últimas três trocas por espectador e prazos para serviços indisponíveis. Se a voz falhar, a legenda continua; se a IA falhar, o jogo continua. O modelo não executa código nem comandos do sistema. A qualidade e a latência do Qwen no seu celular ainda precisam ser medidas.

## Estabilidade, backup e atualização

O supervisor recupera falhas do servidor no máximo quatro vezes em 15 minutos, com espera crescente. Logs em `logs/server.jsonl`, `logs/supervisor.jsonl` e `logs/ia-*.log`. Estados de demonstração/LIVE, ranking, filas e configurações ficam em `data/`, salvos atomicamente com backup. O tabuleiro é retomado após falha do processo; não há tentativa de simular o tempo em que o servidor ficou parado.

O wake lock ajuda a manter a CPU ativa, mas **não impede o Android de encerrar o Termux inteiro**. No Realme GT3, mantenha o Termux permitido em segundo plano e retire a restrição de bateria. Um encerramento de todo o aplicativo não pode ser recuperado pelo supervisor interno. Inicie novamente com `bash start.sh`.

Antes de uma futura atualização: pare esta instalação, copie a pasta e preserve `data/`. Para reverter, pare a versão nova e execute a cópia anterior com seu `data/` correspondente. Esta entrega não modifica Ben 10, Corrida do Caos ou outros jogos.

## Código e validação

- `server/engine.mjs`: regras, filas, eventos e persistência do tabuleiro.
- `server/pilot.mjs`: ciclo e atalhos seguros do piloto original.
- `server/index.mjs`: HTTP/SSE, controles locais e isolamento de modos.
- `server/studio.mjs`, `public/studio.js`: envio RTMP, mistura de áudio, composição, enquadramento e teste de gravação.
- `server/live.mjs`: adaptação TikTok e normalização de eventos.
- `server/host.mjs`, `tools/tts_worker.py`: conversa local e voz Piper.
- `public/world.js`: Babylon.js, corpo com instâncias, câmera, efeitos e rótulos.
- `public/app.js`, `style.css`, `index.html`: HUD, presentes e áudio.
- `scripts/`: supervisor, identificação de processos e inicialização local.
- `tests/`, `tools/`: regressões e verificações reproduzíveis.

Execute `npm test`. Os relatórios em `docs/` identificam o que foi medido na nuvem e o que permanece pendente no celular. A simulação acelerada não comprova duração de uma LIVE real. Nenhuma promessa de audiência, ganhos ou viralização faz parte do projeto.

Referências e licenças: `docs/ARQUITETURA_E_PENDENCIAS.md`, `docs/TERCEIROS.md`. Este é um jogo próprio, sem vínculo declarado com @cobradoabismo.
