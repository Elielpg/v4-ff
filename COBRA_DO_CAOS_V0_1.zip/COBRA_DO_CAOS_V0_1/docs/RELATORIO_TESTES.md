# Registro de validação · v0.1.0

- **24 testes** unitários e de integração HTTP, todos aprovados. Saída completa em `unit-tests.log`.
- O piloto completou **24 tabuleiros** sob crescimento contínuo sem colisão interna. Também foram verificados recargas de comandos, bombas, escudo, contagem/deduplicação, preservação de presentes no intervalo, recuperação de JSON, memória/contexto da conversa e fila de blocos WebM.
- Navegador Chromium em 430 × 932 e 360 × 800: fotos de presentes, colaborador no corpo, bombas/comida, retomada de áudio, bloqueio da simulação na LIVE e ausência de overflow horizontal. O jogo avançou com música pausada. Evidência: `BROWSER_CHECK.json`.
- **12 arquivos WAV** verificados quanto a cabeçalho, duração e sinal: `AUDIO_CHECK.json`.
- Resposta de texto controlada recebida pelo serviço de voz Piper real, reproduzida no navegador com legenda correspondente: `VOICE_FLOW.json`. Esse teste não mede acurácia/latência do Qwen no celular.
- Simulação acelerada: **7200 segundos de lógica**, 49 rodadas iniciadas, 42 vitórias e 6 quedas; filas e deduplicação dentro dos limites. Tempo de execução 3.18 s na nuvem; RSS final 56.3 MiB. São dados da lógica Node, sem renderização/IA/RTMP concorrentes. Evidência: `SOAK_ENGINE.json`.
- **RTMP real para receptor local:** 720 × 1280, h264, aac, 30/1 FPS na saída, 11.07 s recebidos. Som presente, nível RMS -17.7 dBFS. Progresso de quadros e indicador de transmissão confirmados. Encerramento normal do codificador verificado; a cobra continuou. Amostra local WEBM de dez segundos baixada e validada. Estado público e configuração não expuseram a chave de teste. Evidência: `STUDIO_CHECK.json`.

O navegador usa WebGL por software, sem GPU do Realme GT3. O FPS de software registrado não prevê o FPS no telefone. A simulação acelerada não equivale a duas horas reais de LIVE. Não foi feita transmissão pública ao TikTok. Elegibilidade RTMP, conexão do chat, temperatura, rede móvel e duração no Android continuam pendentes de teste no aparelho.

O teste do ZIP extraído e a checagem SHA-256 do arquivo publicado são entregues separadamente em `COBRA_DO_CAOS_RELEASE_CHECK.json`, vinculados ao hash exato do pacote.
