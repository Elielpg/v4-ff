"""Public model download, immutable revision and hash checks; no HF token needed."""
import argparse
import hashlib
import json
import os
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath

MODELS = {
    "gt3": ["Qwen/Qwen3-4B-Instruct-2507-GGUF", "unsloth/Qwen3-4B-Instruct-2507-GGUF"],
    "light": ["Qwen/Qwen2.5-1.5B-Instruct-GGUF"],
}
VOICE_REPO = "rhasspy/piper-voices"
VOICE_BASE = "pt/pt_BR/faber/medium/"


def metadata(repo):
    with urllib.request.urlopen("https://huggingface.co/api/models/" + repo + "?blobs=true", timeout=45) as response:
        raw = response.read(12 * 1024 * 1024 + 1)
    if len(raw) > 12 * 1024 * 1024:
        raise ValueError("Metadados muito grandes")
    result = json.loads(raw)
    if not re.fullmatch(r"[0-9a-f]{40}", result.get("sha", "")):
        raise ValueError("Revisão do modelo inválida")
    return result


def choose_quant(info):
    files = [f for f in info.get("siblings", []) if re.search(r"(?:^|[-_])q4_k_m\.gguf$", f.get("rfilename", ""), re.I) and PurePosixPath(f["rfilename"]).name == f["rfilename"]]
    if len(files) != 1:
        raise ValueError("O repositório não tem um único GGUF Q4_K_M. Use --model light ou confira o repositório.")
    return files[0]


def verify(path, record):
    if not path.is_file():
        return False
    size = record.get("lfs", {}).get("size", record.get("size"))
    if size is not None and path.stat().st_size != size:
        return False
    lfs = record.get("lfs", {}).get("sha256")
    oid = record.get("blobId")
    if not lfs and not oid:
        raise ValueError("Servidor não informou o hash de integridade")
    digest = hashlib.sha256() if lfs else hashlib.sha1()
    if not lfs:
        digest.update(b"blob " + str(path.stat().st_size).encode() + b"\0")
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest() == (lfs or oid)


def download(repo, revision, record, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if verify(destination, record):
        print("Já conferido:", destination.name, flush=True)
        return
    filename = record["rfilename"]
    if ".." in PurePosixPath(filename).parts or filename.startswith("/"):
        raise ValueError("Nome de arquivo inválido")
    url = "https://huggingface.co/" + repo + "/resolve/" + revision + "/" + urllib.parse.quote(filename, safe="/")
    partial = destination.with_name(destination.name + ".part")
    if verify(partial, record):
        os.replace(partial, destination)
        return
    expected = record.get("lfs", {}).get("size", record.get("size"))
    if partial.exists() and expected is not None and partial.stat().st_size >= expected:
        partial.unlink()
    start = partial.stat().st_size if partial.exists() else 0
    request = urllib.request.Request(url, headers={"Range": f"bytes={start}-"} if start else {})
    print("Baixando:", destination.name, flush=True)
    with urllib.request.urlopen(request, timeout=90) as response:
        append = start > 0 and response.status == 206
        count = start if append else 0
        mark = count
        with partial.open("ab" if append else "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > 6 * 1024**3:
                    raise ValueError("Modelo excede o limite de download")
                output.write(chunk)
                if count - mark >= 100 * 1024**2:
                    print(f"  {count // 1024**2} MiB recebidos", flush=True)
                    mark = count
    if not verify(partial, record):
        partial.unlink(missing_ok=True)
        raise ValueError("Hash do modelo não confere. Repita o download.")
    os.replace(partial, destination)


def install(root, profile):
    root.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(root).free < 8 * 1024**3:
        raise ValueError("Reserve pelo menos 8 GB livres para modelos e ambiente local")
    selected = None
    for repo in MODELS[profile]:
        try:
            info = metadata(repo)
            selected = (repo, info, choose_quant(info))
            break
        except urllib.error.HTTPError as error:
            if error.code != 404:
                raise
        except ValueError:
            continue
    if selected is None:
        raise ValueError("GGUF não encontrado. Tente --model light; nenhum modelo foi instalado como se estivesse pronto.")
    repo, info, record = selected
    model = root / "models" / record["rfilename"]
    download(repo, info["sha"], record, model)
    for optional in ["README.md", "LICENSE"]:
        entry = next((f for f in info["siblings"] if f["rfilename"] == optional), None)
        if entry:
            download(repo, info["sha"], entry, root / "licenses" / ("text-" + optional))
    voice_info = metadata(VOICE_REPO)
    for name in ["pt_BR-faber-medium.onnx", "pt_BR-faber-medium.onnx.json", "MODEL_CARD"]:
        entry = next((f for f in voice_info["siblings"] if f["rfilename"] == VOICE_BASE + name), None)
        if entry is None:
            raise ValueError("Arquivo de voz não encontrado: " + name)
        download(VOICE_REPO, voice_info["sha"], entry, root / "voices" / name)
    manifest = {"profile": profile, "textModel": str(model.resolve()), "voiceModel": str((root / "voices/pt_BR-faber-medium.onnx").resolve()), "textRepo": repo, "textRevision": info["sha"], "voiceRepo": VOICE_REPO, "voiceRevision": voice_info["sha"], "alias": "ben-classico-local", "threads": 4, "context": 2048, "piperVersion": "1.8.0", "llamaRevision": "6c01da6278ab6c69ed67d9124806b50d2b299ba7"}
    temp = root / "install.json.tmp"
    temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    os.replace(temp, root / "install.json")
    print("Modelos conferidos. Créditos e licença da voz em", root / "voices/MODEL_CARD", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--model", choices=MODELS, default="gt3")
    args = parser.parse_args()
    try:
        install(args.root, args.model)
    except Exception as error:
        raise SystemExit("Download não concluído: " + str(error))
