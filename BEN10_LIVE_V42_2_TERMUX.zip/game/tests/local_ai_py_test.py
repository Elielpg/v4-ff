import hashlib
import http.client
import importlib.util
import io
import json
import tempfile
import threading
import unittest
import wave
from pathlib import Path


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


worker = module("worker", "scripts/local-ai/tts_server.py")
downloads = module("downloads", "scripts/local-ai/download_models.py")


class LocalTests(unittest.TestCase):
    def test_voice_bridge_literal_text_and_origin_guard(self):
        spoken = []

        class Voice:
            def synthesize_wav(self, text, output):
                spoken.append(text)
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(22050)
                output.writeframes(b"\0" * 220)

        server = worker.make_server(Voice(), 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            connection = http.client.HTTPConnection("127.0.0.1", server.server_port)
            connection.request("POST", "/synthesize", json.dumps({"text": "E aí, Ana!"}), {"Content-Type": "application/json"})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            with wave.open(io.BytesIO(response.read())) as wav_file:
                self.assertEqual(wav_file.getframerate(), 22050)
            self.assertEqual(spoken, ["E aí, Ana!"])
            connection.request("POST", "/synthesize", json.dumps({"text": "não falar"}), {"Content-Type": "application/json", "Origin": "https://external.example"})
            self.assertEqual(connection.getresponse().status, 403)
            self.assertEqual(spoken, ["E aí, Ana!"])
            connection.close()
        finally:
            server.shutdown()
            server.server_close()

    def test_model_hashes_and_quant_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            model = Path(directory) / "model.gguf"
            model.write_bytes(b"GGUF fixture")
            entry = {"rfilename": "model-Q4_K_M.gguf", "lfs": {"size": model.stat().st_size, "sha256": hashlib.sha256(model.read_bytes()).hexdigest()}}
            self.assertTrue(downloads.verify(model, entry))
            model.write_bytes(b"corrupt")
            self.assertFalse(downloads.verify(model, entry))
            self.assertEqual(downloads.choose_quant({"siblings": [entry]}), entry)
            with self.assertRaises(ValueError):
                downloads.choose_quant({"siblings": [{"rfilename": "../bad-Q4_K_M.gguf"}]})
            card = Path(directory) / "MODEL_CARD"
            card.write_bytes(b"creditos")
            oid = hashlib.sha1(b"blob 8\0creditos").hexdigest()
            self.assertTrue(downloads.verify(card, {"size": 8, "blobId": oid}))


if __name__ == "__main__":
    unittest.main()
