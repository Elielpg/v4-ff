"""Build bundled WAVs offline. Optional build dependencies; not used by the game."""
from pathlib import Path
import os,json,time
import numpy as np,soundfile as sf,onnxruntime as ort
from kokoro_onnx import Kokoro
root=Path(__file__).resolve().parents[1]
opts=ort.SessionOptions();opts.intra_op_num_threads=3;opts.inter_op_num_threads=1
model=os.environ['COBRA_KOKORO_MODEL'];voices=os.environ['COBRA_KOKORO_VOICES']
k=Kokoro.from_session(ort.InferenceSession(model,sess_options=opts,providers=['CPUExecutionProvider']),voices)
for key,text in json.loads((root/'tools/voice-lines.json').read_text()).items():
 a,sr=k.create(text,voice='pm_alex',speed=.97,lang='pt-br',sentence_pause=.17,clause_pause=.08)
 a=np.asarray(a,dtype=np.float32);nz=np.flatnonzero(np.abs(a)>.002)
 if len(nz):a=a[max(0,nz[0]-int(sr*.035)):min(len(a),nz[-1]+int(sr*.14))]
 peak=np.max(np.abs(a)) or 1;a*=min(1.4,.82/peak)
 sf.write(root/'public/assets/voice'/f'{key}.wav',a,sr,subtype='PCM_16')
 print(key,round(len(a)/sr,2),flush=True)
