import {spawn} from 'node:child_process';
import {mkdtemp,rm,writeFile} from 'node:fs/promises';
import path from 'node:path';import os from 'node:os';import http from 'node:http';
const {chromium}=await import('playwright-core').catch(()=>import(process.env.PLAYWRIGHT_MODULE||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core/index.mjs'));
const root=path.resolve(import.meta.dirname,'..'),data=await mkdtemp(path.join(os.tmpdir(),'cobra-v04-flow-')),base='http://127.0.0.1:37984',wait=ms=>new Promise(r=>setTimeout(r,ms));let server,voice,browser,messages;
const model=process.env.COBRA_PIPER_MODEL;if(!model)throw Error('Informe COBRA_PIPER_MODEL para testar síntese real.');
const fixture=http.createServer(async(req,res)=>{let raw='';for await(const b of req)raw+=b;if(raw)messages=JSON.parse(raw).messages;res.setHeader('content-type','application/json');res.end(JSON.stringify(req.url==='/health'?{ready:true}:{choices:[{message:{content:'Sete vezes oito são cinquenta e seis!'}}]}));});
try{
 await new Promise(r=>fixture.listen(38081,'127.0.0.1',r));
 voice=spawn(process.env.PIPER_PYTHON||'python3',['tools/tts_worker.py','--model',model,'--port','38083','--cache-dir',path.join(data,'piper')],{cwd:root,stdio:'ignore'});
 server=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:'37984',COBRA_DATA_DIR:data},stdio:'ignore'});
 for(const url of [base+'/api/health','http://127.0.0.1:38083/health']){let ready=false;for(let i=0;i<150;i++){try{if((await fetch(url)).ok){ready=true;break;}}catch{}await wait(100);}if(!ready)throw Error('Serviço não iniciou: '+url);}
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});const page=await browser.newPage({viewport:{width:430,height:932}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(base,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.caos?.state);await page.locator('#welcome-play').click();await page.waitForFunction(()=>caos.state.running);
 await page.evaluate(async()=>{await caos.api('stop',{});await caos.api('cage/reset',{});await caos.api('start',{simulate:false});caos.world.entryQueue=[];caos.world.setCameraMode('follow');document.getElementById('music').pause();});
 await page.waitForFunction(()=>caos.audio.eatBuffer&&caos.audio.lastEat>0,{},{timeout:30000});const eating=await page.evaluate(()=>({lastEat:caos.audio.lastEat,bufferSamples:caos.audio.eatBuffer.length,goal:caos.state.goal,goalLabel:document.getElementById('goal').textContent,foods:caos.state.foods.length,stepMs:caos.state.stepMs}));
 await page.evaluate(()=>caos.api('host-config',{enabled:true,textPort:38081,voicePort:38083,model:'controlled-text-fixture',ambientInterval:20}));
 // Clear previous canned speech so the test measures the requested reply.
 await page.evaluate(async()=>{await caos.api('stop',{});await caos.api('ask',{user:'test_ai',name:'Teste',text:'Quanto é sete vezes oito?'});});
 await page.waitForFunction(()=>document.getElementById('speech-audio').currentSrc.includes('/voice-cache/')&&!document.getElementById('speech-audio').paused&&document.getElementById('speech-audio').currentTime>.08,{},{timeout:30000});
 const ai=await page.evaluate(()=>({caption:document.getElementById('caption').textContent,src:document.getElementById('speech-audio').currentSrc.split('/').at(-1),time:document.getElementById('speech-audio').currentTime,level:caos.audio.speechLevel()}));if(!ai.caption.includes('cinquenta e seis'))throw Error('Resposta/voz não coincidem');
 await page.waitForFunction(()=>document.getElementById('speech-audio').ended,{},{timeout:15000});
 await page.evaluate(()=>{caos.receiveSpeech({id:50000,audio:'/assets/voice/idleAdventure.wav',at:Date.now(),text:'Fala ambiente de teste.',kind:'ambient',priority:0});});
 await page.waitForFunction(()=>document.getElementById('speech-audio').currentSrc.includes('idleAdventure')&&!document.getElementById('speech-audio').paused);
 await page.evaluate(()=>caos.receiveSpeech({id:50001,audio:'/assets/voice/hello.wav',at:Date.now(),text:'Opa, Ana!',kind:'preset',priority:1}));
 await page.waitForFunction(()=>document.getElementById('speech-audio').currentSrc.includes('hello.wav')&&!document.getElementById('speech-audio').paused,{},{timeout:5000});
 const preempted=true;
 await page.evaluate(async()=>{await caos.api('start',{simulate:false});caos.receiveSpeech({id:50002,audio:'/assets/voice/start.wav',at:Date.now(),text:'Teste de retomada.',kind:'preset',priority:3});});await page.waitForFunction(()=>caos.state.running);await page.waitForFunction(()=>document.getElementById('speech-audio').currentSrc.includes('start.wav'));await page.waitForTimeout(350);
 await page.evaluate(()=>document.getElementById('speech-audio').pause());await page.locator('#play').click();await page.waitForFunction(()=>!document.getElementById('speech-audio').paused,{},{timeout:6000});const resumedAfterTap=true;
 await page.evaluate(()=>{caos.world.setColorMode('green');});await page.waitForTimeout(350);const green=await page.evaluate(()=>caos.world.materials.head.diffuseColor.asArray());await page.evaluate(()=>caos.world.setColorMode('rainbow'));await page.waitForTimeout(500);const rainbow=await page.evaluate(()=>caos.world.materials.head.diffuseColor.asArray());
 const result={ok:errors.length===0&&eating.goal===504&&eating.goalLabel==='504'&&eating.foods<=3&&eating.stepMs>=230&&preempted&&JSON.stringify(green)!==JSON.stringify(rainbow),errors,eating,ai,ambientInterruptedByGreeting:preempted,resumedAfterTap,colors:{green,rainbow},promptUsesNewRules:messages?.[0]?.content.includes('504 casas')&&messages?.[0]?.content.includes('50 curtidas'),note:'Chromium software + síntese real Piper. A resposta de texto é uma fixture HTTP controlada; não avalia o Qwen ou latência/temperatura no GT3.'};
 await writeFile(root+'/docs/V04_VOICE_AND_PACING_CHECK.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));if(!result.ok||!result.promptUsesNewRules)throw Error('Regressão V04');
}finally{await browser?.close();server?.kill('SIGTERM');voice?.kill('SIGTERM');await new Promise(r=>fixture.close(r));await wait(400);await rm(data,{recursive:true,force:true});}
