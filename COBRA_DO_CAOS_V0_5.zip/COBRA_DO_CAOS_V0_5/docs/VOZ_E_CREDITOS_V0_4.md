# Voz e materiais da V0.4

As 24 falas prontas usam **Kokoro v1.0 / pm_alex em português brasileiro**, geradas antes da distribuição. Somente os WAVs vão no jogo; não é necessário instalar Kokoro no Termux. São falas de um personagem original, sem clonagem de dubladores ou pessoas reais.

O modelo público Kokoro-82M é disponibilizado sob Apache-2.0: https://huggingface.co/hexgrad/Kokoro-82M . A execução usa `kokoro-onnx` (MIT): https://github.com/thewh1teagle/kokoro-onnx . Os arquivos de modelo e de vozes não integram este ZIP.

Para reconstruir os WAVs, em ambiente de desenvolvimento com NumPy, SoundFile, ONNX Runtime e kokoro-onnx instalados:

```bash
node tools/voice-lines.mjs
COBRA_KOKORO_MODEL=/caminho/kokoro-v1.0.onnx \
COBRA_KOKORO_VOICES=/caminho/voices-v1.0.bin \
python3 tools/make-stock-voice.py
```

A conversa livre continua no Qwen/Piper já instalado. `tools/tts_worker.py` mantém a síntese Piper, e `make-audio.py` mantém a opção anterior de reconstrução com Piper. O model card Faber anterior permanece em `VOICE_MODEL_CARD.md` (dataset CC0). Não foi instalado nem ativado o clonador.

Comparação auxiliar: uma mesma frase sobre a gaiola, almoço, bombas e convite teve transcrição automática fiel com pm_alex; a tomada Piper apresentou divergências nesses trechos, e pm_santa apresentou divergência em “falta”. Isso orientou a escolha das falas prontas e da narração, sem constituir avaliação humana de timbre ou prova de qualidade para todo texto. A normalização e o tratamento de falhas das respostas locais continuam independentes.

A trilha musical incluída e o som de mastigação foram sintetizados para este projeto. Imagens dos presentes e fontes mantêm a atribuição e as licenças da versão anterior. Consulte `PRESENTES_ORIGEM.json`, os arquivos OFL das fontes e a licença do Babylon.js em `public/vendor/`.
