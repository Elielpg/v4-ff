# Arquitetura V0.5

```mermaid
flowchart TD
  TikTok[Eventos TikTok / ponte local] --> Identity[IdentityBook]
  Identity --> Engine[SnakeEngine]
  Engine --> Cage[CageSystem: missões e banquetes]
  Engine --> Park[ParkSystem: fila, ranking, comentários]
  Engine --> Pilot[Piloto matemático]
  Engine --> Store[Store: estado JSON atômico]
  Engine --> SSE[SSE: estado e ações]
  SSE --> World[Babylon: cobra, parque e avatares]
  SSE --> Host[ShowHost: respostas sociais]
  Host --> Qwen[Qwen local por HTTP]
  Qwen --> Piper[Piper local / cache WAV]
  Piper --> Audio[WebAudio: música, efeitos e fala]
  World --> Studio[Canvas da transmissão]
  Audio --> Studio
  Studio --> FFmpeg[FFmpeg: H.264/AAC para RTMP]
```

## Novos módulos

- `server/park.mjs`: regras e estado da atração, fila de oito, prioridade de presente sem interromper o passeio ativo, recarga por pessoa, pontuação limitada, Top 6, mensagens com TTL, conciliação de aliases e retomada.
- `public/park-rules.js`: configuração permitida e duração das fases. Não aceita comandos ou URLs.
- `public/park-layout.js`: funções puras de trajetória, posição de vagões/visitantes/pódios e escrita da malha tubular.
- `public/continuous-body.js`: malha dinâmica de topologia constante e cauda afilada.
- `public/park-environment.js`: parque, água animada por UV, trilhos, vagões, canhão, placas e festa.
- `public/park-stage.js`: camada de apresentação sobre `CageStage`, com papéis de gaiola, fuga, comida, parque, vagão, pódio e canhão. Não altera o progresso das missões.

## Persistência e processos

O arquivo de cada modo conserva a estrutura de esquema 1 e acrescenta `park`. A V0.4 não precisa migrar o tabuleiro; versões anteriores conservam a migração já existente. O clock do canhão só avança com `tick` da sessão em execução. Marcadores `shot` e `landed` são atualizados antes de emitir as ações salvas. Após uma queda, retomar o mesmo estado continua a fase e não soma novamente os pontos de pouso. Uma falha abrupta pode perder os últimos eventos que ainda não chegaram ao disco; o teste de recuperação espera um estado persistido antes de derrubar o processo.

`Store` mantém a escrita atômica; `scripts/supervisor.mjs` limita reinicializações a quatro em 15 minutos. O processo de voz não encerra o servidor do jogo. O envio RTMP e a conexão do chat precisam ser conferidos pelo operador após uma falha/rede perdida. Encerrar todo o Termux interrompe também o supervisor.

## Identidade e limites

TikTok pode enviar @, ID numérico e atualizações de foto em eventos diferentes. O livro de identidades faz a conciliação; `mergeProfiles` repassa a união também ao parque para não duplicar fila/pontos. O atlas reutiliza slots e descarta imagens atrasadas de outro dono do slot. Erro de CORS mantém a inicial e não contamina o canvas de transmissão.

Há até 1.500 perfis e registros detalhados do parque, 3.000 IDs de deduplicação, 2.000 marcadores de passeios concluídos, um passeio ativo e oito aguardando. São selecionados até 30 visitantes recentes, além de líderes e pessoas envolvidas nas ações, sem exceder 192 avatares visuais. A lógica da gaiola conserva seus próprios limites e créditos.

## Áudio e transmissão

Falas prontas são WAVs PT-BR Kokoro/pm_alex, gerados no build. A conversa livre usa Qwen/Piper já instalados; não há download de modelos na instalação do jogo. A amplitude realmente reproduzida controla a boca. O navegador exige um toque inicial para liberar áudio. Trocar a versão invalida o cache de falas prontas pela URL no cliente.

`studio.js` redesenha nomes, comentários, Top 6, contadores e legendas no canvas codificado. O DOM da interface não é capturado automaticamente por `captureStream`. O app Android continua sendo uma alternativa de captura da tela/áudio do aparelho, com permissão do Android; não deve transmitir junto com o estúdio do navegador.

## Segurança operacional

A IA recebe contexto social e retorna texto. Não há ferramentas de shell acessíveis ao modelo. As APIs de configuração exigem JSON, origem local e listas de valores válidos. Destino/chave RTMP permanecem no fluxo privado já existente. O ZIP não contém estado, chave de ponte, modelos, credenciais, referências privadas ou material do vídeo enviado.
