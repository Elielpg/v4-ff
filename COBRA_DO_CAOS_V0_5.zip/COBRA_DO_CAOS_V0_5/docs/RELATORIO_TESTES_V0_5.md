# Testes da V0.5

Execução em 23/11/2026, em Linux Cloud. A etapa de pacote possui registros próprios com o SHA-256 do ZIP. O SHA-256 do ZIP final fica no relatório externo que acompanha a entrega.

## Resultados já registrados

- Base V0.4: 61 testes passaram antes das mudanças.
- V0.5: 74 testes unitários e de integração passaram. `unit-tests.log` inclui todos os nomes e o resultado final.
- `V05_BROWSER_CHECK.json`: percurso do canhão, voo, pouso, retorno ao pódio, retratos no peito, Top 6, quatro viewports, movimento reduzido e composição da transmissão.
- `V05_CAGE_BROWSER_CHECK.json`: vinte presos, dia/noite, três métodos de fuga, compartilhamento, movimento da câmera, banquete de cinquenta, crescimento com dono, playlist e bloqueio de simulação no modo LIVE.
- `V05_AVATAR_CHECK.json`: foto sintética atualizada no mesmo slot, sem duplicar a pessoa nem impedir a leitura do canvas de captura.
- `V05_VOICE_AND_PACING_CHECK.json`: síntese Piper real, resposta de texto controlada, reprodução no navegador, interrupção da fala ambiente, retomada com toque e regras lentas preservadas.
- `V05_STUDIO_CHECK.json`: receptor RTMP local recebeu H.264 e AAC em 720 × 1280. A chave não apareceu no estado/configuração/logs verificados; encerrar o codificador não encerrou o jogo.
- `V05_SOAK_ENGINE.json`: duas horas simuladas de lógica, com entradas, curtidas, presentes e canhão, executadas de forma acelerada. Limites de perfis, filas e deduplicação foram conferidos. O tempo de execução registrado é da nuvem, não do GT3.

## Etapa de pacote

A pré-validação `V05_RELEASE_FROM_0_4_0.json` passou: instalação limpa, atualização da V0.4, configuração/progresso preservados, retomada após SIGKILL durante voo e reversão. O código permanece o mesmo; somente relatórios e capturas são incorporados antes do empacotamento final. O ZIP final é testado novamente e identificado pelo SHA-256 no relatório externo `COBRA_DO_CAOS_V0_5_VALIDACAO.json`, distribuído junto com o ZIP. O relatório externo não é incluído dentro do arquivo cujo hash ele registra, para evitar autorreferência.

## O que estes testes não comprovam

Não houve publicação de LIVE real no TikTok nem conexão a uma conta de espectador real nesta validação. A resposta do teste de IA é uma fixture HTTP controlada; o motor de voz é Piper real. Não foi medido desempenho, temperatura, latência do Qwen, captura MediaProjection ou uma sessão prolongada no Realme GT3. A recuperação isolada do processo Node não é recuperação de todo o aplicativo Termux encerrado pelo Android. Não há resultados inventados de benchmarks.
