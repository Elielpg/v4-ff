# Cobra do Caos V0.3 · arquitetura e alterações

A V0.3 evolui a V0.2; mantém Babylon.js 9.32.1, Node, piloto, regras, ranking, gaiola e serviços locais. Não recria o jogo nem migra para Godot. O backup anterior está no pacote publicado V0.2; cada atualização local também gera seu próprio backup de código e estados.

## Cenário e apresentação

O tabuleiro físico passa de uma plataforma isolada para uma ilha com lago, árvores, pedras, montanhas, lanternas e passarela. O espaço das casas aumenta para 1,5 unidade; o piso tem 18 × 27 unidades. As **12 × 18 casas lógicas** permanecem iguais: não é necessário remapear corpo, comida, bombas ou progresso salvo.

| Módulo | Responsabilidade |
| --- | --- |
| `public/world.js` | Corpo instanciado, objetos, efeitos e interpolação do estado autoritativo |
| `public/island-environment.js` | Ilha, piso, cenário, materiais, lago e sombras limitadas |
| `public/scene-design.js` | Medidas, características dos avatares, enquadramentos e envelope da boca; funções testáveis sem GPU |
| `public/cinematic-world.js` | Cobra erguida, mandíbula, olhos, câmera frontal/superior e apresentação dos visitantes |
| `public/cage-stage.js` | Corpos variados, retratos no atlas, nomes, palco de chegada, fuga e queda dos avatares |
| `public/audio.js` | Música, batida e fonte única da voz com análise da amplitude reproduzida |
| `public/app.js` | HUD compacto, modo CENA AMPLA, eventos, fila de fala e controles |

A mandíbula acompanha a amplitude do áudio da fala. Legenda sem áudio, música isolada ou pausa não mantêm a boca aberta. A mesma fonte WebAudio alimenta ouvido, análise e RTMP, evitando criar duas MediaElementSource para o mesmo elemento.

A câmera frontal segue rapidamente a posição da cabeça e suaviza sua orientação. A interpolação usa o tempo de parede para manter o rosto enquadrado também com renderização lenta. O modo automático alterna com tomadas superiores e órbita, e reage a presentes/visitantes. Há modos manuais; eles são respeitados.

Cada ID define uma aparência estável: seis famílias, oito cores, quatro tons, acessórios e proporções. Entrada em destaque usa um palco para não esconder o visitante atrás da fila da gaiola. A fila de tomadas mantém até seis destaques por até 18 s; em picos, a lógica cadastra todos os participantes aceitos, mas a câmera não promete apresentar cada entrada individualmente. Até 156 avatares visuais e 256 posições de retratos são mantidos; o estado social conserva os limites da V0.2.

Perfis Leve/Equilibrado/Detalhado mantêm limites de resolução e 24/30 FPS. Sombras são desligadas no Leve. O limite configurado não é um resultado medido no telefone. Fotos que impedem CORS exibem iniciais sem invalidar a captura do canvas. O layout se adapta a retrato/paisagem e pode recolher os painéis.

## Captura nativa e captura pelo navegador

```mermaid
flowchart LR
  T[Termux: servidor e regras] --> W[WebView ou Chrome: cena Babylon]
  W --> P[Android MediaProjection]
  P --> E[EGL: cortes e proporção]
  E --> V[MediaCodec H.264]
  P --> A[AudioRecord: áudio interno]
  A --> C[MediaCodec AAC]
  V --> R[Cliente Java RTMP/RTMPS]
  C --> R
  A --> B[Medidas de graves e agudos]
  B --> T
  R --> D[Servidor indicado pelo usuário]
```

`android-live/` contém um aplicativo nativo independente, `br.caos.live`, Android 10+. O jogo é servido pelo Termux; o APK não inclui Node, modelos de IA ou outra cópia do jogo. O app abre a página local na porta 3500. O MediaProjection compartilha a tela inteira mediante diálogo do sistema. MainActivity protege a configuração com FLAG_SECURE e não salva a chave.

`CaptureService` é um serviço de primeiro plano, não exportado, com parada pela notificação. Obtém uma autorização nova a cada início. Mantém a captura de tela e áudio numa só sessão; não depende de FFmpeg. `ScreenRenderer` compõe cortes/proporção num contexto EGL separado e envia a superfície para MediaCodec. A captura segue alterações do display; a saída mantém o formato escolhido.

Áudio interno tenta estéreo AAC/128 kbps, com alternativa mono se AudioRecord não aceitar estéreo; microfone usa mono. A configuração AAC emitida pelo encoder informa o formato real. Só existe uma modalidade de áudio por vez. A captura de players externos depende das permissões de origem; não há contorno de restrições de áudio protegido.

O cliente Java implementa handshake, AMF0, comandos, controle de chunks/ack/ping, FLV AVC/AAC e TLS verificado no RTMPS. A fila tem limite de 240 pacotes e 8 MiB. Saturação ou envio bloqueado por 15 s termina a transmissão com mensagem; não há laço automático de reinício. Encerrar a captura não encerra o Node. O código de transmissão não é exposto a JavaScript nem ao servidor Node.

A opção anterior permanece em `public/studio.js`/`server/studio.mjs`: canvas + WebAudio → WebM → FFmpeg → RTMP. Os avisos de stderr deixaram de ser classificados automaticamente como erros; há regressão específica. As duas opções não devem transmitir simultaneamente.

## Batidas e compatibilidade

A captura antiga enviava `{frames: [...]}`, enquanto o servidor da cobra esperava um quadro único. A V0.3 aceita os dois formatos, com até 24 quadros por lote e a mesma autenticação. Valida identificação, sequência, tempo, energia e tamanho; a ponte não modifica participantes nem presentes.

O app novo usa o mesmo PCM em memória para `BeatMeter` e `RhythmRelay`, sem iniciar uma segunda captura MediaProjection. Somente energia, detalhe e tempo passam para localhost. A fila tem 64 medidas; cinco falhas encerram a ponte sem derrubar RTMP. O pareamento é automático na porta 3500 quando a opção de sincronização está ligada. A compensação Bluetooth de 0 a 400 ms também vale para esse caminho. Não execute outro capturador MediaProjection ao mesmo tempo.

## Dados e atualização

O esquema autoritativo anterior é preservado. IDs, @, pontos, missões, imunidade e créditos da gaiola continuam nos mesmos serviços. Estado de demonstração fica separado da LIVE. Os limites sociais e de filas estão descritos em `ARQUITETURA_V0_2.md`.

O atualizador verifica o manifesto antes de parar a instância, faz backup e copia apenas arquivos do pacote. `data/`, `.env`, cache e modelos externos não são substituídos. Uma reversão restaura código e snapshots anteriores, substituindo o progresso obtido depois da atualização. Os testes do ZIP extraído acompanham o download, vinculados ao SHA-256 exato.

## Pendências e limites reais

- **ANDROID-001:** MediaProjection, EGL, MediaCodec, permissões, rotação e duração da captura ainda precisam de teste físico no GT3. Compilar o APK e testar o transporte Java não verifica esses componentes no Android.
- **ANDROID-002:** Android pode encerrar o Termux inteiro ou revogar a projeção. O supervisor do jogo não consegue reiniciar o próprio aplicativo Termux; a captura revogada requer nova autorização. Não há correção definitiva comprovada para encerramento pelo Android.
- **LIVE-001:** TikTok real, IDs regionais, fotos/permissões e RTMP da conta precisam de teste com a conta do operador. Não houve transmissão pública nesta sessão.
- **AUDIO-001:** Apps que proíbem AudioPlaybackCapture podem ficar silenciosos. A alternativa é carregar arquivos no jogo ou usar microfone, conforme a modalidade escolhida.
- **PERF-001:** FPS, temperatura, rede e latência de Qwen/Piper com captura concorrente não foram medidos no GT3. O teste Chromium usa GPU por software.
- **UI-001:** Arquivos da playlist precisam ser selecionados novamente ao recarregar a página. A página da WebView é reaproveitada ao voltar do painel, mas encerramento completo do app perde essa seleção.

As evidências atuais estão em `RELATORIO_TESTES.md`; relatórios com prefixo BASE registram versões anteriores.
