# Voz e créditos V0.5

28 falas PT-BR prontas em WAV. As novas falas do canhão/parque e a revisão das referências à ilha foram geradas com Kokoro v1.0, voz pm_alex, velocidade 0,97. Os modelos não integram o jogo; somente os áudios já gerados. Não há clonagem de ator/dublador nem uso da amostra antiga de Ben 10.

Mantidos os créditos: Kokoro-82M Apache-2.0, kokoro-onnx MIT. As referências e instruções de reconstrução estão em `VOZ_E_CREDITOS_V0_4.md`; selecione as chaves a reconstruir com `COBRA_VOICE_KEYS=chave1,chave2` se desejar. `tools/voice-lines.json` corresponde ao texto atual de `server/host.mjs`.

A voz de respostas livres continua no Piper existente, com o Qwen local fornecendo o texto. O teste de reprodução usa síntese Piper real e servidor de texto controlado. Isso não é prova de timbre, sotaque ou pronúncia perfeita de todas as palavras.

Música original e som de mastigação da V0.4 preservados. Canhão e pouso têm tons/sweeps sintetizados pelo WebAudio, sem amostras de terceiros. A água, os avatares e as atrações são geometria/textura procedural criada no projeto. Nenhum quadro do vídeo de referência foi incluído no pacote.

Fontes, imagens dos presentes, Babylon.js e os APKs mantêm suas atribuições e licenças anteriores em `TERCEIROS.md`, `PRESENTES_ORIGEM.json`, arquivos OFL e pastas `public/vendor/`, `android/` e `android-live/`.
