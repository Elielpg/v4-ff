# Registro de validação · Cobra do Caos V0.3.0

Execução em 23/11/2026, Linux Cloud e Chromium com WebGL por software. Não houve sessão real no GT3 nem transmissão pública ao TikTok.

## Jogo e serviços

**57 testes aprovados, zero falhas**, preservando os anteriores. Saída em `unit-tests.log`. Cobrem piloto/crescimento, efeitos, gaiola, missões alternativas, identidade, persistência, filas, IA com resposta controlada, instalador assinado/isolado, atualização, supervisor, playlist e HTTP.

Novas regressões verificam aparência determinística/variada dos avatares, enquadramentos em retrato/paisagem, câmera acompanhando a direção, envelope da boca, classificação de avisos do FFmpeg e autenticação/compensação da ponte de áudio. O teste HTTP enviou lotes com medidas de energia, confirmou pulsos e estado listening, manteve o formato de quadro único, recusou lotes vazios/maiores que 24 e token ausente, e verificou que o estado público não devolve o token.

## Navegador 3D e voz

`PANORAMA_CHECK.json` confirma câmera de frente com o rosto dentro do quadro, apresentação do visitante correto, avatar e retrato, agradecimento colorido, modo panorâmico/CENA AMPLA e ausência de overflow em 360 × 800. Nenhum erro JavaScript. A boca atingiu amplitude 0.715 durante fala Piper real e caiu para 0.00014 após pausa; a legenda não é usada como sinal de áudio. As imagens `V03_*.png` são capturas reais desses testes.

`CAGE_BROWSER_CHECK.json`: três fugas, compartilhamento sem fuga, queda dos 50 avatares no centro, consumo/crescimento, dia/noite, câmera, alternância automática de duas faixas e botões de simulação recusados no modo LIVE. A demonstração não adicionou participantes à LIVE.

`AVATAR_CHECK.json`: foto recebida depois do cadastro atualiza o mesmo slot sem duplicar usuário; o canvas continua capturável. A referência usa CORS permitido, sem comprovar fotos reais da plataforma. `AUDIO_CHECK.json`: 16 WAV Piper com sinal e formato conferidos, incluindo o novo agradecimento. Não é avaliação humana de timbre ou pronúncia. Os modelos Qwen/Piper existentes não foram benchmarkados no telefone.

## Aplicativo Android

`ANDROID_LIVE_BUILD.json`: fontes Java compiladas contra SDK 35, APK alinhado e assinatura verificada, minSdk 29/targetSdk 35, permissões/serviço declarados. SHA-256:

```
cbcb06bdde1624faf11ca3e0e28228b97409b6742f1b928b68931a6ca21a76ea
```

`NATIVE_RTMP_CHECK.json`: **24 verificações JVM** de URI, AMF0, framing AVC/AAC, rejeição de dados inválidos, silêncio e filtro de graves. Cliente Java real publicou **411 tags** para FFmpeg local. Recebidos H.264/AAC, 320 × 568, 7.035 s, áudio RMS -21.099 dBFS. O fixture é um arquivo conhecido; esse teste verifica transporte e mídia, sem executar MediaProjection, MediaCodec ou EGL.

O APK contém código para captura real da tela, áudio interno estéreo com alternativa mono, microfone, cortes, rotação, foreground service e ponte de batidas. **Esses componentes e as permissões precisam de teste físico no Android.** Compilação/assinatura e transporte local não comprovam a captura física nem uma LIVE pública.

## RTMP do navegador preservado

`STUDIO_CHECK.json`: canvas/WebAudio → WebM → FFmpeg → receptor RTMP local. Recebidos **720 × 1280, H.264/AAC, 9.966 s**, 3,352,515 bytes, som RMS **-19.843 dBFS**. A saída declara 30/1 FPS; não é medida de quadros únicos da GPU. Confirmados progresso de quadros, gravação WEBM de dez segundos, encerramento do codificador com jogo continuando e ausência da chave no estado público. Nenhum erro JavaScript. O teste final registrou lastError vazio.

## Instalação, atualização e reversão do ZIP

Os relatórios do pacote extraído ficam **ao lado do download**, vinculados ao SHA-256 exato do ZIP: `COBRA_DO_CAOS_V0_3_RELEASE_CHECK.json` e `COBRA_DO_CAOS_V0_3_FROM_*_CHECK.json`. O verificador faz instalação limpa, atualização de instância ativa, preservação de outra instalação, migração de dados/configuração, falha forçada do servidor e reversão do backup. Confira `ok: true` e hash correspondente antes de considerar a validação do pacote concluída.

## Limites da evidência

A simulação acelerada da V0.2 está identificada como `BASE_V0_2_SOAK_ENGINE.json`; não foi uma nova sessão prolongada da V0.3. Ainda faltam: TikTok real, captura física pelo APK, latência de voz, FPS/temperatura/rede no GT3 e duração com todos os serviços concorrentes. O supervisor não recupera o encerramento de todo o Termux pelo Android.
