# Gaiola 3D · arquitetura, limites e pendências

A V0.2 evolui os serviços da V0.1. O servidor continua sendo a autoridade, com tick de 50 ms, estados SSE a cada 200 ms e gravação atômica. O piloto matemático é independente da câmera, áudio, IA e transmissão.

## Estado social

`CageSystem` é separado do motor da cobra. Mantém até 50 presos, progresso individual desde a captura, missões alternativas, entradas repetidas, fugas e grupos de 50 despachados ao centro. A identificação numérica da plataforma é conciliada com o @ para que likes e comentários não criem duas missões. Curtidas sem identificação ficam no coletivo e no diagnóstico, sem atribuição inventada.

A primeira rosa de um combo liberta imediatamente; bombas e outras ações do presente permanecem condicionadas ao encerramento/deduplicação do combo. A missão é processada antes de verificar o limite: uma rosa enviada como primeira interação pelo quinquagésimo cadastro pode libertá-lo sem disparar o banquete dos outros 49.

A queda dura 3,2 s. A pilha ocupa o centro visual e é coletada ao passar por uma das quatro casas centrais. Não interfere como obstáculo físico no piloto. Créditos de comida da gaiola são separados dos créditos comuns, persistem ao trocar de rodada e não são perdidos na recarga do processo.

Limites: 1.500 perfis/registro visual, 6.000 associações de identidade, 12 grupos detalhados aguardando no centro, 600 créditos detalhados de crescimento, até 50 mil créditos agregados de excesso e 50 mil marcas de fuga por sessão. A reserva agregada conserva a quantidade sem reter todas as fotos/nomes em picos maiores. Marcas de fuga usam identificadores reduzidos; não entram no estado público. Fotos da gaiola são reidratadas a partir dos perfis ao restaurar o estado, evitando duplicação no arquivo de persistência.

## Renderização

Babylon.js 9.32.1 foi preservado. A câmera ArcRotate faz percursos e foca eventos com transições suaves. Há modos para acompanhar a cobra, ver o tabuleiro e visitar a gaiola. O modo de movimento reduzido prioriza uma visão fixa.

Corpos, membros, cabeças e comida usam instâncias. Retratos compartilham um atlas de 1024 × 1024, atualizado com limite de frequência; as fotos usam CORS e têm iniciais como alternativa. A cena mantém avatares de presos, fugitivos recentes e no máximo dois grupos visuais de queda. Os grupos de jogo continuam completos mesmo quando há mais eventos que a apresentação visual simultânea. Nomes são escolhidos com espaçamento de tela para reduzir sobreposição. O renderer limita a taxa a 24/30 FPS, sem afirmar um resultado medido no GT3.

Dia/noite usa o relógio da sessão em um ciclo de oito minutos. Compartilhar produz variação de matiz e brilho moderado por nove segundos. O controle de redução de movimento desliga a pulsação e a órbita. A playlist mantém objetos File locais e um único URL de áudio ativo, liberado ao trocar de faixa.

## Integrações e atualização

O compositor RTMP usa o mesmo canvas 3D, com HUD próprio das missões; controles privados não aparecem no vídeo. A mistura continua sendo WebAudio, codificada pelo FFmpeg como H.264/AAC. A chave permanece em memória na sessão de envio. O browser deve permanecer visível.

O atualizador verifica os hashes, encerra somente processos do jogo cujo diretório corresponde ao destino, faz backup de arquivos substituídos e snapshots JSON e então aplica o código. Existe uma reversão local. O esquema anterior é aceito; os contadores antigos continuam no ranking, enquanto missões da gaiola começam a contar a partir da nova captura. Não há alterações em pesos da IA, chaves APT, repositórios ou arquivos externos.

## Pendências reais

- Validar uma LIVE real no GT3: entrega de eventos de entrada/likes identificados, fotos do TikTok e presentes regionais.
- Medir duração, memória, temperatura e FPS com renderização, Qwen/Piper e RTMP simultâneos no telefone. A simulação da lógica e o Chromium por software não comprovam esses resultados.
- Android pode encerrar todo o Termux; o supervisor interno não consegue reiniciar o próprio aplicativo. Logs do aparelho continuam necessários para atribuir a causa.
- Se a foto não oferecer CORS ao browser, o avatar exibe iniciais. Isso mantém o canvas capturável.
- A playlist de arquivos precisa ser selecionada novamente após recarregar a página.
- Perguntas em processamento na IA não são retomadas após queda. Gaiola, progresso de missão, imunidade e créditos de jogo salvos são restaurados.
- A conexão de eventos e a transmissão são independentes; após uma falha, confirme ambas. RTMP integrado depende da liberação da conta e de Chrome visível.
