# Arquitetura e pendências · Cobra do Caos 0.1

Este documento registra a base preservada da V0.1. Para a evolução da gaiola, câmera, playlist e os limites atuais, consulte [ARQUITETURA_V0_2.md](ARQUITETURA_V0_2.md). Evidências antigas de navegador e voz estão em `BASE_V0_1_BROWSER_CHECK.json` e `BASE_V0_1_VOICE_FLOW.json`; os testes atuais estão descritos em `RELATORIO_TESTES.md`.

## Implementado

O servidor é a autoridade da partida: lógica a cada 50 ms e estado via SSE a cada 200 ms. A renderização interpola as posições. O tabuleiro é 12 × 18; um ciclo Hamiltoniano original cobre todas as casas e atalhos preservam a ordem do corpo. Crescimento pendente é adiado se encontraria a cauda. O piloto é independente de LLM, voz, rede e detecção musical.

Comida, bombas e crescimento têm filas limitadas. Há classificação de colaboradores em heróis/vilões e identificação por foto/nome quando o crédito vira corpo. Presentes durante o intervalo entre rodadas ficam em grupos persistentes para a revanche. Falas prontas, efeitos e trilha são locais. O Qwen e o Piper podem ser reaproveitados da instalação anterior; não há clonador ativo.

A camada TikTok normaliza IDs de evento, combo, avatar e quantidade. Eventos de demonstração são recusados no servidor quando o modo LIVE está selecionado. Cada modo tem estado, participantes e ranking próprios. Curtidas sem usuário entram apenas no total coletivo, sem atribuição falsa.

Babylon 9.32.1 usa instâncias para o corpo, tabuleiro estático mesclado em dois materiais, partículas com pool de 28 elementos e perfis de resolução. A câmera privilegia a leitura do tabuleiro. Não há dependência de CDN para rodar o frontend.

O supervisor identifica esta instalação e reinicia apenas seu servidor. Recuperação é limitada, com logs, persistência atômica e segunda cópia do JSON. A fila de perguntas não bloqueia o ciclo do jogo. Falha de voz mantém a legenda. A sequência das falas é reiniciada por `bootId` para evitar silêncio após recuperação do servidor.

## Estúdio RTMP integrado

`public/studio.js` compõe um canvas vertical com o render Babylon, HUD e nomes dos colaboradores. Fontes e fotos dos presentes são locais; avatars externos usam CORS e têm fallback para iniciais. Música, efeitos e o áudio da voz passam por uma mistura WebAudio com compressor. MediaRecorder gera WebM em blocos ordenados e limitados. `server/studio.mjs` alimenta o stdin do FFmpeg, que envia H.264/AAC por RTMP/RTMPS, sem comandos de shell.

A área do tabuleiro pode ser ampliada e reposicionada, com prévia do quadro final. Menus privados não são capturados. A chave não é persistida nem devolvida pelo estado público; o codificador é encerrado separadamente do jogo. O progresso de quadros do FFmpeg confirma o envio ao servidor configurado, sem afirmar que o TikTok publicou ou distribuiu o conteúdo. Há desligamento por falta de quadros, limites de fila e encerramento ao ocultar a página. Não há reinício automático de uma transmissão pública.

## Verificado e ainda não verificado

As evidências da base foram preservadas em `BASE_V0_1_BROWSER_CHECK.json` e `BASE_V0_1_VOICE_FLOW.json`. O teste da voz usa uma resposta de texto controlada e síntese Piper real. Não é um benchmark do Qwen. O teste em navegador usa renderização por software na nuvem, sem GPU do GT3. A simulação de duas horas avança o relógio da lógica rapidamente, sem aguardar duas horas reais.

Pendentes para o aparelho: conexão TikTok real e reconhecimento dos presentes regionais; teste prolongado de temperatura/memória; comportamento do Android ao bloquear a tela; latência e pronúncia do Piper instalado; capacidade da captura de áudio do GreenTube e compensação Bluetooth; adaptação do fluxo de captura de tela utilizado na live.

## Problemas conhecidos / limitações

- **SNAKE-001 · Android encerra o Termux inteiro.** O supervisor no mesmo aplicativo também morre. Mitigar com bateria sem restrição e permissão de segundo plano; obter logs do Android para atribuir causa. Não há comprovação de correção definitiva desse encerramento.
- **SNAKE-002 · TikTok pode alterar o protocolo.** Existe reconexão manual no painel. Após recuperação do servidor, reconecte a LIVE e confirme o indicador antes de confiar nas contagens.
- **SNAKE-003 · Consulta longa de IA.** Há prazo de 14 s para texto, 7 s para voz, descarte de perguntas antigas e filas limitadas. O celular pode exceder esses prazos; o jogo continua, mas a fala pode não ser produzida. Só dados do aparelho permitem ajustar esses valores com segurança.
- **SNAKE-004 · Catálogo de presentes regional.** Os seis efeitos são configurados em `public/rules.js`. Imagens são ilustrativas dos presentes conhecidos; o nome e ID reais devem ser conferidos na conta de transmissão.
- **SNAKE-005 · Limites sob enxurrada de eventos.** Filas possuem capacidade explícita e excesso é limitado. Até 1.500 perfis são mantidos; perfis menos recentes podem ser descartados quando o limite é atingido. A fila de perguntas é volátil durante uma queda de processo; os efeitos de jogo e a memória social já salva são persistentes.
- **SNAKE-007 · RTMP depende da conta e do navegador.** Requer URL/chave liberadas pela plataforma e Chrome visível. Perfis 540p/1080p e estabilidade prolongada no GT3 permanecem pendentes; o teste local confirma somente o caminho H.264/AAC em 720p. Captura de outro app fornece batidas, sem encaminhar seu áudio ao RTMP.
- **SNAKE-006 · Música em outros aplicativos.** Android/app podem proibir captura. Sem essa autorização, use um arquivo no painel; não há detecção direta por áudio interno no navegador.

## Próximas melhorias recomendadas

Medir uma sessão real no GT3 antes de aumentar o número de objetos ou efeitos. Registrar latência por etapa de IA/voz e capturar o motivo real de encerramento do Termux. Após validação do TikTok, adicionar reconexão automática limitada, com proteção contra reconexões duplicadas. Melhorar a curvatura e expressões do Zig com animações específicas para ameaça/escudo, e opções de dificuldade que mantenham as regras transparentes. Expandir o catálogo de presentes somente depois de validar os IDs reais.

## Referências

Foram consultadas descrições públicas dos repositórios `amthedev/tiktok-snake-live`, `landsbetween/tiktok-snake-live` e `livecade/snake-tiktok-live-game`. O último descreve um produto hospedado, sem disponibilizar o código do jogo. As mecânicas comuns de cobra automática ajudaram a orientar o escopo; piloto, regras e renderização desta entrega são implementação própria com serviços reutilizados dos projetos locais do usuário. Não foi possível assistir à live @cobradoabismo na rede desta sessão, nem confirmar vínculo desses repositórios com o canal.
