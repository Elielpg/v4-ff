# Recursos e dependências

- **Babylon.js 9.32.1**: Apache-2.0; cópia local e licença em `public/vendor/`.
- **piratetok-live-js 0.3.0**: 0BSD conforme pacote; dependência fixa no lockfile, instalada pelo npm. Conector não oficial do TikTok.
- **Anton e Space Grotesk**: SIL OFL, textos de licença nesta pasta; fontes locais.
- **Piper PT-BR Faber medium**: falas sintetizadas com Piper 1.8 e modelo cujo cartão declara o dataset CC0. Cartão em `VOICE_MODEL_CARD.md`. Pesos e runtime de síntese não estão no ZIP; a instalação de IA existente é reutilizada opcionalmente.
- **Imagens dos presentes**: arquivos reutilizados do catálogo do projeto local, origem em `PRESENTES_ORIGEM.json`. Marcas e imagens identificam os presentes da plataforma.
- **Pulso Batida 0.2.1**: captador Android do projeto local; APK e código-fonte incluídos. Usa a captura de reprodução autorizada pelo Android, sem enviar arquivos de áudio ao servidor.
- Logo do Zig, piloto, regras, efeitos, interface e trilha instrumental original preparados para este projeto. A trilha não incorpora fonogramas comerciais ou a música enviada em projetos anteriores.

- **FFmpeg**: executável externo da instalação Termux/sistema, com libx264 e AAC. Não é distribuído neste ZIP; a licença do binário depende das opções de compilação e bibliotecas, incluindo libx264 GPL. O instalador usa o pacote oficial disponível no Termux.
