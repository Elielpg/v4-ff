# Evolução V0.5 — Parque do Caos

## Implementado

A V0.5 evolui a V0.4 existente. O servidor continua Node.js e a cena continua Babylon.js, com jogo no Chrome/WebView e compatibilidade de instalação com Termux.

- Parque original no deserto: piscina, barracas, cactos, rochas, calçadas, luminárias, oito vagões sobre trilhos contínuos e pódios.
- Corpo tubular contínuo da cobra, com curvas e cauda afilada; movimento e crescimento conservam os intervalos lentos da V0.4.
- Avatares com proporções de desenho, cabelos, acessórios, sobrancelhas, nariz, braços e pernas articulados. A foto recebida fica no peito; há alternativa com a inicial.
- Visitantes livres circulam ou aparecem nos vagões; os líderes livres usam os pódios. Gaiola e banquete conservam suas poses e regras.
- Canhão com fila gratuita ATIRAR, prioridade configurável por presente, preparação, voo em arco, giro, pouso, comemoração, partículas e som próprios.
- Top 6 integrado aos pontos; comentários curtos nos balões e nomes projetados também na captura RTMP.
- Câmera automática com planos da cobra, parque, gaiola, visitantes, canhão e pódios. Botão CENA AMPLA preservado.
- 28 WAVs PT-BR prontos. Qwen e Piper existentes continuam disponíveis. A voz não dirige a física ou executa comandos do sistema.
- Reutilização de buffers gráficos e limite explícito de 192 avatares renderizados. Atlas de 256 retratos; perfis persistidos continuam limitados a 1.500.
- Estado do canhão salvo com marcadores de lançamento e pouso para evitar nova recompensa após retomada do mesmo estado.

## Mantido

50 pessoas na gaiola; fuga por 500 curtidas próprias OU uma rosa OU dez comentários. Compartilhar muda a cor sem libertar. Presentes mantêm os efeitos anteriores. Tabuleiro 18 × 28, piloto, donos dos segmentos, revanche, ranking por time, demos isoladas, playlists, dia/noite, IA local, ponte de batidas, app Android existente, RTMP do navegador e supervisor com limite de recuperação.

## Diferenças intencionais da referência

O parque foi redesenhado com recursos próprios. A associação padrão de GG ao canhão, a recarga e os pontos são configurados por nós. A gaiola e as missões foram preservadas conforme as regras já escolhidas pelo usuário; não foram afirmadas como características do jogo gravado.

## Limites

Animações são procedurais; não são captura de movimento. A cobra mantém o caminho matemático em grade, embora o corpo visual seja contínuo. Os personagens não têm navegação física complexa nem uma simulação completa de parque. Pódios são uma apresentação dos líderes já livres; estar em primeiro não remove a missão da gaiola. Atrações não dão dinheiro nem prometem audiência.

O APK de captura é o mesmo já entregue, sem nova compilação ou instalação de clonador. Veja `PENDENCIAS_V0_5.md` e `RELATORIO_TESTES_V0_5.md`.
