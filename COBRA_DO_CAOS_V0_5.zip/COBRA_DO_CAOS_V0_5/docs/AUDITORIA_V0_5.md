# Auditoria antes da evolução V0.5

Base: Cobra do Caos V0.4.0 existente. A cópia estável e seu ZIP foram preservados antes das edições, em separado da pasta V0.5. Não houve migração de engine. Os 61 testes da base passaram antes de alterar o comportamento.

## Achados e decisões

| Arquivos | Achado | Alteração e impacto |
|---|---|---|
| `server/engine.mjs`, `cage.mjs`, `identity.mjs` | Regras e conciliação de identidade já testadas; reescrever causaria perda de missões | Manter piloto/gaiola; compor um módulo `ParkSystem` independente |
| `server/storage.mjs`, `scripts/supervisor.mjs` | Persistência atômica e recuperação limitada existentes | Salvar a atração no mesmo estado e nos eventos de transição; preservar o supervisor |
| `public/world.js` | Corpo desenhado com cápsulas separadas | Gancho para malha tubular contínua com topologia e buffers reutilizados |
| `public/cage-stage.js` | Retratos acima da cabeça; partes instanciadas; capacidade por parte insuficiente para acrescentar pernas e sobrancelhas em público numeroso | Fotos no peito, cabeça expressiva, atlas existente, capacidade explícita e uploads parciais de matrizes |
| `public/cinematic-world.js`, `scene-design.js` | Câmera só conhecia ilha/gaiola | Novo plano geral do parque, pódio, preparação, voo e pouso; limite de altura e opção de movimento reduzido |
| `public/studio.js` | Elementos DOM dos nomes não pertenciam à captura do canvas | Projetar nomes/comentários também no compositor RTMP; cena em tela inteira |
| `public/style.css` | Altura mínima herdada excedia a tela horizontal | HUD compacto adaptativo; botões conferidos em quatro tamanhos |
| `server/index.mjs` | Salvar voz podia sobrescrever outras configurações | Persistir voz e parque juntos; API validada do canhão |
| `server/host.mjs` | Texto tem contexto de ilha, sem a atração nova | Contexto do parque, falas próprias e prioridade limitada aos líderes; piloto permanece fora da IA |
| `tools/update.mjs`, `build-release.py` | Manifesto e listas aceitavam até V0.4 | Atualizador e pacote V0.5; backup e reversão mantidos |

## Riscos identificados

- Captura física e desempenho sustentado no Realme GT3 não podem ser comprovados com Chromium Cloud. Requerem uma transmissão real no aparelho.
- Fotos dependem de CORS do CDN e do evento correto do TikTok; a inicial continua como alternativa quando a imagem falha.
- O Android pode encerrar todo o Termux. O supervisor dentro do mesmo aplicativo não consegue sobreviver a isso.
- O parque e a água são gráficos procedurais originais. Não foram extraídos modelos, texturas, código ou falas do vídeo de referência.
- Canhão, pontos e recarga são regras explícitas desta implementação. O vídeo não revela os gatilhos nem a fórmula de pontos do jogo original.
