import {readFile,access,mkdir,open} from 'node:fs/promises';import {constants} from 'node:fs';import {spawn} from 'node:child_process';import {createConnection} from 'node:net';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {localRequest} from '../server/host.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),LOCAL=path.resolve(process.env.BEN10_LOCAL_ROOT||path.join(os.homedir(),'.local/share/ben10-local-ai')),GAME=Number(process.env.PORT||3500),children=[];let stopping=false;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const json=async(port,url,body)=>{const r=await localRequest(port,url,{body,timeout:2500});if(r.status!==200)throw Error('Serviço sem resposta');return JSON.parse(r.data);};
const portOpen=port=>new Promise(resolve=>{const s=createConnection({host:'127.0.0.1',port});const done=x=>{s.destroy();resolve(x);};s.once('connect',()=>done(true));s.once('error',()=>done(false));s.setTimeout(600,()=>done(false));});
async function ready(port,predicate,child,label){for(let i=0;i<180&&!stopping;i++){if(child&&(child.exitCode!==null||child.signalCode!==null||child.startError))throw Error(label+' encerrou. Confira logs/ia-*.log.');try{if(predicate(await json(port,'/health')))return;}catch{}if(i%10===0)console.log('Carregando '+label+'…');await wait(1000);}throw Error(label+' não ficou pronto.');}
async function launch(command,args,log){const file=await open(path.join(ROOT,'logs',log),'a');const child=spawn(command,args,{cwd:ROOT,env:process.env,detached:true,stdio:['ignore',file.fd,file.fd]});child.on('error',e=>child.startError=e);children.push(child);await file.close();return child;}
async function stop(){if(stopping)return;stopping=true;for(const c of children)if(c.exitCode===null)try{process.kill(-c.pid,'SIGTERM');}catch{c.kill('SIGTERM');}}
process.on('SIGINT',()=>void stop());process.on('SIGTERM',()=>void stop());
async function main(){
 const health=await json(GAME,'/api/health').catch(()=>{throw Error('Abra primeiro o jogo com bash start.sh em outra sessão.');});if(health.project!=='cobra-do-caos')throw Error('A porta não pertence à Cobra do Caos.');
 const host=await json(GAME,'/api/host');let textPort=host.config.textPort,voicePort=host.config.voicePort,model=host.config.model;let textReady=false,voiceReady=false;
 try{textReady=(await json(textPort,'/health')).status==='ok';}catch{}
 try{const v=await json(voicePort,'/health');voiceReady=v.ready===true&&/piper|faber/i.test(v.model||'');}catch{}
 let manifest;try{manifest=JSON.parse(await readFile(path.join(LOCAL,'install.json'),'utf8'));}catch{if(!textReady||!voiceReady)throw Error('Instalação local não encontrada em '+LOCAL+'. As falas prontas continuam funcionando. Configure serviços já existentes no painel ou conclua a instalação local anterior.');}
 await mkdir(path.join(ROOT,'logs'),{recursive:true});
 if(!textReady){if(await portOpen(textPort))throw Error('Porta do texto ocupada por outro serviço. Ajuste no painel.');const binary=path.join(LOCAL,'llama.cpp/build/bin/llama-server');await access(binary,constants.X_OK);await access(manifest.textModel);const c=await launch(binary,['--model',manifest.textModel,'--alias',model,'--host','127.0.0.1','--port',String(textPort),'--ctx-size','2048','--threads','3','--threads-batch','3','--batch-size','128','--ubatch-size','128','--parallel','1','--threads-http','2','--no-webui','--reasoning','off'],'ia-texto.log');await ready(textPort,v=>v.status==='ok',c,'Qwen local');}
 if(!voiceReady){
  if(await portOpen(voicePort)){voicePort=8083;if(await portOpen(voicePort))throw Error('Portas de voz ocupadas. Selecione outra no painel.');}
  const modelFile=path.resolve(manifest.voiceModel||''),relative=path.relative(LOCAL,modelFile);if(relative.startsWith('..')||path.isAbsolute(relative)||!relative.endsWith('.onnx'))throw Error('Modelo Piper da instalação anterior não localizado.');await access(modelFile);await access(modelFile+'.json');
  const c=await launch('proot-distro',['login','--bind',LOCAL+':/cobra-data','--bind',path.join(ROOT,'tools')+':/cobra-worker','ben10-ai','--','/opt/ben10-voice/bin/python','/cobra-worker/tts_worker.py','--model','/cobra-data/'+relative.split(path.sep).join('/'),'--cache-dir','/cobra-data/cobra-voice-cache','--port',String(voicePort)],'ia-voz.log');await ready(voicePort,v=>v.ready===true,c,'voz Piper');
 }
 await json(GAME,'/api/host-config',{enabled:true,voiceEnabled:true,textPort,voicePort,model});console.log('IA e voz locais prontas para a Cobra do Caos.\nMantenha esta sessão aberta. Ctrl+C encerra somente serviços iniciados por este comando.');
 while(!stopping){for(const c of children)if(c.exitCode!==null||c.signalCode!==null||c.startError)throw Error('Um serviço de IA encerrou. O jogo continua; confira os logs.');await wait(1000);}
}
main().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(stop);
