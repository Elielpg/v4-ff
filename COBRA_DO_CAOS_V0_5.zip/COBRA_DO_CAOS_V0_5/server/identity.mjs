const clean=x=>x==null?'':String(x).slice(0,64);
export class IdentityBook{
 constructor(saved=[]){this.aliases=new Map((Array.isArray(saved)?saved:[]).filter(x=>Array.isArray(x)&&typeof x[0]==='string'&&typeof x[1]==='string').slice(-6000));}
 resolve(e,players,merge){const raw=clean(e.user),unique=clean(e.uniqueId),platform=clean(e.platformId);if(!raw&&!unique&&!platform)return null;
  const p=platform?this.aliases.get('platform:'+platform):null,u=unique?this.aliases.get('unique:'+unique):null;
  const named=unique&&players.has(unique)?unique:null,oldRaw=raw&&!(platform&&!unique&&raw===platform)&&players.has(raw)?raw:null;
  let key=named||u||p||oldRaw||this.aliases.get('user:'+raw)||(unique|| (platform?'tiktok:'+platform:raw));
  if(unique&&platform)for(const other of new Set([p,u,named,oldRaw].filter(Boolean)))if(other!==key&&players.has(other)){merge(key,other);for(const [a,v]of this.aliases)if(v===other)this.aliases.set(a,key);}
  for(const alias of [platform&&'platform:'+platform,unique&&'unique:'+unique,raw&&'user:'+raw].filter(Boolean))this.aliases.set(alias,key);
  while(this.aliases.size>6000)this.aliases.delete(this.aliases.keys().next().value);return key;
 }
 save(){return [...this.aliases];}
}
