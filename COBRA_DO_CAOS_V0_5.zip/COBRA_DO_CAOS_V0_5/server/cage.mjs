import {createHash} from 'node:crypto';
import {CAGE_RULES as R,CENTER_CELLS} from '../public/cage-rules.js';
import {giftRule,hash} from '../public/rules.js';
const integer=(v,max=1e12)=>Math.max(0,Math.min(max,Math.floor(Number(v)||0)));
const id=v=>typeof v==='string'?v.slice(0,64):null;
const avatar=v=>{try{const u=new URL(v);return u.protocol==='https:'&&u.href.length<1500?u.href:null;}catch{return null;}};
export class CageSystem{
 constructor({now=Date.now,emit=()=>{},saved=null}={}){
  Object.assign(this,{now,emit,records:new Map(),members:[],escapedHashes:new Set(),session:1,batches:0,captured:0,escaped:0,fed:0,unattributedLikes:0,feasts:[],growth:[],overflow:0,overflowReadyAt:0,lastFeed:0,shareUntil:0,epoch:now()});
  if(saved){this.escapedHashes=new Set((Array.isArray(saved.escapedHashes)?saved.escapedHashes:[]).filter(h=>/^[a-f0-9]{24}$/.test(h)).slice(-50000));for(const key of ['session','batches','captured','escaped','fed','unattributedLikes','overflowReadyAt','shareUntil','epoch'])this[key]=integer(saved[key]);this.session=Math.max(1,this.session);this.epoch=this.epoch||now();
   for(const p of (Array.isArray(saved.records)?saved.records:[]).slice(-R.maxRecords)){const key=id(p.id);if(!key)continue;this.records.set(key,{id:key,name:String(p.name||key).slice(0,36),avatar:avatar(p.avatar),state:['caged','escaped','food'].includes(p.state)?p.state:'food',likes:integer(p.likes,R.likes),comments:integer(p.comments,R.comments),at:integer(p.at),escapedAt:integer(p.escapedAt),reason:['likes','rose','comments'].includes(p.reason)?p.reason:null});}
   this.members=[...new Set((Array.isArray(saved.members)?saved.members:[]).filter(key=>this.records.get(key)?.state==='caged'))].slice(0,R.capacity);
   this.growth=(Array.isArray(saved.growth)?saved.growth:[]).slice(0,R.maxGrowth).map(id);
   for(const f of (Array.isArray(saved.feasts)?saved.feasts:[]).slice(0,R.maxFeasts)){const ids=(Array.isArray(f.ids)?f.ids:[]).map(id).filter(Boolean).slice(0,R.capacity);if(ids.length)this.feasts.push({id:integer(f.id),ids,at:integer(f.at),readyAt:integer(f.readyAt)});}
   this.overflow=integer(saved.overflow,R.maxOverflow);
  }
 }
 capture(p){let record=this.records.get(p.id);if(record){record.name=p.name;record.avatar=p.avatar||record.avatar;return record;}
  if(this.members.length>=R.capacity)this.flush();
  if(this.records.size>=R.maxRecords){const old=[...this.records.values()].find(r=>r.state!=='caged');if(old)this.records.delete(old.id);}
  record={id:p.id,name:p.name,avatar:p.avatar,state:this.escapedHashes.has(this.fingerprint(p.id))?'escaped':'caged',likes:0,comments:0,at:this.now(),reason:null};this.records.set(p.id,record);if(record.state==='escaped')return record;this.members.push(p.id);this.captured++;this.emit('cageEnter',{user:p.id,name:p.name,avatar:p.avatar,count:this.members.length});return record;
 }
 event(p,e,count){const r=this.capture(p);if(r.state!=='caged')return;
  if(e.type==='like')r.likes=Math.min(R.likes,r.likes+count);
  if(e.type==='comment'&&String(e.text||'').trim())r.comments=Math.min(R.comments,r.comments+1);
  if(e.type==='gift'&&count>0&&giftRule(e.gift,e.giftId)?.id==='rose')this.escape(r,'rose');
  else if(r.likes>=R.likes)this.escape(r,'likes');else if(r.comments>=R.comments)this.escape(r,'comments');
 }
 fingerprint(key){return createHash('sha256').update(key).digest('hex').slice(0,24);}
 escape(r,reason){if(r.state!=='caged')return false;r.state='escaped';r.reason=reason;r.escapedAt=this.now();this.escapedHashes.add(this.fingerprint(r.id));while(this.escapedHashes.size>50000)this.escapedHashes.delete(this.escapedHashes.values().next().value);this.members=this.members.filter(x=>x!==r.id);this.escaped++;this.emit('cageEscape',{user:r.id,name:r.name,avatar:r.avatar,reason,count:this.members.length});return true;}
 flush(){if(this.members.length<R.capacity)return false;const ids=this.members.splice(0,R.capacity),at=this.now();this.batches++;this.fed+=ids.length;for(const key of ids){const p=this.records.get(key);if(p)p.state='food';}
  const f={id:this.batches,ids,at,readyAt:at+R.dropMs};if(this.feasts.length<R.maxFeasts)this.feasts.push(f);else{this.overflow=Math.min(R.maxOverflow,this.overflow+ids.length);this.overflowReadyAt=f.readyAt;}
  this.emit('cageBanquet',{batch:f.id,count:ids.length,at,readyAt:f.readyAt,people:ids.map(key=>this.person(key))});return true;
 }
 person(key){const p=this.records.get(key);return p?{...p,seed:hash(p.id)}:{id:key,name:key,avatar:null,seed:hash(key),state:'food',likes:0,comments:0};}
 targets(){return this.feasts.some(f=>f.readyAt<=this.now())||this.overflow&&this.overflowReadyAt<=this.now()?CENTER_CELLS:[];}
 collect(cell){if(!CENTER_CELLS.includes(cell)||this.now()-this.lastFeed<R.feedCooldownMs)return 0;
  const index=this.feasts.findIndex(f=>f.readyAt<=this.now());let ids=[];
  if(index>=0){const feast=this.feasts[index];if(this.growth.length+feast.ids.length>R.maxGrowth)return 0;ids=this.feasts.splice(index,1)[0].ids;}
  else if(this.overflow>0&&this.overflowReadyAt<=this.now()){const n=Math.min(R.capacity,this.overflow,R.maxGrowth-this.growth.length);if(!n)return 0;ids=Array(n).fill(null);this.overflow-=n;}
  if(!ids.length)return 0;this.growth.push(...ids);this.lastFeed=this.now();this.emit('banquetEat',{count:ids.length,cell});return ids.length;
 }
 share(p){this.shareUntil=this.now()+R.shareMs;this.emit('shareColor',{user:p.id,name:p.name,avatar:p.avatar,until:this.shareUntil});}
 reset(){this.session++;this.records.clear();this.escapedHashes.clear();this.members=[];this.captured=0;this.escaped=0;this.fed=0;this.unattributedLikes=0;this.emit('cageReset',{session:this.session});}
 merge(keep,remove){const a=this.records.get(keep),b=this.records.get(remove);if(!b)return;if(!a){b.id=keep;this.records.set(keep,b);}else{a.likes=Math.min(R.likes,a.likes+b.likes);a.comments=Math.min(R.comments,a.comments+b.comments);if(b.state==='escaped'||a.state==='escaped'){a.state='escaped';a.reason=a.reason||b.reason;}else if(b.state==='food'||a.state==='food')a.state='food';}
  this.records.delete(remove);this.members=[...new Set(this.members.map(x=>x===remove?keep:x))].filter(x=>this.records.get(x)?.state==='caged');for(const f of this.feasts)f.ids=[...new Set(f.ids.map(x=>x===remove?keep:x))];this.growth=this.growth.map(x=>x===remove?keep:x);const p=this.records.get(keep);if(p?.state==='escaped')this.escapedHashes.add(this.fingerprint(keep));if(p?.state==='caged'){if(p.likes>=R.likes)this.escape(p,'likes');else if(p.comments>=R.comments)this.escape(p,'comments');}
 }
 public(){const now=this.now();return {capacity:R.capacity,count:this.members.length,missing:R.capacity-this.members.length,session:this.session,captured:this.captured,escaped:this.escaped,fed:this.fed,batches:this.batches,unattributedLikes:this.unattributedLikes,members:this.members.map(key=>this.person(key)),recentEscapes:[...this.records.values()].filter(p=>p.state==='escaped').sort((a,b)=>(b.escapedAt||0)-(a.escapedAt||0)).slice(0,6).map(p=>this.person(p.id)),food:this.feasts.reduce((sum,f)=>sum+f.ids.length,0)+this.overflow,growth:this.growth.length,shareUntil:this.shareUntil,epoch:this.epoch,feasts:this.feasts.map((f,i)=>({...f,people:i>=this.feasts.length-2&&f.readyAt>now-350?f.ids.slice(0,R.capacity).map(key=>this.person(key)):[],landed:f.readyAt<=now}))};}
 save({omitAvatars=false}={}){return {escapedHashes:[...this.escapedHashes],session:this.session,batches:this.batches,captured:this.captured,escaped:this.escaped,fed:this.fed,unattributedLikes:this.unattributedLikes,records:[...this.records.values()].map(p=>omitAvatars?{...p,avatar:null}:p),members:this.members,feasts:this.feasts,growth:this.growth,overflow:this.overflow,overflowReadyAt:this.overflowReadyAt,shareUntil:this.shareUntil,epoch:this.epoch};}
}
