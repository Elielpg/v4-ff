// Original Hamiltonian pilot. Social AI never chooses movement or executes code.
export function cycle(cols,rows){if(cols<2||rows<2||rows%2)throw Error('Use pelo menos duas colunas e um número par de linhas');const a=[0];for(let y=0;y<rows;y++){if(y%2===0)for(let x=1;x<cols;x++)a.push(y*cols+x);else for(let x=cols-1;x>=1;x--)a.push(y*cols+x);}for(let y=rows-1;y>0;y--)a.push(y*cols);return a;}
export class Pilot{
 constructor(cols,rows){this.cols=cols;this.rows=rows;this.path=cycle(cols,rows);this.size=cols*rows;this.index=new Map(this.path.map((p,i)=>[p,i]));}
 distance(a,b){return (this.index.get(b)-this.index.get(a)+this.size)%this.size;}
 neighbors(cell){const x=cell%this.cols,y=Math.floor(cell/this.cols);return [x>0?cell-1:-1,x<this.cols-1?cell+1:-1,y>0?cell-this.cols:-1,y<this.rows-1?cell+this.cols:-1].filter(c=>c>=0);}
 valid(body){if(!Array.isArray(body)||body.length<3||body.length>this.size||new Set(body).size!==body.length||body.some(c=>!this.index.has(c)))return false;let span=0;for(let i=1;i<body.length;i++){if(!this.neighbors(body[i]).includes(body[i-1]))return false;span+=this.distance(body[i],body[i-1]);}return span<this.size;}
 next(body,foods){const head=body[0],tail=body.at(-1),gap=this.distance(head,tail),successor=this.path[(this.index.get(head)+1)%this.size];let target=this.size;for(const f of foods){const d=this.distance(head,typeof f==='number'?f:f.cell);if(d>0)target=Math.min(target,d);}let best=successor,bestD=1;for(const n of this.neighbors(head)){const d=this.distance(head,n);if(d>bestD&&d<gap&&d<=target&&!body.includes(n)){best=n;bestD=d;}}return best;}
}
