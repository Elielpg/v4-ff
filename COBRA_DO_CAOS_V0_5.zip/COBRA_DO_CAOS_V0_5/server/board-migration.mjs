import {Pilot} from './pilot.mjs';
import {RULES} from '../public/rules.js';
/** Repositions a legacy round on the new cycle without changing earned progress. */
export function migrateBoardState(saved,cols=RULES.cols,rows=RULES.rows){
 if(!saved||saved.project!=='cobra-do-caos'||saved.schema!==1)return saved;
 const grid=saved.grid||{cols:12,rows:18};
 if(grid.cols===cols&&grid.rows===rows)return saved;
 if(!Number.isInteger(grid.cols)||!Number.isInteger(grid.rows)||grid.cols<2||grid.rows<2||grid.cols>64||grid.rows>64||grid.rows%2)return {...saved,body:[],grid:{cols,rows}};
 const old=new Pilot(grid.cols,grid.rows),next=new Pilot(cols,rows);
 if(!old.valid(saved.body)||saved.body.length>next.size)return {...saved,body:[],grid:{cols,rows}};
 const head=Math.floor(old.index.get(saved.body[0])/old.size*next.size),body=saved.body.map((_,i)=>next.path[(head-i+next.size)%next.size]),used=new Set(body);
 const remap=list=>{const out=[];for(const item of Array.isArray(list)?list:[]){if(!old.index.has(item.cell))continue;const at=Math.floor(old.index.get(item.cell)/old.size*next.size);for(let n=0;n<next.size;n++){const cell=next.path[(at+n)%next.size];if(!used.has(cell)){used.add(cell);out.push({...item,cell});break;}}}return out;};
 const foods=remap(saved.foods),bombs=remap(saved.bombs);
 return {...saved,grid:{cols,rows},body,foods,bombs,migratedFrom:{cols:grid.cols,rows:grid.rows}};
}
