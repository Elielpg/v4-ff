from pathlib import Path
import subprocess,json,tempfile,time,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];NATIVE=ROOT/'android-live';tmp=Path(tempfile.mkdtemp(prefix='cobra-native-rtmp-'));receiver=None
try:
 classes=tmp/'classes';classes.mkdir()
 sources=list((NATIVE/'app/src/br/caos/live/rtmp').glob('*.java'))+[NATIVE/'app/src/br/caos/live/BeatMeter.java']+list((NATIVE/'tests').glob('*.java'))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-d',str(classes),*map(str,sources)],check=True,capture_output=True)
 unit=subprocess.run(['java','-cp',str(classes),'ProtocolTest'],check=True,capture_output=True,text=True)
 fixture=tmp/'source.flv';target=tmp/'received.flv'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=320x568:rate=15','-f','lavfi','-i','sine=frequency=540:sample_rate=44100','-t','7','-c:v','libx264','-preset','ultrafast','-tune','zerolatency','-pix_fmt','yuv420p','-profile:v','baseline','-g','30','-c:a','aac','-b:a','96k','-ac','1','-f','flv',str(fixture)],check=True)
 receiver=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-listen','1','-timeout','15','-i','rtmp://127.0.0.1:19359/live/check-native','-c','copy','-f','flv',str(target)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 time.sleep(.5)
 publish=subprocess.run(['java','-cp',str(classes),'PublishFlv','rtmp://127.0.0.1:19359/live','check-native',str(fixture)],capture_output=True,text=True,timeout=45)
 if publish.returncode:raise RuntimeError('Java RTMP: '+publish.stderr[-3000:])
 out,err=receiver.communicate(timeout=15)
 probe=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(target)],capture_output=True,text=True,check=True)
 data=json.loads(probe.stdout);streams=data['streams'];video=next(s for s in streams if s['codec_type']=='video');audio=next(s for s in streams if s['codec_type']=='audio');duration=float(data['format']['duration']);assert video['codec_name']=='h264' and audio['codec_name']=='aac' and duration>6
 pcm=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(target),'-vn','-f','s16le','-ac','1','-ar','16000','pipe:1'],capture_output=True,check=True).stdout
 import array,math
 a=array.array('h');a.frombytes(pcm);rms=(sum(x*x for x in a)/len(a))**.5;db=20*math.log10(max(1,rms)/32768);assert db>-55
 report={'ok':True,'protocol':json.loads(unit.stdout),'publisher':json.loads(publish.stdout),'received':{'video':video['codec_name'],'audio':audio['codec_name'],'width':video['width'],'height':video['height'],'duration':duration,'bytes':target.stat().st_size,'audioDbFS':round(db,3)},'apkSha256':hashlib.sha256((ROOT/'public/downloads/CAOS_LIVE_V0_1.apk').read_bytes()).hexdigest(),'scope':'Cliente Java RTMP real → receptor FFmpeg local. Confere protocolo e mídia H.264/AAC. Não executa MediaProjection, EGL ou MediaCodec no Android nem transmite ao TikTok.'}
 (ROOT/'docs/NATIVE_RTMP_CHECK.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,indent=2,ensure_ascii=False))
finally:
 if receiver and receiver.poll() is None:receiver.terminate();receiver.wait(timeout=5)
 shutil.rmtree(tmp)
