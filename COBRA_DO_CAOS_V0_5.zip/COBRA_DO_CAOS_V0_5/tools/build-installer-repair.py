from pathlib import Path
import hashlib,zipfile,shutil,json
root=Path(__file__).resolve().parents[1];out=root.parent/'artifacts';name='COBRA_REPARO_APT_V0_1_1';stage=out/(name+'_stage')
if stage.exists():shutil.rmtree(stage)
dest=stage/name;(dest/'payload/scripts').mkdir(parents=True)
shutil.copy2(root/'tools/installer-repair.sh',dest/'REPARAR.sh')
files=['install.sh','scripts/termux-packages.sh']
for file in files:shutil.copy2(root/file,dest/'payload'/file)
(dest/'payload/MANIFEST.sha256').write_text(''.join(hashlib.sha256((root/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in files))
(dest/'LEIA_ME.txt').write_text('Reparo 0.1.1 do instalador da Cobra do Caos.\nNa pasta do jogo, execute bash caminho/REPARAR.sh "$PWD"; depois bash install.sh && bash start.sh.\nSomente install.sh e scripts/termux-packages.sh são alterados, com backup.\nFontes APT, chaves, dados e modelos permanecem intactos.\nApenas a fonte principal já configurada é consultada, com assinaturas exigidas.\nFFmpeg pendente não impede iniciar o jogo, mas impede transmitir RTMP.\n')
archive=out/(name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(dest.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(stage))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(out/(name+'.sha256')).write_text(sha+'  '+archive.name+'\n');print(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha},indent=2))
