#!/usr/bin/env bash
set -euo pipefail
task_bundle="$(cd "$(dirname "$0")" && pwd -P)"
task_target="${1:-$PWD}"
node "$task_bundle/tools/update.mjs" "$task_bundle" "$task_target"
