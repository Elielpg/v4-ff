package br.caos.live;
public final class BeatMeter {
 private final double high,low,highDetail,lowDetail;
 private double previous,hp,lp,lp2,sum,full,detailHp,detailHp2,previousDetail,detailLp,detailSum;private int count,windowIndex;private final double[] bassWindow=new double[3],detailWindow=new double[3];
 public double level,detail;
 public BeatMeter(int rate){high=Math.exp(-2*Math.PI*35/rate);low=1-Math.exp(-2*Math.PI*240/rate);highDetail=Math.exp(-2*Math.PI*300/rate);lowDetail=1-Math.exp(-2*Math.PI*5500/rate);}
 public double push(double value){
  hp=high*(hp+value-previous);detailHp=highDetail*(detailHp+value-previous);previous=value;detailHp2=highDetail*(detailHp2+detailHp-previousDetail);previousDetail=detailHp;
  lp+=low*(hp-lp);lp2+=low*(lp-lp2);detailLp+=lowDetail*(detailHp2-detailLp);
  sum+=lp2*lp2;detailSum+=detailLp*detailLp;full+=value*value;
  if(++count<512)return -1;
  bassWindow[windowIndex]=sum/count;detailWindow[windowIndex]=detailSum/count;windowIndex=(windowIndex+1)%3;
  double energy=Math.sqrt((bassWindow[0]+bassWindow[1]+bassWindow[2])/3);detail=Math.sqrt((detailWindow[0]+detailWindow[1]+detailWindow[2])/3);level=Math.sqrt(full/count);
  sum=0;detailSum=0;full=0;count=0;return energy;
 }
}
