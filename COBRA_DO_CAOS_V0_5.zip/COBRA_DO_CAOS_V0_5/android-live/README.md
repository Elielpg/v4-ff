# Caos Live 0.1 · captura Android para Cobra do Caos V0.3

APK entregue em `../public/downloads/CAOS_LIVE_V0_1.apk`. Android 10+ (minSdk 29), alvo Android 15 (35). Pacote `br.caos.live`, separado do antigo Pulso Batida. A fonte completa está nesta pasta; não é necessário compilá-la para usar o APK entregue.

## Usar

Execute o servidor no Termux, abra o app, preencha endereço e chave, escolha perfil e autorize a captura do Android. O app abre a página `http://127.0.0.1:3500/?v=0.3.0` em tela cheia. Ative o som com um toque e conecte o @ ao vivo pelo painel do jogo. O app não inicia o Node nem baixa modelos de IA.

Perfis: 540 × 960/24 FPS, 720 × 1280/30 FPS, 1080 × 1920/30 FPS ou 1280 × 720/30 FPS. Esses são parâmetros de saída, sem benchmark no telefone. Há corte de topo/rodapé até 30% e laterais até 20%; o restante é ajustado sem distorção, com barras quando necessário. A captura acompanha alterações de tamanho/rotação do display. A opção CENA AMPLA pertence ao jogo e permite uma área maior do cenário.

Áudio interno, microfone e sem áudio são alternativas. O áudio interno tenta estéreo AAC/128 kbps, com alternativa mono se a captura estéreo não for aceita; o microfone usa mono. AudioPlaybackCapture depende da autorização do app de origem. No modo interno, a ponte opcional reaproveita o mesmo PCM para medir graves/agudos e enviar características ao jogo local. A falha dessa ponte não encerra o envio de vídeo. A compensação Bluetooth é ajustada no painel Música do jogo.

## Fluxo

- `MainActivity`: configuração privada em memória, solicitações de permissão, início e parada explícitos.
- `GameActivity`: WebView local, tela cheia, seleção de músicas e reutilização da página ao retornar do painel.
- `CaptureService`: serviço em primeiro plano, MediaProjection, MediaCodec H.264/AAC, leitura de áudio e encerramento dos recursos.
- `ScreenRenderer`: contexto EGL próprio, SurfaceTexture do display, composição/corte proporcional na superfície do codificador e repetição do último quadro nos intervalos de saída.
- `RhythmRelay` e `BeatMeter`: apenas medidas de áudio para localhost; fila de 64 amostras e término após falhas limitadas, independente do RTMP.
- `rtmp/`: URI validada, handshake, AMF0, chunks, controles, AVC/AAC em FLV e cliente RTMP/RTMPS. Fila de 240 pacotes com limite de 8 MiB; saturação ou escrita parada encerram a transmissão com mensagem, sem ciclo de reinícios.

A chave não vai a arquivos, snapshots, servidor Node, vídeo ou diagnóstico. A tela MainActivity tem FLAG_SECURE. Não há ponte JavaScript com acesso à chave. O serviço não é exportado e usa START_NOT_STICKY: uma captura revogada pelo Android precisa de nova autorização. A notificação permite encerrar sem voltar ao app. O jogo no Termux é um processo separado e continua se a transmissão parar.

O Android admite apenas uma sessão de captura desse tipo por vez. Evite executar Pulso Batida com MediaProjection junto do Caos Live; a ponte de ritmo integrada elimina essa necessidade. O RTMP do navegador também deve ficar desligado enquanto usar o app.

## Compilar

Java com módulos `jdk.compiler` e `jdk.jartool`, Android platform 35 e build-tools 35 oficiais. O script espera `<SDK>/android-35/android.jar` e `<SDK>/android-15/{aapt2,d8,zipalign,apksigner}`, como nas pastas dos ZIPs oficiais extraídos. Informe o SDK pela variável:

```bash
CAOS_ANDROID_SDK=/caminho/do/sdk python3 android-live/build.py --output public/downloads/CAOS_LIVE_V0_1.apk
```

A primeira compilação cria sua chave em `android-live/private/`. Guarde-a fora de publicações para assinar suas futuras compilações com o mesmo certificado. Chaves, senhas, SDK, classes e cache não fazem parte do ZIP de entrega. Não há dependência Gradle/Maven nem download de biblioteca durante a compilação.

## Evidências e limites

`docs/ANDROID_LIVE_BUILD.json`: compilação, manifesto e assinatura do APK. `docs/NATIVE_RTMP_CHECK.json`: testes JVM de protocolo, framing e filtro, além de envio real para um receptor RTMP local, com vídeo H.264 e som AAC verificados por ffprobe/FFmpeg. O fixture é um arquivo conhecido; não é uma captura de tela Android.

MediaProjection, permissões, MediaCodec, EGL, captura de GreenTube, rotação e sessão prolongada ainda precisam ser verificados no GT3. Não foi feita transmissão ao TikTok. Qualidade de rede, disponibilidade de RTMP na conta e políticas de captura dos outros apps permanecem externas ao projeto.
