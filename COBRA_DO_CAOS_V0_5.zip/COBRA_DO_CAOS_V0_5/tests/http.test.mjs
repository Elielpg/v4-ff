import test from 'node:test';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {once} from 'node:events';import {mkdtemp,rm} from 'node:fs/promises';import os from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),wait=ms=>new Promise(r=>setTimeout(r,ms));
test('HTTP: demo/LIVE isoladas, controles, origem, SSE e retomada após reinício',async()=>{
 const data=await mkdtemp(path.join(os.tmpdir(),'cobra-http-')),port=37851,base='http://127.0.0.1:'+port;let child;
 const request=async(p,b,headers={})=>{const r=await fetch(base+p,{method:b===undefined?'GET':'POST',headers:{'content-type':'application/json',...headers},body:b===undefined?undefined:JSON.stringify(b)});return {status:r.status,json:await r.json()};};
 const start=async()=>{child=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),COBRA_DATA_DIR:data},stdio:'ignore'});for(let i=0;i<120;i++){if(child.exitCode!==null)throw Error('Servidor não iniciou');try{if((await request('/api/health')).status===200)return;}catch{}await wait(30);}throw Error('Servidor sem resposta');};
 const stop=async()=>{const done=once(child,'exit');child.kill('SIGTERM');await done;};
 try{
  await start();assert.equal((await request('/api/state')).json.running,false);
  assert.equal((await request('/api/test-event',{type:'comment',user:'ana',text:'HERÓI'})).status,200);
  assert.equal((await request('/api/mode',{mode:'live'})).json.players,0);
  assert.equal((await request('/api/test-event',{type:'gift',user:'ana',gift:'Rosa'})).status,403);assert.equal((await request('/api/test-cage-fill',{})).status,403);assert.equal((await request('/api/test-mission',{kind:'likes',user:'fake'})).status,403);assert.equal((await request('/api/state')).json.cage.count,0);
  assert.equal((await request('/api/bridge',{type:'like',count:100})).status,403);
  assert.equal((await request('/api/start',{}, {origin:'https://example.com'})).status,403);
  assert.equal((await request('/api/host-config',{textPort:22})).status,400);
  assert.equal((await request('/api/mode',{mode:'demo'})).json.players,1);
  const ac=new AbortController(),stream=await fetch(base+'/api/events',{signal:ac.signal});const first=await stream.body.getReader().read();assert.match(new TextDecoder().decode(first.value),/state/);ac.abort();
  await request('/api/start',{simulate:false});await wait(150);const paused=(await request('/api/stop',{})).json.stepNo;await wait(160);assert.equal((await request('/api/state')).json.stepNo,paused);
  await request('/api/start',{simulate:false});const bootBefore=(await request('/api/state')).json.bootId;await stop();await start();const restored=(await request('/api/state')).json;assert.equal(restored.running,true);assert.equal(restored.players,1);assert.equal(restored.cage.count,1);assert.equal(restored.cage.members[0].comments,1);assert.equal(restored.body.length>=8,true);assert.equal(restored.mode,'demo');assert.notEqual(restored.bootId,bootBefore);
  const sensitive=await fetch(base+'/data/live.json');assert.equal(sensitive.status,404);const traversal=await fetch(base+'/%2e%2e%2fpackage.json');assert.ok([403,404].includes(traversal.status));
 }finally{if(child&&child.exitCode===null)await stop();await rm(data,{recursive:true,force:true});}
});

test('HTTP: captador aceita lote e quadro único, preserva autenticação e aplica compensação',async()=>{
 const data=await mkdtemp(path.join(os.tmpdir(),'cobra-rhythm-http-')),port=37852,base='http://127.0.0.1:'+port;const child=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),COBRA_DATA_DIR:data},stdio:'ignore'});const post=async(route,b,token)=>{const r=await fetch(base+'/api/rhythm/'+route,{method:'POST',headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(b)});return {status:r.status,json:await r.json()};};
 try{let ready=false;for(let i=0;i<120;i++){try{if((await fetch(base+'/api/health')).ok){ready=true;break;}}catch{}await wait(30);}assert.ok(ready);const code=(await post('code',{})).json.code,token=(await post('pair',{code})).json.token;assert.match(token,/^[a-f0-9]{64}$/);assert.equal((await post('config',{offset:230})).json.offset,230);assert.equal((await post('config',{offset:500})).status,400);assert.equal((await post('frame',{frames:[]} ,token)).status,400);assert.equal((await post('frame',{frames:Array(25).fill({})},token)).status,400);
  const start=Date.now()-1440;for(let i=0;i<120;i+=12){const frames=[];for(let j=0;j<12;j++){const n=i+j;frames.push({energy:n%12<2?.45:.008,detail:n%6===0?.25:.002,level:.3,at:start+n*12,seq:n});}const r=await post('frame',{frames},token);assert.equal(r.status,200);assert.equal(r.json.frames,12);}
  const frame={energy:.01,detail:.005,level:.1,at:Date.now()+10,seq:120};assert.equal((await post('frame',frame,token)).status,200);assert.equal((await post('frame',{...frame,seq:121,at:Date.now()+30})).status,401);const state=await fetch(base+'/api/state').then(r=>r.json());assert.equal(state.rhythm.state,'listening');assert.ok(state.rhythm.pulses>0);assert.equal(state.rhythm.offset,230);assert.ok(!JSON.stringify(state).includes(token));
 }finally{if(child.exitCode===null){const done=once(child,'exit');child.kill('SIGTERM');await done;}await rm(data,{recursive:true,force:true});}
});
