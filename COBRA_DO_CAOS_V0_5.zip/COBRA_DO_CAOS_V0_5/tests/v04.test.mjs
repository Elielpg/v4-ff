import test from 'node:test';
import assert from 'node:assert/strict';
import {SnakeEngine} from '../server/engine.mjs';
import {Pilot} from '../server/pilot.mjs';
import {RULES} from '../public/rules.js';
import {CENTER_CELLS} from '../public/cage-rules.js';
import {movePhase,curvePosition,chewingEnvelope} from '../public/motion.js';
import {ShowHost,settings,AMBIENT_KEYS} from '../server/host.mjs';

test('V04: tabuleiro maior, ritmo lento e créditos de comida continuam limitados',()=>{
 let now=100000;const events=[],e=new SnakeEngine({now:()=>now,onAction:a=>events.push(a)});
 assert.equal(e.pilot.size,504);assert.equal(e.foods.length,1);assert.ok(e.stepMs()>=230);
 e.enqueue('pendingFood',null,100);assert.equal(e.foods.length,1);
 for(let i=0;i<40;i++){now+=50;e.tick();assert.ok(e.foods.length<=3);}
 assert.ok(e.stepNo<9);assert.ok(e.pendingFood.length>90);
 e.growth=Array(30).fill(null);let last=e.lastGrowthAt;
 for(let i=0;i<100;i++){now+=280;const before=e.body.length;e.step();if(e.body.length>before){assert.ok(now-last>=RULES.growthMs);last=now;}assert.ok(e.pilot.valid(e.body));}
 const eaten=events.find(a=>a.kind==='eat');assert.ok(eaten);assert.ok(eaten.displayAt>=eaten.at);
});

test('V04: migração 12x18 preserva donos, pontos e todas as comidas excedentes na fila',()=>{
 const p=new Pilot(12,18),body=p.path.slice(0,30).reverse(),foods=p.path.slice(40,72).map(cell=>({cell,owner:'ana'}));
 const saved={project:'cobra-do-caos',schema:1,body,owners:body.map(()=> 'ana'),foods,bombs:[],pendingFood:Array(180).fill('ana'),players:[{id:'ana',name:'Ana',likes:700,heroPoints:21}],likes:700,wins:3,round:4};
 const e=new SnakeEngine({saved});assert.equal(e.body.length,30);assert.ok(e.pilot.valid(e.body));assert.equal(e.foods.length,3);assert.equal(e.pendingFood.length,209);
 assert.equal(e.likes,700);assert.equal(e.wins,3);assert.equal(e.players.get('ana').heroPoints,21);assert.ok(e.owners.every(x=>x==='ana'));
 assert.deepEqual(e.save().grid,{cols:18,rows:28});assert.deepEqual(new SnakeEngine({saved:e.save()}).body,e.body);
 for(const cell of CENTER_CELLS){assert.ok(cell%18>=8&&cell%18<=9);assert.ok(Math.floor(cell/18)>=13&&Math.floor(cell/18)<=14);}
});

test('V04: interpolação visual chega às casas e curva sem saltos ou valores inválidos',()=>{
 const p={x:0,y:.57,z:0},a={x:1,y:.57,z:0},b={x:1,y:.57,z:1},n={x:1,y:.57,z:2};
 assert.deepEqual(curvePosition(p,a,b,n,0),a);assert.deepEqual(curvePosition(p,a,b,n,1),b);
 let before=a;for(let i=0;i<=100;i++){const v=curvePosition(p,a,b,n,i/100);assert.ok(Object.values(v).every(Number.isFinite));assert.ok(Math.hypot(v.x-before.x,v.z-before.z)<.03);before=v;}
 assert.equal(movePhase({running:true,phase:'playing',moveAt:100,stepMs:280},240),.5);
 assert.equal(movePhase({running:false,phase:'playing'},500),1);assert.equal(chewingEnvelope(-1),0);assert.equal(chewingEnvelope(500),0);assert.ok(chewingEnvelope(110)>.6);
});

test('V04: apresentador fala no silêncio, varia assuntos e cede ao público',()=>{
 let now=100000;const events=[],h=new ShowHost({now:()=>now,random:()=>.3,onSpeech:a=>events.push(a)});
 now+=41000;assert.equal(h.tick({running:false}),false);assert.equal(h.tick({running:true}),true);assert.equal(events[0].kind,'ambient');assert.equal(events[0].priority,0);
 assert.ok(AMBIENT_KEYS.some(k=>events[0].audio.endsWith('/'+k+'.wav')));
 const unique=new Set([events[0].audio]);for(let i=0;i<7;i++){now+=41000;h.tick({running:true});unique.add(events.at(-1).audio);}assert.equal(unique.size,8);
 now+=41000;h.ask({user:'ana',name:'Ana',text:'olá'});assert.equal(events.at(-1).priority,1);assert.equal(h.tick({running:true}),false);
 now+=41000;h.working=true;assert.equal(h.tick({running:true}),false);h.working=false;h.configure({ambientEnabled:false});now+=41000;assert.equal(h.tick({running:true}),false);h.close();
 assert.throws(()=>settings({ambientInterval:'abc'}));assert.equal(settings({ambientInterval:1}).ambientInterval,20);
});
