export class TrackQueue{
 constructor({random=Math.random,max=32}={}){this.random=random;this.max=max;this.tracks=[];this.bag=[];this.lastId=null;this.sequence=0;this.shuffle=true;}
 add(files){let added=0;for(const file of files){if(this.tracks.length>=this.max)break;if(!file.size||(!String(file.type).startsWith('audio/')&&!/\.(mp3|m4a|aac|ogg|opus|wav|flac|webm)$/i.test(file.name)))continue;const signature=[file.name,file.size,file.lastModified||0].join(':');if(this.tracks.some(t=>t.signature===signature))continue;this.tracks.push({id:'track-'+(++this.sequence),name:file.name,file,signature});added++;}this.bag=[];return added;}
 next(){if(!this.tracks.length)return null;let selected;
  if(!this.shuffle){const i=this.tracks.findIndex(t=>t.id===this.lastId);selected=this.tracks[(i+1)%this.tracks.length];}
  else{if(!this.bag.length){this.bag=this.tracks.map(t=>t.id);for(let i=this.bag.length-1;i>0;i--){const j=Math.floor(this.random()*(i+1));[this.bag[i],this.bag[j]]=[this.bag[j],this.bag[i]];}if(this.bag.length>1&&this.bag.at(-1)===this.lastId)[this.bag[0],this.bag[this.bag.length-1]]=[this.bag.at(-1),this.bag[0]];}const id=this.bag.pop();selected=this.tracks.find(t=>t.id===id);}
  this.lastId=selected.id;return selected;
 }
 select(id){const t=this.tracks.find(t=>t.id===id);if(!t)return null;this.lastId=id;this.bag=this.bag.filter(x=>x!==id);return t;}
 remove(id){const length=this.tracks.length;this.tracks=this.tracks.filter(t=>t.id!==id);this.bag=[];return this.tracks.length!==length;}
}
export function createPlaylist({audio,element,getOriginal,onTrack=()=>{},onStatus=()=>{}}){const queue=new TrackQueue(),failed=new Set();let generation=0,current=null;
 async function load(track,play=true){const token=++generation,file=track?track.file:await getOriginal();await audio.load(file);if(token!==generation)return;current=track?.id||'original';element.loop=queue.tracks.length<=1||!track;onTrack({name:track?.name||'Caos 132 · trilha original',id:current,count:queue.tracks.length});if(play)await element.play();}
 async function next(play=true){for(let i=0;i<queue.tracks.length;i++){const t=queue.next();if(!failed.has(t.id))return load(t,play);}return load(null,play);}
 element.addEventListener('ended',()=>{void next(true).catch(e=>onStatus(e.message));});
 element.addEventListener('error',()=>{if(current&&current!=='original'){failed.add(current);onStatus('Arquivo indisponível; escolhendo outra faixa.');void next(true).catch(e=>onStatus(e.message));}else onStatus('Não foi possível abrir a música. Escolha outro arquivo.');});
 return {queue,next,loadDefault:()=>load(null,false),async add(files){const added=queue.add(Array.from(files));failed.clear();if(added)await next(true);return added;},async select(id){const t=queue.select(id);if(t&&!failed.has(id))await load(t,true);},async remove(id){queue.remove(id);if(current===id)await next(!element.paused);onTrack({name:element.currentSrc?null:'Caos 132',id:current,count:queue.tracks.length});},get current(){return current;}};
}
