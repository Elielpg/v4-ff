export const PARK_LIMITS=Object.freeze({queue:8,records:1500,visible:30,completed:2000,prepareMs:1500,flightMs:3000,celebrateMs:2500});
export const CANNON_MS=PARK_LIMITS.prepareMs+PARK_LIMITS.flightMs+PARK_LIMITS.celebrateMs;
export function parkSettings(value={}) {
 const result={enabled:true,cannonGift:'gg',freeCooldown:45,landingPoints:5,...value};
 if(!['gg','rose','popular','any','none'].includes(result.cannonGift))throw Error('Presente do canhão inválido');
 for(const [key,min,max]of [['freeCooldown',15,120],['landingPoints',0,25]]){const n=Number(result[key]);if(!Number.isFinite(n))throw Error('Configuração do parque inválida');result[key]=Math.max(min,Math.min(max,Math.round(n)));}
 result.enabled=!!result.enabled;return {enabled:result.enabled,cannonGift:result.cannonGift,freeCooldown:result.freeCooldown,landingPoints:result.landingPoints};
}
export function cannonPhase(elapsed) {
 if(elapsed<PARK_LIMITS.prepareMs)return 'prepare';
 if(elapsed<PARK_LIMITS.prepareMs+PARK_LIMITS.flightMs)return 'flight';
 if(elapsed<CANNON_MS)return 'celebrate';
 return 'done';
}
