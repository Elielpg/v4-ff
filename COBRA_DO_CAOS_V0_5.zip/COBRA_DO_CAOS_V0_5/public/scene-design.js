import {hash,RULES} from './rules.js';
export const SCENE=Object.freeze({cell:1.5,boardWidth:RULES.cols*1.5,boardDepth:RULES.rows*1.5,cageZ:-RULES.rows*.75-6.8,actorLimit:192,portraitSlots:256});
const species=['SOLAR','COSMO','MUSGO','BRASA','POLAR','PIXEL'];
export function avatarDesign(id){const n=hash(id);return {seed:n,species:species[n%6],shape:n%6,color:(n>>>4)%8,skin:(n>>>9)%4,hat:(n>>>12)%5,height:.88+((n>>>15)%24)/100,width:.86+((n>>>20)%28)/100,eye:(n>>>25)%3,pose:(n>>>28)%4};}
export function shotFor({mode='overview',elapsed=0,aspect=.65,head={x:0,z:0},yaw=0,visitor=null,reduced=false}={}){
 if(reduced)mode='overview';let target={x:0,y:.6,z:-4.2},alpha=Math.PI/2,beta=.48,radius=77;
 const fit=(width,height)=>Math.max(height/(2*Math.tan(.82/2)),width/(2*Math.tan(.82/2)*Math.max(.35,aspect)))*1.12;
 if(mode==='podium'){target={x:23,y:1.8,z:-15};alpha=Math.PI/2+.15;beta=1.08;radius=Math.max(12,7.8/(2*Math.tan(.41)*Math.max(.35,aspect))*1.05);}
 else if(mode==='orbit'){alpha=Math.PI/2+elapsed*.048;beta=.6;radius=fit((SCENE.boardWidth+5)*Math.abs(Math.sin(alpha))+(SCENE.boardDepth+12)*Math.abs(Math.cos(alpha)),57);}
 else if(mode==='follow'||mode==='thanks'){target={x:head.x,y:1.55,z:head.z};alpha=Math.PI/2-yaw+Math.sin(elapsed*.2)*.12;radius=mode==='thanks'?6.8:8.7;beta=1.12;}
 else if(mode==='cage'){target={x:0,y:1,z:SCENE.cageZ};alpha=Math.PI/2+.15*Math.sin(elapsed*.18);radius=Math.max(15,14/(2*Math.tan(.82/2)*Math.max(.35,aspect)));beta=.84;}
 else if(mode==='visitor'&&visitor){target={x:visitor.x,y:visitor.y+1,z:visitor.z};alpha=Math.PI/2+.12;radius=Math.max(4.5,2/(Math.tan(.82/2)*Math.max(.35,aspect)));beta=1.18;}
 else if(mode==='banquet'){target={x:0,y:1,z:-2};radius=Math.max(26,19/(2*Math.tan(.82/2)*Math.max(.35,aspect)));beta=.64;}
 else {radius=Math.max(104,fit(68,94));beta=.68;target={x:0,y:1,z:-3};}
 return {mode,target,alpha,beta,radius};
}
export function mouthEnvelope(previous,level,speaking,dt){const target=speaking?Math.min(1,Math.max(0,level)*5):0;return previous+(target-previous)*(1-Math.exp(-Math.min(.5,Math.max(0,dt))*(target>previous?28:16)));}
