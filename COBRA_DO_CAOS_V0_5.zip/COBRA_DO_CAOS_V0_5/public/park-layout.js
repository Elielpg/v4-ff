import {PARK_LIMITS} from './park-rules.js';
export const PARK=Object.freeze({cannon:{x:-18,y:.4,z:19},landing:{x:0,y:3.32,z:0},podium:{x:23,z:-15}});
const lerp=(a,b,t)=>a+(b-a)*t;
export function cannonPose(elapsed){
 const {prepareMs,flightMs}=PARK_LIMITS,start=PARK.cannon,end=PARK.landing;
 if(elapsed<prepareMs)return {...start,y:2.1,phase:'prepare',scale:1};
 const t=Math.max(0,Math.min(1,(elapsed-prepareMs)/flightMs));
 if(t<1)return {x:lerp(start.x,end.x,t),y:lerp(2.1,end.y,t)+Math.sin(t*Math.PI)*13,z:lerp(start.z,end.z,t),phase:'flight',spin:t*Math.PI*4,scale:1};
 return {...end,phase:'celebrate',scale:1};
}
export function coasterPose(t,index=0){const a=t*.105+index*.32;return {x:35*Math.cos(a),y:3.8+Math.pow(.5+.5*Math.sin(a*2+.7),3)*7,z:40*Math.sin(a)-4,yaw:Math.atan2(-35*Math.sin(a),40*Math.cos(a))};}
export function visitorPose(seed,time=0){const a=(seed%1000)/1000*Math.PI*2+Math.sin(time*.11+seed)*.08,side=seed%2?1:-1;return {x:side*(17.4+(seed%3)*1.4)+Math.sin(a+time*.16)*.65,y:0,z:-20+(seed%41)+Math.cos(a+time*.16)*.8};}
export function podiumPose(index=0){return {x:PARK.podium.x+(index===0?0:index===1?-2.3:2.3),y:index===0?1.25:index===1?.9:.6,z:PARK.podium.z};}
// Constant topology; every ring is written in place, including rounded corners and tapered tail.
export function writeTube(points,positions,normals,sides=8,samples=3){
 if(points.length<2)return 0;let ring=0;
 const sample=(i,t,key)=>{const p0=points[Math.max(0,i-1)][key],p1=points[i][key],p2=points[Math.min(points.length-1,i+1)][key],p3=points[Math.min(points.length-1,i+2)][key];return .5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t);};
 for(let i=0;i<points.length-1;i++)for(let j=0;j<samples;j++){
  const t=j/samples,x=sample(i,t,'x'),y=sample(i,t,'y'),z=sample(i,t,'z'),u=Math.min(1,t+.01),l=Math.max(0,t-.01),dx=sample(i,u,'x')-sample(i,l,'x'),dz=sample(i,u,'z')-sample(i,l,'z'),len=Math.hypot(dx,dz)||1,rx=dz/len,rz=-dx/len,r=.53*Math.min(1,.22+(points.length-1-i-t)*.55);
  for(let k=0;k<=sides;k++){const a=k/sides*Math.PI*2,nx=Math.cos(a)*rx,ny=Math.sin(a),nz=Math.cos(a)*rz,o=(ring*(sides+1)+k)*3;positions[o]=x+nx*r;positions[o+1]=y+ny*r;positions[o+2]=z+nz*r;normals[o]=nx;normals[o+1]=ny;normals[o+2]=nz;}ring++;
 }
 const p=points.at(-1);for(let k=0;k<=sides;k++){const o=(ring*(sides+1)+k)*3;positions[o]=p.x;positions[o+1]=p.y;positions[o+2]=p.z;normals[o]=0;normals[o+1]=1;normals[o+2]=0;}return ring+1;
}
