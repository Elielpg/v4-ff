// Visual interpolation only. The authoritative pilot continues to use grid cells.
export const clamp01 = value => Math.max(0, Math.min(1, value));
export function movePhase(state, clock) {
  if (!state.running || state.phase !== 'playing') return 1;
  return clamp01((clock - state.moveAt) / Math.max(1, state.stepMs));
}
export function curvePosition(prior, from, to, next, phase) {
  const t=clamp01(phase), t2=t*t, t3=t2*t, out={};
  for (const key of ['x','y','z']) {
    const a=from[key], b=to[key], m0=(b-prior[key])*.4, m1=(next[key]-a)*.4;
    out[key]=(2*t3-3*t2+1)*a+(t3-2*t2+t)*m0+(-2*t3+3*t2)*b+(t3-t2)*m1;
  }
  return out;
}
export function chewingEnvelope(ageMs, reduced=false) {
  if (ageMs < 0 || ageMs > 440) return 0;
  return Math.pow(Math.sin(Math.PI*ageMs/220),2)*(1-ageMs/540)*(reduced?.35:1);
}
