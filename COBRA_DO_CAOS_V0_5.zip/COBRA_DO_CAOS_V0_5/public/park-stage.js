import {CageStage} from './cage-stage.js';
import {SCENE} from './scene-design.js';
import {cannonPose,coasterPose,visitorPose,podiumPose} from './park-layout.js';
const B=window.BABYLON;
export class ParkStage extends CageStage{
 extraPeople(s){return s.park?.visitors||[];}
 updateExtras(s,needed){const active=s.park?.active?.user,top=s.park?.top||[];for(const p of this.extraPeople(s).sort((a,b)=>(b.id===active)-(a.id===active))){if(!needed.has(p.id)&&needed.size>=SCENE.actorLimit)continue;needed.add(p.id);const a=this.actor(p);a.person={...a.person,...p};a.top=top.findIndex(x=>x.id===p.id);if(a.kind==='caged'&&!s.cage.members.some(x=>x.id===p.id))a.kind='park';if(a.kind==='food'&&a.feast?.readyAt>s.serverTime-350)continue;
   // The social park is a visual layer. Cage membership and escape progress stay authoritative.
   if(!['caged','escaped'].includes(a.kind))a.kind='park';a.cannon=p.id===active;
  }for(const a of this.actors.values())if(a.id!==active)a.cannon=false;
 }
 poseActor(a,{now,clock}){const park=this.state.park;if(!park)return null;const seconds=(park.time+(this.state.running?Math.max(0,now-this.w.stateAt):0))/1000;
  if(a.cannon&&park.active){const elapsed=park.active.elapsedMs+(this.state.running?Math.max(0,now-this.w.stateAt):0),p=cannonPose(elapsed);a.parkPose=p;return {...p,yaw:p.phase==='flight'?p.spin:Math.PI/2-this.w.camera.alpha,snap:true,celebrate:p.phase!=='prepare'};}
  a.parkPose=null;if(a.kind==='food'||a.kind==='caged')return null;
  if(a.top>=0&&a.top<3){const p=podiumPose(a.top);return {...p,celebrate:true,yaw:Math.PI/2-this.w.camera.alpha,y:p.y+(this.w.reduceMotion?0:Math.abs(Math.sin(now/260+a.design.seed))*.10)};}
  if(a.kind==='escaped')return null;const seed=a.design.seed;
  if(seed%4===0){const index=seed%8,p=coasterPose(now/1000,index);return {...p,y:p.y+.1,seated:true,snap:true};}
  const p=visitorPose(seed,seconds);return {...p,walk:true,yaw:Math.PI/2-this.w.camera.alpha};
 }
 frame(dt,now,clock,mode){super.frame(dt,now,clock,mode);this.afterFrame=now;}
}
