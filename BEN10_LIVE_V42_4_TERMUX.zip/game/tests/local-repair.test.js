import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,copyFile,rm,readdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import os from 'node:os';import path from 'node:path';

test('reparo autônomo atualiza conversa e permite trocar só a voz, faz backup e preserva dados/repositórios',{timeout:15000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben42-repair-')),game=path.join(temp,'game'),prefix=path.join(temp,'prefix');
 try{
  await mkdir(path.join(game,'scripts/local-ai'),{recursive:true});await mkdir(path.join(game,'data/private'),{recursive:true});await mkdir(path.join(prefix,'etc/apt/sources.list.d'),{recursive:true});
  await writeFile(path.join(game,'package.json'),'{"name":"linel-live-city","version":"42.0.0","type":"module"}');await copyFile('scripts/phone-update.js',path.join(game,'scripts/phone-update.js'));
  const names=["package.json", "package-lock.json", "public/release.js", "public/index.html", "public/arena-app.js", "public/broadcast-ui.css", "public/chat-intent.js", "public/transformations.js", "public/arena-commands.js", "server/core.js", "server/index.js", "server/conversation.js", "server/local-ai.js", "server/classic.js", "scripts/termux-packages.sh", "scripts/local-ai/install.sh", "local-ai.sh", "scripts/local-ai/run.js", "scripts/local-ai/download_models.py", "scripts/local-ai/tts_server.py"];
  for(const name of names)if(!['scripts/termux-packages.sh','package.json'].includes(name)){await mkdir(path.dirname(path.join(game,name)),{recursive:true});await writeFile(path.join(game,name),'script antigo');}
  const preserved={'data/private/gemini-keys.json':'chave fictícia do teste','.env':'BEN_FIXTURE_ONLY=valor_ficticio\n','data/alien-progress.json':'{"likes":125}'};
  for(const [name,text] of Object.entries(preserved))await writeFile(path.join(game,name),text);
  const extra=path.join(prefix,'etc/apt/sources.list.d/glibc.list');await writeFile(extra,'repositório extra do teste');
  const repair=path.resolve('REPARAR_CONVERSA_V42_4.sh'),r=spawnSync('bash',[repair],{cwd:game,encoding:'utf8',env:{...process.env,PREFIX:prefix,TMPDIR:temp},timeout:10000});assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Atualização de conversa aplicada/);
  for(const name of names)assert.equal(await readFile(path.join(game,name),'utf8'),await readFile(name,'utf8'));
  for(const [name,text] of Object.entries(preserved))assert.equal(await readFile(path.join(game,name),'utf8'),text);
  assert.equal(await readFile(extra,'utf8'),'repositório extra do teste');
  const backups=await readdir(path.join(game,'data/installer-backups'));assert.equal(backups.length,1);assert.equal(await readFile(path.join(game,'data/installer-backups',backups[0],'local-ai.sh'),'utf8'),'script antigo');
  assert.equal(JSON.parse(await readFile(path.join(game,'package.json'),'utf8')).version,'42.4.0');
 }finally{await rm(temp,{recursive:true,force:true});}
});
