#!/usr/bin/env bash
set -euo pipefail
task_game_root="$(cd -- "$(dirname -- "$0")" && pwd)"
task_local_root="${BEN10_LOCAL_ROOT:-$HOME/.local/share/ben10-local-ai}"
task_command="${1:-help}"
shift || true
case "$task_command" in
  install) exec bash "$task_game_root/scripts/local-ai/install.sh" "$@" ;;
  voice)
    if [[ $# -ne 1 || ! "$1" =~ ^(cadu|faber|jeff)$ ]]; then printf 'Use: bash local-ai.sh voice cadu|faber|jeff\n' >&2; exit 1; fi
    exec python3 "$task_game_root/scripts/local-ai/download_models.py" --root "$task_local_root" --voice "$1"
    ;;
  start|status)
    task_node_options=()
    if [[ -f "$task_game_root/.env" ]]; then task_node_options+=("--env-file=$task_game_root/.env"); fi
    exec node "${task_node_options[@]}" "$task_game_root/scripts/local-ai/run.js" "$task_command"
    ;;
  help|--help|-h)
    printf 'Instalar uma vez: bash local-ai.sh install [--model gt3|light]\nIniciar IA e jogo: bash local-ai.sh start\nComparar voz brasileira: bash local-ai.sh voice cadu|faber|jeff\nDiagnóstico: bash local-ai.sh status\nModelos: %s\n' "$task_local_root"
    ;;
  *) printf 'Comando inválido. Use bash local-ai.sh help\n' >&2; exit 1 ;;
esac
