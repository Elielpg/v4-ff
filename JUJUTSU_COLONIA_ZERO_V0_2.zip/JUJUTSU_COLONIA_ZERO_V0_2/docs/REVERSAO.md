# Backup e reversão

A V0.1 publicada foi preservada separadamente na nuvem antes das mudanças. O
atualizador também gera, **na sua instalação**, um backup contendo o código,
configuração e progresso que existiam imediatamente antes da atualização.
O nome é exibido ao terminar: `backups/antes-0.2.0-DATA-HORA.zip`.

Para reverter, na pasta instalada:

```bash
bash stop.sh
python3 -m zipfile -l backups/antes-0.2.0-DATA-HORA.zip
python3 -m zipfile -e backups/antes-0.2.0-DATA-HORA.zip .
bash install.sh
bash start.sh
```

Substitua DATA-HORA pelo arquivo real. A extração repõe também o progresso do
momento do backup. Para preservar o progresso posterior, faça antes uma cópia
separada de `data/`, com o servidor parado, e decida qual progresso deseja manter.
Não publique nem compartilhe esse diretório pessoal junto do ZIP do jogo.

Arquivos novos exclusivos da V0.2 podem permanecer no disco após a extração,
mas o código V0.1 restaurado não os importa. Para uma reversão limpa, extraia o
backup em outra pasta, execute a instalação nela e mantenha somente uma cópia
ativa na porta 3200.

O atualizador valida o manifesto antes de parar a instalação anterior. Se houver
falha depois do backup, ele não apaga o backup; consulte a mensagem e os logs.
Não use comandos que encerrem todos os processos Node do aparelho.
