# Limites e melhorias futuras — 0.2.0

| ID | Situação |
|---|---|
| JJK-001 | LIVE real na conta do usuário ainda não validada nesta nuvem. Confirmar join, follow, streak de Rosa, comentários, likes e compartilhamentos no GT3. |
| JJK-002 | O supervisor recupera o filho, com limite, e registra sinal/código. Não sobrevive ao Android encerrar todo o Termux. A causa da parada antiga no aparelho continua indeterminada sem os logs daquela ocorrência. |
| JJK-003 | FPS, temperatura, autonomia e sessão real de 30/60 min no GT3 pendentes. Testes virtuais e SwiftShader não equivalem ao aparelho. |
| JJK-004 | GreenTube/fone/Bluetooth dependem da captura disponibilizada pelo Android. APK anterior preservado; configurar porta 3200 e testar no aparelho. |
| JJK-005 | Entregues novos GLBs com rig e clips. Ainda são modelos estilizados próprios; roupas, rosto, pele, mãos e animações podem receber acabamento artístico manual. Não equivalem aos modelos oficiais. |
| JJK-006 | Oito domínios têm composições distintas, mas técnicas ainda compartilham algumas bases de energia. Invocações são estilizadas; não há todos os shikigamis/arcos/personagens da obra. |
| JJK-007 | Disputa de dois domínios foi implementada por confronto. Regras de domínio, distâncias, barreiras incompletas e resistência não reproduzem integralmente a física narrativa do anime/mangá. |
| JJK-008 | A câmera mostra somente um encontro por vez, até três combatentes. As outras batalhas são simuladas. Personagens podem cruzar-se brevemente durante um teleporte/combo; não há física de contato entre ossos. |
| JJK-009 | As 27 falas inglesas são clipes originais preparados. Não são vozes dos dubladores, não leem cada nome e não respondem perguntas livres. Não foi adicionado clonador. |
| JJK-010 | Seguidor antigo só é reconhecido se observado/salvo nesta instalação. O conector não consulta a lista histórica de seguidores. |
| JJK-011 | Queda abrupta pode perder eventos do último segundo, e o TikTok pode não reenviá-los. Áudio de arquivo/externo exige retomada após recuperar. |
| JJK-012 | Renderização de NPCs no fundo de outros encontros, replay cinematográfico e editor visual de habilidades são possíveis evoluções. Manter orçamento de GPU/memória antes de ampliar atores. |

## Falhas corrigidas durante esta atualização

- Um trio da demonstração podia ficar todo no mesmo time após a atribuição tardia
  de personagens. O time agora é definido antes da entrada.
- Um pulso letal de domínio em trio podia limpar o próprio domínio no meio do
  laço e acessar `null`. A referência do pulso é estável e o laço para na vitória.
  Foi adicionado teste de regressão específico.
- O congelamento offline podia deslocar duas vezes um domínio referenciado
  também pelo campo legado. Agora cada temporizador local é deslocado uma vez.
- O Vermelho podia aplicar o limite global de coordenadas de V0.1 em uma batalha
  distante. O recuo fica limitado à interseção correta e ao alvo realmente atacado.
- A câmera verificava poucos pontos do corpo. Agora amostra dos pés à identificação
  acima da cabeça, incluindo margem, para atenuar os obstáculos.
- Fonte de áudio de arquivo/externa perdida não reinicia em modo manual após
  recuperar: aguarda reprodução/conexão, preservando o BPM manual quando escolhido.

As correções acima foram reproduzidas e verificadas nesta versão. Elas não
provam que a antiga parada silenciosa do Termux tinha a mesma causa.
