# Registro de entrega — V0.2

Foi instalado um candidato completo do ZIP em uma pasta temporária limpa, com
`bash install.sh`, e executada a suíte: **62/62 testes passaram**.

O teste de atualização utilizou outra cópia extraída do ZIP público da V0.1,
com dados de teste, fila, mapeamento de presente, arquivo de configuração e
arquivo personalizado. O atualizador da V0.2 foi executado de verdade nessa cópia:

- Identidade do projeto e manifesto conferidos; backup ZIP com CRC válido.
- Arquivos de progresso mantidos byte a byte durante a cópia da atualização.
- Configuração e arquivo personalizado preservados.
- Servidor atualizado respondeu com versão 0.2.0, 105 pontos, 150 HP, 250 curtidas,
  fila `caio` e rodada 5.
- Backup extraído sobre a instalação com servidor parado; servidor revertido
  respondeu na versão 0.1.0 com os mesmos valores.

O primeiro ensaio da fila usou um limite de um jogador, abaixo do mínimo permitido
de dois. A expectativa do próprio teste estava errada; o cenário foi corrigido
para dois jogadores e um na fila. Não houve alteração do limite do jogo para
fazer a verificação passar.

O pacote final inclui este registro e os resultados. A repacotagem acrescenta
somente documentação/evidências após os testes de instalação; os hashes dos
arquivos de execução são comparados com o candidato instalado. CRC e manifesto
são verificados de novo no arquivo final. `MANIFEST.sha256` identifica cada
arquivo. O SHA-256 do ZIP é entregue em arquivo `.sha256` externo, evitando
referência circular dentro do próprio ZIP.

Evidências: `evidencias/v02/DELIVERY_TEST.json`, `TESTES_EXTRAIDO.txt`,
`ATUALIZACAO_REAL.txt`, `INSTALACAO_EXTRAIDO.txt` e demais registros da V0.2.
Os caminhos temporários nesses logs pertencem à nuvem, não ao seu celular.

O APK Pulso Batida 0.2.1 anterior permanece idêntico. Pastas de pesquisa,
FBXs/texturas inspecionados, `node_modules`, dados pessoais, logs de produção,
modelos de IA e chaves não fazem parte da distribuição.
