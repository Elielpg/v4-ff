# Pesquisa de modelos e recursos

Foram pesquisados repositórios públicos no GitHub e inspecionados os arquivos de
licença/README antes da decisão de distribuição. A API do GitHub estava bloqueada
pela rede desta nuvem; a página pública e acesso git/raw estavam disponíveis.

| Repositório | Achado | Uso no pacote |
|---|---|---|
| https://github.com/hoch98/3D-Model-Animation-Test | FBXs de Gojo, Yuji, Megumi e Nobara com rig Mixamo. Commit inspecionado: `148118b9e8c62a37c47724d94bf357168f6389d9`. O README atribui os modelos a DeviantArt/risqi26; há MIT para o projeto, mas não foi localizada autorização clara do autor externo dos modelos para esta redistribuição. | Nenhum FBX, textura ou animação desse repositório foi incluído. |
| https://github.com/shahriarshaheen/Jujutsu-Kaisen-Cursed-Energy-BattleGround | Experimento Python/OpenGL; não forneceu um conjunto adequado de avatares para esta versão. | Nenhum arquivo reutilizado. |
| https://github.com/Tejashree-Likhar/jujutsu-kaisen-domain-expansion | Experimento de partículas/domínios com câmera; licença MIT no projeto. | Consulta de referência; nenhum código copiado. |
| https://github.com/BabylonJS/Babylon.js | Engine já usada pelo jogo; loaders glTF e CellMaterial oficiais 9.32.1. | Bibliotecas locais Apache-2.0 com avisos de licença. |

Os novos modelos foram gerados em Blender a partir de geometria própria, com
cabelo, roupas, olhos, dedos e detalhes específicos de personagem. O script
`scripts/build_avatars.py` é incluído. Os GLBs não contêm malhas importadas dos
repositórios pesquisados. O universo/personagens continuam sendo uma adaptação
de fã de Jujutsu Kaisen, não um projeto oficial.

As pastas de pesquisa e arquivos baixados para inspeção ficaram fora do ZIP.
A escolha por modelos próprios evita apresentar uma licença de software como
comprovação de permissão de um modelo atribuído a terceiros. O visual entregue é
3D estilizado; refinamento artístico manual e animações profissionais continuam
sendo melhorias possíveis, sem prometer modelos idênticos aos oficiais.
