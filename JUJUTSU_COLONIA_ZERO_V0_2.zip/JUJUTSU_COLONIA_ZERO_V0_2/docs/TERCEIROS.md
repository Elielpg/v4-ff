# Créditos e recursos

- **Jujutsu Kaisen:** personagens e universo de Gege Akutami. Esta é uma
  adaptação de fã, sem vínculo oficial. Não foram incluídos episódios,
  gravações de dublagem, trilha comercial ou modelos extraídos do anime.
- **Babylon.js 9.32.1:** Apache-2.0. Distribuído em `public/vendor/`, junto da
  licença. https://github.com/BabylonJS/Babylon.js
- **piratetok-live-js 0.3.0:** 0BSD, dependências fixadas no lockfile.
  https://www.npmjs.com/package/piratetok-live-js
- **Piper:** usado só na produção dos WAVs, versão 1.8.0.
  https://github.com/OHF-Voice/piper1-gpl . Motor/modelo de síntese não estão no
  pacote de execução. Falas foram escritas para este jogo e processadas em
  timbre, dinâmica e volume, sem usar amostras de dubladores.
- **Voz John / en_US-medium:** modelo divulgado com dataset de gravações
  LibriVox de domínio público, conforme a ficha publicada:
  https://huggingface.co/rhasspy/piper-voices/blob/main/en/en_US/john/medium/MODEL_CARD
  A ficha credita o treinamento a Bryce Beattie. O modelo não está incluído;
  `VOZES.json` registra texto, duração e RMS dos clipes gerados.
- **Pulso Batida 0.2.1:** captador e fonte reutilizados do PULSO ARENA desta
  sessão. Configure porta 3200 para este jogo. O APK original foi mantido.
- **Cidade, modelos procedurais, ícones SVG, partículas, animações e trilha
  Colony Pulse:** criados nesta implementação. `scripts/create_demo_music.py`
  reproduz o loop original sem amostras de gravações comerciais.

Os scripts de geração e validação usados na nuvem ficam fora do pacote de
execução quando dependem de caminhos locais do ambiente. Testes portáveis e
evidências estão incluídos.

## Adições V0.2

Os loaders glTF e CellMaterial oficiais Babylon.js **9.32.1** estão em
`public/vendor/`, com `LOADERS-LICENSE.md` e `CELL-LICENSE.md` (Apache-2.0).
Os novos avatares GLB e clips foram produzidos com Blender 4.3.2; o script gerador
é distribuído. Blender é ferramenta de produção e não é exigido no Termux.
A pesquisa de repositórios e a decisão de não distribuir seus modelos externos
estão em `PESQUISA_MODELOS.md`. Não foram incluídos FBXs/texturas dessa pesquisa.
