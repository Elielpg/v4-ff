# Arquitetura — Jujutsu Live V0.2

O motor anterior continua como base. A V0.2 separa os confrontos da lógica de
entrada, presentes, regras, persistência e transporte existente. Não houve troca
de engine gráfica; o cenário Babylon.js anterior foi reaproveitado.

```text
TikTok / ponte de eventos / demonstração isolada
  -> server/live.mjs / server/index.mjs
  -> server/engine.mjs (exporta o motor ativo)
  -> server/battle-engine.mjs
       -> core-engine.mjs: participantes, fila, presentes, regras, pontuação
       -> encounters.mjs: membros, adversários, posições, vitória, restauração
       -> catalog.mjs -> public/catalog.js: personagens/técnicas/configuração
  -> SSE: snapshots a cada 250ms + ações identificadas pelo confronto
  -> public/app.js: HUD, controles, áudio somente do confronto em foco
       -> combat-world.js estende world.js
            -> cidade/domínios/partículas existentes
            -> avatars.js + GLBs: esqueletos, amostragem de clips, transições
            -> fx.js: pool de energia, invocações, Black Flash e pregos
       -> sound.js/audio.js: SFX, WAVs ingleses, música e batidas
```

## Servidor

`server/core-engine.mjs` preserva o motor V0.1 e é dependência de produção. Os
testes legados de `colony.test.mjs` passam a importar essa base porque descrevem
contratos da V0.1, incluindo o domínio global e a preferência antiga por Sukuna.
Esses dois comportamentos foram substituídos a pedido do usuário; a regressão da
V0.2 é coberta separadamente por `encounters.test.mjs` e pela integração HTTP.
Os testes antigos não devem ser apresentados como prova isolada do novo combate.

`EncounterManager` é responsável pelo limite de **três, contando NPCs**. Jogadores
ficam em exatamente um confronto. Centros ficam em interseções distintas. O
motor mantém no máximo 12 jogadores humanos em combate e uma reserva FIFO de
200. NPCs complementam confrontos; são separados de `players` e não entram no
ranking. Cada confronto armazena ordem do combo, domínio, perigo e fase de
vitória. Os poderes não chamam comandos do sistema operacional.

Alvos pertencem ao mesmo confronto; um desafio pode mudar de encontro somente
quando há espaço. Dano entre encontros é recusado. Domínios mantêm controle,
custo, recarga, dano periódico e disputa de barreira locais ao encontro. Após
eliminar alguém, uma janela de vitória suspende os ataques, e o encontro é
reorganizado sem ultrapassar o limite. Golpes seguem os acentos; dano é ajustado
pela cadência para evitar que mais amostras simplesmente multipliquem a força.

## Navegador e modelos

`combat-world.js` reutiliza a cidade de `world.js`, mas substitui a criação e
animação dos lutadores. São carregados dez contêineres GLB locais (nove personagens
combatentes e cidadão) em lotes de três. Clones recebem esqueletos independentes;
os materiais CellMaterial são compartilhados e respeitam ossos. O foco renderiza
até três combatentes; a simulação dos demais continua no servidor. Quando não
há combate, há um pequeno número de cidadãos visíveis.

Cada GLB inclui 38 ossos e 18 clips. `avatars.js` interpola posições e quaternions
entre quadros e mistura transições. A animação do esqueleto é combinada com
avanço/recuo, curva lateral, teleporte, salto e voo no espaço da cidade. Não é uma
simulação física completa de artes marciais nem captura de movimentos humana.

A câmera calcula centro/extensão dos participantes, respeita a proporção da tela
e atenua obstáculos contra amostras do corpo inteiro. Técnicas fortes seguram o
corte. Cada domínio cria sua arquitetura uma única vez e reutiliza a cena nas
próximas ativações. Partículas e imagens residuais têm limites fixos.

## Som e batidas

A trilha original e os WAVs já estão no pacote. O AudioContext é liberado por
um toque do usuário; reprodução e cache são limitados. Falas menores podem ser
descartadas quando outra fala está ativa. Som de luta de um confronto fora de
foco é filtrado. Não existe dependência de Gemini, IA local ou clonagem de voz
para este jogo funcionar.

O detector do player local e o captador Android anterior foram preservados.
O APK envia eventos de ritmo pareados para a porta configurada. A captura de
outro aplicativo depende das permissões e políticas do próprio Android.

## Persistência e supervisão

A identidade `jujutsu-live`/schema 1 permanece, com campos adicionais
`encountersVersion`, `fights`, `npcs` e `rhythm`. Um estado V0.1 recebe encontros
novos sem perder acesso, time, personagem, pontos, curtidas, fila ou presentes
mapeados. Domínios, perigos e falas transitórios não são reexecutados ao recuperar.
Áudio de arquivo/externo perdido fica pausado até reconexão; BPM manual é mantido.

O servidor grava snapshots de forma atômica com backup. O supervisor é um
processo Node separado, com recuperação limitada e identificação da própria
instalação. Não controla o gerenciamento de bateria/temperatura do Android.
Os logs devem distinguir falha do filho, porta ocupada e encerramento do Termux.
