import { ColonyWorld } from './world.js';
import { AvatarLibrary } from './avatars.js';
import { CHARACTERS,TECHNIQUES } from './catalog.js';
import { clamp } from './motion.js';
const B=BABYLON,V=B.Vector3,C=B.Color3;
const CLIPS={jab:'Punch',flurry:'Cross',uppercut:'Uppercut',hook:'Hook',kick:'Kick',airKick:'AirKick',teleport:'Cross',dash:'Punch',blackFlash:'BlackFlash'};
export class CombatWorld extends ColonyWorld {
 constructor(canvas){super(canvas);this.selectedFight=null;this.autoFights=true;this.switchAt=performance.now()/1000+12;this.movements=new Map();this.casts=new Map();this.snapshot=null;this.assets=new AvatarLibrary(this);this.loadingError=null;this.ready=this.assets.ready.then(()=>{if(this.snapshot)this.update(this.snapshot);return this;}).catch(e=>{this.loadingError=e.message;throw e;});this.ready.catch(()=>{});
  this.scene.lights[0].intensity=1.15;this.scene.lights[0].groundColor=new C(.35,.38,.48);this.scene.lights[1].intensity=1.2;
  this.occluders=this.scene.meshes.filter(m=>['tower','roof','billboard'].includes(m.name));this.camera.position.set(8,3.8,10);this.camera.fov=.72;this.ghosts=[];
  const tx=this.texture('speed silhouette',128,256,c=>{c.clearRect(0,0,128,256);c.fillStyle='#b5deff';c.beginPath();c.ellipse(64,39,19,25,0,0,Math.PI*2);c.fill();c.beginPath();c.moveTo(39,68);c.lineTo(87,68);c.lineTo(96,148);c.lineTo(78,146);c.lineTo(85,244);c.lineTo(65,244);c.lineTo(62,162);c.lineTo(55,244);c.lineTo(35,244);c.lineTo(44,143);c.lineTo(30,147);c.closePath();c.fill();});tx.hasAlpha=true;
  const m=new B.StandardMaterial('afterimage',this.scene);m.diffuseTexture=m.emissiveTexture=tx;m.disableLighting=true;m.useAlphaFromDiffuseTexture=true;m.backFaceCulling=false;
  for(let i=0;i<6;i++){const q=B.MeshBuilder.CreatePlane('afterimage',{width:.8,height:2.2},this.scene);q.material=m;q.billboardMode=B.Mesh.BILLBOARDMODE_Y;q.isPickable=false;q.setEnabled(false);this.ghosts.push({q,until:0});}
 }
 setQuality(q){super.setQuality(q);this.citizenLimit=q==='low'?1:2;this.fighterLimit=3;this.engine.setHardwareScalingLevel(q==='high'?1:q==='low'?1.6:1.15);if(this.actors)for(const a of this.actors.values())for(const m of a.rig?.meshes||[])m.renderOutline=q!=='low';}
 buildDomain(){super.buildDomain();this.domainSets=new Map();this.clashRing=B.MeshBuilder.CreateTorus('contested barrier',{diameter:15,thickness:.08,tessellation:48},this.scene);this.clashRing.parent=this.domainRoot;this.clashRing.rotation.x=Math.PI/2;this.clashRing.position.y=2.1;this.clashRing.material=this.mat('contested energy','#ff819b',1);this.glow.addIncludedOnlyMesh(this.clashRing);this.clashRing.setEnabled(false);}
 domainSet(id){if(this.domainSets.has(id))return this.domainSets.get(id);const root=new B.TransformNode('domain architecture '+id,this.scene);root.parent=this.domainRoot;const ink=this.mat('domain obsidian','#121221'),gold=this.mat('domain gold','#dab787',.2),steel=this.mat('domain blades','#bbdce9',.3),lava=this.mat('domain lava','#ff7042',1),col=this.mat('domain '+id,TECHNIQUES[id]?.color||'#ba9bff',.25);
  if(id==='garden'){const pool=B.MeshBuilder.CreateDisc('shadow sea',{radius:9,tessellation:48},this.scene);pool.rotation.x=Math.PI/2;pool.position.y=.09;pool.parent=root;pool.material=ink;for(let i=0;i<12;i++){const a=i/12*Math.PI*2;this.ball('rising shadow',1.2,col,root,[Math.sin(a)*7,.15,Math.cos(a)*7],[.8,.18+(i%3)*.16,1]);}}
  if(id==='perfection')for(let i=0;i<10;i++){const a=i/10*Math.PI*2,x=Math.sin(a)*7,z=Math.cos(a)*7;const hand=new B.TransformNode('mudra pillar',this.scene);hand.parent=root;hand.position.set(x,0,z);hand.rotation.y=-a;this.cylinder('wrist',.35,2.5,gold,hand,[0,1.2,0]);this.ball('palm',.9,gold,hand,[0,2.7,0],[.8,1,.35]);for(let j=0;j<5;j++){const f=this.cylinder('finger',.14,1.1-j*.07,gold,hand,[(j-2)*.16,3.45-Math.abs(j-2)*.08,0]);f.rotation.z=(j-2)*-.07;}}
  if(id==='bond')for(let i=0;i<16;i++){const a=i/16*Math.PI*2,r=4+(i%3),sword=new B.TransformNode('domain katana',this.scene);sword.parent=root;sword.position.set(Math.sin(a)*r,0,Math.cos(a)*r);sword.rotation.z=(i%2?1:-1)*.2;this.box('katana blade',[.07,1.9,.025],steel,sword,[0,.95,0]);this.box('katana guard',[.35,.07,.12],gold,sword,[0,1.8,0]);this.cylinder('katana grip',.075,.45,ink,sword,[0,2.05,0]);}
  if(id==='coffin')for(let i=0;i<9;i++){const a=i/9*Math.PI*2;const rock=B.MeshBuilder.CreatePolyhedron('volcanic wall',{type:1,size:1.7},this.scene);rock.parent=root;rock.position.set(Math.sin(a)*7,1.2,Math.cos(a)*7);rock.scaling.y=1.5+(i%3)*.3;rock.material=ink;const fissure=this.cylinder('molten fissure',.12,4,lava,root,[Math.sin(a)*6.7,1.7,Math.cos(a)*6.7]);this.glow.addIncludedOnlyMesh(fissure);}
  if(id==='womb'){for(let i=0;i<9;i++){const a=i/9*Math.PI*2,x=Math.sin(a)*6,z=Math.cos(a)*6;const branch=this.cylinder('cursed root',.4,6,col,root,[x,2.6,z]);branch.rotation.x=Math.cos(a)*.5;branch.rotation.z=-Math.sin(a)*.5;this.ball('cursed bud',1,gold,root,[x*.85,5.1,z*.85],[.75,1.1,.7]);}this.ball('womb canopy',4,col,root,[0,7,-3],[2,.35,1]);}
  if(id==='impact'){for(let i=0;i<12;i++){const q=this.ball('quiet horizon',.1,gold,root,[(i-6)*1.2,2.4+Math.sin(i)*1.2,-7]);this.glow.addIncludedOnlyMesh(q);}this.box('domain path',[2,.04,18],gold,root,[0,.08,0]);}
  if(id==='shrine'){for(const sign of [-1,1])for(let i=0;i<4;i++){const eave=this.box('shrine curved eave',[1.15,.16,2],ink,root,[sign*(3+i*.55),5.8+i*i*.035,-4]);eave.rotation.z=sign*i*.08;}for(let i=0;i<6;i++){const rib=this.cylinder('shrine bone',.12,1.6,gold,root,[(i-2.5)*.45,2.2,-4]);rib.rotation.z=(i-2.5)*.17;}}
  this.domainSets.set(id,root);return root;
 }
 allEntities(s=this.snapshot){return s?[...s.players,...(s.npcs||[]),s.boss]:[];}
 get fight(){return this.snapshot?.fights?.find(f=>f.id===this.selectedFight)||null;}
 selectFight(id,manual=true){if(!this.snapshot?.fights?.some(f=>f.id===id))return false;if(manual)this.autoFights=false;if(this.selectedFight!==id){this.selectedFight=id;this.resetShot();this.update(this.snapshot);}this.switchAt=performance.now()/1000+12;return true;}
 cycle(delta=1){const f=this.snapshot?.fights||[];if(!f.length)return;const i=f.findIndex(x=>x.id===this.selectedFight);this.selectFight(f[(i+delta+f.length)%f.length].id);}
 resetShot(){this.fx.clear();this.tracks.clear();this.reactions.clear();this.poses.clear();this.movements?.clear();this.casts?.clear();this.latest=null;this.shot=null;this.focus=null;this.cameraCut=true;for(const g of this.ghosts||[])g.until=0;}
 clear(){super.clear();this.resetShot();this.snapshot=null;this.selectedFight=null;this.state=null;for(const a of this.actors.values())a.dispose();this.actors.clear();}
 update(s){this.snapshot=s;const fights=s.fights||[];if(!fights.some(f=>f.id===this.selectedFight)){this.selectedFight=fights[0]?.id||null;this.resetShot();}
  const f=this.fight;this.state={...s,domain:f?.domain||null,hazard:f?.hazard||null};if(!this.assets?.loaded)return;
  const entities=this.allEntities(s),roster=f?f.members.slice(0,3).map(id=>entities.find(p=>p.id===id)).filter(Boolean):entities.filter(p=>!p.isNpc&&p.status==='citizen').slice(0,this.citizenLimit);
  const wanted=new Set(roster.map(p=>p.id));for(const [id,a]of this.actors)if(!wanted.has(id)){a.dispose();this.actors.delete(id);this.tracks.delete(id);this.reactions.delete(id);}
  for(const p of roster){let a=this.actors.get(p.id);if(a&&a.type!==p.character){a.dispose();this.actors.delete(p.id);a=null;}if(!a){a=this.fighter(p);this.actors.set(p.id,a);}a.update(p);}
 }
 fighter(p){const root=new B.TransformNode(p.id,this.scene),rig=this.assets.spawn(p.character||'citizen',root);root.position.set(p.x||0,.08,p.z||0);
  const tx=this.texture('name-'+p.id,512,128,()=>{});tx.hasAlpha=true;const m=new B.StandardMaterial('name-'+p.id,this.scene);m.diffuseTexture=m.emissiveTexture=tx;m.disableLighting=true;m.useAlphaFromDiffuseTexture=true;m.backFaceCulling=false;
  const label=B.MeshBuilder.CreatePlane('fighter label',{width:1.25,height:.31},this.scene);label.parent=root;label.position.y=2.4;label.material=m;label.billboardMode=B.Mesh.BILLBOARDMODE_ALL;label.isPickable=false;
  const a={p,type:p.character,root,rig,label,key:'',update(q){this.p=q;const key=q.id+Math.round(q.hp)+Math.floor(q.energy)+q.status;if(key===this.key)return;this.key=key;const c=tx.getContext();c.clearRect(0,0,512,128);c.fillStyle='#0b1428e5';c.beginPath();c.roundRect(2,3,508,120,20);c.fill();c.fillStyle=q.team==='gojo'?'#86e2ff':q.id==='sukuna'?'#ff8ba5':'#d1adff';c.font='800 34px sans-serif';c.textAlign='center';c.fillText(q.isNpc?CHARACTERS[q.character].name+' · NPC':'@'+q.id.slice(0,19),256,48);c.fillStyle='#f4f6ff';c.font='600 25px sans-serif';c.fillText(CHARACTERS[q.character].name+' · '+Math.max(0,Math.ceil(q.hp))+' HP',256,83);c.fillStyle='#192b45';c.fillRect(35,100,442,7);c.fillStyle=q.team==='gojo'?'#82deff':'#d3aaff';c.fillRect(35,100,442*clamp(q.hp/q.maxHp,0,1),7);tx.update();},dispose(){rig?.dispose();root.dispose();tx.dispose();m.dispose();}};return a;
 }
 accepts(a){return !a.encounter||a.encounter===this.selectedFight;}
 action(a){if(!this.accepts(a))return false;super.action(a);const t=performance.now()/1000;
  if(a.kind==='movement')this.movements.set(a.player,{...a,at:t});
  if(a.kind==='technique'){this.casts.set(a.player,{...a,at:t});if(a.domain)this.switchAt=Math.max(this.switchAt,t+7);}
  if(a.kind==='domainClash'){this.casts.set(a.player,{...a,domain:true,at:t});this.shot={...a,time:t,until:t+3,priority:4};this.switchAt=Math.max(this.switchAt,t+5);const actor=this.actors.get(a.player);if(actor)this.fx.impact(actor.root.position.add(new V(0,1,0)),TECHNIQUES[a.technique]?.color,2.3);}
  if(a.kind==='attack'&&(a.move==='teleport'||a.move==='dash')){const actor=this.actors.get(a.player);if(actor)this.afterimage(actor);}
  if(a.kind==='attack'&&a.black){const actor=this.actors.get(a.target);if(actor)this.fx.blackFlash(actor.root.position.add(new V(0,1.2,0)));this.shot={...a,time:t,until:t+.85,priority:2};}
  return true;
 }
 afterimage(a){if(this.reduceMotion||!this.ghosts.length)return;const t=performance.now()/1000,g=this.ghosts.reduce((x,y)=>x.until<y.until?x:y);g.q.position.copyFrom(a.root.position.add(new V(0,1.1,0)));g.until=t+.22;}
 animate(a,t,dt){const p=a.p,root=a.root,track=this.tracks.get(p.id),cast=this.casts.get(p.id),motion=this.movements.get(p.id),reaction=this.reactions.get(p.id),command=this.poses.get(p.id),base=new V(p.x||0,.08,p.z||0);
  const progress=track?(t-track.time)/Math.max(.1,track.duration):2,attacking=progress>=0&&progress<1,other=attacking?this.actors.get(track.target):null;
  let clip='Idle',phase=(t*.8+(p.seed||0))%1,yaw=root.rotation.y;
  if(other){const q=other.p,to=new V(q.x||0,.08,q.z||0),d=to.subtract(base),dist=Math.max(.01,d.length()),dir=d.scale(1/dist);yaw=Math.atan2(dir.x,dir.z);const hit=Math.sin(Math.PI*Math.min(1,progress/.62))**2;
   clip=CLIPS[track.move]||'Punch';phase=progress;if(track.move==='flurry'){phase=(progress*3)%1;clip=Math.floor(progress*3)%2?'Cross':'Punch';}
   if(track.move==='teleport'&&progress>.15&&progress<.78){base.copyFrom(to.subtract(dir.scale(-.75)));yaw+=Math.PI;root.scaling.setAll(1);if(progress<.3)for(const m of a.rig.meshes)m.visibility=.18;}
   else{base.addInPlace(dir.scale(Math.max(0,dist-.85)*hit));base.x+=Math.cos(yaw)*Math.sin(progress*Math.PI*2)*.13;base.z-=Math.sin(yaw)*Math.sin(progress*Math.PI*2)*.13;}
   if(track.move==='airKick')base.y+=Math.sin(Math.PI*progress)*1.1;
   if(track.move==='teleport'||track.move==='dash')if(t-(a.lastGhost||0)>.06){this.afterimage(a);a.lastGhost=t;}
  }else{const enemy=[...this.actors.values()].find(q=>q.p.id!==p.id&&q.p.hp>0&&q.p.team!==p.team);if(enemy)yaw=Math.atan2(enemy.root.position.x-root.position.x,enemy.root.position.z-root.position.z);}
  if(motion&&t-motion.at<motion.duration){const k=(t-motion.at)/motion.duration;if(motion.motion==='run'){clip='Run';phase=(k*3)%1;base.x+=Math.sin(k*Math.PI*2)*1.1;base.z+=Math.sin(k*Math.PI*4)*.45;yaw+=Math.cos(k*Math.PI*2)*.55;}else{clip='Fly';phase=k;base.y+=Math.sin(Math.PI*k)*(motion.motion==='levitate'?2:1.3);base.x+=Math.sin(k*Math.PI*2)*.6;}}
  const cAge=cast?t-cast.at:99;if(cAge<(cast?.domain?1.8:.72)){clip=cast.domain?'Domain':'Cast';phase=Math.min(1,cAge/(cast.domain?1.8:.72));}
  if(p.guardUntil>(this.state?.serverTime||0)&&!attacking){clip='Guard';phase=.4;}
  if(reaction&&t-reaction.time<.27&&reaction.defense==='dodge'){clip='Dodge';phase=(t-reaction.time)/.27;base.x+=Math.cos(yaw)*Math.sin(phase*Math.PI)*.6;}
  else if(reaction&&reaction.defense==='block'&&t-reaction.time<.24&&!attacking){clip='Guard';phase=.6;}
  else if(reaction&&t-reaction.time<.18&&!attacking){clip='Hit';phase=(t-reaction.time)/.18;base.addInPlace(new V(-Math.sin(yaw),0,-Math.cos(yaw)).scale(Math.sin(phase*Math.PI)*.25));}
  if(command){const age=t-command.at;if(command.pose==='pular'&&age<.85){clip='Jump';phase=age/.85;base.y+=Math.sin(phase*Math.PI)*1.05;}if(command.pose==='dancar'&&age<8&&!attacking){clip='Guard';phase=.4;base.y+=Math.abs(Math.sin(t*(this.state?.rhythm.bpm||110)/60*Math.PI))*.12;yaw+=Math.sin(t*5)*.25;}}
  if(p.status==='dead'){clip='KO';phase=1;root.rotation.z=.5;root.rotation.x=-1.25;base.y=.35;}else{root.rotation.z=0;root.rotation.x=0;}
  const moving=base.subtract(root.position).length();if(!attacking&&clip==='Idle'&&moving>.18){clip='Walk';phase=(t*1.7)%1;}
  root.position.copyFrom(V.Lerp(root.position,base,Math.min(1,dt*(attacking?42:12))));const delta=Math.atan2(Math.sin(yaw-root.rotation.y),Math.cos(yaw-root.rotation.y));root.rotation.y+=delta*Math.min(1,dt*24);a.rig?.pose(clip,phase,dt);
  for(const m of a.rig?.meshes||[])if(!(attacking&&track.move==='teleport'&&progress>.15&&progress<.3))m.visibility=1;
  a.label.setEnabled(!this.state?.domain);
 }
 render(){if(!this.assets)return;const t=performance.now()/1000,dt=clamp(t-(this.time||t),0,.08);this.time=t;
  if(this.autoFights&&this.snapshot?.fights?.length>1&&t>this.switchAt){const fights=this.snapshot.fights,i=fights.findIndex(f=>f.id===this.selectedFight);this.selectFight(fights[(i+1)%fights.length].id,false);}
  const impulse=Math.exp(-Math.max(0,t-this.beatAt)*17)*this.pulseStrength;
  for(const a of this.actors.values())this.animate(a,t,dt);
  const domain=this.state?.domain,isVoid=domain?.technique==='void',center=this.fight?.center||{x:0,z:0};this.domainRoot.setEnabled(!!domain);this.voidShell.setEnabled(!!isVoid);this.infinity.forEach((q,i)=>{q.setEnabled(!!isVoid);q.rotation.z=t*.08+i*.13;});this.scene.fogColor=isVoid?new C(.005,.008,.025):domain?.technique==='shrine'?new C(.12,.025,.06):new C(.04,.07,.14);
  if(domain){this.domainSet(domain.technique);this.domainRoot.position.set(center.x,0,center.z);const col=C.FromHexString(TECHNIQUES[domain.technique]?.color||'#a19cff');this.dome.setEnabled(!isVoid);this.dome.material.diffuseColor=col;this.dome.material.emissiveColor=col.scale(.4);this.domainRing.material.emissiveColor=col;this.domainRing.rotation.y=t*.3;this.temple.setEnabled(domain.technique==='shrine');for(let i=0;i<this.stars.length;i++)this.stars[i].scaling.setAll(.4+Math.abs(Math.sin(t*2+i)));this.clashRing.setEnabled(!!domain.challenger);if(domain.challenger){this.clashRing.material.emissiveColor=C.FromHexString(TECHNIQUES[domain.challenger.technique].color);this.clashRing.rotation.z=t*1.3;}}
  for(const [id,node]of this.domainSets)node.setEnabled(domain?.technique===id);
  this.kogane.position.set(center.x+3.3,3+Math.sin(t*2)*.15,center.z-2);this.kogane.rotation.y=t;this.kogane.scaling.setAll(this.koganePulse&&t-this.koganePulse<2?1.6:.65);
  this.neons.forEach((m,i)=>m.emissiveColor=m.diffuseColor.scale(.6+(this.reduceMotion?.05:.65)*impulse*(i===this.pulse%3?1:.3)));this.fx.update(t,this.reduceMotion);
  for(const g of this.ghosts){g.q.setEnabled(t<g.until&&!this.reduceMotion);g.q.visibility=clamp((g.until-t)/.22,0,1)*.35;}
  const hazard=this.state?.hazard;this.warningRing.setEnabled(!!hazard);if(hazard){this.warningRing.position.set(hazard.x,.12,hazard.z);this.warningRing.scaling.set(hazard.radius*2,1,hazard.radius*2);this.warningRing.visibility=this.reduceMotion?.5:.4+Math.abs(Math.sin(t*7))*.4;}
  this.updateCamera(t,dt,impulse);this.scene.render();this.renderBubbles();
 }
 updateCamera(t,dt,impulse=0){const actors=[...this.actors.values()],positions=actors.map(a=>a.root.position),middle=positions.length?positions.reduce((p,q)=>p.add(q),V.Zero()).scale(1/positions.length):new V(this.fight?.center.x||0,0,this.fight?.center.z||0);let target=middle.add(new V(0,1.25,0));
  if(this.cinematic&&!this.reduceMotion)this.angle+=dt*.1;let angle=this.angle;
  if(positions.length===2&&this.cinematic){const d=positions[1].subtract(positions[0]);angle=Math.atan2(-d.z,d.x)+Math.sin(t*.18)*.22;}
  if(positions.length===3&&this.cinematic){const center=this.fight?.center||{x:middle.x,z:middle.z};const candidates=actors.flatMap(a=>{const x=Math.atan2((a.p.x||0)-center.x,(a.p.z||0)-center.z);return[x,x+Math.PI];});angle=candidates.reduce((best,a)=>Math.abs(Math.atan2(Math.sin(a-this.angle),Math.cos(a-this.angle)))<Math.abs(Math.atan2(Math.sin(best-this.angle),Math.cos(best-this.angle)))?a:best,candidates[0])+Math.sin(t*.2)*.12;}
  const shot=this.shot?.until>t?this.shot:null;if(shot&&!this.reduceMotion&&this.cinematic)angle+=Math.sin((t-shot.time)*2)*.15;
  let bound=1.5;for(const p of positions)bound=Math.max(bound,Math.hypot(p.x-middle.x,p.z-middle.z)+.6);
  const aspect=this.engine.getAspectRatio(this.camera),radius=Math.max(6.7,bound/(Math.tan(.36)*Math.max(.38,aspect)));
  const destination=target.add(new V(Math.sin(angle)*radius,2.25,Math.cos(angle)*radius));this.camera.position.copyFrom(this.cameraCut?destination:V.Lerp(this.camera.position,destination,Math.min(1,dt*6)));this.cameraCut=false;this.camera.setTarget(target);this.camera.fov=.72-(this.reduceMotion?0:impulse*.008);this.camera.rotation.z=this.reduceMotion?0:(shot?.black?Math.sin((t-shot.time)*32)*Math.exp(-(t-shot.time)*9)*.022:0);
  const points=positions.flatMap(p=>[p.add(new V(0,.12,0)),p.add(new V(0,.6,0)),p.add(new V(0,1.2,0)),p.add(new V(0,2.25,0)),p.add(new V(0,2.7,0))]);if(!points.length)points.push(target);
  for(const b of this.occluders||this.buildings){b.computeWorldMatrix(true);const bounds=b.getBoundingInfo().boundingBox,minimum=bounds.minimumWorld.subtract(new V(.25,.25,.25)),maximum=bounds.maximumWorld.add(new V(.25,.25,.25));b.visibility=points.some(point=>{const d=point.subtract(this.camera.position),distance=d.length(),r=new B.Ray(this.camera.position,d.normalize(),distance);return r.intersectsBoxMinMax(minimum,maximum);})?.035:1;}
 }
 metrics(){return{...super.metrics(),visibleCombatants:this.fight?.members.length||0,encounters:this.snapshot?.fights?.length||0,selectedFight:this.selectedFight,modelsReady:!!this.assets?.loaded,cellMaterials:this.assets?.materials.size||0,rigged:this.actors.size? [...this.actors.values()].every(a=>a.rig?.skeletons.length>0):false,bones:[...this.actors.values()].reduce((n,a)=>n+(a.rig?.skeletons[0]?.bones.length||0),0)};}
}
