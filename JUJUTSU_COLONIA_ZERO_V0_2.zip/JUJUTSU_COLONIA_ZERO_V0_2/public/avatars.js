const B=BABYLON,V=B.Vector3,Q=B.Quaternion;
const IDS=['gojo','yuji','megumi','nobara','yuta','kenjaku','mahito','jogo','sukuna','citizen'];
function valueAt(track,frame){const keys=track.getKeys();if(!keys.length)return null;if(frame<=keys[0].frame)return keys[0].value;const last=keys[keys.length-1];if(frame>=last.frame)return last.value;let lo=0,hi=keys.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(keys[m].frame>frame)hi=m;else lo=m;}const a=keys[lo],b=keys[hi],t=(frame-a.frame)/(b.frame-a.frame);return a.value.w!==undefined?Q.Slerp(a.value,b.value,t):V.Lerp(a.value,b.value,t);}
export class AvatarLibrary {
 constructor(world){this.w=world;this.containers=new Map();this.materials=new Map();this.loaded=false;this.ready=this.load();}
 async load(){for(let i=0;i<IDS.length;i+=3)await Promise.all(IDS.slice(i,i+3).map(async id=>{const c=await B.SceneLoader.LoadAssetContainerAsync('/assets/models/',id+'.glb',this.w.scene);for(const g of c.animationGroups)g.stop();this.containers.set(id,c);}));this.loaded=true;return this;}
 cell(original){if(!original)return null;if(this.materials.has(original.uniqueId))return this.materials.get(original.uniqueId);let m;
  if(B.CellMaterial){m=new B.CellMaterial('anime-'+original.name,this.w.scene);m.computeHighLevel=true;m.diffuseColor=(original.albedoColor||original.diffuseColor||B.Color3.White()).clone();m.diffuseTexture=original.albedoTexture||original.diffuseTexture||null;m.maxSimultaneousLights=3;}
  else{m=new B.StandardMaterial('anime-'+original.name,this.w.scene);m.diffuseColor=(original.albedoColor||B.Color3.White()).clone();m.diffuseTexture=original.albedoTexture||null;m.specularColor=B.Color3.Black();}
  m.backFaceCulling=false;this.materials.set(original.uniqueId,m);return m;
 }
 spawn(id,parent){const template=this.containers.get(id);if(!template)return null;const entry=template.instantiateModelsToScene(n=>parent.name+':'+n,false,{doNotInstantiate:true});const pivot=new B.TransformNode('avatar-pivot',this.w.scene);pivot.parent=parent;for(const n of entry.rootNodes)n.parent=pivot;
  const meshes=entry.rootNodes.flatMap(n=>n.getChildMeshes?.()||[]);let min=Infinity,max=-Infinity;
  for(const m of meshes){m.computeWorldMatrix(true);const box=m.getBoundingInfo().boundingBox;min=Math.min(min,box.minimumWorld.y);max=Math.max(max,box.maximumWorld.y);m.material=this.cell(m.material);m.isPickable=false;m.renderOutline=this.w.profile!=='low';m.outlineWidth=.006;m.outlineColor=new B.Color3(.025,.03,.05);this.w.shadow?.addShadowCaster(m,false);}
  const scale=2.1/Math.max(.1,max-min);pivot.scaling.setAll(scale);pivot.position.y=-min*scale;
  const marker=entry.rootNodes.flatMap(n=>n.getDescendants?.()||[]).find(n=>n.name.endsWith(':FrontMarker'));
  if(marker){marker.computeWorldMatrix(true);if(marker.getAbsolutePosition().z<0)pivot.rotation.y=Math.PI;}
  const clips=new Map();for(const group of entry.animationGroups){group.stop();clips.set(group.name.split(':').at(-1),{tracks:group.targetedAnimations,from:group.from,to:group.to});}
  const nodes=entry.rootNodes.flatMap(n=>n.getDescendants?.()||[]);const rig={clips,nodes,pivot,meshes,skeletons:entry.skeletons,kind:'Idle',phase:0};
  rig.pose=(kind,phase,dt=.016)=>{const clip=clips.get(kind)||clips.get('Idle');if(!clip)return;rig.kind=kind;rig.phase=phase;const frame=clip.from+Math.max(0,Math.min(1,phase))*(clip.to-clip.from);const blend=Math.min(1,dt*32);
   for(const {target,animation}of clip.tracks){const value=valueAt(animation,frame);if(!value)continue;const prop=animation.targetProperty;
    if(prop==='rotationQuaternion'){if(!target.rotationQuaternion)target.rotationQuaternion=Q.Identity();Q.SlerpToRef(target.rotationQuaternion,value,blend,target.rotationQuaternion);}
    else if(prop==='position'||prop==='scaling')target[prop].copyFrom(V.Lerp(target[prop],value,blend));
   }
  };
  rig.dispose=()=>{for(const m of meshes)this.w.shadow?.removeShadowCaster(m,false);for(const g of entry.animationGroups)g.dispose();for(const n of entry.rootNodes)n.dispose();for(const s of entry.skeletons)s.dispose();pivot.dispose();};
  rig.pose('Idle',0,1);return rig;
 }
}
