import { ArenaAudio } from "./audio.js";
export class ColonyAudio extends ArenaAudio {
 constructor(element,handlers){super(element,handlers);this.voices=true;this.sfxEnabled=true;this.voiceVolume=.65;this.cache=new Map();this.current=null;this.voiceUntil=0;this.request=0;this.lastVoice=0;this.onCaption=()=>{};}
 async voice(id,priority=1){if(!this.enabled||!this.voices||!/^[a-z]+$/.test(id||""))return false;const now=performance.now();if(priority<3&&(this.current||now-this.lastVoice<1800))return false;
  if(now<(this.pendingUntil||0)&&priority<(this.pendingPriority||0))return false;
  const ticket=++this.request;this.pendingUntil=now+2500;this.pendingPriority=priority;try{if(!this.cache.has(id)){const r=await fetch('/assets/voices/'+id+'.wav');if(!r.ok)return false;const decoded=await this.ctx.decodeAudioData(await r.arrayBuffer());this.cache.set(id,decoded);if(this.cache.size>12)this.cache.delete(this.cache.keys().next().value);}
   if(ticket!==this.request||performance.now()-now>2500||!this.voices)return false;
   if(this.current){if(priority<3)return false;this.current.stop();this.current=null;}
   const node=this.ctx.createBufferSource(),gain=this.ctx.createGain();node.buffer=this.cache.get(id);gain.gain.value=this.voiceVolume;node.connect(gain);gain.connect(this.ctx.destination);node.start();this.current=node;this.lastVoice=performance.now();
   node.onended=()=>{node.disconnect();gain.disconnect();if(this.current===node)this.current=null;};return true;
  }catch{return false;}finally{if(ticket===this.request)this.pendingUntil=0;}
 }
 sfx(kind){if(!this.sfxEnabled)return;super.sfx(kind);if(kind==="technique"){this.tone(480,.18,"sawtooth",.12);this.tone(65,.26,"sine",.36);}if(kind==="domain"){this.tone(90,.6,"sine",.42);this.tone(270,.45,"triangle",.11);}if(kind==="slash"){this.tone(1200,.085,"sine",.1);this.tone(110,.12,"triangle",.3);}if(kind==="black"){this.tone(45,.28,"sine",.6);this.tone(1800,.035,"sawtooth",.12);this.tone(150,.1,"triangle",.38);}if(kind==="lightning"){this.tone(1800,.07,"sawtooth",.1);this.tone(125,.22,"sine",.3);}if(kind==="beam"){this.tone(130,.4,"sawtooth",.12);this.tone(530,.3,"triangle",.12);}if(kind==="meteor"){this.tone(52,.38,"sine",.48);this.tone(130,.19,"sawtooth",.12);}if(kind==="rule"){this.tone(880,.25,"triangle",.22);this.tone(1320,.4,"sine",.16);}}
 stopVoice(){this.request++;this.pendingUntil=0;try{this.current?.stop();}catch{}this.current=null;}
}
