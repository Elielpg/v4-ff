# JUJUTSU LIVE · COLÔNIA ZERO 0.2.0

LIVE interativa de fã inspirada em Jujutsu Kaisen, em uma cidade 3D de Babylon.js.
A V0.2 evolui a V0.1: modelos GLB esqueléticos originais, 18 animações por modelo,
confrontos independentes de até **três participantes incluindo NPCs**, 36 técnicas
configuradas e oito expansões. A câmera mostra um confronto por vez; os demais
continuam sendo simulados na cidade. Projeto separado do PULSO ARENA e do Ben 10.
Porta padrão: **3200**.

## Instalação nova no Termux

Requer Python e Node **22.19 ou mais recente**. A primeira instalação do npm usa
internet; modelos, bibliotecas gráficas, efeitos e falas já vêm no ZIP.

```bash
termux-setup-storage
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/JUJUTSU_COLONIA_ZERO_V0_2.zip . &&
cd ~/JUJUTSU_COLONIA_ZERO_V0_2 &&
bash install.sh &&
bash start.sh
```

Se faltar ferramenta: `pkg install python nodejs-lts`.
Abra **http://127.0.0.1:3200/?v=0.2.0** no Chrome do celular. Toque em
**TESTAR A COLÔNIA** para usar participantes fictícios e liberar o som.
No menu ☰, conecte a sua LIVE para receber eventos reais. A demonstração e a LIVE
usam arquivos de progresso separados.

## Atualizar a instalação V0.1 preservando o progresso

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/JUJUTSU_COLONIA_ZERO_V0_2.zip . &&
bash ~/JUJUTSU_COLONIA_ZERO_V0_2/ATUALIZAR.sh ~/JUJUTSU_COLONIA_ZERO_V0_1 &&
cd ~/JUJUTSU_COLONIA_ZERO_V0_1 &&
bash start.sh
```

Se você renomeou a pasta antiga, substitua o último caminho. **Não aponte para
Ben 10 ou PULSO ARENA:** o atualizador confere o nome do projeto e recusa a troca.
Ele verifica o manifesto, para somente a própria instalação, cria um ZIP em
`backups/` e preserva `data/` e `logs/`. O nome da pasta antiga pode continuar
V0_1; a versão executada será 0.2.0.

Para abrir nas próximas vezes, use `cd` na pasta instalada e `bash start.sh`.
Para parar: Ctrl+C no terminal original ou `bash stop.sh` em outra sessão na
mesma pasta. Não execute duas cópias na mesma porta.

## Como participar

1. Entrou na LIVE: recebe um cidadão, inicialmente protegido por 12 segundos.
2. Seguiu ou enviou uma Rosa: recebe acesso à batalha, com time Gojo/Kenjaku e
   personagem sorteados. Seguir é uma alternativa gratuita. Até 12 jogadores
   humanos ativos, distribuídos por confrontos; excedentes entram na reserva FIFO.
3. Cada confronto tem dois ou três participantes contando NPCs. Não existe um
   alvo obrigatório: NPCs e jogadores de times adversários podem se enfrentar.
4. A cada dez curtidas **identificadas**, +1 energia e +1 HP na reserva de cura.
   Cura gradual de até 2 HP/s, reserva máxima 25 e limite de 200 HP. Curtidas
   sem autor entram apenas no total da LIVE.
5. Compartilhar dá +3% de apoio e +10 energia; intervalo 15s e apoio máximo 30%.
6. Eliminação de feiticeiro/NPC dá 5 pontos; cidadão dá 1. NPCs não ganham ranking.
   O eliminado retorna como cidadão em 16s e mantém pontos. Quem já tem acesso
   comenta **LUTAR** para voltar, sem outra Rosa.
7. Com 100 pontos disponíveis: **REGRA REFUGIO**, **REGRA TROCA**, **REGRA RESGATE**
   ou **REGRA FLUXO**. Regras controladas e temporárias; não aceitam código livre.

Cidadãos podem ser desafiados por vilões após a proteção inicial. Poderes e
perigos de um confronto não causam dano em outra batalha. Refúgio protege
cidadãos enquanto estiver ativo. Seguidores antigos só são reconhecidos se a
entrada já tiver sido observada e salva pelo jogo.

## Personagens, comandos e habilidades

Gojo, Yuji, Megumi, Nobara, Yuta, Kenjaku, Mahito e Jogo são sorteados para
jogadores. Sukuna é um NPC e pode ser desafiado com **ALVO SUKUNA** quando houver
espaço. NPCs aparecem identificados no HUD. Os modelos são originais e
estilizados; não são os modelos oficiais do anime ou de jogos licenciados.

| Comentário | Ação |
|---|---|
| SOCO / CHUTE / COMBO | Ataque manual, respeitando o intervalo |
| PODER / TECNICA 1 / TECNICA 2 / TECNICA 3 | Técnica própria, energia e recarga |
| TECNICA 4 | Expansão ou finalizador do personagem |
| DOMINIO | Expansão, apenas para personagens com domínio configurado |
| BLACK FLASH | 40 energia; recarga de 12s para o comando universal |
| DEFESA / ESQUIVA | Proteção consumida no próximo contato |
| REVERSA | Recuperação com energia; GG também cura |
| PULAR / CORRER / DANÇAR | Movimento e pose |
| VOAR | Manobra aérea específica, se o personagem a permite; 12 energia |
| TELEPORTE | Teleporte para Gojo/Sukuna; arrancada nos demais; 10 energia |
| ALVO @usuario | Desafio ao rival; não entra como quarto participante |
| KOGANE / REGRAS | Consulta os pontos e opções |
| LUTAR | Retorno de quem já foi admitido, após o tempo de recuperação |

Nobara usa Ressonância, Grampo, pregos e Black Flash; **não recebe um domínio
inventado**. O domínio de Yuji não recebe nome canônico inventado. Há referências
do mangá; técnicas, voo, danos e tempos são adaptações para a LIVE. A expansão de
Megumi representa seu jardim incompleto, sem prometer uma simulação integral da
obra. Cada um dos oito domínios tem uma composição visual distinta. Dois domínios
no mesmo confronto podem disputar a barreira durante 1,5s; prevalece um dono.
Confrontos separados podem manter expansões simultâneas.

## Presentes

| Presente | Efeito |
|---|---|
| Rosa | Entrada e energia, sem duplicar a vaga |
| Heart Me | Energia |
| GG | Reversão/cura |
| Perfume | Técnica especial do próprio personagem |
| Galaxy/Galáxia | Expansão ou finalizador; respeita recarga e disputa |
| Lion | Despertar temporário |

Presentes em sequência são processados no evento final. Poder sem alvo ou em
recarga converte-se em energia conforme as regras. Os ícones SVG são ilustrações
incluídas. No menu, o anfitrião pode associar IDs numéricos a efeitos permitidos,
por exemplo `{"5655":"rose"}`. O jogo não compra nem envia presentes.

## Câmera, áudio e música

- **‹ / ›** no HUD: escolhe o confronto. **AUTO/FIXA** alterna a troca automática
  de confronto a cada aproximadamente 12s. O seletor completo fica no menu.
- A câmera enquadra a dupla/trio, com órbita, cortes de técnica, aproximação e
  impacto. Prédios, telhados e letreiros que cobrem os corpos são atenuados.
- Três perfis: Leve, Equilibrado e Detalhado. Leve reduz resolução/efeitos e
  desativa sombras e glow. A opção de reduzir movimentos também reduz luzes.
- Escolha um arquivo MP3/WAV/M4A no menu ou use a trilha original incluída.
  Acentos rápidos podem gerar ataques entre os pulsos principais, com limite
  mínimo de 95ms e dano escalado pela cadência. Um atacante completa até quatro
  contatos antes de alternar; oponente pode defender/esquivar.
- Existem **27 falas inglesas pré-geradas**, efeitos sintetizados e cache de
  reprodução. São falas originais, sem gravações do anime, clonagem ou modelo de
  IA pesado durante a LIVE. Não há conversa livre nem voz lendo cada nome.
- Para GreenTube/fone/Bluetooth: instale o APK Pulso Batida incluído, configure
  **porta 3200**, gere o código no menu e ative o captador. O Android e o aplicativo
  de origem precisam permitir captura. Se não chegar sinal, use arquivo ou BPM.
- Após recuperação do servidor, áudio de arquivo/externo fica pausado até nova
  reprodução/conexão. O navegador exige um toque para liberar o áudio.

## Estabilidade e diagnóstico

O supervisor registra saídas e sinais em `logs/supervisor.jsonl` e faz até quatro
recuperações em 15 minutos, sem ciclo infinito. Uma cópia encerrada normalmente
não derruba outros projetos. O estado usa escrita atômica e backup recuperável.
Uma queda pode perder eventos do último segundo; o TikTok pode não reenviá-los.

Se o Android encerrar **todo** o Termux, o supervisor também para. Este pacote
não pode garantir que o sistema Android mantenha um aplicativo vivo. Use
`bash start.sh` e confira os logs. O wake lock é solicitado quando disponível.
Os testes na nuvem não equivalem a 30/60 minutos de LIVE no Realme GT3.

## Testes, arquitetura e reversão

```bash
npm test
node scripts/benchmark.mjs
```

- [Relatório V0.2](docs/RELATORIO_V0_2.md)
- [Arquitetura](docs/ARQUITETURA.md)
- [Limites e próximos passos](docs/PROBLEMAS_PENDENTES.md)
- [Reverter atualização](docs/REVERSAO.md)
- [Pesquisa de modelos e créditos](docs/PESQUISA_MODELOS.md)
- Evidências em `docs/evidencias/v02/`; prévias em `docs/previas/`.

A compilação dos próprios avatares é opcional: Blender 4.3+ com
`blender -b --python scripts/build_avatars.py`. O Termux usa os GLBs prontos e
não precisa instalar Blender, Piper, Qwen ou um clonador de voz.
