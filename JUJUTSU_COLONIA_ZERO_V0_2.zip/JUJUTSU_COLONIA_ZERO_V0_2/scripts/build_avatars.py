"""Original humanoid meshes and baked skeletal choreography. Blender 4.3+."""
import bpy,math,json,random
from mathutils import Vector,Matrix,Quaternion
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DEST=ROOT/'public/assets/models';DEST.mkdir(parents=True,exist_ok=True)
PAL={
 'gojo':('#273650','#eceff8','#f1cbb7'), 'yuji':('#27394e','#dd9b97','#edbd9f'),
 'megumi':('#27394a','#111722','#ebc5ae'), 'nobara':('#2d3e53','#a87342','#edc5ae'),
 'yuta':('#d5e2e6','#171c29','#eac8b7'), 'kenjaku':('#262139','#17151f','#ebc3a5'),
 'mahito':('#364950','#94a8be','#d0dcd6'), 'jogo':('#806c42','#5c5548','#b4a383'),
 'sukuna':('#eee6dc','#d99e94','#dfb096'), 'citizen':('#586b83','#3b343b','#e3bd9f')}
def rgba(h):return tuple(int(h[i:i+2],16)/255 for i in (1,3,5))+(1,)
def material(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=rgba(c);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgba(c);p.inputs['Roughness'].default_value=1
 return m
def assign(obj,mat,bone):
 obj.data.materials.append(mat)
 if bone:obj.vertex_groups.new(name=bone).add(list(range(len(obj.data.vertices))),1,'REPLACE')
 objects.append(obj);return obj
def mesh(n,verts,faces,mat,bone):
 data=bpy.data.meshes.new(n);data.from_pydata(verts,[],faces);data.update();o=bpy.data.objects.new(n,data);bpy.context.collection.objects.link(o);return assign(o,mat,bone)
def ell(n,center,scale,mat,bone,segments=12,rings=7):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,radius=1,location=center);o=bpy.context.object;o.name=n;o.scale=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return assign(o,mat,bone)
def box(n,center,scale,mat,bone):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return assign(o,mat,bone)
def loft(n,rings,mat,bone,axis='z'):
 verts=[];N=12
 for center,r1,r2 in rings:
  for i in range(N):
   a=i/N*math.tau
   verts.append((center[0]+r1*math.cos(a),center[1]+r2*math.sin(a),center[2]) if axis=='z' else (center[0],center[1]+r1*math.cos(a),center[2]+r2*math.sin(a)))
 faces=[tuple(range(N-1,-1,-1)),tuple((len(rings)-1)*N+i for i in range(N))]
 for j in range(len(rings)-1):
  for i in range(N):faces.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
 return mesh(n,verts,faces,mat,bone)
def strand(n,points,widths,mat,bone):
 vs=[];N=6
 for p,w in zip(points,widths):
  for i in range(N):
   a=i/N*math.tau;vs.append((p[0]+math.cos(a)*w,p[1]+math.sin(a)*w*.65,p[2]))
 fs=[tuple(range(N-1,-1,-1))]
 for j in range(len(points)-1):
  for k in range(N):fs.append((j*N+k,j*N+(k+1)%N,(j+1)*N+(k+1)%N,(j+1)*N+k))
 fs.append(tuple((len(points)-1)*N+k for k in range(N)));return mesh(n,vs,fs,mat,bone)
def rod(n,a,b,r,mat,bone):
 d=Vector(b)-Vector(a);mid=(Vector(a)+Vector(b))*.5;bpy.ops.mesh.primitive_cylinder_add(vertices=8,radius=r,depth=d.length,location=mid)
 o=bpy.context.object;o.name=n;o.rotation_mode='QUATERNION';o.rotation_quaternion=d.to_track_quat('Z','Y');bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return assign(o,mat,bone)
def make_rig():
 data=bpy.data.armatures.new('Humanoid');rig=bpy.data.objects.new('Humanoid',data);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
 def bone(n,a,b,parent=None):
  p=data.edit_bones.new(n);p.head=a;p.tail=b
  if parent:p.parent=data.edit_bones[parent]
 bone('Hips',(0,0,1),(0,0,1.12));bone('Spine',(0,0,1.12),(0,0,1.32),'Hips');bone('Spine1',(0,0,1.32),(0,0,1.51),'Spine');bone('Neck',(0,0,1.51),(0,0,1.76),'Spine1');bone('Head',(0,0,1.76),(0,0,2.06),'Neck')
 for side,s in [('L',1),('R',-1)]:
  bone('Arm'+side,(s*.23,0,1.56),(s*.52,0,1.55),'Spine1');bone('Fore'+side,(s*.52,0,1.55),(s*.78,0,1.54),'Arm'+side);bone('Hand'+side,(s*.78,0,1.54),(s*.88,0,1.54),'Fore'+side)
  for k in range(5):
   y=(k-2)*.022
   for j in range(2):bone(f'Finger{side}{k}{j}',(s*(.86+j*.045),y,1.54),(s*(.905+j*.045),y,1.54),'Hand'+side if j==0 else f'Finger{side}{k}0')
  bone('Thigh'+side,(s*.105,0,1.02),(s*.12,-.015,.59),'Hips');bone('Shin'+side,(s*.12,-.015,.59),(s*.12,0,.145),'Thigh'+side);bone('Foot'+side,(s*.12,0,.145),(s*.12,-.20,.08),'Shin'+side)
 bone('FrontMarker',(0,-.3,1.8),(0,-.31,1.81),'Head')
 bpy.ops.object.mode_set(mode='OBJECT');return rig
def ik(rig,upper,lower,end,target,pole):
 bpy.context.view_layer.update();u=rig.pose.bones[upper];lo=rig.pose.bones[lower];hand=rig.pose.bones[end];S=u.head.copy();T=Vector(target);P=Vector(pole)
 L1=rig.data.bones[upper].length;L2=rig.data.bones[lower].length;d=T-S;n=d.length or .001;direction=d.normalized();r=max(abs(L1-L2)+.003,min(n,(L1+L2)*.985));T=S+direction*r
 perp=P-S-direction*(P-S).dot(direction)
 if perp.length<.001:perp=Vector((0,-1,0))
 perp.normalize();a=(L1*L1-L2*L2+r*r)/(2*r);E=S+direction*a+perp*math.sqrt(max(0,L1*L1-a*a))
 def aim(pb,start,tip):
  rest=rig.data.bones[pb.name];v=rest.tail_local-rest.head_local;q=v.normalized().rotation_difference((tip-start).normalized())@rest.matrix_local.to_quaternion();pb.matrix=Matrix.LocRotScale(start,q,Vector((1,1,1)))
 aim(u,S,E);bpy.context.view_layer.update();aim(lo,E,T);bpy.context.view_layer.update()
def pose(rig,kind,p,char):
 for pb in rig.pose.bones:pb.rotation_mode='QUATERNION';pb.location=(0,0,0);pb.rotation_quaternion=Quaternion();pb.scale=(1,1,1)
 phase=p*math.tau;f=math.sin(math.pi*min(1,p/.62))**2 if p<.62 else 0
 # Starting/ending poses blend back to a readable guard.
 hands={s:Vector((s*.18,-.31,1.43)) for s in [-1,1]};feet={s:Vector((s*.13,-.04,.15))for s in [-1,1]}
 lean=0;twist=0
 if kind=='Guard':
  hands[1]=Vector((.14,-.26,1.67));hands[-1]=Vector((-.14,-.28,1.65));lean=.04
 if kind in ['Walk','Run']:
  strength=.22 if kind=='Walk' else .37
  for s in [-1,1]:
   z=math.sin(phase+s*math.pi/2);feet[s]=Vector((s*.13,-z*strength,.15+max(0,z)*(.12 if kind=='Walk' else .22)));hands[s]=Vector((s*.28,z*strength*.5,1.12 if kind=='Walk' else 1.36))
  lean=.05 if kind=='Walk' else .15
 if kind in ['Punch','Cross','Hook','Uppercut','BlackFlash']:
  side=-1 if kind=='Cross' else 1
  hands[side]=Vector((side*(.10 if kind!='Hook' else .35-.6*f),-.28-.38*f,1.43+(f*.35 if kind=='Uppercut' else 0)));twist=side*f*.22;lean=f*.09
 if kind in ['Kick','AirKick']:
  feet[1]=Vector((.13,-.05-.76*f,.15+.78*f));hands[1]=Vector((.35,.15,1.25));hands[-1]=Vector((-.35,-.12,1.4));lean=-f*.18
 if kind in ['Jump','AirKick','Fly']:
  if kind!='AirKick':feet[1]=Vector((.16,-.28,.6));feet[-1]=Vector((-.17,.16,.35));hands[1]=Vector((.35,-.12,1.4));hands[-1]=Vector((-.35,-.15,1.45));lean=.08
 if kind=='Dodge':
  lean=.32*math.sin(math.pi*p);hands[1].z-=.15;hands[-1].z-=.15
 if kind=='Cast':hands[1]=Vector((.11,-.55,1.5));hands[-1]=Vector((-.14,-.35,1.24));twist=.12
 if kind=='Domain':
  hands[1]=Vector((.05 if char=='gojo' else .055,-.30,1.67 if char=='gojo' else 1.43));hands[-1]=Vector((-.11 if char=='gojo' else -.055,-.28,1.29 if char=='gojo' else 1.43))
 if kind=='Hit':lean=-.2*math.sin(math.pi*p);twist=.1
 if kind=='KO':lean=-.25
 rig.pose.bones['Spine'].rotation_quaternion=Quaternion((1,0,0),lean)
 rig.pose.bones['Spine1'].rotation_quaternion=Quaternion((0,1,0),twist)
 bpy.context.view_layer.update()
 for side,s in [('L',1),('R',-1)]:
  ik(rig,'Arm'+side,'Fore'+side,'Hand'+side,hands[s],(s*.55,-.02,1.2));ik(rig,'Thigh'+side,'Shin'+side,'Foot'+side,feet[s],(s*.13,-.9,.52))
  for k in range(5):
   for j in range(2):
    pb=rig.pose.bones[f'Finger{side}{k}{j}'];curl=0 if kind in ['Cast','Fly'] or (kind=='Domain' and char=='gojo' and k in [1,2]) else .9
    pb.rotation_quaternion=Quaternion((1,0,0),curl*s)
 for pb in rig.pose.bones:
  if pb.name not in ['FrontMarker']:pb.keyframe_insert('rotation_quaternion');pb.keyframe_insert('location')
def build(char):
 global objects
 bpy.ops.wm.read_factory_settings(use_empty=True);objects=[];suitHex,hairHex,skinHex=PAL[char];suit=material('cloth',suitHex);hair=material('hair',hairHex);skin=material('skin',skinHex);dark=material('ink','#101623');white=material('white','#f1f0e7');iris=material('iris','#b82943' if char=='sukuna' else '#4b91ae');gold=material('gold','#b6975b');red=material('red','#9f3249')
 rig=make_rig()
 torso=loft('tailored jacket',[((0,0,1.00),.145,.08),((0,0,1.13),.14,.085),((0,0,1.37),.20,.105),((0,0,1.57),.235,.09),((0,0,1.65),.08,.055)],suit,'Spine')
 # Smooth skinning across the torso rather than rigid capsule parts.
 torso.vertex_groups.clear()
 for name in ['Hips','Spine','Spine1']:torso.vertex_groups.new(name=name)
 for v in torso.data.vertices:
  z=v.co.z
  if z<1.12:weights={'Hips':1}
  elif z<1.32:
   t=(z-1.12)/.2;weights={'Hips':1-t,'Spine':t}
  elif z<1.52:
   t=(z-1.32)/.2;weights={'Spine':1-t,'Spine1':t}
  else:weights={'Spine1':1}
  for name,w in weights.items():
   if w>0:torso.vertex_groups[name].add([v.index],w,'REPLACE')
 loft('neck',[((0,0,1.62),.052,.05),((0,0,1.77),.052,.05)],skin,'Neck')
 loft('jaw and skull',[((0,0,1.715),.043,.055),((0,-.008,1.76),.085,.08),((0,0,1.845),.123,.112),((0,.005,1.94),.118,.107),((0,.012,2.015),.068,.07)],skin,'Head')
 for side,s in [('L',1),('R',-1)]:
  loft('upper sleeve',[((s*.225,0,1.56),.075,.08),((s*.36,0,1.55),.067,.075),((s*.52,0,1.55),.05,.055)],suit if char!='sukuna' else skin,'Arm'+side,'x')
  loft('forearm',[((s*.52,0,1.55),.05,.055),((s*.63,0,1.545),.055,.058),((s*.78,0,1.54),.035,.039)],suit if char not in ['sukuna','mahito'] else skin,'Fore'+side,'x')
  box('palm',(s*.825,0,1.54),(.10,.09,.035),skin,'Hand'+side)
  for k in range(5):
   for j in range(2):ell('finger',(s*(.88+j*.04),(k-2)*.022,1.54),(.03,.012,.015),skin,f'Finger{side}{k}{j}',8,4)
  loft('thigh',[((s*.105,0,1.02),.10,.09),((s*.115,0,.79),.09,.085),((s*.12,-.015,.59),.066,.064)],suit,'Thigh'+side)
  loft('shin',[((s*.12,-.015,.59),.066,.064),((s*.12,0,.4),.068,.07),((s*.12,0,.15),.044,.05)],suit,'Shin'+side)
  loft('boot',[((s*.12,-.065,.025),.073,.145),((s*.12,-.065,.08),.075,.14),((s*.12,-.015,.17),.052,.065)],dark,'Foot'+side)
  ell('elbow seam',(s*.52,0,1.55),(.055,.055,.055),suit if char not in ['sukuna','mahito'] else skin,'Fore'+side,10,5)
  ell('knee seam',(s*.12,-.015,.59),(.068,.067,.07),suit,'Shin'+side,10,5)
  ell('ear',(s*.126,.005,1.85),(.026,.025,.045),skin,'Head',8,5)
 # Sharply drawn eyes, iris and eyebrows are geometry, avoiding low-resolution faces.
 if char!='gojo':
  positions=[0] if char=='jogo' else [-.058,.058]
  for x in positions:
   z=1.875;r=.068 if char=='jogo' else .042
   mesh('almond eye',[(x-r,-.111,z+.005),(x+r,-.111,z+.012),(x+r*.65,-.119,z-.018),(x-r*.7,-.119,z-.016)],[(0,1,2,3)],white,'Head')
   ell('iris',(x,-.124,z-.004),(.012,.005,.018),iris,'Head',10,6);ell('pupil',(x,-.129,z-.004),(.005,.002,.014),dark,'Head',8,5)
   rod('eyebrow',(x-r,-.112,z+.031),(x+r,-.112,z+.023),.005,dark,'Head')
   ell('eye glint',(x-.004,-.132,z+.004),(.003,.001,.004),white,'Head',6,4)
 else:
  loft('blindfold',[((0,0,1.855),.131,.118),((0,0,1.905),.13,.116)],dark,'Head')
  rod('fold edge',(-.105,-.118,1.9),(.105,-.118,1.9),.002,material('fold sheen','#4c586d'),'Head')
 mesh('nose',[(0,-.116,1.858),(-.013,-.124,1.813),(0,-.145,1.819),(.013,-.124,1.813)],[(0,1,2),(0,2,3)],skin,'Head')
 rod('mouth',(-.025,-.102,1.776),(.026,-.102,1.78),.0025,dark,'Head')
 # Hair cap plus individually shaped tapered locks.
 ell('hair cap',(0,.015,1.966),(.128,.108,.085),hair,'Head',14,7)
 rng=random.Random(char)
 count=15 if char in ['gojo','megumi','yuji','sukuna'] else 10
 for i in range(count):
  a=i/count*math.tau;x=math.cos(a)*.10;y=math.sin(a)*.085
  length=(.13+rng.random()*.05) if char=='megumi' else (.065+rng.random()*.065) if char=='gojo' else .045 if char in ['yuji','sukuna'] else .025
  # Swept, irregular locks rather than a ring of vertical crown spikes.
  tip=Vector((x*(1.55 if char=='megumi' else .8)+(.025 if char=='gojo' else 0),y*1.5+.015,2.0+length))
  strand('hair lock',[(x,y,1.955),(x*1.1+.015,y*1.1,2.01),tip],[.047,.035,.001],hair,'Head')
 if char=='gojo':
  for i in range(5):
   x=-.10+i*.047;strand('swept fringe',[(x,-.07,1.99),(x+.03,-.11,2.06),(x+.07,-.06,2.11+rng.random()*.035)],[.04,.03,.001],hair,'Head')
 if char in ['nobara','mahito','kenjaku','yuta']:
  count=8 if char!='yuta' else 5
  for i in range(count):
   a=(i/(count-1)*math.pi)+.05;x=math.cos(a)*.12;y=math.sin(a)*.1+.035;bottom=1.6 if char in ['mahito','kenjaku'] else 1.76
   strand('long hair',[(x,y,1.97),(x*1.1,y*1.1,1.82),(x*1.05,y*1.15,bottom)],[.04,.04,.025],hair,'Head')
  for s in [-1,1]:strand('fringe',[(s*.09,-.06,1.99),(s*.075,-.115,1.94),(s*.10,-.11,1.85)],[.04,.03,.002],hair,'Head')
 if char=='kenjaku':
  ell('hair bun',(0,.05,2.067),(.065,.065,.07),hair,'Head');box('gold stole',(-.11,-.11,1.39),(.095,.025,.52),gold,'Spine1')
  for i in range(7):x=-.1+i*.033;rod('forehead stitch',(x,-.105,1.938),(x+.008,-.108,1.92),.002,dark,'Head')
 if char=='yuji':loft('red hood',[((0,0,1.54),.09,.08),((0,0,1.69),.09,.08)],red,'Neck')
 if char in ['gojo','megumi','nobara']:loft('high collar',[((0,0,1.57),.075,.065),((0,0,1.72),.075,.065)],suit,'Neck')
 if char in ['sukuna','kenjaku']:
  box('obi',(0,-.005,1.09),(.31,.19,.075),red if char=='sukuna' else gold,'Hips')
  if char=='sukuna':
   box('open kimono',(0,-.108,1.41),(.17,.02,.4),skin,'Spine1')
   for s in [-1,1]:
    for z in [1.38,1.45,1.52]:rod('chest tattoo',(s*.025,-.125,z),(s*.07,-.125,z+.025),.0035,dark,'Spine1')
    for k in [0,1]:rod('facial tattoo',(s*.045,-.115,1.832-k*.014),(s*.095,-.102,1.816-k*.008),.003,dark,'Head')
 if char=='mahito':
  for i in range(6):x=-.1+i*.04;rod('face stitch',(x,-.112,1.83),(x+.01,-.117,1.816),.002,dark,'Head')
 if char=='jogo':
  bpy.ops.mesh.primitive_torus_add(major_radius=.087,minor_radius=.017,major_segments=16,minor_segments=6,location=(0,0,2.065));assign(bpy.context.object,material('lava','#f49a3e'),'Head')
 if char=='yuta':
  rod('katana sheath',(-.18,.12,.78),(-.25,.12,1.5),.025,dark,'Hips');rod('sword grip',(-.25,.12,1.5),(-.27,.12,1.68),.025,dark,'Hips')
 if char=='nobara':box('hammer handle',(.84,-.025,1.49),(.035,.035,.25),dark,'HandL');box('hammer head',(.84,-.025,1.34),(.16,.07,.075),material('hammer steel','#7c8d9c'),'HandL')
 for z in [1.22,1.34,1.46]:ell('jacket button',(.045,-.108,z),(.009,.006,.009),gold,'Spine1',8,4)
 for side,sign in [('L',1),('R',-1)]:
  rod('sleeve seam',(sign*.29,-.075,1.55),(sign*.49,-.055,1.545),.0025,dark,'Arm'+side)
 # Join into one skinned mesh with a small shared material palette.
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();body=bpy.context.object;body.name=char+'_skinned'
 body.parent=rig;mod=body.modifiers.new('Humanoid skin','ARMATURE');mod.object=rig
 for poly in body.data.polygons:poly.use_smooth=True
 rig.animation_data_create();clips=['Idle','Walk','Run','Punch','Cross','Hook','Uppercut','Kick','AirKick','Guard','Dodge','Jump','Fly','Cast','Domain','BlackFlash','Hit','KO']
 for kind in clips:
  action=bpy.data.actions.new(kind);rig.animation_data.action=action
  for frame in range(0,31,2):bpy.context.scene.frame_set(frame);pose(rig,kind,frame/30,char)
  for curve in action.fcurves:
   for k in curve.keyframe_points:k.interpolation='LINEAR'
 rig.animation_data.action=None
 for pb in rig.pose.bones:pb.location=(0,0,0);pb.rotation_quaternion=Quaternion()
 bpy.context.scene.render.fps=30;bpy.context.scene.frame_start=0;bpy.context.scene.frame_end=30;bpy.context.view_layer.update()
 bpy.ops.object.select_all(action='DESELECT');body.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=rig
 props=bpy.ops.export_scene.gltf.get_rna_type().properties.keys();opts={'filepath':str(DEST/(char+'.glb')),'export_format':'GLB','use_selection':True,'export_animations':True,'export_skins':True,'export_yup':True}
 if 'export_animation_mode'in props:opts['export_animation_mode']='ACTIONS'
 if 'export_anim_single_armature'in props:opts['export_anim_single_armature']=True
 if 'export_force_sampling'in props:opts['export_force_sampling']=True
 bpy.ops.export_scene.gltf(**opts)
 return {'id':char,'vertices':len(body.data.vertices),'triangles':sum(len(p.vertices)-2 for p in body.data.polygons),'bones':len(rig.data.bones),'clips':clips,'bytes':(DEST/(char+'.glb')).stat().st_size,'origin':'Original Blender model; no third-party character mesh included'}
if __name__=='__main__':
 report=[build(char)for char in PAL]
 (DEST/'manifest.json').write_text(json.dumps({'height':2.15,'avatars':report},indent=2));print('AVATARS_COMPLETE')
