/** Portable CPU/state benchmark. Virtual game time, not a device or LIVE benchmark. */
import {ArenaEngine} from '../server/engine.mjs';
import {performance} from 'node:perf_hooks';
let now=100000;const engine=new ArenaEngine({now:()=>now});
for(let i=0;i<1000;i++)engine.ingest({type:'join',user:'viewer'+i});
for(let i=0;i<12;i++)engine.ingest({type:'follow',user:'viewer'+i});
const cpu0=process.cpuUsage(),start=performance.now(),rssStart=process.memoryUsage().rss;let snapshots=0;
for(let step=0;step<36000;step++){
 now+=50;engine.tick();
 if(step%100===0)for(let i=0;i<12;i++){const p=engine.players.get('viewer'+i);if(p.status==='citizen'&&p.nextEntryAt<=now)engine.enter(p,'benchmark');}
 if(step%20===0){JSON.stringify(engine.public());snapshots++;}
 for(const fight of engine.matches.fights.values())if(fight.members.length>3)throw Error('Confronto excedeu três participantes');
}
const cpu=process.cpuUsage(cpu0),saved=JSON.parse(JSON.stringify(engine.save())),restored=new ArenaEngine({now:()=>now,saved});
const finite=[...engine.players.values(),...engine.npcs.values()].every(p=>Number.isFinite(p.hp)&&Number.isFinite(p.x)&&Number.isFinite(p.energy)&&Number.isFinite(p.points));
if(!finite||engine.recent.length>40||restored.players.size!==1000)throw Error('Falha no teste prolongado');
console.log(JSON.stringify({type:'CPU/state simulation; no physical phone or real LIVE',virtualSeconds:1800,steps:36000,players:engine.players.size,snapshots,wallMs:Math.round(performance.now()-start),cpuUserMs:Math.round(cpu.user/1000),cpuSystemMs:Math.round(cpu.system/1000),rssStart,rssEnd:process.memoryUsage().rss,eliminations:engine.totals.eliminations,encounters:engine.matches.fights.size,maxPerEncounter:Math.max(0,...engine.matches.snapshot().map(f=>f.members.length)),finite,restoredPlayers:restored.players.size},null,2));
