export const MAX_PER_FIGHT=3;
const CENTERS=[{x:0,z:0},{x:0,z:27},{x:27,z:0},{x:0,z:-27},{x:-27,z:0},{x:0,z:49},{x:49,z:0}];
export class EncounterManager {
 constructor(engine){this.e=engine;this.fights=new Map();this.seq=0;}
 entity(id){return id==='sukuna'?this.e.boss:this.e.players.get(id)||this.e.npcs.get(id);}
 of(p){return p?this.fights.get(p.encounterId):null;}
 members(f){return(f?.members||[]).map(id=>this.entity(id)).filter(Boolean);}
 eligible(a,b){return a&&b&&a.id!==b.id&&b.hp>0&&b.status!=='dead'&&(a.team!==b.team||a.target===b.id||b.target===a.id);}
 create(){const id='fight_'+(++this.seq),center=CENTERS[(this.seq-1)%CENTERS.length];const f={id,number:this.seq,center:{...center},members:[],turn:0,phase:'fighting',until:0,domain:null,hazard:null,nextHazard:this.e.now()+18000};this.fights.set(id,f);return f;}
 attach(p,f){if(!p||!f||f.members.length>=MAX_PER_FIGHT)return false;if(p.encounterId===f.id)return true;this.detach(p);f.members.push(p.id);p.encounterId=f.id;return true;}
 detach(p){const f=this.of(p);if(f){f.members=f.members.filter(id=>id!==p.id);if(f.domain?.player===p.id)f.domain=null;}p.encounterId=null;}
 npc(team,f){const e=this.e;let p;
  if(team==='kenjaku'&&f.number%3===0&&!e.boss.encounterId&&e.boss.alive){p=e.boss;}
  else{const chars=team==='kenjaku'?['mahito','jogo','kenjaku']:['yuji','megumi','gojo','yuta'];const char=chars[(f.number-1)%chars.length],id='npc_'+f.id;
   p={id,name:char.toUpperCase()+' · NPC',character:char,team,isNpc:true,status:'fighter',hp:230,maxHp:230,energy:65,support:0,points:0,earned:0,kills:0,deaths:0,seed:f.number*101,x:f.center.x,z:f.center.z,cooldowns:{},protectedUntil:0};e.npcs.set(id,p);}
  this.attach(p,f);return p;
 }
 assign(p){const open=[...this.fights.values()].find(f=>f.phase==='fighting'&&f.members.length<MAX_PER_FIGHT&&this.members(f).some(q=>q.hp>0&&q.team!==p.team));const f=open||this.create();this.attach(p,f);if(f.members.length===1)this.npc(p.team==='gojo'?'kenjaku':'gojo',f);return f;}
 challenge(p,target){if(!target||p.id===target.id||target.hp<=0||p.team===target.team||(target.status==='citizen'&&p.team!=='kenjaku'))return false;let f=this.of(target);if(f&&f.phase!=='fighting')return false;if(!f){f=this.create();this.attach(target,f);}if(!f.members.includes(p.id)&&f.members.length>=MAX_PER_FIGHT)return false;this.attach(p,f);p.target=target.id;return true;}
 reconcile(){const now=this.e.now();for(const f of [...this.fights.values()]){
  if(f.phase==='victory'&&f.until>now)continue;
  const humans=this.members(f).filter(p=>!p.isNpc&&p.id!=='sukuna'&&p.status==='fighter'&&p.hp>0);
  if(!humans.length){for(const p of this.members(f)){p.encounterId=null;if(p.isNpc&&p.id!=='sukuna')this.e.npcs.delete(p.id);}this.fights.delete(f.id);continue;}
  f.members=f.members.filter(id=>{const p=this.entity(id);if(!p||p.hp<=0||p.status==='dead'){if(p)p.encounterId=null;if(p?.isNpc&&id!=='sukuna')this.e.npcs.delete(id);return false;}return true;});
  f.phase='fighting';const m=this.members(f);if(m.length<2||!m.some(a=>m.some(b=>this.eligible(a,b))))if(f.members.length<MAX_PER_FIGHT)this.npc(humans[0].team==='gojo'?'kenjaku':'gojo',f);
 }}
 death(victim,winner){const f=this.of(victim);if(!f)return;f.phase='victory';f.until=this.e.now()+2600;f.winner=winner?.id;f.domain=null;f.hazard=null;}
 positions(now){for(const f of this.fights.values()){const m=this.members(f),n=m.length;for(let i=0;i<n;i++){const p=m[i];if(p.status==='dead'||p.stunnedUntil>now)continue;const a=(n===2?i*Math.PI:i*Math.PI*2/3)+f.number*.71+Math.sin(now/2200+p.seed)*.08;const r=n===2?1.65:2.05;p.x=f.center.x+Math.cos(a)*r;p.z=f.center.z+Math.sin(a)*r;}}}
 snapshot(){return[...this.fights.values()].map(f=>({...f,center:{...f.center},members:[...f.members]}));}
 restore(data){if(!Array.isArray(data))return;const assigned=new Set();for(const item of data.slice(0,8)){const f={...item,center:{...CENTERS[0],...item.center},members:[],domain:null,hazard:null,phase:'fighting',nextHazard:this.e.now()+15000};for(const id of(item.members||[]).slice(0,3)){const p=this.entity(id);if(p&&p.hp>0&&p.status==='fighter'&&!assigned.has(id)){f.members.push(id);p.encounterId=f.id;assigned.add(id);}}if(f.members.length){this.fights.set(f.id,f);this.seq=Math.max(this.seq,Number(f.number)||0);}}}
}
