import {
  DEFAULTS,
  GIFTS,
  EFFECTS,
  VERSION,
  giftRule,
  normalizeText,
} from "../public/catalog.js";
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const number = (n, max = 100000) =>
  Number.isFinite(Number(n)) ? clamp(Math.floor(Number(n)), 0, max) : 0;
const clean = (s, len = 100) =>
  String(s ?? "")
    .replace(/[\x00-\x1f<>]/g, "")
    .trim()
    .slice(0, len);
export class TowerEngine {
  constructor({
    mode = "demo",
    now = Date.now,
    onAction = () => {},
    saved = null,
  } = {}) {
    this.mode = mode;
    this.now = now;
    this.onAction = onAction;
    this.settings = { ...DEFAULTS, giftMap: {} };
    this.blocks = 0;
    this.wins = 0;
    this.round = 1;
    this.shield = 0;
    this.shieldUntil = 0;
    this.celebration = null;
    this.players = new Map();
    this.seen = new Map();
    this.streaks = new Map();
    this.recent = [];
    this.seq = 0;
    this.likeCarry = 0;
    this.roomLikeBaseline = null;
    this.lastTick = now();
    this.totals = {
      likes: 0,
      comments: 0,
      gifts: 0,
      followers: 0,
      shares: 0,
      built: 0,
      destroyed: 0,
    };
    if (saved) this.restore(saved);
  }
  action(kind, data = {}) {
    const a = { ...data, kind, id: ++this.seq, at: this.now() };
    this.recent.push(a);
    if (this.recent.length > 40) this.recent.shift();
    this.onAction(a);
    return a;
  }
  player(id, name, avatar) {
    id = clean(id, 30).replace(/^@/, "").toLowerCase();
    if (!/^[a-z0-9_.]{1,30}$/.test(id)) return null;
    if (!this.players.has(id)) {
      if (this.players.size >= 4000) {
        const candidate = [...this.players.values()]
          .filter((p) => p.score === 0)
          .sort((a, b) => a.lastSeen - b.lastSeen)[0];
        if (!candidate) return null;
        this.players.delete(candidate.id);
      }
      this.players.set(id, {
        id,
        name: clean(name || id, 28),
        avatar: null,
        score: 0,
        built: 0,
        destroyed: 0,
        likes: 0,
        gifts: 0,
        shares: 0,
        followed: false,
        lastSeen: this.now(),
        commands: {},
        lastShare: null,
        joined: this.now(),
      });
    }
    const p = this.players.get(id);
    p.lastSeen = this.now();
    if (name) p.name = clean(name, 28);
    if (avatar && safeImage(avatar)) p.avatar = avatar;
    return p;
  }
  remember(e) {
    if (!e.id) return true;
    const key =
      e.type +
      ":" +
      clean(e.id, 140) +
      (e.isStreak ? ":" + String(e.count) : "");
    if (this.seen.has(key)) return false;
    this.seen.set(key, this.now());
    if (this.seen.size > 4096) this.seen.delete(this.seen.keys().next().value);
    return true;
  }
  ingest(e) {
    if (
      !e ||
      !["join", "like", "comment", "follow", "share", "gift"].includes(e.type)
    )
      return { accepted: false, reason: "Evento inválido" };
    if (
      e.type === "gift" &&
      e.isStreak &&
      (!e.streakId || String(e.streakId) === "0") &&
      e.repeatEnd === false
    )
      return { accepted: false, reason: "Aguardando confirmação da sequência" };
    if (!this.remember(e))
      return { accepted: false, reason: "Evento repetido" };
    const p = e.user ? this.player(e.user, e.name, e.avatar) : null;
    if (e.type === "like") {
      let count = number(e.count, 1000000);
      if (e.roomTotal !== undefined && e.roomTotal !== null) {
        const current = number(e.roomTotal, Number.MAX_SAFE_INTEGER);
        if (
          !count &&
          this.roomLikeBaseline !== null &&
          current >= this.roomLikeBaseline
        )
          count = clamp(current - this.roomLikeBaseline, 0, 1000000);
        // Shards can deliver older totals. Never count the same rebound twice.
        this.roomLikeBaseline =
          this.roomLikeBaseline === null
            ? current
            : Math.max(current, this.roomLikeBaseline);
      }
      if (!count) return { accepted: false, reason: "Sem novas curtidas" };
      this.totals.likes += count;
      if (p) {
        const before = Math.floor(p.likes / this.settings.likesPerBlock);
        p.likes += count;
        p.score += Math.floor(p.likes / this.settings.likesPerBlock) - before;
      }
      this.likeCarry += count;
      const blocks = Math.floor(this.likeCarry / this.settings.likesPerBlock);
      this.likeCarry %= this.settings.likesPerBlock;
      if (blocks) this.build(blocks, null, "likes");
      this.action("likes", {
        player: p?.id || null,
        name: p?.name || "Comunidade",
        count,
        blocks,
      });
      return { accepted: true, count, blocks };
    }
    if (!p) return { accepted: false, reason: "Usuário ausente ou inválido" };
    if (e.type === "join") {
      this.action("welcome", { player: p.id, name: p.name, avatar: p.avatar });
      return { accepted: true };
    }
    if (e.type === "follow") {
      if (p.followed)
        return { accepted: false, reason: "Seguidor já reconhecido" };
      p.followed = true;
      this.totals.followers++;
      this.build(5, p, "follow");
      this.action("follow", { player: p.id, name: p.name, blocks: 5 });
      return { accepted: true };
    }
    if (e.type === "share") {
      if (p.lastShare !== null && this.now() - p.lastShare < 20000)
        return { accepted: false, reason: "Compartilhamento em intervalo" };
      p.lastShare = this.now();
      p.shares++;
      this.totals.shares++;
      this.build(3, p, "share");
      this.protect(2, p, "share");
      return { accepted: true };
    }
    if (e.type === "comment") {
      this.totals.comments++;
      const text = clean(e.text, 140),
        cmd = normalizeText(text);
      let effect = null;
      if (["bloco", "construir", "build"].includes(cmd)) effect = "build";
      if (["defesa", "escudo", "defender"].includes(cmd)) effect = "shield";
      if (cmd === "tnt") effect = "tnt";
      p.chat = { text, until: this.now() + 6000 };
      this.action("chat", { player: p.id, name: p.name, text });
      if (!effect) return { accepted: true };
      const cooldown =
        effect === "build"
          ? this.settings.chatCooldown
          : effect === "tnt"
            ? this.settings.chatTntCooldown
            : 15000;
      if (this.now() - (p.commands[effect] ?? -Infinity) < cooldown)
        return { accepted: true, limited: true };
      p.commands[effect] = this.now();
      if (effect === "build") this.build(1, p, "chat");
      if (effect === "shield") this.protect(3, p, "chat");
      if (effect === "tnt") this.blast(1, p, "tnt", "chat");
      return { accepted: true };
    }
    if (e.type === "gift") {
      const total = Math.max(1, number(e.count, 1000));
      let count = total;
      const group = clean(e.streakId, 80);
      if (e.isStreak && group && group !== "0") {
        const key = p.id + "|" + String(e.giftId || e.gift) + "|" + group,
          old = this.streaks.get(key);
        count = Math.max(0, total - (old?.count || 0));
        this.streaks.set(key, {
          count: Math.max(total, old?.count || 0),
          at: this.now(),
        });
        if (this.streaks.size > 4096)
          this.streaks.delete(this.streaks.keys().next().value);
      } else if (e.isStreak && e.repeatEnd === false)
        return {
          accepted: false,
          reason: "Aguardando confirmação da sequência",
        };
      if (!count)
        return { accepted: false, reason: "Sequência já contabilizada" };
      const rule = giftRule(e, this.settings.giftMap);
      p.gifts += count;
      this.totals.gifts += count;
      p.score += count;
      this.action("gift", {
        player: p.id,
        name: p.name,
        avatar: p.avatar,
        gift: clean(e.gift || rule?.name || "Presente", 45),
        giftId: String(e.giftId || ""),
        icon: rule?.icon || "heart_me",
        image: safeImage(e.giftImage) ? e.giftImage : null,
        count,
        total,
        effect: rule?.effect || "shield",
        amount: rule?.amount || 1,
      });
      if (!rule) {
        this.protect(Math.min(10, count), p, "gift");
        return { accepted: true, count, unknown: true };
      }
      const amount = clamp(number(rule.amount, 1000) * count, 0, 50000);
      if (rule.effect === "build") this.build(amount, p, "gift");
      if (["tnt", "airstrike", "lightning"].includes(rule.effect))
        this.blast(amount, p, rule.effect, "gift");
      if (rule.effect === "fill")
        this.build(
          this.settings.goal -
            this.blocks +
            Math.max(0, count - 1) * this.settings.goal,
          p,
          "fill",
        );
      if (rule.effect === "shield") this.protect(amount, p, "gift");
      if (rule.effect === "reset") {
        const before = this.blocks;
        this.blocks = 0;
        this.shield = 0;
        this.shieldUntil = 0;
        this.totals.destroyed += before;
        p.destroyed += before;
        p.score += before * 2;
        this.action("reset", {
          player: p.id,
          name: p.name,
          before,
          after: 0,
          source: "gift",
        });
      }
      return { accepted: true, count };
    }
  }
  build(amount, p, source) {
    amount = number(amount, 50000);
    if (!amount) return;
    const before = this.blocks,
      total = this.blocks + amount,
      won = Math.floor(total / this.settings.goal);
    this.blocks = total % this.settings.goal;
    this.totals.built += amount;
    if (p) {
      p.built += amount;
      p.score += amount;
    }
    this.action("build", {
      player: p?.id || null,
      name: p?.name || "Comunidade",
      amount,
      before,
      after: this.blocks,
      source,
      won,
    });
    if (won) {
      this.wins += won;
      this.round += won;
      this.celebration = {
        until: this.now() + 3400,
        wins:
          won +
          (this.celebration?.until > this.now() ? this.celebration.wins : 0),
        player: p?.id || null,
        name: p?.name || "Comunidade",
      };
      this.action("victory", {
        player: p?.id || null,
        name: p?.name || "Comunidade",
        won,
        wins: this.wins,
        goal: this.settings.goal,
      });
    }
  }
  blast(amount, p, kind = "tnt", source = "gift") {
    amount = number(amount, 50000);
    if (!amount) return;
    this.expireShield();
    const absorbed = Math.min(this.shield, amount);
    this.shield -= absorbed;
    const damage = Math.min(this.blocks, amount - absorbed),
      before = this.blocks;
    this.blocks -= damage;
    this.totals.destroyed += damage;
    if (p) {
      p.destroyed += damage;
      p.score += damage * 2;
    }
    this.action("blast", {
      player: p?.id || null,
      name: p?.name || "Comunidade",
      kindEffect: kind,
      amount,
      damage,
      absorbed,
      before,
      after: this.blocks,
      source,
    });
  }
  protect(amount, p, source) {
    this.expireShield();
    const gain = Math.min(
      this.settings.maxShield - this.shield,
      number(amount, 50000),
    );
    this.shield += gain;
    this.shieldUntil = this.now() + this.settings.shieldSeconds * 1000;
    this.action("shield", {
      player: p?.id || null,
      name: p?.name || "Comunidade",
      amount: gain,
      charges: this.shield,
      until: this.shieldUntil,
      source,
    });
  }
  expireShield() {
    if (this.shieldUntil <= this.now()) {
      this.shield = 0;
      this.shieldUntil = 0;
    }
  }
  tick() {
    this.lastTick = this.now();
    this.expireShield();
    if (this.celebration && this.celebration.until <= this.now()) {
      this.celebration = null;
      this.action("round", { round: this.round, blocks: this.blocks });
    }
    for (const [k, s] of this.streaks)
      if (this.now() - s.at > 600000) this.streaks.delete(k);
  }
  freeze() {
    const dt = Math.max(0, this.now() - this.lastTick);
    this.lastTick = this.now();
    if (this.shieldUntil) this.shieldUntil += dt;
    if (this.celebration) this.celebration.until += dt;
  }
  configure(data) {
    const out = { ...this.settings, giftMap: { ...this.settings.giftMap } };
    if (data.likesPerBlock !== undefined) {
      const n = Number(data.likesPerBlock);
      if (!Number.isInteger(n) || n < 1 || n > 1000)
        throw Error("Curtidas por bloco: use 1 a 1000.");
      out.likesPerBlock = n;
    }
    if (data.giftMap !== undefined) {
      if (
        !data.giftMap ||
        Array.isArray(data.giftMap) ||
        typeof data.giftMap !== "object" ||
        Object.keys(data.giftMap).length > 80
      )
        throw Error("Mapa de presentes inválido");
      const map = Object.create(null);
      for (const [key, v] of Object.entries(data.giftMap)) {
        if (
          ["__proto__", "constructor", "prototype"].includes(key) ||
          !/^[a-zA-Z0-9 _.-]{1,70}$/.test(key) ||
          !v ||
          typeof v !== "object" ||
          !EFFECTS.includes(v.effect) ||
          !Number.isInteger(v.amount) ||
          v.amount < 1 ||
          v.amount > 1000
        )
          throw Error("Use efeito permitido e quantidade de 1 a 1000.");
        map[normalizeText(key)] = {
          effect: v.effect,
          amount: v.amount,
          name: clean(v.name || key, 40),
          icon: GIFTS.some((g) => g.icon === v.icon) ? v.icon : "heart_me",
        };
      }
      out.giftMap = map;
    }
    this.settings = out;
    this.likeCarry %= out.likesPerBlock;
    return out;
  }
  public() {
    const all = [...this.players.values()],
      ranking = [...all]
        .sort((a, b) => b.score - a.score || b.built - a.built)
        .slice(0, 8);
    return {
      project: "torre-tnt-live",
      version: VERSION,
      mode: this.mode,
      serverTime: this.now(),
      blocks: this.blocks,
      goal: this.settings.goal,
      wins: this.wins,
      winGoal: this.settings.winGoal,
      round: this.round,
      shield: this.shield,
      shieldUntil: this.shieldUntil,
      celebration: this.celebration,
      likeCarry: this.likeCarry,
      totals: { ...this.totals },
      players: all
        .sort((a, b) => b.lastSeen - a.lastSeen)
        .slice(0, 12)
        .map((p) => ({ ...p, commands: undefined })),
      totalPlayers: all.length,
      ranking: ranking.map((p) => ({ ...p, commands: undefined })),
      settings: this.settings,
      lastAction: this.seq,
      recent: this.recent,
    };
  }
  save() {
    return {
      project: "torre-tnt-live",
      schema: 1,
      blocks: this.blocks,
      wins: this.wins,
      round: this.round,
      likeCarry: this.likeCarry,
      roomLikeBaseline: this.roomLikeBaseline,
      shield: this.shield,
      shieldRemaining: Math.max(0, this.shieldUntil - this.now()),
      celebration: this.celebration
        ? {
            ...this.celebration,
            remaining: Math.max(0, this.celebration.until - this.now()),
          }
        : null,
      settings: this.settings,
      totals: this.totals,
      players: [...this.players.values()],
      seen: [...this.seen],
      streaks: [...this.streaks],
      seq: this.seq,
    };
  }
  restore(s) {
    if (s.project !== "torre-tnt-live" || s.schema !== 1) return;
    this.configure(s.settings || {});
    this.blocks = number(s.blocks, this.settings.goal - 1);
    this.wins = number(s.wins, 1e9);
    this.round = Math.max(1, number(s.round, 1e9));
    this.likeCarry = number(s.likeCarry, this.settings.likesPerBlock - 1);
    this.roomLikeBaseline = s.roomLikeBaseline ?? null;
    this.shield = number(s.shield, this.settings.maxShield);
    this.shieldUntil = this.now() + number(s.shieldRemaining, 30000);
    if (s.celebration?.remaining > 0)
      this.celebration = {
        ...s.celebration,
        until: this.now() + number(s.celebration.remaining, 3400),
      };
    this.totals = { ...this.totals, ...s.totals };
    for (const p of (s.players || []).slice(-4000))
      if (p.id)
        this.players.set(p.id, {
          ...p,
          chat: null,
          commands: {},
          lastShare: null,
        });
    this.seen = new Map((s.seen || []).slice(-4096));
    this.streaks = new Map((s.streaks || []).slice(-4096));
    this.seq = number(s.seq, 1e12);
  }
}
export function safeImage(value) {
  if (typeof value !== "string" || value.length > 2200) return false;
  try {
    const u = new URL(value);
    return (
      u.protocol === "https:" &&
      [
        "tiktokcdn.com",
        "tiktokcdn-us.com",
        "tiktokcdn-eu.com",
        "tiktokcdn-in.com",
        "ibyteimg.com",
        "ibytedtos.com",
        "muscdn.com",
        "ttwstatic.com",
      ].some((d) => u.hostname === d || u.hostname.endsWith("." + d))
    );
  } catch {
    return false;
  }
}
