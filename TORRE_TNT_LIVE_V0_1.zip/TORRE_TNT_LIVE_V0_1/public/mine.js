const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const ease = (x) => {
  x = clamp(x, 0, 1);
  return x * x * (3 - 2 * x);
};
const colors = {
  green: "#b3e775",
  red: "#ff846c",
  blue: "#8adaed",
  gold: "#ffda7a",
};
export class MineWorld {
  constructor(canvas, { onImpact = () => {}, onCount = () => {} } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.onImpact = onImpact;
    this.onCount = onCount;
    this.state = null;
    this.visual = 0;
    this.pending = [];
    this.particles = [];
    this.labels = [];
    this.born = new Map();
    this.quality = "balanced";
    this.reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.shakeAt = -100;
    this.victoryAt = -100;
    this.lastFrame = 0;
    this.frames = 0;
    this.fps = 0;
    this.fpsAt = performance.now();
    this.lastCountAt = 0;
    this.counted = -1;
    this.lastTime = performance.now() / 1000;
    this.resize();
    window.addEventListener("resize", () => this.resize());
    document.fonts.ready.then(() => this.resize());
    requestAnimationFrame((t) => this.loop(t));
  }
  resize() {
    this.W = 360;
    this.H = (innerHeight / innerWidth) * this.W;
    const scale =
      this.quality === "high" ? 1.5 : this.quality === "low" ? 0.8 : 1;
    this.canvas.width = Math.round(this.W * scale);
    this.canvas.height = Math.round(this.H * scale);
    this.scale = this.canvas.width / this.W;
    this.desktop = innerWidth >= 700 && innerWidth / innerHeight >= 1.2;
    const footerTop = document
      .querySelector("footer")
      ?.getBoundingClientRect().top;
    this.floor =
      (footerTop ? (footerTop / innerWidth) * this.W : this.H - 105) - 37;
    const hud = document.getElementById("hud");
    this.top = this.desktop
      ? 34
      : ((hud?.getBoundingClientRect().bottom || 300) / innerWidth) * this.W +
        12;
    const available = Math.max(90, this.floor - this.top - 8);
    this.tile = Math.min(18, available / 23);
    this.tx = (this.desktop ? this.W * 0.63 : this.W * 0.43) - this.tile * 2.5;
    this.makeBackground();
  }
  setQuality(q) {
    this.quality = q;
    this.resize();
  }
  makeBackground() {
    this.bg = document.createElement("canvas");
    this.bg.width = 360;
    this.bg.height = Math.ceil(this.H);
    const c = this.bg.getContext("2d");
    c.fillStyle = "#282c35";
    c.fillRect(0, 0, 360, this.H);
    let seed = 317;
    const rnd = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    for (let y = 0; y < this.H; y += 20)
      for (let x = 0; x < 360; x += 20) {
        const k = Math.floor(rnd() * 8);
        c.fillStyle = `rgb(${43 + k},${47 + k},${57 + k})`;
        c.fillRect(x, y, 20, 20);
        c.fillStyle = "#1d232c";
        c.fillRect(x, y, 20, 1);
        c.fillRect(x, y, 1, 20);
        c.fillStyle = "#59616c25";
        c.fillRect(x + 2, y + 2, 16, 1);
        for (let i = 0; i < 6; i++) {
          const xx = x + 3 + Math.floor(rnd() * 15),
            yy = y + 3 + Math.floor(rnd() * 15);
          c.fillStyle = rnd() < 0.5 ? "#c7c8a008" : "#00000012";
          c.fillRect(xx, yy, 2, 2);
        }
        if (rnd() < 0.08) {
          c.fillStyle = "#1b222c";
          c.fillRect(x + 6, y + 7, 1, 6);
          c.fillRect(x + 7, y + 12, 4, 1);
        }
      }
    for (let side of [8, 346]) {
      c.fillStyle = "#161e28";
      c.fillRect(side, 0, 7, this.H);
      c.fillStyle = "#687177";
      c.fillRect(side + 1, 0, 2, this.H);
      for (let y = 0; y < this.H; y += 12) {
        c.fillStyle = y % 24 ? "#404b54" : "#777e77";
        c.fillRect(side + 1, y + 1, 5, 5);
      }
    }
  }
  clear() {
    this.visual = 0;
    this.pending = [];
    this.particles = [];
    this.labels = [];
    this.born.clear();
    this.state = null;
    this.counted = -1;
  }
  update(s) {
    const old = this.state;
    this.state = s;
    if (!old || (!this.pending.length && !this.isCelebrating()))
      this.visual = s.blocks;
    if (old?.celebration && !s.celebration) {
      this.visual = s.blocks;
      this.pending = [];
      this.born.clear();
    }
    this.visual = clamp(this.visual, 0, s.goal);
  }
  isCelebrating() {
    return (
      !!this.state?.celebration &&
      this.state.celebration.until > this.state.serverTime
    );
  }
  get displayCount() {
    return this.isCelebrating()
      ? this.state?.goal || 100
      : Math.round(this.visual);
  }
  cell(index) {
    return {
      x: this.tx + (index % 5) * this.tile,
      y: this.floor - (Math.floor(index / 5) + 1) * this.tile,
    };
  }
  topPoint() {
    return this.cell(Math.max(0, Math.min(99, this.visual - 1)));
  }
  particle(x, y, color, kind = "dust", power = 1) {
    const max = this.quality === "low" ? 90 : 240;
    if (this.particles.length >= max) this.particles.shift();
    const a = Math.random() * Math.PI * 2,
      fast = kind === "confetti" ? 75 : 45;
    this.particles.push({
      x,
      y,
      vx: Math.cos(a) * fast * power,
      vy: -25 - Math.random() * fast * power,
      life: kind === "confetti" ? 2 : 0.6 + Math.random() * 0.5,
      age: 0,
      color,
      kind,
      size: 2 + Math.random() * 2,
    });
  }
  float(text, x, y, color) {
    if (this.labels.length >= 10) this.labels.shift();
    this.labels.push({ text, x, y, color, at: performance.now() / 1000 });
  }
  action(a) {
    const t = performance.now() / 1000;
    if (a.kind === "build") {
      const old = this.visual;
      if (this.pending.length)
        this.visual = clamp(this.visual + a.amount, 0, 100);
      else this.visual = a.after;
      for (let i = Math.min(old, this.visual); i < this.visual; i++)
        this.born.set(i, t + (i - old) * 0.008);
      const p = this.topPoint();
      this.float("+" + a.amount, p.x + this.tile * 2, p.y - 10, colors.green);
      this.hammerUntil = t + 0.6;
    }
    if (a.kind === "blast") {
      const wait =
        a.kindEffect === "lightning"
          ? 0.25
          : a.kindEffect === "airstrike"
            ? 1
            : 0.8;
      const wave = { ...a, at: t, impact: t + wait, end: t + wait + 0.45 };
      if (this.pending.length >= 24) {
        const last = this.pending.at(-1);
        last.damage += a.damage;
        last.amount += a.amount;
        last.absorbed += a.absorbed;
      } else this.pending.push(wave);
      this.shakeAt = t + 0.8;
    }
    if (a.kind === "likes") {
      const to = this.topPoint();
      for (let i = 0; i < Math.min(8, Math.ceil(a.count / 12)); i++) {
        this.particles.push({
          kind: "heart",
          from: { x: 290 + i * 2, y: this.floor + 18 },
          to: { x: to.x + this.tile / 2, y: to.y },
          age: -i * 0.04,
          life: 0.9,
          color: colors.green,
          x: 290,
          y: this.floor,
          size: 3,
        });
        if (this.particles.length > 240) this.particles.shift();
      }
    }
    if (a.kind === "shield") {
      const p = this.topPoint();
      this.float("ESCUDO +" + a.amount, p.x + 40, p.y - 15, colors.blue);
      for (let i = 0; i < 12; i++)
        this.particle(p.x + 30, p.y, colors.blue, "spark");
    }
    if (a.kind === "victory") {
      this.victoryAt = t;
      for (let i = 0; i < 90; i++)
        this.particle(
          this.tx + this.tile * 2.5,
          this.floor - this.tile * 18,
          [colors.gold, colors.green, colors.red, colors.blue][i % 4],
          "confetti",
          1.5,
        );
    }
    if (a.kind === "round") {
      this.visual = this.state?.blocks || 0;
      this.pending = [];
      this.born.clear();
    }
    if (a.kind === "reset" || a.kind === "boardReset") {
      const count = this.visual;
      this.visual = 0;
      this.pending = [];
      for (let i = 0; i < Math.min(50, count); i++) {
        const p = this.cell(Math.floor(Math.random() * Math.max(1, count)));
        this.particle(p.x, p.y, colors.red, "dust", 1.5);
      }
      this.shakeAt = t;
      this.float(
        "TORRE ZERADA",
        this.tx + this.tile * 2.5,
        this.floor - this.tile * 7,
        colors.red,
      );
    }
  }
  rect(x, y, w, h, c) {
    this.ctx.fillStyle = c;
    this.ctx.fillRect(
      Math.round(x),
      Math.round(y),
      Math.max(1, Math.ceil(w)),
      Math.max(1, Math.ceil(h)),
    );
  }
  text(s, x, y, size, c, align = "center") {
    const q = this.ctx;
    q.font = `${size}px VT, monospace`;
    q.textAlign = align;
    q.textBaseline = "middle";
    q.lineWidth = size <= 11 ? 1 : 2;
    q.strokeStyle = "#111922";
    q.strokeText(s, Math.round(x), Math.round(y));
    q.fillStyle = c;
    q.fillText(s, Math.round(x), Math.round(y));
  }
  block(i, x, y, size, at, t) {
    const q = this.ctx;
    let dy = 0;
    if (at && t < at + 0.22) dy = -Math.max(0, 1 - ease((t - at) / 0.22)) * 18;
    const row = Math.floor(i / 5),
      palette =
        row < 3
          ? ["#727c87", "#a0a9ad", "#454e5a"]
          : row < 12
            ? ["#ad6850", "#d49772", "#6b443c"]
            : row < 17
              ? ["#5e9c86", "#93c6a0", "#345e5e"]
              : ["#c89c45", "#f4d17a", "#806a38"];
    y += dy;
    this.rect(x, y, size - 1, size - 1, palette[0]);
    this.rect(x, y, size - 1, 1, palette[1]);
    this.rect(x, y, 1, size - 1, palette[1]);
    this.rect(x, y + size - 2, size - 1, 1, palette[2]);
    const yy = y + size * 0.5;
    this.rect(x + 1, yy, size - 3, 1, palette[2]);
    this.rect(
      x + size * (row % 2 ? 0.65 : 0.35),
      y + 1,
      1,
      size * 0.48,
      palette[2],
    );
    this.rect(x + size * (row % 2 ? 0.3 : 0.7), yy, 1, size * 0.4, palette[2]);
    if (size > 9) {
      this.rect(x + 3, y + 3, 2, 1, palette[1]);
      this.rect(x + size - 5, y + size - 4, 2, 1, palette[2]);
    }
  }
  tnt(x, y, t, scale = 1) {
    const q = this.ctx;
    q.save();
    q.translate(x, y);
    q.rotate(Math.sin(t * 4) * 0.25);
    q.scale(scale, scale);
    this.rect(-6, -7, 12, 14, "#9b302f");
    this.rect(-5, -6, 10, 12, "#e45949");
    this.rect(-5, -1, 10, 5, "#f4e6c1");
    this.rect(-6, 6, 12, 2, "#712b32");
    this.rect(-3, -6, 1, 4, "#ff8a64");
    this.text("TNT", 0, 1.7, 6, "#20232a");
    this.rect(0, -10, 2, 4, "#bd9b65");
    this.rect(0, -12, 2, 2, "#ffe195");
    this.rect(Math.sin(t * 17) > 0 ? 2 : -2, -14, 2, 2, "#ff8f53");
    q.restore();
  }
  miner(
    x,
    y,
    t,
    working = false,
    celebrate = false,
    color = "#e7bd55",
    small = false,
  ) {
    const q = this.ctx,
      u = small ? 0.8 : this.tile / 8;
    q.save();
    q.translate(x, y + (celebrate ? -Math.abs(Math.sin(t * 10)) * 6 : 0));
    q.scale(u, u);
    const walk = Math.sin(t * 7) * 0.4;
    this.rect(-4, -8, 3, 8, "#304b6a");
    this.rect(1, -8, 3, 8, "#304b6a");
    this.rect(-5, -1, 5, 2, "#111e2e");
    this.rect(1, -1, 5, 2, "#111e2e");
    this.rect(-5, -17, 10, 10, "#416e8c");
    this.rect(-4, -16, 8, 3, "#85a8a2");
    this.rect(-2, -17, 4, 7, "#426184");
    this.rect(-4, -26, 8, 9, "#d49b71");
    this.rect(-5, -29, 10, 5, color);
    this.rect(-6, -26, 12, 2, color);
    this.rect(-1, -28, 2, 2, "#fff0b9");
    this.rect(1, -22, 1, 2, "#172732");
    this.rect(3, -22, 1, 2, "#172732");
    this.rect(1, -18, 3, 1, "#704d43");
    this.rect(-7, -16, 3, 7, "#d49b71");
    q.save();
    q.translate(6, -15);
    q.rotate(celebrate ? -2.1 : working ? Math.sin(t * 16) * 1.1 - 0.9 : -0.25);
    this.rect(0, 0, 3, 7, "#d49b71");
    this.rect(1, -7, 2, 10, "#805c43");
    this.rect(-2, -8, 9, 3, "#a9b7ba");
    this.rect(-2, -9, 9, 1, "#e6e6c9");
    q.restore();
    q.restore();
  }
  heart(x, y, size, color) {
    const q = this.ctx;
    q.save();
    q.translate(Math.round(x), Math.round(y));
    q.scale(size, size);
    this.rect(-2, -1, 2, 1, color);
    this.rect(1, -1, 2, 1, color);
    this.rect(-3, 0, 7, 2, color);
    this.rect(-2, 2, 5, 1, color);
    this.rect(-1, 3, 3, 1, color);
    this.rect(0, 4, 1, 1, color);
    q.restore();
  }
  loop(ms) {
    requestAnimationFrame((t) => this.loop(t));
    if (ms - this.lastFrame < (this.quality === "low" ? 32 : 15)) return;
    const t = ms / 1000,
      dt = clamp(t - this.lastTime, 0, 0.06);
    this.lastTime = t;
    this.lastFrame = ms;
    this.frames++;
    if (ms - this.fpsAt > 1500) {
      this.fps = Math.round((this.frames * 1000) / (ms - this.fpsAt));
      this.frames = 0;
      this.fpsAt = ms;
    }
    this.render(t, dt);
    if (ms - this.lastCountAt > 80) {
      this.onCount(this.displayCount);
      this.lastCountAt = ms;
    }
  }
  render(t, dt) {
    const c = this.ctx;
    c.setTransform(this.scale, 0, 0, this.scale, 0, 0);
    c.imageSmoothingEnabled = false;
    c.clearRect(0, 0, this.W, this.H);
    c.drawImage(this.bg, 0, 0);
    c.save();
    if (!this.reduceMotion && t - this.shakeAt < 0.24 && t >= this.shakeAt)
      c.translate(Math.sin(t * 80) * 2, Math.cos(t * 70));
    // Original pixel mine, ledges and target guide.
    for (const x of [23, 334])
      for (const y of [this.top + 45, this.floor - 130]) {
        const flame = Math.sin(t * 11 + y) > 0;
        this.rect(x, y, 3, 13, "#71513c");
        this.rect(x - 2, y - 6, 7, 7, "#a64f31");
        this.rect(x - 1, y - 8, 5, 7, "#e58a41");
        this.rect(x, flame ? y - 10 : y - 8, 3, 6, "#f9d479");
        c.globalAlpha = 0.07;
        c.fillStyle = "#ffc171";
        c.beginPath();
        c.arc(x + 2, y, 28, 0, Math.PI * 2);
        c.fill();
        c.globalAlpha = 1;
      }
    this.rect(22, this.floor + 2, 316, 9, "#1a222b");
    this.rect(22, this.floor + 2, 316, 2, "#8d9584");
    for (let x = 22; x < 338; x += 17) {
      this.rect(x, this.floor + 6, 14, 1, "#4b585e");
      this.rect(x + 12, this.floor + 2, 1, 8, "#111a24");
    }
    const goalY = this.floor - this.tile * 20;
    this.rect(this.tx - 9, goalY - 10, 2, this.tile * 20 + 10, "#7d8b81");
    for (let y = goalY + 3; y < this.floor; y += 9)
      this.rect(this.tx - 8, y, 2, 3, "#293640");
    this.rect(this.tx - 7, goalY - 10, 22, 10, "#c0e58b");
    this.text("100", this.tx + 4, goalY - 5, 9, "#243927");
    c.globalAlpha = 0.13;
    for (let row = 0; row < 20; row++) {
      this.rect(
        this.tx - 1,
        this.floor - (row + 1) * this.tile,
        this.tile * 5 + 1,
        1,
        "#c2d2c0",
      );
    }
    this.rect(this.tx - 1, goalY, 1, this.tile * 20, "#c2d2c0");
    this.rect(this.tx + this.tile * 5, goalY, 1, this.tile * 20, "#c2d2c0");
    c.globalAlpha = 1;
    const shown = clamp(this.displayCount, 0, 100);
    for (let i = 0; i < shown; i++) {
      const p = this.cell(i);
      this.block(i, p.x, p.y, this.tile, this.born.get(i), t);
    }
    const top = this.cell(Math.max(0, shown - 1)),
      builderX = this.tx + this.tile * 5 + 15,
      targetY = shown
        ? this.floor - Math.floor((shown - 1) / 5) * this.tile
        : this.floor;
    this.builderY =
      this.builderY === undefined
        ? targetY
        : this.builderY + (targetY - this.builderY) * Math.min(1, dt * 6);
    this.rect(builderX - 10, this.builderY + 2, 20, 3, "#d3ab56");
    this.rect(builderX - 7, this.builderY + 5, 14, 2, "#4f575b");
    this.miner(
      builderX,
      this.builderY,
      t,
      this.hammerUntil > t,
      this.isCelebrating(),
    );
    if (this.state?.shield > 0) {
      c.strokeStyle = "#82d7ec";
      c.globalAlpha = this.reduceMotion ? 0.7 : 0.4 + Math.sin(t * 3) * 0.1;
      c.lineWidth = 1;
      c.strokeRect(
        this.tx - 4,
        top.y - 5,
        this.tile * 5 + 8,
        this.floor - top.y + 8,
      );
      c.globalAlpha = 1;
    }
    // Pending explosions preserve the visual order; the server has already recorded the effect.
    for (const wave of this.pending) {
      const age = t - wave.at,
        duration = wave.impact - wave.at,
        point = this.cell(Math.max(0, Math.min(99, wave.before - 1))),
        target = { x: point.x + this.tile * 2, y: point.y + this.tile / 2 };
      if (t < wave.impact) {
        if (wave.kindEffect === "lightning") {
          c.strokeStyle = "#c1efff";
          c.lineWidth = 2;
          c.beginPath();
          c.moveTo(target.x, this.top);
          for (let i = 1; i <= 6; i++)
            c.lineTo(
              target.x + (i % 2 ? -7 : 7),
              this.top + ((target.y - this.top) * i) / 6,
            );
          c.stroke();
        } else {
          const n =
            wave.kindEffect === "airstrike"
              ? 6
              : Math.min(7, Math.ceil(Math.log2(wave.amount + 1)) + 1);
          for (let i = 0; i < n; i++) {
            const p = clamp(age / duration - i * 0.025, 0, 1),
              sx = wave.kindEffect === "airstrike" ? -15 + i * 55 : 70 + i * 32,
              xx = sx + (target.x + (i - (n - 1) / 2) * 5 - sx) * ease(p),
              yy = this.top - 20 + (target.y - this.top + 20) * p * p;
            this.tnt(xx, yy, t + i, 0.8 + (i % 2) * 0.15);
          }
          this.text(
            "×" + wave.amount,
            this.tx + this.tile * 2.5,
            this.top + 20,
            19,
            colors.red,
          );
        }
      } else if (!wave.done) {
        wave.done = true;
        const before = this.visual;
        this.visual = clamp(this.visual - wave.damage, 0, 100);
        for (let i = 0; i < Math.min(60, Math.max(8, wave.damage * 2)); i++) {
          const p = this.cell(
            Math.max(0, Math.min(99, before - 1 - Math.floor(i / 2))),
          );
          this.particle(
            p.x + this.tile / 2,
            p.y,
            wave.damage
              ? [colors.red, colors.gold, "#c28d69"][i % 3]
              : colors.blue,
            "dust",
            1.5,
          );
        }
        this.float(
          wave.damage ? "−" + wave.damage : "DEFENDIDO!",
          target.x,
          target.y - 16,
          wave.damage ? colors.red : colors.blue,
        );
        this.shakeAt = t;
        this.onImpact(
          wave.kindEffect === "lightning"
            ? "lightning"
            : wave.damage
              ? "explosion"
              : "shield",
          wave.amount,
        );
      }
    }
    this.pending = this.pending.filter((w) => t < w.end);
    if (!this.pending.length && this.state && !this.isCelebrating())
      this.visual = this.state.blocks;
    for (const p of this.particles) {
      p.age += dt;
      if (p.age < 0) continue;
      const life = p.age / p.life;
      if (p.kind === "heart") {
        const u = ease(life),
          x = p.from.x + (p.to.x - p.from.x) * u,
          y = p.from.y + (p.to.y - p.from.y) * u - Math.sin(u * Math.PI) * 30;
        c.globalAlpha = 1 - life * 0.6;
        this.heart(x, y, 1.2, p.color);
      } else {
        p.vy += dt * (p.kind === "confetti" ? 45 : 100);
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        c.globalAlpha = 1 - life;
        this.rect(
          p.x,
          p.y,
          p.size,
          p.kind === "confetti" ? p.size * 0.5 : p.size,
          p.color,
        );
      }
      c.globalAlpha = 1;
    }
    this.particles = this.particles.filter((p) => p.age < p.life);
    this.labels = this.labels.filter((l) => t - l.at < 1.2);
    for (const l of this.labels) {
      const age = t - l.at;
      c.globalAlpha = 1 - age / 1.2;
      this.text(l.text, l.x, l.y - age * 20, 16, l.color);
      c.globalAlpha = 1;
    }
    for (const [i, p] of (this.state?.players || []).slice(0, 4).entries()) {
      const x = 36 + i * 24;
      this.miner(
        x,
        this.floor + 24,
        t,
        false,
        false,
        ["#9dd17a", "#c39bde", "#d99c6c", "#8fcbd4"][i],
        true,
      );
      this.text(p.name.slice(0, 7), x, this.floor + 31, 7, "#d0dcd6");
    }
    if (!shown && !this.isCelebrating()) {
      this.text(
        "A BASE ESTÁ PRONTA",
        this.tx + this.tile * 2.5,
        this.floor - this.tile * 5,
        13,
        "#b5c5ba",
      );
      this.text(
        "TAP TAP PARA CONSTRUIR",
        this.tx + this.tile * 2.5,
        this.floor - this.tile * 4,
        10,
        "#9eb77f",
      );
    }
    c.restore();
  }
  metrics() {
    return {
      fps: this.fps,
      visualBlocks: this.displayCount,
      pending: this.pending.length,
      particles: this.particles.length,
      profile: this.quality,
      canvasWidth: this.canvas.width,
      canvasHeight: this.canvas.height,
      towerBounds: {
        left: this.tx,
        right: this.tx + this.tile * 5,
        top: this.floor - this.tile * 20,
        bottom: this.floor,
      },
      worldTop: this.top,
      worldHeight: this.H,
    };
  }
}
