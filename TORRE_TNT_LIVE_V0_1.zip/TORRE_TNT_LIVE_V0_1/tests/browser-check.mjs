// Optional development check: install playwright-core and Chromium first.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const { chromium } = await import(
  process.env.PLAYWRIGHT_MODULE || "playwright-core"
);
const data = await mkdtemp(path.join(tmpdir(), "torre-browser-"));
const port = Number(process.env.TEST_PORT || 34731),
  base = "http://127.0.0.1:" + port;
const child = spawn(process.execPath, ["server/index.mjs"], {
  cwd: root,
  env: { ...process.env, PORT: String(port), TORRE_DATA_DIR: data },
  stdio: ["ignore", "pipe", "pipe"],
});
let browser,
  log = "";
child.stderr.on("data", (d) => (log += d));
child.stdout.on("data", (d) => (log += d));
const delay = (ms) => new Promise((r) => setTimeout(r, ms));
const post = async (p, d = {}) => {
  const r = await fetch(base + "/api/" + p, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(d),
  });
  assert(r.ok, await r.clone().text());
  return r.json();
};
const event = (d) =>
  post("demo/event", {
    id: crypto.randomUUID(),
    user: "teste_lua",
    name: "Lua",
    ...d,
  });
const state = () => fetch(base + "/api/state").then((r) => r.json());
try {
  for (let i = 0; i < 100; i++) {
    try {
      await state();
      break;
    } catch {
      if (child.exitCode !== null) throw Error(log);
      await delay(50);
    }
  }
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({
    viewport: { width: 450, height: 960 },
    deviceScaleFactor: 1,
  });
  const errors = [],
    failed = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("response", (r) => {
    if (r.status() >= 400) failed.push({ url: r.url(), status: r.status() });
  });
  await page.goto(base);
  await page.waitForFunction(() => window.TORRE?.state);
  await page.locator("#demo-start").click();
  await delay(300);
  await post("demo/stop");
  const sound = await page.evaluate(() => ({
    context: TORRE.audio.context?.state || TORRE.audio.ctx?.state,
    musicPaused: document.getElementById("music").paused,
    musicReady: document.getElementById("music").readyState,
  }));
  assert.equal(sound.context, "running");
  assert.equal(sound.musicPaused, false);
  assert(sound.musicReady >= 2);
  sound.effectRms = await page.evaluate(async () => {
    const a = TORRE.audio,
      analyser = a.ctx.createAnalyser();
    a.master.connect(analyser);
    a.sfx("explosion");
    await new Promise((r) => setTimeout(r, 110));
    const samples = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(samples);
    analyser.disconnect();
    a.master.disconnect(analyser);
    return Math.sqrt(samples.reduce((s, x) => s + x * x, 0) / samples.length);
  });
  assert(
    sound.effectRms > 0.0001,
    "Explosion audio must contain audible samples",
  );
  await post("demo/reset");
  await event({ type: "like", count: 1200 });
  await delay(600);
  assert.equal((await state()).blocks, 60);
  await page.locator("#gift-pause").click();
  const decoded = await page
    .locator("#gift-cards img")
    .evaluateAll((imgs) => imgs.every((i) => i.complete && i.naturalWidth > 0));
  assert(decoded);
  await mkdir(path.join(root, "docs/previas"), { recursive: true });
  await page.screenshot({ path: path.join(root, "docs/previas/JOGO.png") });
  await event({ type: "gift", gift: "Rosa", count: 1, repeatEnd: true });
  await delay(500);
  assert.equal((await state()).blocks, 50);
  assert.equal(await page.locator("#gift-alert-name").textContent(), "Rosa");
  await page.screenshot({ path: path.join(root, "docs/previas/TNT.png") });
  await delay(1100);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 50);
  await event({ type: "comment", text: "DEFESA" });
  await event({ type: "gift", gift: "Rosa", count: 1, repeatEnd: true });
  await delay(1600);
  assert.equal((await state()).blocks, 43);
  await event({ type: "gift", gift: "GG", count: 1, repeatEnd: true });
  await delay(500);
  assert.equal((await state()).wins, 1);
  assert.equal((await state()).blocks, 23);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 100);
  assert(await page.locator("#win-banner").isVisible());
  await page.screenshot({ path: path.join(root, "docs/previas/VITORIA.png") });
  await delay(3300);
  assert.equal(await page.evaluate(() => TORRE.world.displayCount), 23);
  const layouts = [];
  for (const size of [
    { width: 360, height: 800 },
    { width: 450, height: 960 },
    { width: 916, height: 2040 },
    { width: 1280, height: 720 },
  ]) {
    await page.setViewportSize(size);
    await delay(1700);
    const m = await page.evaluate(() => ({
      ...TORRE.world.metrics(),
      hud: document.getElementById("hud").getBoundingClientRect().toJSON(),
      footer: document.querySelector("footer").getBoundingClientRect().toJSON(),
      scroll: document.body.scrollWidth,
      screen: innerWidth,
    }));
    assert(m.towerBounds.top > m.worldTop);
    assert(m.towerBounds.bottom < m.worldHeight);
    assert(m.hud.bottom < m.footer.top);
    assert(m.scroll <= m.screen);
    assert.equal(m.pending, 0);
    assert(
      m.towerBounds.bottom + 32 < (m.footer.top / size.width) * 360,
      "Footer must not cover tower or helpers",
    );
    layouts.push({ viewport: size, ...m });
  }
  // LIVE cannot accept fake taps or demo gifts. A separate LIVE board starts empty.
  await post("mode", { mode: "live" });
  await delay(400);
  const before = (await state()).totals.likes;
  await page.locator("#game").click({ position: { x: 820, y: 440 } });
  await delay(300);
  assert.equal((await state()).totals.likes, before);
  assert(await page.locator("#quick-gift").isDisabled());
  await page.locator("#demo-start").click();
  assert(await page.locator("#drawer").isVisible());
  assert.deepEqual(errors, []);
  assert.deepEqual(failed, []);
  const report = {
    checkedAt: new Date().toISOString(),
    browser: browser.version(),
    checks: [
      "AudioContext running after first click",
      "Original WAV playing",
      "Gift photos decoded",
      "1200 likes build 60 blocks",
      "Rose removes 10 blocks with delayed visual impact",
      "Shield absorbs 3 before damage",
      "GG awards victory and preserves 23 overflow blocks",
      "Celebration ends on next board",
      "Four viewport layouts fit",
      "Local demo taps rejected in LIVE",
    ],
    sound,
    layouts,
    pageErrors: errors,
    failedResponses: failed,
    realTikTokLiveTested: false,
    physicalAndroidTested: false,
  };
  await mkdir(path.join(root, "output"), { recursive: true });
  await writeFile(
    path.join(root, "output/BROWSER.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  await browser?.close();
  child.kill("SIGTERM");
  await new Promise((r) => {
    if (child.exitCode !== null) return r();
    child.once("exit", r);
    setTimeout(() => {
      child.kill("SIGKILL");
      r();
    }, 4000).unref();
  });
  await rm(data, { recursive: true, force: true });
}
