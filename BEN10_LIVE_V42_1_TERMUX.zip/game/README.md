# Ben 10 · Clareira LIVE · V42.1

**Correção V42.1:** o instalador verifica quais ferramentas faltam e usa somente o repositório principal oficial (`termux.net` ou `termux-main`) em uma configuração APT temporária, sem consultar nem editar repositórios extras. Mantém a verificação de assinaturas e evita o erro `NO_PUBKEY` do repositório glibc. O aviso de `.env` ausente também foi retirado quando o arquivo não é necessário. [Reparo pequeno para V42 já instalada](docs/V42_1_REPARO_TERMUX.md).

A V42 conecta o jogo a **conversa e voz neural locais no Termux**, sem chave de API depois de instalar os modelos. O perfil inicial é para o Realme GT3 ARM64 com 16 GB: Qwen3-4B-Instruct-2507 em GGUF Q4_K_M, llama.cpp e Piper pt-BR. Ben mantém a personalidade do clássico; a voz recebe somente a frase, sem descrições de interpretação.

A conversa local pode ter qualidade/velocidade inferiores ao Gemini. O Piper é uma voz neural em português, não a dublagem do desenho. Não houve medição em GT3 físico nem inferência com os pesos reais nesta validação. O TikTok continua precisando de internet.

## Instalar e executar

Na instalação existente, depois de baixar o ZIP:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V42_1_TERMUX.zip
bash local-ai.sh install && bash local-ai.sh start
```

Ajuste o caminho se usar outra pasta. Não use `--start` no atualizador nesse primeiro passo: quem inicia o jogo com os modelos é `local-ai.sh start`.

A instalação inicial baixa vários GB, compila o llama.cpp e prepara uma instalação Debian própria para o Piper. Reserve pelo menos 8 GB livres e mantenha a internet até terminar. Os pesos ficam em `~/.local/share/ben10-local-ai`, fora do ZIP e do backup do jogo.

Instalação nova: extraia o ZIP, entre em `game` e execute `bash install.sh` antes dos dois comandos `local-ai.sh`.

Nas próximas vezes, rode somente `bash local-ai.sh start`. Ele inicia conversa, voz e jogo, espera os serviços ficarem prontos e seleciona os provedores locais. Mantenha a sessão aberta e toque em **♫** no Chrome. Confira **V42.1 / 42.1.0**. Diagnóstico: `bash local-ai.sh status` ou **LIVE → IA e voz → Verificar serviços locais**.

Se precisar reduzir o consumo, pare a sessão com Ctrl+C e instale o perfil leve:

```sh
bash local-ai.sh install --model light
bash local-ai.sh start
```

[Guia completo e limites da validação](docs/V42_IA_LOCAL_TERMUX.md).

## O que permanece

Avatares com nome/foto, recepção e câmera, cumprimento de seguidores, prioridade de presentes, memória recente por pessoa, energia 3D entrando no relógio, desbloqueios por curtidas, metas coletivas, dia/tarde/noite, poderes, ícones, ranking e Omnitrix original. Sem tarefas de cidade.

Gemini e ElevenLabs continuam opcionais no painel; uma falha local não chama um provedor online nem a voz do aparelho. O público mantém a legenda quando a voz não está disponível. Chaves e progresso anteriores são preservados pelo atualizador.

## Desenvolvimento

Node >=22.19, npm, Python 3. Assets Babylon e licenças locais, sem CDN.

- `npm ci`, `npm test`, `npm run lint`, `npm run build`.
- `node scripts/v42-local-check.js`: navegador real com serviços locais simulados, sem chaves ou dados pessoais.
- `npm run package`: testes, build e ZIP sem `data/`, `.env`, dependências ou pesos GGUF/ONNX.
- `node scripts/archive-smoke.js ../BEN10_LIVE_V42_1_TERMUX.zip`: extrai e inicia o pacote usando dependências do mesmo lockfile.

Relatórios em `reports/v42_1/`. As fixtures verificam contratos, estados e reprodução de WAV sintético; não medem qualidade da IA/voz ou desempenho do telefone. O acesso aos repositórios de pesos é verificado pelo instalador no aparelho; os pesos não foram baixados nesta validação cloud.

Código do projeto AGPL-3.0. [Créditos dos modelos 3D](docs/MODEL_CREDITS.md), `third_party/NOTICE.md`. Componentes locais: llama.cpp MIT, Piper GPL-3.0 e Qwen com licença Apache-2.0. O instalador baixa também os cartões/licenças do modelo e da voz; consulte `voices/MODEL_CARD`. Não há gravações oficiais de voz. Guias de versões anteriores são históricos.
