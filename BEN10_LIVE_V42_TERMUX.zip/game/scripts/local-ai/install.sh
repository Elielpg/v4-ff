#!/usr/bin/env bash
set -euo pipefail
task_game_root="$(cd -- "$(dirname -- "$0")/../.." && pwd)"
task_local_root="${BEN10_LOCAL_ROOT:-$HOME/.local/share/ben10-local-ai}"
task_model=gt3
while (($#)); do
  case "$1" in
    --model) task_model="${2:-}"; shift 2 ;;
    --help|-h) printf 'bash local-ai.sh install [--model gt3|light]\n'; exit 0 ;;
    *) printf 'Argumento inválido: %s\n' "$1" >&2; exit 1 ;;
  esac
done
[[ "$task_model" == gt3 || "$task_model" == light ]] || { printf 'Modelo: gt3 ou light\n' >&2; exit 1; }
command -v pkg >/dev/null && [[ "$(uname -m)" == aarch64 ]] || { printf 'Este instalador é para Termux Android ARM64. O painel pode usar serviços locais já instalados em outros sistemas.\n' >&2; exit 1; }
command -v node >/dev/null || { printf 'Execute bash install.sh do jogo primeiro.\n' >&2; exit 1; }
umask 077
mkdir -p "$task_local_root/logs"
printf 'IA local: instalação inicial usa internet e vários GB. Perfil: %s.\n' "$task_model"
pkg install -y git cmake ninja clang python curl libandroid-spawn proot-distro
python3 "$task_game_root/scripts/local-ai/download_models.py" --root "$task_local_root" --model "$task_model"
task_llama_revision=6c01da6278ab6c69ed67d9124806b50d2b299ba7
if [[ ! -d "$task_local_root/llama.cpp/.git" ]]; then
  git init "$task_local_root/llama.cpp"
  git -C "$task_local_root/llama.cpp" remote add origin https://github.com/ggml-org/llama.cpp.git
fi
if ! git -C "$task_local_root/llama.cpp" cat-file -e "$task_llama_revision^{commit}" 2>/dev/null; then
  git -C "$task_local_root/llama.cpp" fetch --depth 1 origin "$task_llama_revision"
fi
git -C "$task_local_root/llama.cpp" checkout --detach "$task_llama_revision"
cmake -S "$task_local_root/llama.cpp" -B "$task_local_root/llama.cpp/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DGGML_OPENMP=OFF -DGGML_LLAMAFILE=OFF -DLLAMA_OPENSSL=OFF -DLLAMA_BUILD_TESTS=OFF
cmake --build "$task_local_root/llama.cpp/build" --target llama-server --parallel 4
if ! proot-distro login ben10-ai -- /bin/true >/dev/null 2>&1; then
  task_proot_help="$(proot-distro install --help 2>&1)"
  if [[ "$task_proot_help" == *'--name'* ]]; then
    proot-distro install debian:bookworm --name ben10-ai
  else
    proot-distro install --override-alias ben10-ai debian
  fi
fi
proot-distro login --bind "$task_game_root/scripts/local-ai:/opt/ben10-worker" ben10-ai -- /bin/bash -lc 'set -e; export DEBIAN_FRONTEND=noninteractive; apt-get update; apt-get install -y python3 python3-venv ca-certificates libgomp1; python3 -m venv /opt/ben10-voice; /opt/ben10-voice/bin/pip install --disable-pip-version-check -r /opt/ben10-worker/requirements.txt; /opt/ben10-voice/bin/python -c "from piper import PiperVoice; import onnxruntime; print(\"Bibliotecas de voz prontas\")"'
printf '\nInstalação concluída. Inicie com: bash local-ai.sh start\n'
