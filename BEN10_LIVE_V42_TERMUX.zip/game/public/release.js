export const BUILD_ID='42.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 42.0.0';
