# Ben 10 · Clareira LIVE · V43.3

Reparo da entrega da voz clonada ao jogo. O teste WAV já foi ouvido como fala compreensível no GT3; não é necessário baixar ou converter modelos novamente.

- O botão de entrada ativa o contexto de áudio; as respostas usam WebAudio e não dependem de iniciar um novo elemento de mídia depois da geração longa.
- IA e voz → Ouvir teste salvo do clone reproduz o preview existente, sem sintetizar outra frase. É um teste salvo, não uma resposta ao chat.
- O jogo avisa quando os serviços locais estão parados. `bash start.sh` inicia também a IA se conversa e voz estiverem ambas configuradas como locais.
- `logs/inicializacao.log` registra saídas e sinais dos serviços para diferenciar encerramento manual de falhas.

## Atualizar uma instalação V43.1/V43.2

Pare a sessão anterior com Ctrl+C. Na pasta `~/ben10-v34/game`, extraia BEN10_REPARO_AUDIO_V43_3.zip e execute REPARAR_AUDIO_V43_3.sh. Depois execute `bash local-ai.sh start`. Mantenha a sessão aberta; comandos de diagnóstico devem rodar em outra sessão do Termux.

Abra http://127.0.0.1:3000/?v=43.3.0, toque em Entrar ou ♫ e teste o áudio salvo em LIVE → IA e voz. Ajuste o volume de voz se estiver zerado.

## Velocidade da clonagem

O log fornecido pelo usuário mediu 69,5 segundos para produzir 5,1 segundos de áudio. O reparo de reprodução não torna a inferência instantânea.

Uma reconstrução opcional, com os serviços parados, usa FP16 e dotprod apenas se o carregador do Android confirmar suporte: `bash local-ai.sh clone repair-native`. Não usa SVE, SME, i8mm, `-mcpu=native` ou `-march=native`. Preserva GGUF e referência; precisa medir novamente no celular. Para forçar o perfil básico: `BEN10_CLONE_BASELINE=1 bash local-ai.sh clone repair-native`.

Testes de navegador usam WAV de tom e serviços simulados, com autoplay restrito. Eles verificam reprodução, fila e diagnóstico; não medem timbre nem desempenho real do Android.
