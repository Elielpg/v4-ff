# Roteiro — convite com o visual 2D

26 segundos, vertical, sem identificador de perfil.

- 0–3 s: Quem manda no Omnitrix? Você! Três aliens e transformação.
- 3–10 s: Chama, corrida do XLR8 e defesa/ataque do Diamante.
- 10–14 s: exemplo de pergunta no chat; Ben alterna boca e gestos.
- 14–18 s: TAP TAP e energia indo ao relógio.
- 18–21 s: presentes e efeitos no cenário.
- 21–26 s: escolha entre três aliens e convite para seguir e vir à live.

A apresentação reaproveita o áudio claro da produção anterior com capturas totalmente novas do jogo V45 e os quatro personagens em 2D.
