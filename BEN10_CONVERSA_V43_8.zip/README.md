# Ben 10 · Clareira LIVE · V43.8

Esta é uma atualização de código para quem já usa a V43.7. Prioriza demora e precisão das respostas. Não baixa modelos nem modifica a voz selecionada.

## Instalar

Baixe BEN10_CONVERSA_V43_8.zip para Downloads. Na pasta do jogo:

```bash
cd ~/ben10-v34/game &&
python3 -m zipfile -e ~/storage/downloads/BEN10_CONVERSA_V43_8.zip "$TMPDIR/ben10-conversa-43-8" &&
bash "$TMPDIR/ben10-conversa-43-8/ATUALIZAR_CONVERSA_V43_8.sh" &&
bash local-ai.sh start
```

Abra http://127.0.0.1:3000/?v=43.8.0 e toque em ♫. Mantenha o Termux aberto e conecte sua LIVE no painel. Nas próximas vezes: `cd ~/ben10-v34/game && bash local-ai.sh start`. Para parar: `bash local-ai.sh stop`.

## Respostas e espera

Contas simples, algumas perguntas verificadas sobre o clássico e o próximo desbloqueio recebem resposta direta, identificada como RESPOSTA DIRETA. Perguntas compostas ou não previstas continuam no modelo Qwen3 de 4B já instalado. O teste de IA continua consultando o modelo real; uma resposta direta não confirma que o modelo está online.

O início prepara o contexto uma vez antes de abrir o jogo. O prefixo fica estável para o cache de contexto. Perguntas independentes dispensam histórico sem relação; perguntas de seguimento mantêm até duas interações da mesma pessoa. Respostas gerais iguais podem ser reaproveitadas por até dois minutos. Perguntas pessoais, de seguimento e de estado/tempo ficam fora desse cache.

O modelo recebe menos instruções e devolve até duas frases curtas. A aplicação remove nomes repetidos e evita referências do desenho sem relação com a pergunta. Nas contas calculadas, o resultado fica em algarismos na legenda e segue por extenso para a voz. Não altera a pronúncia do modelo de voz nem promete um timbre diferente.

Avisos automáticos de chegada, TAP TAP, comandos e falas de ambiente que aguardam mais de 20 segundos saem da fila. Perguntas, presentes e agradecimentos por seguir são preservados. Presentes continuam com prioridade, sem cortar a fala em reprodução. O preparo da próxima resposta/voz continua funcionando.

LIVE → IA e voz → copiar diagnóstico inclui tempos separados da fila, resposta, entrega da voz, síntese e reprodução. Isso ajuda a localizar a espera restante.

## Limites da validação

No teste com o modelo real Qwen3-4B-Instruct-2507 Q4_K_M em CPU Linux, sem renderizar o cenário, contas e uma pergunta verificada levaram de 0 a 33 ms; perguntas gerais levaram aproximadamente 7 a 14 s. O contexto inicial levou cerca de 7 s para preparar. O modelo explicou fotossíntese, respondeu Tóquio e admitiu não saber o aniversário da pessoa, sem repetir seu nome. Não são resultados do Realme GT3 nem incluem geração da voz.

A voz atual é preservada. A etapa experimental de um novo clonador foi bloqueada por um filtro de conteúdo e não está incluída nesta atualização. Uma voz de IA original e mais clara permanece uma alternativa; nenhuma voz foi trocada automaticamente. Não é usada voz do aparelho.

## Dados preservados

O instalador confere a integridade e a sintaxe dos arquivos e guarda backup em `data/installer-backups`. Mantém .env, chaves, configurações, progresso, modelos, referência e seleção da voz. Não consulta APT nem baixa dependências. É específico para V43.7/V43.8; não substitui o pacote completo.
