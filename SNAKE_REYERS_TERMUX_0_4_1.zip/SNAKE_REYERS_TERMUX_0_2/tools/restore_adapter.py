"""Restore own adapter files from this repair's backup; never alter game data."""
from pathlib import Path
import json
import shutil
import socket
import sys
import os


def main():
    backup=Path(__file__).resolve().parent
    with socket.socket() as sock:
        sock.settimeout(.5)
        if sock.connect_ex(('127.0.0.1',9393))==0:
            sys.exit('Encerre o jogo com Ctrl+C antes de reverter.')
    manifest=json.loads((backup/'restore-manifest.json').read_text())
    root=Path(manifest['root'])
    # Validate the entire plan before touching any file.
    plan=[]
    for relative,existed in manifest['files'].items():
        path=Path(relative)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Caminho inválido no backup')
        if existed and not (backup/path).is_file():
            raise ValueError('Arquivo ausente no backup: '+relative)
        plan.append((path,existed))
    external=[]
    for item in manifest.get('external_settings',[]):
        path=Path(item['path']);keys=item['keys']
        if not path.is_absolute() or set(keys)-{'termux_live_policy','termux_welcome_enabled','termux_reply_mode'}:
            raise ValueError('Preferências externas inválidas no backup')
        raw=json.loads(path.read_text()) if path.exists() else {}
        if not isinstance(raw,dict):raise ValueError('Configuração privada inválida')
        for key,before in keys.items():
            if before['present']:raw[key]=before['value']
            else:raw.pop(key,None)
        external.append((path,raw))
    for path,existed in plan:
        target=root/path
        if existed:
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(backup/path,target)
        else:
            target.unlink(missing_ok=True)
    for path,raw in external:
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_name(path.name+'.restore-tmp')
        with open(temporary,'w',opener=lambda name,flags:os.open(name,flags,0o600)) as file:
            json.dump(raw,file,ensure_ascii=False,indent=2)
        temporary.replace(path)
    print('Arquivos anteriores restaurados. Configurações e dados preservados.')


if __name__=='__main__':
    main()
