"""Standalone synthetic render regression; needs a working X11/display and Godot.

Does not load the original game, connect TikTok, or read API/streaming keys.
"""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--godot',default=shutil.which('godot'))
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--renderer',choices=('gl_compatibility','mobile'),default='gl_compatibility')
    args=parser.parse_args()
    if not args.godot:parser.error('Informe --godot ou instale o motor nativo já usado pelo jogo.')
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    (out/'result.json').unlink(missing_ok=True)
    project=out/'project';project.mkdir(exist_ok=True)
    (project/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Render regression"\n[display]\nwindow/size/viewport_width=640\nwindow/size/viewport_height=480\n')
    source=Path(__file__).resolve().parents[1]/'tests/godot/render_pipeline_test.gd'
    command=[args.godot,'--path',str(project),'--script',str(source),'--rendering-method',args.renderer,
             '--audio-driver','Dummy','--max-fps','60']
    if args.renderer=='mobile':command+=['--rendering-driver','vulkan','--render-thread','safe']
    env={**os.environ,'SNAKE_RENDER_TEST_OUTPUT':str(out)}
    with (out/'run.log').open('w') as file:result=subprocess.run(command,env=env,stdout=file,stderr=subprocess.STDOUT,timeout=90)
    text=(out/'run.log').read_text()
    if result.returncode or 'SCRIPT ERROR' in text or '\nERROR:' in text:
        raise SystemExit(text[-3000:])
    report=json.loads((out/'result.json').read_text())
    assert report['filter']['no_overshoot'] and report['camera']['logical_camera_preserved']
    assert report['batching']['audit']['batched_instances']==64
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
