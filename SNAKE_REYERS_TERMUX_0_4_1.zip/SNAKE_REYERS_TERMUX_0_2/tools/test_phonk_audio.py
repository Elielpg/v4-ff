"""Real Godot audio regression. Requires an existing working PulseAudio server.

Runs an isolated, synthetic scene; never starts/stops another project's audio,
opens the original pack, changes its files, or connects a TikTok LIVE.
"""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import tempfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--godot',default='godot')
    parser.add_argument('--output',type=Path,default=Path('PHONK_AUDIO_TEST.json'))
    parser.add_argument('--stress-seconds',type=int,default=0,help='0..600 seconds of repeated object/camera creation')
    args=parser.parse_args()
    if not 0<=args.stress_seconds<=600:parser.error('Use --stress-seconds entre 0 e 600.')
    root=Path(__file__).resolve().parents[1]
    with tempfile.TemporaryDirectory(prefix='phonk-audio-test-') as directory:
        work=Path(directory)
        (work/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Own PHONK audio test"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
        shutil.copy2(root/'tests/godot/phonk_main.gd',work/'main.gd')
        source=(root/'tests/godot/phonk_audio.gd.in').read_text()
        runtime=(root/'snake_termux/godot/phonk_runtime.gd').as_posix()
        (work/'test.gd').write_text(source.replace('RUNTIME_PATH',runtime))
        config={'enabled':True,'palette':['#9922ff','#ee55ff'],
                'track_palettes':{'songB':['#aa00ee','#ee11aa']},'color_mode':'fixed',
                'source':'music','runtime':{'tracks':{'b.ogg':{'id':'songB','title':'Test B'}}}}
        (work/'config.json').write_text(json.dumps(config))
        import os
        env={**os.environ,'SNAKE_PHONK_CONFIG':str(work/'config.json'),
             'SNAKE_PHONK_STATUS':str(work/'runtime.json'),
             'SNAKE_PHONK_STRESS_SECONDS':str(args.stress_seconds)}
        result=subprocess.run([args.godot,'--headless','--audio-driver','PulseAudio',
                               '--path',str(work),'--script',str(work/'test.gd')],
                              env=env,capture_output=True,text=True,timeout=40+args.stress_seconds)
        args.output.with_suffix('.log').write_text(result.stdout+result.stderr)
        if (work/'result.json').exists():shutil.copy2(work/'result.json',args.output)
        if result.returncode or 'PHONK_TEST_PASSED' not in result.stdout:
            raise SystemExit('Teste não passou. Confira '+str(args.output.with_suffix('.log')))
        print(args.output.read_text())


if __name__=='__main__':main()
