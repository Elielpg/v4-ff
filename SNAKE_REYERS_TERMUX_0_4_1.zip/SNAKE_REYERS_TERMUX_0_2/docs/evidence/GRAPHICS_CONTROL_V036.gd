extends "/workspace/snake-reyers-termux-adapter/snake_termux/godot/scene_graphics.gd"
func _initialize() -> void:
    viewport_3d=root
    config={"adaptive_resolution":true,"minimum_scale":.65,"maximum_scale":.90,"target_fps":30}
    current_scale=.82
    elapsed=0.0
    for index in range(3):
        frame_times=[50.0,50.0,50.0]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.82))
    elapsed=20.0
    for index in range(3):
        frame_times=[50.0,50.0,50.0]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.77))
    for index in range(2):
        frame_times=[40.0,40.0,40.0]
        _report_and_adapt()
    for step in range(8):
        for index in range(3):
            frame_times=[100.0,100.0,100.0]
            _report_and_adapt()
        for index in range(2):
            frame_times=[80.0,80.0,80.0]
            _report_and_adapt()
    assert(is_equal_approx(current_scale,.65))
    for index in range(120):
        frame_times=[33.34,33.34,33.34]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.90))
    current_scale=.82
    slow_windows=0
    good_windows=0
    for index in range(5):
        frame_times=[100.0,100.0,100.0]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.82))
    assert(no_gain_reverts==1 and adaptive_cooldown_until>elapsed)
    for index in range(8):
        frame_times=[100.0,100.0,100.0]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.82))
    adaptive_cooldown_until=0.0
    Engine.max_fps=24
    current_scale=.82
    slow_windows=0
    good_windows=0
    for index in range(4):
        frame_times=[41.67,41.67,41.67]
        _report_and_adapt()
    assert(is_equal_approx(current_scale,.82))
    Engine.max_fps=0
    _build_decorations()
    assert(audit.decor_instances==114 and audit.decor_batches==5)
    for child in detail_root.get_children():
        assert(child is MultiMeshInstance3D)
        assert(child.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF)
    print("OWN_GRAPHICS_CONTROL_OK bounds, startup hysteresis, recovery, no-gain restore/cooldown, explicit cap, 114 instances in 5 batches, no shadow casters")
    quit()
func _process(_delta: float) -> bool:
    return false
