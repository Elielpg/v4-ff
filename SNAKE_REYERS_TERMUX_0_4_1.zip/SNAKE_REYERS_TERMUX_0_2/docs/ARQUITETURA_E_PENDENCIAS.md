# Arquitetura e pendências — 25/11/2026

## GT3 e captura 0.3.4

`performance.py` mede somente processos próprios conhecidos pelo jogo e pelo iniciador local, incluindo filhos do proot quando legíveis. CPU usa deltas de `/proc`, normalizados por um núcleo; PID reutilizado não aproveita contadores anteriores. RSS, CPUs permitidas, threads quentes, falhas maiores de página e sensores disponíveis acompanham a leitura. O gravador mantém um único trabalho, seis amostras, em thread do servidor; ausência de sensores não vira zero. Não aceita PIDs ou comandos do público.

`presentation.py` acrescenta perfis GT3 sem retirar os anteriores. `native.py` reconhece o log de GPU Vulkan e permite optar por Mobile/Vulkan; não o ativa automaticamente. Falta de GPU confirmada no caminho Termux preserva a alternativa OpenGL. `reuse_ai.py` aplica o orçamento de CPU apenas a filhos que lança; não reniceia nem encerra serviços externos. `piper_worker.py` permite 1–2 threads, mantendo cache e espera ativa desativada. Não foi adicionado uso de GPU/NPU à IA.

`studio_audio.py` expõe PCM 48 kHz/estéreo somente do mixer privado deste jogo. Autoriza por token efêmero/uso único em cabeçalho, limita leitores e termina somente o próprio parec ao desconectar. Não usa o daemon PulseAudio compartilhado nem altera a saída audível. A ponte é opcional; falha dela não encerra o jogo.

Cofra Studio é um app Android separado, sem recursos do jogo e sem executar o modelo. MediaProjection captura a fonte autorizada; EGL faz composição/corte; MediaCodec H264 por hardware/AAC produz MP4 de teste ou RTMP/RTMPS. Fila de envio limitada, sem reconexão infinita ou publicação automática. A chave fica no app, não no backend Termux. O teste MP4 não precisa de chave e não abre conexão de transmissão.

Backup anterior à etapa: adaptador 0.3.3 preservado no ambiente de desenvolvimento. O reparo salva arquivos e configuração de perfil/recursos no aparelho, com primeira aplicação registrada e reaplicações que preservam escolhas posteriores. O guia contém reversão por commit conhecido, sem mexer em jogo, progresso ou modelos.

A causa física das travadas no GT3 ainda é pendência, não correção comprovada. Comparação Vulkan/Adreno, MediaProjection, encoder Qualcomm, áudio Android, Green Tube e LIVE prolongada exigem aparelho físico. Detalhes em `GT3_E_TRANSMISSAO_V034.md`.


## Conversa local 0.3.3

`local_social.py` instala hooks reversíveis no gerador de resposta social e no construtor de resposta principal, somente quando Qwen local e o perfil melhorado estão selecionados. Gemini/OpenAI e o perfil anterior continuam disponíveis. Saudações instantâneas, guardas originais, atribuição, presentes e os eventos de gameplay são preservados. Falha de geração não repete a chamada nem retorna uma resposta fictícia sem relação.

`client.py` envia uma identidade compacta com os campos de nome/criador originais, personalidade, nome pronunciável do espectador, até duas trocas em roles user/assistant e a pergunta atual. Nome/histórico não viram instruções de sistema. O tratamento de eu/meu distingue o espectador da cobra. Perguntas informativas usam amostragem mais conservadora e instrução para explicar sem piada; conversa social usa sarcasmo gentil. Não há ferramentas, shell, navegação ou execução de ações vindas do modelo. O contexto continua compatível com o limite existente de 2048 tokens.

A memória fica em `original/server/private/termux-conversation.json`: dois turnos por ID em hash, TTL de uma hora, até 128 IDs, escrita atômica privada. O painel só retorna configurações/quantidade, sem histórico de conversa. Um erro de disco deixa aviso e mantém o estado da sessão. GET não chama modelo nem TTS. Rotas: GET/POST `/termux/local-personality` e GET/POST `/termux/local-speech`.

`voice.py` permite uma síntese até 240 caracteres; `piper_worker.py` escolhe três perfis e inclui perfil/versão/modelo no cache. O controle de threads/espera ativa permanece. A timeline vem do áudio real. `cloud_ai.py` ajusta apenas instruções de dicção OpenAI, sem trocar a voz ou usar uma chave localmente durante os testes. A etapa adicional de normalização textual não foi incluída; não se afirma expansão automática de números ou correção lexical da saída do modelo.

O reparo V033 seleciona o provedor local no arquivo privado antes da abertura. Guarda backup 0600 da seleção anterior e conserva voz, chaves, modelos e portas. O modo `--files-only` serve aos testes e não muda a seleção. O helper não consulta APT, não instala pesos e não encerra serviços de outros projetos.

Pendentes: avaliar dicção/timbre no GT3 e na voz selecionada, latência e temperatura em LIVE prolongada; estudar um modelo maior apenas se o aparelho sustentar o custo e o usuário optar. Os testes reais de Qwen mostraram que linguagem técnica ainda pode sair incorreta. Os checks de tópico não são certificação de correção factual. A inferência Cloud usa CPU x86_64 e prazo de desenvolvimento distinto; não demonstra desempenho Android. Captura/RTMP e o contador de espectadores mantêm os limites da 0.3.2.

## Evolução 0.3.2

| Arquivo próprio | Mudança | Impacto e limite |
|---|---|---|
| `reuse_ai.py` | Não regrava a seleção local após iniciar Qwen; atualização da porta Piper exige seleção ainda correspondente | Impede sobrescrever Gemini/OpenAI durante inicialização lenta; não encerra serviços externos |
| `cloud_settings.py`, `cloud_ui.js` | Provedor ativo destacado; atalho Gemini; teste com provedor esperado | Separa teste de chave da seleção real e recusa divergência antes da chamada |
| `cloud_ai.py` | Catálogo paginado, modelo resolvido em cache, configuração de geração, tratamento de 400/404/limite de saída | Até duas chaves/três gerações; respeita 429 e cotas por projeto; sem consulta de saldo |
| `live_load.py` | Um job adiantado, foco do espectador diferido, priorização de perguntas recentes, dedup limitado, saudações agrupadas | Mantém uma voz por vez e ações originais; não promete ler todos os eventos |
| `speech_names.py` | Normalização de nomes somente na síntese; aliases persistidos | Preserva identidade visual e legenda; pronúncia do motor ainda precisa de escuta |
| `native.py`, `presentation.py`, `ui.js` | FPS do log atual, GPU observada e perfis opcionais 720p45/864p30 | Sem alteração do PCK, shaders ou câmera interna; limite não equivale a FPS medido |
| `director.py`, `director.html` | Evento existente data-viewer → contador separado do cenário | viewerCount apenas, dado ausente/desatualizado explícito; captura de tela inteira pode mostrar o painel |

```text
TikTok → monitor original → regras/eventos originais → Godot original
                         ├─ roomUser.viewerCount → painel do operador, fora do cenário
                         └─ decisão social → Qwen OU Gemini OU OpenAI
                              └─ fila com no máximo 1 preparação adiantada
                                   └─ Piper OU OpenAI speech OU XTTS → WAV/timeline → Godot
```

O hook de preparação adiantada registra a atividade visual do próximo espectador nos metadados internos do job. O bridge a envia apenas ao despachar speech_ready, removendo esse campo interno da mensagem de fala. As regras originais de presentes, cantoria, sequências e diálogo continuam. A normalização altera somente o texto de síntese; a fila devolve `text` original e `spoken_text` separado. Os hooks são reversíveis por `LocalBinding.restore()`.

Rotas acrescentadas: GET/POST `/termux/live-load`, POST `/termux/spoken-name`, GET `/termux/director`, GET `/termux/director/status`, POST `/termux/director/encoder-check`. Nenhuma recebe shell arbitrário, chave de transmissão ou publica LIVE. Os aliases ficam na configuração privada existente com permissão 0600. Estatísticas agregadas não incluem conteúdo do chat.

**Evidência da falha Gemini:** a imagem do usuário confirma teste de chave bem-sucedido e pergunta roteada ao Qwen. Não é evidência de chave Gemini inválida. A corrida do iniciador foi reproduzida com processo/HTTP controlados, e a seleção agora é preservada. Chamadas externas reais continuam pendentes; compatibilidade do request é testada com transporte simulado.

**Pendências atuais:** medir FPS/temperatura/memória/latência numa LIVE longa no GT3, ouvir os nomes com voz OpenAI selecionada, confirmar viewerCount emitido na LIVE real e avaliar captura/RTMP Android com acesso TikTok à URL/chave. A suíte Cloud não valida essas condições físicas/de conta. A 0.3.2 não implementa transmissão; a consulta de encoders não confirma aceleração por hardware. O painel do operador só fica fora da LIVE se a captura usada não incluir o navegador.

## Histórico da estrutura

Na 0.3.1, `cloud_settings.py` envolve de forma reversível as funções do binding antes da instalação dos hooks originais. O provedor de respostas (`local`, `gemini`, `openai`) e o de voz (`piper-local`, `xtts`, `openai`) são independentes. A opção de nuvem usa campos próprios e não é ativada por credenciais históricas. `reuse_ai.py` inicia apenas os serviços locais selecionados, sem encerrar serviços externos.

`cloud_ai.py` implementa HTTPS com hosts fixos e sem redirecionamentos. Gemini usa generateContent e o catálogo models para seleção automática de Flash de texto; OpenAI usa Responses e audio/speech. Os modelos recebem texto e identidade, sem ferramentas, shell ou navegação. A voz usa input separado de instructions e devolve PCM convertido para WAV/timeline compartilhada em `voice.prepare_speech`. O cache tem até 60 itens. As chamadas têm timeout, tamanho máximo e limitador local, sem reinícios ou tentativas infinitas.

As chaves Gemini são agrupadas por projeto informado pelo usuário; sem grupo usa-se default. Estados de recusa e espera por cota ficam em `termux-cloud-health.json` com IDs e diagnósticos gerados, sem valores de chave. Um 429 pausa o grupo/modelo; outra chave do mesmo grupo não contorna a espera. Na 0.3.2 há no máximo duas chaves/três gerações por resposta. O painel não apresenta saldo financeiro, pois a API de geração não expõe esse saldo por chave.

Rotas novas: GET/POST `/termux/cloud/settings`, POST `/termux/gemini/check`, POST `/termux/ai/test`, POST `/termux/cloud/voice` e GET `/termux/cloud-ui.js`. Os endpoints locais continuam disponíveis. `cloud_ui.js` apresenta um cartão novo somente quando o backend correspondente existe, conservando a compatibilidade de reparos parciais anteriores. O painel usa campos vazios para novas chaves; nenhum GET devolve valores completos.

Pendentes: verificar chamadas reais com chaves inseridas pelo usuário, quotas/modelos acessíveis, qualidade de pronúncia e timbre OpenAI, latência de rede e estabilidade no GT3. A fonte consultada foi o SDK oficial público e os exemplos oficiais no GitHub; os sites de documentação estavam bloqueados na rede deste ambiente. Não houve chamada real à API nem consulta de conta/créditos. Testes de transporte usam respostas simuladas e PCM sintético, sem alegar uma amostra real de voz OpenAI.

Na 0.3.0, `piper_worker.py` constrói a sessão ONNX CPU com `intra_op_num_threads=2`, `inter_op_num_threads=1`, execução sequencial e spinning desativado. `/health` informa o limite de inferência; o processo pode conter outras threads do Python/NumPy além das duas de inferência. Não há troca de modelo ou timbre. O iniciador preserva sua política de não encerrar serviços externos já prontos.

`music_library.py` prefixa somente a conversão com `nice -n 10` quando existe o comando; FFmpeg continua com uma thread, timeout e validação. Nenhum processo externo tem prioridade ou afinidade alterada. `PrivateAudio` escolhe 160 ms como padrão do seu ambiente privado; `device_runtime.output_latency` aplica a margem ao módulo Android e ao Godot, respeitando override e limitando valores a 40–300 ms. Rotas de captura explícitas mantêm seu tratamento anterior. O perfil `stable` acrescenta um limite opcional de 30 FPS e preserva a exigência de GPU confirmada.

Pendência principal: os novos logs e o A/B com música pausada do GT3 não chegaram. A regressão relatada ainda não tem causa única confirmada. Há evidência de menor concorrência do Piper no host Linux e de funcionamento conjunto de música e voz, sem benchmark ou confirmação de ausência de engasgos no Android/Bluetooth. Não há alteração em câmera, shaders ou código privado do pacote.

Na 0.2.9, `music_library.py` instala hooks reversíveis sobre `music_runtime.websocket_message` e `choose_session_start_track`. Os arquivos e o player originais permanecem intactos. A mensagem mantém volume/pausa do runtime e filtra `tracks`/metadados para uma única faixa repetida ou para o subconjunto marcado. A biblioteca não adiciona outro player ao mixer nem interfere na fila de voz ou no TikTok.

Rotas: GET `/termux/music/library`, POST `/termux/music/import` (um multipart por arquivo), POST `/termux/music/control` e compatibilidade com POST `/termux/music/upload`. A API aceita IDs de faixas conhecidas, não comandos ou caminhos arbitrários. O conteúdo é analisado por FFprobe; FFmpeg roda com argumentos separados, protocolos locais, uma thread, timeout e arquivo temporário antes da substituição atômica. A preparação usa `asyncio.to_thread`, com uma operação por vez e status consultável. Seleção, modo, metadados e cache ficam em JSON próprio; os originais são mantidos.

Falha confirmada no aparelho: o Godot registra `MUSIC_LOAD_FAIL` e `Failed to decode mp3 file` para duas cópias de Barões, então volta à trilha padrão. O conteúdo exato desses arquivos não foi recebido; pode ser outro contêiner renomeado ou um download incompleto. Converter resolve contêiner compatível mal nomeado; não recupera áudio inexistente. Pendentes: validar os mesmos arquivos no GT3 e observar memória/temperatura em faixas longas. Biblioteca salva não é confirmação de saída física; o painel informa seleção enviada, e os testes Linux capturam o mixer.

Na 0.2.8, `live_tuning.py` instala hooks reversíveis sobre o tratamento de comentários e o cache de avatares. O modo direto enfileira apenas o ator principal, sem metadados de par que esperariam uma leitura prévia do usuário. Preserva a seleção visual do espectador e a prioridade dos apoiadores. O modo de diálogo chama a função original. Os presentes seguem o fluxo original.

Avatar e geração textual são aguardados em paralelo; o enfileiramento só acontece depois de ambos, sem tarefas atrasadas de seleção roubando o foco durante a fala. A imagem derivada de até 256 px fica ao lado do cache original. A opção `termux_reply_mode` fica no arquivo privado de IA existente, preservando os outros campos. `/termux/live-tuning` retorna apenas modo e métricas de preparação, sem texto de comentários, fotos ou chaves.

Pendências: validar o tempo entre comentário real e áudio no GT3, observar travadas no perfil LIVE e, para alterar a interpolação interna de câmera/oclusão por objetos, obter uma versão publicada do projeto Godot. A revisão atual reduz o acionamento do foco intermediário; não altera recursos privados do pacote.

A revisão 0.2.7 separa a preparação gráfica da consulta de áudio compartilhado. `audio_service.py` cria um servidor PulseAudio próprio para a janela nativa e acompanha seu processo. O socket Unix fica numa pasta com permissão 0700. O jogo e o teste de som recebem o mesmo `PULSE_SERVER`. Não se carrega a configuração compartilhada do daemon nem a suspensão por inatividade.

Falha de áudio passa a escolher Dummy explicitamente antes de iniciar Godot, evitando que o motor tente conectar a um servidor sem resposta. O jogo continua visual, com aviso de som indisponível. Os processos próprios recebem encerramento limitado e a limpeza fica restrita à pasta temporária que o complemento criou. O wrapper de captura mantém rotas explícitas do original. Não há mudanças de modelos/IA, game assets ou reinícios automáticos em ciclo.

O GT3 confirmou timeout de pactl com GPU/tela prontas. O caminho privado e o fallback visual foram testados com o jogo original no Linux; AAudio físico, calor e longa duração no aparelho permanecem pendentes.

A revisão 0.2.6 adiciona uma segunda verificação de áudio após as preferências X11 e antes do processo Godot. Ela usa um PCM silencioso para verificar abertura do stream e presença da saída, sem afirmar audibilidade. O fallback AAudio usa a proteção oficial contra fechamento/retomada problemática. O processo recebe latência de saída de 80 ms. O painel identifica driver Dummy no log da execução atual, mesmo que a reprodução interna informe início/fim.

Falha atual do GT3: áudio gerado e eventos de fala completos, mas Godot em Dummy e apenas auto_null disponível. O desaparecimento exato do módulo Android não foi reproduzido em hardware. Não foram acrescentados reinícios automáticos de processo/daemon, nem um segundo player que pudesse duplicar falas. A próxima validação é aplicar a 0.2.6 e conferir a fala no aparelho.

Na revisão 0.2.5, `presentation.py` aplica as preferências oficiais do Termux:X11 com backup e timeout, confirma a resolução pelo `xdpyinfo` e escolhe o modo fullscreen do processo original. O perfil só aumenta a resolução quando `device_runtime.py` confirmou GPU. O arquivo `presentation-config.json` guarda a opção de qualidade. Isso não altera shaders, personagens, câmera, regras nem os recursos internos do jogo.

O mesmo módulo adiciona a faixa própria `assets/music/Neon Garden.ogg` uma única vez numa biblioteca vazia. O runtime e o websocket originais continuam responsáveis pela playlist, pausa, volume e reprodução. Não há geração de música durante a LIVE nem uma segunda fila de áudio concorrendo com Piper.

Pendências atuais: confirmar a interface limpa e a nova trilha no GT3; medir FPS/temperatura/latência durante uma LIVE real prolongada; validar captura/transmissão Android. O usuário já confirmou GPU no relatório e testes de som/voz audíveis. Os limites de FPS são configurações, não resultados de benchmark.

```text
start.sh → Termux:X11 + PulseAudio → python -m snake_termux --game --reuse-ai
  └─ servidor FastAPI original 0.1.9
       ├─ painel original + controles locais ui.js
       ├─ monitor TikTok original ← @ normalizado
       ├─ regras/eventos/gameplay originais
       ├─ respostas sociais originais
       │    └─ client.py → Qwen em loopback, sem API externa
       └─ fila de fala original
            ├─ voice.py → Piper local → WAV + timeline originais
            └─ XTTS original, quando selecionado

jogo Godot original ← bridge original /ws/godot
  └─ native.py → Godot 4.7.2 --main-pack arquivo original
       ├─ execução e renderização Linux x86_64 comprovadas
       └─ execução ARM64/Android: pendente de validação no aparelho
```

`integration.py` instala hooks reversíveis depois de importar o servidor. Atualiza também referências já importadas por outros módulos: trocar apenas a função em `social_text_ai` deixaria algumas chamadas usando a função antiga que exige chave. `restore()` permite desfazer os hooks nos testes; encerrar o processo os desfaz no uso normal.

As chamadas de IA e Piper usam portas configuráveis somente em 127.0.0.1. Proxies de ambiente e redirecionamentos HTTP são desabilitados nesses clientes para não encaminhar o conteúdo a outro host. Não existe executor de comandos solicitado pelo modelo. A entrada @ é validada antes de chegar ao monitor original.

`voice.py` usa o serviço Piper já existente: `/health` deve anunciar um modelo Piper pronto e `/synthesize` deve devolver WAV PCM válido. Não instala modelos nem inicia automaticamente a clonagem. A configuração pode manter XTTS original. O retorno inclui `audio_path`, `timeline_path`, `timeline`, `voice_path` e `chunks`, consumidos pela fila original.

`device_runtime.py` acrescenta configuração por processo para Zink/Turnip, verificação do renderizador e fallback de CPU. O mesmo módulo prepara uma saída PulseAudio real, com fallback OpenSL ES → AAudio, e registra diagnóstico em `state/device-runtime.json`. O motor usa PulseAudio quando uma saída real é preparada, evitando uma variável antiga Dummy silenciar o jogo. Os novos controles permitem testar sinal, fala pela fila original e selecionar música local.

## Problemas encontrados e situação

| Problema | Evidência | Situação |
|---|---|---|
| IA original exige chave OpenAI e usa `/v1/responses` | Leitura de `social_text_ai.py` e `user_ai_settings.py` | Adaptada para chat/completions local; teste HTTP com servidor controlado passou. Falta Qwen real no GT3. |
| Referências antigas de funções na fila social | Imports por valor em `social_reply.py` | Hook cobre aliases; teste de pergunta e presente passou. |
| Fonética XTTS aplicada a outro motor pode alterar pronúncia | Substituições em `prepare_tts_input` | Piper recebe grafia brasileira sem essas trocas. Isso não prova qualidade perceptual de todos os nomes. |
| Clonador lento pode ocupar a porta anterior | Histórico e contratos dos serviços | Detecção do modelo evita confundir clonador com Piper. |
| Voz gerada sem reprodução no navegador | Histórico; política de autoplay | Player e botão de retomada implementados; WAV real decodificado no Chromium. Falta teste do jogo Android. |
| Motor Windows x86_64 incompatível diretamente com ARM64 | Cabeçalho PE | Godot nativo carrega os dados originais via main-pack; funcionamento e renderização comprovados no Linux. Falta validar Android. |
| Executável inicialmente incompleto | Manifesto dos oito fragmentos | Resolvido: oito partes válidas e SHA-256 completo correspondente. |
| Atualizador original instala pacotes de desktop | Leitura dos launchers/updater | Instalação automática de desktop bloqueada pelo adaptador; conferência manual necessária. |
| Python 3.13 remove `audioop` | Import em `audio_timeline.py` | Dependência `audioop-lts` prevista. Testes atuais em Python 3.12. |
| Instalador Linux pressupõe desktop e voz pesada | Leitura de install.sh, requisitos e launchers | Bootstrap Termux/X11 independente, com cópia interna, backup e reutilização dos modelos. Instalação Android ainda não testada. |
| Áudios completos não estão nos uploads | Apenas manifests/links recebidos | Preservados os mecanismos originais, sem afirmar que os pacotes musicais estão disponíveis. |
| Programa termina e volta ao prompt | Relato do usuário sobre projetos anteriores | Não reproduzido no celular. Logs e códigos de saída adicionados para obter evidência. Não há diagnóstico comprovado de memória/Android. |
| Jogo lento no GT3 | Log de OpenGL informa llvmpipe; Freedreno não instalado | Reparo instala driver oficial e mede renderer antes de ativar perfil GPU; verificação real do GT3 pendente. |
| Jogo sem áudio | PulseAudio informa apenas auto_null | Preparação de saída Android e teste de som implementados; confirmação auditiva no GT3 pendente. |
| Sem música de fundo | Log original informa tracks=0 | Seleção/upload de arquivo local adicionada ao painel, usando o runtime original. |

## Próximas verificações

1. Testar instalação Bionic/ARM64 e drivers Termux:X11 no GT3; o caminho de carga já foi comprovado no Linux.
2. Testar Qwen real, comentários e presentes numa LIVE curta; nenhum teste local comprova acesso atual do TikTok.
3. Medir estabilidade e memória/temperatura no GT3 com gráficos, IA, voz e captura juntos. Não há benchmark desse conjunto ainda.
4. Investigar encerramentos com os novos logs e código de saída. Este complemento não cria laços de reinicialização automática.

`reuse_ai.py` procura os serviços existentes e pode iniciar somente os binários/modelos da instalação anterior. `prepare_project.py` mantém a cópia original e faz backup privado. `termux_packages.py` isola temporariamente as fontes APT principal/X11, preservando formato Deb822, Signed-By e verificação de assinatura.

Nenhuma promessa de FPS, latência ou estabilidade no Android é feita com base nos resultados da máquina Cloud.
