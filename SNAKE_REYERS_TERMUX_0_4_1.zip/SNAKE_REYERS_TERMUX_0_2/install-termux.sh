#!/usr/bin/env bash
set -euo pipefail
adapter_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "$adapter_dir"
if ! command -v python3 >/dev/null 2>&1; then
  printf 'Instale primeiro o pacote python no Termux.\n' >&2
  exit 1
fi
python3 -m snake_termux.prepare_project "$@"
python3 -m snake_termux.termux_packages
bash install-panel.sh
project_dir="$(cat state/project-path.txt)"
npm --prefix "$project_dir/server/external/tiktok-live-monitoring-server" ci
.venv/bin/python -m snake_termux.device_runtime --install
if [[ -f snake_termux/original_update.py ]]; then
  .venv/bin/python -m snake_termux.original_update "$adapter_dir"
fi
printf '\nPreparo concluído. Instale também o aplicativo oficial Termux:X11 no Android.\n'
printf 'Iniciar: bash start.sh\n'
