import json
import time
from pathlib import Path

from fastapi.testclient import TestClient

from snake_termux.local_social import ConversationMemory, select_local, trim_reply


def test_local_question_has_one_identity_and_isolated_role_history(adapted, local_service):
    app,binding=adapted
    binding.update({'provider':'local','local_port':local_service['port']})
    local_service['text']='O Sol é uma estrela. Até eu sei, e nem pálpebra tenho!'
    first=binding.ai.generate_chat_reply(display_name='A N A',comment='O que é o Sol?',user_key='ana')
    assert first==local_service['text']
    local_service['text']='Ele emite luz por fusão nuclear.'
    assert binding.ai.generate_chat_reply(display_name='Ana',comment='Como ele produz luz?',user_key='ana')
    messages=local_service['calls'][-1]['data']['messages']
    assert [x['role'] for x in messages]==['system','user','assistant','user']
    assert messages[0]['content'].count('Nome: Serpente do Abismo')==1
    assert 'sarcasmo gentil' in messages[0]['content']
    assert first==messages[2]['content']
    assert 'Como ele produz luz?' in messages[-1]['content']
    assert 'Nome: Serpente' not in messages[-1]['content']
    binding.ai.generate_chat_reply(display_name='Beto',comment='E ele?',user_key='beto')
    assert len(local_service['calls'][-1]['data']['messages'])==2
    assert TestClient(app).get('/termux/local-personality').json()['memory_users']==2


def test_model_is_not_replaced_secrets_not_sent_and_private_memory_not_exposed(adapted,local_service):
    app,binding=adapted
    raw={'provider':'local','model':'auto','enabled':True,'local_port':local_service['port'],'openai_api_key':'private-never-send','termux_response_provider':'local'}
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,raw)
    answer=binding.ai.generate_chat_reply(display_name='Ana',comment='Me explica uma célula',user_key='ana')
    request=local_service['calls'][-1]['data']
    assert request['model']=='ben-classico-local' and not request.get('tools')
    assert 'private-never-send' not in json.dumps(request)
    memory=binding.conversation_memory
    assert memory.path.stat().st_mode & 0o777==0o600
    public=TestClient(app).get('/termux/local-personality').text
    assert 'Me explica' not in public and answer not in public
    assert 'ana' not in memory.path.read_text()  # user IDs are hashed


def test_two_turns_persist_expire_and_top_event_ids_share_same_viewer(tmp_path):
    path=tmp_path/'memory.json';m=ConversationMemory(path)
    for n in range(4):m.remember('ana:top:event'+str(n),'question'+str(n),'answer'+str(n))
    restored=ConversationMemory(path)
    assert [x['user'] for x in restored.history('ana')]==['question2','question3']
    assert restored.history('bob')==[]
    restored.entries[restored.key('ana')]['at']=time.time()-4000
    assert restored.history('ana')==[]
    restored.entries[restored.key('bad')]={'at':time.time(),'turns':1}
    assert restored.history('bad')==[]


def test_memory_bounded_and_disk_failure_does_not_drop_answer(tmp_path,monkeypatch):
    m=ConversationMemory(tmp_path/'memory.json')
    for n in range(131):m.remember(str(n),'pergunta','resposta')
    assert len(m.entries)==128 and not m.history('0')
    original=Path.replace
    def fail(path,target):
        if target==m.path:raise OSError('disk full')
        return original(path,target)
    monkeypatch.setattr(Path,'replace',fail)
    m.remember('current','oi','olá')
    assert m.history('current')[0]['assistant']=='olá' and m.warning


def test_memory_off_clear_and_response_length_are_selectable(adapted,local_service):
    app,binding=adapted;client=TestClient(app)
    binding.update({'local_port':local_service['port']})
    assert binding.config()['max_chars']==220
    first='A fotossíntese converte luz em energia química para a planta.'
    local_service['text']=first+' '+('Uma brincadeira muito longa que pode ficar para depois. '*6)
    from cobrinha_server.services.social_reply import build_main_reply
    answer=build_main_reply(display_name='Ana',comment='Como funciona a fotossíntese?',user_key='ana')
    assert answer.startswith(first) and len(answer)<=220 and answer.endswith('.')
    assert client.post('/termux/local-personality',json={'memory':False,'length':'short','clear_memory':True}).status_code==200
    assert binding.config()['max_chars']==150
    binding.ai.generate_chat_reply(display_name='Ana',comment='E os animais?',user_key='ana')
    assert len(local_service['calls'][-1]['data']['messages'])==2
    assert not binding.conversation_memory.entries
    assert client.post('/termux/local-personality',json={'enabled':'yes'}).status_code==400


def test_failure_does_not_repeat_model_call_or_fabricate_unrelated_reply(adapted,local_service):
    _,binding=adapted;binding.update({'local_port':local_service['port']})
    local_service['text']=''
    from cobrinha_server.services.social_reply import build_main_reply
    answer=build_main_reply(display_name='Ana',comment='Qual é a capital do Peru?',user_key='ana')
    assert 'Não consegui responder' in answer
    assert len([x for x in local_service['calls'] if x['path'].endswith('completions')])==1
    assert not binding.conversation_memory.entries


def test_offline_local_choice_preserves_voice_keys_port_and_creates_backup(adapted,tmp_path):
    _,binding=adapted
    source=Path('/workspace/snake-reyers-0.1.9-audit')
    adapter=tmp_path/'adapter';(adapter/'state').mkdir(parents=True)
    (adapter/'state/project-path.txt').write_text(str(source))
    raw={'termux_response_provider':'gemini','provider':'local','model':'auto','local_port':8081,'voice_provider':'piper-local','termux_cloud_voice_enabled':True,'termux_openai_voice':'cedar','openai_api_key':'keep-private'}
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,raw)
    select_local(adapter)
    result=binding.settings._raw()
    assert result['termux_response_provider']=='local' and result['enabled']
    assert result['termux_cloud_voice_enabled'] and result['termux_openai_voice']=='cedar'
    assert result['openai_api_key']=='keep-private' and result['local_port']==8081
    backup=next((adapter/'state/launcher-backups').glob('local-choice*'))
    assert json.loads(backup.read_text())==raw and backup.stat().st_mode & 0o777==0o600


def test_current_weather_is_not_invented_but_science_still_uses_model(adapted,local_service):
    _,binding=adapted;binding.update({'local_port':local_service['port']})
    answer=binding.ai.generate_chat_reply(display_name='Ana',comment='Está chovendo agora em Recife?',user_key='ana')
    assert 'Não consulto o clima' in answer and not local_service['calls']
    answer=binding.ai.generate_chat_reply(display_name='Ana',comment='Por que a chuva cai?',user_key='ana')
    assert answer==local_service['text'] and local_service['calls']


def test_factual_questions_prioritize_precision_while_social_comments_keep_humor(adapted,local_service):
    _,binding=adapted;binding.update({'local_port':local_service['port']})
    binding.ai.generate_chat_reply(display_name='Ana',comment='Qual é a capital da França?',user_key='ana')
    factual=local_service['calls'][-1]['data']
    assert factual['temperature']==.2 and 'sem piada' in factual['messages'][0]['content']
    binding.ai.generate_chat_reply(display_name='Ana',comment='Você é muito convencida, cobra!',user_key='ana')
    social=local_service['calls'][-1]['data']
    assert social['temperature']==.6 and 'sarcasmo gentil' in social['messages'][0]['content']
