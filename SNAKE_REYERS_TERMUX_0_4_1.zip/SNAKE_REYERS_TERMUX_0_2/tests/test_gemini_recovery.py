import json
import time

import pytest
from fastapi.testclient import TestClient

from snake_termux.cloud_ai import CloudAPI, APIError, classify
from test_cloud_ai import configure, G1


def response(text='Olá, Ana!'):
    return {'candidates': [{'content': {'parts': [{'text': text}]}}]}


def test_catalog_pagination_and_working_model_are_preserved(adapted, monkeypatch):
    app, binding = adapted; configure(binding, 'gemini')
    pages = []
    def request(provider, path, payload, key, **kw):
        if path == '/models':
            pages.append(kw.get('query'))
            if len(pages) == 1: return {'models': [], 'nextPageToken': 'next-token'}
            return {'models': [{'name': 'models/gemini-3.5-flash-lite', 'supportedGenerationMethods': ['generateContent']}]}
        return response()
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    result = TestClient(app).post('/termux/ai/test', json={'text': 'uma pergunta'})
    assert result.status_code == 200
    assert pages[0]['pageSize'] == 100 and pages[1]['pageToken'] == 'next-token'


def test_optional_config_400_retries_same_model_without_marking_key_invalid(adapted, monkeypatch):
    app, binding = adapted; configure(binding, 'gemini', gemini_model='gemini-3.5-flash-lite')
    calls = []
    def request(provider, path, payload, key, **kw):
        calls.append(json.loads(json.dumps(payload)))
        if len(calls) == 1: raise classify(400, {'error': {'status': 'INVALID_ARGUMENT', 'message': 'thinkingConfig not supported'}})
        return response()
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'uma pergunta'}).status_code == 200
    assert len(calls) == 2 and 'thinkingConfig' in calls[0]['generationConfig']
    assert 'thinkingConfig' not in calls[1]['generationConfig']
    assert binding.cloud_api.keys_public()[0]['state'] == 'available'


def test_unavailable_auto_model_falls_back_to_announced_text_model_only(adapted, monkeypatch):
    app, binding = adapted; configure(binding, 'gemini')
    calls = []
    def request(provider, path, payload, key, **kw):
        if path == '/models': return {'models': [{'name': 'models/' + model, 'supportedGenerationMethods': ['generateContent']} for model in ('gemini-3.5-flash-lite', 'gemini-2.5-flash-lite')]}
        calls.append(path)
        if '3.5' in path: raise classify(404, {})
        return response()
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'uma pergunta'}).status_code == 200
    assert len(calls) == 2 and '2.5' in calls[-1]
    assert binding.cloud_api.keys_public()[0]['resolved_model'] == 'gemini-2.5-flash-lite'


def test_key_check_has_text_budget_and_explains_reasoning_only_result(adapted, monkeypatch):
    app, binding = adapted; configure(binding, 'gemini', gemini_model='gemini-3.5-flash-lite')
    def request(provider, path, payload, key, **kw):
        assert payload['generationConfig']['maxOutputTokens'] >= 128
        return {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'parts': [{'thought': True, 'text': 'hidden'}]}}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    key = binding.cloud_api.keys_public()[0]['id']
    result = TestClient(app).post('/termux/gemini/check', json={'id': key}).json()
    assert not result['ok'] and result['code'] == 'output_budget'
    assert result['keys'][0]['state'] != 'invalid_key'


@pytest.mark.parametrize('body,code', [({'error': {'message': 'Billing account required'}}, 'billing_required'), ({'error': {'message': 'Unsupported location'}}, 'region_unavailable'), ({'error': {'status': 'INVALID_ARGUMENT'}}, 'invalid_request')])
def test_gemini_400_distinguishes_account_and_request(body, code):
    error = classify(400, body)
    assert error.code == code


def test_previous_wrong_model_cooldown_is_migrated_but_real_quota_retained(tmp_path):
    entries = [{'id': 'one', 'project': 'a'}, {'id': 'two', 'project': 'b'}]
    file = tmp_path / 'ai.json'
    (tmp_path / 'termux-cloud-health.json').write_text(json.dumps({
        'projects': [{'project': 'a', 'model': 'auto', 'until': time.time() + 300}, {'project': 'b', 'model': 'auto', 'until': time.time() + 300}],
        'keys': [{'id': 'one', 'model': 'auto', 'state': {'state': 'model_unavailable'}}, {'id': 'two', 'model': 'auto', 'state': {'state': 'quota', 'retry_at': time.time() + 300}}]}))
    api = CloudAPI(lambda: {'termux_gemini_keys': entries}, file)
    assert ('a', 'auto') not in api.project_cooldowns
    assert ('b', 'auto') in api.project_cooldowns


def test_diagnostic_write_failure_does_not_discard_valid_reply(adapted, monkeypatch):
    app, binding = adapted; configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    monkeypatch.setattr(binding.cloud_api, 'request', lambda *a, **kw: response())
    monkeypatch.setattr(binding.cloud_api, '_persist_health', lambda: (_ for _ in ()).throw(OSError('disk full')))
    assert TestClient(app).post('/termux/ai/test', json={'text': 'uma pergunta'}).status_code == 200
