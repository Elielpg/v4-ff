extends SceneTree
const Batches=preload("../../snake_termux/godot/static_batches.gd")
const Filter=preload("../../snake_termux/godot/camera_filter.gd")
const Pipeline=preload("../../snake_termux/godot/render_pipeline.gd")
var frame := 0
var stage := 0
var batcher: Node
var branch: Node3D
var camera: Camera3D
var sources: Array[MeshInstance3D]=[]
var before: Image
var after: Image
var render_node: Node
var results := {}
var original_poses: Array[Transform3D]=[]
var output := ""

func _initialize() -> void:
    output=OS.get_environment("SNAKE_RENDER_TEST_OUTPUT")
    if output.is_empty():output=ProjectSettings.globalize_path("user://render-pipeline-tests")
    DirAccess.make_dir_recursive_absolute(output)
    root.size=Vector2i(640,480);root.content_scale_size=Vector2i(640,480)
    branch=Node3D.new();branch.name="StaticWorldProcedural";root.add_child(branch)
    var env := WorldEnvironment.new();var world := Environment.new()
    world.background_mode=Environment.BG_COLOR;world.background_color=Color("20232c");world.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;world.ambient_light_color=Color.WHITE;world.ambient_light_energy=.6
    env.environment=world;root.add_child(env)
    var light := DirectionalLight3D.new();light.rotation_degrees=Vector3(-55,-25,0);root.add_child(light)
    for y in range(8):
        for x in range(8):
            var mesh: PrimitiveMesh
            if x%2==0:
                var shape := BoxMesh.new();shape.size=Vector3(.20+x*.018,.23+y*.02,.24);mesh=shape
            else:
                var shape := SphereMesh.new();shape.radius=.11+x*.009;shape.height=.28+y*.018;shape.radial_segments=16;shape.rings=8;mesh=shape
            var mat := StandardMaterial3D.new();mat.albedo_color=Color.from_hsv(float(x+y*8)/64,.7,.85);mat.roughness=.8;mesh.material=mat
            var node := MeshInstance3D.new();node.mesh=mesh;node.position=Vector3(-1.7+x*.48,0,-1.7+y*.48)
            branch.add_child(node);sources.append(node);original_poses.append(node.transform)
    camera=Camera3D.new();root.add_child(camera);camera.transform=Transform3D(Basis.IDENTITY,Vector3(0,4.5,6)).looking_at(Vector3.ZERO);camera.current=true
    _filter_tests()

func _filter_tests() -> void:
    var filter=Filter.new()
    filter.sample(Transform3D.IDENTITY,.033)
    var target := Transform3D(Basis.IDENTITY,Vector3(1,0,0))
    var previous := 0.0
    for index in range(120):
        var next: Transform3D=filter.sample(target,.033)
        assert(next.origin.x>=previous and next.origin.x<=1.0)
        previous=next.origin.x
    assert(is_equal_approx(previous,1.0))
    target.origin=Vector3(40,0,0)
    assert(filter.sample(target,.033).origin==target.origin)
    target.origin=Vector3(41,0,0)
    assert(filter.sample(target,.5).origin==target.origin)
    var q=Filter.new();q.sample(Transform3D.IDENTITY,.016)
    var raw := 0.0;var presented := 0.0
    for index in range(300):
        var p := Transform3D(Basis.IDENTITY,Vector3(.03 if index%2==0 else -.03,0,0))
        raw+=p.origin.x*p.origin.x
        var output: Transform3D=q.sample(p,.016)
        presented+=output.origin.x*output.origin.x
    assert(presented<raw*.2)
    results.filter={"no_overshoot":true,"monotonic":true,"teleport_preserved":true,"long_frame_snap":true,"jitter_energy_ratio":presented/raw}

func _process(_delta: float) -> bool:
    frame+=1
    if stage==0 and frame>40:
        before=root.get_texture().get_image();before.save_png(output+"/before.png")
        batcher=Batches.new();root.add_child(batcher);batcher.elapsed=4.1;stage=1;frame=0
    elif stage==1 and batcher.finished and frame>30:
        stage=2;frame=0
    elif stage==2 and frame>10:
        after=root.get_texture().get_image();after.save_png(output+"/after.png")
        assert(batcher.audit.batched_instances==64,batcher.audit)
        assert(batcher.audit.batches<16,batcher.audit)
        for index in range(sources.size()):assert(sources[index].visible and sources[index].transform==original_poses[index])
        results.batching={"audit":batcher.audit,"original_nodes_still_logically_visible":true,"source_transforms_preserved":true}
        var record: Dictionary=batcher.batches[0]
        var original: MeshInstance3D=record.sources[0].node
        original.position.x+=.07
        stage=3;frame=0
    elif stage==3 and frame>15:
        assert(batcher.audit.invalidated_groups>0)
        results.batching.dynamic_source_restored=true
        render_node=Pipeline.new();render_node.config={"camera_smoothing":true};root.add_child(render_node)
        stage=4;frame=0
    elif stage==4:
        assert(root.get_camera_3d()==camera)
        if frame>145:
            results.renderer=RenderingServer.get_current_rendering_method()
            results.camera={"logical_camera_preserved":true,"presentation":render_node.report}
            var file := FileAccess.open(output+"/result.json",FileAccess.WRITE)
            file.store_string(JSON.stringify(results));file.close();print("SYNTHETIC_PASS "+JSON.stringify(results));quit()
    if Engine.get_process_frames()>1600:push_error("Test timeout");quit(2)
    return false
