import json
import os
import time
from types import SimpleNamespace
from fastapi import FastAPI
from fastapi.testclient import TestClient
from snake_termux.performance import Sampler, inference_settings, install, DEFAULTS


def test_settings_are_bounded_and_do_not_accept_booleans(tmp_path):
    (tmp_path/'performance-config.json').write_text(json.dumps({'text_threads':True,'text_batch_threads':900,'voice_threads':2,'text_nice':-1}))
    assert inference_settings(tmp_path)==DEFAULTS
    (tmp_path/'performance-config.json').write_text('[]')
    assert inference_settings(tmp_path)==DEFAULTS


def test_setting_roundtrip_backup_and_external_services_not_changed(tmp_path):
    app=FastAPI();game=SimpleNamespace(state_dir=tmp_path,status=lambda:{})
    install(app,game);client=TestClient(app)
    assert client.post('/termux/performance/settings',json={'text_threads':4,'text_nice':5}).status_code==200
    assert client.post('/termux/performance/settings',json={'voice_threads':1}).status_code==200
    assert (tmp_path/'performance-config-before-v034.json').is_file()
    assert client.get('/termux/performance/settings').json()['settings']['text_threads']==4
    for obj in ({'voice_threads':4},{'text_threads':True},{'text_nice':-5},{'pid':os.getpid()}):
        assert client.post('/termux/performance/settings',json=obj).status_code==400


def test_reads_real_owned_process_without_confusing_cores_and_system_memory(tmp_path):
    sampler=Sampler();now=time.monotonic();a=sampler.process(os.getpid(),'test',now)
    assert a['cpu_percent_one_core'] is None and a['rss_mb']>0
    b=sampler.process(os.getpid(),'test',now+.2)
    assert b['cpu_percent_one_core']>=0 and b['threads']>=1
    assert sampler.process(987654321,'absent',now) is None
    sys=sampler.system();assert sys['available_memory_mb']>0
    assert 'not game-only' in sys['gpu_busy_scope']


def test_missing_android_sensors_are_unknown_not_zero(tmp_path):
    sys=Sampler(proc=tmp_path,sysfs=tmp_path).system()
    assert sys['gpu_busy_percent'] is None and sys['available_memory_mb'] is None and sys['temperatures']==[]


def test_includes_child_workers_of_owned_proot(tmp_path):
    import subprocess,sys
    child_file=tmp_path/'child.pid'
    parent=subprocess.Popen([sys.executable,'-c','import subprocess,time,pathlib,sys; p=subprocess.Popen(["sleep","5"]); pathlib.Path(sys.argv[1]).write_text(str(p.pid)); time.sleep(5)',str(child_file)])
    try:
        until=time.monotonic()+3
        while not child_file.exists() and time.monotonic()<until:time.sleep(.02)
        assert child_file.exists()
        (tmp_path/'ai-services.json').write_text(json.dumps({'owned_pids':[parent.pid]}))
        game=SimpleNamespace(status=lambda:{'pid':None,'performance':{},'audio_runtime':{}})
        rows=Sampler().sample(tmp_path,game)['processes']
        assert len(rows)>=2 and any('filho' in r['label'] for r in rows)
    finally:
        if child_file.exists():
            try:os.kill(int(child_file.read_text()),15)
            except ProcessLookupError:pass
        parent.terminate();parent.wait(timeout=3)


def test_renderer_choice_is_separate_reversible_and_no_commands(tmp_path):
    from snake_termux.performance import renderer_settings
    assert renderer_settings(tmp_path)=='gl_compatibility'
    app=FastAPI();g=SimpleNamespace(state_dir=tmp_path,renderer='gl_compatibility',status=lambda:{})
    install(app,g);c=TestClient(app)
    assert c.post('/termux/game/engine',json={'renderer':'mobile'}).status_code==200
    assert c.get('/termux/game/engine').json()['active']=='gl_compatibility'
    assert renderer_settings(tmp_path)=='mobile'
    assert c.post('/termux/game/engine',json={'renderer':'gl_compatibility'}).status_code==200
    assert (tmp_path/'render-config-before-v034.json').exists()
    assert c.post('/termux/game/engine',json={'renderer':'sh -c something'}).status_code==400
    (tmp_path/'render-config.json').write_text('null');assert renderer_settings(tmp_path)=='gl_compatibility'


def test_direct_vulkan_command_is_explicit_and_gl_unchanged(tmp_path):
    from snake_termux.native import native_command
    from pathlib import Path
    mobile=native_command(Path('/godot'),Path('/pack'),[],workdir=tmp_path,renderer='mobile')
    assert mobile[mobile.index('--rendering-driver')+1]=='vulkan'
    gl=native_command(Path('/godot'),Path('/pack'),[],workdir=tmp_path)
    assert '--rendering-driver' not in gl


def test_server_recording_is_bounded_single_job_and_survives_ui_absence(tmp_path):
    from snake_termux.performance import Recorder
    game=SimpleNamespace(status=lambda:{'pid':os.getpid(),'performance':{},'audio_runtime':{}})
    recorder=Recorder(Sampler(),tmp_path,game,interval=.05,count=3)
    assert recorder.start()['running']
    thread=recorder.thread;recorder.start();assert recorder.thread is thread
    thread.join(timeout=3)
    assert not recorder.status()['running'] and len(recorder.status()['samples'])==3
    recorder.stop()


def test_gt3_helper_first_application_backs_up_config_and_later_preserves_choices(tmp_path):
    import subprocess,sys,shutil
    from pathlib import Path
    root=Path(__file__).resolve().parents[1];target=tmp_path/'adapter'
    (target/'snake_termux').mkdir(parents=True);(target/'.venv/bin').mkdir(parents=True);(target/'state').mkdir()
    (target/'.venv/bin/python').symlink_to(sys.executable)
    for name in ('start.sh','snake_termux/native.py','snake_termux/__main__.py'):(target/name).write_text('# previous\n')
    before=b'{"profile":"clear","clean_display":false}'
    (target/'state/presentation-config.json').write_bytes(before)
    (target/'state/private.json').write_text('private settings')
    cmd=[shutil.which('bash'),str(root/'SNAKE_REYERS_GT3_STUDIO_V034.sh'),str(target)]
    result=subprocess.run(cmd,capture_output=True,text=True,timeout=15)
    assert result.returncode==0,result.stdout+result.stderr
    marker=json.loads((target/'state/gt3-v034-applied.json').read_text());backup=Path(marker['settings_backup'])
    assert (backup/'presentation-config.json').read_bytes()==before
    assert not json.loads((backup/'gt3-config-presence.json').read_text())['performance-config.json']
    assert json.loads((target/'state/presentation-config.json').read_text())=={'profile':'gt3_live','clean_display':False}
    assert json.loads((target/'state/performance-config.json').read_text())['text_nice']==3
    (target/'state/presentation-config.json').write_text('{"profile":"sharp"}')
    result=subprocess.run(cmd,capture_output=True,text=True,timeout=15);assert result.returncode==0,result.stdout+result.stderr
    assert json.loads((target/'state/presentation-config.json').read_text())['profile']=='sharp'
    assert (target/'state/private.json').read_text()=='private settings'


def test_vulkan_renderer_log_is_recognized_as_observed_not_assumed(tmp_path,monkeypatch):
    from pathlib import Path
    from snake_termux import native
    monkeypatch.setattr(native,'resolve_godot',lambda _:Path('/fake'))
    monkeypatch.setattr(native,'verify_original',lambda _:{'verified':True})
    game=native.NativeGame(tmp_path,state_dir=tmp_path/'state')
    game.process=SimpleNamespace(pid=1234,poll=lambda:None)
    game.log_path.write_text('Vulkan 1.4 - Forward Mobile - Using Device #0: Qualcomm - Turnip Adreno\nProject FPS: 29\n')
    result=game.status()['performance']
    assert result['fps']==29 and 'Adreno' in result['observed_renderer'] and not result['software_renderer']
