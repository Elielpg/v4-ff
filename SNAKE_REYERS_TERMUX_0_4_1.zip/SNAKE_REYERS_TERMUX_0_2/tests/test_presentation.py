import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux import native, presentation as view


def fake_x11(monkeypatch, *, fail=False, actual='720x1280'):
    prefs = {**view.DISPLAY_KEYS, 'fullscreen': 'false', 'showAdditionalKbd': 'true',
             'displayResolutionMode': 'native', 'displayResolutionCustom': '1280x1024'}
    calls = []
    def run(command, **kwargs):
        calls.append((command, kwargs))
        if fail:
            raise subprocess.TimeoutExpired(command, kwargs['timeout'])
        if command[0] == 'xdpyinfo':
            return subprocess.CompletedProcess(command, 0, f'dimensions: {actual} pixels (100x100 millimeters)', '')
        assert command[0] == 'termux-x11-preference'
        if command[1:] == ['list']:
            text = '\n'.join(f'"{key}"="{value}"' for key, value in prefs.items())
            text += '\n"extra_keys_config"="private keyboard content"'
            return subprocess.CompletedProcess(command, 0, text, '')
        for item in command[1:]:
            key, value = item.split(':', 1)
            prefs[key] = value
        return subprocess.CompletedProcess(command, 0, '', '')
    monkeypatch.setattr(view.subprocess, 'run', run)
    return prefs, calls


def test_display_hides_controls_matches_resolution_and_preserves_first_backup(tmp_path, monkeypatch):
    prefs, calls = fake_x11(monkeypatch)
    before = dict(prefs)
    env = {'PREFIX': '/data/local/test', 'DISPLAY': ':9'}
    result = view.clean_display(tmp_path, env, '720x1280')
    assert result['applied'] and result['fullscreen']
    assert prefs['showAdditionalKbd'] == 'false' and prefs['displayStretch'] == 'false'
    backup = json.loads((tmp_path / 'x11-display-before-v025.json').read_text())
    assert backup == before and 'extra_keys_config' not in backup
    view.clean_display(tmp_path, env, '720x1280')
    assert json.loads((tmp_path / 'x11-display-before-v025.json').read_text()) == before
    assert all(item[1]['timeout'] <= 7 for item in calls)
    view.restore_display(tmp_path, env)
    assert prefs == before and view.settings(tmp_path)['clean_display'] is False


def test_absent_x11_activity_is_bounded_and_does_not_stop_game(tmp_path, monkeypatch):
    fake_x11(monkeypatch, fail=True)
    result = view.clean_display(tmp_path, {}, '720x1280')
    assert not result['applied'] and not result['fullscreen']
    assert not (tmp_path / 'x11-display-before-v025.json').exists()


def test_stale_landscape_screen_does_not_claim_fullscreen_ready(tmp_path, monkeypatch):
    fake_x11(monkeypatch, actual='1280x720')
    monkeypatch.setattr(view.time, 'sleep', lambda _: None)
    report = view.clean_display(tmp_path, {}, '720x1280')
    assert not report['applied'] and '1280x720' in report['message']


def test_profiles_only_increase_resolution_after_hardware_verification(tmp_path, monkeypatch):
    fake_x11(monkeypatch, actual='640x1136')
    view.save_settings(tmp_path, {'profile': 'light'})
    gpu = {'graphics': {'hardware_verified': True, 'resolution': '720x1280', 'max_fps': 60}}
    report = view.prepare_display(tmp_path, {'PREFIX': '/data/local/test'}, gpu)
    assert report['graphics']['resolution'] == '640x1136' and report['display']['applied']
    assert gpu['graphics']['resolution'] == '720x1280'
    view.save_settings(tmp_path, {'profile': 'sharp', 'clean_display': False})
    cpu = {'graphics': {'hardware_verified': False, 'resolution': '540x960', 'max_fps': 30}}
    report = view.prepare_display(tmp_path, {'PREFIX': '/data/local/test'}, cpu)
    assert report['graphics']['resolution'] == '536x960' and report['graphics']['max_fps'] == 30
    assert not report['display']['fullscreen']
    assert view.prepare_display(tmp_path, {}, gpu) == gpu


@pytest.mark.parametrize('payload', [{'profile': '4k'}, {'profile': []}, {'clean_display': 'true'}, {'command': 'anything'}])
def test_settings_accept_no_arbitrary_commands_or_invalid_profiles(tmp_path, payload):
    with pytest.raises(ValueError):
        view.save_settings(tmp_path, payload)
    assert not (tmp_path / 'presentation-config.json').exists()


def isolated_music(tmp_path, monkeypatch):
    from cobrinha_server.services import music_runtime
    monkeypatch.setattr(music_runtime, 'BACKGROUND_MUSIC_DIR', tmp_path / 'music')
    monkeypatch.setattr(music_runtime, 'BACKGROUND_MUSIC_PROCESSED_DIR', tmp_path / 'processed')
    monkeypatch.setattr(music_runtime, 'MUSIC_RUNTIME_FILE', tmp_path / 'music.json')
    return music_runtime


def test_empty_library_gets_verified_track_once_and_preserves_mute(tmp_path, monkeypatch):
    music = isolated_music(tmp_path, monkeypatch)
    music.MUSIC_RUNTIME_FILE.write_text('{"enabled":false,"volume":0.23}')
    before = music.MUSIC_RUNTIME_FILE.read_bytes()
    assert view.provision_music(music, tmp_path / 'state')['added']
    assert music.status()['track_count'] == 1
    assert not music.status()['enabled'] and music.status()['volume'] == .23
    assert music.MUSIC_RUNTIME_FILE.read_bytes() == before
    track = Path(music.tracks()[0])
    assert track.read_bytes()[:4] == b'OggS'
    track.unlink()
    assert not view.provision_music(music, tmp_path / 'state')['added']
    assert music.status()['track_count'] == 0  # A deliberate deletion stays deleted.


def test_existing_playlist_is_not_changed(tmp_path, monkeypatch):
    music = isolated_music(tmp_path, monkeypatch)
    music.BACKGROUND_MUSIC_DIR.mkdir()
    existing = music.BACKGROUND_MUSIC_DIR / 'my-song.mp3'
    existing.write_bytes(b'private song')
    music.update(current_track=str(existing.resolve()))
    before = music.MUSIC_RUNTIME_FILE.read_bytes()
    assert not view.provision_music(music, tmp_path / 'state')['added']
    assert music.MUSIC_RUNTIME_FILE.read_bytes() == before and existing.read_bytes() == b'private song'
    assert len(list(music.BACKGROUND_MUSIC_DIR.iterdir())) == 1


def test_bad_track_integrity_cannot_provision_music(tmp_path, monkeypatch):
    music = isolated_music(tmp_path, monkeypatch)
    monkeypatch.setattr(view, 'TRACK_SHA256', '0' * 64)
    with pytest.raises(ValueError, match='integridade'):
        view.provision_music(music, tmp_path / 'state')
    assert not music.BACKGROUND_MUSIC_DIR.exists()


def test_profiles_api_persists_only_supported_settings(adapted, tmp_path, monkeypatch):
    app, binding = adapted
    monkeypatch.setattr(native, 'resolve_godot', lambda _: Path('/placeholder'))
    monkeypatch.setattr(native, 'verify_original', lambda _: {'verified': True})
    game = native.NativeGame(tmp_path, state_dir=tmp_path / 'state')
    native.attach(binding, app, game)
    client = TestClient(app)
    assert client.get('/termux/presentation').json()['settings']['profile'] == 'balanced'
    saved = client.post('/termux/presentation', json={'profile': 'light'}).json()
    assert saved['restart_required'] and view.settings(game.state_dir)['profile'] == 'light'
    assert client.post('/termux/presentation', json={'profile': []}).status_code == 400


@pytest.mark.parametrize('repair_name', ['SNAKE_REYERS_TELA_MUSICA_V025.sh', 'SNAKE_REYERS_REPARAR_SOM_V026.sh', 'SNAKE_REYERS_RECUPERAR_IMAGEM_SOM_V027.sh', 'SNAKE_REYERS_RITMO_LIVE_V028.sh', 'SNAKE_REYERS_BIBLIOTECA_MUSICAS_V029.sh', 'SNAKE_REYERS_ESTABILIDADE_V030.sh', 'SNAKE_REYERS_IA_NUVEM_V031.sh', 'SNAKE_REYERS_LIVE_FLUIDA_V032.sh', 'SNAKE_REYERS_CONVERSA_LOCAL_V033.sh', 'SNAKE_REYERS_GT3_STUDIO_V034.sh'])
def test_new_repair_is_self_contained_and_preserves_private_files(tmp_path, repair_name):
    root = Path(__file__).resolve().parents[1]
    app = tmp_path / 'adapter'
    (app / 'snake_termux').mkdir(parents=True)
    (app / '.venv/bin').mkdir(parents=True)
    (app / '.venv/bin/python').symlink_to(sys.executable)
    for relative in ('start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py'):
        (app / relative).write_text('# old adapter\n')
    (app / 'state').mkdir()
    (app / 'state/private.json').write_text('keep private')
    (app / 'state/device-config.json').write_text('{"enabled":true}')
    result = subprocess.run([shutil.which('bash'), str(root / repair_name), '--files-only', str(app)], capture_output=True, text=True, timeout=15)
    assert result.returncode == 0, result.stdout + result.stderr
    for relative in ('snake_termux/native.py', 'snake_termux/presentation.py', 'snake_termux/audio_service.py', 'snake_termux/integration.py', 'snake_termux/live_tuning.py', 'snake_termux/music_library.py', 'snake_termux/piper_worker.py', 'snake_termux/cloud_ai.py', 'snake_termux/cloud_settings.py', 'snake_termux/cloud_ui.js', 'snake_termux/live_load.py', 'snake_termux/speech_names.py', 'snake_termux/director.py', 'snake_termux/director.html', 'snake_termux/voice.py', 'snake_termux/reuse_ai.py', 'snake_termux/ui.js', 'assets/music/Neon Garden.ogg'):
        assert (app / relative).read_bytes() == (root / relative).read_bytes()
    assert (app / 'state/private.json').read_text() == 'keep private'
    assert (app / 'snake_termux/local_social.py').read_bytes() == (root / 'snake_termux/local_social.py').read_bytes()
    assert (app / 'snake_termux/client.py').read_bytes() == (root / 'snake_termux/client.py').read_bytes()
    assert json.loads((app / 'state/device-config.json').read_text()) == {'enabled': True}
    backup = next((app / 'state/launcher-backups').iterdir())
    assert (backup / 'snake_termux/native.py').read_text() == '# old adapter\n'
