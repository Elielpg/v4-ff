import json
from fastapi.testclient import TestClient
from cobrinha_server.services import tts_service
from snake_termux.voice import PiperClient
from snake_termux.piper_worker import PROFILES


def test_piper_profile_affects_request_without_changing_voice_provider(adapted,local_service):
    app,binding=adapted;client=TestClient(app)
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,{'voice_local_port':local_service['port'],'openai_api_key':'keep-private'})
    assert client.post('/termux/local-speech',json={'profile':'natural'}).status_code==200
    result=tts_service.synthesize_for_job('Rosa, relógio, carro e clarão. Que pergunta boa!')
    sent=[r for r in local_service['calls'] if r['path']=='/synthesize']
    assert len(sent)==1 and sent[0]['data']['profile']=='natural'
    assert sent[0]['data']['text']=='Rosa, relógio, carro e clarão. Que pergunta boa!'
    assert result['voice_provider']=='piper-local'
    assert binding.settings._raw()['openai_api_key']=='keep-private'
    assert client.post('/termux/local-speech',json={'profile':'cloned'}).status_code==400


def test_full_balanced_answer_is_one_synthesis_and_timeline(adapted,local_service):
    app,binding=adapted
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,{'voice_local_port':local_service['port']})
    text='A ciência explica esse fenômeno pela dispersão da luz na atmosfera. '+('Essa é uma explicação simples e direta para a pergunta. '*2)
    assert 150<len(text)<240
    result=tts_service.synthesize_for_job(text)
    assert result['chunks']==[text.strip()]
    assert len([r for r in local_service['calls'] if r['path']=='/synthesize'])==1
    assert result['timeline']['speech_end']>0


def test_clear_profile_uses_model_defaults_with_a_slower_pace():
    assert PROFILES['clear']['length_scale']>PROFILES['natural']['length_scale']>PROFILES['legacy']['length_scale']
    assert PROFILES['clear']['noise_scale']==.5
    assert PROFILES['legacy']['noise_scale']==.4


def test_profile_setting_does_not_enable_or_call_openai(adapted):
    app,binding=adapted
    before=binding.settings._raw()
    assert TestClient(app).post('/termux/local-speech',json={'profile':'clear'}).status_code==200
    raw=binding.settings._raw()
    assert raw.get('termux_cloud_voice_enabled')==before.get('termux_cloud_voice_enabled')
    assert binding.cloud_api.diagnostics['speech']['requests']==0
