import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from snake_termux import native,scene_graphics as scene


def test_original_launch_is_default_and_custom_scripts_or_editor_are_preserved(tmp_path):
    env={'DISPLAY':':1','PULSE_SINK':'original-sink'}
    args=['--resolution','720x1280','--','--cobrinha-live']
    assert scene.launch(env,args,tmp_path)==(env,args)
    scene.save(tmp_path,{'enabled':True})
    for explicit in (['--script','/custom.gd','--','--cobrinha-live'],['-s','/custom.gd','--','--cobrinha-preview'],['--','--cobrinha-terrain-editor']):
        assert scene.launch(env,explicit,tmp_path)==(env,explicit)


def test_enabled_layer_keeps_mode_audio_and_uses_own_script_without_unpacking(tmp_path):
    scene.save(tmp_path,{'enabled':True,'preset':'balanced'})
    stale=tmp_path/'scene-graphics-runtime.json';stale.write_text('{"pid":1}')
    env,args=scene.launch({'PULSE_SINK':'capture-sink'},['--max-fps','24','--','--cobrinha-live'],tmp_path)
    assert env['PULSE_SINK']=='capture-sink' and args[-2:]==['--','--cobrinha-live']
    assert args[:2]==['--script',str(scene.SCRIPT)] and args[args.index('--max-fps')+1]=='24'
    assert not stale.exists()
    config=json.loads(Path(env['SNAKE_SCENE_GRAPHICS_CONFIG']).read_text())
    assert config['scale']==.92
    assert set(tmp_path.iterdir())=={tmp_path/'scene-graphics-config.json',tmp_path/'scene-graphics-launch.json'}


def test_missing_optional_layer_does_not_prevent_original_game_from_opening(tmp_path,monkeypatch):
    scene.save(tmp_path,{'enabled':True})
    monkeypatch.setattr(scene,'SCRIPT',tmp_path/'absent.gd')
    args=['--','--cobrinha-live'];env={'PULSE_SINK':'saved'}
    assert scene.launch(env,args,tmp_path)==(env,args)
    assert 'original' in scene.status(tmp_path)['warning']


@pytest.mark.parametrize('payload',[{}, {'preset':'ultra;anything'}, {'preset':[]}, {'enabled':'yes'}, {'terrain_colors':1}, {'script':'/custom.gd'}])
def test_settings_validate_without_overwriting_previous_configuration(tmp_path,payload):
    scene.save(tmp_path,{'enabled':True,'preset':'fluid'})
    before=(tmp_path/'scene-graphics-config.json').read_bytes()
    with pytest.raises(ValueError):scene.save(tmp_path,payload)
    assert (tmp_path/'scene-graphics-config.json').read_bytes()==before


def test_budget_limits_unbounded_frame_work_without_changing_window_size(tmp_path):
    device={'graphics':{'max_fps':60,'resolution':'864x1536'},'audio':{'sink':'saved'}}
    assert native.scene_budget(tmp_path,device)==device
    scene.save(tmp_path,{'enabled':True})
    budget=native.scene_budget(tmp_path,device)
    assert budget['graphics']['max_fps']==30 and budget['graphics']['resolution']=='864x1536'
    assert budget['audio']==device['audio'] and device['graphics']['max_fps']==60
    assert native.scene_budget(tmp_path,{'graphics':{'max_fps':24}})['graphics']['max_fps']==24


def test_api_switch_off_is_reversible_and_does_not_touch_voice_or_user_files(tmp_path):
    private=tmp_path/'voice.json';private.write_text('{"voice":"keep-me"}')
    app=FastAPI();scene.install(app,SimpleNamespace(state_dir=tmp_path));client=TestClient(app)
    assert not client.get('/termux/scene-graphics').json()['settings']['enabled']
    assert client.post('/termux/scene-graphics',json={'enabled':True,'decorations':False}).json()['restart_required']
    assert client.post('/termux/scene-graphics',json={'preset':'bad'}).status_code==400
    saved=client.post('/termux/scene-graphics',json={'enabled':False}).json()['settings']
    assert not saved['enabled'] and not saved['decorations']
    assert private.read_text()=='{"voice":"keep-me"}'


def test_new_x11_filter_restores_even_if_old_display_backup_predates_it(tmp_path,monkeypatch):
    from test_presentation import fake_x11
    from snake_termux import presentation
    preferences,calls=fake_x11(monkeypatch)
    preferences['displayFilteringMode']='nearest'
    old={k:v for k,v in preferences.items() if k!='displayFilteringMode'}
    (tmp_path/'x11-display-before-v025.json').write_text(json.dumps(old))
    assert presentation.clean_display(tmp_path,{'DISPLAY':':1'},'720x1280')['applied']
    assert preferences['displayFilteringMode']=='bilinear'
    presentation.restore_display(tmp_path,{'DISPLAY':':1'})
    assert preferences['displayFilteringMode']=='nearest'


def test_graphics_repair_enables_once_preserves_choices_and_reverts_new_settings(tmp_path):
    import subprocess
    import sys
    root=Path(__file__).resolve().parents[1]
    target=tmp_path/'adapter';(target/'snake_termux').mkdir(parents=True)
    for relative in ('start.sh','snake_termux/native.py','snake_termux/__main__.py'):
        (target/relative).write_text('# previous adapter file\n')
    helper=root/'SNAKE_REYERS_GRAFICOS_GT3_V036.sh'
    first=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert first.returncode==0,first.stdout+first.stderr
    assert scene.settings(target/'state')['enabled']
    backup=next((target/'state/launcher-backups').glob('*/REVERTER.py'))
    scene.save(target/'state',{'enabled':False,'decorations':False})
    repeated=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert repeated.returncode==0,repeated.stdout+repeated.stderr
    assert not scene.settings(target/'state')['enabled'] and not scene.settings(target/'state')['decorations']
    restored=subprocess.run([sys.executable,str(backup)],capture_output=True,text=True,timeout=5)
    assert restored.returncode==0,restored.stdout+restored.stderr
    assert not (target/'state/scene-graphics-config.json').exists()
    assert not (target/'state/scene-graphics-v036-applied.json').exists()
    assert (target/'snake_termux/native.py').read_text()=='# previous adapter file\n'
