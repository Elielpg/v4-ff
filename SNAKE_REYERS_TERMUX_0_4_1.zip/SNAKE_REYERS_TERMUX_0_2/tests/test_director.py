import asyncio
import json
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux.director import viewer_count, Audience
from snake_termux import native


@pytest.mark.parametrize('raw,result', [({'viewerCount': 25, 'totalUser': 5000}, 25), ('{"viewerCount":0}', 0), ({'data': {'viewerCount': '12'}}, 12), ({'totalUser': 5000}, None), ({'viewerCount': True}, None), ({'viewerCount': -1}, None)])
def test_only_concurrent_viewer_field_is_used(raw, result):
    assert viewer_count(raw) == result


def test_audience_unknown_stale_and_room_change_are_explicit():
    a = Audience(); assert a.status('live', True)['count'] is None
    a.update({'viewerCount': 17}, 'live')
    assert a.status('live', True)['count'] == 17
    assert a.status('other', True)['count'] is None
    assert a.status('live', False)['stale']
    a.at = time.time() - 40
    assert a.status('live', True)['stale']


def test_existing_monitor_events_feed_operator_panel_only(adapted, monkeypatch):
    from cobrinha_server.services import tiktok_monitor
    app, binding = adapted
    class Client:
        def __init__(self): self.handlers = {}
        def event(self, callback): self.handlers[callback.__name__] = callback; return callback
        def on(self, event, handler=None, **kwargs):
            if handler: self.handlers[event] = handler; return handler
            def install(callback): self.handlers[event] = callback; return callback
            return install
    client = Client(); tiktok_monitor._register_handlers(client, 'test.live')
    assert 'data-chat' in client.handlers and 'data-gift' in client.handlers
    client.handlers['data-viewer']('{"viewerCount":42,"totalUser":800}')
    monkeypatch.setattr(tiktok_monitor, 'status', lambda: {'username': 'test.live', 'connected': True, 'listening': True})
    result = TestClient(app).get('/termux/director/status').json()
    assert result['audience']['count'] == 42 and not result['audience']['sent_to_game']
    assert not result['broadcast']['started_by_this_panel']
    assert 'tela inteira' in result['capture_note']
    assert TestClient(app).get('/termux/director').status_code == 200


def test_fps_comes_from_current_log_tail_and_renderer_is_observed(tmp_path, monkeypatch):
    monkeypatch.setattr(native, 'resolve_godot', lambda _: Path('/fake'))
    monkeypatch.setattr(native, 'verify_original', lambda _: {'verified': True})
    game = native.NativeGame(tmp_path, state_dir=tmp_path / 'state')
    class Process:
        pid = 1234
        def poll(self): return None
    game.process = Process()
    game.log_path.write_text('Using Device: Mesa - zink Vulkan Turnip Adreno 725\nProject FPS: 60\n' + ('x' * 40000) + '\nProject FPS: 42 (23 mspf)\n')
    report = game.status()['performance']
    assert report['fps'] == 42 and 'Adreno' in report['observed_renderer'] and not report['software_renderer']
    game.log_path.write_text('Using Device: Mesa - llvmpipe\nProject FPS: 12\n')
    assert game.status()['performance']['software_renderer']
