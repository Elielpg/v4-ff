import os
import time
from types import SimpleNamespace
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from snake_termux.studio_audio import install


def client_for(game):
    app=FastAPI();install(app,game);return TestClient(app)


def test_no_audio_source_does_not_close_game_or_guess_shared_sink():
    c=client_for(SimpleNamespace(status=lambda:{'running':True},audio_env={},audio_driver='Dummy'))
    assert c.post('/termux/studio/audio/authorize').status_code==409
    assert c.get('/termux/studio/audio/pcm').status_code==401
    assert c.get('/termux/studio/audio/status').json()['active'] is False


def test_cross_origin_audio_capture_is_rejected():
    c=client_for(SimpleNamespace(status=lambda:{'running':True},audio_env={},audio_driver='Dummy'))
    assert c.post('/termux/studio/audio/authorize',headers={'Origin':'https://other.example'}).status_code==403
    assert c.get('/termux/studio/audio/pcm',headers={'Origin':'https://other.example'}).status_code==403


def test_local_token_is_header_only_one_use_and_bounded(tmp_path,monkeypatch):
    from snake_termux import studio_audio
    monkeypatch.setattr(studio_audio.shutil,'which',lambda name,**kw:'/fake/'+name)
    g=SimpleNamespace(status=lambda:{'running':True},audio_env={'PULSE_SERVER':'unix:/private','PULSE_SINK':'owned'},audio_driver='PulseAudio')
    c=client_for(g)
    tokens=[c.post('/termux/studio/audio/authorize').json()['token'] for _ in range(4)]
    assert all(len(t)==64 for t in tokens)
    assert c.post('/termux/studio/audio/authorize').status_code==429
    assert c.get('/termux/studio/audio/pcm?token='+tokens[0]).status_code==401
    monkeypatch.setattr(studio_audio.subprocess,'Popen',lambda *a,**k:(_ for _ in ()).throw(OSError('fake unavailable')))
    with pytest.raises(OSError):c.get('/termux/studio/audio/pcm',headers={'Authorization':'Bearer '+tokens[0]})
    assert not c.get('/termux/studio/audio/status').json()['active']
    assert c.get('/termux/studio/audio/pcm',headers={'Authorization':'Bearer '+tokens[0]}).status_code==401


def test_token_expiration_does_not_spawn_process(tmp_path,monkeypatch):
    from snake_termux import studio_audio
    monkeypatch.setattr(studio_audio.shutil,'which',lambda name,**kw:'/fake/'+name)
    g=SimpleNamespace(status=lambda:{'running':True},audio_env={'PULSE_SERVER':'unix:/private','PULSE_SINK':'owned'},audio_driver='PulseAudio')
    c=client_for(g);token=c.post('/termux/studio/audio/authorize').json()['token']
    before=time.monotonic();monkeypatch.setattr(studio_audio.time,'monotonic',lambda:before+31)
    assert c.get('/termux/studio/audio/pcm',headers={'Authorization':'Bearer '+token}).status_code==401
