import asyncio
import json
import time
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient

from snake_termux.live_queue import LiveQueue


def event(i, kind='gift', **metadata):
    return {'id': str(i), 'kind': kind, 'priority': 70 + int(i) % 100,
            'username': f'user{i}', 'display_name': f'Pessoa {i}',
            'text': f'Pergunta {i}?' if kind == 'comment' else 'Rosa',
            'created_at': time.time() - 10000, 'metadata': {'count': 1, 'gift_name': 'Rosa', **metadata}}


def test_gifts_do_not_expire_or_get_capped_and_survive_restart_in_arrival_order(tmp_path):
    path = tmp_path / 'journal.db'; q = LiveQueue(path)
    for i in range(150): assert q.ingest(event(i))
    q.close(); q = LiveQueue(path)
    assert q.status()['gifts_waiting'] == 150
    for i in range(150):
        e = q.claim(); assert e['id'] == str(i)
        assert q.claim() is None  # A later gift cannot overtake this receipt.
        q.attach(e['id'], f'job{i}'); q.finish(f'job{i}')
    assert q.status()['gifts_waiting'] == 0
    assert q.status()['counts']['gifts_finished'] == 150
    q.close()


def test_concurrent_comments_admit_only_three_and_rejected_messages_never_reappear(tmp_path):
    q = LiveQueue(tmp_path / 'journal.db')
    with ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(lambda i: (i, q.ingest(event(i, 'comment'))), range(60)))
    admitted = {str(i) for i, accepted in results if accepted}
    assert len(admitted) == 3 and q.status()['comments_waiting'] == 3
    assert q.status()['counts']['comments_rejected_full'] == 57
    first = q.claim(); q.attach(first['id'], 'playing'); q.update_job('playing', 'playing')
    assert q.ingest(event(100, 'comment'))
    assert q.status()['comments_waiting'] == 3
    q.finish('playing')
    remaining = []
    while e := q.claim():
        remaining.append(e['id']); q.attach(e['id'], e['id']); q.finish(e['id'])
    assert set(remaining) == (admitted - {first['id']}) | {'100'}
    q.close()


def test_gifts_take_precedence_over_old_comments_and_keep_low_value_first(tmp_path):
    q = LiveQueue(tmp_path / 'journal.db')
    q.ingest(event(1, 'comment')); q.ingest(event(2, priority=1)); q.ingest(event(3, priority=999))
    assert q.claim()['id'] == '2'
    q.attach('2', 'a'); q.finish('a'); assert q.claim()['id'] == '3'
    q.attach('3', 'b'); q.finish('b'); assert q.claim()['kind'] == 'comment'
    q.close()


def test_failure_retries_are_limited_and_receipt_remains_until_success(tmp_path):
    q = LiveQueue(tmp_path / 'journal.db'); q.ingest(event(1))
    for i in range(3):
        e = q.claim(); assert e['id'] == '1'
        if not i: q.effects_started('1')
        else: assert e['_queue_effects_started']
        q.failed('1', 'voice_unavailable')
        with q.lock, q.db: q.db.execute('UPDATE events SET retry_at=0')
    assert q.status()['gift_head']['status'] == 'blocked'
    assert q.claim() is None and q.status()['gifts_waiting'] == 1
    assert q.retry_gift(); assert q.claim()['_queue_effects_started']
    q.attach('1', 'fixed'); q.finish('fixed'); assert not q.status()['gifts_waiting']
    q.close()


def test_duplicate_upstream_receipts_are_not_rethanked_after_reset(tmp_path):
    q = LiveQueue(tmp_path / 'journal.db')
    assert q.ingest(event(1, upstream_event_id='upstream-123'))
    q.reset_transient()
    assert not q.ingest(event(2, upstream_event_id='upstream-123'))
    assert q.status()['gifts_waiting'] == 1
    q.close()


def test_welcomes_are_batched_with_bounded_names_and_no_spam_from_reentries(tmp_path):
    q = LiveQueue(tmp_path / 'journal.db')
    for i in range(200): assert q.member({'username': f'user{i}', 'display_name': f'Pessoa {i}'})
    assert not q.member({'username': 'user0'})
    assert q.status()['welcome_batches'] == 1
    with q.lock, q.db:
        row = q.db.execute("SELECT payload FROM events WHERE kind='welcome'").fetchone()
        payload = json.loads(row[0]); payload['created_at'] = time.time()-3
        q.db.execute('UPDATE events SET payload=?', (json.dumps(payload),))
    e = q.claim(); assert len(e['users']) == 3 and e['count'] == 200
    assert q.status()['counts']['visitors_received'] == 200
    q.close()


@pytest.fixture
def policy(adapted, tmp_path, monkeypatch):
    from test_live_load import isolate
    app, binding = adapted
    sq, events, worker = isolate(tmp_path, monkeypatch)
    raw = binding.settings._raw(); raw['termux_live_policy'] = True
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
    store = app.state.snake_live_queue()
    class Socket:
        async def send_json(self, value): pass
    monkeypatch.setattr(worker.godot_bridge, '_socket', Socket())
    monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: False)
    monkeypatch.setattr(worker.godot_runtime_state, 'heart_me_band_music_showcase_active', lambda: False)
    monkeypatch.setattr(worker, 'tts_worker_status', lambda: {'state': 'idle'})
    async def no_activity(*a, **kw): return ''
    monkeypatch.setattr(worker, '_send_spectator_activity', no_activity)
    monkeypatch.setattr(worker, '_flush_top_supporters_update', no_activity)
    yield app, binding, store, sq, events, worker
    store.close()


def test_actual_monitor_admission_full_rejection_allows_same_text_after_slot_opens(policy):
    app, binding, store, sq, events, worker = policy
    for name in ('ana', 'bia', 'carla'):
        assert not events.push_comment({'username': name, 'comment': 'Oi, tudo bem?' }).get('ignored')
    rejected = events.push_comment({'username': 'duda', 'comment': 'Oi, tudo bem?'})
    assert rejected['ignored'] and rejected['reason'] == 'comment_queue_full'
    first = store.claim(); store.attach(first['id'], 'first'); store.finish('first')
    assert not events.push_comment({'username': 'duda', 'comment': 'Oi, tudo bem?'}).get('ignored')
    assert events.status()['comments_pending'] == 3
    assert TestClient(app).get('/termux/live-policy').json()['queue']['comments_waiting'] == 3


def test_actual_gift_worker_keeps_effects_and_thanks_every_received_gift_without_ai(policy, monkeypatch):
    app, binding, store, sq, events, worker = policy
    messages = []
    async def send(message): messages.append(message); return True
    monkeypatch.setattr(worker.godot_bridge, 'send', send)
    monkeypatch.setattr(worker.content_updates, 'reaction_for_gift_name', lambda _: None)
    monkeypatch.setattr(worker.song_runtime, 'song_trigger_for_gift_event', lambda _: {})
    monkeypatch.setattr(binding, 'transport', lambda *_: pytest.fail('Gift thanks should not call the LLM'))
    receipts = [events.push_gift({'username': name, 'gift_name': 'Rosa', 'event_id': f'gift-{name}'}) for name in ('ana', 'bia', 'carla')]
    assert store.status()['gifts_waiting'] == 3
    for receipt in receipts:
        result = asyncio.run(worker.process_once())
        assert result['ok'] and result['thanked']
        job = sq.pop_pending()
        assert job['metadata']['_termux_live_event'] == receipt['id']
        assert job['priority'] == 200
        assert receipt['username'].capitalize() in job['text']
        sq.push_ready({**job, 'timeline': {'timeline_end': 1}})
        active = sq.pop_next(); assert active['id'] == job['id']
        assert sq.acknowledge_speech_finished(active['id'])['acknowledged']
    assert store.status()['gifts_waiting'] == 0
    assert len([m for m in messages if m.get('type') == 'gift_apples']) == 3


def test_welcome_socket_is_added_without_replacing_chat_gift_or_viewer_handlers(policy):
    from cobrinha_server.services import tiktok_monitor
    app, binding, store, *_ = policy
    class Client:
        def __init__(self): self.handlers = {}
        def event(self, callback): self.handlers[callback.__name__] = callback; return callback
        def on(self, event, handler=None, **kwargs):
            if handler: self.handlers[event] = handler; return handler
            def register(callback): self.handlers[event] = callback; return callback
            return register
    client = Client(); tiktok_monitor._register_handlers(client, 'test.live')
    assert all(name in client.handlers for name in ('data-chat', 'data-gift', 'data-viewer', 'data-member'))
    client.handlers['data-member']({'uniqueId': 'ana', 'nickname': 'Ana', 'userId': '1'})
    assert store.status()['welcome_batches'] == 1
    assert TestClient(app).post('/termux/live-policy', json={'welcome_enabled': False}).status_code == 200
    client.handlers['data-member']({'uniqueId': 'bia', 'nickname': 'Bia', 'userId': '2'})
    assert store.status()['counts']['visitors_received'] == 1


def test_tts_failure_and_queue_reset_do_not_lose_gift_or_repeat_effects(policy):
    app, binding, store, sq, events, worker = policy
    receipt = events.push_gift({'username': 'ana', 'gift_name': 'Rosa', 'event_id': 'gift-ana'})
    e = store.claim(); store.effects_started(e['id']); store.attach(e['id'], 'broken')
    sq.push_ready({'id': 'broken', 'prepare_error': 'missing_voice', 'metadata': {'_termux_live_kind': 'gift'}})
    assert sq.status()['ready_size'] == 0
    assert store.status()['gifts_waiting'] == 1
    assert store.status()['gift_head']['status'] == 'retry'
    events.reset()
    assert store.status()['gifts_waiting'] == 1
    replay = store.claim(); assert replay['_queue_effects_started']
    assert replay['id'] == receipt['id']


def test_new_gift_passes_already_prepared_comment_without_interrupting_playback(policy, monkeypatch):
    app, binding, store, sq, events, worker = policy
    first = events.push_comment({'username': 'carla', 'comment': 'Qual seu nome?'})
    store.claim(); store.attach(first['id'], 'comment-ready')
    sq.push_ready({'id': 'comment-ready', 'text': 'Carla, sou a cobra!', 'priority': 70,
                  'created_at': time.time(), 'metadata': {'_termux_live_kind': 'comment'}})
    receipt = events.push_gift({'username': 'ana', 'gift_name': 'Rosa', 'event_id': 'gift-ana'})
    assert sq.pop_next() is None
    monkeypatch.setattr(worker.content_updates, 'reaction_for_gift_name', lambda _: None)
    monkeypatch.setattr(worker.song_runtime, 'song_trigger_for_gift_event', lambda _: {})
    result = asyncio.run(worker.process_once()); assert result['thanked']
    job = sq.pop_pending(); assert job['metadata']['_termux_live_event'] == receipt['id']
    sq.push_ready({**job, 'timeline': {'timeline_end': 1}})
    assert sq.pop_next()['id'] == job['id']
    sq.acknowledge_speech_finished(job['id'])
    assert sq.pop_next()['id'] == 'comment-ready'


def test_new_gift_does_not_steal_camera_during_previous_speech(adapted, tmp_path, monkeypatch):
    from test_live_load import isolate
    app, binding = adapted
    sq, events, worker = isolate(tmp_path, monkeypatch)
    raw = binding.settings._raw(); raw['termux_live_policy'] = True
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
    sent = []
    class Socket:
        async def send_json(self, value): sent.append(value)
    monkeypatch.setattr(worker.godot_bridge, '_socket', Socket())
    monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: False)
    monkeypatch.setattr(worker.godot_runtime_state, 'heart_me_band_music_showcase_active', lambda: False)
    monkeypatch.setattr(worker, 'tts_worker_status', lambda: {'state': 'idle'})
    monkeypatch.setattr(worker.content_updates, 'reaction_for_gift_name', lambda _: None)
    monkeypatch.setattr(worker.song_runtime, 'song_trigger_for_gift_event', lambda _: {})
    async def cache(_): return '/avatar.png'
    monkeypatch.setattr(worker, '_cache_avatar_for_event', cache)
    sq.write_json_atomic(sq.ACTIVE_SPEECH_FILE, {'id': 'playing', 'activated_at': time.time(), 'timeline': {'timeline_end': 10}})
    events.push_gift({'username': 'ana', 'gift_name': 'Rosa', 'event_id': 'gift-ana'})
    asyncio.run(worker.process_once())
    assert not [m for m in sent if m['type'] == 'spectator_user_selected']
    job = sq.status()['next_pending']
    assert '_termux_deferred_spectator' in job['metadata']
    app.state.snake_live_queue().close()


def test_generated_updater_applies_preferences_and_reverts_on_a_copy(tmp_path):
    import subprocess
    import sys
    import shutil
    from pathlib import Path
    from conftest import ROOT
    root = Path(__file__).resolve().parents[1]
    target = tmp_path / 'adapter'; (target / 'snake_termux').mkdir(parents=True)
    for relative in ('start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py'):
        (target / relative).write_text('# previous own adapter\n')
    original = tmp_path / 'original'
    shutil.copytree(ROOT / 'server/src', original / 'server/src', ignore=shutil.ignore_patterns('__pycache__'))
    (original / 'VERSION').write_text('0.1.9\n')
    (target / 'state').mkdir(); (target / 'state/project-path.txt').write_text(str(original))
    private = original / 'server/private/social_text_ai.json'; private.parent.mkdir(parents=True)
    private.write_text('{"voice_provider":"keep-me","local_port":18081,"openai_api_key":"private-test"}')
    helper = root / 'SNAKE_REYERS_ORIGINAL_FILAS_V040.sh'
    result = subprocess.run(['bash', str(helper), str(target)], capture_output=True, text=True, timeout=25)
    assert result.returncode == 0, result.stdout + result.stderr
    selected = json.loads(private.read_text())
    assert selected['termux_live_policy'] and selected['voice_provider'] == 'keep-me'
    assert not json.loads((target / 'state/phonk-config.json').read_text())['enabled']
    backup = next((target / 'state/launcher-backups').glob('*/REVERTER.py'))
    result = subprocess.run([sys.executable, str(backup)], capture_output=True, text=True, timeout=6)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (target / 'snake_termux/native.py').read_text() == '# previous own adapter\n'
    assert 'termux_live_policy' not in json.loads(private.read_text())


def test_immediate_tts_failure_before_enqueue_returns_does_not_mark_gift_delivered(policy, monkeypatch):
    app, binding, store, sq, events, worker = policy
    monkeypatch.setattr(worker.content_updates, 'reaction_for_gift_name', lambda _: None)
    monkeypatch.setattr(worker.song_runtime, 'song_trigger_for_gift_event', lambda _: {})
    original_write = sq.write_json_atomic
    def write(path, value):
        original_write(path, value)
        if path == sq.PENDING_QUEUE_FILE and value:
            job = value[-1]
            if (job.get('metadata') or {}).get('_termux_live_event'):
                original_write(path, [])
                sq.push_ready({**job, 'prepare_error': 'immediate_voice_failure'})
    monkeypatch.setattr(sq, 'write_json_atomic', write)
    events.push_gift({'username': 'ana', 'gift_name': 'Rosa', 'event_id': 'instant-failure'})
    asyncio.run(worker.process_once())
    assert store.status()['gift_head']['status'] == 'retry'
    assert store.status()['gifts_waiting'] == 1
    assert sq.status()['ready_size'] == 0
    assert not store.status()['counts'].get('gifts_finished')


def test_original_visual_keeps_stability_without_attaching_phonk_runtime(tmp_path):
    from snake_termux import scene_graphics, phonk
    phonk.save(tmp_path, {'enabled': False})
    scene_graphics.save(tmp_path, {'enabled': True, 'stable_render': True, 'welcome_garden': True})
    env, args = scene_graphics.launch({}, ['--', '--cobrinha-live'], tmp_path)
    assert args[:2] == ['--script', str(scene_graphics.SCRIPT)]
    assert 'SNAKE_PHONK_CONFIG' not in env
    config = json.loads(open(env['SNAKE_SCENE_GRAPHICS_CONFIG']).read())
    assert config['stable_render'] and not config['adaptive_resolution']
    assert config['welcome_garden'] and config['msaa'] == 0


def test_one_time_migration_restores_original_visual_and_reverts_only_owned_preferences(tmp_path, monkeypatch):
    import subprocess
    import sys
    import shutil
    from pathlib import Path
    from snake_termux.original_update import apply
    from snake_termux import phonk, scene_graphics
    from cobrinha_server.services import user_ai_settings
    from snake_termux import __main__
    adapter = tmp_path / 'adapter'; (adapter / 'state').mkdir(parents=True)
    (adapter / 'tools').mkdir()
    (adapter / 'state/project-path.txt').write_text(str(tmp_path / 'original'))
    shutil.copy2(Path(__file__).resolve().parents[1] / 'tools/restore_adapter.py', adapter / 'tools/restore_adapter.py')
    private = tmp_path / 'original/private/ai.json'; private.parent.mkdir(parents=True)
    raw = {'provider': 'local', 'voice_provider': 'piper-local', 'openai_api_key': 'keep-private', 'local_port': 18081}
    private.write_text(json.dumps(raw))
    monkeypatch.setattr(__main__, 'configure_source', lambda _: None)
    monkeypatch.setattr(user_ai_settings, 'SOCIAL_TEXT_AI_CONFIG_FILE', private)
    phonk.save(adapter / 'state', {'enabled': True})
    result = apply(adapter)
    assert result['applied'] and not phonk.settings(adapter / 'state')['enabled']
    assert scene_graphics.settings(adapter / 'state')['welcome_garden']
    selected = json.loads(private.read_text())
    assert selected['termux_live_policy'] and all(selected[k] == v for k, v in raw.items())
    assert 'keep-private' not in (Path(result['backup']) / 'restore-manifest.json').read_text()
    selected['voice_provider'] = 'new-choice'; private.write_text(json.dumps(selected))
    assert not apply(adapter)['applied']
    reverted = subprocess.run([sys.executable, str(Path(result['backup']) / 'REVERTER.py')], capture_output=True, text=True)
    assert reverted.returncode == 0, reverted.stdout + reverted.stderr
    restored = json.loads(private.read_text())
    assert 'termux_live_policy' not in restored and restored['voice_provider'] == 'new-choice'
    assert restored['openai_api_key'] == 'keep-private'
    assert phonk.settings(adapter / 'state')['enabled']
