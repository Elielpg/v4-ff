from pathlib import Path
import os
import sys
import pytest
from snake_termux import native,presentation


def test_wrapper_applies_selected_cap_without_touching_display_or_source(tmp_path):
    presentation.save_settings(tmp_path,{'profile':'gt3_live'})
    source={'graphics':{'hardware_verified':True,'max_fps':60,'resolution':'720x1280'},'audio':{'server':'private'}}
    result=native.apply_wrapper_frame_limit({'PREFIX':'/data/local/test'},tmp_path,source)
    assert result['graphics']['max_fps']==30 and source['graphics']['max_fps']==60
    assert result['graphics']['resolution']=='720x1280' and result['audio']==source['audio']
    assert not (tmp_path/'x11-display-before-v025.json').exists()


def test_wrapper_keeps_cpu_fallback_and_host_behavior(tmp_path):
    presentation.save_settings(tmp_path,{'profile':'clear'})
    cpu={'graphics':{'hardware_verified':False,'max_fps':30}}
    assert native.apply_wrapper_frame_limit({'PREFIX':'/data/local/test'},tmp_path,cpu) is cpu
    gpu={'graphics':{'hardware_verified':True,'max_fps':60}}
    assert native.apply_wrapper_frame_limit({},tmp_path,gpu) is gpu


@pytest.mark.parametrize('explicit',[False,True])
def test_actual_wrapper_exec_receives_profile_cap_and_keeps_capture_arguments(tmp_path,monkeypatch,explicit):
    class Game:
        state_dir=tmp_path;godot=Path('/godot');pack=Path('/game.exe');renderer='mobile'
    presentation.save_settings(tmp_path,{'profile':'gt3_live'})
    monkeypatch.setattr(native,'NativeGame',lambda *a,**k:Game())
    monkeypatch.setattr(native,'prepare_device',lambda env,state:({**env,'PREFIX':'/data/local/test'},{'graphics':{'hardware_verified':True,'max_fps':60},'audio':{'output_available':True}}))
    monkeypatch.setattr(native,'finalize_device_audio',lambda env,state,device:(env,device))
    seen={}
    monkeypatch.setattr(os,'execvpe',lambda program,args,env:seen.update(program=program,args=args,env=env))
    args=['native','--project',str(tmp_path),'--godot','/godot','--workdir',str(tmp_path),'--','--resolution','540x960']
    if explicit:args+=['--max-fps','24']
    args+=['--','--cobrinha-preview']
    monkeypatch.setattr(sys,'argv',args);native.main();command=seen['args']
    assert command[command.index('--max-fps')+1]==('24' if explicit else '30')
    assert command[command.index('--resolution')+1]=='540x960'
    assert command[-2:]==['--','--cobrinha-preview']
    assert command[command.index('--rendering-driver')+1]=='vulkan'
