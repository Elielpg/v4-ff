import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from snake_termux import device_runtime as device, scene_graphics as scene
from snake_termux.render_update import apply


def icd(root):
    p=root/'share/vulkan/icd.d/freedreno_icd.aarch64.json';p.parent.mkdir(parents=True)
    p.write_text('{"ICD":{"library_path":"libvulkan_freedreno.so"}}')
    return p


def test_direct_vulkan_probes_the_actual_device_and_removes_gl_translation(tmp_path,monkeypatch):
    driver=icd(tmp_path);calls=[]
    def probe(command,**kw):
        calls.append((command,kw))
        return subprocess.CompletedProcess(command,0,'GPU0:\n deviceName = Turnip Adreno (TM) 730\n','')
    monkeypatch.setattr(device,'run',probe)
    base={'GALLIUM_DRIVER':'zink','MESA_LOADER_DRIVER_OVERRIDE':'zink','LIBGL_ALWAYS_SOFTWARE':'1','PULSE_SINK':'game','OTHER':'keep'}
    env,report=device.vulkan_graphics(base,tmp_path)
    assert report['hardware_verified'] and report['probe_source']=='vulkaninfo'
    assert calls[0][0]==['vulkaninfo','--summary']
    assert env['VK_DRIVER_FILES']==str(driver)
    assert all(key not in env for key in ('GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LIBGL_ALWAYS_SOFTWARE'))
    assert env['PULSE_SINK']=='game' and base['GALLIUM_DRIVER']=='zink'


@pytest.mark.parametrize('output',['deviceName = llvmpipe (LLVM 21)\n','deviceName = lavapipe\n','deviceName = Unknown\n',''])
def test_direct_vulkan_does_not_call_software_a_gpu(tmp_path,monkeypatch,output):
    icd(tmp_path)
    monkeypatch.setattr(device,'run',lambda *a,**k:subprocess.CompletedProcess([],0,output,''))
    monkeypatch.setattr(device,'graphics',lambda base,prefix:({'fallback':'preserved'},{'hardware_verified':False}))
    env,report=device.vulkan_graphics({},tmp_path)
    assert not report['hardware_verified'] and env=={'fallback':'preserved'}


def test_missing_vulkaninfo_can_use_existing_gpu_verification_without_forcing_zink(tmp_path,monkeypatch):
    icd(tmp_path)
    def missing(*a,**kw):raise FileNotFoundError('vulkaninfo')
    monkeypatch.setattr(device,'run',missing)
    monkeypatch.setattr(device,'graphics',lambda base,prefix:({'GALLIUM_DRIVER':'zink','PULSE_SINK':'game'},{'hardware_verified':True}))
    env,report=device.vulkan_graphics({},tmp_path)
    assert report['hardware_verified'] and report['probe_source']=='glxinfo_fallback'
    assert env=={'PULSE_SINK':'game'}


def test_saved_renderer_selects_vulkan_probe(tmp_path,monkeypatch):
    device.atomic_json(tmp_path/'device-config.json',{'enabled':True})
    device.atomic_json(tmp_path/'render-config.json',{'renderer':'mobile'})
    calls=[]
    monkeypatch.setattr(device,'vulkan_graphics',lambda base,prefix:(calls.append('vulkan') or dict(base),{'message':'test','renderer':'Turnip'}))
    monkeypatch.setattr(device,'graphics',lambda *a:pytest.fail('GL probe should not be used'))
    _,report=device.prepare_graphics({'PREFIX':'/data/test-prefix'},tmp_path)
    assert calls==['vulkan'] and report['graphics']['renderer']=='Turnip'


def test_direct_render_path_cleans_gl_overrides_and_preserves_explicit_arguments(tmp_path):
    scene.save(tmp_path,{'enabled':True,'static_batching':True,'camera_smoothing':True})
    env={'SNAKE_EFFECTIVE_RENDERER':'mobile','PREFIX':'/data/test','GALLIUM_DRIVER':'zink','PULSE_SINK':'voice','VK_DRIVER_FILES':'turnip.json'}
    out,args=scene.launch(env,['--max-fps','30','--','--cobrinha-live'],tmp_path)
    assert '--render-thread' not in args
    assert out['PULSE_SINK']=='voice' and out['VK_DRIVER_FILES']=='turnip.json' and 'GALLIUM_DRIVER' not in out
    explicit=['--render-thread','safe','--','--cobrinha-live']
    _,args=scene.launch(env,explicit,tmp_path)
    assert args.count('--render-thread')==1 and args[args.index('--render-thread')+1]=='safe'
    _,args=scene.launch({**env,'SNAKE_EFFECTIVE_RENDERER':'gl_compatibility'},['--','--cobrinha-live'],tmp_path)
    assert '--render-thread' not in args


@pytest.mark.parametrize('payload',[{'static_batching':'yes'},{'camera_smoothing':1},{'separate_render_thread':[]},{'frame_skip':True}])
def test_presentation_switches_reject_invalid_settings_without_overwriting(tmp_path,payload):
    scene.save(tmp_path,{'enabled':True})
    before=(tmp_path/'scene-graphics-config.json').read_bytes()
    with pytest.raises(ValueError):scene.save(tmp_path,payload)
    assert before==(tmp_path/'scene-graphics-config.json').read_bytes()


def test_render_selection_preserves_quality_audio_and_has_working_rollback(tmp_path):
    root=Path(__file__).resolve().parents[1]
    adapter=tmp_path/'adapter';state=adapter/'state';backup=state/'backups/test';backup.mkdir(parents=True)
    (adapter/'tools').mkdir();shutil.copy2(root/'tools/restore_adapter.py',adapter/'tools/restore_adapter.py')
    (backup/'restore-manifest.json').write_text(json.dumps({'root':str(adapter),'files':{}}))
    scene.save(state,{'enabled':True,'preset':'detail','welcome_garden':True})
    device.atomic_json(state/'render-config.json',{'renderer':'gl_compatibility'})
    (state/'private-settings.json').write_text('{"voice":"unchanged","key":"private-test"}')
    before=(state/'scene-graphics-config.json').read_bytes()
    assert apply(adapter,backup)['applied']
    assert scene.settings(state)['preset']=='detail' and scene.settings(state)['static_batching']
    assert json.loads((state/'render-config.json').read_text())['renderer']=='mobile'
    scene.save(state,{'camera_smoothing':False})
    assert not apply(adapter,backup)['applied'] and not scene.settings(state)['camera_smoothing']
    result=subprocess.run([sys.executable,str(backup/'REVERTER.py')],capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    assert (state/'scene-graphics-config.json').read_bytes()==before
    assert (state/'private-settings.json').read_text()=='{"voice":"unchanged","key":"private-test"}'


def test_complete_render_helper_keeps_original_marker_distinct_and_applies_both_updates(tmp_path):
    from conftest import ROOT
    root=Path(__file__).resolve().parents[1];target=tmp_path/'adapter';(target/'snake_termux').mkdir(parents=True)
    for name in ('start.sh','snake_termux/native.py','snake_termux/__main__.py'):(target/name).write_text('# previous\n')
    original=tmp_path/'original';shutil.copytree(ROOT/'server/src',original/'server/src',ignore=shutil.ignore_patterns('__pycache__'))
    (original/'VERSION').write_text('0.1.9\n')
    (target/'state').mkdir();(target/'state/project-path.txt').write_text(str(original))
    private=original/'server/private/social_text_ai.json';private.parent.mkdir(parents=True)
    private.write_text('{"provider":"local","voice_provider":"piper-local","port":18083}')
    helper=root/'SNAKE_REYERS_RENDER_MOVIMENTO_V041.sh'
    result=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=25)
    assert result.returncode==0,result.stdout+result.stderr
    assert (target/'state/original-live-v040-applied.json').exists()
    assert (target/'state/render-v041-applied.json').exists()
    assert json.loads((target/'state/render-config.json').read_text())['renderer']=='mobile'
    assert scene.settings(target/'state')['static_batching'] and scene.settings(target/'state')['camera_smoothing']
    assert json.loads(private.read_text())['termux_live_policy']
    backup=next((target/'state/launcher-backups').glob('*/REVERTER.py'))
    reverted=subprocess.run([sys.executable,str(backup)],capture_output=True,text=True,timeout=6)
    assert reverted.returncode==0,reverted.stdout+reverted.stderr
    assert not (target/'state/render-config.json').exists()
    assert not (target/'state/scene-graphics-config.json').exists()
    assert (target/'snake_termux/native.py').read_text()=='# previous\n'
