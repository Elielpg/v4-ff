import asyncio
import io
import json
import threading
import time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from fastapi.testclient import TestClient
import pytest
from snake_termux.client import LocalQwen,LocalServiceError
from snake_termux.local_social import trim_reply


@pytest.fixture
def sse_service():
    state={'mode':'valid','requests':[]}
    text='O Sol é uma estrela que fornece luz e calor para a Terra. '+('Uma explicação adicional sobre a luz e a energia. '*8)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])));state['requests'].append(payload)
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
            try:
                if state['mode']=='invalid':self.wfile.write(b'data: not-json\n\n');return
                for i in range(0,len(text),12):
                    self.wfile.write(('data: '+json.dumps({'choices':[{'delta':{'content':text[i:i+12]}}]},ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                    time.sleep(.001)
                    if state['mode']=='truncated':return
                self.wfile.write(b'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":80,"completion_tokens":20}}\n\ndata: [DONE]\n\n')
            except (BrokenPipeError,ConnectionResetError):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    yield state,server.server_port,text
    server.shutdown();server.server_close();thread.join(timeout=2)


def test_stream_stops_at_visible_budget_and_keeps_same_sanitized_prefix(sse_service):
    state,port,full=sse_service;c=LocalQwen(port)
    text=c.reply({'model':'fixed','local_question':'O que é o Sol?','max_chars':150,'bounded_generation':True},identity='Cobra')
    assert 150<len(text)<len(full)
    assert trim_reply(text,150)==trim_reply(full,150)
    assert c.diagnostics['stopped_at_visible_limit'] and c.diagnostics['first_token_ms'] is not None
    request=state['requests'][0]
    assert request['stream'] and '_termux_visible_limit' not in request and not request.get('tools')


@pytest.mark.parametrize('mode',['truncated','invalid'])
def test_incomplete_or_invalid_stream_does_not_become_spoken_reply(sse_service,mode):
    state,port,full=sse_service;state['mode']=mode
    with pytest.raises(LocalServiceError):LocalQwen(port).reply({'model':'fixed','local_question':'Explique','max_chars':150},identity='Cobra')


def test_stream_usage_and_done_are_accepted():
    c=LocalQwen(38001);c._request_started=time.monotonic()
    raw=b'data: {"choices":[{"delta":{"content":"Oi!"}}]}\n\ndata: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"completion_tokens":3}}\n\ndata: [DONE]\n\n'
    data=c._read_stream(io.BytesIO(raw),{'_termux_visible_limit':150},2)
    assert data['choices'][0]['message']['content']=='Oi!' and data['usage']['completion_tokens']==3


def test_large_stream_line_is_rejected():
    c=LocalQwen(38001);c._request_started=time.monotonic()
    with pytest.raises(LocalServiceError):c._read_stream(io.BytesIO(b'data: '+b'x'*66000),{},2)


def test_stream_deadline_includes_time_spent_waiting_for_headers():
    c=LocalQwen(38001);c._request_started=time.monotonic()-3
    with pytest.raises(LocalServiceError,match='prazo'):
        c._read_stream(io.BytesIO(b'data: [DONE]\n'),{},2)


def test_settings_preserve_voice_provider_and_secret_and_have_no_chat_in_status(adapted):
    app,binding=adapted
    raw=binding.settings._raw();raw.update(openai_api_key='SECRET_CANARY',voice_provider='openai');binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,raw)
    c=TestClient(app);r=c.post('/termux/responsiveness',json={'early_focus':False,'bounded_generation':False})
    assert r.status_code==200 and not r.json()['settings']['early_focus'] and 'SECRET_CANARY' not in r.text
    assert binding.settings._raw()['voice_provider']=='openai'
    assert c.post('/termux/responsiveness',json={'early_focus':'yes'}).status_code==400


def test_idle_comment_requests_camera_before_avatar_and_generation_finish(adapted,tmp_path,monkeypatch):
    from test_live_load import isolate
    app,binding=adapted;queue,events,worker=isolate(tmp_path,monkeypatch)
    sent=[];times={}
    class Socket:
        async def send_json(self,value):sent.append(value);times.setdefault('first_send',time.monotonic())
    monkeypatch.setattr(worker.godot_bridge,'_socket',Socket())
    monkeypatch.setattr(worker.song_runtime,'singing_blocks_speech',lambda:False)
    monkeypatch.setattr(worker.godot_runtime_state,'heart_me_band_music_showcase_active',lambda:False)
    monkeypatch.setattr(worker,'tts_worker_status',lambda:{'state':'idle'})
    monkeypatch.setattr(worker.top_supporters,'is_priority_comment',lambda _:False)
    monkeypatch.setattr(worker.top_supporters,'choose_comment',lambda comments:(comments[0],comments[1:]))
    def reply(*a,**kw):time.sleep(.15);times['model_done']=time.monotonic();return 'Ana, aqui está a resposta.'
    monkeypatch.setattr(worker,'_comment_reply',reply)
    async def cache(event):await asyncio.sleep(.2);times['avatar_done']=time.monotonic();return '/cache/photo.png'
    monkeypatch.setattr(worker,'_cache_avatar_for_event',cache)
    events.push_comment({'username':'ana','display_name':'Ana','comment':'Como funciona a cobra?'})
    result=asyncio.run(worker.process_once())
    assert result['ok'] and len(sent)==1 and sent[0]['type']=='spectator_user_selected'
    assert times['first_send']<times['model_done'] and times['first_send']<times['avatar_done']
    job=queue.status()['next_pending'];assert job['metadata']['avatar_path']=='/cache/photo.png'
    assert job['metadata']['_termux_deferred_spectator']['payload']['avatar_path']=='/cache/photo.png'
    status=TestClient(app).get('/termux/responsiveness').json();trace=status['traces'][-1]
    assert trace['viewer_requested_ms']<100 and trace['text_queued_ms']>=150
    assert 'Como funciona' not in json.dumps(status) and 'Ana' not in json.dumps(status)


def test_response_update_can_be_reverted_without_touching_settings_or_original_data(tmp_path):
    from pathlib import Path
    import subprocess
    import sys
    root=Path(__file__).resolve().parents[1]
    target=tmp_path/'adapter';(target/'snake_termux').mkdir(parents=True)
    originals={name:(root/name).read_bytes() for name in ('start.sh','snake_termux/native.py','snake_termux/__main__.py')}
    for name,data in originals.items():(target/name).write_bytes(data)
    (target/'state').mkdir();sentinel=target/'state/settings.json';sentinel.write_text('{"voice":"preserved"}')
    result=subprocess.run(['bash',str(root/'SNAKE_REYERS_RESPOSTA_RAPIDA_V035.sh'),'--files-only',str(target)],capture_output=True,text=True,timeout=20)
    assert result.returncode==0,result.stderr
    assert (target/'snake_termux/responsive.py').exists()
    restore=next((target/'state/launcher-backups').glob('*/REVERTER.py'))
    result=subprocess.run([sys.executable,str(restore)],capture_output=True,text=True,timeout=5)
    assert result.returncode==0,result.stderr
    for name,data in originals.items():assert (target/name).read_bytes()==data
    assert not (target/'snake_termux/responsive.py').exists()
    assert sentinel.read_text()=='{"voice":"preserved"}'
