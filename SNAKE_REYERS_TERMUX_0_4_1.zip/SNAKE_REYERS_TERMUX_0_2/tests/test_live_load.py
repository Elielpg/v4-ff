import asyncio
import json
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux.speech_names import spoken_name, normalize_text


@pytest.mark.parametrize('raw,expected', [('G U S T A V O', 'Gustavo'), ('𝕸𝖆𝖗𝖎𝖆', 'Maria'), ('@linel.exe', 'Linel'), ('ANA_123', 'Ana'), ('DJ Lucas 🔥', 'Lucas'), ('user987654', 'amigo'), ('XX_9823', 'amigo'), ('João Pedro', 'João'), ('🇧🇷 A N A 🍀', 'Ana')])
def test_names_are_words_not_identifiers(raw, expected):
    assert spoken_name(raw) == expected


def isolate(tmp_path, monkeypatch):
    from cobrinha_server.services import speech_queue as queue, live_events as events, event_decision_worker as worker
    for name, value in list(vars(queue).items()):
        if name.endswith('_FILE') and isinstance(value, Path): monkeypatch.setattr(queue, name, tmp_path / value.name)
    monkeypatch.setattr(events, 'SOCIAL_EVENTS_FILE', tmp_path / 'events.json')
    monkeypatch.setattr(worker, '_write_status', lambda **kw: None)
    return queue, events, worker


def test_voice_name_changes_but_original_caption_and_identity_stay(adapted, tmp_path, monkeypatch, local_service):
    from cobrinha_server.services import speech_queue, tts_service
    app, binding = adapted
    queue, events, worker = isolate(tmp_path, monkeypatch)
    raw = binding.settings._raw(); raw['voice_local_port'] = local_service['port']; binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
    job = {'id': 'name', 'text': 'G U S T A V O, sete vezes oito é 56!', 'metadata': {'display_name': 'G U S T A V O', 'username': 'gustavo123'}}
    ready = queue.prepare_pending_job(job)
    assert ready['text'] == job['text'] and ready['metadata']['display_name'] == 'G U S T A V O'
    assert local_service['calls'][-1]['data']['text'] == 'Gustavo, sete vezes oito é 56!'
    assert ready['spoken_text'].startswith('Gustavo,')


def test_alias_is_saved_privately_and_used_only_in_speech(adapted):
    app, binding = adapted
    client = TestClient(app)
    result = client.post('/termux/spoken-name', json={'name': 'pdrxx99', 'username': '@pdrxx99', 'alias': 'Pedro'})
    assert result.json()['saved'] and result.json()['spoken'] == 'Pedro'
    assert normalize_text('pdrxx99, olá!', {'display_name': 'pdrxx99', 'username': 'pdrxx99'}, binding.settings._raw()['termux_spoken_aliases']) == 'Pedro, olá!'
    assert client.post('/termux/spoken-name', json={'username': 'bad name', 'alias': 'Pedro'}).status_code == 400


def test_prefetch_has_one_slot_and_keeps_manual_music_and_pairs_blocked(adapted, tmp_path, monkeypatch):
    queue, events, worker = isolate(tmp_path, monkeypatch)
    monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: False)
    monkeypatch.setattr(worker.godot_runtime_state, 'heart_me_band_music_showcase_active', lambda: False)
    monkeypatch.setattr(worker, 'tts_worker_status', lambda: {'state': 'idle'})
    state = {'active': {'id': 'playing'}, 'pending_size': 0, 'ready_size': 0, 'pair_waiting_size': 0, 'manual_sequence': {}}
    monkeypatch.setattr(worker, 'speech_queue_status', lambda: dict(state))
    events.push_comment({'username': 'ana', 'comment': 'Como funciona?'})
    assert worker._speech_pipeline_can_accept_next()
    for field in ('pending_size', 'ready_size', 'pair_waiting_size'):
        state[field] = 1; assert not worker._speech_pipeline_can_accept_next(); state[field] = 0
    state['manual_sequence'] = {'active': True}; assert not worker._speech_pipeline_can_accept_next()
    state['manual_sequence'] = {}; monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: True)
    assert not worker._speech_pipeline_can_accept_next()


def test_current_question_is_selected_over_old_greetings(adapted, tmp_path, monkeypatch):
    queue, events, worker = isolate(tmp_path, monkeypatch)
    now = time.time()
    items = [{'kind': 'comment', 'id': 'old', 'priority': 70, 'text': 'qual é?', 'created_at': now - 30},
             {'kind': 'comment', 'id': 'new', 'priority': 70, 'text': 'oi', 'created_at': now},
             {'kind': 'comment', 'id': 'question', 'priority': 70, 'text': 'quanto é sete vezes oito?', 'created_at': now - 2}]
    result = events._sort_events(items)
    assert [e['id'] for e in result] == ['question', 'new']
    assert TestClient(adapted[0]).get('/termux/live-load').json()['metrics']['expired_comments'] == 1


def test_large_user_history_is_bounded_but_gift_dedup_untouched(adapted, tmp_path, monkeypatch):
    queue, events, worker = isolate(tmp_path, monkeypatch)
    now = time.time()
    history = {str(i): {'created_at': now - i / 100, 'signature': 'x'} for i in range(5000)}
    kept = events._prune_comment_dedup(history, now)
    assert len(kept) == 512 and '0' in kept and '4999' not in kept
    assert events._prune_gift_dedup.__module__.startswith('cobrinha_server')


def test_welcome_speech_coalesces_without_dropping_questions(adapted, tmp_path, monkeypatch):
    queue, events, worker = isolate(tmp_path, monkeypatch)
    first = worker.enqueue_text('Bem-vindo, A N A', metadata={'audio_role': 'system'})
    second = worker.enqueue_text('Bem-vindo, B R U N O', metadata={'audio_role': 'system'})
    question = worker.enqueue_text('Ana, aqui está sua resposta.', metadata={'source': 'social_comment'})
    assert first['id'] and second['suppressed'] and question['id']
    assert queue.status()['pending_size'] == 2


def test_prefetched_reply_does_not_move_spectator_camera_before_dispatch(adapted, tmp_path, monkeypatch):
    queue, events, worker = isolate(tmp_path, monkeypatch)
    sent = []
    class Socket:
        async def send_json(self, value): sent.append(value)
    monkeypatch.setattr(worker.godot_bridge, '_socket', Socket())
    monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: False)
    monkeypatch.setattr(worker.godot_runtime_state, 'heart_me_band_music_showcase_active', lambda: False)
    monkeypatch.setattr(worker, 'tts_worker_status', lambda: {'state': 'idle'})
    monkeypatch.setattr(worker.top_supporters, 'is_priority_comment', lambda _: False)
    monkeypatch.setattr(worker.top_supporters, 'choose_comment', lambda comments: (comments[0], comments[1:]))
    monkeypatch.setattr(worker, '_comment_reply', lambda *a, **kw: 'Ana, aqui está sua resposta!')
    async def cache(event): return '/avatar.png'
    monkeypatch.setattr(worker, '_cache_avatar_for_event', cache)
    queue.write_json_atomic(queue.ACTIVE_SPEECH_FILE, {'id': 'playing', 'activated_at': time.time(), 'timeline': {'timeline_end': 10}})
    events.push_comment({'username': 'ana', 'display_name': 'Ana', 'comment': 'Como funciona a cobra?'})
    result = asyncio.run(worker.process_once())
    assert result['ok'] and not sent
    job = queue.status()['next_pending']
    assert '_termux_deferred_spectator' in job['metadata']
    queue.acknowledge_speech_finished('playing')
    asyncio.run(worker.godot_bridge.send({'type': 'speech_ready', 'payload': {'metadata': job['metadata']}}))
    assert len(sent) == 2 and sent[-1]['type'] == 'speech_ready'
    assert '_termux_deferred_spectator' not in sent[-1]['payload']['metadata']
    assert sent[0]['payload']['display_name'] == 'Ana'


def test_provider_failure_gives_honest_notice_instead_of_unrelated_answer(adapted, tmp_path, monkeypatch):
    from test_cloud_ai import configure
    from snake_termux.cloud_ai import APIError
    app, binding = adapted; queue, events, worker = isolate(tmp_path, monkeypatch)
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    monkeypatch.setattr(binding.cloud_api, 'request', lambda *a, **kw: (_ for _ in ()).throw(APIError('Cota.', status=429, code='rate_limit', retry=30, project=True)))
    class Socket:
        async def send_json(self, value): pass
    monkeypatch.setattr(worker.godot_bridge, '_socket', Socket())
    monkeypatch.setattr(worker.song_runtime, 'singing_blocks_speech', lambda: False)
    monkeypatch.setattr(worker.godot_runtime_state, 'heart_me_band_music_showcase_active', lambda: False)
    monkeypatch.setattr(worker, 'tts_worker_status', lambda: {'state': 'idle'})
    monkeypatch.setattr(worker.top_supporters, 'is_priority_comment', lambda _: False)
    monkeypatch.setattr(worker.top_supporters, 'choose_comment', lambda comments: (comments[0], comments[1:]))
    async def activity(*a, **kw): return ''
    monkeypatch.setattr(worker, '_send_spectator_activity', activity)
    events.push_comment({'username': 'ana', 'display_name': 'Ana', 'comment': 'Como funciona a cobra?'})
    asyncio.run(worker.process_once())
    assert 'não consegui responder' in queue.status()['next_pending']['text']
