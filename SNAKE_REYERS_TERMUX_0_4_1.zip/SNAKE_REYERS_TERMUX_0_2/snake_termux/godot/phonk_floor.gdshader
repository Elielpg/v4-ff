// Independent material; the existing floor mesh/UV/texture remain in place.
shader_type spatial;
render_mode diffuse_burley;
uniform sampler2D floor_texture : source_color, filter_linear_mipmap, repeat_enable;
uniform bool use_texture = false;
uniform vec4 floor_tint : source_color = vec4(.24,.12,.34,1.);
uniform vec3 uv_scale = vec3(1.);
uniform vec3 uv_offset = vec3(0.);
uniform vec4 accent : source_color = vec4(.61,.17,1.,1.);
uniform float pulse = 0.;
uniform float flow_time = 0.;
uniform float strength = .8;
uniform bool chrome_style = false;
uniform float accent_strength = .16;
varying vec2 arena_position;
void vertex(){arena_position=(MODEL_MATRIX*vec4(VERTEX,1.)).xz;}
void fragment(){
    vec3 texture_color=use_texture?texture(floor_texture,UV*uv_scale.xy+uv_offset.xy).rgb:vec3(.35);
    vec2 cell=abs(fract(arena_position*.5+.5)-.5);
    vec2 width=max(fwidth(arena_position*.5),vec2(.003));
    vec2 lines=1.-smoothstep(vec2(.012),vec2(.024)+width,cell);
    float grid=max(lines.x,lines.y);
    float radial=length(arena_position);
    float wave=pow(max(0.,sin(radial*1.4-flow_time*4.)),14.);
    ALBEDO=texture_color*floor_tint.rgb;
    if(chrome_style){ALBEDO=vec3(0.);}
    ROUGHNESS=.8;
    SPECULAR=.25;
    if(chrome_style){
        float silver_wave=pow(max(0.,sin(radial*.7-flow_time*2.5)),10.);
        float streak=pow(max(0.,sin(arena_position.x*.35+arena_position.y*.17-flow_time*1.4)),18.);
        EMISSION=vec3(.78,.84,.92)*(grid*(.04+pulse*.32)+silver_wave*(.02+pulse*.3))*strength;
        EMISSION+=accent.rgb*streak*(.015+pulse*.5)*accent_strength*strength;
        EMISSION+=vec3(.055,.061,.072)*dot(texture_color,vec3(.2126,.7152,.0722));
    }else{EMISSION=accent.rgb*(grid*(.16+pulse*1.15)+wave*(.02+pulse*.55))*strength;}
}
