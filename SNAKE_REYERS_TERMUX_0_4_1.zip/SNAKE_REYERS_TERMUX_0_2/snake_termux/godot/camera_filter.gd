# Frame-rate-independent presentation filter. Never changes gameplay transforms.
extends RefCounted
var initialized := false
var value := Transform3D.IDENTITY
var discontinuities := 0

func sample(target: Transform3D, delta: float, reset: bool=false) -> Transform3D:
    var gap := value.origin.distance_to(target.origin)
    var angle := value.basis.get_rotation_quaternion().angle_to(target.basis.get_rotation_quaternion())
    if reset or not initialized or gap>10.0 or angle>deg_to_rad(65.0) or delta>.30:
        value=target
        if initialized:discontinuities+=1
        initialized=true
        return value
    var alpha := clampf(1.0-exp(-maxf(delta,0.0)/.055),0.0,1.0)
    value=value.interpolate_with(target,alpha)
    return value
