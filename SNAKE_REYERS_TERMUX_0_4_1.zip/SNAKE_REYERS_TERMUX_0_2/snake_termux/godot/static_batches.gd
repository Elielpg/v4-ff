# Renderer-side instancing only. Original nodes, scripts and collisions remain.
extends Node
var config: Dictionary={}
var pending: Array[Node]=[]
var groups: Dictionary={}
var material_keys: Dictionary={}
var mesh_keys: Dictionary={}
var batches: Array=[]
var checks: Array=[]
var check_index := 0
var elapsed := 0.0
var finished := false
var initial_scan := false
var audit := {"examined":0,"batched_instances":0,"batches":0,"invalidated_groups":0,"skipped":0}

func _ready() -> void:
    process_priority=900000

func _process(delta: float) -> void:
    elapsed+=delta
    if not initial_scan and elapsed>=4.0:
        initial_scan=true
        for branch_name in ["StaticWorldProcedural","MimosaBackgroundLandscape"]:
            for branch in get_tree().root.find_children(branch_name,"Node3D",true,false):pending.append(branch)
    if initial_scan and not finished:
        var budget := 48
        var started := Time.get_ticks_usec()
        while budget>0 and not pending.is_empty() and Time.get_ticks_usec()-started<1800:
            var node: Node=pending.pop_back();budget-=1
            if not is_instance_valid(node):continue
            for child in node.get_children():pending.append(child)
            if node is MeshInstance3D:_collect(node)
        if pending.is_empty():
            _build()
            finished=true;groups.clear();material_keys.clear();mesh_keys.clear()
            print("TERMUX_STATIC_BATCHES "+JSON.stringify(audit))
    if finished and not checks.is_empty():
        # Bounded checks restore a whole group if a supposedly static source changes.
        for index in range(mini(16,checks.size())):
            check_index=(check_index+1)%checks.size()
            _check(checks[check_index])

func _storage_signature(resource: Resource, ignored: Array) -> Array:
    var result: Array=[resource.get_class()]
    for prop in resource.get_property_list():
        var key: String=prop.name
        if int(prop.usage)&PROPERTY_USAGE_STORAGE==0 or key in ignored or key.begins_with("metadata/"):continue
        var item=resource.get(key)
        result.append([key,item.get_instance_id() if item is Resource else var_to_str(item)])
    return result

func _material_key(mat: StandardMaterial3D) -> String:
    var id := mat.get_instance_id()
    if not material_keys.has(id):
        material_keys[id]=str(_storage_signature(mat,["albedo_color","vertex_color_use_as_albedo","resource_name","resource_path","resource_local_to_scene","script"]))
    return material_keys[id]

func _shape(mesh: PrimitiveMesh) -> Dictionary:
    var id := mesh.get_instance_id()
    if mesh_keys.has(id):return mesh_keys[id]
    var ignored: Array=["material","resource_name","resource_path","resource_local_to_scene","script"]
    var scale := Vector3.ONE
    var canonical := false
    # UV2/lightmapped primitives use their exact dimensions.
    if not mesh.add_uv2 and mesh is BoxMesh and mesh.size.x>0 and mesh.size.y>0 and mesh.size.z>0:
        scale=mesh.size
        ignored.append("size")
        canonical=true
    elif not mesh.add_uv2 and mesh is SphereMesh and mesh.radius>0 and mesh.height>0:
        scale=Vector3(mesh.radius,mesh.height*.5,mesh.radius)
        ignored.append_array(["radius","height"])
        canonical=true
    var result := {"key":str(_storage_signature(mesh,ignored)),"source_mesh":mesh,"canonical":canonical,"scale":scale}
    mesh_keys[id]=result
    return result

func _branch(node: MeshInstance3D) -> Node3D:
    var parent: Node=node
    while parent!=null:
        if str(parent.name) in ["StaticWorldProcedural","MimosaBackgroundLandscape"]:return parent as Node3D
        if parent!=node and parent.get_script()!=null:return null
        parent=parent.get_parent()
    return null

func _collect(node: MeshInstance3D) -> void:
    if node.mesh==null or not node.mesh is PrimitiveMesh:return
    var branch := _branch(node)
    if branch==null:return
    audit.examined+=1
    if not node.is_visible_in_tree() or node.get_script()!=null or node.skin!=null or node.material_overlay!=null or node.mesh.get_surface_count()!=1 or node.transparency>0 or node.visibility_range_begin>0 or node.visibility_range_end>0 or node.gi_mode==GeometryInstance3D.GI_MODE_DYNAMIC:
        audit.skipped+=1;return
    var mat=node.get_active_material(0)
    if not mat is StandardMaterial3D or mat.transparency!=BaseMaterial3D.TRANSPARENCY_DISABLED or mat.vertex_color_use_as_albedo or mat.billboard_mode!=BaseMaterial3D.BILLBOARD_DISABLED or mat.grow or mat.proximity_fade_enabled or mat.distance_fade_mode!=BaseMaterial3D.DISTANCE_FADE_DISABLED:
        audit.skipped+=1;return
    var shape := _shape(node.mesh)
    var location := branch.to_local(node.global_position)
    var tile := Vector2i(floori(location.x/8.0),floori(location.z/8.0))
    var key := str(branch.get_instance_id())+str(tile)+str(shape.key)+_material_key(mat)+str([node.layers,node.cast_shadow,node.extra_cull_margin,node.ignore_occlusion_culling,node.lod_bias,node.gi_mode])
    if not groups.has(key):groups[key]={"branch":branch,"shape":shape,"material":mat,"nodes":[]}
    groups[key].nodes.append({"node":node,"scale":shape.scale})

func _build() -> void:
    for key in groups:
        var group: Dictionary=groups[key]
        if group.nodes.size()<4:continue
        var branch: Node3D=group.branch
        if not is_instance_valid(branch):continue
        # Allocate geometry only for groups that will actually be rendered.
        var mesh: PrimitiveMesh=group.shape.source_mesh.duplicate()
        if group.shape.canonical:
            if mesh is BoxMesh:mesh.size=Vector3.ONE
            elif mesh is SphereMesh:mesh.radius=1.0;mesh.height=2.0
        mesh.material=null
        var material: StandardMaterial3D=group.material.duplicate()
        material.albedo_color=Color.WHITE;material.vertex_color_use_as_albedo=true
        var multi := MultiMesh.new();multi.transform_format=MultiMesh.TRANSFORM_3D;multi.use_colors=true;multi.mesh=mesh;multi.instance_count=group.nodes.size()
        var draw := MultiMeshInstance3D.new();draw.name="TermuxStaticBatch";draw.multimesh=multi;draw.material_override=material
        var first: MeshInstance3D=group.nodes[0].node
        draw.layers=first.layers;draw.cast_shadow=first.cast_shadow;draw.extra_cull_margin=first.extra_cull_margin;draw.ignore_occlusion_culling=first.ignore_occlusion_culling;draw.lod_bias=first.lod_bias;draw.gi_mode=first.gi_mode
        branch.add_child(draw)
        var record := {"draw":draw,"sources":[],"active":true}
        for index in range(group.nodes.size()):
            var node: MeshInstance3D=group.nodes[index].node
            var pose: Transform3D=branch.global_transform.affine_inverse()*node.global_transform
            var source_pose := pose
            pose.basis=pose.basis.scaled_local(group.nodes[index].scale)
            multi.set_instance_transform(index,pose)
            var mat: StandardMaterial3D=node.get_active_material(0)
            multi.set_instance_color(index,mat.albedo_color)
            var source := {"node":node,"branch":branch,"visible":node.is_visible_in_tree(),"pose":source_pose,"mesh":node.mesh,"material":mat,"color":mat.albedo_color,"group":record}
            record.sources.append(source);checks.append(source)
            if not source.visible:multi.set_instance_transform(index,Transform3D(Basis().scaled(Vector3.ZERO),Vector3.ZERO))
            RenderingServer.instance_set_visible(node.get_instance(),false)
        batches.append(record);audit.batches+=1;audit.batched_instances+=group.nodes.size()

func _check(source: Dictionary) -> void:
    var group: Dictionary=source.group
    if not group.active:return
    var node: MeshInstance3D=source.node
    var branch: Node3D=source.branch
    if not is_instance_valid(node) or not is_instance_valid(branch) or node.mesh!=source.mesh or node.get_active_material(0)!=source.material or node.is_visible_in_tree()!=source.visible or source.material.albedo_color!=source.color:
        _restore(group)
    elif absf(branch.global_basis.determinant())<.000001 or not (branch.global_transform.affine_inverse()*node.global_transform).is_equal_approx(source.pose):
        _restore(group)

func _restore(group: Dictionary) -> void:
    if not group.active:return
    group.active=false;audit.invalidated_groups+=1
    if is_instance_valid(group.draw):group.draw.visible=false
    for source in group.sources:
        if is_instance_valid(source.node):RenderingServer.instance_set_visible(source.node.get_instance(),source.node.is_visible_in_tree())

func _exit_tree() -> void:
    for group in batches:_restore(group)
    checks.clear()
    for group in batches:
        for source in group.sources:source.erase("group")
        group.sources.clear()
    batches.clear()
