// Soft outer shell for two existing meshes; no particles or new geometry.
shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_front, shadows_disabled;
uniform vec4 accent : source_color = vec4(.61,.17,1.,1.);
uniform float pulse = 0.;
uniform float flow_time = 0.;
uniform float strength = .35;
uniform bool chrome_style = false;
void vertex(){
    float breath=.9+.1*sin(VERTEX.y*5.+VERTEX.x*3.+VERTEX.z*4.-flow_time*3.);
    VERTEX+=NORMAL*(.035+pulse*.06)*(chrome_style?1.7:1.)*breath;
}
void fragment(){
    float rim=pow(1.-abs(dot(normalize(NORMAL),normalize(VIEW))),1.7);
    ALBEDO=chrome_style?vec3(.88,.92,1.):accent.rgb;
    ALPHA=clamp(rim*strength*(.2+pulse*.8),0.,.55);
}
