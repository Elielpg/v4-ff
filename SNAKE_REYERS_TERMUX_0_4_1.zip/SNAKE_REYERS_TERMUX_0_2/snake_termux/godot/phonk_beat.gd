# Adaptive onset detector. Event rate is not advertised as the song's BPM.
extends RefCounted
var bass_average := 0.0
var high_average := 0.0
var previous_bass := 0.0
var previous_high := 0.0
var last_hit := -10.0
var warmup := 0.0

func reset() -> void:
    bass_average=0.0;high_average=0.0;previous_bass=0.0;previous_high=0.0;last_hit=-10.0;warmup=0.0

func update(bass: float,high: float,delta: float,now: float,sensitivity: float=1.0) -> bool:
    warmup+=delta
    var factor := 1.0-exp(-delta/0.32)
    var bass_flux := maxf(0.0,bass-previous_bass)
    var high_flux := maxf(0.0,high-previous_high)
    var bass_hit := bass>maxf(.000012,bass_average*(1.38/sensitivity)) and bass_flux>maxf(.000006,bass_average*.20/sensitivity)
    var high_hit := high>maxf(.000008,high_average*(1.65/sensitivity)) and high_flux>maxf(.000005,high_average*.35/sensitivity)
    var hit := warmup>.10 and now-last_hit>=.085 and (bass_hit or high_hit)
    bass_average=lerpf(bass_average,bass,factor)
    high_average=lerpf(high_average,high,factor)
    previous_bass=bass;previous_high=high
    if hit:last_hit=now
    return hit
