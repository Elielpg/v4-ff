# Own optional extension, not a replacement for the original game's scene.
extends "scene_graphics.gd"
const PhonkRuntime=preload("phonk_runtime.gd")
var phonk_runtime: Node

func _try_install() -> void:
    super._try_install()
    if installed and not is_instance_valid(phonk_runtime):
        phonk_runtime=PhonkRuntime.new()
        phonk_runtime.name="TermuxPhonkRuntime"
        viewport_3d.add_child(phonk_runtime)
