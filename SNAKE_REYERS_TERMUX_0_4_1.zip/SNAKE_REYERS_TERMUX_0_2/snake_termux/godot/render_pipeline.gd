# Independent renderer presentation; never assigns original camera/head transforms.
extends Node
const Filter=preload("camera_filter.gd")
const StaticBatches=preload("static_batches.gd")
var config: Dictionary={}
var filter=Filter.new()
var proxy: Camera3D
var source: Camera3D
var batcher: Node
var viewport: Viewport
var previous_raw := Vector3.ZERO
var previous_filtered := Vector3.ZERO
var raw_distance := 0.0
var filtered_distance := 0.0
var sample_seconds := 0.0
var samples := 0
var report: Dictionary={}
var projection_signature: Array=[]

func _ready() -> void:
    process_priority=1000000
    viewport=get_viewport()
    if config.get("static_batching",false):
        batcher=StaticBatches.new();batcher.name="TermuxStaticInstancing";add_child(batcher)
    if config.get("camera_smoothing",false):
        proxy=Camera3D.new();proxy.name="TermuxPresentationCamera";proxy.current=false
        add_child(proxy)

func _process(delta: float) -> void:
    var current := viewport.get_camera_3d()
    if current==null or current==proxy:return
    var changed := source!=current
    source=current
    var target := source.global_transform
    var visible_pose := target
    if is_instance_valid(proxy):
        visible_pose=filter.sample(target,delta,changed)
        proxy.global_transform=visible_pose
        var signature: Array=[source.projection,source.fov,source.size,source.frustum_offset,source.keep_aspect,source.near,source.far,source.h_offset,source.v_offset,source.cull_mask,source.environment,source.attributes,source.compositor]
        if projection_signature!=signature:
            projection_signature=signature
            proxy.projection=source.projection;proxy.fov=source.fov;proxy.size=source.size;proxy.frustum_offset=source.frustum_offset
            proxy.keep_aspect=source.keep_aspect;proxy.near=source.near;proxy.far=source.far
            proxy.h_offset=source.h_offset;proxy.v_offset=source.v_offset;proxy.cull_mask=source.cull_mask
            proxy.environment=source.environment;proxy.attributes=source.attributes;proxy.compositor=source.compositor
        # Attach only the renderer RID: get_camera_3d() still returns the game's
        # original camera, so targeting, animation and gameplay use original data.
        RenderingServer.viewport_attach_camera(viewport.get_viewport_rid(),proxy.get_camera_rid())
    if samples>0 and not changed:
        raw_distance+=previous_raw.distance_to(target.origin)
        filtered_distance+=previous_filtered.distance_to(visible_pose.origin)
    previous_raw=target.origin;previous_filtered=visible_pose.origin;samples+=1;sample_seconds+=delta
    if sample_seconds>=2.0:
        report={"camera_smoothing":is_instance_valid(proxy),"camera_discontinuities":filter.discontinuities,
                "camera_original_current":viewport.get_camera_3d()==source,"camera_sample_count":samples,
                "camera_raw_distance":snappedf(raw_distance,.001),"camera_presented_distance":snappedf(filtered_distance,.001),
                "physics_interpolation_changed":false,"original_transforms_changed":false,
                "static_batching":batcher.audit if is_instance_valid(batcher) else {},
                "project_render_thread_mode":ProjectSettings.get_setting("rendering/driver/threads/thread_model",null)}
        raw_distance=0;filtered_distance=0;samples=0;sample_seconds=0

func _exit_tree() -> void:
    if is_instance_valid(viewport) and is_instance_valid(source):
        RenderingServer.viewport_attach_camera(viewport.get_viewport_rid(),source.get_camera_rid())
