# Independent, reversible PHONK look using public runtime APIs only.
# No microphone, external-app capture, scene replacement or gameplay mutation.
extends Node
const BeatDetector=preload("phonk_beat.gd")
const SkinShader=preload("phonk_skin.gdshader")
const FloorShader=preload("phonk_floor.gdshader")
const AuraShader=preload("phonk_aura.gdshader")
const MAX_PENDING=2048
const MAX_OVERRIDES=2048
const MAX_CAMERAS=16
const MAX_MATERIALS=128
var config: Dictionary={}
var active := false
var detector=BeatDetector.new()
var spectrum: AudioEffectSpectrumAnalyzer
var spectrum_instance: AudioEffectSpectrumAnalyzerInstance
var bus := -1
var clock := 0.0
var reload_time := 0.0
var report_time := 0.0
var pulse := 0.0
var beats := 0
var color_index := 0
var last_manual := -1
var track_id := ""
var track_title := ""
var track_path := ""
var player: AudioStreamPlayer
var main: Node
var skin := ShaderMaterial.new()
var aura_skin := ShaderMaterial.new()
var aura_material := ShaderMaterial.new()
var accent := Color("9c2cff")
var overrides: Array=[]
var visited: Dictionary={}
var terrain_materials: Dictionary={}
var pending: Array[Dictionary]=[]
var cameras: Array=[]
var current_camera: Camera3D
var themed_environment: Environment
var sky: GeometryInstance3D
var sky_visible := true
var own_decor: Array=[]
var own_root: Node3D
var revision := ""
var save_error := false
var queued: Dictionary={}
var floor_materials: Array[ShaderMaterial]=[]
var neon_material := StandardMaterial3D.new()
var chrome_scenery := StandardMaterial3D.new()
var target_accent := Color("9c2cff")
var random := RandomNumberGenerator.new()
var cleanup_time := 0.0
var random_changed_at := -10.0
var queue_dropped := 0
var removed_records := 0
var slow_frames := 0
var maximum_frame_ms := 0.0
var maximum_scan_us := 0
var previous_frame_us := 0
var parameter_applies := 0
var last_snake_position := Vector3.ZERO
var snake_position_known := false
var snake_moved_at := 0.0

func _ready() -> void:
    skin.shader=SkinShader
    aura_skin.shader=SkinShader
    aura_material.shader=AuraShader
    random.randomize()
    neon_material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
    chrome_scenery.albedo_color=Color(.07,.075,.085)
    chrome_scenery.metallic=.48
    chrome_scenery.roughness=.4
    get_tree().node_added.connect(_node_added)
    _reload()

func _exit_tree() -> void:
    _disable()

func _reload() -> void:
    var path := OS.get_environment("SNAKE_PHONK_CONFIG")
    if path.is_empty() or not FileAccess.file_exists(path):return
    var file := FileAccess.open(path,FileAccess.READ)
    if file==null or file.get_length()>65536:return
    var parsed=JSON.parse_string(file.get_as_text())
    if not parsed is Dictionary:return
    var style_changed: bool=parsed.get("style","chrome")!=config.get("style","chrome")
    if active and style_changed:_disable()
    config=parsed
    var enabled := bool(config.get("enabled",false))
    if enabled and not active:_enable()
    elif not enabled and active:_disable()
    if not active:return
    var signature := JSON.stringify(config)
    if signature!=revision:
        revision=signature
        parameter_applies+=1
        var chrome: bool=config.get("style","chrome")=="chrome"
        for material in [skin,aura_skin]:
            material.set_shader_parameter("base_color",Color(str(config.get("base_color","#08050f"))))
            material.set_shader_parameter("strength",float(config.get("intensity",.6)))
            material.set_shader_parameter("lightning_strength",float(config.get("lightning_strength",1.2)) if config.get("lightning",true) else 0.0)
            material.set_shader_parameter("lightning_speed",float(config.get("lightning_speed",1.0)))
            material.set_shader_parameter("chrome_style",chrome)
            material.set_shader_parameter("accent_strength",float(config.get("accent_strength",.16)))
        var next: Material=aura_material if config.get("aura",true) else null
        if aura_skin.next_pass!=next:aura_skin.next_pass=next
        aura_material.set_shader_parameter("strength",float(config.get("aura_strength",.35)))
        aura_material.set_shader_parameter("chrome_style",chrome)
        _select_color(false)
    _track()
    _camera()

func _enable() -> void:
    active=true
    main=get_tree().root.get_node_or_null("Cobrinha3D")
    if main!=null:
        player=main.get_node_or_null("MusicPlayer") as AudioStreamPlayer
        sky=main.get_node_or_null("VisibleSkyDome") as GeometryInstance3D
        if sky!=null:sky_visible=sky.visible;sky.visible=false
    _queue(get_tree().root)
    _analyzer()
    _build_neon()
    print("TERMUX_PHONK_READY Music bus only; original game and voice routing preserved")

func _analyzer() -> void:
    bus=AudioServer.get_bus_index("Music")
    if bus<0:return
    spectrum=AudioEffectSpectrumAnalyzer.new()
    spectrum.fft_size=AudioEffectSpectrumAnalyzer.FFT_SIZE_1024
    spectrum.buffer_length=.2
    AudioServer.add_bus_effect(bus,spectrum)
    spectrum_instance=AudioServer.get_bus_effect_instance(bus,AudioServer.get_bus_effect_count(bus)-1) as AudioEffectSpectrumAnalyzerInstance

func _disable() -> void:
    active=false;pulse=0.0;pending.clear();queued.clear();revision=""
    # Remove only the effect that this extension owns, never an existing one.
    var current_bus := AudioServer.get_bus_index("Music")
    if current_bus>=0 and spectrum!=null:
        for index in range(AudioServer.get_bus_effect_count(current_bus)-1,-1,-1):
            if AudioServer.get_bus_effect(current_bus,index)==spectrum:AudioServer.remove_bus_effect(current_bus,index)
    spectrum_instance=null;spectrum=null;bus=-1
    for row in overrides:
        var node=row.node.get_ref()
        if is_instance_valid(node) and node.material_override==row.owned:node.material_override=row.previous
    overrides.clear();visited.clear();terrain_materials.clear();floor_materials.clear()
    for row in cameras:
        var node=row.node.get_ref()
        if is_instance_valid(node) and node.environment==row.themed:node.environment=row.previous
    cameras.clear();current_camera=null;themed_environment=null
    if is_instance_valid(sky):sky.visible=sky_visible
    for row in own_decor:
        var node=row.node.get_ref()
        if is_instance_valid(node):
            if node.material_override==neon_material:node.material_override=row.previous
            for i in range(row.colors.size()):node.multimesh.set_instance_color(i,row.colors[i])
    own_decor.clear()
    if is_instance_valid(own_root):own_root.queue_free()
    own_root=null
    detector.reset()

func _node_added(node: Node) -> void:
    if active and node is MeshInstance3D:
        var path := str(node.get_path())
        if "/SnakeHead/" in path or path.ends_with("/ContinuousSnakeBody"):
            _queue(node)

func _queue(node: Node) -> void:
    if not is_instance_valid(node):return
    var key := node.get_instance_id()
    if queued.has(key) or visited.has(key):return
    if pending.size()>=MAX_PENDING:queue_dropped+=1;return
    queued[key]=true
    pending.append({"node":weakref(node),"id":key})

func _remember(node: GeometryInstance3D,material: Material) -> void:
    if overrides.size()>=MAX_OVERRIDES:return
    var key := node.get_instance_id()
    visited[key]=true
    overrides.append({"node":weakref(node),"id":key,"previous":node.material_override,"owned":material})
    node.material_override=material

func _cleanup() -> void:
    var alive: Array=[]
    visited.clear()
    for row in overrides:
        var node=row.node.get_ref()
        if is_instance_valid(node) and node.material_override==row.owned:
            alive.append(row);visited[row.id]=true
        else:removed_records+=1
    overrides=alive
    for key in terrain_materials.keys():
        if terrain_materials[key].source.get_ref()==null:terrain_materials.erase(key)
    floor_materials.clear()
    for row in terrain_materials.values():
        if row.material is ShaderMaterial:floor_materials.append(row.material)
    var active_cameras: Array=[]
    for row in cameras:
        if row.node.get_ref()!=null:active_cameras.append(row)
    cameras=active_cameras
    var decor: Array=[]
    for row in own_decor:
        if row.node.get_ref()!=null:decor.append(row)
    own_decor=decor

func _scan() -> void:
    var started := Time.get_ticks_usec()
    var budget := 64
    while budget>0 and not pending.is_empty():
        if Time.get_ticks_usec()-started>=2000:break
        budget-=1
        var entry: Dictionary=pending.pop_back()
        queued.erase(entry.id)
        var node: Node=entry.node.get_ref()
        if not is_instance_valid(node):continue
        for child in node.get_children():_queue(child)
        var node_path := str(node.get_path())
        var scenery := "/StaticWorldProcedural/" in node_path or "/MimosaBackgroundLandscape/" in node_path
        if node is MultiMeshInstance3D and scenery and config.get("style","chrome")=="chrome":
            if not visited.has(node.get_instance_id()):_remember(node,chrome_scenery)
            continue
        if node is MultiMeshInstance3D and "TermuxArenaDetails" in str(node.get_path()):
            var colors: Array=[]
            for i in range(node.multimesh.instance_count):
                colors.append(node.multimesh.get_instance_color(i))
                node.multimesh.set_instance_color(i,Color(1,1,1))
            own_decor.append({"node":weakref(node),"previous":node.material_override,"colors":colors})
            node.material_override=_neon_material()
        if not node is MeshInstance3D or node.mesh==null:continue
        var key := node.get_instance_id()
        if visited.has(key) or overrides.size()>=MAX_OVERRIDES:continue
        var path := str(node.get_path())
        var snake := path.ends_with("/ContinuousSnakeBody") or "/SnakeHead/" in path
        var excluded := false
        for word in ["eye","pupil","teeth","tooth","tongue","fang","gum","mouthinterior","nostril"]:
            if word in path.to_lower():excluded=true
        # Anonymous meshes in the original head include the eyes and tongue.
        if str(node.name).begins_with("@"):excluded=true
        if snake and not excluded:
            _remember(node,aura_skin if str(node.name) in ["ContinuousSnakeBody","OrganicHead"] else skin)
        elif not snake:
            var material: Material=node.get_active_material(0) if node.mesh.get_surface_count()>0 else null
            if material is BaseMaterial3D:
                var source: String=material.albedo_texture.resource_path if material.albedo_texture!=null else ""
                var category: String=str(material.get_meta("termux_terrain_category",""))
                var terrain := scenery or str(node.name)=="ArenaFloor" or category in ["piso","parede","grama","elevacao"]
                for group in ["piso","parede","elevacao","grama"]:
                    if source.begins_with("res://assets/textures/"+group+"/"):terrain=true
                if terrain:
                    var floor := source.begins_with("res://assets/textures/piso/") or category=="piso" or str(node.name)=="ArenaFloor"
                    if config.get("style","chrome")=="chrome" and not floor:
                        _remember(node,chrome_scenery)
                        continue
                    var material_key := material.get_instance_id()
                    if not terrain_materials.has(material_key):
                        # Reserve sixteen entries for the floor, even when the
                        # scenery is visited first and contains many materials.
                        if terrain_materials.size()>=MAX_MATERIALS or (not floor and terrain_materials.size()>=MAX_MATERIALS-16):continue
                        var copy: Material
                        if floor and floor_materials.size()<16:
                            var reactive := ShaderMaterial.new();reactive.shader=FloorShader
                            reactive.set_shader_parameter("use_texture",material.albedo_texture!=null)
                            if material.albedo_texture!=null:reactive.set_shader_parameter("floor_texture",material.albedo_texture)
                            reactive.set_shader_parameter("uv_scale",material.uv1_scale)
                            reactive.set_shader_parameter("uv_offset",material.uv1_offset)
                            floor_materials.append(reactive);copy=reactive
                        else:
                            var tinted: BaseMaterial3D=material.duplicate()
                            tinted.albedo_color=material.albedo_color*Color(.24,.12,.34)
                            tinted.roughness=.85;copy=tinted
                        terrain_materials[material_key]={"material":copy,"source":weakref(material)}
                    _remember(node,terrain_materials[material_key].material)
    maximum_scan_us=maxi(maximum_scan_us,Time.get_ticks_usec()-started)

func _neon_material() -> StandardMaterial3D:
    return neon_material

func _build_neon() -> void:
    # Seven cheap static meshes, no particles, shadow maps or dynamic lights.
    own_root=Node3D.new();own_root.name="TermuxPhonkNeon";add_child(own_root)
    for radius in [13.0,13.3,13.6]:
        var mesh := TorusMesh.new();mesh.inner_radius=radius;mesh.outer_radius=radius+.045
        mesh.rings=64;mesh.ring_segments=6
        var node := MeshInstance3D.new();node.mesh=mesh;node.position.y=.02
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.material_override=_neon_material();own_root.add_child(node)
    for point in [Vector3(-13,1,-13),Vector3(13,1,-13),Vector3(-13,1,13),Vector3(13,1,13)]:
        var mesh := BoxMesh.new();mesh.size=Vector3(.05,2,.05)
        var node := MeshInstance3D.new();node.mesh=mesh;node.position=point
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.material_override=_neon_material();own_root.add_child(node)

func _camera() -> void:
    var camera := get_viewport().get_camera_3d()
    if camera==null or (is_instance_valid(current_camera) and camera==current_camera):return
    current_camera=camera
    for row in cameras:
        if row.node.get_ref()==camera:
            themed_environment=row.themed
            camera.environment=themed_environment
            return
    if cameras.size()>=MAX_CAMERAS:return
    var environment: Environment=camera.environment
    if environment==null and main!=null:
        var world := main.get_node_or_null("WorldEnvironment") as WorldEnvironment
        if world!=null:environment=world.environment
    themed_environment=environment.duplicate() if environment!=null else Environment.new()
    themed_environment.background_mode=Environment.BG_COLOR
    var chrome: bool=config.get("style","chrome")=="chrome"
    themed_environment.background_color=Color("020305") if chrome else Color("07030f")
    themed_environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    themed_environment.ambient_light_color=Color("b9c3d2") if chrome else Color("9866cc")
    themed_environment.ambient_light_energy=.65
    themed_environment.fog_enabled=false
    themed_environment.glow_enabled=false
    cameras.append({"node":weakref(camera),"previous":camera.environment,"themed":themed_environment})
    camera.environment=themed_environment

func _track() -> void:
    if not is_instance_valid(main):return
    # Public runtime state; no script/source/resource extraction.
    var value=main.get("music_current_track")
    if value==null:return
    var path := str(value)
    var table: Dictionary=config.get("runtime",{}).get("tracks",{})
    var row: Dictionary=table.get(path.get_file(),{})
    if path==track_path and str(row.get("id",""))==track_id:return
    track_path=path
    track_id=str(row.get("id",""));track_title=str(row.get("title",path.get_file().get_basename()))
    detector.reset();color_index=0;pulse=0.0
    _select_color()

func _select_color(change: bool=true) -> void:
    var colors: Array=config.get("track_palettes",{}).get(track_id,config.get("palette",["#9c2cff","#d653ff","#6333ed"]))
    if colors.size()<2:return
    var mode := str(config.get("color_mode","random"))
    if mode=="random":
        if not change:return
        var hue := fmod(target_accent.h+random.randf_range(.19,.65),1.0)
        target_accent=Color.from_hsv(hue,.83,1.0)
        random_changed_at=clock
        return
    var index := color_index if mode=="beat" else (absi(track_id.hash()) if mode=="track" else 0)
    target_accent=Color(str(colors[index%colors.size()]))
    if mode in ["fixed","track"]:accent=target_accent

func _process(delta: float) -> void:
    # Godot can clamp delta after a stall. Measure actual wall time so a frozen
    # render loop is not reported as a sequence of harmless 150 ms frames.
    var now := Time.get_ticks_usec()
    if previous_frame_us>0:delta=float(now-previous_frame_us)/1000000.0
    previous_frame_us=now
    clock+=delta;reload_time+=delta;report_time+=delta;cleanup_time+=delta
    maximum_frame_ms=maxf(maximum_frame_ms,delta*1000.0)
    if delta>.25:slow_frames+=1
    if reload_time>=.5:reload_time=0.0;_reload()
    if active:
        if cleanup_time>=2.0:cleanup_time=0.0;_cleanup()
        if not pending.is_empty():_scan()
        var hit := false
        if config.get("source","music")=="manual":
            var epoch := float(config.get("manual_epoch",0.0))
            var phase := int(floor((Time.get_unix_time_from_system()-epoch)*float(config.get("manual_bpm",140))/60.0))
            hit=last_manual>=0 and phase!=last_manual
            last_manual=phase
        elif spectrum_instance!=null and is_instance_valid(player) and player.playing:
            var bass := spectrum_instance.get_magnitude_for_frequency_range(35,220).length()
            var high := spectrum_instance.get_magnitude_for_frequency_range(1600,6500).length()
            hit=detector.update(bass,high,delta,clock,float(config.get("sensitivity",1.0)))
        if hit:
            beats+=1
            if beats%maxi(1,int(config.get("color_every",2)))==0:
                color_index+=1
                if config.get("color_mode","random")!="random" or clock-random_changed_at>=.5:_select_color()
            if config.get("pulses",true):pulse=1.0
        else:pulse*=exp(-delta/0.23)
        if not config.get("pulses",true):pulse=0.0
        accent=accent.lerp(target_accent,1.0-exp(-delta/.18))
        for material in [skin,aura_skin,aura_material]:
            material.set_shader_parameter("pulse",pulse)
            material.set_shader_parameter("flow_time",clock)
            material.set_shader_parameter("accent",accent)
        for material in floor_materials:
            material.set_shader_parameter("accent",accent)
            material.set_shader_parameter("pulse",pulse if config.get("floor_reactive",true) else 0.0)
            material.set_shader_parameter("flow_time",clock)
            material.set_shader_parameter("strength",float(config.get("floor_strength",.8)) if config.get("floor_reactive",true) else 0.0)
            material.set_shader_parameter("chrome_style",config.get("style","chrome")=="chrome")
            material.set_shader_parameter("accent_strength",float(config.get("accent_strength",.16)))
        var brightness := .45+float(config.get("intensity",.6))*(.45+pulse*.8)
        var light_color := Color(.8,.86,.94).lerp(accent,float(config.get("accent_strength",.16))) if config.get("style","chrome")=="chrome" else accent
        neon_material.albedo_color=light_color*brightness
        if themed_environment!=null:themed_environment.ambient_light_energy=.6+pulse*.12*float(config.get("intensity",.6))
    if report_time>=2.0:report_time=0.0;_report()

func _report() -> void:
    var path := OS.get_environment("SNAKE_PHONK_STATUS")
    if path.is_empty():return
    var report := {"at":Time.get_unix_time_from_system(),"enabled":active,"source":config.get("source","music"),"analyzer_bus":"Music" if bus>=0 else "unavailable","playing":is_instance_valid(player) and player.playing,"beats":beats,"pulse":pulse,"color":"#"+accent.to_html(false),"track_id":track_id,"track_title":track_title,"themed_meshes":overrides.size(),"external_app_capture":false,"manual_bpm":config.get("manual_bpm",140)}
    report.merge({"floor_materials":floor_materials.size(),"lightning":config.get("lightning",true),"floor_reactive":config.get("floor_reactive",true),"aura":config.get("aura",true),"pending_nodes":pending.size(),"queue_limit":MAX_PENDING,"queue_dropped":queue_dropped,"tracked_cameras":cameras.size(),"removed_records":removed_records,"material_cache":terrain_materials.size(),"slow_frames":slow_frames,"max_frame_ms":snappedf(maximum_frame_ms,.1),"max_scan_us":maximum_scan_us,"static_memory_mb":snappedf(float(Performance.get_monitor(Performance.MEMORY_STATIC))/1048576.0,.1)})
    report.merge({"style":config.get("style","chrome"),"body_color":"#d1dbe8" if config.get("style","chrome")=="chrome" else "#"+accent.to_html(false),"aura_color":"#e0ebff" if config.get("style","chrome")=="chrome" else "#"+accent.to_html(false),"parameter_applies":parameter_applies})
    report.merge({"process_frames":Engine.get_process_frames(),"physics_frames":Engine.get_physics_frames(),"frames_drawn":Engine.get_frames_drawn()})
    if is_instance_valid(main):
        var head := main.get_node_or_null("SnakeHead") as Node3D
        if head!=null:
            var position := head.global_position
            if not snake_position_known or position.distance_squared_to(last_snake_position)>.00001:
                snake_moved_at=clock;last_snake_position=position;snake_position_known=true
            report["snake_motion_age_seconds"]=snappedf(clock-snake_moved_at,.1)
            report["snake_position"]=[snappedf(position.x,.01),snappedf(position.y,.01),snappedf(position.z,.01)]
    var file := FileAccess.open(path+".tmp",FileAccess.WRITE)
    if file!=null:
        file.store_string(JSON.stringify(report));file.close()
        DirAccess.rename_absolute(path+".tmp",path)
    elif not save_error:save_error=true;push_warning("PHONK status unavailable; game continues")
