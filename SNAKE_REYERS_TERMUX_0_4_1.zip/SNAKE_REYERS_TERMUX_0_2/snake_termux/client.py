from __future__ import annotations

import json
import re
import threading
import time
import urllib.error
import urllib.request


def valid_port(value: object) -> int:
    if isinstance(value, bool):
        raise ValueError('Porta local inválida.')
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError('Porta local inválida.') from exc
    if str(value).strip() != str(port) or not 1024 <= port <= 65535:
        raise ValueError('Use uma porta local entre 1024 e 65535.')
    return port


def valid_model(value: object) -> str:
    model = str(value or 'auto').strip()
    if not re.fullmatch(r'[A-Za-z0-9_./:-]{1,240}', model):
        raise ValueError('Nome de modelo local inválido.')
    return model


class LocalServiceError(RuntimeError):
    pass


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def loopback_opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirects())


class LocalQwen:
    def __init__(self, port: int = 8081):
        self.port = valid_port(port)
        self.base = f'http://127.0.0.1:{self.port}'
        # This opener is limited to a fixed loopback host and does not send local
        # conversation requests through any environment-configured outbound proxy.
        self.opener = loopback_opener()
        self.lock = threading.RLock()
        self.model_ids: list[str] = []
        self.models_at = 0.0
        self.diagnostics = {'ready': None, 'requests': 0, 'answered': 0, 'failed': 0, 'last_error': None, 'latency_ms': None, 'selected_model': None}

    def _json(self, path: str, payload: dict | None = None, timeout: float = 2.0) -> dict:
        if path not in {'/v1/models', '/v1/chat/completions'}:
            raise ValueError('Rota local inválida.')
        outgoing = {k:v for k,v in payload.items() if k != '_termux_visible_limit'} if payload is not None else None
        data = None if outgoing is None else json.dumps(outgoing, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(self.base + path, data=data, headers={'Content-Type': 'application/json'}, method='GET' if payload is None else 'POST')
        try:
            with self.opener.open(request, timeout=timeout) as response:
                if payload and payload.get('stream') is True and 'text/event-stream' in response.headers.get('Content-Type', '').lower():
                    return self._read_stream(response, payload, timeout)
                body = response.read(1_000_001)
                if len(body) > 1_000_000:
                    raise LocalServiceError('Resposta do serviço local excedeu o limite.')
            value = json.loads(body)
            if not isinstance(value, dict):
                raise LocalServiceError('Resposta inválida do serviço local.')
            return value
        except urllib.error.HTTPError as exc:
            raise LocalServiceError(f'Serviço local respondeu HTTP {exc.code}. Confira a porta e o serviço Qwen.') from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise LocalServiceError('Qwen local indisponível ou demorou demais. Inicie a IA local e confira a porta.') from exc
        except (ValueError, UnicodeDecodeError) as exc:
            raise LocalServiceError('O serviço nesta porta não devolveu uma resposta JSON válida.') from exc

    def _read_stream(self, response, payload, timeout):
        """Read a bounded SSE response; close generation once the visible budget exists.

        Sanitization and sentence trimming still run in the existing social layer.
        No partial audio is spoken before that layer accepts the final text.
        """
        deadline=getattr(self,'_request_started',time.monotonic())+timeout
        limit=int(payload.get('_termux_visible_limit') or 240)
        parts=[];size=0;characters=0;usage={};finished=False
        while True:
            left=deadline-time.monotonic()
            if left<=0: raise LocalServiceError('Qwen local excedeu o prazo da resposta.')
            # CPython's urllib exposes the connection socket here. Mock/alternate
            # response objects can omit it; the outer HTTP timeout remains set.
            sock=getattr(getattr(getattr(response,'fp',None),'raw',None),'_sock',None)
            if sock is not None:sock.settimeout(max(.05,left))
            line=response.readline(65537)
            if not line:break
            size+=len(line)
            if len(line)>65536 or size>1_000_000:raise LocalServiceError('Fluxo local excedeu o limite.')
            if not line.startswith(b'data:'):continue
            value=line[5:].strip()
            if value==b'[DONE]':finished=True;break
            try:data=json.loads(value)
            except (ValueError,UnicodeDecodeError) as exc:raise LocalServiceError('Fluxo local inválido.') from exc
            if not isinstance(data,dict) or data.get('error'):raise LocalServiceError('Serviço local interrompeu a resposta.')
            if isinstance(data.get('usage'),dict):usage=data['usage']
            choices=data.get('choices') or []
            if not choices:continue
            choice=choices[0]
            if not isinstance(choice,dict):raise LocalServiceError('Fluxo local inválido.')
            delta=choice.get('delta') or {}
            content=delta.get('content') if isinstance(delta,dict) else None
            if content is not None:
                if not isinstance(content,str):raise LocalServiceError('Fluxo local devolveu texto inválido.')
                if content:
                    if not parts:self.diagnostics['first_token_ms']=round((time.monotonic()-self._request_started)*1000)
                    parts.append(content);characters+=len(content)
            if choice.get('finish_reason') is not None:finished=True
            if characters>limit:
                self.diagnostics.update(stopped_at_visible_limit=True,received_characters=characters)
                return {'choices':[{'message':{'content':''.join(parts)}}],'usage':usage}
        if not finished:raise LocalServiceError('Fluxo local terminou antes de confirmar a resposta.')
        text=''.join(parts)
        self.diagnostics.update(received_characters=len(text))
        return {'choices':[{'message':{'content':text}}],'usage':usage}

    def models(self, *, refresh: bool = False) -> list[str]:
        with self.lock:
            if not refresh and self.model_ids and time.monotonic() - self.models_at < 30:
                return list(self.model_ids)
            data = self._json('/v1/models')
            if not isinstance(data.get('data'), list):
                raise LocalServiceError('Catálogo de modelos locais inválido.')
            ids = []
            for item in data.get('data', []):
                if not isinstance(item, dict):
                    continue
                try:
                    model = valid_model(item.get('id'))
                except ValueError:
                    continue
                if model != 'auto' and model not in ids:
                    ids.append(model)
            if not ids:
                raise LocalServiceError('Nenhum modelo local foi anunciado em /v1/models.')
            self.model_ids, self.models_at = ids, time.monotonic()
            return list(ids)

    def health(self) -> dict:
        try:
            ids = self.models(refresh=True)
            self.diagnostics.update(ready=True, last_error=None)
            return {'ready': True, 'port': self.port, 'models': ids}
        except (LocalServiceError, TypeError) as exc:
            self.diagnostics.update(ready=False, last_error=str(exc))
            return {'ready': False, 'port': self.port, 'models': [], 'message': str(exc)}

    def reply(self, request_data: dict, *, identity: str) -> str:
        self.diagnostics['requests'] += 1
        started = time.monotonic()
        self._request_started=started
        self.diagnostics.update(first_token_ms=None,stopped_at_visible_limit=False,received_characters=None,prompt_tokens=None,completion_tokens=None,cached_prompt_tokens=None)
        try:
            model = valid_model(request_data.get('model'))
            if model == 'auto':
                model = self.models()[0]
            timeout = max(2.0, min(30.0, float(request_data.get('timeout') or 18)))
            max_chars = max(60, min(240, int(request_data.get('max_chars') or 150)))
            payload = {'model': model, 'messages': [{'role': 'system', 'content': identity + '\nResponda diretamente, em uma ou duas frases curtas. Não inclua raciocínio, rubricas ou instruções de voz. Você apenas conversa; não executa comandos do sistema.'}, {'role': 'user', 'content': str(request_data.get('prompt') or '')}], 'max_tokens': min(160, max(60, max_chars // 2 + 35)), 'temperature': 0.55, 'stream': False, 'chat_template_kwargs': {'enable_thinking': False}}
            if 'local_question' in request_data:
                system = identity + '\n' + str(request_data.get('local_personality') or '') + f'\nLimite: {max_chars} caracteres; não sacrifique a informação pela piada.'
                from .speech_names import spoken_name
                system += '\nEspectador desta conversa: ' + spoken_name(request_data.get('viewer_name')) + '. Eu/meu nas mensagens se referem ao espectador, não à cobra.'
                factual = request_data.get('local_factual') is True
                if factual:
                    system += '\nEsta pergunta pede informação: dê uma explicação simples, precisa e curta, sem piada, metáfora ou jargão desnecessário.'
                messages = [{'role': 'system', 'content': system}]
                for turn in request_data.get('conversation', [])[-2:]:
                    if isinstance(turn, dict) and isinstance(turn.get('user'), str) and isinstance(turn.get('assistant'), str):
                        messages.extend([{'role':'user','content':turn['user'][:200]}, {'role':'assistant','content':turn['assistant'][:240]}])
                question = str(request_data['local_question'])[:400]
                messages.append({'role':'user','content': question})
                payload.update(messages=messages, max_tokens=min(190, max_chars // 2 + 50), temperature=.2 if factual else .6, top_p=.85 if factual else .9, repeat_penalty=1.03)
                if request_data.get('bounded_generation',True) is True:
                    payload.update(stream=True,stream_options={'include_usage':True},_termux_visible_limit=max_chars)
            data = self._json('/v1/chat/completions', payload, timeout)
            usage=data.get('usage') if isinstance(data.get('usage'),dict) else {}
            details=usage.get('prompt_tokens_details') if isinstance(usage.get('prompt_tokens_details'),dict) else {}
            self.diagnostics.update(prompt_tokens=usage.get('prompt_tokens'),completion_tokens=usage.get('completion_tokens'),cached_prompt_tokens=details.get('cached_tokens'))
            try:
                text = data['choices'][0]['message']['content']
            except (KeyError, IndexError, TypeError) as exc:
                raise LocalServiceError('Qwen local não devolveu uma resposta de conversa válida.') from exc
            if not isinstance(text, str):
                raise LocalServiceError('Qwen local não devolveu texto.')
            text = re.sub(r'<think>.*?</think>', '', text, flags=re.I | re.S).strip()
            if not text or '<think>' in text.casefold():
                raise LocalServiceError('Qwen local não devolveu uma resposta final.')
            self.diagnostics.update(ready=True, last_error=None, selected_model=model)
            self.diagnostics['answered'] += 1
            return text
        except (LocalServiceError, ValueError, TypeError) as exc:
            self.diagnostics['failed'] += 1
            self.diagnostics.update(ready=False, last_error=str(exc))
            raise
        finally:
            self.diagnostics['latency_ms'] = round((time.monotonic() - started) * 1000)
