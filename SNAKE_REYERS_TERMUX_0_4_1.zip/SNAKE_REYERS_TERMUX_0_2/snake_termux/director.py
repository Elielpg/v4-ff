"""Operator-only counters and rendering evidence; no extra 3D render or broadcast."""
from __future__ import annotations

import json
import math
import shutil
import subprocess
import threading
import time
from pathlib import Path


def viewer_count(raw):
    if isinstance(raw, str):
        if len(raw) > 200_000: return None
        try: raw = json.loads(raw)
        except ValueError: return None
    if not isinstance(raw, dict): return None
    # roomUser.viewerCount is current audience. totalUser is not concurrent viewers.
    for candidate in (raw, raw.get('data')):
        if isinstance(candidate, dict):
            value = candidate.get('viewerCount')
            if isinstance(value, bool): continue
            try:
                count = int(value)
                if str(value).strip() == str(count) and 0 <= count <= 100_000_000: return count
            except (ValueError, TypeError): pass
    return None


class Audience:
    def __init__(self):
        self.count, self.at, self.username = None, 0, ''
        self.lock = threading.RLock()

    def update(self, raw, username):
        count = viewer_count(raw)
        if count is not None:
            with self.lock: self.count, self.at, self.username = count, time.time(), username

    def status(self, current, connected):
        with self.lock:
            same = self.username == current
            age = time.time() - self.at if self.at else None
            return {'count': self.count if same else None, 'updated_at': self.at if same else 0,
                    'age_seconds': round(age, 1) if same and age is not None else None,
                    'stale': not connected or not same or age is None or age > 30,
                    'source': 'TikTok roomUser.viewerCount', 'sent_to_game': False}


def install(binding, app):
    from fastapi.responses import FileResponse
    from cobrinha_server.services import tiktok_monitor
    audience = Audience()
    original_register = tiktok_monitor._register_handlers

    def register(client, username):
        original_register(client, username)
        client.on('data-viewer', handler=lambda raw: audience.update(raw, username))
    binding.replace_aliases(original_register, register)
    existing = getattr(tiktok_monitor, '_CLIENT', None)
    if existing is not None:
        existing.on('data-viewer', handler=lambda raw: audience.update(raw, str(tiktok_monitor.status().get('username') or '')))
    app.state.snake_audience = audience

    @app.get('/termux/director')
    def page():
        return FileResponse(Path(__file__).with_name('director.html'), headers={'Cache-Control': 'no-store'}, media_type='text/html')

    @app.get('/termux/director/status')
    def status():
        monitor = tiktok_monitor.status()
        username = str(monitor.get('username') or '')
        connected = bool(monitor.get('connected') and monitor.get('listening'))
        game = getattr(app.state, 'snake_native_game', None)
        state = game.status() if game is not None else {}
        return {'username': username, 'connected': connected, 'audience': audience.status(username, connected),
            'game': {'running': state.get('running', False), 'performance': state.get('performance', {}),
                     'graphics': state.get('device', {}).get('graphics', {})},
            'capture_note': 'Este painel não é desenhado no jogo. Capturar a tela inteira do celular pode incluí-lo ao abrir o navegador.',
            'broadcast': {'protocols': ['RTMP', 'RTMPS'], 'started_by_this_panel': False,
                'requires_tiktok_stream_key_access': True, 'recommended_capture': 'Aplicativo Android com MediaProjection e codificador H.264 por hardware; capturar somente o jogo quando disponível.',
                'desktop_pipeline': 'O original usa GStreamer/NVENC para desktop. Isso não comprova transmissão acelerada no Termux.'}}

    @app.post('/termux/director/encoder-check')
    def encoders():
        binary = shutil.which('ffmpeg')
        if not binary:
            return {'available': False, 'hardware_encoding_confirmed': False, 'message': 'FFmpeg não encontrado. Um aplicativo Android ainda pode usar MediaCodec.'}
        try:
            result = subprocess.run([binary, '-hide_banner', '-encoders'], capture_output=True, text=True, timeout=5)
            names = [name for name in ('h264_mediacodec', 'h264_v4l2m2m', 'libx264') if name in result.stdout]
            return {'available': result.returncode == 0, 'encoders': names, 'hardware_encoding_confirmed': False,
                'message': 'Lista do FFmpeg, sem iniciar captura. Presença do encoder não confirma funcionamento no aparelho. Aplicativos Android podem usar MediaCodec independentemente desta lista.'}
        except (OSError, subprocess.TimeoutExpired):
            return {'available': False, 'hardware_encoding_confirmed': False, 'message': 'A consulta de encoders falhou. Nenhuma transmissão foi iniciada.'}
