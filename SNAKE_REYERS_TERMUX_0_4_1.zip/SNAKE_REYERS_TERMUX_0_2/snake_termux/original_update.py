"""One-time reversible V040 preferences. The game pack is never rewritten."""
from pathlib import Path
import argparse
import json
import os
import shutil
import time
import uuid

from .device_runtime import atomic_json

KEYS = ('termux_live_policy', 'termux_welcome_enabled', 'termux_reply_mode')


def apply(adapter, backup=None):
    adapter = Path(adapter).resolve(); state = adapter / 'state'
    marker = state / 'original-live-v040-applied.json'
    if marker.exists(): return {'applied': False, 'reason': 'already_applied'}
    from .__main__ import configure_source
    configure_source((state / 'project-path.txt').read_text().strip())
    from cobrinha_server.services import user_ai_settings
    private = user_ai_settings.SOCIAL_TEXT_AI_CONFIG_FILE
    if backup is None:
        backup = state / 'launcher-backups' / ('original-live-v040-' + uuid.uuid4().hex)
    backup = Path(backup); backup.mkdir(parents=True, exist_ok=True)
    os.chmod(backup, 0o700)
    manifest_path = backup / 'restore-manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {'root': str(adapter), 'files': {}}
    raw = user_ai_settings._raw()
    before = {key: {'present': key in raw, 'value': raw.get(key)} for key in KEYS}
    manifest['external_settings'] = [{'path': str(private), 'keys': before}]
    names = ('state/phonk-config.json', 'state/scene-graphics-config.json', 'state/original-live-v040-applied.json')
    snapshots = {}
    for name in names:
        path = adapter / name
        snapshots[name] = path.read_bytes() if path.exists() else None
        manifest['files'][name] = path.is_file()
        if path.is_file():
            (backup / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup / name)
    atomic_json(manifest_path, manifest)
    shutil.copy2(adapter / 'tools/restore_adapter.py', backup / 'REVERTER.py')
    try:
        from .phonk import save as save_theme
        from .scene_graphics import save as save_scene
        save_theme(state, {'enabled': False})
        save_scene(state, {'enabled': True, 'decorations': True, 'welcome_garden': True,
                           'stable_render': True, 'adaptive_resolution': False})
        user_ai_settings.write_json_atomic(private, {**raw, 'termux_live_policy': True,
            'termux_welcome_enabled': True, 'termux_reply_mode': 'direct'})
        os.chmod(private, 0o600)
        atomic_json(marker, {'applied_at': time.time(), 'backup': str(backup), 'version': '0.4.0'})
    except Exception:
        for name, data in snapshots.items():
            path = adapter / name
            if data is None: path.unlink(missing_ok=True)
            else: path.write_bytes(data)
        user_ai_settings.write_json_atomic(private, raw)
        raise
    return {'applied': True, 'backup': str(backup)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('adapter', type=Path)
    parser.add_argument('--backup', type=Path)
    result = apply(**vars(parser.parse_args()))
    print('Visual original e filas V040 preparados.' if result['applied'] else 'Preferências V040 já aplicadas; escolhas posteriores preservadas.')
    if result.get('backup'): print('Reversão: python3 "' + result['backup'] + '/REVERTER.py"')
