"""Pronounceable viewer names for speech, preserving identity in the scene/HUD."""
from __future__ import annotations

import re
import unicodedata

PREFIXES = {'dj', 'mc', 'sr', 'sra', 'dr', 'dra', 'user', 'usuario', 'ofc', 'oficial', 'exe', 'real'}


def spoken_name(value, alias=''):
    text = unicodedata.normalize('NFKC', str(alias or value or '')).strip().lstrip('@')
    text = ''.join(c if c.isalpha() or c.isspace() else ' ' for c in text)
    words = text.split()
    # Stylized display names such as L I N E L must become a word, not initials.
    if len(words) >= 3 and all(len(word) == 1 for word in words):
        words = [''.join(words)]
    for word in words:
        word = word.strip()
        plain = ''.join(c for c in unicodedata.normalize('NFD', word).casefold() if not unicodedata.combining(c))
        if plain in PREFIXES or len(word) < 2 or len(word) > 22 or not re.search(r'[aeiouy]', plain):
            continue
        return word.capitalize() if word.isupper() or word.islower() else word
    return 'amigo'


def for_event(event, aliases=None):
    aliases = aliases or {}
    key = str(event.get('username') or event.get('user_id') or '').lstrip('@').casefold()
    return spoken_name(event.get('display_name') or event.get('username'), aliases.get(key, ''))


def normalize_text(text, metadata=None, aliases=None):
    """Replace known identity strings, not ordinary numbers or the whole caption."""
    metadata = metadata or {}
    clean = unicodedata.normalize('NFKC', str(text or ''))
    alias = for_event(metadata, aliases)
    candidates = {str(metadata.get('display_name') or ''), str(metadata.get('username') or '')}
    for original in sorted(candidates, key=len, reverse=True):
        if not original: continue
        normalized = unicodedata.normalize('NFKC', original).strip()
        if not normalized: continue
        clean = re.sub(r'(?<!\w)@?' + re.escape(normalized.lstrip('@')) + r'(?!\w)', alias, clean, flags=re.IGNORECASE)
    return clean
