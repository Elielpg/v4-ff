"""Explicit, loopback-only PCM relay from this game's existing PulseAudio mixer."""

import asyncio
import secrets
import shutil
import subprocess
import threading
import time
import anyio


def install(app, native):
    from fastapi import HTTPException, Request
    from fastapi.responses import StreamingResponse
    from starlette.concurrency import run_in_threadpool
    guard = threading.Lock()
    state = {'tokens': {}, 'process': None, 'active': False, 'last_error': ''}

    def local(request):
        host = request.client.host if request.client else ''
        if host not in ('127.0.0.1', '::1', 'localhost', 'testclient'):
            raise HTTPException(status_code=403, detail='A ponte de áudio é somente local.')
        origin = request.headers.get('origin', '')
        if origin and origin not in ('http://127.0.0.1:9393', 'http://localhost:9393'):
            raise HTTPException(status_code=403, detail='Origem não autorizada para áudio.')

    def source():
        if not native.status().get('running') or not native.audio_env:
            raise HTTPException(status_code=409, detail='Abra o jogo com áudio antes de usar a ponte.')
        env = dict(native.audio_env)
        # Do not access the shared server if the game was opened with Dummy.
        if native.audio_driver == 'Dummy' or not env.get('PULSE_SERVER'):
            raise HTTPException(status_code=409, detail='O jogo não tem uma saída PulseAudio própria pronta.')
        binary = shutil.which('parec', path=env.get('PATH'))
        control = shutil.which('pactl', path=env.get('PATH'))
        if not binary or not control:
            raise HTTPException(status_code=503, detail='Falta parec/pactl do PulseAudio no Termux.')
        sink = env.get('PULSE_SINK')
        if not sink:
            try:
                result = subprocess.run([control, 'get-default-sink'], env=env, capture_output=True, text=True, timeout=2)
                sink = result.stdout.strip() if result.returncode == 0 else ''
            except (OSError, subprocess.TimeoutExpired):
                sink = ''
        if not sink or len(sink) > 240 or any(c.isspace() for c in sink):
            raise HTTPException(status_code=503, detail='A saída do jogo não respondeu. Confira o áudio no painel.')
        return binary, sink + '.monitor', env

    def stop(process):
        if process and process.poll() is None:
            process.terminate()
            try: process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=2)

    @app.post('/termux/studio/audio/authorize')
    async def authorize(request: Request):
        local(request)
        await run_in_threadpool(source)
        with guard:
            now = time.monotonic()
            state['tokens'] = {key: expiry for key, expiry in state['tokens'].items() if expiry > now}
            if state['active']:
                raise HTTPException(status_code=409, detail='A ponte já está sendo usada por uma captura.')
            if len(state['tokens']) >= 4:
                raise HTTPException(status_code=429, detail='Aguarde expirar a autorização anterior.')
            token = secrets.token_hex(32)
            state['tokens'][token] = now + 30
        return {'token': token, 'expires_in': 30, 'sample_rate': 48000, 'channels': 2,
                'format': 's16le', 'source': 'Somente o mixer deste jogo; não captura outros aplicativos.'}

    @app.get('/termux/studio/audio/status')
    def status():
        with guard:
            return {'active': state['active'], 'last_error': state['last_error'], 'scope': 'mixer do jogo',
                    'sample_rate': 48000, 'channels': 2, 'format': 's16le'}

    @app.get('/termux/studio/audio/pcm')
    async def pcm(request: Request):
        local(request)
        value = request.headers.get('authorization', '')
        token = value[7:] if value.startswith('Bearer ') else ''
        with guard:
            expiry = state['tokens'].pop(token, 0)
            if not token or expiry <= time.monotonic():
                raise HTTPException(status_code=401, detail='Autorize uma nova sessão de áudio no aplicativo.')
            if state['active']:
                raise HTTPException(status_code=409, detail='A ponte já está ocupada.')
            state['active'] = True
        process = None
        try:
            binary, monitor, env = await run_in_threadpool(source)
            process = subprocess.Popen([binary, '--raw', '--device=' + monitor, '--format=s16le', '--rate=48000', '--channels=2'],
                env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            with guard: state.update(process=process, last_error='')
        except Exception:
            with guard: state.update(active=False, process=None, last_error='Falha ao abrir o monitor de áudio do jogo.')
            if process: await run_in_threadpool(stop, process)
            raise

        async def stream():
            try:
                while process.poll() is None:
                    block = await asyncio.to_thread(process.stdout.read, 4096)
                    if not block: break
                    yield block
            finally:
                with anyio.CancelScope(shield=True):
                    await asyncio.to_thread(stop, process)
                    process.stdout.close()
                    with guard: state.update(process=None, active=False)
        return StreamingResponse(stream(), media_type='application/octet-stream', headers={
            'Cache-Control': 'no-store', 'X-Cofra-PCM': 's16le;rate=48000;channels=2', 'X-Content-Type-Options': 'nosniff'})

    @app.on_event('shutdown')
    def shutdown():
        with guard: process = state['process']
        stop(process)
