"""Private, bounded timings of the response pipeline, without chat text or keys."""
from __future__ import annotations
import contextvars
import os
import threading
import time
import uuid
from collections import deque

_CONTEXT=contextvars.ContextVar('snake_response_timing',default=None)


def install(binding,app):
    from fastapi import HTTPException
    from cobrinha_server.services import event_decision_worker as worker,speech_queue
    from cobrinha_server.bridge.godot_bridge import godot_bridge
    lock=threading.RLock();traces=deque(maxlen=32);jobs={}
    original_comment=worker._process_comment;original_enqueue=worker.enqueue_text
    original_prepare=speech_queue.prepare_pending_job;original_send=godot_bridge.send;original_remember=godot_bridge.remember
    original_transport=binding.transport

    def settings():
        raw=binding.settings._raw()
        return {'bounded_generation':raw.get('termux_bounded_generation',True) is True,
                'early_focus':raw.get('termux_early_focus',True) is True}
    binding.responsive_settings=settings

    def mark(field,record=...):
        record=_CONTEXT.get() if record is ... else record
        if record is not None:
            with lock:record[field]=round((time.monotonic()-record['_start'])*1000)
    binding.response_mark=mark

    async def comment(event):
        now=time.time();created=event.get('created_at');age=max(0,now-created)*1000 if isinstance(created,(int,float)) else None
        record={'id':uuid.uuid4().hex[:16],'_start':time.monotonic(),'at':now,'queue_wait_ms':round(age) if age is not None else None}
        with lock:traces.append(record)
        token=_CONTEXT.set(record)
        try:
            result=await original_comment(event);mark('text_queued_ms',record);return result
        except Exception:
            record['error']='comment_preparation_failed';raise
        finally:_CONTEXT.reset(token)

    def transport(data):
        record=_CONTEXT.get();start=time.monotonic()
        try:return original_transport({**data,'bounded_generation':settings()['bounded_generation']})
        finally:
            if record is not None:
                with lock:
                    record['ai_ms']=round((time.monotonic()-start)*1000)
                    client=getattr(binding,'client',None)
                    if client:
                        d=client.diagnostics
                        record.update(first_token_ms=d.get('first_token_ms'),stopped_at_visible_limit=d.get('stopped_at_visible_limit'),
                                      prompt_tokens=d.get('prompt_tokens'),completion_tokens=d.get('completion_tokens'),cached_prompt_tokens=d.get('cached_prompt_tokens'))
    binding.transport=transport

    def enqueue(text,**kwargs):
        record=_CONTEXT.get()
        if record is not None:
            metadata=dict(kwargs.get('metadata') or {});metadata['_termux_response_trace']=record['id'];kwargs={**kwargs,'metadata':metadata}
        job=original_enqueue(text,**kwargs)
        if record is not None and job.get('id'):
            with lock:
                jobs[job['id']]=record
                if len(jobs)>128:
                    for key in list(jobs)[:-128]:jobs.pop(key,None)
        return job

    def record_for(job):
        if not isinstance(job,dict):return None
        with lock:
            record=jobs.get(str(job.get('id') or job.get('job_id') or ''))
            if record is not None:return record
            trace=(job.get('metadata') or {}).get('_termux_response_trace')
            return next((r for r in traces if r['id']==trace),None) if trace else None

    def prepare(job):
        record=record_for(job);start=time.monotonic();mark('tts_started_ms',record)
        try:
            result=original_prepare(job);mark('audio_ready_ms',record);return result
        except Exception:
            if record is not None:record['error']='voice_preparation_failed'
            raise
        finally:
            if record is not None:
                with lock:record['tts_ms']=round((time.monotonic()-start)*1000)

    async def send(message):
        if isinstance(message,dict) and message.get('type')=='speech_ready':
            record=record_for(message.get('payload') or {});mark('dispatch_requested_ms',record)
            result=await original_send(message)
            if record is not None:
                with lock:record['dispatch_sent']=bool(result)
            return result
        return await original_send(message)

    async def remember(message):
        if isinstance(message,dict):
            record=record_for(message)
            if record is not None:
                if message.get('type')=='speech_started':mark('speech_started_ms',record)
                elif message.get('type')=='speech_finished':mark('speech_finished_ms',record)
        return await original_remember(message)

    binding.replace_aliases(original_comment,comment);binding.replace_aliases(original_enqueue,enqueue);binding.replace_aliases(original_prepare,prepare)
    for name,replacement,original in (('send',send,original_send),('remember',remember,original_remember)):
        binding.replacements.append((godot_bridge,name,original));setattr(godot_bridge,name,replacement)

    @app.get('/termux/responsiveness')
    def status():
        with lock:rows=[{k:v for k,v in r.items() if k!='_start'} for r in traces]
        return {'settings':settings(),'traces':rows,'limit':32,
                'providers':{'text':binding.config()['provider'],'voice':binding.voice_config()['provider']},
                'termux_origin':os.environ.get('TERMUX_APK_RELEASE'),'termux_version':os.environ.get('TERMUX_VERSION'),
                'scope':'Timings of this server session only. No usernames, questions, answers or keys. Viewer selection is not proof of camera movement.'}

    @app.post('/termux/responsiveness')
    def save(payload:dict):
        allowed={'bounded_generation','early_focus'}
        if not payload or set(payload)-allowed or any(type(v) is not bool for v in payload.values()):
            raise HTTPException(status_code=400,detail='Opções de resposta inválidas.')
        raw=binding.settings._raw()
        for key,value in payload.items():raw['termux_'+key]=value
        binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,raw)
        os.chmod(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,0o600)
        return status()
