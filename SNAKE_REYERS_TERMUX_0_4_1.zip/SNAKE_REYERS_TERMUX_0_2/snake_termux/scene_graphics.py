"""Optional runtime graphics layer; uses Godot's public API, never unpacks a game."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .device_runtime import atomic_json

SCRIPT=Path(__file__).resolve().parent/'godot/scene_graphics.gd'
PRESETS={
    'fluid':{'label':'GT3 fluido','scale':.82,'minimum_scale':.65,'maximum_scale':.90,'target_fps':30,'shadow_size':1024,'msaa':0},
    'balanced':{'label':'Equilibrado','scale':.92,'minimum_scale':.75,'maximum_scale':1.0,'target_fps':30,'shadow_size':2048,'msaa':0},
    'detail':{'label':'Mais detalhe','scale':1.0,'minimum_scale':.85,'maximum_scale':1.0,'target_fps':30,'shadow_size':2048,'msaa':1},
}
DEFAULTS={'enabled':False,'preset':'fluid','decorations':True,'adaptive_resolution':True,'terrain_filtering':True,'terrain_colors':True,'stable_render':True,'welcome_garden':False,'static_batching':False,'camera_smoothing':False}


def settings(state):
    try:raw=json.loads((Path(state)/'scene-graphics-config.json').read_text())
    except (OSError,ValueError):raw={}
    if not isinstance(raw,dict):raw={}
    result=dict(DEFAULTS)
    for key in ('enabled','decorations','adaptive_resolution','terrain_filtering','terrain_colors','stable_render','welcome_garden','static_batching','camera_smoothing'):
        if type(raw.get(key)) is bool:result[key]=raw[key]
    if isinstance(raw.get('preset'),str) and raw['preset'] in PRESETS:result['preset']=raw['preset']
    return result


def save(state,payload):
    if not payload or set(payload)-set(DEFAULTS):raise ValueError('Ajuste gráfico desconhecido.')
    for key,value in payload.items():
        if key=='preset':
            if not isinstance(value,str) or value not in PRESETS:raise ValueError('Escolha um perfil gráfico disponível.')
        elif type(value) is not bool:raise ValueError('Os controles gráficos devem ser ativados ou desativados.')
    result={**settings(state),**payload};atomic_json(Path(state)/'scene-graphics-config.json',result);return result


def launch(env,args,state):
    """Preserve editor/custom scripts; attach only to the normal original live/preview."""
    selected=settings(state)
    try:
        from . import phonk
        theme=phonk.settings(state)['enabled']
        stable=phonk.settings(state)['stable_render'] if theme else selected['stable_render']
        theme_script=phonk.SCRIPT
    except ImportError:
        theme=False
        stable=selected['stable_render']
        theme_script=None
    divider=args.index('--') if '--' in args else len(args)
    own_mode=any(value in args[divider:] for value in ('--cobrinha-live','--cobrinha-preview'))
    if not (selected['enabled'] or theme) or not own_mode or '--script' in args[:divider] or '-s' in args[:divider]:return dict(env),list(args)
    state=Path(state).resolve()
    dependencies=('render_pipeline.gd','camera_filter.gd','static_batches.gd')
    if not SCRIPT.is_file() or not all(SCRIPT.with_name(name).is_file() for name in dependencies):
        atomic_json(state/'scene-graphics-warning.json',{'message':'Complemento gráfico incompleto; abertura preservada com o visual original. Reaplique a atualização para recuperar os detalhes.'})
        print('Complemento gráfico ausente; abrindo o jogo original.',flush=True)
        return dict(env),list(args)
    (state/'scene-graphics-warning.json').unlink(missing_ok=True)
    config={**selected,**PRESETS[selected['preset']]}
    config['stable_render']=stable
    if stable:
        config['adaptive_resolution']=False
        config['msaa']=0
    if not selected['enabled']:config['adaptive_resolution']=False
    atomic_json(state/'scene-graphics-launch.json',config)
    # A status file belongs to this launch, never to a previous game process.
    (state/'scene-graphics-runtime.json').unlink(missing_ok=True)
    output={**env,'SNAKE_SCENE_GRAPHICS_CONFIG':str(state/'scene-graphics-launch.json'),
            'SNAKE_SCENE_GRAPHICS_STATUS':str(state/'scene-graphics-runtime.json')}
    entry=SCRIPT
    if theme and theme_script is not None and theme_script.is_file() and phonk.available() and (state/'phonk-config.json').exists():
        entry=theme_script
        output=phonk.launch(output,state)
    selected_args=list(args)
    renderer=env.get('SNAKE_EFFECTIVE_RENDERER',env.get('SNAKE_RENDERER','gl_compatibility'))
    if renderer=='mobile':
        if env.get('PREFIX','').startswith('/data/'):
            for key in ('GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LIBGL_ALWAYS_SOFTWARE','LP_NUM_THREADS'):
                output.pop(key,None)
    return output,['--script',str(entry),*selected_args]


def status(state):
    current=settings(state);runtime=None;warning=None
    try:
        path=Path(state)/'scene-graphics-runtime.json'
        if path.stat().st_size<65536:
            data=json.loads(path.read_text())
            if isinstance(data,dict):runtime=data
    except (OSError,ValueError):pass
    try:
        data=json.loads((Path(state)/'scene-graphics-warning.json').read_text())
        if isinstance(data,dict) and isinstance(data.get('message'),str):warning=data['message'][:300]
    except (OSError,ValueError):pass
    return {'settings':current,'presets':PRESETS,'runtime':runtime,
            'warning':warning if current['enabled'] else None,
            'runtime_age_seconds':round(max(0,time.time()-runtime.get('at',0)),1) if runtime else None,
            'restart_required':True,'original_pack_modified':False}


def install(app,native):
    from fastapi import HTTPException
    @app.get('/termux/scene-graphics')
    def read():return status(native.state_dir)
    @app.post('/termux/scene-graphics')
    def write(payload:dict):
        try:save(native.state_dir,payload)
        except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
        return status(native.state_dir)
