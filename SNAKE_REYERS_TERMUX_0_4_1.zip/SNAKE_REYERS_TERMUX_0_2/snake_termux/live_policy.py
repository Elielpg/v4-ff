"""Optional receipt-first LIVE policy installed on public Python service hooks.

The original game and gift effects still execute in the upstream worker.
Only admission, scheduling and thanks persistence are controlled here.
"""
from __future__ import annotations

import asyncio
import contextvars
import threading
import time
from pathlib import Path

from .live_queue import LiveQueue
from .speech_names import spoken_name

_CONTEXT = contextvars.ContextVar('snake_live_policy', default=None)


def install(binding, app):
    from fastapi import HTTPException
    from cobrinha_server.services import event_decision_worker as worker, live_events, speech_queue, tiktok_monitor, tts_worker
    from cobrinha_server.bridge.godot_bridge import godot_bridge

    original_write = live_events._write_state
    original_comment = live_events.push_comment
    original_gift = live_events.push_gift
    original_pop = live_events.pop_next_event
    original_status = live_events.status
    original_reset = live_events.reset
    original_has = live_events.has_pending_reactions
    original_once = worker.process_once
    original_gate = worker._speech_pipeline_can_accept_next
    original_process_gift = worker._process_gift
    original_gift_reply = worker._gift_reply
    original_group = worker._gift_group_ready
    original_should_thank = worker._should_thank_individual_gift
    original_enqueue = worker.enqueue_text
    original_ready = speech_queue.push_ready
    original_next = speech_queue.pop_next
    original_ack = speech_queue.acknowledge_speech_finished
    original_prune = speech_queue._prune_old_jobs
    original_remember = godot_bridge.remember
    original_register = tiktok_monitor._register_handlers
    policy_lock = threading.RLock()
    admission_lock = threading.RLock()
    process_lock = asyncio.Lock()
    database = [None]
    last_recovery = [0.0]

    def enabled():
        return binding.settings._raw().get('termux_live_policy') is True

    def queue():
        with policy_lock:
            if database[0] is None:
                private = Path(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE).resolve().parent
                database[0] = LiveQueue(private / 'termux_live_queue.sqlite3')
            return database[0]

    def write(state):
        if enabled():
            with policy_lock:
                for kind in ('gifts', 'comments'):
                    rejected = set()
                    for event in state.get(kind) or []:
                        if isinstance(event, dict) and not queue().ingest(event): rejected.add(event.get('id'))
                    if kind == 'comments' and rejected:
                        state['preview_comments'] = [e for e in state.get('preview_comments') or [] if e.get('id') not in rejected]
                    # Preview copies and dedup remain with the original service.
                    # Unbounded gifts are held on disk, not truncated to 12.
                    state[kind] = []
        return original_write(state)

    def import_waiting():
        with live_events._LOCK:
            state = live_events._read_state()
            if state.get('gifts') or state.get('comments'): write(state)

    def comment(payload):
        if not enabled(): return original_comment(payload)
        with admission_lock:
            # Preserve the last accepted dedup entry when admission is rejected.
            user = live_events.normalize_social_user(payload)
            key = live_events._comment_user_key(payload, user)
            with live_events._LOCK:
                before = (live_events._read_state().get('comment_dedup') or {}).get(key)
            event = original_comment(payload)
            if not event.get('ignored') and not queue_contains(event['id']):
                with live_events._LOCK:
                    state = live_events._read_state()
                    if before is None: state['comment_dedup'].pop(key, None)
                    else: state['comment_dedup'][key] = before
                    write(state)
                return {**event, 'ignored': True, 'reason': 'comment_queue_full'}
            return event

    def queue_contains(event_id):
        q = queue()
        with q.lock: return q.db.execute('SELECT 1 FROM events WHERE id=?', (event_id,)).fetchone() is not None

    def gift(payload):
        if not enabled(): return original_gift(payload)
        with admission_lock:
            event = original_gift(payload)
            if not event.get('ignored') and not queue_contains(event['id']):
                return {**event, 'ignored': True, 'reason': 'duplicate_gift'}
            return event

    def pop():
        if not enabled(): return original_pop()
        event = queue().claim(allow_welcome=not speech_queue.active_job())
        record = _CONTEXT.get()
        if event:
            if record is not None: record['event'] = event
            return {**event, 'kind': 'system', 'text': welcome_text(event), 'priority': 20} if event['kind'] == 'welcome' else event
        if queue().next_kind(): return None
        return original_pop()

    def welcome_text(event):
        names = [spoken_name(u.get('display_name') or u.get('username')) for u in event.get('users', [])]
        suffix = f" e mais {event['count'] - len(names)} pessoas" if event.get('count', 0) > len(names) else ''
        return 'Bem-vindos, ' + ', '.join(names) + suffix + '! Chega mais e manda sua pergunta pra cobra!'

    def status():
        result = original_status()
        if enabled():
            s = queue().status()
            result.update(comments_pending=s['comments_waiting'], gifts_pending=s['gifts_waiting'], live_policy=s)
        return result

    def has():
        return bool(queue().next_kind()) or original_has() if enabled() else original_has()

    def reset():
        if enabled(): queue().reset_transient()
        return original_reset()

    def gate():
        if not enabled(): return original_gate()
        if worker.song_runtime.singing_blocks_speech() or worker.godot_runtime_state.heart_me_band_music_showcase_active(): return False
        state = worker.speech_queue_status()
        if state.get('manual_sequence', {}).get('active') or state.get('active_pair') or state.get('pair_waiting_size'): return False
        kind = queue().next_kind()
        preparing = worker.tts_worker_status()
        if state.get('pending_size') or state.get('ready_size') or preparing.get('state') == 'preparing':
            # One gift may pass a prefetched comment. Never prepare two gifts
            # out of order or create a second unbounded speech backlog.
            if kind != 'gift': return False
            q = queue()
            with q.lock:
                return not q.db.execute("SELECT 1 FROM events WHERE kind='gift' AND status IN ('processing','enqueued','ready','playing') LIMIT 1").fetchone()
        return not state.get('active') or kind in ('gift', 'comment')

    def known_jobs():
        jobs = set()
        with speech_queue._LOCK:
            for path in (speech_queue.PENDING_QUEUE_FILE, speech_queue.READY_QUEUE_FILE):
                jobs.update(str(j.get('id') or '') for j in speech_queue._read_list(path))
            active = speech_queue.active_job()
            if active: jobs.add(str(active.get('id') or ''))
        preparing = worker.tts_worker_status()
        thread = getattr(tts_worker, '_WORKER_THREAD', None)
        if preparing.get('state') == 'preparing' and thread is not None and thread.is_alive():
            jobs.add(str(preparing.get('job_id') or ''))
        return jobs

    async def once():
        if not enabled(): return await original_once()
        async with process_lock:
            import_waiting()
            if time.monotonic()-last_recovery[0] > 2:
                queue().recover_missing(known_jobs()); last_recovery[0] = time.monotonic()
            record = {}
            token = _CONTEXT.set(record)
            try:
                return await original_once()
            except Exception:
                if record.get('event'): queue().failed(record['event']['id'], 'event_preparation_failed')
                raise
            finally:
                _CONTEXT.reset(token)

    def thank_text(event):
        name = spoken_name(event.get('display_name') or event.get('username'))
        metadata = event.get('metadata') or {}
        count = max(1, int(metadata.get('count') or 1))
        gift_name = ' '.join(str(metadata.get('gift_name') or event.get('text') or 'presente').split())[:48]
        endings = ('Valeu pela força!', 'A cobra agradece. Agora o caos está patrocinado!', 'Obrigado! Isso sim é alimentar o caos.')
        return f'{name}, recebi {count} de {gift_name}! ' + endings[sum(str(event['id']).encode()) % len(endings)]

    def gift_reply(event, **kwargs):
        return thank_text(event) if enabled() and _CONTEXT.get() is not None else original_gift_reply(event, **kwargs)

    async def process_gift(event):
        record = _CONTEXT.get()
        if not enabled() or record is None: return await original_process_gift(event)
        if not event.get('_queue_effects_started'):
            queue().effects_started(event['id'])
            result = await original_process_gift(event)
        else:
            result = {'ok': True, 'kind': 'gift', 'effects_already_attempted': True}
        if not record.get('job'):
            job = worker.enqueue_text(thank_text(event), priority=200, actor='main', metadata={
                'source': 'social_gift', 'event_id': event['id'], 'speaker': 'main',
                'display_name': event.get('display_name') or '', 'username': event.get('username') or ''})
            result = {**result, 'job': job, 'thanked': True}
        return result

    def group(**kwargs):
        return [] if enabled() and _CONTEXT.get() is not None else original_group(**kwargs)

    def should_thank(event, **kwargs):
        return (True, '') if enabled() and _CONTEXT.get() is not None else original_should_thank(event, **kwargs)

    def enqueue(text, **kwargs):
        record = _CONTEXT.get()
        if not enabled() or not record or not record.get('event'): return original_enqueue(text, **kwargs)
        event = record['event']; metadata = dict(kwargs.get('metadata') or {})
        metadata.update(_termux_live_event=event['id'], _termux_live_kind=event['kind'])
        if event['kind'] == 'welcome': metadata['source'] = 'arrival_batch'
        # Every gift has the same priority; the receipt sequence decides order.
        if event['kind'] == 'gift': kwargs['priority'] = 200
        job = original_enqueue(text, **{**kwargs, 'metadata': metadata})
        if job.get('id'):
            queue().attach(event['id'], job['id']); record['job'] = job
        else:
            queue().failed(event['id'], 'speech_not_enqueued')
        return job

    def ready(job):
        event_id = (job.get('metadata') or {}).get('_termux_live_event')
        row = queue().event(event_id) if enabled() and event_id else (queue().job(job.get('id')) if enabled() else None)
        if row:
            # A cached synthesis can finish before enqueue_text returns.
            # Attach it here, and reject stale audio from an earlier attempt.
            if row['status'] == 'processing' and not row['job_id']:
                queue().attach(row['id'], job.get('id')); row = queue().event(row['id'])
            if row['job_id'] != job.get('id') or row['status'] in ('done', 'blocked', 'retry'): return None
        if row and job.get('prepare_error'):
            queue().failed(row['id'], 'voice_preparation_failed')
            return None
        result = original_ready(job)
        if row: queue().update_job(job['id'], 'ready')
        return result

    def next_job():
        if enabled() and queue().next_kind() == 'gift':
            with speech_queue._LOCK:
                jobs = speech_queue._sort_jobs(speech_queue._read_list(speech_queue.READY_QUEUE_FILE))
            if jobs and (jobs[0].get('metadata') or {}).get('_termux_live_kind') != 'gift':
                if not (jobs[0].get('metadata') or {}).get('manual_sequence_id'): return None
        return original_next()

    def ack(job_id, **kwargs):
        result = original_ack(job_id, **kwargs)
        if enabled() and result.get('acknowledged'): queue().finish(job_id)
        return result

    def prune(jobs, *, max_age):
        if not enabled(): return original_prune(jobs, max_age=max_age)
        durable = [j for j in jobs if (j.get('metadata') or {}).get('_termux_live_kind') in ('gift', 'comment')]
        ordinary = [j for j in jobs if (j.get('metadata') or {}).get('_termux_live_kind') not in ('gift', 'comment')]
        return durable + original_prune(ordinary, max_age=max_age)

    async def remember(message):
        result = await original_remember(message)
        if enabled() and isinstance(message, dict) and message.get('type') == 'speech_started':
            queue().update_job(str(message.get('job_id') or ''), 'playing')
        return result

    def member(raw):
        if not enabled() or binding.settings._raw().get('termux_welcome_enabled', True) is not True: return
        data = tiktok_monitor._parse_payload(raw)
        user = {'username': tiktok_monitor._username(data), 'user_id': tiktok_monitor._user_id(data),
                'display_name': tiktok_monitor._display_name(data)[:80]}
        queue().member(user)

    def register(client, username):
        original_register(client, username)
        client.on('data-member', handler=member)

    for old, new in ((original_write, write), (original_comment, comment), (original_gift, gift),
            (original_pop, pop), (original_status, status), (original_reset, reset), (original_has, has),
            (original_once, once), (original_gate, gate), (original_process_gift, process_gift),
            (original_gift_reply, gift_reply), (original_group, group), (original_should_thank, should_thank),
            (original_enqueue, enqueue), (original_ready, ready), (original_next, next_job),
            (original_ack, ack), (original_prune, prune), (original_register, register)):
        binding.replace_aliases(old, new)
    binding.replacements.append((godot_bridge, 'remember', original_remember))
    godot_bridge.remember = remember
    existing = getattr(tiktok_monitor, '_CLIENT', None)
    if existing is not None: existing.on('data-member', handler=member)

    app.state.snake_live_queue = queue

    @app.get('/termux/live-policy')
    def read():
        return {'enabled': enabled(), 'welcome_enabled': binding.settings._raw().get('termux_welcome_enabled', True),
                'queue': queue().status() if enabled() else None,
                'note': 'Presentes recebidos: prioridade e ordem de chegada. Até 3 comentários esperando; os demais são ignorados para resposta. Boas-vindas agrupadas, após perguntas e presentes.'}

    @app.post('/termux/live-policy')
    def save(payload: dict):
        if set(payload) != {'welcome_enabled'} or type(payload['welcome_enabled']) is not bool:
            raise HTTPException(status_code=400, detail='Informe welcome_enabled como verdadeiro ou falso.')
        raw = binding.settings._raw(); raw['termux_welcome_enabled'] = payload['welcome_enabled']
        binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
        return read()

    @app.post('/termux/live-policy/retry-gift')
    def retry():
        return {**read(), 'retried': queue().retry_gift() if enabled() else False}

    def close_queue():
        if database[0] is not None: database[0].close(); database[0] = None
    app.add_event_handler('shutdown', close_queue)
