"""Read-only process measurements and bounded settings for owned AI children."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

DEFAULTS = {'text_threads': 3, 'text_batch_threads': 3, 'voice_threads': 2, 'text_nice': 0}


def inference_settings(state):
    try:
        data = json.loads((Path(state) / 'performance-config.json').read_text())
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict): data = {}
    result = dict(DEFAULTS)
    for key, maximum in (('text_threads', 4), ('text_batch_threads', 4), ('voice_threads', 2), ('text_nice', 10)):
        value = data.get(key)
        if type(value) is int and (0 if key == 'text_nice' else 1) <= value <= maximum:
            result[key] = value
    return result


def proc_stat(path):
    text = Path(path).read_text()
    end = text.rindex(')'); fields = text[end + 2:].split()
    return {'ticks': int(fields[11]) + int(fields[12]), 'rss_pages': int(fields[21]),
            'threads': int(fields[17]), 'major_faults': int(fields[9]),
            'ppid': int(fields[1]), 'start_ticks': int(fields[19]), 'name': text[text.index('(') + 1:end][:40]}


class Sampler:
    def __init__(self, proc=Path('/proc'), sysfs=Path('/sys')):
        self.proc, self.sysfs = Path(proc), Path(sysfs)
        self.previous = {}
        self.lock = threading.RLock()
        self.hz = os.sysconf('SC_CLK_TCK')
        self.pages = os.sysconf('SC_PAGE_SIZE')

    def process(self, pid, label, now):
        root = self.proc / str(pid)
        try:
            # Measure only same-UID processes, never arbitrary requested PIDs.
            if root.stat().st_uid != os.getuid(): return None
            status = (root / 'status').read_text()
            info = proc_stat(root / 'stat')
            previous = self.previous.get(pid)
            if previous and previous.get('start_ticks') != info['start_ticks']: previous = None
            allowed = next((line.split(':', 1)[1].strip() for line in status.splitlines() if line.startswith('Cpus_allowed_list:')), None)
            elapsed = now - previous['at'] if previous else 0
            cpu = max(0, (info['ticks'] - previous['ticks']) / self.hz / elapsed * 100) if previous and elapsed > .1 else None
            faults = max(0, info['major_faults'] - previous['major_faults']) if previous else None
            tasks, hot = {}, []
            for path in sorted((root / 'task').glob('*/stat'))[:128]:
                try:
                    tid = int(path.parent.name); value = proc_stat(path); tasks[tid] = value['ticks']
                    before = previous.get('tasks', {}).get(tid) if previous else None
                    if before is not None and elapsed > .1:
                        hot.append({'name': value['name'], 'cpu_percent_one_core': round(max(0, value['ticks'] - before) / self.hz / elapsed * 100, 1)})
                except (OSError, ValueError, IndexError): pass
            self.previous[pid] = {'at': now, 'start_ticks': info['start_ticks'], 'ticks': info['ticks'], 'major_faults': info['major_faults'], 'tasks': tasks}
            return {'label': label, 'pid': pid, 'cpu_percent_one_core': round(cpu, 1) if cpu is not None else None,
                    'rss_mb': round(info['rss_pages'] * self.pages / 1048576, 1), 'threads': info['threads'],
                    'allowed_cpus': allowed, 'major_faults_delta': faults,
                    'hot_threads': sorted(hot, key=lambda x: x['cpu_percent_one_core'], reverse=True)[:3]}
        except (OSError, ValueError, IndexError):
            return None

    def system(self):
        result = {'available_memory_mb': None, 'gpu_busy_percent': None, 'gpu_busy_scope': 'system-wide, not game-only', 'temperatures': []}
        try:
            for line in (self.proc / 'meminfo').read_text().splitlines():
                if line.startswith('MemAvailable:'): result['available_memory_mb'] = round(int(line.split()[1]) / 1024)
        except (OSError, ValueError, IndexError): pass
        try:
            values = (self.sysfs / 'class/kgsl/kgsl-3d0/gpubusy').read_text().split()
            busy, total = int(values[0]), int(values[1])
            if total > 0 and 0 <= busy <= total: result['gpu_busy_percent'] = round(busy / total * 100, 1)
        except (OSError, ValueError, IndexError): pass
        for root in sorted((self.sysfs / 'class/thermal').glob('thermal_zone*'))[:80]:
            try:
                name = (root / 'type').read_text().strip()
                if not any(x in name.lower() for x in ('cpu', 'gpu', 'soc', 'battery', 'skin')): continue
                value = float((root / 'temp').read_text())
                if value > 1000: value /= 1000
                if 10 <= value <= 120: result['temperatures'].append({'sensor': name[:60], 'celsius': round(value, 1)})
            except (OSError, ValueError): pass
        return result

    def sample(self, state, game):
        with self.lock:
            now = time.monotonic()
            state = Path(state); status = game.status()
            pids = [(status.get('pid'), 'jogo')]
            try:
                data = json.loads((state / 'ai-services.json').read_text())
                for pid in data.get('owned_pids', []):
                    if type(pid) is int and pid > 0:
                        label = 'IA/voz própria'
                        try:
                            comm = (self.proc / str(pid) / 'comm').read_text().lower()
                            label = 'Qwen próprio' if 'llama' in comm else label
                        except OSError: pass
                        pids.append((pid, label))
                        # proot can be a launcher; include its actual owned workers.
                        descendants = [pid]; visited = {pid}
                        while descendants and len(visited) < 32:
                            parent = descendants.pop(0)
                            try:
                                children = (self.proc / str(parent) / 'task' / str(parent) / 'children').read_text().split()
                            except OSError:
                                children = []
                                for candidate in list(self.proc.glob('[0-9]*'))[:1024]:
                                    try:
                                        if candidate.stat().st_uid == os.getuid() and proc_stat(candidate / 'stat')['ppid'] == parent: children.append(candidate.name)
                                    except (OSError, ValueError, IndexError): pass
                            for child in children[:32]:
                                if not child.isdigit(): continue
                                child = int(child)
                                if child in visited: continue
                                visited.add(child); descendants.append(child)
                                pids.append((child, label + ' / processo filho'))
            except (OSError, ValueError, AttributeError): pass
            values = []
            seen = set()
            for pid, label in pids:
                if type(pid) is int and pid > 0 and pid not in seen:
                    seen.add(pid); value = self.process(pid, label, now)
                    if value: values.append(value)
            self.previous = {pid: v for pid, v in self.previous.items() if pid in seen}
            return {'measured_at': time.time(), 'processes': values, 'system': self.system(),
                    'render': status.get('performance', {}), 'audio': status.get('audio_runtime', {}),
                    'note': 'CPU 100% significa um núcleo ocupado. Valores ausentes indicam dado não permitido/disponível. GPU é do sistema inteiro.'}


class Recorder:
    """One bounded server-side recording continues when Chrome is backgrounded."""
    def __init__(self, sampler, state, native, interval=3, count=6):
        self.sampler, self.state, self.native = sampler, state, native
        self.interval, self.count = interval, count
        self.stop_event=threading.Event();self.lock=threading.RLock()
        self.thread=None;self.report={'running':False,'samples':[]}

    def status(self):
        with self.lock:
            return {**self.report,'samples':list(self.report['samples'])}

    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive(): return self.status()
            self.stop_event.clear();self.report={'running':True,'samples':[],'started_at':time.time()}
            def run():
                try:
                    for index in range(self.count):
                        if self.stop_event.is_set():break
                        value=self.sampler.sample(self.state,self.native)
                        with self.lock:self.report['samples'].append(value)
                        if index<self.count-1 and self.stop_event.wait(self.interval):break
                except Exception:
                    with self.lock:self.report['error']='Leitura de desempenho interrompida; o jogo permanece independente.'
                finally:
                    with self.lock:self.report['running']=False;self.report['finished_at']=time.time()
            self.thread=threading.Thread(target=run,name='snake-metrics',daemon=True);self.thread.start()
            return self.status()

    def stop(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=2)


def install(app, native):
    from fastapi import HTTPException
    from .device_runtime import atomic_json
    sampler = Sampler(); state = native.state_dir
    recorder=Recorder(sampler,state,native)

    @app.post('/termux/performance/record')
    def start_recording(): return recorder.start()

    @app.get('/termux/performance/record')
    def read_recording(): return recorder.status()

    app.add_event_handler('shutdown',recorder.stop)

    @app.get('/termux/performance')
    def metrics():
        return sampler.sample(state, native)

    @app.get('/termux/performance/settings')
    def settings():
        return {'settings': inference_settings(state), 'restart_required': True,
                'scope': 'Apenas os serviços Qwen/Piper iniciados por este complemento. Serviços externos permanecem preservados.'}

    @app.get('/termux/game/engine')
    def engine():
        return {'configured': renderer_settings(state), 'active': native.renderer,
                'restart_required': True, 'direct_vulkan_device_validation': 'pending',
                'note': 'Vulkan direto evita a tradução OpenGL/Zink. O painel mantém OpenGL para comparação e reversão; o ganho sustentado no GT3 precisa ser medido.'}

    @app.post('/termux/game/engine')
    def save_engine(payload: dict):
        if set(payload) != {'renderer'} or payload['renderer'] not in ('gl_compatibility','mobile'):
            raise HTTPException(status_code=400, detail='Motor gráfico inválido.')
        path=state/'render-config.json'
        if path.exists() and not (state/'render-config-before-v034.json').exists():
            (state/'render-config-before-v034.json').write_bytes(path.read_bytes())
        atomic_json(path,payload)
        return engine()

    @app.post('/termux/performance/settings')
    def save(payload: dict):
        if not payload or set(payload) - set(DEFAULTS):
            raise HTTPException(status_code=400, detail='Opções de recursos inválidas.')
        for key, value in payload.items():
            low = 0 if key == 'text_nice' else 1
            high = 10 if key == 'text_nice' else (2 if key == 'voice_threads' else 4)
            if type(value) is not int or not low <= value <= high:
                raise HTTPException(status_code=400, detail='Número de threads/prioridade fora dos limites.')
        current = inference_settings(state); current.update(payload)
        path = state / 'performance-config.json'
        if path.exists():
            backup = state / 'performance-config-before-v034.json'
            if not backup.exists(): backup.write_bytes(path.read_bytes())
        atomic_json(path, current)
        return settings()


def renderer_settings(state):
    try:
        data=json.loads((Path(state)/'render-config.json').read_text())
        return data['renderer'] if data.get('renderer') in ('gl_compatibility','mobile') else 'gl_compatibility'
    except (OSError, ValueError, AttributeError, KeyError):
        return 'gl_compatibility'
