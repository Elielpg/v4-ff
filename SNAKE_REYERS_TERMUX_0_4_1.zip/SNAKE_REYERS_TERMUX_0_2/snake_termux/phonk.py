"""Reversible PHONK theme controls. Never captures microphone or Android app audio."""
from __future__ import annotations
import copy
import json
import re
import os
import shutil
import subprocess
import signal
import threading
import time
from pathlib import Path

from .device_runtime import atomic_json

DEFAULTS={'enabled':False,'base_color':'#08050f','palette':['#9c2cff','#d653ff','#6333ed'],
          'intensity':.60,'sensitivity':1.0,'pulses':True,'source':'music','manual_bpm':140,
          'color_mode':'random','color_every':2,'track_palettes':{},
          'lightning':True,'lightning_strength':1.2,'lightning_speed':1.0,
          'floor_reactive':True,'floor_strength':.8,'aura':True,'aura_strength':.35,
          'style':'chrome','stable_render':True,'accent_strength':.16}
LOCK=threading.RLock()
SCRIPT=Path(__file__).resolve().parent/'godot/phonk_scene.gd'


def available():
    return all(SCRIPT.with_name(name).is_file() for name in
               ('phonk_scene.gd','phonk_runtime.gd','phonk_beat.gd','phonk_skin.gdshader','phonk_floor.gdshader','phonk_aura.gdshader'))


def _read(state):
    try:
        path=Path(state)/'phonk-config.json'
        if path.stat().st_size>65536:return {}
        value=json.loads(path.read_text())
    except (OSError,ValueError):value={}
    return value if isinstance(value,dict) else {}


def color(value):
    if not isinstance(value,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',value):raise ValueError('Use cores no formato #RRGGBB.')
    return value.lower()


def palette(value):
    if not isinstance(value,list) or not 2<=len(value)<=6:raise ValueError('Escolha de duas a seis cores.')
    return [color(x) for x in value]


def validate(payload):
    if not isinstance(payload,dict) or not payload or set(payload)-set(DEFAULTS):raise ValueError('Controle PHONK desconhecido.')
    clean={}
    for key,value in payload.items():
        if key in ('enabled','pulses','lightning','floor_reactive','aura','stable_render'):
            if type(value) is not bool:raise ValueError('Ative ou desative o controle.')
            clean[key]=value
        elif key=='base_color':clean[key]=color(value)
        elif key=='palette':clean[key]=palette(value)
        elif key in ('intensity','sensitivity','lightning_strength','lightning_speed','floor_strength','aura_strength','accent_strength'):
            minimum,maximum={'intensity':(0.,1.),'sensitivity':(.3,2.),
                'lightning_strength':(0.,2.),'lightning_speed':(.2,2.5),'floor_strength':(0.,1.5),'aura_strength':(0.,1.),'accent_strength':(0.,.5)}[key]
            if type(value) not in (int,float) or not minimum<=value<=maximum:raise ValueError('Intensidade ou sensibilidade fora do intervalo.')
            clean[key]=float(value)
        elif key in ('manual_bpm','color_every'):
            lo,hi=(40,300) if key=='manual_bpm' else (1,16)
            if type(value) is not int or not lo<=value<=hi:raise ValueError('Ritmo fora do intervalo permitido.')
            clean[key]=value
        elif key in ('source','color_mode','style'):
            choices={'source':('music','manual'),'color_mode':('beat','track','fixed','random'),'style':('chrome','neon')}[key]
            if not isinstance(value,str) or value not in choices:raise ValueError('Modo PHONK inválido.')
            clean[key]=value
        elif key=='track_palettes':
            if not isinstance(value,dict) or len(value)>64:raise ValueError('Limite de 64 paletas por música.')
            records={}
            for track,colors in value.items():
                if not isinstance(track,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',track):raise ValueError('Identificador de música inválido.')
                records[track]=palette(colors)
            clean[key]=records
    return clean


def settings(state):
    raw=_read(state);result=copy.deepcopy(DEFAULTS)
    for key in DEFAULTS:
        if key in raw:
            try:result.update(validate({key:raw[key]}))
            except ValueError:pass
    return result


def save(state,payload,*,sync=False):
    values=validate(payload)
    with LOCK:
        raw={**_read(state),**values}
        if sync or ('source' in values and values['source']=='manual'):
            raw['manual_epoch']=time.time()
        previous=raw.get('revision',0)
        raw['revision']=(previous if type(previous) is int else 0)+1
        atomic_json(Path(state)/'phonk-config.json',raw)
    return settings(state)


def refresh(state,library,log_path):
    tracks={}
    if library is not None:
        for key,row in list(library.inventory().items())[:128]:
            playable=row.get('playable') or row.get('source')
            if playable:tracks[Path(playable).name]={'id':key,'title':row.get('title',Path(playable).stem)}
    with LOCK:
        raw=_read(state);value={'tracks':tracks,'native_log':str(log_path)}
        if raw.get('runtime')!=value:
            raw['runtime']=value
            atomic_json(Path(state)/'phonk-config.json',raw)


def launch(env,state):
    state=Path(state).resolve()
    (state/'phonk-runtime.json').unlink(missing_ok=True)
    return {**env,'SNAKE_PHONK_CONFIG':str(state/'phonk-config.json'),
            'SNAKE_PHONK_STATUS':str(state/'phonk-runtime.json')}


def status(state):
    runtime=None
    try:
        path=Path(state)/'phonk-runtime.json'
        if path.stat().st_size<32768:
            value=json.loads(path.read_text())
            if isinstance(value,dict):runtime=value
    except (OSError,ValueError):pass
    raw=_read(state)
    return {'settings':settings(state),'runtime':runtime,'available':available(),
            'runtime_age_seconds':round(max(0,time.time()-runtime.get('at',0)),1) if runtime else None,
            'tracks':list(raw.get('runtime',{}).get('tracks',{}).values()),
            'note':'Música analisa somente o bus Music do jogo. Manual usa o BPM informado; não escuta GreenTube, microfone ou outros apps.',
            'original_game_credit':'Snake Reyers — Thiago Reyes'}


def diagnostic(native):
    """Read only our process and bounded render telemetry; never restarts it."""
    value=status(native.state_dir)
    process=getattr(native,'process',None)
    exit_code=process.poll() if process is not None else getattr(native,'last_exit_code',None)
    running=process is not None and exit_code is None
    exit_signal=None
    if type(exit_code) is int and exit_code<0:
        try:exit_signal=signal.Signals(-exit_code).name
        except ValueError:pass
    metrics={}
    if running:
        try:
            for line in Path('/proc',str(process.pid),'status').read_text().splitlines():
                name,_,body=line.partition(':')
                if name in ('State','VmRSS','Threads'):metrics[name]=body.strip()
        except OSError:pass
    cpu=None
    wait_channels=[]
    if running:
        from .performance import Sampler
        sampler=Sampler()
        sampler.process(process.pid,'jogo',time.monotonic())
        time.sleep(.25)
        cpu=sampler.process(process.pid,'jogo',time.monotonic())
        for task in sorted(Path('/proc',str(process.pid),'task').glob('*'))[:32]:
            try:
                wait_channels.append({'name':(task/'comm').read_text().strip()[:40],
                                      'wait':(task/'wchan').read_text().strip()[:80]})
            except OSError:pass
    flags=[]
    try:
        with Path(native.log_path).open('rb') as file:
            file.seek(max(0,file.seek(0,2)-32768))
            tail=file.read(32768).decode(errors='replace').lower()
        for name in ('vk_error_device_lost','device lost','out of memory','gpu hang','failed to allocate'):
            if name in tail:flags.append(name)
    except OSError:pass
    age=value['runtime_age_seconds']
    stale=running and age is not None and age>8
    from .scene_graphics import status as graphics_status
    graphics=graphics_status(native.state_dir).get('runtime')
    device=getattr(native,'device_report',{}).get('graphics',{})
    display_env=getattr(native,'audio_env',None) or os.environ.copy()
    display={'available':False,'responsive':None}
    binary=shutil.which('xdpyinfo',path=display_env.get('PATH'))
    if binary and display_env.get('DISPLAY'):
        display['available']=True
        started=time.monotonic()
        try:
            probe=subprocess.run([binary,'-display',display_env['DISPLAY']],env=display_env,
                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2)
            display['responsive']=probe.returncode==0
        except subprocess.TimeoutExpired:display['responsive']=False
        except OSError:pass
        display['probe_ms']=round((time.monotonic()-started)*1000)
    return {**value,'diagnostic':{'game_running':running,'render_updates_stale':stale,
            'process_exit_code':exit_code,'process_exit_signal':exit_signal,
            'process':metrics,'cpu_sample':cpu,'thread_waits':wait_channels,'display_probe':display,
            'graphics_errors':flags,'scene_metrics':graphics,
            'configured_renderer':getattr(native,'renderer',None),'observed_renderer':getattr(native,'observed_renderer',None),
            'resolution':device.get('resolution'),'max_fps':device.get('max_fps'),
            'interpretation':('O processo do jogo não está ativo. Confira o código/sinal de saída; isso não identifica sozinho o motivo.' if not running else
              'Processo vivo, mas a atualização da cena parou. A causa ainda precisa ser confirmada.' if stale else
              'A atualização está recente. Compare quadros e movimento: a parada pode estar na lógica do jogo ou na apresentação X11/captura. Não é uma confirmação da causa.'),
            'automatic_restart':False}}


def install(app,native,binding):
    from fastapi import HTTPException
    library=getattr(app.state,'snake_music_library',None)
    refresh(native.state_dir,library,native.log_path)
    binding.phonk_settings=lambda:settings(native.state_dir)
    if library is not None:
        old_broadcast=library.broadcast
        async def broadcast():
            refresh(native.state_dir,library,native.log_path)
            return await old_broadcast()
        library.broadcast=broadcast
        if hasattr(binding,'replacements'):binding.replacements.append((library,'broadcast',old_broadcast))

    @app.get('/termux/phonk')
    def read():
        refresh(native.state_dir,library,native.log_path)
        return status(native.state_dir)

    @app.get('/termux/phonk/diagnostic')
    def read_diagnostic():return diagnostic(native)

    @app.post('/termux/phonk')
    def write(payload:dict):
        try:save(native.state_dir,payload)
        except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
        return status(native.state_dir)

    @app.post('/termux/phonk/sync')
    def sync(payload:dict):
        if set(payload)!={'manual_bpm'}:raise HTTPException(status_code=400,detail='Informe somente o BPM manual.')
        try:save(native.state_dir,{**payload,'source':'manual'},sync=True)
        except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
        return status(native.state_dir)
