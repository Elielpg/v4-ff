"""Reversible LIVE pacing hooks. Original gameplay and dialogue mode stay available."""
from __future__ import annotations

import asyncio
import os
import time
import uuid
from pathlib import Path


def install(binding, app):
    from fastapi import HTTPException
    from cobrinha_server.services import avatar_cache, event_decision_worker as worker

    original_comment = worker._process_comment
    original_avatar = avatar_cache.cache_profile_avatar
    metrics = {'comments_direct': 0, 'last_preparation_ms': None, 'last_jobs_enqueued': None}

    def settings():
        raw = binding.settings._raw()
        return {'reply_mode': 'dialogue' if raw.get('termux_reply_mode') == 'dialogue' else 'direct'}

    def avatar(url, *, user_key='', timeout=8):
        result = original_avatar(url, user_key=user_key, timeout=min(2.0, float(timeout)))
        if not result.get('ok') or not result.get('path'):
            return result
        source = Path(result['path'])
        target = source.with_name(source.stem + '_live256.png')
        try:
            if not target.exists() or target.stat().st_mtime < source.stat().st_mtime:
                from PIL import Image, ImageOps
                with Image.open(source) as image:
                    if image.width * image.height > 20_000_000:
                        return {**result, 'ok': False, 'path': '', 'error': 'avatar grande demais'}
                    small = ImageOps.exif_transpose(image)
                    small.thumbnail((256, 256))
                    temporary = target.with_name('.' + uuid.uuid4().hex + '.png')
                    try:
                        small.convert('RGBA').save(temporary, format='PNG', compress_level=3)
                        temporary.replace(target)
                    finally:
                        temporary.unlink(missing_ok=True)
            return {**result, 'path': str(target.resolve()), 'bytes': target.stat().st_size}
        except (ImportError, OSError, ValueError):
            return result

    async def process_comment(event):
        if settings()['reply_mode'] == 'dialogue':
            return await original_comment(event)
        started = time.monotonic()
        display_name = worker._display_name(event)
        comment = str(event.get('text') or '').strip()
        user_key = worker._event_user_key(event) or display_name
        top = worker.top_supporters.is_priority_comment(event)
        # Avatar I/O and model generation used to run sequentially. Both are
        # awaited here so no late avatar event can interrupt an ongoing reply.
        avatar_path, response = await asyncio.gather(
            worker._send_spectator_activity(event, source='social_comment'),
            asyncio.to_thread(worker._comment_reply, event, display_name=display_name,
                              comment=comment, user_key=user_key, top_priority=top),
        )
        limit = binding.config()['max_chars']
        if len(response) > limit:
            cut = response[:limit - 1].rsplit(' ', 1)[0].rstrip(' ,.;:')
            response = cut + '.'
        # A normal, single main job bypasses paired comment reading and its
        # spectator -> snake camera handoff. Never invent unsupported camera API.
        job = worker.enqueue_text(response, priority=80 if top else 70, actor='main', metadata={
            'source': 'social_comment', 'event_id': str(event.get('id') or ''),
            'speaker': 'main', 'user_id': str(event.get('user_id') or user_key),
            'username': str(event.get('username') or ''), 'display_name': display_name,
            'avatar_url': str(event.get('avatar_url') or event.get('profile_image') or ''),
            'avatar_path': avatar_path, 'snake_color': worker._snake_color_for_user(user_key),
            'audio_role': 'direct_reply', 'top_supporter_priority': top,
        })
        metrics.update(comments_direct=metrics['comments_direct'] + 1,
                       last_preparation_ms=round((time.monotonic() - started) * 1000), last_jobs_enqueued=1)
        worker._write_status(running=True, last_action='comment_direct_reply_queued', last_error='',
                             events_processed=int(worker._STATE.get('events_processed') or 0) + 1,
                             comments_processed=int(worker._STATE.get('comments_processed') or 0) + 1)
        return {'ok': True, 'kind': 'comment', 'mode': 'direct', 'user_job': None, 'main_job': job}

    binding.replace_aliases(original_avatar, avatar)
    binding.replace_aliases(original_comment, process_comment)

    @app.get('/termux/live-tuning')
    def status():
        return {'settings': settings(), 'metrics': dict(metrics),
                'camera_note': 'O modo direto evita a leitura do comentário e a troca de foco associada. A interpolação interna continua original.'}

    @app.post('/termux/live-tuning')
    def save(payload: dict):
        if set(payload) != {'reply_mode'} or payload['reply_mode'] not in ('direct', 'dialogue'):
            raise HTTPException(status_code=400, detail='Escolha direct ou dialogue.')
        raw = binding.settings._raw()
        raw['termux_reply_mode'] = payload['reply_mode']
        binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
        try:
            os.chmod(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)
        except OSError:
            pass
        return status()
