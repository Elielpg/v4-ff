"""One-time, reversible selection of the new renderer path; no driver installation."""
from pathlib import Path
import argparse
import json
import shutil
import time

from .device_runtime import atomic_json


def apply(adapter, backup):
    adapter=Path(adapter).resolve();backup=Path(backup);state=adapter/'state'
    marker=state/'render-v041-applied.json'
    if marker.exists():return {'applied':False}
    manifest_path=backup/'restore-manifest.json'
    manifest=json.loads(manifest_path.read_text())
    names=('state/render-config.json','state/scene-graphics-config.json','state/device-config.json','state/render-v041-applied.json')
    snapshots={}
    for name in names:
        path=adapter/name;snapshots[name]=path.read_bytes() if path.exists() else None
        if name not in manifest['files']:
            manifest['files'][name]=path.is_file()
            if path.is_file():
                (backup/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup/name)
    atomic_json(manifest_path,manifest)
    shutil.copy2(adapter/'tools/restore_adapter.py',backup/'REVERTER.py')
    try:
        from .scene_graphics import save
        save(state,{'enabled':True,'stable_render':True,'adaptive_resolution':False,
                    'static_batching':True,'camera_smoothing':True})
        raw={}
        if snapshots['state/device-config.json']:
            raw=json.loads(snapshots['state/device-config.json'])
            if not isinstance(raw,dict):raw={}
        atomic_json(state/'device-config.json',{**raw,'enabled':True})
        atomic_json(state/'render-config.json',{'renderer':'mobile'})
        atomic_json(marker,{'version':'0.4.1','applied_at':time.time(),'backup':str(backup),
                            'gt3_speed_gain_confirmed':False})
    except Exception:
        for name,data in snapshots.items():
            path=adapter/name
            if data is None:path.unlink(missing_ok=True)
            else:path.write_bytes(data)
        raise
    return {'applied':True,'backup':str(backup)}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('adapter',type=Path);parser.add_argument('--backup',required=True,type=Path)
    result=apply(**vars(parser.parse_args()))
    print('Vulkan direto em modo seguro, lotes estáticos e câmera estabilizada selecionados.' if result['applied'] else 'Perfil 0.4.1 já aplicado; escolhas posteriores preservadas.')
    print('Reabra o jogo. Para comparar com OpenGL: SNAKE_RENDERER=gl_compatibility bash start.sh')
