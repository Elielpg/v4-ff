"""Private, transactional receipt journal. No credentials or commands are stored."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path

COMMENT_LIMIT = 3
MAX_ATTEMPTS = 3


class LiveQueue:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path, timeout=6, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS events (
              seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL,
              kind TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
              job_id TEXT NOT NULL DEFAULT '', attempts INTEGER NOT NULL DEFAULT 0,
              effects_started INTEGER NOT NULL DEFAULT 0, retry_at REAL NOT NULL DEFAULT 0,
              error TEXT NOT NULL DEFAULT '', updated REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS queue_order ON events(kind,status,seq);
            CREATE INDEX IF NOT EXISTS job_lookup ON events(job_id);
            CREATE TABLE IF NOT EXISTS receipts (receipt TEXT PRIMARY KEY, seen REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS counts (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS visitors (name TEXT PRIMARY KEY, seen REAL NOT NULL);
        ''')
        self.db.commit()
        os.chmod(self.path, 0o600)
        for suffix in ('-wal', '-shm'):
            try: os.chmod(str(self.path) + suffix, 0o600)
            except FileNotFoundError: pass

    def close(self):
        with self.lock: self.db.close()

    def _count(self, name, amount=1):
        self.db.execute('INSERT INTO counts VALUES (?,?) ON CONFLICT(name) DO UPDATE SET value=value+excluded.value', (name, amount))

    def ingest(self, event):
        kind = event.get('kind')
        if kind not in ('gift', 'comment'): return False
        now = time.time()
        with self.lock, self.db:
            if self.db.execute('SELECT 1 FROM events WHERE id=?', (event['id'],)).fetchone(): return True
            if kind == 'comment':
                waiting = self.db.execute("SELECT COUNT(*) FROM events WHERE kind='comment' AND status NOT IN ('done','playing')").fetchone()[0]
                if waiting >= COMMENT_LIMIT:
                    self._count('comments_rejected_full')
                    return False
            metadata = event.get('metadata') or {}
            receipt = str(metadata.get('upstream_event_id') or '') if kind == 'gift' else ''
            if receipt:
                receipt = 'gift:' + receipt
                previous = self.db.execute('SELECT 1 FROM receipts WHERE receipt=?', (receipt,)).fetchone()
                if previous:
                    self._count('gifts_duplicate')
                    return False
                self.db.execute('INSERT INTO receipts VALUES (?,?)', (receipt, now))
            self.db.execute('INSERT INTO events (id,kind,payload,updated) VALUES (?,?,?,?)',
                            (event['id'], kind, json.dumps(event, ensure_ascii=False), now))
            self._count(kind + 's_received')
            return True

    def member(self, user):
        name = str(user.get('user_id') or user.get('username') or '')
        if not name: return False
        now = time.time()
        with self.lock, self.db:
            previous = self.db.execute('SELECT seen FROM visitors WHERE name=?', (name,)).fetchone()
            if previous and now - previous[0] < 120: return False
            self.db.execute('INSERT OR REPLACE INTO visitors VALUES (?,?)', (name, now))
            self.db.execute('DELETE FROM visitors WHERE seen<?', (now - 120,))
            self._count('visitors_received')
            row = self.db.execute("SELECT id,payload FROM events WHERE kind='welcome' AND status='pending' ORDER BY seq LIMIT 1").fetchone()
            event = json.loads(row['payload']) if row else {'id': uuid.uuid4().hex, 'kind': 'welcome', 'created_at': now, 'users': [], 'count': 0}
            event['count'] += 1
            if len(event['users']) < 3: event['users'].append(user)
            encoded = json.dumps(event, ensure_ascii=False)
            if row: self.db.execute('UPDATE events SET payload=?,updated=? WHERE id=?', (encoded, now, row['id']))
            else: self.db.execute('INSERT INTO events (id,kind,payload,updated) VALUES (?,?,?,?)', (event['id'], 'welcome', encoded, now))
            return True

    def _first(self, kind):
        return self.db.execute("SELECT * FROM events WHERE kind=? AND status!='done' ORDER BY seq LIMIT 1", (kind,)).fetchone()

    def next_kind(self):
        with self.lock:
            for kind in ('gift', 'comment', 'welcome'):
                row = self._first(kind)
                if row: return kind
            return None

    def claim(self, *, allow_welcome=True):
        now = time.time()
        with self.lock, self.db:
            row = self._first('gift')
            if row:
                if row['status'] not in ('pending', 'retry') or row['retry_at'] > now: return None
            else:
                row = self.db.execute("SELECT * FROM events WHERE kind='comment' AND status='pending' ORDER BY seq LIMIT 1").fetchone()
                if row is None and allow_welcome:
                    row = self.db.execute("SELECT * FROM events WHERE kind='welcome' AND status='pending' ORDER BY seq LIMIT 1").fetchone()
                    if row and now - json.loads(row['payload'])['created_at'] < 2: return None
            if not row: return None
            self.db.execute("UPDATE events SET status='processing',attempts=attempts+1,updated=? WHERE id=?", (now, row['id']))
            return {**json.loads(row['payload']), '_queue_effects_started': bool(row['effects_started'])}

    def effects_started(self, event_id):
        with self.lock, self.db:
            self.db.execute('UPDATE events SET effects_started=1,updated=? WHERE id=?', (time.time(), event_id))

    def attach(self, event_id, job_id):
        with self.lock, self.db:
            self.db.execute("""UPDATE events SET job_id=?,
                status=CASE WHEN status='processing' THEN 'enqueued' ELSE status END,
                error='',updated=? WHERE id=? AND
                (status='processing' OR (job_id=? AND status IN ('enqueued','ready','playing')))""",
                (job_id, time.time(), event_id, job_id))

    def event(self, event_id):
        with self.lock:
            row = self.db.execute('SELECT * FROM events WHERE id=?', (event_id,)).fetchone()
            return dict(row) if row else None

    def job(self, job_id):
        if not job_id: return None
        with self.lock:
            row = self.db.execute('SELECT * FROM events WHERE job_id=? AND status!=?', (job_id, 'done')).fetchone()
            return dict(row) if row else None

    def update_job(self, job_id, status):
        with self.lock, self.db:
            self.db.execute("UPDATE events SET status=?,updated=? WHERE job_id=? AND status!='done'", (status, time.time(), job_id))

    def failed(self, event_id, error):
        with self.lock, self.db:
            row = self.db.execute('SELECT kind,attempts FROM events WHERE id=?', (event_id,)).fetchone()
            if not row: return
            retry = row['kind'] == 'gift' and row['attempts'] < MAX_ATTEMPTS
            status = 'retry' if retry else ('blocked' if row['kind'] == 'gift' else 'done')
            self.db.execute('UPDATE events SET status=?,job_id=?,retry_at=?,error=?,updated=? WHERE id=?',
                            (status, '', time.time() + 5 * max(1, row['attempts']), str(error)[:180], time.time(), event_id))
            self._count('preparation_errors')

    def finish(self, job_id):
        with self.lock, self.db:
            row = self.db.execute("SELECT id,kind FROM events WHERE job_id=? AND status!='done'", (job_id,)).fetchone()
            if not row: return
            self.db.execute("UPDATE events SET status='done',updated=? WHERE id=?", (time.time(), row['id']))
            self._count(row['kind'] + 's_finished')
            # Pending gifts never expire; only acknowledged history is bounded.
            self.db.execute("DELETE FROM events WHERE status='done' AND seq NOT IN (SELECT seq FROM events WHERE status='done' ORDER BY seq DESC LIMIT 2048)")
            self.db.execute('DELETE FROM receipts WHERE seen<?', (time.time() - 7 * 86400,))

    def reset_transient(self):
        with self.lock, self.db:
            self.db.execute("DELETE FROM events WHERE kind!='gift'")
            self.db.execute("UPDATE events SET status='pending',job_id='',retry_at=0,updated=? WHERE kind='gift' AND status NOT IN ('done','blocked')", (time.time(),))

    def recover_missing(self, known_jobs):
        with self.lock:
            rows = self.db.execute("SELECT * FROM events WHERE status IN ('processing','enqueued','ready','playing') AND updated<?", (time.time()-2,)).fetchall()
            for row in rows:
                if row['job_id'] not in known_jobs: self.failed(row['id'], 'playback_not_confirmed')

    def retry_gift(self):
        with self.lock, self.db:
            row = self._first('gift')
            if not row or row['status'] not in ('blocked', 'retry'): return False
            self.db.execute("UPDATE events SET status='pending',attempts=0,retry_at=0,error='',updated=? WHERE id=?", (time.time(), row['id']))
            return True

    def status(self):
        with self.lock:
            totals = {kind: self.db.execute("SELECT COUNT(*) FROM events WHERE kind=? AND status!='done'", (kind,)).fetchone()[0] for kind in ('gift', 'comment', 'welcome')}
            waiting = self.db.execute("SELECT COUNT(*) FROM events WHERE kind='comment' AND status NOT IN ('done','playing')").fetchone()[0]
            oldest = self._first('gift')
            return {'gifts_waiting': totals['gift'], 'comments_waiting': waiting,
                    'comments_total': totals['comment'], 'welcome_batches': totals['welcome'],
                    'gift_head': {k: oldest[k] for k in ('status', 'attempts', 'error')} if oldest else None,
                    'counts': dict(self.db.execute('SELECT name,value FROM counts').fetchall()),
                    'comment_limit': COMMENT_LIMIT, 'gift_order': 'arrival', 'full_queue': 'reject_new'}
