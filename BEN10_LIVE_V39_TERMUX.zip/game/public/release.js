export const BUILD_ID='39.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 39.0.0';
