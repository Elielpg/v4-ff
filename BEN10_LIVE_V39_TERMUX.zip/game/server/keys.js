import {readFile,mkdir,writeFile,rename} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
export function normalizeKey(value){
 if(typeof value!=='string')throw Error('Formato de chave inválido');
 const key=value.trim().replace(/^(?:export\s+)?(?:GEMINI_API_KEY|GOOGLE_API_KEY|ELEVENLABS_API_KEY)\s*=\s*/,'').replace(/^['"]|['"]$/g,'').trim();
 if(!/^[-_a-zA-Z0-9]{20,200}$/.test(key))throw Error('Formato de chave inválido: cole uma chave por linha, sem comentários');return key;
}
export class KeyStore {
 constructor(file,environmentName='GEMINI_API_KEY'){this.file=file;this.environmentName=environmentName;this.entries=[];this.activeId=null;this.write=Promise.resolve();}
 async load(){try{const d=JSON.parse(await readFile(this.file,'utf8'));this.entries=d.entries||[];this.activeId=d.activeId;if(this.activeId&&!this.entries.some(e=>e.id===this.activeId))this.activeId=this.entries[0]?.id||null;}catch(e){if(e.code!=='ENOENT')throw Error('Não foi possível ler as chaves locais');}return this;}
 status(){return {entries:this.entries.map(({id,label})=>({id,label,active:id===this.activeId})),count:this.entries.length,limit:20,environmentAvailable:!!process.env[this.environmentName],activeId:this.activeId,selectedLabel:this.entries.find(e=>e.id===this.activeId)?.label||(process.env[this.environmentName]?'Chave do ambiente':null)};}
 key(){return this.entries.find(e=>e.id===this.activeId)?.key||process.env[this.environmentName];}
 async change(action,data){
 const operation=this.write.catch(()=>{}).then(async()=>{let entries=this.entries.map(e=>({...e})),activeId=this.activeId,added=0,duplicates=0;
 if(action==='add'||action==='add_many'){
  const items=action==='add'?[data]:data.keys;if(!Array.isArray(items)||!items.length||items.length>20)throw Error('Informe de 1 a 20 chaves');
  for(const item of items){const key=normalizeKey(typeof item==='string'?item:item?.key);if(entries.some(e=>e.key===key)){if(action==='add')throw Error('Essa chave já está cadastrada');duplicates++;continue;}
   if(entries.length>=20)throw Error('Limite de 20 chaves');let label=String((typeof item==='object'&&item?.label)||data.label||'Gemini').trim().slice(0,50)||'Gemini',suffix=1,base=label;while(entries.some(e=>e.label===label))label=base+' '+(++suffix);
   const entry={id:randomUUID(),label,key};entries.push(entry);activeId??=entry.id;added++;
  }
 }else if(action==='select'){if(data.id!==null&&!entries.some(e=>e.id===data.id))throw Error('Chave não encontrada');activeId=data.id;}
 else if(action==='remove'){entries=entries.filter(e=>e.id!==data.id);if(activeId===data.id)activeId=entries[0]?.id||null;}
 else throw Error('Ação inválida');
 await mkdir(path.dirname(this.file),{recursive:true,mode:0o700});const temp=this.file+'.tmp';await writeFile(temp,JSON.stringify({entries,activeId}),{mode:0o600});await rename(temp,this.file);this.entries=entries;this.activeId=activeId;return {...this.status(),added,duplicates};});this.write=operation;return operation;
 }
}
