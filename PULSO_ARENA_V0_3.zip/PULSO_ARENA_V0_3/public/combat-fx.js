const B = BABYLON,
  V = B.Vector3;
export class CombatFX {
  constructor(world) {
    this.w = world;
    this.pool = [];
    this.budget = 16;
    const tx = new B.DynamicTexture(
        "estrela-impacto",
        { width: 128, height: 128 },
        world.scene,
        false,
      ),
      c = tx.getContext();
    tx.hasAlpha = true;
    c.clearRect(0, 0, 128, 128);
    c.fillStyle = "#fff8d6";
    c.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2,
        r = i % 2 ? 23 : 59,
        x = 64 + Math.cos(a) * r,
        y = 64 + Math.sin(a) * r;
      if (i) c.lineTo(x, y);
      else c.moveTo(x, y);
    }
    c.closePath();
    c.fill();
    tx.update();
    const starMat = new B.StandardMaterial("estrela-mat", world.scene);
    starMat.diffuseTexture = tx;
    starMat.emissiveTexture = tx;
    starMat.disableLighting = true;
    starMat.useAlphaFromDiffuseTexture = true;
    starMat.backFaceCulling = false;
    this.colors = ["#ffe49b", "#65e4ff", "#bdf66d", "#ff8fae"];
    this.mats = this.colors.map((hex, i) => {
      const m = world.mat("rastro-" + i, hex, 1);
      m.disableLighting = true;
      return m;
    });
    for (let i = 0; i < 8; i++)
      for (const kind of ["arc", "ring", "star", "line"]) {
        let mesh;
        if (kind === "star") {
          mesh = B.MeshBuilder.CreatePlane(
            "estrela",
            { size: 0.55 },
            world.scene,
          );
          mesh.material = starMat;
          mesh.billboardMode = B.Mesh.BILLBOARDMODE_ALL;
        } else if (kind === "line")
          mesh = B.MeshBuilder.CreateCylinder(
            "linha-golpe",
            { height: 1, diameter: 0.027, tessellation: 6 },
            world.scene,
          );
        else
          mesh = B.MeshBuilder.CreateTorus(
            "rastro-" + kind,
            {
              diameter: 1,
              thickness: kind === "arc" ? 0.045 : 0.025,
              tessellation: 24,
              arc: kind === "arc" ? 0.5 : 1,
            },
            world.scene,
          );
        mesh.isPickable = false;
        mesh.setEnabled(false);
        world.glow.addIncludedOnlyMesh(mesh);
        this.pool.push({ kind, mesh, at: -100, life: 0.3 });
      }
  }
  clear() {
    for (const f of this.pool) {
      f.at = -100;
      f.mesh.setEnabled(false);
    }
  }
  emit(
    kind,
    pos,
    {
      delay = 0,
      life = 0.28,
      scale = 1,
      color = 0,
      rotation = [0, 0, 0],
      direction,
    } = {},
  ) {
    const slots = this.pool
      .slice(0, this.budget)
      .filter((x) => x.kind === kind);
    if (!slots.length) return;
    const f = slots.reduce((a, b) => (a.at + a.life < b.at + b.life ? a : b));
    f.at = performance.now() / 1000 + delay;
    f.life = life;
    f.scale = scale;
    f.mesh.position.copyFrom(pos);
    f.mesh.rotationQuaternion = null;
    f.mesh.rotation.set(...rotation);
    f.spin = kind === "arc" ? 5 : 0;
    f.baseYaw = rotation[1];
    if (kind !== "star") f.mesh.material = this.mats[color % this.mats.length];
    if (kind === "line") {
      const d = direction || new V(0, 0, 1);
      this.w.link(f.mesh, pos.asArray(), pos.add(d.scale(scale)).asArray());
      f.scale = 1;
    }
  }
  jump(pos, duration = 1) {
    this.emit("ring", pos, { scale: 0.6, life: 0.35, color: 1 });
    this.emit("ring", pos, {
      scale: 0.7,
      life: 0.3,
      color: 0,
      delay: duration * 0.9,
    });
  }
  attack(action, actors) {
    const a = actors.get(action.player),
      b = actors.get(action.target);
    if (!a || !b) return;
    const from = a.root.position.clone(),
      to = b.root.position.clone(),
      d = to.subtract(from);
    d.y = 0;
    d.normalize();
    const side = new V(d.z, 0, -d.x),
      impact = to.add(new V(0, action.move === "uppercut" ? 1.6 : 1.15, 0)),
      delay = (action.duration || 0.5) * 0.18;
    const color =
      a.type === "hippo"
        ? 3
        : a.type === "raccoon"
          ? 1
          : a.type === "ram"
            ? 2
            : 0;
    if (action.defense === "dodge") {
      for (let i = 0; i < 3; i++)
        this.emit(
          "arc",
          to.add(side.scale(i * 0.2 - 0.1)).add(new V(0, 1.0, 0)),
          {
            rotation: [Math.PI / 2, Math.atan2(d.x, d.z), i * 0.4],
            scale: 0.65,
            delay: delay + i * 0.04,
            color: 1,
            life: 0.28,
          },
        );
      return;
    }
    if (action.defense === "block")
      this.emit("ring", impact, {
        rotation: [Math.PI / 2, Math.atan2(d.x, d.z), 0],
        scale: 0.7,
        delay,
        color: 1,
        life: 0.3,
      });
    else
      this.emit("star", impact, {
        scale: action.special ? 1.4 : 0.8,
        delay,
        life: 0.2,
      });
    const kick = ["kick", "jumpKick", "entryKick", "spin"].includes(
      action.move,
    );
    if (kick || ["uppercut", "hook", "special"].includes(action.move))
      this.emit(
        "arc",
        from.add(d.scale(0.5)).add(new V(0, kick ? 0.9 : 1.2, 0)),
        {
          rotation: [
            action.move === "hook" ? 0 : Math.PI / 2,
            Math.atan2(d.x, d.z),
            action.move === "uppercut" ? Math.PI / 2 : 0.25,
          ],
          scale: action.special ? 1.8 : 1.15,
          delay,
          color,
          life: 0.3,
        },
      );
    else
      for (let i = 0; i < 3; i++)
        this.emit(
          "line",
          from
            .add(d.scale(0.35))
            .add(side.scale((i - 1) * 0.12))
            .add(new V(0, 1.25 + (i - 1) * 0.07, 0)),
          {
            direction: d,
            scale: 0.9,
            delay: delay + i * 0.015,
            color,
            life: 0.16,
          },
        );
    if (["jumpKick", "entryKick"].includes(action.move))
      this.jump(from.add(new V(0, 0.015, 0)), action.duration || 0.5);
  }
  update(t, calm) {
    for (const [i, f] of this.pool.entries()) {
      const age = t - f.at,
        active = i < this.budget && age >= 0 && age < f.life;
      f.mesh.setEnabled(active);
      if (!active) continue;
      const p = age / f.life;
      f.mesh.visibility = (calm ? 0.35 : 0.8) * (1 - p);
      if (f.kind !== "line")
        f.mesh.scaling.setAll(
          f.scale *
            (f.kind === "star"
              ? 0.6 + Math.sin(p * Math.PI) * 0.8
              : 1 + p * 0.8),
        );
      if (f.spin) f.mesh.rotation.y = f.baseYaw + (calm ? 0 : f.spin * age);
    }
  }
  get active() {
    return this.pool.filter((f) => f.mesh.isEnabled()).length;
  }
}
