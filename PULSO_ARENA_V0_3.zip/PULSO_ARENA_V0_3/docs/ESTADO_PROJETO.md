# Atualização atual — Pulso Arena 0.3.0

Câmera desobstruída, novos golpes/efeitos, comemorações e ranking no cenário. Relatório e evidências atuais: ATUALIZACAO_V0_3.md e evidencias/v0_3/. As seções abaixo preservam a arquitetura e o histórico das versões anteriores.

# Estado atual — Pulso Arena 0.2.1

Correção ativa: detector multifaixa de phonk, subdivisões, dança contínua, lotes Android e sensibilidade. 41 testes e comparações controladas descritos em CORRECAO_PHONK_0_2_1.md. APK e jogo devem ser atualizados juntos para aproveitar o transporte novo; APK antigo ainda usa o evento individual aceito pela ponte.

## Base preservada da 0.2.0

Projeto original ativo; Ben 10 e vídeos continuam separados. Plataforma alvo: Realme GT3 16 GB, Android/Termux. Bases originais: raposa, hipopótamo, guaxinim e carneiro.

0.2 evolui a 0.1: câmera 360°, balões por usuário, deslocamento e golpes com curvas, defesa/esquiva/dança, festa na batida, guia maior e captador Android. Mantém regras de rosa, HP por likes, torcida, fila FIFO, ranking, limites e persistência schema 1.

Não afirmar captura real do GreenTube testada: existe APK compilado/assinado e ponte verificada com energia sintética; ainda falta testar no GT3 com fone/caixa. Modo padrão Visualizer; avançado MediaProjection opcional pode interromper outra captura de tela. Arquivo local e BPM/TAP preservados.

33 testes Node e teste de navegador com 360°, balão visível, defesa e 119 BPM. Captura Android, LIVE real, desempenho térmico e duração no GT3 pendentes. Supervisor cobre o filho, não o Android matando todo o Termux. Nada depende de LLM/voz neste projeto.

Atualizador com validação de manifesto, parada da própria instalação e backup ZIP; não sobrescrever dados com uma instalação limpa. Os arquivos de evidência históricos ficam separados por versão.
