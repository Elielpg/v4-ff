import test from "node:test";
import assert from "node:assert/strict";
import { OnsetDetector, PulseTracker } from "../public/onset.js";
import { ArenaEngine } from "../server/engine.mjs";
import { RhythmBridge } from "../server/rhythm.mjs";
import { advanceDancePhase } from "../public/choreo.js";
test("isolated missed subdivisions do not force the tempo into double time", () => {
  const t = new PulseTracker();
  for (let i = 0; i < 80; i++) if (i % 9 !== 5) t.note(i * 125, 1);
  assert.equal(t.interval, 500);
});
test("quiet sixteenth-note attacks after loud kicks are retained at eight pulses per second", () => {
  const d = new OnsetDetector(),
    hits = [];
  for (let i = 0; i < 800; i++) {
    const t = i * 0.01,
      j = Math.floor(t / 0.125),
      age = t - j * 0.125,
      value =
        0.001 +
        (age < 0.04 ? (j % 4 === 0 ? 0.2 : 0.025) * Math.exp(-age * 45) : 0);
    if (d.sample(value, t)) hits.push(t);
  }
  assert.ok(hits.length >= 61 && hits.length <= 64, JSON.stringify(hits));
  for (let i = 1; i < hits.length; i++)
    assert.ok(hits[i] - hits[i - 1] < 0.16, "weak attack missing");
});
test("small level wobble and silence do not turn sustained bass into rapid drums", () => {
  const d = new OnsetDetector();
  let n = 0;
  for (let i = 0; i < 1500; i++) {
    if (d.sample(0.12 + 0.0015 * Math.sin(i * 0.37), i * 0.016)) n++;
  }
  assert.ok(n <= 1);
  d.reset();
  for (let i = 0; i < 500; i++)
    assert.equal(d.sample(0.0001 + Math.sin(i) * 0.00005, i * 0.016), false);
});
test("main accents hold 120 BPM while accepting every 125 ms subdivision", () => {
  const tracker = new PulseTracker();
  let count = 0,
    last;
  for (let i = 0; i < 64; i++) {
    last = tracker.note(i * 125, i % 4 === 0 ? 1 : 0.2);
    if (last) count++;
  }
  assert.equal(count, 64);
  assert.equal(last.interval, 500);
  assert.equal(last.pulseInterval, 125);
});
test("tempo can change after previous anchor evidence becomes old", () => {
  const tracker = new PulseTracker();
  for (let i = 0; i < 8; i++) tracker.note(i * 500, 1);
  for (let i = 0; i < 16; i++) tracker.note(4000 + i * 250, 1);
  assert.equal(tracker.interval, 250);
});
test("fast visual beats do not multiply combat damage or create overlapping strikes", () => {
  let now = 100000;
  const actions = [],
    e = new ArenaEngine({ now: () => now, onAction: (a) => actions.push(a) });
  for (const user of ["a", "b"]) e.ingest({ type: "gift", user, gift: "Rosa" });
  now += 2300;
  e.tick();
  e.setMusic({ source: "external" });
  for (let i = 0; i < 16; i++) {
    now += 125;
    assert.equal(
      e.beat({
        source: "external",
        interval: 500,
        strength: i % 4 === 0 ? 1 : 0.2,
      }),
      true,
    );
  }
  assert.equal(actions.filter((a) => a.kind === "beat").length, 16);
  assert.equal(
    actions.filter((a) => a.kind === "attack" && a.move !== "entryKick").length,
    4,
  );
});
test("delayed transport preserves distinct sample times while rejecting duplicates", () => {
  let now = 100220;
  const b = new RhythmBridge({ now: () => now }),
    { code } = b.issue(),
    { token } = b.pair(code);
  let hits = 0;
  for (let i = 0; i < 12; i++) {
    const r = b.frame("Bearer " + token, {
      energy: 0.0001,
      detail: i === 4 || i === 10 ? 0.1 : 0.0001,
      level: 0.1,
      seq: i,
      at: 100000 + i * 20,
    });
    assert.equal(r.accepted, true);
    if (r.hit) hits++;
  }
  assert.equal(hits, 2);
  assert.equal(
    b.frame("Bearer " + token, { energy: 0, level: 0, seq: 11, at: 100220 })
      .accepted,
    false,
  );
});
test("sensitivity modes change weak onset thresholds without disabling the noise floor", () => {
  const normal = new OnsetDetector(),
    sensitive = new OnsetDetector("sensitive");
  let a = 0,
    b = 0;
  for (let i = 0; i < 400; i++) {
    const t = i * 0.016,
      level = 0.0001 + (i % 10 === 0 ? 0.00039 : 0);
    if (normal.sample(level, t)) a++;
    if (sensitive.sample(level, t)) b++;
  }
  assert.equal(a, 0);
  assert.ok(b > 30);
});
test("dance phase advances continuously between fast light accents", () => {
  let phase = 0;
  for (let i = 0; i < 500; i++) {
    const next = advanceDancePhase(phase, 0.016, 120, Math.sin(i) * 3);
    assert.ok(next > phase);
    phase = next;
  }
  assert.ok(phase > 12 * Math.PI);
});
