import test from "node:test";import assert from "node:assert/strict";import {spawn} from "node:child_process";import {mkdtemp,rm,readFile} from "node:fs/promises";import {tmpdir} from "node:os";
test("HTTP integration separates demonstration, persists settings, serves voices and refuses offline LIVE combat",async()=>{
 const dir=await mkdtemp(tmpdir()+"/jujutsu-http-"),port=35000+Math.floor(Math.random()*5000),base=`http://127.0.0.1:${port}`;
 const server=spawn(process.execPath,["server/index.mjs"],{cwd:import.meta.dirname+"/..",env:{...process.env,PORT:String(port),JUJUTSU_DATA_DIR:dir},stdio:"pipe"});
 const post=async(path,data={})=>{const r=await fetch(base+"/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});return{status:r.status,data:await r.json()};};
 try{
  let ready=false;for(let i=0;i<100;i++){try{if((await fetch(base+"/api/state")).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,50));}assert.ok(ready);
  await post("demo/event",{type:"join",user:"ana"});let s=await(await fetch(base+"/api/state")).json();assert.equal(s.players[0].status,"citizen");
  await post("demo/event",{type:"follow",user:"ana"});s=await(await fetch(base+"/api/state")).json();assert.equal(s.players[0].status,"fighter");
  await post("settings",{giftMap:{"99":"reverse"}});const saved=JSON.parse(await readFile(dir+"/demo.json","utf8"));assert.equal(saved.settings.giftMap["99"],"reverse");assert.equal((await post("settings",{giftMap:{"99":"eval"}})).status,400);
  const code=await post("rhythm/code"),paired=await post("rhythm/pair",{code:code.data.code});assert.equal(code.data.port,port);assert.equal(paired.data.token.length,64);assert.ok(!JSON.stringify(await(await fetch(base+"/api/state")).json()).includes(paired.data.token));
  const voice=await fetch(base+"/assets/voices/shrine.wav");assert.equal(voice.status,200);assert.match(voice.headers.get("content-type"),/audio\/wav/);assert.equal(Buffer.from(await voice.arrayBuffer()).toString("ascii",0,4),"RIFF");
  assert.equal((await fetch(base+"/../../package.json")).status,404);
  const blocked=await fetch(base+"/api/demo/event",{method:"POST",headers:{"Content-Type":"application/json",Origin:"https://evil.invalid"},body:JSON.stringify({type:"join",user:"bad"})});assert.equal(blocked.status,403);
  await post("live/connect",{username:"invalid link/"});assert.equal((await post("demo/boss")).status,409);assert.equal((await post("demo/points",{user:"ana"})).status,409);assert.equal((await post("demo/event",{type:"follow",user:"fake"})).status,409);assert.equal((await post("beat",{interval:500})).status,409);
  s=await(await fetch(base+"/api/state")).json();assert.equal(s.mode,"live");assert.equal(s.totalPlayers,0);
 }finally{server.kill("SIGTERM");await new Promise(resolve=>server.exitCode!==null?resolve():server.once("exit",resolve));await rm(dir,{recursive:true,force:true});}
});
