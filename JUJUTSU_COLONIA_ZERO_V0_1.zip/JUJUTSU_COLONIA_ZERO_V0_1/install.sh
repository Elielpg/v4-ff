#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then pkg install nodejs-lts; fi
node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<19)){console.error("Use Node 22.19 ou mais recente: pkg install nodejs-lts");process.exit(1)}'
npm ci --omit=dev --ignore-scripts
printf '\nInstalado. Execute: bash start.sh\nAbra: http://127.0.0.1:3200\n'
