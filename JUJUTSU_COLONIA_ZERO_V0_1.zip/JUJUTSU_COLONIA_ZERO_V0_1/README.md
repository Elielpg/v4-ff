# JUJUTSU LIVE · COLÔNIA ZERO 0.1.0

Primeira versão jogável de uma LIVE interativa de feiticeiros contra Sukuna em
uma cidade 3D. Projeto de fã inspirado em Jujutsu Kaisen, com modelos
procedurais estilizados, técnicas, câmera cinematográfica e áudio original.
Instalação separada do PULSO ARENA e do Ben 10; porta **3200**.

## Instalar no Termux

Requer Termux atualizado, Python para extrair o ZIP e Node **22.19+**. A primeira
instalação das dependências precisa de internet.

```bash
termux-setup-storage
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/JUJUTSU_COLONIA_ZERO_V0_1.zip . &&
cd ~/JUJUTSU_COLONIA_ZERO_V0_1 &&
bash install.sh &&
bash start.sh
```

Se necessário: `pkg install python nodejs-lts`.
Abra **http://127.0.0.1:3200/?v=0.1.0** no Chrome do celular e toque em
**TESTAR A COLÔNIA**. O toque também libera o áudio do navegador.

Para iniciar nas próximas vezes:

```bash
cd ~/JUJUTSU_COLONIA_ZERO_V0_1 && bash start.sh
```

Para parar, Ctrl+C no terminal original ou `bash stop.sh` em outra sessão na
mesma pasta. O supervisor verifica a própria instalação e informa conflito de
porta; não encerra o PULSO ou outros programas.

## Como participar

1. **Entrou na LIVE:** ganha um cidadão na cidade, com identificação sobre o
   personagem. Há 12 segundos de proteção inicial.
2. **Seguiu ou enviou uma Rosa:** ganha acesso à batalha, com sorteio de time
   Gojo/Kenjaku e personagem daquele time. A escolha não depende do valor do
   presente. Até 12 combatentes simultâneos; excedentes entram na reserva FIFO.
3. **TAP TAP:** a cada dez curtidas identificadas, +1 energia e +1 vida na reserva
   de cura. Cura em combate é gradual, até 2 HP/s, com reserva de 25 e limite de
   200 HP. Curtidas sem identificação contam no total, sem inventar vida para
   alguém.
4. **Compartilhou:** +3% de apoio e +10 energia, com intervalo de 15 segundos e
   teto de 30% de apoio.
5. **Foi eliminado:** retorna como cidadão depois de 16 segundos. Quem já tem
   acesso pode comentar **LUTAR** para voltar, sem outra Rosa. Pontos ficam salvos.

O evento de novo seguidor concede a entrada. O conector não consulta a lista de
seguidores antigos: acesso já concedido nesta instalação fica salvo, mas uma
relação de seguidor anterior nunca vista pelo jogo não é inferida.

Cidadãos podem ser atingidos pelas zonas anunciadas de Sukuna. O Santuário é
perigoso para toda a colônia. A entrada em combate não garante vitória, proteção
permanente ou uma posição duplicada na reserva.

## Personagens e luta

Heróis: **Gojo, Yuji, Megumi e Yuta**. Time Kenjaku: **Kenjaku, Mahito e Jogo**.
**Sukuna** é um chefe NPC e ameaça ambos os lados. Os times competem entre si e
também enfrentam o chefe. Há 28 técnicas dos personagens jogáveis e quatro do
chefe, com custos, recargas e bases visuais independentes.

Socos, rajadas alternadas, chutes aéreos e arrancadas/teleporte usam os acentos
musicais. O dano comum é proporcional à cadência; batidas mais rápidas não
significam dano multiplicado pela quantidade de rastros decorativos.

Azul puxa e controla o alvo, Vermelho repele, Nue aplica controle breve e o Vazio
interrompe o rival. Rika/invocações, Cães Divinos, cortes, meteoros, feixes,
explosões e domínios usam efeitos próprios ou bases de efeitos compartilhadas.
O domínio do Gojo usa espaço escuro com filamentos e estrelas; o Santuário
manifesta uma estrutura no cenário. Alguns nomes/efeitos foram adaptados para
identificação e equilíbrio na LIVE.

## Comandos do chat

| Comando | Resultado |
|---|---|
| PODER ou TECNICA 1 | Primeira técnica do personagem |
| TECNICA 2 / TECNICA 3 | Outras técnicas, com energia e recarga |
| DOMINIO | Quarta técnica / expansão, com energia e recarga |
| REVERSA | +35 vida por 30 energia, recarga de dez segundos |
| DEFESA | Reduz um golpe comum em cerca de 70%; janela de 3,5 s |
| ESQUIVA | Evita um golpe comum; janela de 1,8 s |
| PULAR / DANÇAR | Animações; não concedem invulnerabilidade |
| ALVO @usuario | Prioriza um combatente rival; Kenjaku também pode marcar cidadãos |
| ALVO SUKUNA | Volta à seleção automática, que inclui Sukuna |
| LUTAR | Reentrada de quem já tem acesso, após o retorno |
| KOGANE / REGRAS | Mostra as opções de regra |

Técnicas automáticas continuam durante a batalha; comandos e presentes dão
controle ao espectador. O chefe sinaliza áreas de perigo antes do impacto.
Há uma expansão de domínio por vez; não há sistema de colisão de domínios nesta
versão inicial. Ataques de área fortes atravessam defesas comuns.

## Presentes

| Presente padrão | Efeito |
|---|---|
| Rosa / Rose (ID 5655) | Libera entrada; repetição não duplica vaga |
| Heart Me | +35 energia, limitado a 100 |
| GG | Reversão: +45 vida, limitada ao HP máximo |
| Perfume | Terceira técnica do personagem, sem custo de energia |
| Galaxy / Galáxia | Domínio, sem custo de energia |
| Lion / Leão | +55 vida, energia cheia e despertar por 14 s |

Recargas e domínio ocupado continuam valendo para presentes. Nesses casos,
o presente de poder é convertido em energia e o jogo informa a conversão.
Fora da batalha, um poder pode ficar guardado para a entrada; outro presente
enquanto já há poder guardado vira energia. Cura recebida durante a eliminação
fica guardada para a próxima entrada. Limites evitam filas infinitas de efeitos.

Os seis presets reconhecem nomes comuns em inglês/português. Em **Presentes
personalizados**, o apresentador pode associar outros IDs a `rose`, `energy`,
`reverse`, `special`, `domain` ou `awakening`. Exemplo:

```json
{"5655":"rose","12345":"reverse"}
```

`12345` é um exemplo, não um ID verificado de presente. Nomes/IDs podem variar
no TikTok; valide os presentes usados na sua LIVE. Outros presentes sem
mapeamento não ativam uma técnica. A contagem de combo é normalizada somente
no fechamento da sequência, para não criar entradas duplicadas.

## Pontos e regras de Kogane

Eliminar um feiticeiro rende **5 pontos**; um cidadão, **1**. A derrota do chefe
NPC concede cinco ao finalizador. Sukuna não recebe pontos de jogador.
O ranking mostra o total conquistado; o saldo disponível é separado.

Com **100 pontos disponíveis**, o usuário pode comentar:

| Regra | Efeito aceito |
|---|---|
| REGRA REFUGIO | Cidadãos protegidos por 45 segundos |
| REGRA TROCA | Libera TRANSFERIR @usuario quantidade por 90 segundos |
| REGRA RESGATE | Retorna o aliado eliminado há mais tempo, mantendo time/personagem |
| REGRA FLUXO | Energia regenera ×1,5 para os dois times por 45 segundos |

Uma proposta aceita custa 100 pontos. Proposta inválida, repetida enquanto
ativa ou sem aliado elegível para resgate não cobra pontos. Transferências
exigem saldo e regra ativa, de 1 a 50 pontos por comando; não criam pontos novos
nem aumentam o total conquistado no ranking.

É uma adaptação para LIVE: proteção inicial, respawn, durações curtas e opções
fixas tornam a partida contínua. Não reproduz o prazo de 19 dias nem todas as
regras narrativas do mangá. Kogane rejeita regras arbitrárias que acabariam com
a colônia. Texto do chat não executa comandos de computador.

## Música, voz e efeitos

Em **Música e áudio**, escolha MP3/WAV/M4A ou toque a **trilha original da
colônia**. O loop original incluído tem 32 segundos, 120 BPM, sem amostras de
gravações comerciais. O player lê arquivos locais sem decodificar uma hora
inteira na RAM. Há BPM manual, TAP, sensibilidade Phonk/Sensível/Suave e
compensação Bluetooth de 0 a 400 ms.

**27 clipes neurais em inglês** já estão incluídos como WAV. São interpretações
sintéticas originais, com timbres ajustados; não são gravações ou réplicas dos
dubladores. O jogo não instala Piper, Gemini, Qwen ou clonador no celular e não
precisa de API para essas falas. São chamadas de batalha preparadas, não uma IA
de conversa livre. Domínios têm prioridade; chamadas menores podem ser
descartadas para não criar atraso na fila. Vozes e efeitos possuem controles.

Para **GreenTube/outro app**, use o APK Pulso Batida incluído em
`public/downloads/`. Configure a porta **3200**, gere o código de pareamento no
jogo e digite no captador. Quem já tem Pulso Batida 0.2.1 pode usá-lo sem
reinstalação. O padrão Visualizer depende da saída liberada pelo Android e
pode não receber áudio em algumas rotas Bluetooth. Captura compartilhada
avançada pode interromper outra captura de tela; prefira arquivo local ou o
modo padrão durante a transmissão. Veja `android/README.md`.

## Conectar à LIVE

Inicie sua transmissão pelo aplicativo habitual. No jogo, informe somente o @
em **Conectar à sua LIVE** e aguarde **LIVE · CONECTADA**. O conector usa eventos
públicos, sem pedir a senha da conta. A reconexão é manual.

Demo e LIVE têm dados separados. Botões de simulação, pontos de teste e domínio
forçado do chefe são recusados no modo LIVE. Sem conexão confirmada, o relógio
dos perigos é congelado para evitar dano ocorrido durante a desconexão.

A integração foi testada com eventos e conexão controlados; ainda falta validar
uma LIVE real na conta e no Realme GT3. O TikTok pode alterar o protocolo.

## Qualidade e estabilidade

Perfis Leve, Equilibrado e Detalhado ajustam resolução, sombras, brilho e atores
visíveis. Até 12 combatentes no motor, 8/12 desenhados conforme o perfil, mais
Sukuna e parte dos cidadãos. O restante continua cadastrado. Limites: 5.000
usuários, 200 na reserva, 48 elementos de energia e quatro invocações no pool;
Leve reduz efeitos. Nem todos os participantes ficam no enquadramento ao mesmo
tempo: a câmera alterna foco, dupla e domínio.

O supervisor recupera o servidor filho até quatro vezes em 15 minutos e para
ao atingir o limite. O Android ainda pode encerrar todo o Termux; um supervisor
interno não sobrevive a isso. Libere atividade em segundo plano e observe
bateria/temperatura no GT3. Não há promessa de LIVE ilimitada.

## Dados, atualização e reversão

`data/demo.json` e `data/live.json` guardam personagens, equipes, pontos,
admissão, reserva, regras vigentes e deduplicação. Há gravação atômica e backup
`.bak`. Queda abrupta pode perder o último segundo de eventos ainda não salvos.

Antes de atualizar, pare o jogo e guarde a pasta completa. Versões futuras do
mesmo projeto usarão `ATUALIZAR.sh` com validação de manifesto e backup ZIP. O
atualizador **recusa** pastas PULSO/Ben 10. Para reverter, pare, restaure código
e dados do backup juntos, execute `bash install.sh` e `bash start.sh`.

Logs: `logs/server.jsonl` e `logs/supervisor.jsonl`. O servidor registra estado,
memória e saídas; o supervisor registra código e sinal. Não se sabe a causa de
um encerramento do Android apenas pela ausência de uma mensagem no terminal.

## Desenvolvimento

`npm test` executa testes unitários e HTTP. Resultados e pendências em
`docs/RELATORIO_V0_1.md`, arquitetura em `docs/ARQUITETURA.md`, evidências em
`docs/evidencias/`. Prévias são capturas reais do renderer, algumas com quadros
preparados para inspeção; não são benchmarks do GT3.

O projeto usa Babylon.js local, sem CDN. Créditos e fontes de áudio em
`docs/TERCEIROS.md`. Modelos, cidade, ícones, efeitos, loop musical e composição
das falas desta versão foram criados para este projeto.
