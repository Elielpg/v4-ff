# Limites e próximos passos — 0.1.0

| ID | Estado / próximo passo |
|---|---|
| JJK-001 | LIVE pública real não validada na conta. Testar join/follow/rosa/streak/like/comment/share no GT3. |
| JJK-002 | Android pode encerrar todo o Termux. Supervisor recupera o filho; não sobrevive ao encerramento do aplicativo inteiro. Medir bateria, temperatura e logs. |
| JJK-003 | FPS, memória do navegador e duração de 30/60 min no GT3 pendentes. A simulação de 30 min virtuais e SwiftShader não equivalem ao aparelho. |
| JJK-004 | Captura GreenTube/Bluetooth depende do sinal disponibilizado pelo Android. APK preservado; testar na rota real. Configurar porta 3200. |
| JJK-005 | Modelos são procedurais estilizados, com animação procedural. Evoluir roupas/rigs, poses, colisão visual e expressões após avaliação da primeira versão. |
| JJK-006 | Algumas técnicas compartilham bases visuais de energia. Evoluir invocações, variações específicas e colisões sem perder o limite de recursos. |
| JJK-007 | Um domínio por vez. Confronto entre expansões ainda não implementado; presente bloqueado por domínio/recarga vira energia. |
| JJK-008 | Câmera alterna focos; nem todos os cidadãos/lutadores ficam visíveis simultaneamente. Tags podem coincidir em multidões; domínios ocultam tags para preservar a cena. |
| JJK-009 | Falas inglesas são 27 clipes preparados; não há conversa livre nem leitura do nome pela voz. Chamadas menores podem ser descartadas para evitar atraso. |
| JJK-010 | Reconhecimento de seguidor antigo só existe se já foi observado e salvo nesta instalação. O conector não consulta a relação histórica de seguidores. |
| JJK-011 | Queda abrupta pode perder o último segundo de eventos e o TikTok não garante replay. Backup reduz perda de estado já salvo. |
| JJK-012 | Não foram implementados todos os personagens/arcos/regras do mangá. Respawn, proteção e regras temporárias são adaptações de LIVE. |

## Corrigido durante a implementação

- Campo de tipo visual sobrescrevia o tipo do evento: `kind` agora é fixado
  pelo motor, e técnicas chegam como eventos de técnica ao navegador.
- Controle/repulsão são aplicados no motor, não apenas como luz decorativa.
- Regras pagas continuam válidas após recuperação, até sua expiração real.
- Resgate mantém o time e o personagem do aliado.
- Cura recebida durante a eliminação fica guardada para a entrada.
- Domínios e poderes fortes têm prioridade de câmera e áudio sobre cortes menores.
- Sem conexão LIVE, perigos pendentes têm seu relógio congelado.
- Tags foram reduzidas e ficam ocultas durante expansões para não cobrir a cena.
- Todas as referências de falas foram conferidas com WAV existente e não silencioso.
