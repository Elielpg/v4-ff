# Arquitetura — Colônia Zero

```mermaid
flowchart LR
    T[TikTok LIVE] --> A[Normalizador de eventos]
    D[Botões de demonstração] --> X[Estado demo isolado]
    A --> E[Motor autoritativo LIVE]
    M[Player local ou captador Android] --> P[Detector multifaixa]
    P --> E
    P --> X
    E --> S[SSE / snapshots]
    X --> S
    S --> W[Babylon: cidade / atores / câmera / FX]
    S --> V[Clipes neurais / efeitos sonoros]
    E --> B[Snapshot atômico + backup]
    U[Supervisor separado] --> E
```

- `server/engine.mjs`: cidadãos, entrada por seguidor/Rosa, sorteio, reserva,
  dano, defesa, energia, pontos, regras de Kogane, chefe e perigos anunciados.
  O navegador não decide dano, saldo ou resultado de uma proposta.
- `public/catalog.js`: fonte única de personagens, quatro técnicas de cada
  perfil, nomes, energia, recargas, cor, som, regras e presentes.
  `server/catalog.mjs` reexporta esse catálogo.
- `server/index.mjs`: HTTP restrito ao loopback, limites de corpo, origem,
  SSE, modos isolados, ponte de eventos, persistência e encerramento.
- `server/live.mjs`: conector com cancelamento de sessão antiga, sem repetir
  automaticamente uma conexão não confirmada. Seguidor antigo não é inferido.
- `server/rhythm.mjs`, `public/onset.js`, `public/beat-meter.js`: análise de
  graves/percussão, separação de andamento e acentos, pareamento, timestamps e
  lotes numéricos do captador. O APK não manda gravações ao servidor.
- `public/world.js`: cidade procedural, personagens, domínios, Kogane, câmera,
  nomes e projeção de comentários. `public/motion.js` fornece curvas testáveis.
- `public/fx.js`: pool de energia, cortes, anéis, fragmentos e invocações.
  Nenhum presente cria um emissor infinito.
- `public/toon.js`: iluminação em faixas e fallback de material.
- `public/audio.js`: leitura do player, detecção e efeitos sintetizados.
  `public/sound.js`: cache de clipes ingleses, prioridade, interrupção e descarte
  de chamadas antigas. Não usa voz do aparelho nem fila de síntese pesada.
- `scripts/supervisor.mjs`, `scripts/instance.mjs`: identificação da própria
  instalação, recuperação limitada e parada segura do servidor filho.
- `scripts/update.py`: verifica projeto, hashes, caminhos e backup antes de
  copiar uma atualização do mesmo jogo.

## Persistência e limites

Schema 1 exige `project: "jujutsu-live"`; dados do PULSO não são importados.
Persistem equipe, personagem, pontos disponíveis/conquistados, vida, acesso,
deduplicação e reserva. Comandos/poderes em trânsito não são repetidos após
reinício. Regras temporárias preservam a data de expiração. Perigos não são
aplicados retroativamente após reinício.

Máximos: 5.000 jogadores, 200 na reserva, 12 combatentes, 4.096 IDs deduplicados,
40 eventos recentes e 30 registros de regras. A resposta pública limita cidadãos
e mantém combatentes, ranking e comentários recentes. O áudio mantém até 12
clipes decodificados e não acumula uma fila de falas atrasadas.

## O que não é executado no celular

A geração neural dos 27 WAVs foi feita durante a produção com Piper e um modelo
inglês. Só os clipes prontos são entregues. Modelos ONNX, Python de síntese,
clonagem e serviço externo de IA não fazem parte da execução do jogo.

## Fronteiras de segurança

Chat vira somente comandos reconhecidos e texto escapado pela DOM. Kogane
aceita apenas quatro IDs de regra; não há `eval`, shell ou acesso arbitrário a
arquivos a partir de comentários. O mapeamento de presentes aceita somente IDs
numéricos e seis efeitos conhecidos. Rotas demo não funcionam na LIVE.

O captador usa código curto temporário, token de sessão e amostras com sequência
e tempo. Token não entra nos snapshots. API local não deve ser exposta na
internet; esta entrega escuta `127.0.0.1`.
