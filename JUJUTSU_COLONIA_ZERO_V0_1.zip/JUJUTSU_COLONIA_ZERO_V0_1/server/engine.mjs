import { CHARACTERS, TECHNIQUES, RULE_OPTIONS, GIFT_GUIDE, giftEffect } from "./catalog.mjs";
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const clean = (v, n = 40) => String(v ?? "").replace(/[\x00-\x1f<>]/g, "").trim().slice(0, n);
const norm = v => clean(v).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/^@/, "");
export function hash(s) { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; }
export const RULES = { sorcererPoints: 5, citizenPoints: 1, ruleCost: 100, maxPlayers: 5000, maxActive: 12, maxQueue: 200, maxHp: 200, respawnMs: 16000, welcomeProtectionMs: 12000 };
export class ArenaEngine {
  constructor({ now = Date.now, saved = null, mode = "demo", onAction = () => {} } = {}) {
    Object.assign(this, { now, mode, onAction });
    this.players = new Map(); this.queue = []; this.seen = new Map(); this.recent = [];
    this.seq = 0; this.turn = 0; this.rng = hash("colonia-zero"); this.lastTick = now(); this.nextBeat = now() + 550;
    this.lastPulse = -Infinity; this.lastBeat = 0; this.lastExternalBeat = 0; this.lastBeatSource = "manual";
    this.beatMs = 545; this.musicSource = "manual"; this.running = false; this.round = 1; this.battleMs = 0;
    this.notice = null; this.domain = null; this.hazard = null; this.nextHazard = now() + 20000;
    this.activeRules = []; this.ruleHistory = []; this.settings = { giftMap: {}, maxActive: 12 };
    this.boss = { id: "sukuna", name: "Sukuna", character: "sukuna", team: "boss", hp: 850, maxHp: 850, energy: 0, x: 0, z: 0, alive: true, defeatedUntil: 0, cooldowns: {} };
    this.totals = { likes: 0, comments: 0, gifts: 0, shares: 0, followers: 0, eliminations: 0 };
    if (saved) this.restore(saved);
  }
  random() { this.rng = (Math.imul(this.rng, 1664525) + 1013904223) >>> 0; return this.rng / 4294967296; }
  action(kind, data = {}) { const a = { ...data, id: ++this.seq, at: this.now(), kind }; this.recent.push(a); this.recent = this.recent.slice(-40); this.onAction(a); return a; }
  announce(text, kind = "info") { this.notice = { text, kind, until: this.now() + 5500 }; }
  player(id, name) {
    id = norm(id); if (!id || id === "sukuna") return null;
    if (!this.players.has(id)) {
      if (this.players.size >= RULES.maxPlayers) {
        const old = [...this.players.values()].filter(p => p.status === "citizen" && !this.queue.includes(p.id)).sort((a,b) => a.lastSeen-b.lastSeen)[0];
        if (!old) return null; this.players.delete(old.id);
      }
      const seed = hash(id), angle = (seed % 360) * Math.PI / 180;
      this.players.set(id, { id, name: clean(name || id, 25), seed, team: "neutral", character: "citizen", status: "citizen", hp: 70, maxHp: 70, energy: 0, points: 0, earned: 0, kills: 0, deaths: 0, likes: 0, likeCarry: 0, support: 0, followed: false, admitted: false, x: Math.sin(angle)*12, z: Math.cos(angle)*12, joinedAt: this.now(), lastSeen: this.now(), protectedUntil: this.now()+RULES.welcomeProtectionMs, cooldowns: {}, guardUntil: 0, dodgeUntil: 0, nextEntryAt: 0, chat: null });
    }
    const p = this.players.get(id); p.lastSeen = this.now(); if (name) p.name = clean(name,25); return p;
  }
  ingest(e) {
    if (!e || !["join","comment","like","share","follow","gift"].includes(e.type)) return { accepted:false, reason:"Evento inválido" };
    if (e.type === "gift" && e.repeatEnd === false) return { accepted:false, reason:"Aguardando fim da sequência" };
    const msg = clean(e.id,100); const key = e.type+":"+msg;
    if (msg && this.seen.has(key)) return { accepted:false, reason:"Duplicado" };
    if (e.type === "like" && !(Number(e.count ?? 1)>0)) return { accepted:false, reason:"Sem incremento" };
    if (msg) { this.seen.set(key,this.now()); while(this.seen.size>4096) this.seen.delete(this.seen.keys().next().value); }
    const count = clamp(Math.floor(Number(e.count)||1),1,50000);
    if (!e.user && e.type === "like") { this.totals.likes += count; return {accepted:true, attributed:false}; }
    const existed = this.players.has(norm(e.user)); const p = this.player(e.user,e.name); if (!p) return {accepted:false,reason:"Usuário inválido ou limite"};
    if (e.type === "join") {
      this.running=true;
      if (!existed || this.now()-(p.lastWelcome||0)>60000) { p.lastWelcome=this.now(); this.action("welcome",{player:p.id}); this.announce(`@${p.id} chegou à cidade. SIGA ou envie ROSA para lutar.`); }
      if (p.admitted && p.status === "citizen") this.enter(p,"retorno");
    }
    if (e.type === "follow") { this.totals.followers++; p.followed=true; p.admitted=true; this.action("follow",{player:p.id}); this.enter(p,"seguidor"); }
    if (e.type === "like") {
      p.likes+=count; this.totals.likes+=count; const gain=Math.floor((p.likeCarry+count)/10); p.likeCarry=(p.likeCarry+count)%10;
      p.energy=clamp(p.energy+gain,0,100); p.healPool=clamp((p.healPool||0)+gain,0,25);
      this.action("likes",{player:p.id,count,energy:gain});
    }
    if (e.type === "share" && this.now()-(p.lastShare||0)>=15000) { p.lastShare=this.now(); p.support=clamp(p.support+3,0,30); p.energy=clamp(p.energy+10,0,100); this.totals.shares++; this.action("support",{player:p.id}); }
    if (e.type === "comment") {
      this.totals.comments++; const text=clean(e.text,140); p.chat={text,at:this.now(),until:this.now()+6500}; this.action("comment",{player:p.id,text});
      this.command(p,text);
    }
    if (e.type === "gift") {
      this.totals.gifts+=count; const effect=giftEffect(e,this.settings.giftMap);
      this.action("gift",{player:p.id,effect,gift:clean(e.gift,35),count});
      if (effect === "rose") { p.admitted=true; this.enter(p,"rosa"); if(p.status==="fighter") p.energy=clamp(p.energy+Math.min(20,count*5),0,100); }
      if (effect === "energy") p.energy=clamp(p.energy+35*Math.min(3,count),0,100);
      if (effect === "reverse") this.reverse(p,45);
      if (["special","domain","awakening"].includes(effect)) {
        if(p.status!=="fighter") { if(p.pendingGift){p.energy=clamp(p.energy+50,0,100);this.announce(`@${p.id}: um poder já está guardado; este presente virou energia.`);}else{p.pendingGift=effect;this.announce(`@${p.id}: poder guardado. SIGA ou mande ROSA para entrar.`);} }
        else this.giftPower(p,effect);
      }
    }
    return { accepted:true, player:p.id, status:p.status };
  }
  enter(p, source) {
    if(p.status==="fighter" || this.queue.includes(p.id)) return false;
    if(p.nextEntryAt>this.now()) { this.announce(`@${p.id}: retorno em ${Math.ceil((p.nextEntryAt-this.now())/1000)}s.`); return false; }
    p.admitted=true;
    if(this.fighters().length>=this.settings.maxActive) {
      if(this.queue.length>=RULES.maxQueue) { this.announce("Reserva cheia. Tente novamente em instantes."); return false; }
      this.queue.push(p.id); this.action("queued",{player:p.id}); this.announce(`@${p.id} está na reserva · posição ${this.queue.length}. A entrada será automática.`); return true;
    }
    const keep=p.rescueTeam && ["gojo","kenjaku"].includes(p.team);
    const team=keep?p.team:this.random()<0.5?"gojo":"kenjaku", options=Object.keys(CHARACTERS).filter(id=>CHARACTERS[id].team===team);
    p.team=team; p.character=keep?p.character:options[Math.floor(this.random()*options.length)]; p.rescueTeam=false; p.status="fighter"; p.maxHp=RULES.maxHp; p.hp=clamp(160+(p.pendingHeal||0),0,RULES.maxHp); p.pendingHeal=0; p.energy=Math.max(40,p.energy); p.cooldowns={}; p.protectedUntil=this.now()+2500;
    const a=this.random()*Math.PI*2; p.x=Math.sin(a)*5.3; p.z=Math.cos(a)*5.3; p.combo=0;
    this.running=true; this.action("entrance",{player:p.id,team,character:p.character,source});
    this.announce(`@${p.id} → ${CHARACTERS[p.character].name} · TIME ${team==="gojo"?"GOJO":"KENJAKU"}`);
    if(p.pendingGift) { const effect=p.pendingGift; p.pendingGift=null; this.giftPower(p,effect); }
    return true;
  }
  fighters() { return [...this.players.values()].filter(p=>p.status==="fighter" && p.hp>0); }
  target(p) {
    const forced=this.players.get(p.target); if(forced?.hp>0 && ((forced.status==="fighter" && forced.team!==p.team)||(p.team==="kenjaku"&&forced.status==="citizen"))) return forced;
    const foes=this.fighters().filter(q=>q.id!==p.id && q.team!==p.team);
    if(this.boss.alive && (!foes.length || this.random()<(p.team==="gojo"?0.7:0.35))) return this.boss;
    return foes.length?foes[Math.floor(this.random()*foes.length)]:(this.boss.alive?this.boss:null);
  }
  command(p,text) {
    const cmd=norm(text), now=this.now();
    if(cmd==="lutar" && p.admitted) return this.enter(p,"comando");
    if(cmd==="kogane" || cmd==="regras") { this.announce(`KOGANE · ${p.points}/100 pontos. REGRA REFUGIO · TROCA · RESGATE · FLUXO`); return; }
    if(cmd.startsWith("regra ")) return this.proposeRule(p,cmd.slice(6).trim());
    const transfer=cmd.match(/^transferir @?([a-z0-9_.]+) (\d{1,3})$/);
    if(transfer) return this.transfer(p,transfer[1],Number(transfer[2]));
    const target=cmd.match(/^alvo @?([a-z0-9_.]+)$/); if(target) {const q=this.players.get(target[1]); if((q?.status==="fighter" && q.team!==p.team)||(q?.status==="citizen"&&p.team==="kenjaku")) p.target=q.id; else if(target[1]==="sukuna") p.target=null; return;}
    if(p.status!=="fighter") return;
    if(["defesa","esquiva"].includes(cmd) && now-(p.lastPose||0)>=2500) {
      p.lastPose=now; if(cmd==="defesa") p.guardUntil=now+3500; else p.dodgeUntil=now+1800;
      this.action("pose",{player:p.id,pose:cmd}); return;
    }
    if(cmd==="reversa") { if(p.energy>=30 && now>=(p.cooldowns.reverse||0)) {p.energy-=30;p.cooldowns.reverse=now+10000;this.reverse(p,35);} return; }
    const c=CHARACTERS[p.character]; let index=-1;
    if(cmd==="poder" || cmd==="tecnica 1") index=0; if(cmd==="tecnica 2") index=1; if(cmd==="tecnica 3") index=2; if(cmd==="dominio") index=3;
    if(index>=0) return this.cast(p,c.techniques[index]);
    if(cmd==="pular" || cmd==="dancar") this.action("pose",{player:p.id,pose:cmd});
  }
  reverse(p,hp) {
    if(p.status==="dead") {p.pendingHeal=clamp((p.pendingHeal||0)+hp,0,100);this.announce(`@${p.id}: cura guardada para o retorno.`);return;}
    p.hp=clamp(p.hp+hp,0,p.maxHp);this.action("heal",{player:p.id,hp});
  }
  giftPower(p,effect) {
    if(effect==="awakening") {this.reverse(p,55);p.energy=100;p.awakenedUntil=this.now()+14000;this.action("awakening",{player:p.id});return;}
    const id=CHARACTERS[p.character].techniques[effect==="domain"?3:2];
    if(this.now()<(p.cooldowns[id]||0) || (effect==="domain" && this.domain)) {p.energy=clamp(p.energy+50,0,100);this.announce("Poder em recarga: presente convertido em energia.");return;}
    if(!this.cast(p,id,true)){p.energy=clamp(p.energy+50,0,100);this.announce(`@${p.id}: sem alvo disponível; presente convertido em energia.`);}
  }
  cast(p,id,gift=false) {
    const spec=TECHNIQUES[id], now=this.now(); if(!spec || p.status!=="fighter") return false;
    if(now<(p.cooldowns[id]||0)) {this.announce(`${spec.name} · recarga ${Math.ceil((p.cooldowns[id]-now)/1000)}s`);return false;}
    if(spec.domain && this.domain) {this.announce("Já existe um domínio ativo. Aguarde a janela de expansão.");return false;}
    if(!gift && p.energy<spec.cost) {this.announce(`@${p.id}: ${Math.ceil(spec.cost-p.energy)} de energia para ${spec.name}. TAP TAP ajuda!`);return false;}
    const target=this.target(p); if(!target) return false;
    if(!gift) p.energy-=spec.cost; p.cooldowns[id]=now+spec.cooldown;
    if(spec.domain) this.domain={player:p.id,character:p.character,technique:id,until:now+5200};
    this.action("technique",{player:p.id,target:target.id,technique:id,...spec,character:p.character,duration:spec.domain?5.2:1.2,gift});
    this.damage(p,target,spec.power*(1+p.support/100),id,spec.domain);
    if(["blue","gravity","nue","void","shadows"].includes(id)) {
      target.stunnedUntil=now+(id==="void"?1800:900);
      if(target.id!=="sukuna"){const dx=target.x-p.x,dz=target.z-p.z;target.x-=dx*.25;target.z-=dz*.25;}
    }
    if(id==="red"&&target.id!=="sukuna"){const dx=target.x-p.x,dz=target.z-p.z,n=Math.hypot(dx,dz)||1;target.x=clamp(target.x+dx/n*2,-10,10);target.z=clamp(target.z+dz/n*2,-10,10);target.stunnedUntil=now+600;}
    if(id==="bond")for(const ally of this.fighters().filter(q=>q.team===p.team))ally.hp=clamp(ally.hp+12,0,ally.maxHp);
    if(spec.domain) for(const q of this.fighters().filter(q=>q.id!==p.id && q.id!==target.id && q.team!==p.team).slice(0,5)) this.damage(p,q,spec.power*0.45,id,true);
    return true;
  }
  damage(a,b,raw,move="jab",pierce=false) {
    if(!b || b.hp<=0 || (b.id!=="sukuna" && b.protectedUntil>this.now())) return 0;
    if(b.status==="citizen" && this.activeRules.some(r=>r.id==="refugio" && r.until>this.now())) return 0;
    const defense=!pierce && b.dodgeUntil>this.now()?"dodge":!pierce && b.guardUntil>this.now()?"block":"none";
    let amount=Math.max(1,Math.round(raw)); if(defense==="dodge") amount=0; if(defense==="block") amount=Math.max(1,Math.round(amount*0.3));
    if(defense!=="none") {b.dodgeUntil=0;b.guardUntil=0;}
    b.hp=Math.max(0,b.hp-amount); if(a && a.id!=="sukuna") a.damageDealt=(a.damageDealt||0)+amount;
    this.action("damage",{player:a?.id||"sukuna",target:b.id,damage:amount,move,defense,hp:b.hp});
    if(b.hp<=0) this.eliminate(a,b); return amount;
  }
  eliminate(a,b) {
    if(b.id==="sukuna") {
      if(!b.alive) return; b.alive=false;b.defeatedUntil=this.now()+8500;this.hazard=null;if(this.domain?.player==="sukuna")this.domain=null;
      if(a?.id!=="sukuna" && a) this.award(a,5);
      this.action("bossDefeated",{player:a?.id||"",round:this.round});this.announce("SUKUNA CAIU · a cidade respira. Próxima onda em 8s.");return;
    }
    if(b.status==="dead") return;
    const points=b.status==="fighter"?5:1;
    b.status="dead";b.deaths++;b.nextEntryAt=this.now()+RULES.respawnMs;b.eliminatedAt=this.now();this.queue=this.queue.filter(id=>id!==b.id);
    if(a && a.id!=="sukuna") this.award(a,points);
    this.totals.eliminations++;this.action("elimination",{player:a?.id||"sukuna",target:b.id,points:a?.id!=="sukuna"?points:0});
  }
  award(p,n) {p.points+=n;p.earned+=n;p.kills++;if(p.points>=100)this.announce(`KOGANE · @${p.id}, você tem ${p.points} pontos. Digite REGRA REFUGIO, TROCA, RESGATE ou FLUXO.`);}
  proposeRule(p,id) {
    const rule=RULE_OPTIONS[id];if(!rule) {this.announce("Kogane: regra fora das opções permitidas.");return false;}
    if(p.points<100) {this.announce(`Kogane: faltam ${100-p.points} pontos.`);return false;}
    if(this.activeRules.some(r=>r.id===id && r.until>this.now())) {this.announce("Kogane: essa regra já está ativa.");return false;}
    let rescue;
    if(id==="resgate") {rescue=[...this.players.values()].filter(q=>q.team===p.team && q.status==="dead").sort((a,b)=>a.eliminatedAt-b.eliminatedAt)[0];if(!rescue){this.announce("Kogane: nenhum aliado eliminado para resgatar.");return false;}}
    p.points-=100;
    if(rule.duration) this.activeRules.push({id,by:p.id,until:this.now()+rule.duration});
    if(rescue) {rescue.status="citizen";rescue.nextEntryAt=0;rescue.hp=70;rescue.rescueTeam=true;this.enter(rescue,"regra de resgate");}
    this.ruleHistory.push({id,by:p.id,at:this.now()});this.ruleHistory=this.ruleHistory.slice(-30);
    this.action("rule",{player:p.id,rule:id,label:rule.label});this.announce(`KOGANE ACEITOU · ${rule.label} · @${p.id}`);return true;
  }
  transfer(p,id,amount) {
    const target=this.players.get(id);
    if(!this.activeRules.some(r=>r.id==="troca" && r.until>this.now()) || !target || target.id===p.id || amount<1 || amount>50 || !Number.isInteger(amount) || p.points<amount) return false;
    p.points-=amount;target.points+=amount;this.action("transfer",{player:p.id,target:id,points:amount});return true;
  }
  setMusic({source,bpm}={}) {if(["manual","file","paused","external"].includes(source))this.musicSource=source;if(Number.isFinite(bpm))this.beatMs=60000/clamp(bpm,50,240);this.nextBeat=this.now()+this.beatMs;if(source==="file")this.lastExternalBeat=this.now();}
  beat({source="manual",interval,pulseInterval,strength=1,at}={}) {
    const now=this.now(), sample=Number.isFinite(at)?at:now;
    if(!this.running || this.musicSource==="paused" || now-sample>500 || sample-now>50 || sample-this.lastPulse<95)return false;
    const gap=sample-this.lastPulse;this.lastPulse=sample;this.lastBeat=now;this.lastBeatSource=source;
    if(source==="file"||source==="external"){this.musicSource=source;this.lastExternalBeat=now;}
    if(Number.isFinite(interval))this.beatMs=clamp(interval,250,1200);this.nextBeat=now+this.beatMs;
    const cadence=clamp(Number(pulseInterval)||gap,95,this.beatMs),scale=cadence/this.beatMs;
    this.action("beat",{source,interval:this.beatMs,strength:clamp(Number(strength)||0.3,0.1,1),pulseInterval:cadence});
    const fighters=this.fighters();
    for(let i=0;i<Math.min(2,fighters.length);i++) {
      const p=fighters[(this.turn+i)%fighters.length];if(p.stunnedUntil>now)continue;const target=this.target(p);if(!target)continue;
      p.combo=((p.combo||0)%4)+1;const move=p.combo===4?"airKick":p.combo===3?"teleport":p.combo===2?"flurry":"jab";
      const black=(p.awakenedUntil||0)>now && p.combo===4;
      this.action("attack",{player:p.id,target:target.id,move,combo:p.combo,black,duration:clamp(cadence/1000*0.9,0.085,0.42),character:p.character});
      this.damage(p,target,(black?14:7+this.random()*3)*scale*(1+p.support/100),move);
      p.energy=clamp(p.energy+3*scale,0,100);
      if(p.combo===4 && this.random()<0.45) this.cast(p,CHARACTERS[p.character].techniques[Math.floor(this.random()*3)]);
    }
    this.turn++;
    if(this.boss.alive && fighters.length && this.turn%4===0 && !this.domain && !(this.boss.stunnedUntil>now)) {
      const target=fighters[Math.floor(this.random()*fighters.length)];
      const id=(Math.floor(this.turn/4)%2)?"cleave":"dismantle",spec=TECHNIQUES[id];
      if(now-(this.boss.lastTechnique||0)>=3500){this.boss.lastTechnique=now;this.action("technique",{player:"sukuna",target:target.id,character:"sukuna",technique:id,...spec,duration:.7});this.damage(this.boss,target,spec.power,id);}
      else{this.action("attack",{player:"sukuna",target:target.id,move:"teleport",combo:3,duration:0.24,character:"sukuna"});this.damage(this.boss,target,8,"cleave");}
      this.boss.energy=clamp(this.boss.energy+7,0,100);
    }
    return true;
  }
  tick() {
    const now=this.now(),dt=clamp(now-this.lastTick,0,250);this.lastTick=now;if(!this.running)return;
    this.battleMs+=dt;this.activeRules=this.activeRules.filter(r=>r.until>now);
    const flux=this.activeRules.some(r=>r.id==="fluxo")?1.5:1;
    for(const p of this.players.values()) {
      if(p.status==="dead" && p.nextEntryAt<=now) {p.status="citizen";p.hp=70;p.maxHp=70;p.protectedUntil=now+8000;this.action("return",{player:p.id});}
      if(p.status==="fighter") {p.energy=clamp(p.energy+dt/1000*4*flux,0,100);const heal=Math.min(p.healPool||0,dt/1000*2);p.healPool=Math.max(0,(p.healPool||0)-heal);p.hp=clamp(p.hp+heal,0,p.maxHp);}
      if(p.status==="citizen") {const t=now/1000+p.seed;p.x=Math.sin(t*0.045+p.seed)*12;p.z=Math.cos(t*0.045+p.seed)*12;}
      if(p.status==="fighter"&&!(p.stunnedUntil>now)) {const angle=now/4500+(p.seed%360)*Math.PI/180, radius=4.8+Math.sin(now/700+p.seed)*0.6;p.x=Math.sin(angle)*radius;p.z=Math.cos(angle)*radius;}
    }
    while(this.fighters().length<this.settings.maxActive && this.queue.length) {const p=this.players.get(this.queue.shift());if(p?.admitted && p.nextEntryAt<=now)this.enter(p,"reserva");}
    if(this.domain?.until<=now)this.domain=null;
    if(!this.boss.alive && this.boss.defeatedUntil<=now){this.round++;this.boss.alive=true;this.boss.maxHp=850+Math.min(1200,(this.round-1)*125);this.boss.hp=this.boss.maxHp;this.boss.energy=0;this.action("bossReturn",{round:this.round});}
    if(this.hazard && now>=this.hazard.resolveAt) {
      const h=this.hazard;this.hazard=null;
      this.action("hazardImpact",{...h});
      for(const p of this.players.values())if(p.status!=="dead" && Math.hypot(p.x-h.x,p.z-h.z)<=h.radius)this.damage(this.boss,p,h.power,h.technique,true);
    }
    if(this.boss.alive && !this.hazard && now>=this.nextHazard) {
      const domain=this.boss.energy>=70 && !this.domain;const radius=domain?22:5.5;
      this.hazard={x:domain?0:Math.sin(now)*8,z:domain?0:Math.cos(now)*8,radius,power:domain?105:40,technique:domain?"shrine":"furnace",resolveAt:now+(domain?4200:2800)};
      this.nextHazard=now+(domain?22000:14000);if(domain){this.boss.energy=0;this.domain={player:"sukuna",character:"sukuna",technique:"shrine",until:now+6500};}
      this.action("hazard",{...this.hazard});this.announce(domain?"SUKUNA · SANTUÁRIO MALEVOLENTE · BUSQUE REFÚGIO!":"SUKUNA PREPARA A FORNALHA · zona marcada em vermelho");
    }
    const musical=this.musicSource==="manual" || (this.musicSource==="file" && now-this.lastExternalBeat>1500);
    if(musical && now>=this.nextBeat)this.beat({source:this.musicSource==="manual"?"manual":"estimated"});
    if(this.notice?.until<now)this.notice=null;
  }
  configure(data) {
    if(data.maxActive!==undefined && Number.isInteger(data.maxActive))this.settings.maxActive=clamp(data.maxActive,2,12);
    if(data.giftMap && typeof data.giftMap==="object" && !Array.isArray(data.giftMap)) {
      const entries=Object.entries(data.giftMap);if(entries.length>40)throw Error("Máximo de 40 presentes personalizados");
      const map={};for(const [key,v] of entries){if(!/^\d{1,10}$/.test(key) || !GIFT_GUIDE.some(g=>g.id===v))throw Error("Mapeamento inválido");map[key]=v;}this.settings.giftMap=map;
    }
  }
  freeze(now=this.now()) {const dt=Math.max(0,now-this.lastTick);this.lastTick=now;this.nextBeat+=dt;this.nextHazard+=dt;if(this.hazard)this.hazard.resolveAt+=dt;if(this.domain)this.domain.until+=dt;if(!this.boss.alive)this.boss.defeatedUntil+=dt;}
  public() {
    const all=[...this.players.values()];const ranking=[...all].sort((a,b)=>b.earned-a.earned||(b.damageDealt||0)-(a.damageDealt||0)).slice(0,8);
    const exposed=[...new Map([...all.slice(-70),...all.filter(p=>p.status==="fighter"),...all.filter(p=>p.chat?.until>this.now()).slice(-8),...ranking].map(p=>[p.id,p])).values()];
    return {version:"0.1.0",project:"jujutsu-live",mode:this.mode,serverTime:this.now(),running:this.running,round:this.round,players:exposed,totalPlayers:all.length,boss:{...this.boss},queue:[...this.queue],ranking,totals:{...this.totals},activeRules:this.activeRules,ruleOptions:Object.values(RULE_OPTIONS),ruleHistory:this.ruleHistory.slice(-5),notice:this.notice,domain:this.domain,hazard:this.hazard,recent:this.recent,lastAction:this.recent.at(-1),rhythm:{source:this.musicSource,effective:this.lastBeatSource,bpm:Math.round(60000/this.beatMs),lastBeat:this.lastBeat},teams:{gojo:all.filter(p=>p.team==="gojo"&&p.status==="fighter").length,kenjaku:all.filter(p=>p.team==="kenjaku"&&p.status==="fighter").length,citizens:all.filter(p=>p.status==="citizen").length},settings:this.settings,rules:RULES,giftGuide:GIFT_GUIDE};
  }
  save() {return {schema:1,project:"jujutsu-live",players:[...this.players.values()],queue:this.queue,seq:this.seq,rng:this.rng,seen:[...this.seen],totals:this.totals,round:this.round,boss:this.boss,settings:this.settings,ruleHistory:this.ruleHistory,activeRules:this.activeRules};}
  restore(s) {
    if(s.project!=="jujutsu-live"||s.schema!==1||!Array.isArray(s.players))return;
    for(const p of s.players.slice(-RULES.maxPlayers))if(p.id&&CHARACTERS[p.character])this.players.set(p.id,{...p,cooldowns:{},chat:null,protectedUntil:this.now()+5000,guardUntil:0,dodgeUntil:0,nextEntryAt:p.status==="dead"?this.now()+5000:0});
    this.queue=(s.queue||[]).filter(id=>this.players.has(id)).slice(0,200);this.seq=Number(s.seq)||0;this.rng=s.rng||this.rng;this.seen=new Map((s.seen||[]).slice(-4096));this.totals={...this.totals,...s.totals};this.round=s.round||1;
    if(s.boss?.maxHp>0){this.boss={...this.boss,...s.boss,cooldowns:{},defeatedUntil:this.now()+8000};}
    if(s.settings)this.configure(s.settings);this.ruleHistory=(s.ruleHistory||[]).slice(-30);this.activeRules=(s.activeRules||[]).filter(r=>RULE_OPTIONS[r.id]&&r.until>this.now()).slice(-4);this.running=this.players.size>0;
    this.announce("Colônia recuperada. Pontos, personagens e reserva preservados.");
  }
}
