import http from "node:http";
import path from "node:path";
import { readFile, mkdir, appendFile, stat, rename } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { ArenaEngine } from "./engine.mjs";
import { Store } from "./storage.mjs";
import { TikTokAdapter } from "./live.mjs";
import { RhythmBridge } from "./rhythm.mjs";
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."),
  PORT = Number(process.env.PORT || 3200),
  HOST = "127.0.0.1",
  store = new Store(process.env.JUJUTSU_DATA_DIR || path.join(ROOT, "data"));
const clients = new Set();
const rhythm = new RhythmBridge();
let mode = "demo",
  closing = false,
  demoTimer = null,
  lastBridgeAt = 0;
const logs = path.join(ROOT, "logs");
await mkdir(logs, { recursive: true });
async function log(kind, data = {}) {
  try {
    const f = path.join(logs, "server.jsonl");
    if ((await stat(f).catch(() => ({ size: 0 }))).size > 1e6)
      await rename(f, f + ".1").catch(() => {});
    await appendFile(
      f,
      JSON.stringify({ at: new Date().toISOString(), kind, ...data }) + "\n",
    );
  } catch {}
}
function emit(event, data) {
  const line = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of clients) {
    if (c.writableLength > 512000) {
      c.destroy();
      clients.delete(c);
      continue;
    }
    c.write(line);
  }
}
const engines = {};
for (const name of ["demo", "live"])
  engines[name] = new ArenaEngine({
    mode: name,
    saved: await store.read(name),
    onAction: (a) => {
      if (mode === name) emit("action", { ...a, mode: name });
      if (["queued", "rule", "entrance", "elimination", "bossDefeated"].includes(a.kind)) {
        void log(a.kind, { mode: name, player: a.player });
        if (engines[name])
          void store
            .save(name, engines[name].save())
            .catch((e) => log("save-error", { message: e.message }));
      }
    },
  });
const adapter = new TikTokAdapter(
  (e) => {
    engines.live.ingest(e);
    if (e.type === "gift")
      void store
        .save("live", engines.live.save())
        .catch((err) => log("save-error", { message: err.message }));
  },
  (s) => {
    emit("connection", s);
    void log("live-status", { status: s.status, message: s.message });
  },
);
const liveReady = () =>
  adapter.state.status === "connected" || Date.now() - lastBridgeAt < 30000;
const snapshot = () => ({
  ...engines[mode].public(),
  storageError: store.error,
  audio: rhythm.status(),
  connection:
    Date.now() - lastBridgeAt < 30000
      ? {
          status: "connected",
          message: "Ponte local de eventos ativa",
          provider: "webhook",
        }
      : adapter.state,
});
function json(res, status, obj) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(obj));
}
async function body(req) {
  if (!String(req.headers["content-type"] || "").startsWith("application/json"))
    throw Object.assign(Error("Use application/json"), { status: 415 });
  const origin = req.headers.origin;
  if (
    origin &&
    !new Set([`http://127.0.0.1:${PORT}`, `http://localhost:${PORT}`]).has(
      origin,
    )
  )
    throw Object.assign(Error("Origem recusada"), { status: 403 });
  let b = "";
  for await (const x of req) {
    b += x;
    if (b.length > 32768)
      throw Object.assign(Error("Evento muito grande"), { status: 413 });
  }
  return JSON.parse(b || "{}");
}
function startDemo() {
  void adapter.disconnect(); lastBridgeAt=0; clearInterval(demoTimer); mode="demo";
  const e=engines.demo;
  const names=["sora","luna","akira","yuki","ren","mika","kai","hana"];
  for(const id of names)e.ingest({type:"join",user:"demo_"+id,name:id.toUpperCase()});
  for(const id of names.slice(0,5))e.ingest({type:"follow",user:"demo_"+id});
  const shown=[["sora","gojo"],["luna","yuji"],["akira","kenjaku"],["yuki","megumi"],["ren","mahito"]];
  for(const [id,character] of shown){const p=e.players.get("demo_"+id);p.character=character;p.team=["kenjaku","mahito"].includes(character)?"kenjaku":"gojo";}
  let n=0;
  demoTimer=setInterval(()=>{if(mode!=="demo")return;const p=e.players.get("demo_"+names[n++%names.length]);e.ingest({type:"like",user:p.id,count:20});
    if(n%3===0)e.ingest({type:"comment",user:p.id,text:["PODER","TÉCNICA 2","REVERSA","DEFESA"][Math.floor(n/3)%4]});
    if(n%9===0 && p.status!=="fighter")e.ingest({type:"gift",user:p.id,gift:"Rosa",repeatEnd:true});
  },1700);
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://127.0.0.1");
    if (req.method === "GET" && url.pathname === "/api/state")
      return json(res, 200, snapshot());
    if (req.method === "GET" && url.pathname === "/api/events") {
      res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      });
      res.write("retry: 1500\n\n");
      clients.add(res);
      res.write("event: state\ndata: " + JSON.stringify(snapshot()) + "\n\n");
      req.on("close", () => clients.delete(res));
      return;
    }
    if (req.method === "POST" && url.pathname.startsWith("/api/")) {
      const data = await body(req),
        e = engines[mode];
      if (url.pathname === "/api/rhythm/code") {
        e.setMusic({ source: "external" });
        return json(res, 200, { ...rhythm.issue(), port: PORT });
      }
      if (url.pathname === "/api/rhythm/pair")
        return json(res, 200, rhythm.pair(data.code));
      if (url.pathname === "/api/rhythm/disconnect") {
        rhythm.revoke();
        if (e.musicSource === "external") e.setMusic({ source: "paused" });
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/rhythm/frame") {
        const frames = Array.isArray(data.frames) ? data.frames : [data];
        if (frames.length > 12 || frames.length === 0)
          return json(res, 400, { error: "Lote inválido" });
        let accepted = false;
        for (const frame of frames) {
          const result = rhythm.frame(req.headers.authorization, frame);
          accepted ||= result.accepted;
          if (result.hit && e.musicSource === "external") {
            const ticket = rhythm.generation,
              sourceMode = mode;
            const delay = Math.max(0, result.at + rhythm.offset - Date.now());
            const timer = setTimeout(() => {
              if (
                ticket !== rhythm.generation ||
                mode !== sourceMode ||
                e.musicSource !== "external" ||
                (mode === "live" && !liveReady())
              )
                return;
              e.beat({
                source: "external",
                ...result,
                at: result.at + rhythm.offset,
              });
            }, delay);
            timer.unref();
          }
        }
        return json(res, 200, { accepted });
      }
      if (url.pathname === "/api/rhythm/mode") {
        rhythm.setMode(data.mode);
        return json(res, 200, { mode: rhythm.mode });
      }
      if (url.pathname === "/api/rhythm/offset") {
        if (!Number.isFinite(data.offset))
          return json(res, 400, { error: "Atraso inválido" });
        rhythm.offset = Math.max(0, Math.min(400, data.offset));
        return json(res, 200, { ok: true, offset: rhythm.offset });
      }
      if (url.pathname === "/api/demo/start") {
        startDemo();
        return json(res, 200, snapshot());
      }
      if (url.pathname === "/api/demo/stop") {
        clearInterval(demoTimer);
        demoTimer = null;
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/demo/event") {
        if (mode !== "demo")
          return json(res, 409, { error: "Testes não entram na LIVE real." });
        const out = e.ingest(data);
        await store.save("demo", e.save());
        return json(res, 200, out);
      }
      if (url.pathname === "/api/settings") {
        e.configure(data); await store.save(mode,e.save()); return json(res,200,{ok:true,settings:e.settings});
      }
      if (url.pathname === "/api/rule") {
        const p=e.players.get(String(data.user||"").replace(/^@/,"").toLowerCase());
        if(!p)return json(res,400,{error:"Jogador não encontrado"});
        const accepted=e.proposeRule(p,String(data.rule||"")); await store.save(mode,e.save()); return json(res,200,{accepted});
      }
      if (url.pathname === "/api/demo/points") {
        if(mode!=="demo")return json(res,409,{error:"Pontos de teste só na demonstração"});
        const p=e.player(data.user||"demo_sora"); p.points+=100;p.earned+=100;
        await store.save(mode,e.save()); return json(res,200,{ok:true});
      }
      if (url.pathname === "/api/demo/boss") {
        if(mode!=="demo")return json(res,409,{error:"Comando de teste indisponível na LIVE"});
        if(e.domain||e.hazard)return json(res,409,{error:"Aguarde o domínio ou a zona atual terminar"});
        e.running=true;e.boss.alive=true;e.boss.energy=100;e.nextHazard=Date.now();e.tick();
        return json(res,200,{ok:true});
      }
      if (url.pathname === "/api/music") {
        e.setMusic(data);
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/beat") {
        if (mode === "live" && !liveReady())
          return json(res, 409, {
            error: "LIVE desconectada; combate pausado.",
          });
        if (e.musicSource === "external")
          return json(res, 409, {
            error:
              "Captador Android selecionado. Use o arquivo ou BPM para trocar a fonte.",
          });
        const accepted = e.beat({
          source: data.source || "file",
          interval: data.interval,
          strength: data.strength,
          pulseInterval: data.pulseInterval,
          at: data.at,
        });
        return json(res, 200, { accepted });
      }
      if (url.pathname === "/api/live/connect") {
        clearInterval(demoTimer);
        demoTimer = null;
        mode = "live";
        void adapter
          .connect(data.username)
          .catch((err) => log("live-error", { message: err.message }));
        return json(res, 202, { ok: true });
      }
      if (url.pathname === "/api/live/disconnect") {
        await adapter.disconnect();
        return json(res, 200, { ok: true });
      }
      if (url.pathname === "/api/live/event") {
        if (mode !== "live")
          return json(res, 409, {
            error: "Selecione modo LIVE antes de usar a ponte.",
          });
        lastBridgeAt = Date.now();
        const out = e.ingest(data);
        await store.save("live", e.save());
        return json(res, 200, out);
      }
      return json(res, 404, { error: "Rota não encontrada" });
    }
    if (req.method !== "GET")
      return json(res, 405, { error: "Método não aceito" });
    const relative = decodeURIComponent(
        url.pathname === "/" ? "/index.html" : url.pathname,
      ),
      file = path.resolve(ROOT, "public", "." + relative);
    if (!file.startsWith(path.join(ROOT, "public") + path.sep))
      return json(res, 403, { error: "Caminho recusado" });
    const bytes = await readFile(file);
    const ext = path.extname(file);
    res.writeHead(200, {
      "Content-Type":
        {
          ".html": "text/html; charset=utf-8",
          ".css": "text/css",
          ".js": "text/javascript",
          ".json": "application/json",
          ".md": "text/plain",
          ".svg": "image/svg+xml",
          ".wav": "audio/wav",
          ".mp3": "audio/mpeg",
          ".apk": "application/vnd.android.package-archive",
        }[ext] || "application/octet-stream",
      "Cache-Control": file.includes(path.sep + "vendor" + path.sep)
        ? "public, max-age=86400"
        : "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(bytes);
  } catch (err) {
    json(res, err.status || (err.code === "ENOENT" ? 404 : 400), {
      error: err.code === "ENOENT" ? "Arquivo não encontrado" : err.message,
    });
  }
});
const ticks = setInterval(() => {
    const e = engines[mode];
    if (mode === "demo" || liveReady()) e.tick();
    else e.freeze();
  }, 50),
  broadcast = setInterval(() => emit("state", snapshot()), 250),
  save = setInterval(() => {
    for (const name of ["demo", "live"])
      void store
        .save(name, engines[name].save())
        .catch((e) => log("save-error", { message: e.message }));
  }, 1000),
  health = setInterval(
    () =>
      log("health", {
        rss: process.memoryUsage().rss,
        uptime: process.uptime(),
        clients: clients.size,
        players: engines.live.players.size,
      }),
    60000,
  );
server.listen(PORT, HOST, () => {
  console.log(`JUJUTSU · COLÔNIA ZERO 0.1.0 · http://${HOST}:${PORT}`);
  void log("started", { pid: process.pid, port: PORT });
});
server.on("error", (e) => {
  console.error(e.message);
  process.exitCode = e.code === "EADDRINUSE" ? 78 : 1;
  void shutdown("server-error");
});
async function shutdown(signal) {
  if (closing) return;
  closing = true;
  rhythm.revoke();
  console.log("Encerrando e salvando:", signal);
  for (const t of [ticks, broadcast, save, health, demoTimer]) clearInterval(t);
  await adapter.disconnect();
  for (const [name, e] of Object.entries(engines))
    await store.save(name, e.save()).catch(() => {});
  await store.flush();
  for (const c of clients) c.end();
  server.closeAllConnections();
  server.close();
  await log("stopped", { signal });
}
process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("uncaughtException", (e) => {
  void log("uncaught", { message: e.stack });
  console.error(e);
  process.exit(1);
});
process.on("unhandledRejection", (e) => {
  void log("rejection", { message: String(e) });
  console.error(e);
  process.exit(1);
});
