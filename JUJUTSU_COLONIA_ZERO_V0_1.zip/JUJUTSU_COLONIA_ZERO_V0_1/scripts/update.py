"""Apply a verified Jujutsu Live package, keeping data and a reversible backup."""
from pathlib import Path
import hashlib, json, sys, subprocess, time, zipfile, shutil, shlex

source = Path(__file__).resolve().parent.parent
target = Path(sys.argv[1]).expanduser().resolve()
def package(folder):
    return json.loads((folder / 'package.json').read_text())
try:
    if source == target:
        raise ValueError('Para uma instalação nova, use bash install.sh e bash start.sh.')
    if package(target).get('name') != 'jujutsu-live':
        raise ValueError('A pasta indicada não é uma instalação Jujutsu Live.')
    new_version=package(source)['version']
    files=[]
    for line in (source/'MANIFEST.sha256').read_text().splitlines():
        digest, name=line.split('  ',1); rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Caminho inválido no manifesto.')
        p=source/rel
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
            raise ValueError('Arquivo alterado ou incompleto: '+name)
        files.append(rel)
    subprocess.run(['bash',str(target/'stop.sh')],check=True,cwd=target)
    for _ in range(100):
        live=subprocess.run(['node',str(target/'scripts/instance.mjs')],cwd=target,capture_output=True).returncode==0
        if not live:break
        time.sleep(.1)
    else:raise ValueError('O supervisor anterior não terminou. Código ainda não foi alterado.')
    backups=target/'backups';backups.mkdir(exist_ok=True)
    backup=backups/('antes-'+new_version+'-'+time.strftime('%Y%m%d-%H%M%S')+'.zip')
    excluded={'node_modules','backups','output','.git','sdk','private','build','__pycache__'}
    with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
        for p in target.rglob('*'):
            rel=p.relative_to(target)
            if p.is_file() and not p.is_symlink() and not (set(rel.parts)&excluded):z.write(p,rel.as_posix())
    with zipfile.ZipFile(backup) as z:
        if z.testzip():raise ValueError('Backup falhou na verificação de integridade.')
    for rel in files+[Path('MANIFEST.sha256')]:
        p=target/rel
        if not p.resolve().is_relative_to(target):raise ValueError('Destino fora da instalação: '+str(rel))
        p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/rel,p)
    subprocess.run(['bash',str(target/'install.sh')],check=True,cwd=target)
    print('Atualizado para '+new_version+'. Dados e logs preservados.')
    print('Backup completo da instalação anterior: '+str(backup))
    print('Para iniciar: cd '+shlex.quote(str(target))+' && bash start.sh')
except Exception as e:
    print('Atualização interrompida: '+str(e),file=sys.stderr)
    sys.exit(1)
