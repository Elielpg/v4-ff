"""Original procedural loop, no sampled recording. Python standard library only."""
import math,random,wave,array
from pathlib import Path
sr=24000;duration=32;n=sr*duration;mix=[0.0]*n;rng=random.Random(317)
def add(start,length,fn):
 off=int(start*sr)
 for j in range(min(int(length*sr),n-off)):
  mix[off+j]+=fn(j/sr,j)
for beat in range(64):
 start=beat*.5
 add(start,.3,lambda t,j:.46*math.sin(2*math.pi*(48*t+1.6*(1-math.exp(-t*36))))*math.exp(-t*17))
 if beat%2:
  add(start,.14,lambda t,j:rng.uniform(-1,1)*.17*math.exp(-t*29))
 semitones=[0,0,-3,-3,-5,-5,-7,-7][(beat//4)%8];f=55*2**(semitones/12)
 add(start,.43,lambda t,j,f=f:.19*math.tanh(2.6*math.sin(2*math.pi*f*t))*math.exp(-t*5))
for step in range(256):
 start=step*.125
 add(start,.035,lambda t,j:.055*rng.uniform(-1,1)*math.exp(-t*110))
 if step%2==0 or step%16 in [11,15]:
  f=622.25*2**([0,-3,0,7,0,-5,-3,-7][(step//2)%8]/12)
  add(start,.14,lambda t,j,f=f:.09*(math.sin(2*math.pi*f*t)+.5*math.sin(2*math.pi*f*1.483*t))*math.exp(-t*24))
pcm=array.array('h',(int(max(-1,min(1,math.tanh(v)*.8))*32767) for v in mix))
dest=Path(__file__).resolve().parent.parent/'public/assets/colony_pulse.wav'
with wave.open(str(dest),'wb') as w:w.setparams((1,2,sr,n,'NONE','not compressed'));w.writeframes(pcm.tobytes())
print(dest.name,round(len(pcm)/sr,2),'seconds; original synth composition')
