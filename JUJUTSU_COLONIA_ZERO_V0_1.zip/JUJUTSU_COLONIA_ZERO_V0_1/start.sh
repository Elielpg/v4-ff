#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
if node scripts/instance.mjs; then printf "Esta instalação já está aberta. Use http://127.0.0.1:${PORT:-3200}\n"; exit 0; fi
if command -v termux-wake-lock >/dev/null 2>&1; then termux-wake-lock; fi
trap 'if command -v termux-wake-unlock >/dev/null 2>&1; then termux-wake-unlock; fi' EXIT
node scripts/supervisor.mjs
