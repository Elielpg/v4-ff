import { CHARACTERS, TECHNIQUES } from "./catalog.js";
import { toonMaterial } from "./toon.js";
import { CursedFX } from "./fx.js";
import { clamp,smooth,strike,combatPose,approach } from "./motion.js";
const B=BABYLON,V=B.Vector3,C=B.Color3;
export class ColonyWorld {
 constructor(canvas){
  this.engine=new B.Engine(canvas,true,{adaptToDeviceRatio:false});this.scene=new B.Scene(this.engine);
  this.scene.clearColor=new B.Color4(.025,.035,.075,1);this.scene.fogMode=B.Scene.FOGMODE_EXP2;this.scene.fogDensity=.013;this.scene.fogColor=new C(.04,.07,.14);
  this.camera=new B.FreeCamera("Anime camera",new V(14,9,17),this.scene);this.camera.inputs.clear();this.camera.minZ=.1;this.camera.maxZ=180;this.camera.fov=.77;this.camera.setTarget(new V(0,1,0));
  const ambient=new B.HemisphericLight("moon",new V(0,1,0),this.scene);ambient.intensity=.85;ambient.groundColor=new C(.13,.14,.25);
  const key=new B.DirectionalLight("moonlight",new V(-.4,-1,-.3),this.scene);key.intensity=1;key.position=new V(8,16,8);
  this.shadow=new B.ShadowGenerator(512,key);this.shadow.useBlurExponentialShadowMap=true;this.shadow.blurKernel=8;this.shadow.bias=.003;
  this.glow=new B.GlowLayer("cursed glow",this.scene,{mainTextureFixedSize:256});this.glow.intensity=.38;
  this.toonMaterials=new Set();this.materials=new Map();this.actors=new Map();this.tracks=new Map();this.reactions=new Map();this.poses=new Map();this.bubbles=new Map();
  this.time=0;this.angle=.65;this.beatAt=-10;this.pulseStrength=0;this.pulse=0;this.state=null;this.latest=null;this.lastAction=0;this.reduceMotion=false;this.cinematic=true;this.profile="balanced";this.focus=null;this.focusUntil=0;
  this.buildCity();this.buildDomain();this.buildKogane();this.fx=new CursedFX(this);this.setQuality("balanced");
  window.addEventListener("resize",()=>this.engine.resize());this.engine.runRenderLoop(()=>this.render());
 }
 mat(name,hex,emit=0,alpha=1){if(this.materials.has(name))return this.materials.get(name);const m=new B.StandardMaterial(name,this.scene);m.diffuseColor=C.FromHexString(hex);m.emissiveColor=m.diffuseColor.scale(emit);m.specularColor=new C(.05,.05,.08);m.alpha=alpha;this.materials.set(name,m);return m;}
 toon(name,color){const key="toon-"+name;if(!this.materials.has(key))this.materials.set(key,toonMaterial(this,key,color));const m=this.materials.get(key);return m.fallbackMaterial||m;}
 box(name,size,mat,parent,pos=[0,0,0]){const m=B.MeshBuilder.CreateBox(name,{width:size[0],height:size[1],depth:size[2]},this.scene);m.material=mat;m.parent=parent||null;m.position.set(...pos);return m;}
 ball(name,size,mat,parent,pos=[0,0,0],scale=[1,1,1],segments=12){const m=B.MeshBuilder.CreateSphere(name,{diameter:size,segments},this.scene);m.material=mat;m.parent=parent||null;m.position.set(...pos);m.scaling.set(...scale);return m;}
 cylinder(name,d,h,mat,parent,pos=[0,0,0]){const m=B.MeshBuilder.CreateCylinder(name,{diameter:d,height:h,tessellation:10},this.scene);m.material=mat;m.parent=parent||null;m.position.set(...pos);return m;}
 link(mesh,a,b){const d=b.subtract(a),n=d.length(),dir=d.scale(1/Math.max(n,.001)),axis=V.Cross(B.Axis.Y,dir),dot=clamp(V.Dot(B.Axis.Y,dir),-1,1);mesh.position.copyFrom(V.Lerp(a,b,.5));mesh.scaling.y=n;mesh.rotationQuaternion=axis.lengthSquared()<1e-8?B.Quaternion.RotationAxis(B.Axis.X,dot<0?Math.PI:0):B.Quaternion.RotationAxis(axis.normalize(),Math.acos(dot));}
 texture(name,w,h,draw){const tx=new B.DynamicTexture(name,{width:w,height:h},this.scene,false);draw(tx.getContext());tx.update();return tx;}
 buildCity(){
  const asphalt=this.mat("asphalt","#111e30"),concrete=this.mat("pavement","#354257"),dark=this.mat("dark","#11182b"),neon=this.mat("cyan","#60d9ff",1),red=this.mat("red","#ff4268",1),gold=this.mat("gold","#f8d395",.7);
  this.neons=[neon,red,gold];this.buildings=[];
  const ground=this.box("Tokyo ground",[130,.2,130],dark,null,[0,-.2,0]);ground.receiveShadows=true;
  this.box("avenue",[23,.12,115],asphalt,null,[0,-.03,0]);this.box("cross street",[115,.12,23],asphalt,null,[0,-.02,0]);
  const road=this.texture("city road",1024,1024,c=>{c.fillStyle="#15243a";c.fillRect(0,0,1024,1024);c.strokeStyle="#29405d";c.lineWidth=2;for(let i=0;i<1024;i+=64){c.beginPath();c.moveTo(0,i);c.lineTo(1024,i);c.moveTo(i,0);c.lineTo(i,1024);c.stroke();}c.strokeStyle="#607b9c66";c.lineWidth=14;c.beginPath();c.arc(512,512,410,0,Math.PI*2);c.stroke();c.font="900 80px sans-serif";c.textAlign="center";c.fillStyle="#87a2b766";c.fillText("COLONY 01",512,540);});
  const rm=new B.StandardMaterial("intersection material",this.scene);rm.diffuseTexture=road;rm.specularColor=C.Black();const center=B.MeshBuilder.CreateGround("intersection",{width:22,height:22},this.scene);center.material=rm;center.position.y=.055;center.receiveShadows=true;
  for(let side of [-1,1])for(let i=-4;i<=4;i++){this.box("crosswalk",[1.1,.025,3.8],concrete,null,[i*1.7,.07,side*13.3]);this.box("crosswalk",[3.8,.025,1.1],concrete,null,[side*13.3,.07,i*1.7]);}
  for(let s of [-1,1])for(let axis of [0,1]){this.box("sidewalk",axis?[125,.32,3]:[3,.32,125],concrete,null,axis?[0,.03,s*15.3]:[s*15.3,.03,0]);}
  const win=this.texture("windows",128,256,c=>{c.fillStyle="#131d31";c.fillRect(0,0,128,256);for(let x=8;x<128;x+=24)for(let y=9;y<256;y+=22){c.fillStyle=(x+y)%5===0?"#28415d":(x+y)%3===0?"#d5aa72":"#81b5cb";c.fillRect(x,y,12,12);}});win.uScale=2;win.vScale=2;
  const buildingMat=new B.StandardMaterial("lit towers",this.scene);buildingMat.diffuseTexture=win;buildingMat.emissiveTexture=win;buildingMat.emissiveColor=new C(.28,.32,.4);buildingMat.specularColor=C.Black();
  let seed=7;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  for(let x=-3;x<=3;x++)for(let z=-3;z<=3;z++){if(x===0||z===0)continue;const h=9+random()*29,w=6+random()*3;
   const bx=x*21+(random()-.5)*3,bz=z*21+(random()-.5)*3;
   const b=this.box("tower",[w,h,w],buildingMat,null,[bx,h/2,bz]);this.buildings.push(b);
   this.box("roof",[w+.35,.35,w+.35],concrete,null,[bx,h,bz]);
   if(Math.abs(x)+Math.abs(z)<4){const strip=this.box("building light",[.08,h*.8,.08],random()<.5?neon:red,null,[bx-w/2-.05,h*.5,bz+w/2]);this.glow.addIncludedOnlyMesh(strip);}
  }
  for(let i=0;i<8;i++){const a=i/8*Math.PI*2,x=Math.sin(a)*17,z=Math.cos(a)*17;this.cylinder("lamp",.12,5,gold,null,[x,2.5,z]);const q=this.ball("lamp light",.35,gold,null,[x,5,z],[1.5,.5,1]);this.glow.addIncludedOnlyMesh(q);}
  for(const [txt,x,z,y,col]of[["COLONY / 01",-18,-19,8,"#63deff"],["SHIBUYA",20,-20,12,"#ff637c"],["CURSED ENERGY",-20,19,14,"#c399ff"],["GOJO / KENJAKU",20,19,7,"#92b9ff"]]){
   const tx=this.texture(txt,512,192,c=>{c.fillStyle="#10182e";c.fillRect(0,0,512,192);c.strokeStyle=col;c.lineWidth=8;c.strokeRect(4,4,504,184);c.fillStyle=col;c.textAlign="center";c.font="900 44px sans-serif";c.fillText(txt,256,109);});
   const m=new B.StandardMaterial(txt,this.scene);m.diffuseTexture=m.emissiveTexture=tx;m.disableLighting=true;
   const sign=B.MeshBuilder.CreatePlane("billboard",{width:7,height:2.65},this.scene);sign.position.set(x,y,z);sign.material=m;sign.billboardMode=B.Mesh.BILLBOARDMODE_Y;this.glow.addIncludedOnlyMesh(sign);
  }
  const barrier=B.MeshBuilder.CreateSphere("colony barrier",{diameter:104,segments:24,sideOrientation:B.Mesh.BACKSIDE},this.scene);const bm=this.mat("barrier","#718cdd",.1,.027);bm.wireframe=true;barrier.material=bm;
  this.landmarks=[];for(let i=0;i<4;i++){const a=i*Math.PI/2,q=this.box("cursed marker",[.07,.025,4],i%2?red:neon,null,[Math.sin(a)*9,.08,Math.cos(a)*9]);q.rotation.y=a;this.glow.addIncludedOnlyMesh(q);this.landmarks.push(q);}
  this.warningRing=B.MeshBuilder.CreateTorus("hazard warning",{diameter:1,thickness:.025,tessellation:64},this.scene);this.warningRing.material=red;this.warningRing.position.y=.12;this.warningRing.setEnabled(false);this.glow.addIncludedOnlyMesh(this.warningRing);
 }
 buildDomain(){
  this.domainRoot=new B.TransformNode("domain",this.scene);this.domainRoot.setEnabled(false);
  this.dome=B.MeshBuilder.CreateSphere("domain sphere",{diameter:23,segments:24,sideOrientation:B.Mesh.DOUBLESIDE},this.scene);this.dome.parent=this.domainRoot;this.dome.material=this.mat("domain skin","#8775ff",.5,.065);this.dome.material.backFaceCulling=false;
  this.domainRing=B.MeshBuilder.CreateTorus("domain boundary",{diameter:21,thickness:.08,tessellation:64},this.scene);this.domainRing.parent=this.domainRoot;this.domainRing.position.y=.15;this.domainRing.material=this.mat("domain edge","#b297ff",1);this.glow.addIncludedOnlyMesh(this.domainRing);
  this.temple=new B.TransformNode("malevolent shrine",this.scene);this.temple.parent=this.domainRoot;
  const red=this.mat("shrine red","#ad203c",.2),bone=this.mat("shrine bone","#e6c5a8",.1),black=this.mat("shrine black","#221728");
  for(const s of [-1,1]){this.cylinder("shrine pillar",.45,5.5,red,this.temple,[s*2.9,2.7,-4]);this.box("shrine foot",[1,.3,1],bone,this.temple,[s*2.9,.15,-4]);}
  this.box("shrine lintel",[7,.35,.65],red,this.temple,[0,5.2,-4]);const roof=this.box("shrine roof",[7.6,.35,1.5],black,this.temple,[0,5.7,-4]);roof.rotation.z=.02;
  this.box("altar",[3,1.8,2],bone,this.temple,[0,.9,-5]);this.box("altar shadow",[2.2,1.3,.05],black,this.temple,[0,.95,-3.98]);
  this.stars=[];for(let i=0;i<28;i++){const a=i*2.4,r=4+(i%7);const q=this.ball("domain star",.07,this.mat("star white","#c3e7ff",1),this.domainRoot,[Math.sin(a)*r,1+(i%9),Math.cos(a)*r]);this.glow.addIncludedOnlyMesh(q);this.stars.push(q);}
  this.voidShell=B.MeshBuilder.CreateSphere("infinite void space",{diameter:29,segments:24,sideOrientation:B.Mesh.BACKSIDE},this.scene);this.voidShell.parent=this.domainRoot;this.voidShell.material=this.mat("space black","#02040d",0);this.voidShell.material.disableLighting=true;
  this.infinity=[];for(let i=0;i<12;i++){const ring=B.MeshBuilder.CreateTorus("infinity filament",{diameter:3+i*1.45,thickness:.016,tessellation:48},this.scene);ring.parent=this.domainRoot;ring.position.set(0,3,-2);ring.rotation.x=Math.PI/2+i*.035;ring.material=this.mat("infinity cyan","#81dfff",1);this.glow.addIncludedOnlyMesh(ring);this.infinity.push(ring);}
 }
 buildKogane(){this.kogane=new B.TransformNode("Kogane",this.scene);const gold=this.mat("Kogane gold","#f8d089",.8);this.ball("Kogane",.34,gold,this.kogane);for(let s of [-1,1]){const wing=this.ball("wing",.4,gold,this.kogane,[s*.25,.04,0],[1,.22,.55]);wing.rotation.z=s*.4;}this.glow.addIncludedOnlyMesh(this.kogane.getChildMeshes()[0]);}
 face(type){const key="face-"+type;if(this.materials.has(key))return this.materials.get(key);
  const tx=this.texture(key,256,128,c=>{c.clearRect(0,0,256,128);
   if(type==="gojo"){c.fillStyle="#101628";c.beginPath();c.roundRect(4,22,248,54,12);c.fill();c.fillStyle="#64809e";c.fillRect(16,28,220,3);}
   else if(type==="jogo"){c.fillStyle="#f5e8d7";c.strokeStyle="#3c3830";c.lineWidth=7;c.beginPath();c.ellipse(128,59,58,33,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle="#3f2e24";c.beginPath();c.ellipse(128,60,16,26,0,0,Math.PI*2);c.fill();}
   else for(const s of [-1,1]){const x=128+s*63;c.beginPath();c.moveTo(x-40,47);c.lineTo(x+36,40);c.quadraticCurveTo(x+26,83,x-31,75);c.closePath();c.fillStyle="#f6eff0";c.fill();c.strokeStyle="#161d2c";c.lineWidth=6;c.stroke();c.fillStyle=type==="sukuna"?"#c82746":type==="mahito"?"#67d8cd":"#448cae";c.beginPath();c.ellipse(x+2,61,10,16,0,0,Math.PI*2);c.fill();c.strokeStyle="#1a1a2a";c.lineWidth=8;c.beginPath();c.moveTo(x-38,29);c.lineTo(x+35,37);c.stroke();}
   c.strokeStyle="#5d3034";c.lineWidth=4;c.beginPath();c.moveTo(111,105);c.quadraticCurveTo(128,113,148,101);c.stroke();
   if(type==="sukuna"){c.strokeStyle="#251e2b";c.lineWidth=5;for(const s of [-1,1]){c.beginPath();c.moveTo(128+s*35,80);c.lineTo(128+s*54,98);c.lineTo(128+s*89,91);c.stroke();c.beginPath();c.moveTo(128+s*7,5);c.lineTo(128+s*19,33);c.stroke();}c.beginPath();c.moveTo(122,75);c.lineTo(128,89);c.lineTo(135,75);c.stroke();}
   if(type==="kenjaku"||type==="mahito"){c.strokeStyle="#4e414a";c.lineWidth=3;const y=type==="kenjaku"?14:93;c.beginPath();c.moveTo(20,y);c.lineTo(238,y);c.stroke();for(let x=35;x<235;x+=23){c.beginPath();c.moveTo(x,y-6);c.lineTo(x+4,y+6);c.stroke();}}
  });tx.hasAlpha=true;const m=new B.StandardMaterial(key,this.scene);m.diffuseTexture=m.emissiveTexture=tx;m.disableLighting=true;m.useAlphaFromDiffuseTexture=true;m.backFaceCulling=false;this.materials.set(key,m);return m;
 }
 fighter(p){const type=p.character||"citizen",c=CHARACTERS[type],root=new B.TransformNode(p.id,this.scene),head=new B.TransformNode("head",this.scene);head.parent=root;head.position.y=1.67;
  head.scaling.setAll(type==="citizen"?.84:.76);
  const skin=this.toon(type+" skin",type==="mahito"?"#d6ddd9":type==="jogo"?"#a59e85":"#eec4ae"),suit=this.toon(type+" suit",c.suit),hair=this.toon(type+" hair",c.hair),shoe=this.toon("shoes","#121b2b"),accent=this.toon(type+" accent",c.color);
  const body=this.ball("jacket",.68,suit,root,[0,1.1,0],[.9,1.25,.56],16);
  this.ball("head",.62,skin,head,[0,0,0],[.92,1.12,.92],20);
  const face=B.MeshBuilder.CreatePlane("face",{width:.48,height:.25},this.scene);face.parent=head;face.position.set(0,-.015,.289);face.rotation.y=Math.PI;face.material=this.face(type);
  const cap=this.ball("hair",.64,hair,head,[0,.14,-.04],[.99,.85,.98],16);
  if(!["mahito","kenjaku","jogo"].includes(type))for(let i=0;i<9;i++){const a=i/9*Math.PI*2;const h=type==="megumi"?.36:.19;const tuft=B.MeshBuilder.CreateCylinder("hair tuft",{diameterTop:0,diameterBottom:.2,height:h,tessellation:4},this.scene);tuft.material=hair;tuft.parent=head;tuft.position.set(Math.sin(a)*.21,.35+Math.cos(a)*.025,Math.cos(a)*.18-.04);tuft.rotation.z=-Math.sin(a)*.55;tuft.rotation.x=Math.cos(a)*.5;}
  if(type==="mahito"||type==="kenjaku"){this.ball("long hair",.56,hair,head,[0,-.14,-.2],[1,1.4,.6]);if(type==="kenjaku")this.ball("hair knot",.28,hair,head,[0,.4,-.08]);}
  if(type==="jogo"){cap.scaling.set(.9,1,.9);const crater=B.MeshBuilder.CreateTorus("volcano crater",{diameter:.39,thickness:.1,tessellation:16},this.scene);crater.parent=head;crater.position.y=.46;crater.material=this.mat("lava","#ff823b",1);this.glow.addIncludedOnlyMesh(crater);}
  if(type==="yuji"){this.cylinder("red collar",.45,.21,this.toon("red hood","#b84455"),root,[0,1.47,0]);}
  if(type==="gojo"||type==="megumi")this.cylinder("high collar",.34,.22,suit,root,[0,1.48,0]);
  if(type==="sukuna"){this.box("open kimono",[.25,.48,.035],skin,root,[0,1.23,.21]);for(const s of [-1,1]){const mark=this.box("cursed marking",[.028,.23,.015],shoe,root,[s*.075,1.2,.237]);mark.rotation.z=s*.35;}}
  if(type==="kenjaku"){this.ball("robe",.58,suit,root,[0,.78,0],[1.1,1,.7]);this.box("gold stole",[.15,.65,.04],accent,root,[-.19,1.17,.23]);}
  if(type==="sukuna"||type==="kenjaku"){this.box("kimono belt",[.62,.12,.34],type==="sukuna"?accent:this.toon("belt","#c8a965"),root,[0,.88,.04]);for(const s of [-1,1]){const lapel=this.box("lapel",[.1,.58,.04],type==="sukuna"?shoe:accent,root,[s*.11,1.2,.2]);lapel.rotation.z=s*-.25;}}
  if(type==="yuta"){const blade=this.box("katana",[.045,1.18,.075],this.mat("steel","#b8e9ee",.15),root,[-.42,.79,-.18]);blade.rotation.z=-.18;}
  const arms=[-1,1].map(s=>({s,upper:this.cylinder("sleeve",.2,1,suit,root),lower:this.cylinder("arm",.14,1,type==="sukuna"?skin:suit,root),hand:this.ball("hand",.17,skin,root)}));
  if(type==="sukuna")for(const s of [-1,1]){const extra=this.cylinder("extra arm",.16,.6,skin,root,[s*.45,.94,-.05]);extra.rotation.z=s*1.1;this.ball("extra hand",.17,skin,root,[s*.7,.8,-.05]);}
  const legs=[-1,1].map(s=>({s,upper:this.cylinder("pants",.22,1,suit,root),lower:this.cylinder("shin",.17,1,suit,root),foot:this.ball("boot",.25,shoe,root,[0,0,0],[.8,.6,1.5])}));
  const labelTx=this.texture("name-"+p.id,512,128,c=>{});labelTx.hasAlpha=true;const lm=new B.StandardMaterial("label-"+p.id,this.scene);lm.diffuseTexture=lm.emissiveTexture=labelTx;lm.disableLighting=true;lm.useAlphaFromDiffuseTexture=true;lm.backFaceCulling=false;
  const label=B.MeshBuilder.CreatePlane("name",{width:1.3,height:.33},this.scene);label.parent=root;label.position.y=2.2;label.material=lm;label.billboardMode=B.Mesh.BILLBOARDMODE_ALL;
  for(const q of root.getChildMeshes()){if(!["name","face"].includes(q.name)){this.shadow.addShadowCaster(q,false);q.renderOutline=this.profile==="high"&&["head","jacket","boot"].includes(q.name);q.outlineColor=new C(.025,.035,.06);q.outlineWidth=.009;}}
  let key="";return {p,type,root,head,body,arms,legs,label,update(q){this.p=q;const k=q.id+q.status+Math.round(q.hp)+q.points+q.admitted+q.queued;if(k===key)return;key=k;const c=labelTx.getContext();c.clearRect(0,0,512,128);c.fillStyle="#0b13288f";c.beginPath();c.roundRect(2,3,508,120,20);c.fill();c.strokeStyle=q.team==="boss"?"#ff597b":q.team==="gojo"?"#78daff":q.team==="kenjaku"?"#d49cff":"#7e94ad";c.lineWidth=4;c.stroke();c.fillStyle="#f0f4ff";c.textAlign="center";c.font="bold 37px sans-serif";c.fillText(q.id==="sukuna"?"SUKUNA · NPC":"@"+q.id.slice(0,18),256,53);c.font="bold 27px sans-serif";c.fillStyle="#c0cedf";c.fillText(q.status==="fighter"?`${CHARACTERS[q.character].name} · ${Math.round(q.hp)} HP · ${q.points} pts`:q.id==="sukuna"?"REI DAS MALDIÇÕES":q.status==="dead"?"ELIMINADO · VOLTA EM BREVE":q.queued?"RESERVA · AGUARDE SUA VEZ":q.admitted?"VOLTE: COMENTE LUTAR":"CIDADÃO · SIGA PARA LUTAR",256,98);labelTx.update();},dispose:()=>{for(const q of root.getChildMeshes())this.shadow.removeShadowCaster(q,false);root.dispose();labelTx.dispose();lm.dispose();}};
 }
 setQuality(q){this.profile=q;this.engine.setHardwareScalingLevel(q==="high"?1:q==="low"?1.8:1.25);this.scene.shadowsEnabled=q!=="low";this.glow.isEnabled=q!=="low";this.citizenLimit=q==="low"?4:q==="high"?14:8;this.fighterLimit=q==="low"?8:12;if(this.fx)this.fx.limit=q==="low"?24:48;this.engine.resize();}
 update(s){this.state=s;const active=s.players.filter(p=>p.status==="fighter").sort((a,b)=>(b.id===this.focus?1:0)-(a.id===this.focus?1:0)||(b.chat?.until||0)-(a.chat?.until||0)).slice(0,this.fighterLimit),citizens=s.players.filter(p=>p.status!=="fighter").sort((a,b)=>b.lastSeen-a.lastSeen).slice(0,this.citizenLimit);
  const roster=[{...s.boss,status:s.boss.alive?"boss":"dead",points:0},...active,...citizens.map(p=>({...p,queued:s.queue.includes(p.id)}))];const wanted=new Set(roster.map(p=>p.id));
  for(const [id,a]of this.actors)if(!wanted.has(id)){a.dispose();this.actors.delete(id);this.tracks.delete(id);this.reactions.delete(id);}
  for(const p of roster){let a=this.actors.get(p.id);if(a&&a.type!==p.character){a.dispose();this.actors.delete(p.id);a=null;}if(!a){a=this.fighter(p);this.actors.set(p.id,a);}a.update(p);}
 }
 clear(){this.fx.clear();this.tracks.clear();this.reactions.clear();this.poses.clear();this.lastAction=0;this.latest=null;this.shot=null;this.focus=null;}
 action(a){if(a.id<=this.lastAction)return;this.lastAction=a.id;const t=performance.now()/1000;
  if(a.kind==="beat"){this.beatAt=t;this.pulseStrength=.3+.7*a.strength;this.pulse++;return;}
  if(a.kind==="attack"){this.tracks.set(a.player,{...a,time:t});this.latest={...a,time:t};this.focus=a.player;this.focusUntil=t+1.5;const x=this.actors.get(a.player),y=this.actors.get(a.target);if(x&&y&&(a.move==="teleport"||a.black))this.fx.trail(x.root.position,y.root.position,a.black?"#ff496e":CHARACTERS[a.character]?.color||"#a6caff");}
  if(a.kind==="damage"){this.reactions.set(a.target,{...a,time:t});const p=this.actors.get(a.target)?.root.position;if(p&&a.damage>0)this.fx.impact(p.add(new V(0,1,0)),a.move==="blackFlash"?"#ff4d77":"#b4dfff",a.damage>25?1.2:.5);this.shake=t;}
  if(a.kind==="technique"){const spec=TECHNIQUES[a.technique];this.fx.technique({...a,effectKind:spec.kind},this.actors);this.latest={...a,time:t};const priority=a.domain?3:spec.power>=28?2:1;if(!this.shot||this.shot.until<=t||priority>=this.shot.priority){this.shot={...a,priority,time:t,until:t+(a.domain?5:2.4)};this.focus=a.player;this.focusUntil=t+(a.domain?4:2);}this.shake=t;}
  if(a.kind==="entrance"||a.kind==="welcome"){this.focus=a.player;this.focusUntil=t+(a.kind==="entrance"?2.8:2);const p=this.actors.get(a.player)?.root.position;if(p)this.fx.impact(p,CHARACTERS[a.character]?.color||"#b4dfff",1);}
  if(a.kind==="pose")this.poses.set(a.player,{pose:a.pose,at:t});
  if(a.kind==="heal"){const p=this.actors.get(a.player)?.root.position;if(p)this.fx.emit("ring",p.add(new V(0,1,0)),null,{color:"#80ffce",scale:1,life:1});}
  if(a.kind==="likes"){const p=this.actors.get(a.player)?.root.position;if(p)this.fx.emit("orb",p.add(new V(.4,0,0)),p.add(new V(0,1.3,0)),{color:"#8dffe0",scale:.23,life:.65});}
  if(a.kind==="hazardImpact"){const spec=TECHNIQUES[a.technique];this.fx.emit("orb",new V(a.x,7,a.z),new V(a.x,.2,a.z),{color:spec.color,scale:a.radius*.6,life:1});this.fx.emit("ring",new V(a.x,.1,a.z),null,{color:spec.color,scale:a.radius*2,life:1.2});}
  if(a.kind==="rule")this.koganePulse=t;
 }
 animate(a,t,dt){const p=a.p,root=a.root,isBoss=p.id==="sukuna",scale=isBoss?1.55:p.status==="fighter"?1:.8;
  const target=new V(p.x||0,.1,p.z||0),track=this.tracks.get(p.id),age=track?(t-track.time)/track.duration:2,attacking=age>=0&&age<=1;
  const pose=combatPose(track?.move||"jab",age),other=attacking?this.actors.get(track.target):null;
  if(other){const approached=approach(target,other.root.position,age,track.move==="teleport");target.x=approached.x;target.z=approached.z;target.y+=pose.jump;}
  const walk=Math.sin(t*(p.status==="citizen"?4:7)+p.seed),idle=Math.sin(t*2+(p.seed||0));
  root.position.copyFrom(V.Lerp(root.position,target,Math.min(1,dt*(attacking?38:7))));root.scaling.setAll(scale);
  a.label.setEnabled(!isBoss&&!this.state?.domain);
  let yaw=other?Math.atan2(other.root.position.x-root.position.x,other.root.position.z-root.position.z):Math.atan2(-root.position.x,-root.position.z);
  if(isBoss&&!other)yaw=this.angle;
  if(!attacking&&!isBoss&&this.focus===p.id&&this.focusUntil>t)yaw=Math.atan2(this.camera.position.x-root.position.x,this.camera.position.z-root.position.z);
  root.rotation.y=yaw+(attacking?pose.spin+pose.twist:idle*.035);root.rotation.z=p.status==="dead"?1.5:0;
  const reaction=this.reactions.get(p.id),hurt=reaction?strike((t-reaction.time)/.32):0;root.rotation.x=hurt*(reaction?.defense==="dodge"?-.45:-.13);
  const command=this.poses.get(p.id),cmdAge=command?t-command.at:99,dancing=command?.pose==="dancar"&&cmdAge<10,phase=t*(this.state?.rhythm.bpm||110)/60*Math.PI*2;
  if(command?.pose==="pular"&&cmdAge<1)root.position.y+=Math.sin(cmdAge*Math.PI)*.8;
  a.head.rotation.z=dancing?Math.sin(phase)*.1:idle*.02;
  const guard=p.guardUntil>(this.state?.serverTime||0);
  for(const arm of a.arms){const s=arm.s,shoulder=new V(s*.3,1.35,0);let elbow=new V(s*.38,1.05,.17),hand=new V(s*.25,1.35,.37);
   if(p.status==="citizen"){elbow.set(s*.38,.98,walk*s*.04);hand.set(s*.36,.76,walk*s*.1);}
   if(attacking&&!pose.kick&&s===pose.side){elbow.set(s*.3,1.25,.25+pose.f*.3);hand.set(s*.12,track.combo===3?1.5:1.4,.4+pose.f*.95);}
   if(guard){elbow.set(s*.28,1.22,.28);hand.set(s*.18,1.65,.36);}
   if(dancing){elbow.set(s*.45,1.2+Math.sin(phase+s)*.22,0);hand.set(s*.58,1.5+Math.cos(phase+s)*.24,.2);}
   this.link(arm.upper,shoulder,elbow);this.link(arm.lower,elbow,hand);arm.hand.position.copyFrom(hand);
  }
  for(const leg of a.legs){const s=leg.s,hip=new V(s*.16,.85,0),swing=Math.sin((dancing?phase:t*5)+s*Math.PI/2);let knee=new V(s*.18,.49,.02+swing*.07),foot=new V(s*.2,.13,.04+swing*.13);
   if(attacking&&pose.kick&&s===1){knee.set(.17,.5+pose.f*.6,.2+pose.f*.5);foot.set(.2,.15+pose.f*1.1,.2+pose.f*1.25);}
   this.link(leg.upper,hip,knee);this.link(leg.lower,knee,foot);leg.foot.position.copyFrom(foot);
  }
 }
 render(){const t=performance.now()/1000,dt=Math.min(.12,t-(this.time||t));this.time=t;const impulse=Math.exp(-Math.max(0,t-this.beatAt)*18)*this.pulseStrength;
  for(const a of this.actors.values())this.animate(a,t,dt);
  const domain=this.state?.domain,isVoid=domain?.technique==="void";this.domainRoot.setEnabled(!!domain);this.voidShell.setEnabled(!!isVoid);this.infinity.forEach((q,i)=>{q.setEnabled(!!isVoid);q.rotation.z=t*.08+i*.13;});
  this.scene.fogColor=isVoid?new C(.005,.008,.025):domain?.technique==="shrine"?new C(.12,.025,.06):new C(.04,.07,.14);
  if(domain){const a=this.actors.get(domain.player);this.domainRoot.position.set(a?.root.position.x||0,0,a?.root.position.z||0);const col=C.FromHexString(TECHNIQUES[domain.technique]?.color||"#a19cff");this.dome.setEnabled(!isVoid);this.dome.material.diffuseColor=col;this.dome.material.emissiveColor=col.scale(.4);this.domainRing.material.emissiveColor=col;this.domainRing.rotation.y=t*.3;this.temple.setEnabled(domain.technique==="shrine");for(let i=0;i<this.stars.length;i++)this.stars[i].scaling.setAll(.4+Math.abs(Math.sin(t*2+i)));}
  const kp=this.actors.get(this.focus)?.root.position||new V(-4,0,-2);this.kogane.position.set(kp.x+1,3.4+Math.sin(t*2)*.15,kp.z);this.kogane.rotation.y=t;this.kogane.scaling.setAll(this.koganePulse&&t-this.koganePulse<2?1.6:1);
  for(const m of this.toonMaterials){m.setVector3("lightDirection",this.camera.position.normalizeToNew().add(new V(0,1,0)));m.setVector3("eyePosition",this.camera.position);m.setFloat("pulse",this.reduceMotion?0:impulse);}
  this.neons.forEach((m,i)=>m.emissiveColor=m.diffuseColor.scale(.6+(this.reduceMotion?.08:.8)*impulse*(i===this.pulse%3?1:.3)));
  this.fx.update(t,this.reduceMotion);
  const hazard=this.state?.hazard;this.warningRing.setEnabled(!!hazard);if(hazard){this.warningRing.position.set(hazard.x,.12,hazard.z);this.warningRing.scaling.set(hazard.radius*2,1,hazard.radius*2);this.warningRing.visibility=this.reduceMotion?.6:.45+Math.abs(Math.sin(t*7))*.45;}
  if(this.cinematic&&!this.reduceMotion)this.angle+=dt*.16;
  let target=new V(0,1.2,0),radius=19,height=9;
  const shot=this.shot?.until>t?this.shot:null;
  const latest=shot||this.latest,age=latest?t-latest.time:99,focus=this.actors.get(shot?.player||this.focus);
  if(this.cinematic&&!this.reduceMotion&&focus&&this.focusUntil>t){target=focus.root.position.add(new V(0,1,0));radius=latest?.kind==="technique"?12.5:14;height=latest?.kind==="technique"?5.4:6.3;const opponent=this.actors.get(latest?.target);if(opponent)target=V.Lerp(target,opponent.root.position.add(new V(0,1,0)),.45);}
  if(domain){target=this.domainRoot.position.add(new V(0,1.8,0));radius=isVoid?10.5:18;height=isVoid?4:7;}
  const aspect=this.engine.getAspectRatio(this.camera);radius=Math.max(radius,aspect<.6?17:12);
  let viewAngle=this.angle;
  if(shot&&!domain&&!this.reduceMotion){const a=this.actors.get(shot.player)?.root.position,b=this.actors.get(shot.target)?.root.position;if(a&&b){target=V.Lerp(a,b,.5).add(new V(0,1.1,0));const d=b.subtract(a),dist=Math.hypot(d.x,d.z)||1;viewAngle=Math.atan2(d.z/dist+d.x/dist*.4,-d.x/dist+d.z/dist*.4);height=4;radius=Math.max(12,(dist*.5+.9)/(Math.tan(.42)*aspect));}}
  if(isVoid){radius=10.5;viewAngle=this.angle+.4;}
  const cam=target.add(new V(Math.sin(viewAngle)*radius,height,Math.cos(viewAngle)*radius));this.camera.position.copyFrom(V.Lerp(this.camera.position,cam,Math.min(1,dt*5)));this.camera.setTarget(target);this.camera.rotation.z=this.reduceMotion?0:Math.sin(age*18)*Math.exp(-Math.max(0,age)*8)*.025;
  this.camera.fov=.77-(this.reduceMotion?0:impulse*.009);if(this.shake&&t-this.shake<.2&&!this.reduceMotion)this.camera.position.y+=Math.sin(t*100)*.045;
  for(const b of this.buildings){b.computeWorldMatrix(true);const bounds=b.getBoundingInfo().boundingBox,from=this.camera.position,d=target.subtract(from),distance=d.length(),ray=new B.Ray(from,d.normalize(),distance);const hit=ray.intersectsBoxMinMax(bounds.minimumWorld,bounds.maximumWorld);b.visibility=hit?.07:1;}
  this.scene.render();this.renderBubbles();
 }
 renderBubbles(){const layer=document.getElementById("bubbles"),s=this.state;if(!layer||!s)return;const visible=new Set();
  for(const a of this.actors.values()){const chat=a.p.chat;if(!chat||chat.until<s.serverTime||visible.size>=5)continue;visible.add(a.p.id);let el=this.bubbles.get(a.p.id);if(!el){el=document.createElement("div");el.className="chat-bubble";layer.append(el);this.bubbles.set(a.p.id,el);}el.textContent=chat.text;const v=V.Project(a.root.position.add(new V(0,2.8,0)),B.Matrix.Identity(),this.scene.getTransformMatrix(),this.camera.viewport.toGlobal(this.engine.getRenderWidth(),this.engine.getRenderHeight()));const x=v.x/this.engine.getRenderWidth()*innerWidth,y=v.y/this.engine.getRenderHeight()*innerHeight;el.style.left=clamp(x,75,innerWidth-75)+"px";el.style.top=clamp(y,220,innerHeight-220)+"px";el.style.visibility=v.z>0&&v.z<1&&x>0&&x<innerWidth?"visible":"hidden";}
  for(const [id,el]of this.bubbles)if(!visible.has(id)){el.remove();this.bubbles.delete(id);}
 }
 metrics(){return {fps:Math.round(this.engine.getFps()),actors:this.actors.size,meshes:this.scene.meshes.length,effects:this.fx.active,profile:this.profile,toonMaterials:this.toonMaterials.size};}
}
