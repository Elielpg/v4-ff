import { ColonyWorld } from "./world.js";
import { ColonyAudio } from "./sound.js";
import { CHARACTERS,TECHNIQUES,GIFT_GUIDE,RULE_OPTIONS } from "./catalog.js";
const $=id=>document.getElementById(id),world=new ColonyWorld($("city"));
let state=null,cursor=0,lastMode=null,toaster,titleTimer,manual=false,slide=0,titlePriority=0,titleUntil=0;
const api=async(path,data={})=>{const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),j=await r.json();if(!r.ok)throw Error(j.error||"Comando recusado");return j;};
function toast(text){$("toast").textContent=text;clearTimeout(toaster);toaster=setTimeout(()=>$("toast").textContent="",4500);}
const audio=new ColonyAudio($("music"),{onBeat:pulse=>{if(!manual&&state?.rhythm.source!=="external")api("beat",{source:"file",...pulse}).catch(()=>{});},onLevel:x=>$("beat-meter").firstElementChild.style.width=Math.min(100,x*100)+"%",onStatus:toast});
function setMode(mode){if(mode===lastMode)return;lastMode=mode;cursor=0;world.clear();audio.stopVoice();}
function title(owner,name,sub,color,duration=1500,priority=2){if(performance.now()<titleUntil&&priority<titlePriority)return;titlePriority=priority;titleUntil=performance.now()+duration;$("technique-owner").textContent=owner;$("technique-name").textContent=name;$("technique-name").style.color=color||"#e6daff";$("technique-sub").textContent=sub||"";$("technique-title").classList.remove("hidden");clearTimeout(titleTimer);titleTimer=setTimeout(()=>$("technique-title").classList.add("hidden"),duration);}
function action(a){if(a.mode)setMode(a.mode);if(a.id<=cursor)return;cursor=a.id;world.action(a);
 const p=state?.players.find(p=>p.id===a.player),character=CHARACTERS[a.character||p?.character];
 if(a.kind==="entrance"){title('@'+a.player,character?.name.toUpperCase()||"FEITICEIRO",a.team==="gojo"?"TIME GOJO":"TIME KENJAKU",character?.color,1900);audio.sfx("entrance");audio.voice(a.character,2);}
 if(a.kind==="welcome"){audio.sfx("welcome");audio.voice("welcome");}
 if(a.kind==="follow")audio.sfx("follow");
 if(a.kind==="attack")audio.sfx(a.move==="airKick"?"kick":a.move==="teleport"?"teleport":"attack");
 if(a.kind==="damage"&&a.defense!=="none")audio.sfx(a.defense==="block"?"block":"dodge");
 if(a.kind==="technique"){const s=TECHNIQUES[a.technique];title('@'+a.player,s.name,s.domain?"DOMAIN EXPANSION":"CURSED TECHNIQUE",s.color,s.domain?2400:1300,s.domain?3:s.power>=28?2:1);audio.sfx(s.domain?"domain":"technique");audio.voice(s.voice,s.domain?3:1);}
 if(a.kind==="hazard"){const s=TECHNIQUES[a.technique];audio.voice(s.voice,a.technique==="shrine"?3:2);if(a.technique==="shrine")title("RYOMEN SUKUNA",s.name,"DOMAIN EXPANSION",s.color,3000,3);}
 if(a.kind==="heal"){audio.sfx("block");audio.voice("reverse");}
 if(a.kind==="rule"){title("KOGANE · REGRA ACEITA",a.label,'@'+a.player,"#f3d7a4",2300);audio.sfx("rule");audio.voice("rule",3);}
 if(a.kind==="bossDefeated"){title("COLÔNIA ZERO","SUKUNA CAIU","PRÓXIMA ONDA EM 8 SEGUNDOS","#b8e9ff",2800);audio.sfx("victory");audio.voice("victory",3);}
}
let selectedKey="";
function selected(){const user=$("test-user").value.replace(/^@/,"").trim().toLowerCase(),p=state?.players.find(p=>p.id===user);
 $("selected-player").textContent=p?`@${p.id} · ${CHARACTERS[p.character].name} · ${p.status==="fighter"?"EM BATALHA":p.status==="dead"?"ELIMINADO":"CIDADÃO"}\n${Math.round(p.hp)} HP · ${Math.floor(p.energy)} energia · ${p.points} pontos disponíveis`:'Novo usuário: entre na cidade ou siga para lutar.';
 const key=p?.id+":"+p?.character+":"+p?.status+":"+(state?.mode||"");if(key!==selectedKey){selectedKey=key;$("technique-buttons").replaceChildren();if(p?.status==="fighter")CHARACTERS[p.character].techniques.forEach((id,i)=>{const b=document.createElement("button");b.textContent=TECHNIQUES[id].name;b.disabled=state.mode!=="demo";b.onclick=()=>comment(i===3?"DOMINIO":"TECNICA "+(i+1));$("technique-buttons").append(b);});}
}
function renderState(s){setMode(s.mode);state=s;world.update(s);$("network").textContent="CONECTADO";$("mode").textContent=s.mode==="demo"?"DEMONSTRAÇÃO LOCAL":s.connection?.status==="connected"?"LIVE · CONECTADA":"LIVE · SEM CONEXÃO";$("live-detail").textContent=s.connection?.message||"LIVE não conectada";
 $("rhythm").textContent=s.rhythm.bpm+" BPM · "+({manual:"MANUAL",file:"ARQUIVO",external:"ANDROID",paused:"PAUSADO"}[s.rhythm.source]||"ESTIMADO");$("boss-hp").textContent=Math.round(s.boss.hp)+" / "+s.boss.maxHp;$("boss-fill").style.width=100*s.boss.hp/s.boss.maxHp+"%";$("wave").textContent="COLÔNIA · ONDA "+String(s.round).padStart(2,"0");$("gojo-count").textContent=s.teams.gojo;$("kenjaku-count").textContent=s.teams.kenjaku;$("citizen-count").textContent=s.teams.citizens+" CIDADÃOS";
 const hints=["SIGA PARA LUTAR · ROSA TAMBÉM LIBERA A ENTRADA","TAP TAP = ENERGIA + CURA GRADUAL","COMENTE PODER · TÉCNICA 2 · DOMINIO","100 PONTOS = UMA REGRA PARA A COLÔNIA","JÁ LUTOU? APÓS O RETORNO, COMENTE LUTAR"];
 $("hint").textContent=hints[Math.floor(s.serverTime/8000)%hints.length];$("notice").textContent=s.notice?.text||`${s.totalPlayers} na cidade · ${s.totals.likes} TAP TAP · ${s.queue.length} na reserva`;
 $("hazard").classList.toggle("hidden",!s.hazard);if(s.hazard)$("hazard").textContent=`${TECHNIQUES[s.hazard.technique].name} · IMPACTO EM ${Math.max(0,Math.ceil((s.hazard.resolveAt-s.serverTime)/1000))}s`;
 $("demo-start").classList.toggle("hidden",s.mode!=="demo");$("ranking").replaceChildren(...s.ranking.slice(0,5).map(p=>{const li=document.createElement("li");li.textContent='@'+p.id+' · '+p.earned+' pts';return li;}));
 const focus=s.players.find(p=>p.id===(world.shot?.until>performance.now()/1000?world.shot.player:world.focus));$("voice-caption").textContent=focus?`@${focus.id} · ${CHARACTERS[focus.character].name} · ${Math.floor(focus.energy)} ENERGIA · ${focus.points}/100 PTS`:s.domain?TECHNIQUES[s.domain.technique].name:"";
 document.querySelectorAll('[data-event],[data-gift],[data-chat],#demo-points,#demo-boss,#chat-send').forEach(b=>b.disabled=s.mode!=="demo");selected();
 $("native-status").textContent={listening:"Captador conectado · sinal recebido",silent:"Sem sinal dessa saída. Teste arquivo local.",waiting:"Aguardando captador…",offline:"Captador não conectado.",pairing:"Digite o código no APK."}[s.audio?.state]||"Captador não conectado.";
}
const es=new EventSource('/api/events');es.addEventListener('state',e=>renderState(JSON.parse(e.data)));es.addEventListener('action',e=>action(JSON.parse(e.data)));es.onerror=()=>$("network").textContent="RECONECTANDO";
$("menu").onclick=()=>$("drawer").classList.remove("hidden");$("close").onclick=()=>$("drawer").classList.add("hidden");
$("sound").onclick=()=>audio.unlock().then(()=>toast("Áudio liberado · falas inglesas e efeitos ativados.")).catch(e=>toast(e.message));
$("demo-start").onclick=async()=>{try{await audio.unlock();await api("demo/start");toast("Demonstração com participantes fictícios. Somente eventos locais.");}catch(e){toast(e.message);}};
$("demo-stop").onclick=()=>api("demo/stop").then(()=>toast("Eventos automáticos pausados. A colônia continua ativa.")).catch(e=>toast(e.message));
$("connect").onclick=()=>{audio.unlock();api("live/connect",{username:$("username").value}).catch(e=>toast(e.message));};$("disconnect").onclick=()=>api("live/disconnect").catch(e=>toast(e.message));
const user=()=>$("test-user").value.replace(/^@/,"").trim();
async function event(data){try{await audio.unlock();const out=await api("demo/event",{user:user(),name:user(),id:crypto.randomUUID(),...data});if(!out.accepted)toast(out.reason);}catch(e){toast(e.message);}}
function comment(text){return event({type:"comment",text});}
document.querySelectorAll('[data-event]').forEach(b=>b.onclick=()=>event({type:b.dataset.event,count:b.dataset.event==="like"?50:1}));document.querySelectorAll('[data-gift]').forEach(b=>b.onclick=()=>event({type:"gift",gift:b.dataset.gift,count:1,repeatEnd:true}));document.querySelectorAll('[data-chat]').forEach(b=>b.onclick=()=>comment(b.dataset.chat));
$("chat-send").onclick=()=>comment($("chat-text").value);$("test-user").oninput=selected;
$("demo-points").onclick=()=>api("demo/points",{user:user()}).then(()=>toast("DEMO: 100 pontos adicionados para testar Kogane.")).catch(e=>toast(e.message));
$("demo-boss").onclick=()=>api("demo/boss").catch(e=>toast(e.message));
for(const r of Object.values(RULE_OPTIONS)){const box=document.createElement("div");box.className="rule-card";const strong=document.createElement("strong");strong.textContent=r.label;const p=document.createElement("p");p.textContent=r.description;const code=document.createElement("code");code.textContent="REGRA "+r.id.toUpperCase()+" · CUSTO 100 PTS";box.append(strong,p,code);$("rule-options").append(box);}
$("voices").onchange=e=>{audio.voices=e.target.checked;if(!audio.voices)audio.stopVoice();};$("sfx").onchange=e=>audio.sfxEnabled=e.target.checked;$("voice-volume").oninput=e=>audio.voiceVolume=Number(e.target.value)/100;
$("music-file").onchange=async e=>{if(!e.target.files[0])return;try{$("music-name").textContent=await audio.load(e.target.files[0]);manual=false;await $("music").play();await api("music",{source:"file"});}catch(e){toast(e.message);}};
$("demo-music").onclick=async()=>{try{await audio.unlock();const r=await fetch('/assets/colony_pulse.wav');const file=new File([await r.blob()],"Colony Pulse · trilha original.wav",{type:"audio/wav"});$("music-name").textContent=await audio.load(file);manual=false;await $("music").play();await api("music",{source:"file"});toast("Trilha original · 120 BPM. Pode usar na demonstração.");}catch(e){toast(e.message);}};
$("music").onplay=()=>{manual=false;audio.unlock().then(()=>api("music",{source:"file"})).catch(e=>toast(e.message));};$("music").onpause=()=>{audio.cancelPending();if(!manual)api("music",{source:"paused"}).catch(()=>{});};
$("bpm").oninput=e=>$("bpm-value").textContent=e.target.value;$("manual-tempo").onclick=()=>{manual=true;api("music",{source:"manual",bpm:Number($("bpm").value)}).catch(e=>toast(e.message));};$("auto-beat").onclick=()=>{manual=false;api("music",{source:"file"}).catch(e=>toast(e.message));};
let taps=[];$("tap").onclick=()=>{const t=performance.now();taps=taps.filter(n=>t-n<4000);taps.push(t);if(taps.length>1){const bpm=Math.round(60000/((t-taps[0])/(taps.length-1)));$("bpm").value=Math.max(50,Math.min(240,bpm));$("bpm-value").textContent=$("bpm").value;manual=true;api("music",{source:"manual",bpm:Number($("bpm").value)}).catch(()=>{});}};
$("sensitivity").onchange=e=>{audio.setMode(e.target.value);api("rhythm/mode",{mode:e.target.value}).catch(()=>{});};$("offset").oninput=e=>{audio.offset=Number(e.target.value);$("offset-value").textContent=audio.offset+" ms";api("rhythm/offset",{offset:audio.offset}).catch(()=>{});};
$("pair-generate").onclick=()=>api("rhythm/code").then(j=>$("pair-code").textContent=j.code).catch(e=>toast(e.message));$("pair-disconnect").onclick=()=>api("rhythm/disconnect").catch(e=>toast(e.message));$("native-select").onclick=()=>api("music",{source:"external"}).catch(e=>toast(e.message));
$("quality").onchange=e=>world.setQuality(e.target.value);$("cinematic").onchange=e=>world.cinematic=e.target.checked;$("reduce-motion").onchange=e=>world.reduceMotion=e.target.checked;
$("save-gifts").onclick=()=>{try{const giftMap=JSON.parse($("gift-map").value||"{}");api("settings",{giftMap}).then(()=>toast("Presentes atualizados para este modo.")).catch(e=>toast(e.message));}catch{toast("JSON inválido. Exemplo: {\"5655\":\"rose\"}");}};
$("ranking-toggle").onclick=()=>$("ranking-box").classList.toggle("hidden");$("fullscreen").onclick=()=>document.fullscreenElement?document.exitFullscreen?.():document.documentElement.requestFullscreen?.().catch(()=>{});
function gifts(){const items=GIFT_GUIDE.slice(slide*3,slide*3+3);$("gifts").replaceChildren(...items.map(g=>{const div=document.createElement("div");div.className="gift";const img=document.createElement("img");img.src='/assets/'+g.icon+'.svg';img.alt=g.name;const text=document.createElement("div"),strong=document.createElement("strong"),b=document.createElement("b"),small=document.createElement("small");strong.textContent=g.name.toUpperCase();b.textContent=g.effect;small.textContent=g.detail;text.append(strong,b,small);div.append(img,text);return div;}));$("slide-index").textContent=(slide+1)+" / 2";}
$("prev-gift").onclick=$("next-gift").onclick=()=>{slide=1-slide;gifts();};setInterval(()=>{slide=1-slide;gifts();},6500);gifts();
setInterval(()=>{const m=world.metrics();$("performance").textContent=`${m.fps} FPS · ${m.actors} atores visíveis · ${m.effects} efeitos ativos`;},1500);
window.JUJUTSU={world,audio,api,get state(){return state;}};
