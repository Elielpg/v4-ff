const B=BABYLON,V=B.Vector3;
export class CursedFX {
 constructor(w){this.w=w;this.pool=[];this.limit=48;this.materials=new Map();
  for(let i=0;i<12;i++)for(const kind of ["orb","ring","beam","shard"]){let q;
   if(kind==="orb")q=B.MeshBuilder.CreateSphere("energia",{diameter:1,segments:8},w.scene);
   if(kind==="ring")q=B.MeshBuilder.CreateTorus("onda",{diameter:1,thickness:.035,tessellation:24},w.scene);
   if(kind==="beam")q=B.MeshBuilder.CreateCylinder("corte",{diameter:.06,height:1,tessellation:6},w.scene);
   if(kind==="shard")q=B.MeshBuilder.CreatePolyhedron("fragmento",{type:1,size:.25},w.scene);
   q.isPickable=false;q.setEnabled(false);w.glow.addIncludedOnlyMesh(q);this.pool.push({kind,q,at:-100,life:.5});
  }
  this.summons=[];
  const spirit=this.mat("#b6d5ff");
  for(const kind of ["wolf","wolf","spirit","spirit"]){
   const root=new B.TransformNode("shikigami-"+kind,w.scene);
   const base=w.ball("spirit body",kind==="wolf"?.7:1.1,spirit,root,kind==="wolf"?[0,.55,0]:[0,1.6,0],kind==="wolf"?[.65,.7,1.7]:[1.25,1.3,.55],10);
   const head=w.ball("spirit head",kind==="wolf"?.45:.9,spirit,root,kind==="wolf"?[0,.8,.55]:[0,2.4,.1],kind==="wolf"?[.8,.8,1.2]:[1.2,1,.8],12);
   for(const s of [-1,1]){
    if(kind==="wolf"){const ear=B.MeshBuilder.CreateCylinder("wolf ear",{height:.28,diameterBottom:.17,diameterTop:0,tessellation:3},w.scene);ear.material=spirit;ear.parent=root;ear.position.set(s*.14,1.05,.57);for(const z of [-.4,.4])w.cylinder("wolf leg",.08,.4,spirit,root,[s*.17,.25,z]);}
    else{const arm=w.cylinder("spirit arm",.18,1.6,spirit,root,[s*.78,1.5,.1]);arm.rotation.z=s*.7;w.ball("spirit hand",.3,spirit,root,[s*1.25,.95,.1]);}
    w.ball("spirit eye",kind==="wolf"?.06:.12,this.mat("#17264a"),root,kind==="wolf"?[s*.11,.85,.79]:[s*.2,2.52,.43]);
   }
   for(const mesh of root.getChildMeshes()){mesh.isPickable=false;w.glow.addIncludedOnlyMesh(mesh);}root.setEnabled(false);this.summons.push({kind,root,at:-100,life:1.6});
  }
 }
 mat(hex){if(!this.materials.has(hex)){const m=new B.StandardMaterial("CE-"+hex,this.w.scene);m.diffuseColor=B.Color3.FromHexString(hex);m.emissiveColor=m.diffuseColor;m.disableLighting=true;m.specularColor=B.Color3.Black();this.materials.set(hex,m);}return this.materials.get(hex);}
 emit(kind,from,to,{color="#a3baff",scale=1,life=.6,delay=0,rotation=0}={}){
  const slots=this.pool.slice(0,this.limit).filter(f=>f.kind===kind);if(!slots.length)return;
  const f=slots.reduce((a,b)=>a.at+a.life<b.at+b.life?a:b);Object.assign(f,{from:from.clone(),to:(to||from).clone(),at:performance.now()/1000+delay,life,scale,rotation});
  f.q.material=this.mat(color);f.q.rotationQuaternion=null;f.q.rotation.set(0,0,rotation);
 }
 impact(pos,color="#fff1b9",power=1){this.emit("ring",pos,null,{color,scale:power,life:.35,rotation:Math.PI/2});for(let i=0;i<5;i++){const a=i/5*Math.PI*2;this.emit("shard",pos,pos.add(new V(Math.cos(a)*power,1+Math.sin(a),Math.sin(a)*power)),{color,scale:.6,life:.45});}}
 trail(from,to,color){for(let i=0;i<3;i++)this.emit("orb",V.Lerp(from,to,i/3).add(new V(0,.9,0)),null,{color,scale:.22,life:.23,delay:i*.02});}
 technique(a,actors){const from=actors.get(a.player)?.root.position.clone()||new V(0,.1,0),to=actors.get(a.target)?.root.position.clone()||new V(0,.1,0);from.y+=1.25;to.y+=1.25;
  const color=a.color||"#cb9eff",kind=a.kind==="technique"?a.kindEffect||a.effectKind:a.kind;
  const effect=a.effectKind||a.fxKind||a.type||kind;
  if(a.domain)return;
  if(["slash","black","impact","rush"].includes(effect)){
   this.emit("beam",from,to,{color,scale:effect==="black"?2.2:1,life:.22});
   this.emit("beam",to.add(new V(-1,-.5,0)),to.add(new V(1,.7,0)),{color:effect==="black"?"#ff3156":"#ffffff",life:.24,scale:.6});this.impact(to,color,1.1);
  }else if(effect==="lightning"){
   const high=to.add(new V(0,6,0));for(let i=0;i<5;i++){const p=V.Lerp(high,to,i/5),q=V.Lerp(high,to,(i+1)/5);p.x+=(i%2?.3:-.3);this.emit("beam",p,q,{color,life:.4,scale:1.2,delay:.1});}this.impact(to,color,1.5);
  }else if(effect==="meteor"){
   this.emit("orb",to.add(new V(0,9,0)),to,{color,scale:2.5,life:.85});this.emit("ring",to,null,{color,scale:3,life:.8,delay:.65});
  }else if(effect==="gravity"||effect==="spiral"){
   for(let i=0;i<5;i++)this.emit("ring",to.add(new V(0,(i-2)*.3,0)),null,{color,scale:1+i*.3,life:1.1,delay:i*.06,rotation:i*.4});this.emit("orb",to,null,{color,scale:1.1,life:.9});
  }else if(effect==="summon"||effect==="wolf"){
   const type=effect==="wolf"?"wolf":"spirit",slots=this.summons.filter(s=>s.kind===type);
   for(const [i,s]of slots.entries()){s.at=performance.now()/1000+i*.05;s.from=from.add(new V((i?1:-1)*.6,-1.1,0));s.to=to.add(new V((i?1:-1)*.5,-1.1,0));s.color=color;}
   this.emit("orb",from, to,{color,scale:effect==="wolf"?.85:2.3,life:1});for(let i=0;i<5;i++)this.emit("shard",from.add(new V(0,i*.2,0)),to.add(new V((i-2)*.3,i*.15,0)),{color,scale:1,life:1,delay:i*.04});
  }else{
   if(a.technique==="purple"){this.emit("orb",from.add(new V(-.4,0,0)),from,{color:"#6ac8ff",scale:.7,life:.35});this.emit("orb",from.add(new V(.4,0,0)),from,{color:"#ff567e",scale:.7,life:.35});this.emit("ring",from,null,{color,scale:2.1,life:.6});}
   this.emit("orb",from,to,{color,scale:effect==="beam"?1.8:.8,life:.85,delay:.1});this.emit("beam",from,to,{color,scale:effect==="beam"?8:1.2,life:.45,delay:.24});if(effect==="beam")this.emit("beam",from,to,{color:"#e5d8ff",scale:2.2,life:.4,delay:.25});this.impact(to,color,1.9);
  }
 }
 update(t,calm=false){for(const [i,s]of this.summons.entries()){const age=t-s.at,on=age>=0&&age<s.life&&(this.limit>24||i%2===0);s.root.setEnabled(on);if(on){const p=age/s.life;s.root.position.copyFrom(V.Lerp(s.from,s.to,Math.min(1,p*1.4)));s.root.rotation.y=Math.atan2(s.to.x-s.from.x,s.to.z-s.from.z);s.root.scaling.setAll(s.kind==="wolf"?1:1.1);for(const m of s.root.getChildMeshes())if(m.name!=="spirit eye"){m.material=this.mat(s.color);m.visibility=(calm?.4:.75)*Math.sin(Math.PI*p);}}}
  for(const [i,f]of this.pool.entries()){const age=t-f.at,on=i<this.limit&&age>=0&&age<f.life;f.q.setEnabled(on);if(!on)continue;const p=age/f.life;f.q.visibility=(calm?.35:.85)*(1-p);
   if(f.kind==="beam"){this.w.link(f.q,f.from,f.to);f.q.scaling.x=f.q.scaling.z=f.scale;}
   else {f.q.position.copyFrom(V.Lerp(f.from,f.to,p));f.q.scaling.setAll(f.scale*(f.kind==="ring"?.6+p*2:f.kind==="orb"?Math.sin(Math.PI*p)*.7+.3:1-p));f.q.rotation.y=t*3;}
  }}
 clear(){for(const f of this.pool){f.at=-100;f.q.setEnabled(false);}for(const s of this.summons){s.at=-100;s.root.setEnabled(false);}}
 get active(){return this.pool.filter(f=>f.q.isEnabled()).length;}
}
