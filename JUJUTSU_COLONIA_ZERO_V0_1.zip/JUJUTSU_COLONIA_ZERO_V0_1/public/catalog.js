export const CHARACTERS = {
  gojo: { name: "Gojo", team: "gojo", color: "#67dfff", hair: "#eef5ff", suit: "#141d38", techniques: ["blue", "red", "purple", "void"], voice: "gojo" },
  yuji: { name: "Yuji", team: "gojo", color: "#ff9e77", hair: "#eaaa99", suit: "#243451", techniques: ["divergent", "blackFlash", "rush", "impact"], voice: "yuji" },
  megumi: { name: "Megumi", team: "gojo", color: "#8ea6ff", hair: "#141e2b", suit: "#18283e", techniques: ["wolf", "nue", "shadows", "garden"], voice: "megumi" },
  yuta: { name: "Yuta", team: "gojo", color: "#b2f9c9", hair: "#202130", suit: "#d8e9e6", techniques: ["katana", "rika", "copy", "bond"], voice: "yuta" },
  kenjaku: { name: "Kenjaku", team: "kenjaku", color: "#e9adff", hair: "#17141f", suit: "#362c4a", techniques: ["curse", "uzumaki", "gravity", "womb"], voice: "kenjaku" },
  mahito: { name: "Mahito", team: "kenjaku", color: "#77dbd8", hair: "#93b0c5", suit: "#364850", techniques: ["transfigure", "blades", "soul", "perfection"], voice: "mahito" },
  jogo: { name: "Jogo", team: "kenjaku", color: "#ffb44b", hair: "#564f43", suit: "#846949", techniques: ["ember", "volcano", "meteor", "coffin"], voice: "jogo" },
  sukuna: { name: "Sukuna", team: "boss", color: "#ff5069", hair: "#db9894", suit: "#f0e8dd", techniques: ["cleave", "dismantle", "furnace", "shrine"], voice: "sukuna" },
  citizen: { name: "Cidadão", team: "neutral", color: "#9aabc3", hair: "#443a37", suit: "#6b7c91", techniques: [] },
};
const technique = (name, color, kind, power, cost, cooldown, voice, domain = false) => ({ name, color, kind, power, cost, cooldown, voice, domain });
export const TECHNIQUES = {
  blue: technique("LAPSO · AZUL", "#4ba6ff", "gravity", 18, 18, 5000, "blue"),
  red: technique("REVERSÃO · VERMELHO", "#ff5473", "burst", 26, 24, 7000, "red"),
  purple: technique("VAZIO · ROXO", "#bf7dff", "beam", 40, 48, 13000, "purple"),
  void: technique("VAZIO ILIMITADO", "#65dcff", "domain", 40, 75, 25000, "void", true),
  divergent: technique("PUNHO DIVERGENTE", "#4fd5ff", "impact", 18, 15, 4500, "strike"),
  blackFlash: technique("BLACK FLASH", "#ff3958", "black", 34, 35, 10000, "blackflash"),
  rush: technique("SEQUÊNCIA DO TIGRE", "#ffb27d", "rush", 25, 24, 7000, "strike"),
  impact: technique("VONTADE INQUEBRÁVEL", "#ff6987", "domain", 32, 65, 24000, "domain", true),
  wolf: technique("CÃES DIVINOS", "#c0d2ff", "wolf", 22, 20, 6000, "shadows"),
  nue: technique("NUE · TROVÃO", "#9896ff", "lightning", 27, 26, 8000, "shadows"),
  shadows: technique("DEZ SOMBRAS", "#9a83e9", "gravity", 30, 34, 11000, "shadows"),
  garden: technique("JARDIM DAS SOMBRAS", "#8497df", "domain", 36, 70, 25000, "domain", true),
  katana: technique("LÂMINA AMALDIÇOADA", "#c1ffd6", "slash", 21, 18, 5000, "strike"),
  rika: technique("RIKA · MANIFESTAÇÃO", "#c6a6ff", "summon", 32, 32, 9500, "rika"),
  copy: technique("TÉCNICA COPIADA", "#b2ffda", "beam", 28, 28, 8500, "rika"),
  bond: technique("AMOR MÚTUO", "#b4f9d4", "domain", 42, 75, 26000, "domain", true),
  curse: technique("MANIPULAÇÃO DE MALDIÇÕES", "#d3a8ff", "summon", 21, 20, 5500, "curses"),
  uzumaki: technique("UZUMAKI", "#b774ef", "spiral", 36, 40, 13000, "curses"),
  gravity: technique("ANTIGRAVIDADE", "#c19eff", "gravity", 24, 26, 8500, "curses"),
  womb: technique("PROFUSÃO DO VENTRE", "#cb9bff", "domain", 40, 75, 25000, "domain", true),
  transfigure: technique("TRANSMUTAÇÃO OCIOSA", "#84e5d6", "impact", 22, 20, 5500, "soul"),
  blades: technique("LÂMINAS DA ALMA", "#7ee6e5", "slash", 25, 25, 7000, "soul"),
  soul: technique("ISÔMERO DA ALMA", "#64d2bd", "summon", 31, 34, 11000, "soul"),
  perfection: technique("AUTOENCARNAÇÃO", "#9cf2e2", "domain", 37, 70, 26000, "domain", true),
  ember: technique("BRASAS AMALDIÇOADAS", "#ffb45b", "burst", 22, 18, 5000, "fire"),
  volcano: technique("ERUPÇÃO", "#ff7e49", "burst", 28, 28, 8000, "fire"),
  meteor: technique("METEORO MÁXIMO", "#ffd078", "meteor", 39, 45, 14000, "fire"),
  coffin: technique("CAIXÃO DA MONTANHA", "#ff8c48", "domain", 40, 75, 25000, "domain", true),
  cleave: technique("CLIVAR", "#ff7486", "slash", 12, 0, 1800, "cleave"),
  dismantle: technique("DESMANTELAR", "#ffd4d7", "slash", 18, 0, 3500, "cleave"),
  furnace: technique("FORNALHA", "#ffb458", "meteor", 32, 0, 11000, "furnace"),
  shrine: technique("SANTUÁRIO MALEVOLENTE", "#ff5469", "domain", 42, 0, 24000, "shrine", true),
};
export const RULE_OPTIONS = {
  refugio: { id: "refugio", label: "REFÚGIO", description: "Cidadãos protegidos por 45 segundos.", duration: 45000 },
  troca: { id: "troca", label: "TROCA DE PONTOS", description: "Libera TRANSFERIR @nome quantidade por 90 segundos.", duration: 90000 },
  resgate: { id: "resgate", label: "RESGATE", description: "Traz de volta o aliado eliminado há mais tempo.", duration: 0 },
  fluxo: { id: "fluxo", label: "FLUXO AMALDIÇOADO", description: "Regeneração de energia ×1,5 para os dois times por 45 segundos.", duration: 45000 },
};
export const GIFT_GUIDE = [
  { id: "rose", name: "Rosa", icon: "rose", effect: "ENTRAR", detail: "Sorteia time e personagem" },
  { id: "energy", name: "Heart Me", icon: "heart", effect: "+35 ENERGIA", detail: "Alimenta suas técnicas" },
  { id: "reverse", name: "GG", icon: "reverse", effect: "REVERSÃO", detail: "Recupera 45 de vida" },
  { id: "special", name: "Perfume", icon: "spark", effect: "TÉCNICA 3", detail: "Ativa o poder do personagem" },
  { id: "domain", name: "Galaxy", icon: "galaxy", effect: "DOMÍNIO", detail: "Expansão do seu personagem" },
  { id: "awakening", name: "Lion", icon: "crown", effect: "DESPERTAR", detail: "Vida, energia e Black Flash" },
];
const norm = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
const ALIASES = { rose: ["rose", "rosa"], energy: ["heart me", "heartme", "coracao", "coração"], reverse: ["gg"], special: ["perfume"], domain: ["galaxy", "galaxia", "galáxia"], awakening: ["lion", "leao", "leão"] };
export function giftEffect(e, overrides = {}) {
  const key = String(e.giftId || "");
  if (overrides[key] && GIFT_GUIDE.some(g => g.id === overrides[key])) return overrides[key];
  if (key === "5655") return "rose";
  const name = norm(e.gift);
  return Object.entries(ALIASES).find(([, names]) => names.some(n => norm(n) === name))?.[0] || null;
}
