export const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
export function strike(p){p=clamp(p);return p<.2?smooth(p/.2):1-smooth((p-.2)/.8);}
export function combatPose(move,p) {
 const rapid=move==="flurry", part=rapid&&p<1?(p*3)%1:p, f=strike(part), kick=["airKick","kick"].includes(move);
 return {f,kick,side:rapid?(Math.floor(p*3)%2?-1:1):1,jump:kick?Math.sin(clamp(p)*Math.PI)*.9:0,twist:f*(rapid?.3:.16),spin:kick?smooth(p)*Math.PI*2:0};
}
export function approach(from,to,p,teleport=false){const f=teleport?(p<.13?smooth(p/.13):1-smooth((p-.35)/.65)):strike(p);const dx=to.x-from.x,dz=to.z-from.z,n=Math.hypot(dx,dz)||1;return {x:from.x+dx/n*Math.max(0,n-1.25)*f,z:from.z+dz/n*Math.max(0,n-1.25)*f};}
