import {PARK_LIMITS,CANNON_MS,parkSettings,cannonPhase} from '../public/park-rules.js';
import {giftRule,hash} from '../public/rules.js';
const bounded=(x,max=1e12)=>Math.max(0,Math.min(max,Math.floor(Number(x)||0)));
const safeId=x=>typeof x==='string'&&x.length>0&&x.length<=80?x:null;
export class ParkSystem {
 constructor({now=Date.now,emit=()=>{},saved=null,config=null}={}){
  this.now=now;this.emit=emit;this.records=new Map();this.queue=[];this.active=null;this.completed=new Set();this.clock=bounded(saved?.clock);this.serial=bounded(saved?.serial);this.priorityStreak=bounded(saved?.priorityStreak,2);this.config=parkSettings({...saved?.config,...config});
  for(const item of (Array.isArray(saved?.records)?saved.records:[]).slice(-PARK_LIMITS.records)){const id=safeId(item.id);if(id)this.records.set(id,{id,score:bounded(item.score),firstSeen:bounded(item.firstSeen)||now(),lastCannon:bounded(item.lastCannon),lastComment:bounded(item.lastComment),message:String(item.message||'').slice(0,90),messageAt:bounded(item.messageAt),arrival:Number.isFinite(item.arrival?.started)?{started:Math.min(this.clock,bounded(item.arrival.started)),at:bounded(item.arrival.at),car:bounded(item.arrival.car,7)}:null});}
  for(const id of (Array.isArray(saved?.completed)?saved.completed:[]).slice(-PARK_LIMITS.completed))if(safeId(id))this.completed.add(id);
  const valid=item=>item&&safeId(item.id)&&safeId(item.user)&&!this.completed.has(item.id);
  if(valid(saved?.active))this.active={id:saved.active.id,user:saved.active.user,source:saved.active.source==='gift'?'gift':'chat',started:Math.min(this.clock,bounded(saved.active.started)),shot:!!saved.active.shot,landed:!!saved.active.landed};
  for(const q of (Array.isArray(saved?.queue)?saved.queue:[]).slice(0,PARK_LIMITS.queue))if(valid(q)&&!this.protects(q.user))this.queue.push({id:q.id,user:q.user,source:q.source==='gift'?'gift':'chat',queued:bounded(q.queued)});
 }
 record(p){let r=this.records.get(p.id);if(!r){if(this.records.size>=PARK_LIMITS.records){const key=[...this.records.keys()].find(id=>!this.protects(id));if(key)this.records.delete(key);}r={id:p.id,score:0,firstSeen:this.now(),lastCannon:0,lastComment:0,message:'',messageAt:0};this.records.set(p.id,r);}return r;}
 arrivalElapsed(a){return a.at?this.now()-a.at:this.clock-a.started;}
 configure(value){this.config=parkSettings({...this.config,...value});return this.config;}
 protects(id){return this.active?.user===id||this.queue.some(q=>q.user===id);}
 orderedQueue(){const pending=[...this.queue],ordered=[];let streak=this.priorityStreak;while(pending.length){const ordinary=pending.findIndex(q=>q.source==='chat'),i=streak>=2&&ordinary>=0?ordinary:0,q=pending.splice(i,1)[0];ordered.push(q);streak=q.source==='gift'?Math.min(2,streak+1):0;}return ordered;}
 request(p,source='chat'){
  const r=this.record(p);if(!this.config.enabled)return {accepted:false,reason:'disabled'};
  if(this.protects(p.id))return {accepted:false,reason:'already-queued'};
  if(source==='chat'&&r.lastCannon&&this.now()-r.lastCannon<this.config.freeCooldown*1000)return {accepted:false,reason:'cooldown',waitMs:this.config.freeCooldown*1000-(this.now()-r.lastCannon)};
  if(this.queue.length>=PARK_LIMITS.queue)return {accepted:false,reason:'full'};
  const q={id:'ride-'+(++this.serial),user:p.id,source,queued:this.clock};if(source==='gift'){const i=this.queue.findIndex(q=>q.source!=='gift');if(i>=0)this.queue.splice(i,0,q);else this.queue.push(q);}else this.queue.push(q);
  r.arrival=null;r.lastCannon=this.now();this.emit('cannonQueue',{user:p.id,name:p.name,request:q.id,position:this.orderedQueue().findIndex(x=>x.id===q.id)+1,source});return {accepted:true,request:q.id};
 }
 event(p,e){
  const fresh=!this.records.has(p.id),r=this.record(p),text=String(e.text||'').trim();if(e.type==='join'||fresh){r.arrival={started:this.clock,at:this.now(),car:hash(p.id)%8};this.emit('arrivalStart',{user:p.id,name:p.name,car:r.arrival.car});}
  if(e.type==='comment'&&text){r.message=text.slice(0,90);r.messageAt=this.now();if(!r.lastComment||this.now()-r.lastComment>=4000){r.score=Math.min(1e12,r.score+1);r.lastComment=this.now();}if(/^ATIRAR[!. ]*$/i.test(text))return this.request(p,'chat');}
  if(e.type==='gift'&&Number(e.count??1)>0){const rule=giftRule(e.gift,e.giftId),popular=/fique\s*popular|popular|make.*popular/i.test(e.gift||''),key=this.config.cannonGift;if(key==='any'||key==='popular'&&popular||key===rule?.id)return this.request(p,'gift');}
  return null;
 }
 tick(dt=50){
  this.clock+=Math.max(0,Math.min(250,Number(dt)||0));
  if(!this.active&&this.queue.length&&this.config.enabled){const ordinary=this.queue.findIndex(q=>q.source==='chat'),index=this.priorityStreak>=2&&ordinary>=0?ordinary:0,q=this.queue.splice(index,1)[0];this.priorityStreak=q.source==='gift'?Math.min(2,this.priorityStreak+1):0;this.active={...q,started:this.clock,shot:false,landed:false};this.emit('cannonReady',{user:q.user,request:q.id});}
  const a=this.active;if(!a)return;
  const elapsed=this.clock-a.started;
  if(!a.shot&&elapsed>=PARK_LIMITS.prepareMs){a.shot=true;this.emit('cannonLaunch',{user:a.user,request:a.id});}
  if(!a.landed&&elapsed>=PARK_LIMITS.prepareMs+PARK_LIMITS.flightMs){a.landed=true;const r=this.records.get(a.user);if(r)r.score=Math.min(1e12,r.score+this.config.landingPoints);this.emit('cannonLand',{user:a.user,request:a.id,points:this.config.landingPoints});}
  if(elapsed>=CANNON_MS){this.completed.add(a.id);while(this.completed.size>PARK_LIMITS.completed)this.completed.delete(this.completed.values().next().value);this.active=null;this.emit('cannonFinish',{user:a.user,request:a.id});}
 }
 score(p){return Math.round((Math.max(0,p.heroPoints||0)+Math.max(0,p.villainPoints||0)+(this.records.get(p.id)?.score||0))*10)/10;}
 ranks(players){return [...players.values()].map(p=>({...p,points:this.score(p)})).filter(p=>p.points>0).sort((a,b)=>b.points-a.points||a.id.localeCompare(b.id)).slice(0,6).map(p=>({id:p.id,name:p.name,avatar:p.avatar,points:p.points}));}
 public(players){
  const top=this.ranks(players),candidates=[...players.values()].sort((a,b)=>b.lastSeen-a.lastSeen).slice(0,PARK_LIMITS.visible),ids=new Set([...candidates.map(p=>p.id),...top.map(p=>p.id),...[...this.records.values()].filter(r=>r.arrival&&this.arrivalElapsed(r.arrival)<9000).slice(-128).map(r=>r.id),...this.queue.map(q=>q.user),...(this.active?[this.active.user]:[])]);
  const visitors=[...ids].map(id=>players.get(id)).filter(Boolean).map(p=>{const r=this.records.get(p.id);return {id:p.id,name:p.name,avatar:p.avatar,seed:hash(p.id),firstSeen:r?.firstSeen||p.lastSeen,message:r?.messageAt>this.now()-9000?r.message:'',points:this.score(p),arrival:r?.arrival&&this.arrivalElapsed(r.arrival)<9000?{...r.arrival,elapsed:this.arrivalElapsed(r.arrival)}:null};});
  return {config:this.config,time:this.clock,active:this.active?{...this.active,elapsedMs:this.clock-this.active.started,phase:cannonPhase(this.clock-this.active.started)}:null,queue:this.orderedQueue().map((q,i)=>({user:q.user,position:i+1,source:q.source,estimatedMs:(this.active?Math.max(0,CANNON_MS-(this.clock-this.active.started)):0)+i*CANNON_MS,estimateMayChange:true})),visitors,top};
 }
 merge(keep,remove){const b=this.records.get(remove);if(b){const a=this.records.get(keep);if(a){a.score=Math.min(1e12,a.score+b.score);a.lastCannon=Math.max(a.lastCannon,b.lastCannon);a.firstSeen=Math.min(a.firstSeen,b.firstSeen);if((b.arrival?.started??-1)>(a.arrival?.started??-1))a.arrival=b.arrival;}else{b.id=keep;this.records.set(keep,b);}this.records.delete(remove);}if(this.active?.user===remove)this.active.user=keep;const seen=new Set(this.active?[this.active.user]:[]);this.queue=this.queue.map(q=>({...q,user:q.user===remove?keep:q.user})).filter(q=>{if(seen.has(q.user))return false;seen.add(q.user);return true;});}
 save(){return {config:this.config,clock:this.clock,serial:this.serial,priorityStreak:this.priorityStreak,records:[...this.records.values()],queue:this.queue,active:this.active,completed:[...this.completed]};}
}
