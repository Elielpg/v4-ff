# Evolução V0.6 — Palcos, música e comentários

A cópia V0.5 publicada foi mantida intacta e seu ZIP foi copiado para um backup antes das alterações.

## Gráficos

Pesquisa no GitHub localizou RobotExpressive e a declaração CC0 no exemplo oficial do Three.js. O GLB foi incorporado localmente ao Babylon.js existente, com sete instâncias reutilizadas, cores por usuário e retratos compartilhando o atlas. O carregador glTF local corresponde à versão 9.32.1 da engine. Não houve migração de engine.

O palco lateral reúne seis líderes; o palco central tem um apresentador. As animações são amostradas pela fase da batida, com contratempos separados do tempo principal. O mortal central combina giro e arco procedural. As luzes recebem a mesma fase. Fonte de batida configurável e perda de sinal interrompem a dança. O modo SHOW da câmera destaca o apresentador; o modo de frente da cobra usa distância 16, antes 8,7.

A repetição de texturas corrigiu a grade que só aparecia num canto. Há grade 18×28, areia repetida, escamas, plantas e caixas de som. Cabeça ganhou detalhes e o giro da cobra usa amortecimento exponencial. Não foi alegado ganho medido de FPS no telefone.

## Chegadas

Uma entrada identificada inicia passeio visual de nove segundos: seis dentro do carrinho e três no salto para a gaiola. O registro de missão continua único; reconexões não duplicam vagas. Quem já escapou conserva sua proteção e pousa na área livre. O canhão solicitado cancela a apresentação de chegada para não apresentar o mesmo avatar em dois lugares. O banquete espera as apresentações do grupo antes de cair.

A apresentação usa tempo de parede para continuar quando o jogo está pausado, como os próprios vagões decorativos. O canhão mantém seu relógio lógico e sua recuperação anterior. Filas, estado e aliases são preservados. Sob muitas chegadas, os carros são compartilhados e a câmera acompanha um por vez; não foi prometido um close exclusivo de cada pessoa em um pico simultâneo.

## Comentários: achados confirmados no código

1. IA livre vinha desligada por padrão. Áudio pronto funcionando não prova Qwen ativo. Novo botão detecta o serviço e ativa a conversa quando disponível; script diagnosticar.sh informa o estado real.
2. Saudações usavam espera global de 18 s, silenciando usuários diferentes. Agora a espera é curta e individual.
3. Perguntas expiradas, fila cheia e falha do modelo não tinham retorno visível. Agora há aviso e contadores, com prazo maior para texto.
4. Presentes podiam remover respostas da fila ou interrompê-las sem retomada. A fila de reprodução preserva respostas da IA e não permite esse corte.
5. O texto inicial dizia que a conversa estava desligada mesmo em configuração ativada. O status agora corresponde à configuração.

Esses são achados reproduzíveis; não identificam sozinhos qual condição ocorreu na instalação do usuário. Falhas de evento/conexão, serviços realmente parados e autorização de reprodução do Chrome ainda precisam ser observadas no aparelho quando ocorrerem.
