# Modelos 3D pesquisados e incorporados

Foi consultado o modelo **RobotExpressive**, de Tomás Laulhé (Quaternius), com modificações de Don McCurdy. O exemplo oficial do Three.js declara explicitamente **CC0** e demonstra as animações Dance, Walking, Running, Sitting, Jump, Wave e outras.

Fonte do modelo: https://github.com/mrdoob/three.js/tree/dev/examples/models/gltf/RobotExpressive

Declaração de autoria/licença e demonstração: https://github.com/mrdoob/three.js/blob/dev/examples/webgl_animation_skinning_morph.html

O arquivo GLB de 463.988 bytes foi incluído em `public/assets/models/RobotExpressive.glb`. O jogo carrega o arquivo local com **Babylon.js**, sem migrar para Three.js e sem depender de CDN durante a LIVE. Sete instâncias são reutilizadas: seis líderes e o apresentador do palco central. Cor e retrato identificam o participante. A multidão continua com avatares instanciados leves; se o GLB falhar, o palco conserva a representação leve.

As animações do modelo são amostradas pelo relógio musical do jogo. O mortal do apresentador combina a animação existente com giro e arco procedural. O detector de batidas é genérico; não reconhece o título ou o cantor da música.

O carregador glTF `babylonjs-loaders` 9.32.1, Apache-2.0, corresponde à versão 9.32.1 do Babylon.js já usada. Fonte: https://github.com/BabylonJS/Babylon.js . O carregador é distribuído localmente em `public/vendor/`. O GLB não exige Draco, KTX ou recursos externos.

O nome do projeto não implica vínculo com Quaternius, Three.js ou Babylon.js. Nenhum modelo foi extraído de vídeos do TikTok.
