# Arquitetura da V0.7

```text
TikTok / ponte local / DEMO
          |
server/live.mjs + server/identity.mjs
          |
server/engine.mjs   <-- estado canônico; tick de 50 ms
  |-- pilot.mjs         caminho seguro na grade
  |-- cage.mjs          entrada, fuga, banquete e créditos
  |-- park.mjs          canhão, fila justa e pontos do parque
  |-- show-system.mjs   marcos, eventos, duelo, retorno e hall
  |-- storage.mjs       estados separados DEMO/LIVE e backup
  |
server/index.mjs -- SSE/HTTP --> public/app.js
  |                             |-- cinematic-world.js / world.js
  |                             |-- park-stage.js / cage-stage.js
  |                             |-- stage-show.js / zigbot.js
  |                             |-- occlusion.js
  |                             |-- show-ui.js / clip-replay.js
  |                             |-- audio.js / playlist.js
  |                             `-- studio.js
  |
  `-- host.mjs --> Qwen local (texto) + Piper local (voz)

Captador Android --> rhythm.mjs --> batida --> dança e luzes
Canvas + áudio --> MediaRecorder --> studio.mjs --> FFmpeg --> RTMP
scripts/supervisor.mjs --> recuperação limitada do servidor
```

O modelo social não executa comandos do sistema nem decide colisões, recompensas ou vitórias. O motor continua mesmo com falha de voz. A configuração nova aceita apenas booleanos conhecidos e as quatro metas numéricas permitidas; a rota mantém a verificação de origem local.

`show-system.mjs` usa relógio lógico. Visitas e dias do hall usam tempo de calendário; o dia considera Brasília. Os marcos são gravados antes de anunciar o evento. O placar do duelo é renovado antes do anúncio para que um instantâneo salvo nesse ponto não repita recompensas ao restaurar. A migração inicial usa os pontos existentes como referência, sem atribuí-los ao hall de hoje.

O replay pertence ao cliente. Guarda no máximo 16 estados recentes, não reenvia eventos ao servidor, não sintetiza voz antiga e não concede pontos. O compositor de transmissão desenha sua própria interface e precisa acompanhar alterações do HUD; ele também identifica replay e exibe a disputa.

Limites preservados: 1.500 jogadores, 1.500 registros da gaiola, 1.500 do parque, 1.500 perfis de retorno, oito aguardando no canhão, 24 destaques, três comidas comuns visíveis, 18 bombas e filas de créditos limitadas. O histórico de retorno tem até sete dias de pontuação por pessoa. O conjunto visual suporta até 192 atores; não são 1.500 modelos simultâneos.

Os ZigBots são geometria procedural do projeto, com articulações e expressão próprias. O RobotExpressive continua como alternativa. O atlas de fotos é compartilhado; não é criada uma textura grande para cada espectador. `DanceClock` segue o sinal da playlist ou do captador, respeitando a seleção da fonte. Captura de outro app continua dependente do Android e do player.

Os estados e a configuração ficam em `data/`; modelos locais continuam fora do pacote. O atualizador usa manifesto SHA-256 e backup em `data/update-backups/`. O ZIP não inclui chaves de transmissão, `.env`, tokens de ponte, histórico de espectadores reais ou modelos de IA.

O supervisor reage à morte do processo Node, com limite de reinícios; ele não consegue reiniciar o Termux se o Android encerrar o aplicativo inteiro. Diagnóstico físico continua pendente.
