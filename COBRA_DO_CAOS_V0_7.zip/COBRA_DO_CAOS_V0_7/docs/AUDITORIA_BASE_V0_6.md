> Auditoria da V0.6, anterior às alterações. Para o resultado implementado, consulte EVOLUCAO_V0_7.md.

# Cobra do Caos — diagnóstico e prévia de retenção

Base analisada: V0.6.0. Data: 23 de novembro de 2026, horário de Brasília.

## Resultado

As sugestões de simplificar o primeiro contato e criar acontecimentos intermediários são pertinentes. A causa de pouca audiência ainda não foi demonstrada em LIVE real. Não há garantia de alcance ou receita a partir destas mudanças.

A V0.6 publicada foi preservada. A cópia `/workspace/cobra-retencao-preview` contém apenas uma experiência de interface: chamada HERÓI/VILÃO, ranking compacto, dicas alternadas, regras expansíveis e marcas visuais na barra. Não é uma nova versão pronta para instalação. O conceito gráfico com mascotes novos também permanece separado.

## O que o código confirma ou corrige

| Observação recebida | Verificação | Consequência |
| --- | --- | --- |
| Canhão leva 45 s por pessoa na fila | `public/park-rules.js`: 45 s é a recarga individual do comando grátis. Cada passeio leva 7 s: preparação 1,5 s, voo 3 s e celebração 2,5 s. | Não reduzir uma suposta duração de 45 s. Medir espera e deixar a posição visível. |
| Fila pode frustrar | `server/park.mjs`: oito aguardando e um ativo; presentes entram antes dos pedidos grátis, sem interromper o voo atual. | Sem novos presentes, oito na fila representam cerca de 56 s até a conclusão do último, além do passeio em andamento. Novas prioridades podem adiar os pedidos grátis; falta garantia contra espera excessiva. |
| Rodada demora aproximadamente sete minutos | Há 504 casas, início com oito e intervalo mínimo de crescimento de 900 ms. Os 446,4 s de orçamento nominal não incluem procura de comida, passos discretos nem espera por espaço na cauda. | A estimativa não representa a duração da partida. A fase final é um gargalo. |
| Faltam efeitos sonoros | `public/audio.js`, `public/assets/sfx/eat.wav`: já existem sons de comida, explosão, proteção, chegada, canhão e pouso. | Melhorar variedade e mixagem, preservando os efeitos existentes. |
| Existe apenas uma trilha | Há uma trilha original incluída, mas `public/playlist.js` já aceita até 32 arquivos, com seleção aleatória. | Diferenciar repertório incluído de capacidade da playlist. Não usar música de artista sem verificar os direitos necessários. |
| Voz é apenas sintética e não varia | Existem 28 falas neurais prontas e integração opcional Qwen/Piper para respostas livres. | Variar roteiro e reduzir repetição; voz e IA continuam independentes do motor. |
| Robô vem do Three.js | O arquivo RobotExpressive é um recurso CC0 dos exemplos do Three.js; o jogo continua usando Babylon.js. | Um mascote próprio diferencia o produto, mas exige trabalho de arte e animação. Nenhum modelo foi substituído nesta prévia. |
| Missão de likes pode falhar sem identificação | O motor aceita likes agregados para metas coletivas, mas não inventa a autoria dos likes. A fuga individual depende do ID do usuário. | Exibir a limitação quando ocorrer; uma rosa ou dez comentários continuam sendo alternativas de fuga. |

## Simulação da duração

Motor atual, passos de relógio de 50 ms, três sementes determinísticas por cenário, sem bombas. O arquivo `COBRA_AUDITORIA_DURACAO.json` contém todos os resultados e tempos de 25%, 50%, 75% e 100%.

| Cenário | Tempo simulado até 504 casas |
| --- | --- |
| Créditos de crescimento mantidos artificialmente disponíveis | 16 min 47 s a 18 min 48 s |
| Somente comida ambiente, sem público | 36 min 23 s a 39 min 52 s |

Isso não é benchmark de CPU, renderização ou Realme GT3, nem previsão garantida de LIVE. A disponibilidade artificial de créditos serve para separar o problema de comida do problema do piloto.

Em `server/engine.mjs`, `step()` evita crescer quando a próxima casa é a cauda ocupada. Em `server/pilot.mjs`, o piloto preserva um caminho seguro. Ao se aproximar da lotação, pode precisar de muitas voltas para abrir espaço. Retirar essa proteção diretamente pode criar colisões; apenas acelerar o relógio não resolve a estrutura do problema.

## Outra falha visual observada

Na captura de uma posição central, a plataforma elevada e o robô central ficaram entre a câmera e a cabeça da cobra. É uma obstrução real na prévia local, não uma falha confirmada no aparelho. Arquivos: `public/park-environment.js`, `public/cinematic-world.js` e `public/stage-show.js`.

Uma próxima implementação deve testar a linha de visão e ajustar o ângulo ou a transparência dos objetos que cobrem a cobra. A distância atual de acompanhamento é 16 unidades e a de agradecimento, 14. O usuário já pediu uma distância confortável; aproximar indiscriminadamente pode piorar o enquadramento.

## Ordem recomendada de implementação

1. **Clareza e visibilidade:** finalizar o HUD da prévia; manter todos os controles no painel; resolver obstrução da cabeça; verificar também o compositor RTMP, que desenha uma interface própria em `public/studio.js`.
2. **Ritmo da rodada:** adicionar marcos de 25%, 50% e 75% como eventos reais, salvos por rodada, sem repetir ao encolher e crescer ou reiniciar o servidor. A prévia atual mostra apenas as marcas visuais. Para encurtar partidas, testar uma meta intermediária ou um perfil para novas rodadas, preservando o tabuleiro e o progresso existente. Alterações no piloto precisam manter os testes de segurança.
3. **Fila justa:** mostrar posição e estimativa, medir espera real e limitar quantos presentes prioritários passam antes de um pedido grátis. Não executar oito voos simultâneos sem antes avaliar câmera, CPU e clareza.
4. **Retenção e clipes:** hall da fama diário/semanal, reconhecimento de retorno, eventos surpresa limitados e destaque para presentes grandes. Replays exigem um histórico limitado e devem ser identificados como replay, sem duplicar recompensas ou alterar o relógio da partida.
5. **Identidade artística e áudio:** mascote próprio e repertório original/licenciado; ajustar volume de voz/música/efeitos. A troca de modelo não foi aplicada.

Uma barra Herói × Vilão com contagem regressiva precisa de uma regra explícita para vitória, duração e recompensa. Os poderes atuais são cumulativos; desenhar uma barra não cria um confronto equilibrado.

## Evidências, backup e reversão

- Testes existentes: **81 aprovados**, inclusive integração HTTP, persistência, retomada de voo, identidade e fila de voz. Primeiro ensaio no sandbox falhou em três testes por bloqueio de sockets locais (`EPERM`); a execução com portas locais liberadas passou integralmente. Não foi necessário alterar os testes.
- Registro: `COBRA_AUDITORIA_TESTES.log`.
- Validação visual separada: `COBRA_HUD_PREVIA_TESTES.json`. Verifica controles e expansão/recolhimento em quatro tamanhos de tela no Chromium Linux.
- Backup completo preservado: `/workspace/artifacts/COBRA_DO_CAOS_V0_6.zip`.
- SHA-256 conferido: `da3309d79e07c0cf5a4ace2a204b7e61ea6a285b5d1af4ce44731673a91fed5f`.
- Nenhum arquivo do motor da V0.6 foi alterado. Para descartar a experiência, basta não utilizar a pasta de prévia. Não há migração de dados a reverter.

## Pendências e limites

Não foram executados LIVE real, medição de distribuição do TikTok, teste prolongado no Realme GT3, diagnóstico do encerramento do Termux no celular ou captura física do GreenTube/Bluetooth. O supervisor existente limita reinícios, mas não recupera o encerramento de todo o aplicativo pelo Android. A causa da parada precisa dos logs da sessão correspondente.

Nenhuma automação de curtidas reais foi adicionada. Os participantes das prévias são DEMO e os dados preparados não pertencem a espectadores reais.
