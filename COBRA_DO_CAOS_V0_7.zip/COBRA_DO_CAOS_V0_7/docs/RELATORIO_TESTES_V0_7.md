# Registro de testes da V0.7

- 94 testes unitários e de integração aprovados; suíte anterior preservada.
- Browser: quatro tamanhos, HUD compacto/expandido, sete ZigBots, retratos, modelo anterior preservado, linha de visão do palco, playlist e replay sem alterar placar. Registro V07_BROWSER_CHECK.json.
- Voz: Piper real com reprodução no Chromium, nível de áudio medido, movimento de boca, prioridade e retomada por toque. Texto HTTP controlado; não mede o Qwen real. Registro V07_VOICE_AND_PACING_CHECK.json.
- RTMP: receptor local recebeu H.264/AAC 720×1280; 11,337 s, 3.972.966 bytes. Registro V07_STUDIO_CHECK.json. Não foi envio ao TikTok.
- Carga: duas horas simuladas, 144.000 ticks; filas e corpo dentro dos limites. 1.500 perfis e 502 passeios finalizados; nenhuma rodada completa nesse cenário de sabotagens. Registro V07_SOAK_ENGINE.json. Não são duas horas reais no Android; tempo de execução de CPU compartilhada não é comparável a benchmark dedicado.
- Empacotamento: manifesto SHA-256 e CRC do ZIP. Instalação limpa, atualização, recuperação de voo após SIGKILL e reversão são verificados no ZIP final e registrados no arquivo de validação entregue ao lado do download.

Falhas corrigidas durante a revisão: anúncio de duelo salvava o placar anterior ao reset (risco de repetir prêmio após reinício); migração atribuía pontos históricos ao hall do dia. Ambos têm testes específicos. O primeiro ensaio HTTP sem liberação de sockets falhou por EPERM do ambiente; não foi falha do jogo.

Pendentes: LIVE real, GT3 prolongado, captura física de GreenTube/Bluetooth e causa do encerramento do Termux no telefone. O APK de captura foi mantido.
