# V0.7 — etapas aplicadas

## Interface e visibilidade

O primeiro convite agora é COMENTE HERÓI OU VILÃO. As regras completas e fotos dos presentes continuam em REGRAS + e nos controles. O Top mostra três pessoas no modo compacto e seis ao expandir. No retrato 430×932, o painel inferior mediu aproximadamente 123 px recolhido e 230 px expandido no Chromium.

A cobra fica no acompanhamento por 20 dos 44 segundos do percurso automático, contra 12 anteriormente. O raio do acompanhamento passa de 16 para 15, mantendo distância confortável. O corpo tem raio visual de 0,60 em vez de 0,53, sem alterar a colisão na grade. Comer e receber explosão movimentam mandíbula, escala da cabeça e sobrancelhas. O palco central e o mascote ficam quase transparentes quando obstruem a linha entre a câmera e o rosto; voltam ao normal em seguida.

Arquivos: `public/show-ui.js`, `public/show-ui.css`, `public/occlusion.js`, `public/cinematic-world.js`, `public/park-layout.js`, `public/app.js`.

## Ritmo e partidas

Marcos de 25%, 50% e 75% emitem aviso, som e fala. São salvos por rodada e não se repetem se bombas diminuírem o comprimento, nem após reiniciar o servidor.

A auditoria confirmou que 900 ms não prevê a duração da partida: a cobra também precisa de comida e de espaço seguro na cauda. Na V0.6, três sementes sem bombas levaram 16m47s–18m48s com créditos sempre disponíveis e 36m23s–39m52s só com comida ambiente. São simulações, não tempos garantidos de LIVE.

Por isso há metas opcionais de 126, 252, 378 e 504 segmentos. A escolha vale só para a próxima rodada; a partida atual, o cenário 18×28, o progresso e as pontuações continuam. O padrão compatível continua 504. Uma meta curta não significa preencher fisicamente todas as casas: o HUD mostra META DA RODADA, e a fala de vitória também distingue isso.

Arquivos: `server/engine.mjs`, `server/show-system.mjs`, `server/index.mjs`, `public/show-ui.js`.

## Canhão

O passeio continua com sete segundos e recarga individual de 45 segundos para o comando grátis. Presentes continuam prioritários, mas no máximo dois passeios prioritários são atendidos antes de um pedido grátis que já aguarda. A sequência justa, os limites e a prioridade atual sobrevivem a reinício. Posição e estimativa usam essa ordem; novos pedidos podem mudar a estimativa.

Arquivo: `server/park.mjs`. A gaiola e o poder normal do presente continuam independentes do passeio.

## Retorno e hall da fama

Há hall do dia e dos últimos sete dias, com dias pelo horário de Brasília. A pontuação acompanha os pontos existentes do parque, sem conceder pontos em replay. O histórico fica separado entre DEMO e LIVE e é salvo localmente.

Visitas não são inferidas como lives diferentes: contam quando há retorno após pelo menos 20 minutos sem interação. Reconectar rapidamente não concede outra visita. Títulos: Visitante, De casa (2), Turma do Zig (5) e Lenda do parque (10). As cores dos ZigBots e o emblema variam com o nível de retorno. O histórico é limitado a 1.500 perfis; perfis antigos podem ser substituídos ao atingir esse limite.

Zig dá boas-vindas de retorno. Com voz local disponível e fila livre, o nome entra na síntese. Sem essa condição, usa a fala pronta e identifica a pessoa na legenda; não promete pronúncia de nomes desconhecidos.

## Eventos e duelo

Duelo de dois minutos, baseado nos pontos das ajudas e sabotagens que o jogo já contabiliza: vitória dos heróis dá três comidas; vitória dos vilões dá duas bombas; empate não dá prêmio. O placar da disputa zera para o próximo duelo. Likes sem identificação não recebem autoria inventada.

A cada 150 segundos de jogo, os eventos se alternam: comida dourada (três créditos de crescimento; se não houver espaço visível, créditos entram na fila), chuva de três bombas, caos de até 30 segundos (comida e bombas enviadas pelo chat em dobro) e chefão com energia 50. Pontos dos heróis reduzem essa energia. Vitória dá quatro comidas; tempo esgotado dá duas bombas. Os limites anteriores de comida, bombas, créditos e efeitos continuam valendo. Bombas extras podem prolongar a rodada; os eventos são opcionais.

Eventos, duelo e replay podem ser desligados em LIVE → Eventos e replays. O relógio é lógico e pausa com o jogo. Evento ativo, prazo e resultado sobrevivem a reinício sem reaplicar recompensas. Histórico de destaques limitado a 24 registros.

## Clipes e presentes grandes

Fugas, banquetes, pousos e mortais podem disparar um replay visual curto, com faixa REPLAY e indicação de placar ao vivo. O cliente guarda até 16 amostras recentes; a apresentação usa até dez e as reproduz mais devagar. A lógica do servidor continua. Isso não é uma gravação exportada nem um replay de áudio. Presentes interrompem o replay; há intervalo de 22 s e o modo de movimento reduzido impede novos replays.

Presentes de resgate, mordida ou efeito aplicado de pelo menos oito unidades recebem faixa maior com nome, presente e quantidade, além do agradecimento e cor da cobra. A lógica mantém os poderes originais.

Arquivos: `public/clip-replay.js`, `public/show-ui.js`, `public/studio.js`. O compositor RTMP também mostra o gancho, a disputa e a identificação de replay.

## Arte e áudio

Sete ZigBots procedurais próprios foram adicionados, com capacete, visor, antenas, retrato e movimentos no relógio de batida. Não dependem de um novo modelo baixado. O RobotExpressive anterior, seus créditos CC0 e suas animações permanecem selecionáveis. O fallback anterior permanece se o recurso do modelo não carregar.

Agora são 38 falas prontas e três instrumentais originais. As duas faixas novas foram geradas por síntese, sem gravações ou samples comerciais, e podem ser reproduzidas por `tools/make-extra-music.py`. A biblioteca é adicionada pelo botão da aba Música; arquivos do operador e captador continuam disponíveis.

Arquivos: `public/zigbot.js`, `public/stage-show.js`, `server/host.mjs`, `tools/voice-lines.json`, `tools/make-extra-music.py`.

## Validação e limites

Os registros estão em `docs/unit-tests.log`, `V07_BROWSER_CHECK.json`, `V07_VOICE_AND_PACING_CHECK.json`, `V07_STUDIO_CHECK.json` e `V07_SOAK_ENGINE.json`. A instalação/atualização/reversão do ZIP é verificada separadamente e publicada com o pacote.

Não houve LIVE real ou teste prolongado no Realme GT3. O texto do teste de voz é uma resposta HTTP controlada; o áudio Piper e a reprodução são reais. O RTMP foi enviado a um receptor local, não ao TikTok. A simulação de duas horas não é uma execução de duas horas reais no Android. A distribuição e a retenção de audiência ainda precisam ser medidas em LIVE.

Para usar a meta curta imediatamente, escolha a meta e use **Iniciar rodada com a nova meta**. Esse botão pede confirmação, pois reinicia o corpo e os créditos da rodada atual. Mantém pontos, ranking e missões da gaiola.
