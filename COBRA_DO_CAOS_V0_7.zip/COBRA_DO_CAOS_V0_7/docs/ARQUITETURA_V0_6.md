# Módulos V0.6

A arquitetura V0.5 foi preservada. Consulte `ARQUITETURA_V0_5.md` para servidor, eventos, persistência, áudio e captura.

- `public/show-motion.js`: relógio musical independente do FPS. Usa ataques reais para ancorar a fase, ignora subdivisões como novo tempo principal, expira sinal e calcula trajetórias de chegada e poses leves.
- `public/stage-show.js`: carrega um AssetContainer GLB e cria sete instâncias com materiais próprios. Grupos de animação são amostrados pelo relógio musical; não executam um loop de dança sem sinal. Retratos reutilizam o atlas e acompanham trocas de liderança. Erro de carregamento conserva os avatares leves.
- `public/show-environment.js`: palco, caixas de som, luminárias, plantas e grade texturizada. Renderiza com recursos já usados no Babylon.js.
- `server/park.mjs`: acrescenta início/tempo da chegada aos registros. Perfis e aliases continuam limitados; até 128 viagens entram na seleção visual. `server/cage.mjs` recebe o atraso de apresentação antes de criar o prazo de queda.
- `public/park-stage.js`: decide o papel visual do ator, sem completar missões por aparência. Chegada, canhão, comida, palco e circulação têm precedência definida. O palco é visual e pode mostrar um líder ainda com missão pendente.
- `server/host.mjs`: retorno explícito de falhas, contadores e prazo de texto de 25 s. Saudações têm espera por usuário; fila continua limitada a quatro perguntas. O modelo apenas produz texto.
- `public/app.js`: separa playlist e captador, preserva respostas na reprodução e mostra diagnóstico. A aba Apresentador detecta serviços por HTTP local; não instala modelos.
- `scripts/diagnose.mjs`: consulta apenas estado/saúde da instância local. Não imprime chaves, texto das conversas nem o manifesto de modelos do usuário.

A fonte de entrada do TikTok e o envio de vídeo continuam independentes. Entradas sem evento não podem ser inventadas. Uma IA pronta só pode responder se houver comentário encaminhado, conversa ativada, serviço disponível e reprodução autorizada no navegador. O diagnóstico separa essas condições.
