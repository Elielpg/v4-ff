# Validação V0.6

- A suíte de regressão foi mantida. Os testes de banquete passaram a aguardar o prazo real da apresentação de chegada, preservando as verificações de quantidade e donos.
- Novos testes cobrem chegada, retomada, pausa, fase musical, contratempos, saudações individuais e retorno de erro da IA. Resultado em `unit-tests.log`.
- `V06_BROWSER_CHECK.json`: GLB carregado, sete modelos, carrinho, câmera de chegada, canhão, palco, animação mudando de quadro, mortal, parada após silêncio, quatro tamanhos de tela, arco-íris e captura.
- `V06_VOICE_AND_PACING_CHECK.json`: comentário pela API de eventos até resposta com síntese Piper real, sinal de áudio medido e presente incapaz de interromper a resposta. O texto vem de um serviço controlado, não de benchmark do Qwen. O teste também exercita detectar e conectar um serviço local disponível.
- `V06_STUDIO_CHECK.json`: imagem H.264 e áudio AAC recebidos por servidor RTMP local, gravação local e jogo mantido após encerramento do codificador.
- `V06_SOAK_ENGINE.json`: duas horas simuladas de lógica acelerada, com filas e memória limitada; não são duas horas físicas de LIVE.

Os relatórios V05 e anteriores são históricos. A instalação limpa, atualização e reversão do ZIP final são verificadas separadamente por `tools/release-check.mjs`. O relatório externo `COBRA_DO_CAOS_V0_6_VALIDACAO.json` identifica o arquivo final pelo SHA-256 sem criar autorreferência dentro do ZIP.

Pendente: sessão prolongada no Realme GT3, temperatura, FPS efetivo com Qwen/Piper/captura simultâneos, captura do GreenTube/Bluetooth e eventos TikTok reais. Não houve conexão a uma LIVE real nem captura física Android nesta validação. O supervisor continua sem poder recuperar o encerramento de todo o Termux pelo Android.
