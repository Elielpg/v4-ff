# Pendências e próximos testes

- **LOCAL-010 — Termux encerra a execução:** causa física ainda não identificada. Supervisor e logs existentes continuam; recuperação após SIGKILL do servidor é testável, mas não equivale ao encerramento de todo o Termux pelo Android. Precisamos de `logs/server.jsonl`, logs do supervisor e horário da parada da sessão real. Não declarar resolvido no GT3.
- **Rodada completa pode ser longa:** a segurança da cauda é preservada. Marcos, eventos e metas curtas opcionais melhoram o ritmo; o piloto não foi substituído nem há promessa de tempo fixo para completar 504 casas. Bombas e chefão podem prolongar a partida.
- **Curtidas individuais:** dependem de o conector fornecer identidade. Likes sem ID ajudam a meta coletiva; não abrem uma gaiola por atribuição artificial. Uma rosa ou dez comentários continuam sendo alternativas.
- **Qwen e Piper no celular:** dependem dos serviços locais ativos. Um teste de texto controlado não comprova raciocínio ou latência do Qwen real. Síntese de nomes e pronúncia precisam de avaliação humana com os arquivos gerados no aparelho.
- **Retorno e títulos:** o intervalo de 20 minutos é uma aproximação local, não uma identificação confiável de uma nova transmissão TikTok. DEMO e LIVE são separadas; limite de 1.500 perfis.
- **Captura externa e áudio Bluetooth:** continuam dependentes das permissões Android e do aplicativo de música. Não houve teste físico de GreenTube/Bluetooth. O APK anterior foi preservado, sem recompilação.
- **Replays:** são visuais e curtos; não exportam um arquivo de vídeo por evento. Mudanças de cena podem parecer bruscas ao voltar ao estado ao vivo. É possível desativá-los.
- **Carga gráfica:** mascotes próprios, texturas, sombras e captura precisam de teste térmico prolongado no GT3. Perfis leve/equilibrado/detalhado e movimento reduzido continuam. Não apresentar FPS da GPU de software como resultado do celular.
- **Balanceamento:** disputar por pontos, eventos automáticos e prioridades de presentes ainda precisam de teste com público real. Não há promessa de alcance, receita ou aumento de audiência.

Teste recomendado no aparelho: 15 minutos em modo DEMO com meta curta, música e voz; depois 15 minutos de LIVE com poucos participantes; em seguida sessão longa anotando horário, temperatura e ocorrência de pausas. Parar a transmissão antes de atualizar ou reverter.

No cenário de carga com eventos automáticos, 1.500 perfis e muitas sabotagens, a simulação de duas horas não terminou uma rodada completa. Isso mantém o balanceamento como pendência. Metas curtas e os controles para desligar eventos permitem testar sessões mais rápidas sem modificar a colisão segura.
