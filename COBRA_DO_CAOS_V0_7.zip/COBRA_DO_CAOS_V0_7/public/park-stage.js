import {CageStage} from './cage-stage.js';
import {SCENE} from './scene-design.js';
import {cannonPose,coasterPose,visitorPose,podiumPose} from './park-layout.js';
import {StageShow} from './stage-show.js';
import {arrivalPose,dancePose} from './show-motion.js';
const B=window.BABYLON;
export class ParkStage extends CageStage{
 constructor(w){super(w);this.show=new StageShow(w);}
 extraPeople(s){return [...(s.park?.visitors||[]),{id:'zig-show-host',name:'Zig · Show do centro',seed:10}];}
 updateExtras(s,needed){const active=s.park?.active?.user,top=s.park?.top||[];for(const p of this.extraPeople(s).sort((a,b)=>(b.id===active)-(a.id===active))){if(!needed.has(p.id)&&needed.size>=SCENE.actorLimit)continue;needed.add(p.id);const a=this.actor(p);a.person={...a.person,...p};a.top=top.findIndex(x=>x.id===p.id);if(a.kind==='caged'&&!s.cage.members.some(x=>x.id===p.id))a.kind='park';if(a.kind==='food'&&a.feast?.readyAt>s.serverTime-350)continue;
   // The social park is a visual layer. Cage membership and escape progress stay authoritative.
   if(!['caged','escaped'].includes(a.kind))a.kind='park';a.cannon=p.id===active;
  }for(const a of this.actors.values())if(a.id!==active)a.cannon=false;
 }
 poseActor(a,{now,clock}){const park=this.state.park;if(!park)return null;if(a.id==='zig-show-host')return {x:0,y:3.32,z:0,model:this.show.status==='ready',dance:dancePose(this.show.sample()),snap:true};const seconds=(park.time+(this.state.running?Math.max(0,now-this.w.stateAt):0))/1000;
  const arrival=a.person.arrival;if(arrival){const elapsed=arrival.at?clock-arrival.at:park.time-arrival.started+(this.state.running?Math.max(0,now-this.w.stateAt):0),p=arrivalPose({elapsed,nowSeconds:now/1000,car:arrival.car,destination:a.kind==='escaped'||a.person.state==='escaped'?{x:7,y:0,z:-27}:this.cagePos(a.index||0)});if(p){a.arrivalStage=p.stage;return p;}}a.arrivalStage=null;
  if(a.cannon&&park.active){const elapsed=park.active.elapsedMs+(this.state.running?Math.max(0,now-this.w.stateAt):0),p=cannonPose(elapsed);a.parkPose=p;return {...p,yaw:p.phase==='flight'?p.spin:Math.PI/2-this.w.camera.alpha,snap:true,celebrate:p.phase!=='prepare'};}
  a.parkPose=null;if(a.kind==='food')return null;
  if(a.top>=0&&a.top<6){const p=podiumPose(a.top);return {...p,dance:dancePose(this.show.sample(),a.design.seed),model:this.show.status==='ready',yaw:Math.PI/2-this.w.camera.alpha};}
  if(a.kind==='caged')return null;
  if(a.kind==='escaped')return null;const seed=a.design.seed;
  if(seed%4===0){const index=seed%8,p=coasterPose(now/1000,index);return {...p,y:p.y+.1,seated:true,snap:true};}
  const p=visitorPose(seed,seconds);return {...p,walk:true,yaw:Math.PI/2-this.w.camera.alpha};
 }
 frame(dt,now,clock,mode){super.frame(dt,now,clock,mode);const top=[...this.actors.values()].filter(a=>a.top>=0&&a.top<6&&!a.arrivalStage&&!a.cannon&&a.kind!=='food').sort((a,b)=>a.top-b.top);let central=this.central;if(!central){const p={id:'zig-show-host',name:'Zig · Show do centro',seed:10};this.central=central=this.actor(p);central.kind='show';central.top=-1;}central.pos=new B.Vector3(0,3.32,0);central.face.setEnabled(false);this.show.frame(now,top,central);this.afterFrame=now;}
}
