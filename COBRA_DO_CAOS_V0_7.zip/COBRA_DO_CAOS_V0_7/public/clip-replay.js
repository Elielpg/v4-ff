export class ClipReplay{
 constructor({world,banner,onStop=()=>{}}){this.world=world;this.banner=banner;this.onStop=onStop;this.frames=[];this.active=false;this.last=0;this.cooldown=0;}
 note(s){this.latest=s;if(!s.running||performance.now()-this.last<180)return;this.last=performance.now();const frame={...s,body:[...s.body],owners:[...s.owners],foods:s.foods.map(f=>({...f})),bombs:s.bombs.map(f=>({...f})),actions:[]};this.frames.push(frame);if(this.frames.length>16)this.frames.shift();}
 start(title){if(this.active||this.world.reduceMotion||Date.now()<this.cooldown||this.frames.length<6)return false;this.active=true;this.clip=this.frames.slice(-10);this.index=-1;this.at=performance.now();this.cooldown=Date.now()+22000;this.banner.textContent='REPLAY · '+title+' · PLACAR AO VIVO';this.banner.hidden=false;return true;}
 frame(now){if(!this.active)return;const index=Math.floor((now-this.at)/320);if(index>=this.clip.length){this.stop();return;}if(index!==this.index){this.index=index;this.world.update({...this.clip[index],running:false});}}
 stop(){if(!this.active)return;this.active=false;this.banner.hidden=true;if(this.latest)this.world.update(this.latest);this.onStop();}
 reset(){this.stop();this.frames=[];this.last=0;this.cooldown=0;}
}
