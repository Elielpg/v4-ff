import {coasterPose} from './park-layout.js';
export const ARRIVAL_MS=9000;
export class DanceClock{
 constructor(){this.reset();}
 reset(){this.period=500;this.anchor=0;this.last=-Infinity;this.beats=0;}
 note({interval,bpm,at,strength=1}={},now=Date.now()) {const time=Number.isFinite(at)?at:now;if(time<this.last-500)return;const period=Number(interval)||(bpm?60000/bpm:0);if(period>=250&&period<=1200)this.period=period;const stale=time-this.last>2500;this.last=time;this.strength=strength;if(stale){this.anchor=time;this.beats=0;}else if(time-this.anchor>=this.period*.7){this.beats+=Math.max(1,Math.round((time-this.anchor)/this.period));this.anchor=time;}}
 sample(now=Date.now()){const active=now-this.last<2500;if(!active)return {active:false,phase:0,cycle:0,kick:0,period:this.period};const position=(now-this.anchor)/this.period,phase=((position%1)+1)%1;return {active:true,phase,cycle:Math.floor(position+this.beats),kick:Math.exp(-phase*8),period:this.period,steps:position+this.beats};}
}
export function arrivalPose({elapsed,nowSeconds,car=0,destination}){if(elapsed>=ARRIVAL_MS||elapsed<0)return null;const p=coasterPose(nowSeconds,car);
 if(elapsed<6000)return {...p,y:p.y+.1,seated:true,snap:true,arrival:true,stage:'ride'};
 const t=Math.min(1,(elapsed-6000)/3000),a=coasterPose(nowSeconds-(elapsed-6000)/1000,car);
 return {x:a.x+(destination.x-a.x)*t,y:a.y+(destination.y-a.y)*t+Math.sin(t*Math.PI)*5,z:a.z+(destination.z-a.z)*t,yaw:Math.PI*.5,arrival:true,snap:true,celebrate:true,stage:'drop'};
}
export function dancePose(beat,seed=0){if(!beat.active)return {sway:0,bob:0,arm:0,foot:0,flip:0};const p=beat.phase*Math.PI*2;return {sway:Math.sin(p/2+seed%2*Math.PI)*.14,bob:Math.sin(p)*.055,arm:Math.sin(p+seed%3)*.23,foot:Math.sin(p/2)*.22,flip:beat.cycle%16===0?beat.phase*Math.PI*2:0};}
