"""Two original generated instrumentals; no samples, recordings or external compositions."""
from pathlib import Path
import subprocess,tempfile,wave
import numpy as np
root=Path(__file__).resolve().parents[1]
sr=22050
for name,bpm,notes in [('zig-neon-140',140,[45,48,52,55,43,47,50,52]),('parque-110',110,[48,52,55,59,45,48,52,55])]:
 beat=60/bpm;n=int(beat*64*sr);audio=np.zeros(n);rng=np.random.default_rng(bpm)
 def add(at,sound):
  i=int(at*sr);m=min(len(sound),n-i)
  if m>0:audio[i:i+m]+=sound[:m]
 for b in range(64):
  t=np.arange(int(sr*.32))/sr
  if b%4 in (0,2):add(b*beat,.32*np.sin(2*np.pi*(42*t+1.8*(1-np.exp(-t/.025))))*np.exp(-t*18))
  if b%4 in (1,3):add(b*beat,.075*rng.standard_normal(len(t))*np.exp(-t*30))
  for sub in [0,.5]:
   h=np.arange(int(sr*.045))/sr;add((b+sub)*beat,.012*rng.standard_normal(len(h))*np.exp(-h*90))
  f=440*2**((notes[(b//2)%8]-69)/12);t=np.arange(int(sr*beat*.9))/sr;env=np.minimum(1,t/.015)*np.exp(-t*5)
  add(b*beat,.12*np.tanh(1.5*np.sin(2*np.pi*f*t))*env)
  if b%2==0:
   for ratio,gain in [(2,.035),(3,.016)]:add(b*beat,.55*gain*np.sin(2*np.pi*f*ratio*t)*np.exp(-t*7))
 audio*=min(1,.72/max(.001,np.max(np.abs(audio))))
 with tempfile.TemporaryDirectory() as temp:
  wav=Path(temp)/'loop.wav'
  with wave.open(str(wav),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes((audio*32767).astype('<i2').tobytes())
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-c:a','libmp3lame','-b:a','128k',str(root/'public/assets/music'/f'{name}.mp3')],check=True)
 print(name,round(n/sr,2),'s',flush=True)
