import {writeFile} from 'node:fs/promises';
import path from 'node:path';import {pathToFileURL} from 'node:url';
const engineURL=process.argv[2]?pathToFileURL(path.resolve(process.argv[2])):new URL('../server/engine.mjs',import.meta.url);
const {SnakeEngine}=await import(engineURL.href);const {RULES,VERSION}=await import(new URL('../public/rules.js',engineURL).href);
const results=[];
for(const abundant of [true,false])for(const initialSeed of [41,73,113]){
 let now=1000000,seed=initialSeed;
 const e=new SnakeEngine({now:()=>now,random:()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}});
 if(e.show){e.show.config.surprises=false;e.show.config.duel=false;}
 let ticks=0;const milestones=[];
 while(e.phase==='playing'&&ticks<120000){
  if(abundant)while(e.growth.length<240)e.growth.push(null);
  now+=50;e.tick();ticks++;
  for(const percent of [25,50,75,100])if(e.body.length/e.pilot.size*100>=percent&&!milestones.some(m=>m.percent===percent))milestones.push({percent,seconds:(now-1000000)/1000});
 }
 results.push({scenario:abundant?'continuous-growth-credits-no-bombs':'ambient-food-only-no-public',seed:initialSeed,won:e.result?.won??false,length:e.body.length,simulatedSeconds:(now-1000000)/1000,milestones});
}
const report={base:VERSION,automaticEvents:false,engineModule:engineURL.pathname,cols:RULES.cols,rows:RULES.rows,growthMs:RULES.growthMs,nominalGrowthBudgetSeconds:(RULES.cols*RULES.rows-RULES.startLength)*RULES.growthMs/1000,results,note:'Simulação determinística em passos de 50 ms, sem explosões ou público real. Créditos mantidos artificialmente no primeiro cenário para isolar o piloto. Não mede CPU/FPS/temperatura, nem garante duração em LIVE.'};
await writeFile(new URL('../docs/AUDITORIA_DURACAO_'+VERSION.replaceAll('.','_')+'.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
