import ctypes as c
import hashlib
import io
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import wave
from unittest import mock

sys.path.insert(0, str(Path("scripts/local-ai").resolve()))
import clone_voice
import clone_config
import clone_models


def reference(filename, seconds=4, channels=2, rate=16000):
    import array
    pcm = array.array("h", (round(9000 * math.sin(i / channels / rate * 300 * math.tau)) for i in range(int(seconds * rate * channels))))
    with wave.open(str(filename), "wb") as wav:
        wav.setnchannels(channels); wav.setsampwidth(2); wav.setframerate(rate); wav.writeframes(pcm.tobytes())


class CloneTests(unittest.TestCase):
    def test_reference_is_local_mono_24k_and_does_not_select_clone(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = root / "source.wav"; reference(source)
            manifest = {"textModel": "existing.gguf", "voiceModel": "piper.onnx"}
            (root / "install.json").write_text(json.dumps(manifest))
            clone_config.configure(root, "reference", source)
            with wave.open(str(root / "cloning/reference.wav")) as wav:
                self.assertEqual(wav.getnchannels(), 1); self.assertEqual(wav.getframerate(), 24000); self.assertEqual(wav.getnframes(), 96000)
            self.assertEqual(json.loads((root / "install.json").read_text()), manifest)
            with self.assertRaises(ValueError):
                clone_config.configure(root, "use")
            reference(source, seconds=1)
            with self.assertRaises(ValueError):
                clone_voice.configure_reference(source, root / "short.wav")

    def test_selection_requires_preview_of_current_reference_and_preserves_piper(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = root / "source.wav"; reference(source)
            original = {"textModel": "chat.gguf", "voiceModel": "piper.onnx"}
            (root / "install.json").write_text(json.dumps(original)); clone_config.configure(root, "reference", source)
            for name in ["qwen3-tts.cpp/build/libqwen3tts.so", "cloning/models/qwen3-tts-0.6b-f16.gguf", "cloning/models/qwen3-tts-tokenizer-f16.gguf", "cloning/preview.wav"]:
                p = root / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b"fixture")
            (root / "cloning/preview.json").write_text(json.dumps({"referenceSha256": hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest()}))
            clone_config.configure(root, "use")
            current = json.loads((root / "install.json").read_text()); self.assertEqual(current["voiceEngine"], "qwen3-clone"); self.assertEqual(current["voiceModel"], original["voiceModel"])
            clone_config.configure(root, "piper"); self.assertEqual(json.loads((root / "install.json").read_text())["textModel"], "chat.gguf")
            clone_config.configure(root, "reference", source); self.assertFalse((root / "cloning/preview.json").exists())

    def test_catalog_failure_happens_before_weight_download(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(clone_models.shutil, "disk_usage", return_value=mock.Mock(free=10 * 1024**3)), mock.patch.object(clone_models, "metadata", return_value={"sha": "a" * 40, "siblings": []}), mock.patch.object(clone_models, "download") as download:
            with self.assertRaises(ValueError):
                clone_models.install(Path(directory))
            download.assert_not_called()

    def test_ctypes_abi_portuguese_embedding_cache_pcm_and_cleanup(self):
        source = r'''
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
typedef struct {int32_t max_audio_tokens;float temperature,top_p;int32_t top_k,n_threads;float repetition_penalty;int32_t language_id;} Params;
typedef struct {const float *samples;int32_t n_samples,sample_rate;} Audio;
static int encoded=0,freed=0,language=0;
void *qwen3_tts_create(const char *p,int32_t n){return (void*)1;}
void qwen3_tts_destroy(void *p){}
void qwen3_tts_default_params(Params *p){memset(p,0,sizeof(*p));}
int32_t qwen3_tts_extract_embedding_file(void*p,const char*r,float*out,int32_t n){encoded++;out[0]=.3f;return 1;}
Audio *qwen3_tts_synthesize_with_embedding(void*p,const char*t,const float*e,int32_t n,const Params*par){language=par->language_id;Audio *a=calloc(1,sizeof(*a));float *s=calloc(480,sizeof(float));for(int i=0;i<480;i++)s[i]=i%2?.2f:-.2f;if(!strcmp(t,"nan"))s[0]=NAN;a->samples=s;a->n_samples=480;a->sample_rate=24000;return a;}
void qwen3_tts_free_audio(Audio*a){freed++;free((void*)a->samples);free(a);}
const char *qwen3_tts_get_error(void*p){return "fixture";}
int clone_encoded(){return encoded;}int clone_freed(){return freed;}int clone_language(){return language;}
'''
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); (root / "fake.c").write_text(source)
            subprocess.run(["cc", "-shared", "-fPIC", str(root / "fake.c"), "-o", str(root / "fake.so")], check=True, capture_output=True)
            voice = clone_voice.CloneVoice(root / "fake.so", root, root / "reference.wav")
            output = io.BytesIO()
            try:
                with wave.open(output, "wb") as wav:
                    voice.synthesize_wav("Olá, Quatro Braços!", wav)
                with wave.open(io.BytesIO(output.getvalue())) as wav:
                    self.assertEqual(wav.getnframes(), 480); self.assertEqual(wav.getframerate(), 24000)
                self.assertEqual(voice.lib.clone_encoded(), 1); self.assertEqual(voice.lib.clone_language(), 2071)
                with self.assertRaises(ValueError), wave.open(io.BytesIO(), "wb") as wav:
                    wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000)
                    voice.synthesize_wav("nan", wav)
                self.assertEqual(voice.lib.clone_freed(), 2)
            finally:
                voice.close()


if __name__ == "__main__":
    unittest.main()
