# Ben 10 · Clareira LIVE · V43

A V43 corrige comentários consumidos sem reprodução quando a voz falha. O texto fica guardado para nova tentativa; depois de três falhas, toque em ♫ para retomar. Saudações completas têm respostas rápidas e identificadas como roteiro, enquanto perguntas continuam usando a IA selecionada. Mensagens diferentes da mesma pessoa não são mais descartadas por chegarem em menos de três segundos.

[Guia da conversa e clonagem](docs/V43_CONVERSA_CLONAGEM.md)

## Atualizar a instalação existente

Pare a sessão da IA/jogo com Ctrl+C:

```sh
cd ~/ben10-v34/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V43_TERMUX.zip
bash local-ai.sh start
```

Abra http://127.0.0.1:3000/?v=43.0.0 e ative ♫. Mantém dados, chaves, progresso, personagens, relógio, ranking e voz atual. O reparo pequeno BEN10_REPARO_V43.zip é uma alternativa ao ZIP completo e faz backup antes de copiar arquivos. Não precisa aplicar os dois.

## Voz parecida com o Ben por referência

Há integração opcional com Qwen3-TTS 0.6B e o motor nativo predict-woo/qwen3-tts.cpp. O motor compilou em Linux; falta medir e ouvir no GT3. A voz clonada ainda não está pronta: precisa de amostra limpa em WAV, idealmente 10 a 20 segundos. Não há um modelo pronto do personagem incluído.

```sh
bash local-ai.sh clone install
bash local-ai.sh clone reference ~/storage/downloads/ben-classico.wav
bash local-ai.sh clone preview
```

A instalação inicial usa vários GB e internet. O preview informa o tempo para gerar a frase; ouça antes de selecionar. A clonagem não muda a voz atual automaticamente.

```sh
bash local-ai.sh clone use
bash local-ai.sh start
```

Para voltar ao Piper: pare a sessão, execute bash local-ai.sh clone piper e depois bash local-ai.sh start. A fala nativa não usa PyTorch; ele é necessário somente na conversão inicial dentro do Debian. Créditos, comandos e limites no guia.

## Validação

Testes automatizados, navegador isolado e extração/início do ZIP. Modelos de conversa e áudio usados nos testes são simulados. A C API nativa real compilou e carregou em Linux, sem pesos para inferência. Não foi medida a qualidade de clonagem nem o desempenho no GT3. Relatórios em reports/v43/.
