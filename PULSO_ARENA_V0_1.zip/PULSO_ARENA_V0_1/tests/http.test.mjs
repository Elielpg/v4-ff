import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
test("HTTP integration isolates demos and preserves working origin restrictions", async () => {
  const root = path.resolve(import.meta.dirname, ".."),
    dir = await mkdtemp(path.join(tmpdir(), "pulso-http-")),
    port = 33000 + Math.floor(Math.random() * 10000),
    base = "http://127.0.0.1:" + port;
  const child = spawn(process.execPath, ["server/index.mjs"], {
    cwd: root,
    env: { ...process.env, PORT: String(port), PULSO_DATA_DIR: dir },
    stdio: "pipe",
  });
  try {
    let ready = false;
    for (let n = 0; n < 60; n++) {
      try {
        const r = await fetch(base + "/api/state");
        if (r.ok) {
          ready = true;
          break;
        }
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    assert.ok(ready);
    let r = await fetch(base + "/api/demo/event", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Origin: "https://example.invalid",
      },
      body: JSON.stringify({ type: "join", user: "ana" }),
    });
    assert.equal(r.status, 403);
    const post = async (p, d) =>
      await (
        await fetch(base + "/api/" + p, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(d),
        })
      ).json();
    await post("demo/event", { type: "join", user: "ana" });
    await post("demo/event", { type: "like", user: "ana", count: 125 });
    await post("demo/event", {
      type: "gift",
      user: "ana",
      gift: "Rosa",
      repeatEnd: true,
    });
    let s = await (await fetch(base + "/api/state")).json();
    assert.equal(s.champion, "ana");
    assert.equal(s.players[0].hp, 125);
    assert.equal(s.mode, "demo");
    r = await fetch(base + "/api/live/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    assert.equal(r.status, 409);
    r = await fetch(base + "/../../package.json");
    assert.equal(r.status, 404);
    assert.equal((await fetch(base + "/")).status, 200);
    await post("live/connect", { username: "invalid link /" });
    r = await fetch(base + "/api/beat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source: "file", interval: 500 }),
    });
    assert.equal(
      r.status,
      409,
      "offline LIVE must also reject audio-driven attacks",
    );
    r = await fetch(base + "/api/demo/event", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "join", user: "fake" }),
    });
    assert.equal(r.status, 409, "simulation events cannot enter LIVE");
  } finally {
    child.kill("SIGTERM");
    await new Promise((resolve) => {
      if (child.exitCode !== null) resolve();
      else child.once("exit", resolve);
    });
    await rm(dir, { recursive: true, force: true });
  }
});
