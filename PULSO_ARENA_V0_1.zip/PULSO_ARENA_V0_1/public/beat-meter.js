import { OnsetDetector } from "./onset.js";
class PulsoMeter extends AudioWorkletProcessor {
  constructor() {
    super();
    this.sum = 0;
    this.n = 0;
    this.detector = new OnsetDetector();
  }
  process(inputs) {
    const a = inputs[0]?.[0];
    if (!a) return true;
    for (let i = 0; i < a.length; i++) {
      this.sum += a[i] * a[i];
      if (++this.n >= 768) {
        const level = Math.sqrt(this.sum / this.n),
          at = currentTime + i / sampleRate,
          hit = this.detector.sample(level, at);
        this.port.postMessage({ level, hit, at });
        this.sum = 0;
        this.n = 0;
      }
    }
    return true;
  }
}
registerProcessor("pulso-meter", PulsoMeter);
