export class OnsetDetector {
  constructor() {
    this.avg = 0.002;
    this.last = 0;
    this.prev = 0;
    this.samples = 0;
  }
  sample(level, at) {
    const old = this.avg;
    this.avg = this.avg * 0.97 + level * 0.03;
    this.samples++;
    const hit =
      this.samples > 6 &&
      level > Math.max(0.006, old * 1.6) &&
      level > this.prev * 1.06 &&
      at - this.last > 0.27;
    this.prev = level;
    if (hit) this.last = at;
    return hit;
  }
}
