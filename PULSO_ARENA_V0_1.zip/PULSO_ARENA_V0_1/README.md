# PULSO ARENA · 0.1.0

Primeiro protótipo do ringue interativo original: mascotes 3D, plateia de espectadores, entrada por rosa, torcida, HP por curtidas e luta na batida. Projeto independente, pensado para navegador e Termux. Não altera a instalação do Ben 10.

## Instalar no Termux

Use Termux atualizado e Node **22.19 ou mais recente**. A instalação inicial das dependências precisa de internet. O teste local funciona depois sem conexão ao TikTok.

Se necessário, libere o acesso à pasta Downloads com `termux-setup-storage`. Com o ZIP em Downloads:

```bash
cd ~
python3 -m zipfile -e ~/storage/downloads/PULSO_ARENA_V0_1.zip .
cd ~/PULSO_ARENA_V0_1
bash install.sh
bash start.sh
```

Se Python ainda não estiver instalado: `pkg install python`.

Abra **http://127.0.0.1:3100** no Chrome do mesmo celular. Toque em **Testar arena** para iniciar uma demonstração com participantes fictícios. O botão também libera o áudio exigido pelo navegador.

Para iniciar nas próximas vezes:

```bash
cd ~/PULSO_ARENA_V0_1 && bash start.sh
```

Para parar, use **Ctrl+C** no terminal original ou `bash stop.sh` em outra sessão dentro da pasta. Para reiniciar, pare primeiro e execute `bash start.sh`. O programa usa a porta 3100; se outro serviço já estiver nela, informa o conflito e não entra em um ciclo de reinicialização.

## Experimentar as interações

Abra o menu **☰ → Teste de interações**. Escolha um nome de usuário e teste entrada, curtidas, rosa, compartilhamento, seguidor e torcida. Esses botões não enviam presentes nem interagem com a conta real do TikTok.

1. Quem entra recebe um mascote e uma identificação na plateia.
2. **5 curtidas do próprio usuário = +1 HP**, até 250 HP. Quem está na plateia guarda vida para a próxima entrada.
3. **1 rosa coloca o usuário na fila**. A primeira pessoa ocupa a coroa provisória, sem receber vitória automática.
4. O próximo desafiante entra com um chute de 10 de dano. A luta segue a batida, com socos, chutes, giros e especial.
5. Comentar **@usuario** fortalece aquele jogador. Nome de exibição exato também funciona se identificar apenas uma pessoa. A força extra tem limite de 30%.
6. Compartilhar fortalece o próprio mascote. O vencedor fica no ringue com o HP restante e soma vitória no ranking.

Cada pessoa ocupa uma única posição na fila. Rosas adicionais não duplicam posições e não interrompem uma luta em andamento. A fila tem limite de 100 pessoas; uma nova rosa durante a luta do próprio usuário carrega o especial. Há 15 segundos de recuperação após uma derrota. Curtidas sem identificação individual somam no total da arena, sem inventar HP para alguém.

Durante o combate, a cura chega gradualmente: até 3 HP por segundo, com reserva de cura de até 30. A rodada dura até 45 segundos ativos e termina por nocaute ou decisão de HP. Os valores ficam em `server/engine.mjs`.

## Música e sincronia

No menu **Música e batida**, carregue MP3, M4A ou WAV. O áudio toca pelo player do navegador, e a análise dos graves controla a batida, os golpes e as luzes. O arquivo é aberto por URL local; o código não decodifica uma hora inteira de música em um grande buffer na RAM.

Para caixa ou fone Bluetooth, ajuste **Compensação Bluetooth** de 0 a 400 ms até os movimentos coincidirem com o som. A latência varia por aparelho. O detector pode interpretar a metade ou o dobro do andamento em algumas músicas; use BPM manual ou **Marcar batida (TAP)** para corrigir. **Usar detector do arquivo** retorna ao modo automático.

**GreenTube e outros aplicativos:** esta versão web não recebe automaticamente o áudio de outro aplicativo. Para tocar música por eles, ajuste o BPM manual. Para detectar a música diretamente, use o arquivo no player do jogo. Uma eventual captura nativa do Android exigirá outro componente e autorização de captura no aparelho.

Pausar a música no player pausa os golpes da luta. Selecionar um BPM manual permite continuar o combate nesse andamento. Toque em **♫** para liberar áudio se o navegador estiver bloqueando o som. O pacote inclui uma batida sintética de teste em `tests/fixtures/batida-120.wav`; não inclui músicas comerciais.

## TikTok LIVE

Inicie sua transmissão pelo aplicativo que costuma usar. No jogo, abra **☰ → Conectar à LIVE**, informe somente o @ e toque em **Conectar**. Aguarde **LIVE · CONECTADA**. A leitura usa o conector `piratetok-live-js`, sem senha da conta.

O conector e a tradução de eventos estão implementados; a conexão a uma LIVE pública real **ainda precisa ser validada no seu aparelho e conta**. O TikTok pode alterar esse protocolo. Os testes de integração foram locais, com eventos simulados e conexões controladas. Valide a leitura dos presentes em uma sessão de teste.

Demo e LIVE possuem estados separados. A demonstração se identifica na tela; os botões de eventos fictícios são recusados no modo LIVE. Sem conexão, os ataques da LIVE ficam suspensos. A reconexão ao TikTok é manual pelo painel.

## Qualidade e estabilidade

- **Leve:** até 8 mascotes visíveis na plateia, menor resolução, sem sombras dinâmicas e brilho adicional.
- **Equilibrado:** até 16 lugares visíveis, sombras de 512 pixels e brilho.
- **Detalhado:** até 24 lugares visíveis e resolução maior.

O restante dos participantes continua registrado, embora nem todos sejam desenhados simultaneamente. O cadastro é limitado a 5.000 usuários e a fila a 100. Partículas e efeitos também possuem limites. O contador de FPS aparece no menu. Comece no perfil Leve no GT3 e ajuste após uma sessão real.

O supervisor acompanha o servidor em um processo separado. Se o servidor encerrar inesperadamente, tenta recuperá-lo até **4 vezes em 15 minutos**, com espera crescente; depois para e registra a falha. Um segundo início verifica se esta instalação já está aberta. O script solicita `termux-wake-lock` quando disponível.

O supervisor **não consegue se recuperar quando o Android encerra todo o Termux**, incluindo o próprio supervisor. Permita atividade em segundo plano e configure a bateria do Realme para não restringir o Termux. Temperatura, memória e duração de uma LIVE no aparelho ainda precisam de medição; não há promessa de execução ilimitada.

## Dados, backup e diagnóstico

O progresso é salvo localmente a cada segundo e em transições importantes. `data/live.json` guarda a LIVE e `data/demo.json` guarda a simulação. Cada arquivo tem uma cópia `.bak`. São persistidos HP, fila, ranking e identificadores recentes para deduplicação. Uma interrupção abrupta pode perder o último segundo ou uma gravação que não chegou ao armazenamento.

Antes de trocar arquivos, pare a arena e guarde as pastas **data** e **logs**, além do ZIP desta versão. Para reverter uma atualização futura, restaure o código anterior junto de um backup de dados compatível. Esta entrega inicial não contém atualização automática nem migração do projeto anterior.

Logs úteis:

```bash
cd ~/PULSO_ARENA_V0_1
tail -n 30 logs/supervisor.jsonl
tail -n 30 logs/server.jsonl
```

O log do servidor registra início, fim, estado de conexão e, a cada minuto, uso de memória do Node. O supervisor registra código de saída e sinal. Se o aplicativo inteiro for morto, os últimos logs ajudam a localizar onde a sessão parou, mas podem não registrar a causa do Android.

## Estrutura e validação

```text
server/engine.mjs       regras, HP, fila, golpes e ranking
server/live.mjs         normalização e conexão TikTok
server/storage.mjs      gravação atômica e recuperação do backup
server/index.mjs        HTTP, eventos SSE, modos e persistência
public/world.js         mascotes, arena, animação, efeitos e câmera
public/audio.js         player, análise e efeitos sonoros
public/onset.js         detector de transientes testável
public/beat-meter.js    processamento AudioWorklet
public/app.js           interface e eventos
scripts/supervisor.mjs  recuperação limitada do servidor
scripts/instance.mjs    identificação e parada desta instalação
tests/                 regras, áudio, armazenamento, conector e HTTP
docs/                  projeto, limitações e evidências
```

Execute `npm test`. Consulte `docs/PROJETO.md`, `docs/PROBLEMAS_PENDENTES.md` e `docs/evidencias/` para resultados e limites dos testes.

O visual entregue usa quatro bases de mascotes geométricos originais. A imagem `docs/CONCEITO_VISUAL.png` é uma **arte de direção visual**; `docs/PULSO_ARENA_PREVIA.png` é uma **captura real do protótipo**. O jogo usa animação procedural, sem alegar um conjunto final de animações desenhadas ou capturadas. As boas-vindas atuais são texto e efeito sonoro; não há narrador de IA nesta versão.

## Dependências

Babylon.js 9.32.1 está incluído localmente, com licença Apache-2.0. O conector `piratetok-live-js` 0.3.0 tem licença 0BSD e é instalado pelo npm com versões transitivas fixadas em `package-lock.json`. Créditos em `docs/TERCEIROS.md`. O frontend não depende de CDN.
