# Créditos e dependências

- **Babylon.js 9.32.1** — https://www.babylonjs.com/ — Apache-2.0. Build local em `public/vendor/babylon.js`; licença em `public/vendor/BABYLON-LICENSE.md`.
- **piratetok-live-js 0.3.0** — https://github.com/PirateTok/live-js — 0BSD, Copyright 2026 Zmole Cristian. Instalado pelo npm; licença reproduzida em `PIRATETOK-LICENSE.txt`.
- As dependências transitivas estão fixadas em `package-lock.json`; seus pacotes instalados pelo npm preservam as licenças próprias. Node.js e Termux são requisitos de execução, não redistribuídos neste ZIP.
- A batida de teste de 120 BPM foi sintetizada para este projeto. Não há músicas comerciais no pacote.
- Mascotes e cenário são originais procedurais. A arte de conceito foi gerada para estabelecer a direção visual e está identificada separadamente da captura real.
