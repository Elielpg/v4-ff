# Registro e roteiro de validação · 0.1.0

## Executado neste ambiente

`npm test`: 24 testes passaram. Saída integral em `evidencias/TESTES_COMPLETOS.txt`.

Teste de navegador: Chromium headless com SwiftShader em computador, viewport CSS 540 × 1.080. A reprodução efetiva do arquivo de 120 BPM foi analisada pelo AudioWorklet: estimativa final 119 BPM. Testadas entrada, likes/HP e rosa/fila. O relatório registra ausência de erros JavaScript e de overflow. A captura real está em `PULSO_ARENA_PREVIA.png`.

Teste de recuperação: encerrado apenas o servidor filho da sessão de teste, com sinal SIGKILL. O supervisor abriu outro servidor e o estado observado foi recuperado: 500 likes e HP reservado 200, 8.178 ms após a interrupção. Não foi simulado o Android matando todo o Termux.

Os scripts automatizados de captura e falha usados no computador não integram a instalação de produção; o pacote contém os registros, a fixture de áudio e os testes portáveis de regras/HTTP.

## No Realme GT3, antes de usar com presentes reais

1. Instalar, abrir http://127.0.0.1:3100 e usar Testar arena. Confirmar dois mascotes distintos, plateia, nomes, golpes e vencedor.
2. No menu, escolher outro usuário e aplicar 50 likes. Verificar vida reservada antes da entrada e aumento de 10 HP; enviar a rosa de teste e aguardar a fila.
3. Torcer por @usuario e conferir aumento de força no HUD. Compartilhar e conferir a força própria.
4. Carregar `tests/fixtures/batida-120.wav`: deve aproximar 120 BPM. Em seguida testar a música real e ajustar o atraso para o fone/caixa.
5. Alternar Leve/Equilibrado/Detalhado, registrar FPS no menu e observar legibilidade. Reduzir movimentos se necessário.
6. Iniciar uma LIVE curta de teste, conectar o @ e confirmar estado CONECTADA. Conferir incremento de likes por usuário, fim da sequência de rosa, comentário e compartilhamento. Comparar com os eventos recebidos no celular.
7. Parar normalmente com Ctrl+C e iniciar outra vez. Conferir HP, fila e ranking da LIVE sem mistura com a simulação.
8. Deixar 30 min e depois 60 min com a música real. Registrar perfil, volume de usuários, bateria, temperatura e últimas linhas dos logs. Repetir com tela ativa e com as configurações de segundo plano que serão usadas na transmissão.

## Critérios ainda sem evidência

Meta inicial sugerida: 30 FPS estáveis no perfil escolhido e ausência de encerramentos durante a sessão de 60 min no GT3. Essa é uma meta de aceitação, não um resultado já obtido.

Precisão musical deve ser avaliada pela relação som/golpe percebida, incluindo pausas, retomadas e Bluetooth. Não há garantia de alinhamento de todas as batidas em músicas arbitrárias. Eventos reais do TikTok e comportamento térmico exigem o aparelho e uma transmissão.
