# Estado para próximas iterações

Projeto ativo: **PULSO ARENA**, jogo original separado do Ben 10 e da série de vídeos. Escolha do usuário: mascotes de luta estilizados, cores fortes e expressões marcantes. Alvo: Realme GT3, 16 GB RAM, Termux, navegador do próprio celular.

0.1.0 entrega o protótipo de rei do ringue, fila por rosa, HP por likes, torcida por @, força por share, plateia, ranking, câmera 3D e música por arquivo. Quatro bases de mascote: fox, hippo, raccoon, ram.

Evidência: 24 testes, navegador com áudio real de fixture, recuperação do servidor filho com HP salvo. Ainda não há evidência de LIVE real, sessão longa ou performance no GT3. As boas-vindas são texto e som curto. O jogo não depende de LLM, clonador nem API de voz.

Não afirmar que captura o GreenTube. Arquivo local usa detector; áudio externo usa BPM/TAP. Usuário usa fone/caixa Bluetooth, com compensação ajustável no painel.

Preservar limites de HP, força, fila, partículas e reinícios; preservar separação de demo/LIVE e progressos. Consultar PROBLEMAS_PENDENTES.md antes de alegar resolução de estabilidade Android. Nunca misturar números de renderização por software com benchmark do telefone.
