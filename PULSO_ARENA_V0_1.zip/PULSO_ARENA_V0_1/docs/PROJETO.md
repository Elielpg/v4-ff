# PULSO ARENA · projeto e entrega 0.1.0

Data: 16/11/2026. Primeiro protótipo do projeto original de luta interativa.

## Direção

Um ringue de mascotes com cores fortes, expressões marcantes e plateia de participantes. A câmera enquadra chegadas, golpes especiais e vitórias. A partida acontece mesmo sem fala contínua do apresentador: música, movimento e instruções breves mostram como participar.

Quatro bases de personagem estão implementadas: raposa, hipopótamo, guaxinim e carneiro. A identidade visual de cada espectador é determinística a partir de seu identificador. A versão atual desenha os mascotes por geometria procedural Babylon.js e usa nomes na identificação. A arte de conceito serve como direção de acabamento, não como demonstração do modelo final.

O ciclo principal é: **chegar → ganhar mascote → acumular HP → enviar rosa → aguardar fila → entrar com chute → lutar na batida → manter a coroa ou voltar à plateia**.

## Regras implementadas

| Interação | Resultado | Limite |
|---|---|---|
| Entrada | Mascote, nome e mensagem na plateia | Boas-vindas por pessoa a cada 60 s |
| 5 curtidas identificadas | +1 HP próprio, na plateia ou no ringue | HP máximo 250; cura em luta até 3/s |
| 1 rosa | Uma posição FIFO na fila | 100 pessoas; sem duplicar posição |
| Entrada no ringue | Chute de 10 de dano | Uma vez por entrada |
| Comentar @jogador | +2 pontos percentuais de força do alvo | 5 s por remetente; força até +30% |
| Compartilhar | +4 pontos percentuais de força própria | 15 s por usuário |
| Seguir | Efeito sonoro e +5 pontos de participação | Deduplicação por ID do evento |
| Especial carregado | Golpe de 27 de dano antes do bônus | Energia máxima 100 |
| Vitória | Coroa, sequência e +100 pontos | Nocaute ou decisão após 45 s ativos |

O primeiro ocupante recebe coroa provisória com zero vitórias. A saúde restante do campeão é mantida para o próximo combate. Derrotados voltam à plateia e aguardam 15 segundos para nova entrada. O HP reservado é consumido na entrada, sem reaplicar o mesmo bônus. Sequências de rosas são processadas ao concluir o presente, com deduplicação por mensagem quando o provedor fornece ID.

## Arquitetura

```text
TikTok LIVE público → TikTokAdapter → evento normalizado
                                          ↓
Simulação isolada → ArenaEngine ← relógio / batidas do navegador
                         ↓                ↑
               snapshot + ações SSE      │ POST /api/beat
                         ↓                │
            Interface + Babylon.js + AudioWorklet
                         ↓
              câmera / golpes / luz / som

Store: estado LIVE e demo separados → JSON temporário → renomeação → .bak
Supervisor Node → servidor HTTP filho → até 4 recuperações por 15 minutos
```

O servidor decide HP, dano, fila e vitória. O navegador representa o estado e envia eventos de batida. As ações da partida não dependem de geração de linguagem, API de IA ou clonagem de voz. O chat é interpretado apenas pelas regras de participação: não executa comandos do sistema.

O servidor escuta somente `127.0.0.1`, com verificação de origem nos POSTs do navegador e tamanho máximo de 32 KB para eventos. Não há endpoint de execução de shell. A ponte `POST /api/live/event` aceita o mesmo esquema de evento local quando o modo LIVE está selecionado; a conexão direta é a opção do painel. Um evento da ponte mantém a sessão ativa por 30 s, período que deve ser renovado por eventos.

## Organização dos módulos

| Arquivo | Responsabilidade |
|---|---|
| server/engine.mjs | Motor de regras, contadores, estados, fila e deduplicação |
| server/live.mjs | Eventos chat, gift, like, follow, share e join; ciclo da conexão |
| server/storage.mjs | Coalescência de gravações, troca atômica e backup |
| server/index.mjs | Servidor HTTP, SSE, simulador, pausas e logs |
| public/world.js | Arena, quatro mascotes, poses, câmera, luzes e efeitos |
| public/audio.js | Reprodução de arquivo, graves, compensação e SFX |
| public/onset.js | Detector de transientes independente da interface |
| public/beat-meter.js | AudioWorklet com processamento de nível e batida |
| public/app.js | Estado da interface, menu, botões e comunicação HTTP/SSE |
| scripts/supervisor.mjs | Supervisão de processo com orçamento de reinício |
| scripts/instance.mjs | Validação da instância por PID, comando e diretório |

## Áudio e câmera

O arquivo local usa `HTMLAudioElement` e URL de arquivo escolhida pelo usuário. O áudio segue para o player e para uma análise dos graves centrada em 110 Hz. O detector usa nível adaptativo, intervalo mínimo entre batidas e mediana de intervalos recentes. Os efeitos sonoros não passam pelo detector da música. O modo manual tem BPM e TAP; o modo automático pode exigir ajuste em músicas com graves sustentados ou subdivisões rítmicas.

O Android não entrega o som do GreenTube diretamente a esta página. A captura nativa de outros aplicativos não foi implementada. Arquivo local é a opção com detecção direta; BPM manual é a opção para áudio externo.

A câmera acompanha a arena, faz aproximação no especial e destaca a plateia em momentos de espera. Há opção para reduzir movimentos e luzes. O movimento de dança usa a fase da batida recebida. A compensação Bluetooth é manual e precisa ser ajustada na saída utilizada.

## Estabilidade e desempenho

Perfis gráficos manuais limitam plateia visível, resolução, sombras e brilho. Efeitos têm teto de 80 partículas ativas. Os participantes fora do enquadramento permanecem no estado do servidor. O limite de 5.000 registros contém consumo de memória; o protótipo não oferece histórico ilimitado de todos os espectadores.

Snapshots são salvos a cada segundo e em mudanças importantes. Escritas acumuladas são substituídas pela versão mais recente antes de gravar. O backup anterior é usado se o arquivo principal estiver corrompido. A recuperação conserva fila, HP e ranking, mas não representa garantia de entrega de todos os eventos durante uma queda de rede ou energia.

O supervisor recupera encerramento do servidor filho, inclusive saída inesperada com código zero. Porta ocupada é erro fatal sem repetição. Os reinícios usam espera crescente e param após o limite. Encerramento do Termux inteiro pelo Android exige reabertura manual; medir essa causa no GT3 continua pendente.

## Evidências de validação

- **24 testes aprovados**: regras, contagem de likes incrementais, fim de sequência de presente, conexão antiga descartada, origem HTTP, separação demo/LIVE, escrita atômica e recuperação de backup.
- Navegador Chromium: arena renderizada, entrada de usuário, 50 likes convertidos em HP 110 e usuário enfileirado por rosa; sem erros JavaScript nem transbordamento horizontal na viewport de teste.
- Áudio real no navegador: arquivo sintético de 8 s a 120 BPM, detector AudioWorklet ativo, cinco intervalos medidos e estimativa final de **119 BPM**.
- Recuperação: SIGKILL apenas no servidor filho de teste; serviço voltou em **8.178 ms**, mantendo 500 likes e HP reservado 200 do participante observado. Esse tempo inclui o atraso do orçamento de reinício daquela sessão.
- Captura visual: Chromium com renderização por software SwiftShader, 675 × 1.350, perfil equilibrado com ajuste de resolução para a captura, 304 meshes e 6 FPS registrados. **Isso não é benchmark de GPU nem resultado do Realme GT3.**

Os JSONs e a saída dos testes ficam em `docs/evidencias/`. O roteiro manual está em `docs/VALIDACAO.md`.

Não foram executados: LIVE real com conta e presentes reais, sessão de uma hora, teste de temperatura/bateria no GT3, comparação de GPUs, sincronização com todos os dispositivos Bluetooth ou captura do GreenTube. A entrega é um protótipo verificável para testar a proposta antes de investir no acabamento final.

## Próximas melhorias propostas

1. Validar conexão e eventos de uma LIVE real antes de ajustar economia de presentes.
2. Medir FPS, memória, temperatura e quedas em 30 e 60 minutos no Realme GT3.
3. Refinar rosto, silhueta e animação de cada mascote a partir de gravações do protótipo.
4. Testar músicas de phonk reais: entradas, pausas, meia batida e Bluetooth.
5. Adicionar fila nominal visível, histórico de resultados e avisos claros de fila cheia/recuperação para a transmissão.
6. Reavaliar quantidade de corpos visíveis e eventual agrupamento de meshes conforme medições no dispositivo.

## Entrega e reversão

O ZIP contém código completo do protótipo, Babylon local, lockfile de dependências, testes, batida sintética, documentação, relatório e prévia. Não inclui `node_modules`, progresso, logs de execução, credenciais nem arquivos do projeto anterior. `bash install.sh` recompõe as dependências.

Esta é uma instalação nova. Atualizações posteriores devem ser feitas com a arena parada e backup das pastas data/logs. Para voltar a esta versão, restaure o ZIP e o backup de estado compatível, reinstale dependências se necessário e execute start.sh.
