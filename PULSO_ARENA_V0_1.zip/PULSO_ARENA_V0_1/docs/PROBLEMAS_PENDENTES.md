# Problemas conhecidos e validações pendentes

Estado em 16/11/2026, versão 0.1.0.

| ID | Situação | Impacto / próximo passo |
|---|---|---|
| PULSO-001 | Conector LIVE sem teste com transmissão real | Validar abertura WebSocket, entrada, rosa, comentário, likes e share na conta do usuário. A compatibilidade pode mudar no TikTok. |
| PULSO-002 | Android pode matar todo o Termux | Supervisor cobre o servidor filho. Colher logs e medir segundo plano/bateria/temperatura do GT3; não há recuperação fora de um Termux encerrado. |
| PULSO-003 | Performance e duração no GT3 não medidas | Começar perfil Leve, gravar FPS e logs por 30/60 min. A medição SwiftShader do computador não prevê desempenho no telefone. |
| PULSO-004 | Detector pode errar meia/dobra de batida | Usar BPM/TAP e testar biblioteca real de phonk. Há evidência com batida sintética de 120 BPM, não com todas as músicas. |
| PULSO-005 | Áudio de outro aplicativo não capturado | GreenTube exige BPM manual ou troca para arquivo local. Captura nativa Android fica para uma etapa própria. |
| PULSO-006 | Acabamento visual é de protótipo | Quatro corpos geométricos e animação procedural. Próxima etapa: acabamento de faces, rig e transições com medição no GT3. |
| PULSO-007 | Apenas parte da plateia é desenhada | Perfis exibem 8/16/24 corpos; registros permanecem no servidor. Fila tem 100 pessoas e cadastro tem limite de 5.000. |
| PULSO-008 | Queda pode perder eventos ainda não salvos/recebidos | Snapshot periódico e backup reduzem perda local; protocolo não garante replay de eventos perdidos do TikTok. |
| PULSO-009 | Fila ainda não mostra todos os nomes no HUD | Há contagem e avisos locais. Evoluir painel para próximo desafiante, fila cheia e recuperação após derrota. |
| PULSO-010 | Boas-vindas sem narração falada | Texto e ding implementados. Narrador é opcional futuro e não participa do motor de luta. |

## Falhas encontradas e corrigidas durante a implementação

- Sombras tentavam usar TransformNode como Mesh: corrigido para registrar somente meshes compatíveis; teste visual com sombras passou.
- Plateia ficava fora do enquadramento: posições ajustadas para trás do ringue.
- Demonstração mostrava corpos iguais: personagens de teste agora usam bases e cores diferentes, com reconstrução do ator quando o tipo muda.
- Torcida por @ perdia o prefixo durante a interpretação: menções agora são reconhecidas antes de comparar nomes.
- Batidas estimadas podiam cessar após interrupção no detector: o relógio da última batida externa foi separado do relógio geral.
- Arquivo corrompido podia substituir um backup bom: a gravação identifica recuperação e preserva a cópia anterior.
- Conexão antiga da LIVE podia terminar depois de outra conexão: geração e cancelamento impedem substituição da sessão atual.
- Batidas enviadas pelo player podiam acionar combate mesmo com a LIVE desconectada: rota de batida agora exige conexão ativa no modo LIVE; regressão HTTP passou.
