export const RULES = {
  baseHp: 100,
  maxHp: 250,
  likesPerHp: 5,
  maxHealPerSecond: 3,
  maxCheer: 30,
  cheerCooldown: 5000,
  shareCooldown: 15000,
  maxQueue: 100,
  maxPlayers: 5000,
  roundMs: 45000,
};
const clamp = (x, a, b) => Math.max(a, Math.min(b, x)),
  safe = (x, n = 40) =>
    String(x ?? "")
      .replace(/[\x00-\x1f<>]/g, "")
      .trim()
      .slice(0, n);
export function hash(s) {
  let h = 2166136261;
  for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return h >>> 0;
}
const norm = (s) =>
  String(s)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/^@/, "")
    .trim();
export class ArenaEngine {
  constructor({
    now = Date.now,
    onAction = () => {},
    saved = null,
    mode = "demo",
  } = {}) {
    this.now = now;
    this.onAction = onAction;
    this.mode = mode;
    this.players = new Map();
    this.queue = [];
    this.champion = null;
    this.challenger = null;
    this.phase = "waiting";
    this.phaseUntil = 0;
    this.lastTick = now();
    this.nextBeat = now() + 550;
    this.seq = 0;
    this.inputSeq = 0;
    this.seen = new Map();
    this.cooldowns = new Map();
    this.notice = null;
    this.recent = [];
    this.lastAction = null;
    this.beatMs = 545;
    this.musicSource = "manual";
    this.lastBeat = 0;
    this.lastExternalBeat = 0;
    this.lastBeatSource = "manual";
    this.boutElapsed = 0;
    this.turn = 0;
    this.rng = hash("pulso");
    this.entryHit = false;
    this.cinematicUntil = 0;
    this.totals = {
      likes: 0,
      unattributedLikes: 0,
      gifts: 0,
      comments: 0,
      shares: 0,
      followers: 0,
    };
    if (saved) this.restore(saved);
  }
  random() {
    this.rng = (Math.imul(this.rng, 1664525) + 1013904223) >>> 0;
    return this.rng / 4294967296;
  }
  action(kind, data = {}) {
    const a = { id: ++this.seq, at: this.now(), kind, ...data };
    this.lastAction = a;
    this.recent.push(a);
    this.recent = this.recent.slice(-16);
    this.onAction(a);
    return a;
  }
  player(id, name = id) {
    id = norm(safe(id, 40));
    if (!id) return null;
    let p = this.players.get(id);
    if (!p) {
      if (this.players.size >= RULES.maxPlayers) {
        const victim = [...this.players.values()]
          .filter((p) => !this.isActive(p.id) && !this.queue.includes(p.id))
          .sort((a, b) => a.lastSeen - b.lastSeen)[0];
        if (!victim) return null;
        this.players.delete(victim.id);
      }
      p = {
        id,
        name: safe(name, 26) || id,
        seed: hash(id),
        archetype: ["fox", "hippo", "raccoon", "ram"][hash(id) % 4],
        reserveHp: 100,
        hp: 100,
        healPool: 0,
        healCarry: 0,
        cheer: 0,
        energy: 0,
        likes: 0,
        wins: 0,
        losses: 0,
        streak: 0,
        bestStreak: 0,
        score: 0,
        roses: 0,
        lastSeen: this.now(),
        joinedAt: this.now(),
        nextEntryAt: 0,
      };
      this.players.set(id, p);
    }
    p.lastSeen = this.now();
    if (name && name !== id) p.name = safe(name, 26) || p.name;
    return p;
  }
  isActive(id) {
    return id === this.champion || id === this.challenger;
  }
  duplicate(e) {
    if (!e.id) return false;
    const key = e.type + ":" + safe(e.id, 100);
    if (this.seen.has(key)) return true;
    this.seen.set(key, this.now());
    while (this.seen.size > 4096)
      this.seen.delete(this.seen.keys().next().value);
    return false;
  }
  can(key, ms) {
    const t = this.now(),
      last = this.cooldowns.get(key) ?? -Infinity;
    if (t - last < ms) return false;
    this.cooldowns.set(key, t);
    while (this.cooldowns.size > 20000)
      this.cooldowns.delete(this.cooldowns.keys().next().value);
    return true;
  }
  ingest(e) {
    if (
      !e ||
      !["join", "like", "comment", "share", "follow", "gift"].includes(e.type)
    )
      return { accepted: false, reason: "tipo inválido" };
    if (e.type === "gift" && e.repeatEnd === false)
      return { accepted: false, reason: "aguardando fim da sequência" };
    if (this.duplicate(e)) return { accepted: false, reason: "duplicado" };
    this.inputSeq++;
    if (e.type === "like" && e.count !== undefined && !(Number(e.count) > 0))
      return { accepted: false, reason: "curtidas sem incremento" };
    const count = clamp(Math.floor(Number(e.count) || 1), 1, 50000);
    if (e.type === "like" && !e.user) {
      this.totals.likes += count;
      this.totals.unattributedLikes += count;
      this.action("crowd", { count, unattributed: true });
      return { accepted: true, attributed: false };
    }
    const p = this.player(e.user, e.name || e.user);
    if (!p)
      return { accepted: false, reason: "usuário ausente ou limite atingido" };
    if (e.type === "join") {
      if (this.can("welcome:" + p.id, 60000)) {
        this.notice = {
          text: `BEM-VINDO, ${p.name}! Seu lugar na plateia está reservado.`,
          until: this.now() + 4000,
        };
        this.action("welcome", { player: p.id });
      }
    }
    if (e.type === "like") {
      p.likes += count;
      this.totals.likes += count;
      const credit = Math.floor(
        ((p.likeRemainder || 0) + count) / RULES.likesPerHp,
      );
      p.likeRemainder = ((p.likeRemainder || 0) + count) % RULES.likesPerHp;
      if (this.isActive(p.id) && this.challenger)
        p.healPool = clamp(p.healPool + credit, 0, 30);
      else if (this.isActive(p.id)) p.hp = clamp(p.hp + credit, 0, RULES.maxHp);
      else p.reserveHp = clamp(p.reserveHp + credit, 100, RULES.maxHp);
      p.score += Math.floor(count / 5);
      this.action("likes", { player: p.id, count, hp: credit });
    }
    if (e.type === "comment") {
      this.totals.comments++;
      const raw = safe(e.text, 160)
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
      const mention = raw.match(/@([a-z0-9_.]+)/);
      let target = mention ? this.players.get(mention[1]) : null;
      if (!mention) {
        const clean = raw.replace(/^(forca|vai|torcida)\s+/, "");
        const matches = [...this.players.values()].filter(
          (q) => norm(q.id) === clean || norm(q.name) === clean,
        );
        if (matches.length === 1) target = matches[0];
      }
      if (target && this.can("cheer:" + p.id, RULES.cheerCooldown)) {
        target.cheer = clamp(target.cheer + 2, 0, RULES.maxCheer);
        target.score += 2;
        this.action("cheer", {
          player: p.id,
          target: target.id,
          power: target.cheer,
        });
      }
    }
    if (e.type === "share" && this.can("share:" + p.id, RULES.shareCooldown)) {
      this.totals.shares++;
      p.cheer = clamp(p.cheer + 4, 0, RULES.maxCheer);
      p.score += 8;
      this.action("share", { player: p.id, power: p.cheer });
    }
    if (e.type === "follow") {
      this.totals.followers++;
      p.score += 5;
      this.action("follow", { player: p.id });
    }
    if (e.type === "gift") {
      const rose =
        [5655].includes(Number(e.giftId)) ||
        ["rose", "rosa"].includes(norm(e.gift));
      this.totals.gifts += count;
      if (rose) {
        p.roses += count;
        p.score += 10 * count;
        if (this.isActive(p.id)) {
          p.energy = clamp(p.energy + 12 * Math.min(count, 5), 0, 100);
          this.action("charge", { player: p.id });
          return { accepted: true, result: "carga especial" };
        }
        if (p.nextEntryAt > this.now())
          return { accepted: true, result: "recuperando na plateia" };
        if (this.queue.includes(p.id))
          return { accepted: true, result: "já está na fila" };
        if (this.queue.length >= RULES.maxQueue)
          return { accepted: true, result: "fila cheia" };
        this.queue.push(p.id);
        this.action("queued", { player: p.id, position: this.queue.length });
        this.tryEntry();
      }
    }
    return { accepted: true };
  }
  tryEntry() {
    if (!this.champion && this.queue.length) {
      const id = this.queue.shift(),
        p = this.players.get(id);
      if (!p) return;
      this.champion = id;
      p.hp = p.reserveHp;
      p.reserveHp = 100;
      p.energy = 0;
      this.phase = "waiting";
      this.action("crowned", { player: id, provisional: true });
    }
    if (
      this.champion &&
      !this.challenger &&
      this.queue.length &&
      this.phase === "waiting"
    ) {
      const id = this.queue.shift(),
        p = this.players.get(id);
      if (!p || id === this.champion) return;
      this.challenger = id;
      p.hp = p.reserveHp;
      p.reserveHp = 100;
      p.energy = 0;
      this.phase = "entrance";
      this.phaseUntil = this.now() + 2200;
      this.entryHit = false;
      this.boutElapsed = 0;
      this.turn = 0;
      this.action("entrance", { player: id, target: this.champion });
    }
  }
  hit(attackerId, targetId, kind, damage) {
    const a = this.players.get(attackerId),
      b = this.players.get(targetId);
    if (!a || !b) return;
    b.hp = Math.max(0, b.hp - damage);
    a.score += damage;
    a.energy = clamp(a.energy + 14, 0, 100);
    b.energy = clamp(b.energy + 7, 0, 100);
    this.action("attack", {
      player: a.id,
      target: b.id,
      move: kind,
      damage,
      hp: b.hp,
      special: kind === "special",
    });
    if (b.hp <= 0) this.win(a.id, b.id, "nocaute");
  }
  beat({ source = "manual", interval } = {}) {
    const now = this.now();
    if (now - this.lastBeat < 250) return false;
    this.lastBeat = now;
    this.lastBeatSource = source;
    if (source === "file") {
      this.lastExternalBeat = now;
      this.musicSource = "file";
    }
    if (Number.isFinite(interval)) this.beatMs = clamp(interval, 300, 1200);
    this.nextBeat = now + this.beatMs;
    this.action("beat", { source, interval: this.beatMs });
    if (this.phase !== "fighting" || now < this.cinematicUntil) return true;
    const a = this.players.get(
        this.turn++ % 2 ? this.challenger : this.champion,
      ),
      b = this.players.get(
        a?.id === this.champion ? this.challenger : this.champion,
      );
    if (!a || !b) return true;
    const special = a.energy >= 100,
      move = special
        ? "special"
        : ["jab", "kick", "cross", "spin"][Math.floor(this.random() * 4)];
    const damage = Math.round(
      (special ? 27 : 6 + this.random() * 4) * (1 + a.cheer / 100),
    );
    if (special) {
      a.energy = 0;
      this.cinematicUntil = now + 1100;
    }
    this.hit(a.id, b.id, move, damage);
    return true;
  }
  win(winnerId, loserId, reason) {
    if (this.phase === "victory") return;
    const w = this.players.get(winnerId),
      l = this.players.get(loserId);
    w.wins++;
    w.streak++;
    w.bestStreak = Math.max(w.bestStreak, w.streak);
    w.score += 100;
    l.losses++;
    l.streak = 0;
    l.nextEntryAt = this.now() + 15000;
    l.reserveHp = 100;
    l.healPool = 0;
    w.healPool = 0;
    this.champion = winnerId;
    this.challenger = null;
    this.phase = "victory";
    this.phaseUntil = this.now() + 3500;
    this.action("victory", {
      player: winnerId,
      target: loserId,
      reason,
      streak: w.streak,
    });
  }
  tick() {
    const now = this.now(),
      dt = clamp(now - this.lastTick, 0, 250);
    this.lastTick = now;
    if (this.phase === "entrance") {
      if (!this.entryHit && now >= this.phaseUntil - 1100) {
        this.entryHit = true;
        this.hit(this.challenger, this.champion, "entryKick", 10);
      }
      if (this.phase === "entrance" && now >= this.phaseUntil) {
        this.phase = "fighting";
        this.nextBeat = now + 200;
        this.action("fight", {
          player: this.champion,
          target: this.challenger,
        });
      }
    }
    if (this.phase === "victory" && now >= this.phaseUntil) {
      this.phase = "waiting";
      this.tryEntry();
    }
    if (this.phase === "fighting" && this.musicSource !== "paused") {
      this.boutElapsed += dt;
      for (const id of [this.champion, this.challenger]) {
        const p = this.players.get(id);
        p.healCarry += (dt / 1000) * RULES.maxHealPerSecond;
        const n = Math.min(p.healPool, Math.floor(p.healCarry));
        if (n) {
          p.hp = clamp(p.hp + n, 0, RULES.maxHp);
          p.healPool -= n;
          p.healCarry -= n;
        } else p.healCarry = Math.min(p.healCarry, 1);
      }
      if (this.boutElapsed >= RULES.roundMs) {
        const a = this.players.get(this.champion),
          b = this.players.get(this.challenger),
          w = a.hp >= b.hp ? a : b,
          l = w === a ? b : a;
        this.win(w.id, l.id, "decisão por HP");
      }
    }
    const estimated =
      this.musicSource === "manual" ||
      (this.musicSource === "file" && now - this.lastExternalBeat > 1500);
    if (this.phase === "fighting" && estimated && now >= this.nextBeat)
      this.beat({
        source: this.musicSource === "manual" ? "manual" : "estimated",
      });
    if (this.phase === "waiting") this.tryEntry();
    if (this.notice?.until < now) this.notice = null;
  }
  setMusic({ source, bpm } = {}) {
    if (["manual", "file", "paused"].includes(source))
      this.musicSource = source;
    if (Number.isFinite(bpm)) this.beatMs = 60000 / clamp(bpm, 50, 200);
    this.nextBeat = this.now() + this.beatMs;
    if (source === "file") this.lastExternalBeat = this.now();
  }
  public() {
    const players = [...this.players.values()].map((p) => ({ ...p }));
    const rank = [...players]
      .sort((a, b) => b.wins - a.wins || b.score - a.score)
      .slice(0, 10);
    return {
      version: "0.1.0",
      mode: this.mode,
      serverTime: this.now(),
      phase: this.phase,
      phaseUntil: this.phaseUntil,
      champion: this.champion,
      challenger: this.challenger,
      queue: [...this.queue],
      totalPlayers: players.length,
      players: [
        ...new Map(
          [
            ...players.slice(-120),
            ...players.filter((p) =>
              [
                this.champion,
                this.challenger,
                ...this.queue.slice(0, 25),
              ].includes(p.id),
            ),
          ].map((p) => [p.id, p]),
        ).values(),
      ],
      ranking: rank,
      totals: { ...this.totals },
      notice: this.notice,
      lastAction: this.lastAction,
      recent: this.recent,
      roundMs: RULES.roundMs,
      boutElapsed: this.boutElapsed,
      rhythm: {
        source: this.musicSource,
        effective: this.lastBeatSource,
        bpm: Math.round(60000 / this.beatMs),
        lastBeat: this.lastBeat,
      },
      rules: RULES,
    };
  }
  save() {
    return {
      schema: 1,
      players: [...this.players.values()],
      queue: this.queue,
      champion: this.champion,
      challenger: this.challenger,
      phase: this.phase,
      seq: this.seq,
      inputSeq: this.inputSeq,
      seen: [...this.seen],
      totals: this.totals,
      rng: this.rng,
      boutElapsed: this.boutElapsed,
      entryHit: this.entryHit,
    };
  }
  restore(s) {
    if (s.schema !== 1 || !Array.isArray(s.players)) return;
    for (const p of s.players.slice(-RULES.maxPlayers))
      if (p.id) this.players.set(p.id, { ...p, healCarry: 0 });
    this.queue = (s.queue || []).filter((id) => this.players.has(id));
    this.champion = this.players.has(s.champion) ? s.champion : null;
    this.challenger = this.players.has(s.challenger) ? s.challenger : null;
    this.seq = Number(s.seq) || 0;
    this.inputSeq = Number(s.inputSeq) || 0;
    this.seen = new Map(s.seen || []);
    this.totals = { ...this.totals, ...s.totals };
    this.rng = s.rng || this.rng;
    this.boutElapsed = s.boutElapsed || 0;
    this.entryHit = !!s.entryHit;
    this.phase = this.challenger ? "fighting" : "waiting";
    this.nextBeat = this.now() + 1000;
    this.musicSource = "manual";
    this.notice = {
      text: "Sessão recuperada. HP, fila e ranking preservados.",
      until: this.now() + 6000,
    };
  }
}
