import {test} from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {once} from 'node:events';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtemp,cp,symlink,writeFile,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {LocalTextClient,LocalVoice,localSettings,localClassicPrompt} from '../server/local-ai.js';
import {AISession} from '../server/ai-session.js';
import {wav} from '../server/core.js';

test('IA no aparelho usa personalidade clássica compacta, contexto curto e desliga pensamento',async()=>{
 let sent;const client=new LocalTextClient({request:async(port,route,options)=>{sent={port,route,...options};return {status:200,data:Buffer.from(JSON.stringify({model:'fixture-local',choices:[{message:{content:'<think>interno</think> Bora nessa!'}}]}))};}});
 const result=await client.generate('Qual alien vem depois?',{context:{arena:true,form:'rock',spectatorName:'Ana',alienUnlocks:{next:{name:'Chama',remaining:12}}},history:[{prompt:'antiga',answer:'antiga'},{prompt:'recente',answer:'recente'}]});
 assert.equal(result.text,'Bora nessa!');assert.equal(sent.port,8081);assert.equal(sent.route,'/v1/chat/completions');assert.equal(sent.body.max_tokens,128);assert.equal(sent.body.chat_template_kwargs.enable_thinking,false);assert(sent.body.messages[0].content.includes('Ben Tennyson de dez anos'));assert(sent.body.messages[0].content.length<3000);assert(!JSON.stringify(sent.body).includes('antiga'));assert(!JSON.stringify(sent.body).includes('api_key'));
 assert.throws(()=>localSettings({textPort:0}));assert.throws(()=>localSettings({textPort:8082}));assert(localClassicPrompt().includes('SOMENTE a fala'));
});

test('sessão local responde sem chave, usa memória e não chama Gemini',async()=>{
 let calls=0;const service=new AISession({keys:{key:()=>null,status:()=>({})},getConfig:()=>({conversationProvider:'local'}),client:{generate:()=>{throw Error('Gemini não deve ser chamado');}},localClient:{generate:async(text,options)=>{calls++;if(calls===2)assert.equal(options.history.length,1);return {text:'Bora nessa, equipe!',model:'local-fixture',latency:1};}}});
 assert.equal(service.status().provider,'local');assert.equal(service.status().keyConfigured,false);
 const first=await service.answer({id:'one',user:'Ana',prompt:'oi'},{arena:true});assert.equal(first.mode,'local-ai');assert.equal(service.status().state,'ready');
 await service.answer({id:'two',user:'Ana',prompt:'tudo bem?'},{arena:true});assert.equal(calls,2);
 assert.equal((await service.test()).ok,true);
});

test('Piper recebe somente a frase, valida WAV e reaproveita a mesma fala',async()=>{
 const audio=wav(Buffer.alloc(240));let calls=0;
 const voice=new LocalVoice({request:async(port,route,options)=>{calls++;assert.equal(port,8082);assert.equal(route,'/synthesize');assert.deepEqual(options.body,{text:'E aí, Ana!'});return {status:200,headers:{'content-type':'audio/wav'},data:audio};}});
 const result=await voice.speak('E aí, Ana!');assert.equal(result.provider,'local');assert.equal(result.mime,'audio/wav');assert.deepEqual(Buffer.from(result.audio,'base64'),audio);await voice.speak('E aí, Ana!');assert.equal(calls,1);
 await assert.rejects(()=>new LocalVoice({request:async()=>({status:200,headers:{'content-type':'audio/wav'},data:Buffer.from('invalido')})}).speak('oi'),e=>e.code==='local_voice_response');
});

test('worker Python e integridade dos modelos são exercitados sem download nem Piper real',()=>{
 const result=spawnSync('python3',['-m','unittest','discover','-s','tests','-p','local_ai_py_test.py'],{encoding:'utf8'});assert.equal(result.status,0,result.stderr||result.stdout);
});

test('HTTP: pergunta e voz locais funcionam sem chaves e não mudam para nuvem em falha',{timeout:20000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben42-local-http-')),requests=[],voices=[];let child;
 const llm=http.createServer(async(req,res)=>{assert.equal(req.headers.authorization,undefined);if(req.url==='/health'){res.end(JSON.stringify({status:'ok'}));return;}let raw='';for await(const part of req)raw+=part;const body=JSON.parse(raw);requests.push(body);res.setHeader('content-type','application/json');res.end(JSON.stringify({model:'ben-classico-local',choices:[{message:{content:'Sou o Ben Tennyson! Essa aventura é nossa!'}}]}));});
 const tts=http.createServer(async(req,res)=>{assert.equal(req.headers.authorization,undefined);if(req.url==='/health'){res.end(JSON.stringify({ready:true,model:'fixture-piper'}));return;}let raw='';for await(const part of req)raw+=part;voices.push(JSON.parse(raw));res.setHeader('content-type','audio/wav');res.end(wav(Buffer.alloc(240)));});
 await new Promise(r=>llm.listen(0,'127.0.0.1',r));await new Promise(r=>tts.listen(0,'127.0.0.1',r));
 const gamePort=42000+Math.floor(Math.random()*10000),base='http://127.0.0.1:'+gamePort,get=r=>fetch(base+'/api/'+r).then(r=>r.json()),post=async(r,data)=>{const response=await fetch(base+'/api/'+r,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});return {status:response.status,body:await response.json()};};
 const start=async()=>{child=spawn(process.execPath,['server/index.js'],{cwd:temp,env:{...process.env,PORT:String(gamePort),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw Error('Servidor local não iniciou');})]);};
 try{
  await cp('server',path.join(temp,'server'),{recursive:true});await cp('public',path.join(temp,'public'),{recursive:true});await symlink(path.resolve('node_modules'),path.join(temp,'node_modules'),'dir');await writeFile(path.join(temp,'package.json'),'{"type":"module"}');await start();
  const config=await post('config',{conversationProvider:'local',voiceProvider:'local',hostSpeech:false,localAi:{textPort:llm.address().port,voicePort:tts.address().port}});assert.equal(config.status,200);
  assert.equal((await get('ai-status')).keyConfigured,false);assert.equal((await get('local-ai/health')).ready,true);
  const test=await post('test-ai',{prompt:'Quem é você?'});assert.equal(test.body.ok,true);assert.equal(test.body.mode,'local-ai');assert.equal(test.body.status.provider,'local');
  await post('event',{type:'comment',user:'Ana',text:'Qual seu alien favorito?'});const item=(await get('health')).queue.active;const answer=await post('answer',{id:item.id});assert.equal(answer.body.mode,'local-ai');assert(answer.body.text.includes('Ana'));
  const voice=await post('tts',{text:answer.body.text,speaker:'blaze'});assert.equal(voice.body.provider,'local');assert.equal(voice.body.name,'Ben Tennyson');assert.equal(voice.body.mime,'audio/wav');assert.deepEqual(voices,[{text:answer.body.text}]);assert(requests[0].messages[0].content.includes('Ben Tennyson de dez anos'));
  assert.equal((await post('config',{localAi:{textPort:0}})).status,400);
  llm.closeAllConnections();await new Promise(r=>llm.close(r));const unavailable=await post('test-ai',{prompt:'Qual seu planeta favorito?'});assert.equal(unavailable.body.ok,false);assert.equal(unavailable.body.code,'local_text_offline');assert(!/API|chave/.test(unavailable.body.text));assert.equal((await get('config')).conversationProvider,'local');
  child.kill();await once(child,'exit');await start();assert.equal((await get('config')).voiceProvider,'local');assert.equal((await get('keys')).count,0);
  const saved=JSON.parse(await readFile(path.join(temp,'data/config.json'),'utf8'));assert.equal(saved.conversationProvider,'local');
 }finally{if(child?.exitCode===null){child.kill();await once(child,'exit');}llm.closeAllConnections();tts.closeAllConnections();llm.close();tts.close();await rm(temp,{recursive:true,force:true});}
});
