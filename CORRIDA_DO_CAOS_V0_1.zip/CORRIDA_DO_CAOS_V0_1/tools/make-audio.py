from pathlib import Path
import json,wave,subprocess
import numpy as np
from piper import PiperVoice,SynthesisConfig
ROOT=Path(__file__).resolve().parents[1]
voice=PiperVoice.load(str(ROOT/'tools/voice-model/pt_BR-faber-medium.onnx'))
for name,text in json.loads((ROOT/'tools/voice-lines.json').read_text()).items():
    with wave.open(str(ROOT/'public/assets/voice'/f'{name}.wav'),'wb') as w:
        voice.synthesize_wav(text,w,syn_config=SynthesisConfig(length_scale=.94,noise_scale=.40,noise_w_scale=.28,volume=.8))
    print('Voz:',name,flush=True)
# Original instrumental loop. No commercial recordings or supplied songs included.
sr=22050;bpm=132;beat=60/bpm;duration=beat*64;n=int(duration*sr);out=np.zeros(n)
def add(at,sound):
    start=int(at*sr);length=min(len(sound),n-start)
    if length>0:out[start:start+length]+=sound[:length]
for b in range(64):
    at=b*beat
    if b%4 in (0,2):
        t=np.arange(int(sr*.35))/sr;add(at,.36*np.sin(2*np.pi*(45*t+65*.035*(1-np.exp(-t/.035))))*np.exp(-t*16))
    if b%4 in (1,3):
        rng=np.random.default_rng(b);t=np.arange(int(sr*.18))/sr;add(at,.095*rng.standard_normal(len(t))*np.exp(-t*28))
    for sub in (0,.5):
        rng=np.random.default_rng(b*9+int(sub*2));t=np.arange(int(sr*.055))/sr;noise=rng.standard_normal(len(t));noise=np.concatenate(([0],np.diff(noise)));add(at+sub*beat,.019*noise*np.exp(-t*90))
    note=[45,45,48,43,45,52,48,43][(b//2)%8];freq=440*2**((note-69)/12);t=np.arange(int(sr*beat*.8))/sr
    add(at,.13*np.tanh(1.6*np.sin(2*np.pi*freq*t))*np.minimum(t/.01,1)*np.exp(-t*5))
    if b%2==0:
        note=[69,72,76,67,69,79,76,72][(b//2)%8];freq=440*2**((note-69)/12);t=np.arange(int(sr*beat*.6))/sr
        add(at,.035*(np.sin(2*np.pi*freq*t)+.4*np.sin(2*np.pi*freq*1.49*t))*np.exp(-t*13))
out=out/max(1,np.max(np.abs(out))/.78);pcm=(out*32767).astype('<i2');wav=ROOT/'tools/original-loop.wav'
with wave.open(str(wav),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes(pcm.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-c:a','libmp3lame','-b:a','128k',str(ROOT/'public/assets/music/caos-132.mp3')],check=True)
print('Trilha original pronta.',flush=True)
