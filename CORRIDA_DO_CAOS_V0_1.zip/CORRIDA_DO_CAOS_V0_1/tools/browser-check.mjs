import {fileURLToPath} from 'node:url';
const {chromium}=await import('playwright-core').catch(()=>import(process.env.PLAYWRIGHT_MODULE||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core/index.mjs'));
import {writeFile,mkdtemp,rm} from 'node:fs/promises';import {spawn} from 'node:child_process';import {once} from 'node:events';import os from 'node:os';import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url)).replace(/\/$/,''),data=await mkdtemp(path.join(os.tmpdir(),'caos-browser-')),port=37942,url='http://127.0.0.1:'+port,server=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),CORRIDA_DATA_DIR:data},stdio:'ignore'});
for(let i=0;i<150;i++){try{if((await fetch(url+'/api/health')).ok)break;}catch{}await new Promise(r=>setTimeout(r,30));}
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:430,height:932},deviceScaleFactor:1});const errors=[],failed=[];page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>failed.push({url:r.url(),error:r.failure()?.errorText}));
try{
 await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.caos?.state,{timeout:60000});
 await page.screenshot({path:root+'/docs/PREVIA_INICIO.png'});
 await page.getByRole('button',{name:'TESTAR COM SOM'}).click();await page.waitForFunction(()=>window.caos.state?.running);
 await page.waitForFunction(()=>window.caos.state.phase==='racing',{timeout:30000});
 const first=await page.evaluate(()=>({phase:caos.state.phase,progress:caos.state.racers[0]?.progress,audio:!document.getElementById('music').paused,voiceFiles:document.getElementById('speech-audio').currentSrc,meshes:caos.world.scene.meshes.length}));
 await page.evaluate(()=>caos.api('test-event',{type:'comment',user:'foto_teste',name:'Você na pista',text:'EU',avatar:null,id:'browser-entry'}));
 await page.evaluate(()=>caos.api('test-event',{type:'gift',user:'demo_luna',name:'Luna · DEMO',gift:'Rosa',repeatEnd:true,count:1,id:'browser-rose'}));
 await page.waitForTimeout(2200);await page.screenshot({path:root+'/docs/PREVIA_CORRIDA.png'});
 const second=await page.evaluate(()=>({progress:caos.state.racers[0]?.progress,queue:caos.state.queueTotal,boost:caos.state.racers.some(r=>r.boostUntil>caos.state.serverTime),labels:document.querySelectorAll('.runner-label').length}));
 if(!(second.progress>first.progress))throw Error('Race did not advance');
 await page.evaluate(()=>{document.getElementById('music').pause();});await page.waitForTimeout(1300);
 const third=await page.evaluate(()=>caos.state.racers[0]?.progress);if(!(third>second.progress))throw Error('Race stopped when music paused');
 await page.getByRole('button',{name:'Abrir controles'}).click();await page.getByRole('button',{name:'Apresentador',exact:true}).click();await page.waitForTimeout(2100);await page.screenshot({path:root+'/docs/PREVIA_CONTROLES.png'});
 await page.getByRole('button',{name:'Fechar',exact:true}).click();
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);if(overflow)throw Error('Horizontal overflow');
 await page.waitForFunction(()=>window.caos.state.phase==='podium',{timeout:45000});await page.screenshot({path:root+'/docs/PREVIA_PODIO.png'});
 const final=await page.evaluate(()=>({results:caos.state.results.length,rank:caos.state.ranking,mode:caos.state.mode,fps:caos.world.fps}));
 const speechAfterRestart=await page.evaluate(()=>{caos.receiveSpeech({id:9999,text:'Fala anterior',kind:'notice',at:Date.now()});caos.applyState({...caos.state,bootId:'restart-fixture',speech:{id:1,text:'Voz pronta após reinício',kind:'notice',at:Date.now(),until:Date.now()+5000}});return document.getElementById('caption').innerText.includes('Voz pronta após reinício');});if(!speechAfterRestart)throw Error('Speech sequence did not reset on reconnection');
 const report={ok:!errors.length&&!failed.length,errors,failed,first,second,progressAfterMusicPause:third,overflow,final,speechAfterRestart,measuredIn:'Cloud Chromium software WebGL; not a Realme GT3 benchmark'};await writeFile(root+'/docs/BROWSER_CHECK.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));if(errors.length||failed.length)throw Error('Browser errors');
}finally{await browser.close();if(server.exitCode===null){const done=once(server,'exit');server.kill('SIGTERM');await done;}await rm(data,{recursive:true,force:true});}
