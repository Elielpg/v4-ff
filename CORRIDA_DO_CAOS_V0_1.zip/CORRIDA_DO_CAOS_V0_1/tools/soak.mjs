import {RaceEngine} from '../server/engine.mjs';import {performance} from 'node:perf_hooks';import {writeFile} from 'node:fs/promises';
let now=1000000;const e=new RaceEngine({now:()=>now});const names=Array.from({length:18},(_,i)=>'sim_'+i),start=performance.now(),before=process.memoryUsage().rss;let lastRound=0,actions=0;e.onAction=()=>actions++;
for(let step=0;step<144000;step++){
 now+=50;if(e.phase==='lobby'&&e.round!==lastRound){lastRound=e.round;for(const user of names)e.ingest({type:'comment',user,text:'EU'});}
 if(step%20===0)e.ingest({type:'like',user:names[step%18],count:5,id:'l'+step});
 if(step%193===0)e.ingest({type:'gift',user:names[step%18],gift:'Rosa',repeatEnd:true,count:3,id:'g'+step});
 e.tick();if(step%4===0)JSON.stringify(e.public());
}
if(e.queue.length>100||e.seen.size>3000||e.racers.length>12)throw Error('Limite excedido');
const result={simulatedSeconds:7200,elapsedMs:performance.now()-start,rounds:e.round,actions,players:e.players.size,queue:e.queue.length,racers:e.racers.length,dedupEntries:e.seen.size,rssBefore:before,rssAfter:process.memoryUsage().rss,note:'Simulação acelerada da lógica Node no computador de desenvolvimento; não mede duas horas reais no Android, GPU, temperatura ou IA.'};await writeFile(new URL('../docs/SOAK_ENGINE.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
