import {MascotFactory} from './mascots.js';
import {clamp,obstacleX} from './rules.js';
const B=BABYLON,V=B.Vector3,C=B.Color3;
const center=z=>Math.sin(z*.043)*2.2;
export class RaceWorld{
 constructor(canvas,labelLayer){
  this.canvas=canvas;this.labelLayer=labelLayer;this.engine=new B.Engine(canvas,true,{adaptToDeviceRatio:false,powerPreference:'high-performance'});this.scene=new B.Scene(this.engine);
  this.scene.clearColor=new B.Color4(.08,.16,.25,1);this.scene.fogMode=B.Scene.FOGMODE_EXP2;this.scene.fogDensity=.009;this.scene.fogColor=new C(.12,.22,.3);
  this.camera=new B.FreeCamera('camera',new V(8,19,23),this.scene);this.camera.minZ=.1;this.camera.maxZ=250;this.camera.fov=.79;this.camera.inputs.clear();this.camera.setTarget(new V(0,0,4));
  const hemi=new B.HemisphericLight('sky',new V(0,1,0),this.scene);hemi.intensity=.60;hemi.groundColor=new C(.15,.18,.25);
  const sun=new B.DirectionalLight('sun',new V(-.4,-1,.3),this.scene);sun.position=new V(12,35,-8);sun.intensity=.62;sun.diffuse=new C(1,.91,.76);
  this.scene.imageProcessingConfiguration.toneMappingEnabled=true;this.scene.imageProcessingConfiguration.toneMappingType=B.ImageProcessingConfiguration.TONEMAPPING_ACES;this.scene.imageProcessingConfiguration.exposure=.9;
  this.shadow=new B.ShadowGenerator(512,sun);this.shadow.useBlurExponentialShadowMap=true;this.shadow.blurKernel=8;this.shadow.normalBias=.03;
  this.factory=new MascotFactory(this.scene,this.camera,this.shadow);this.materials=new Map();this.actors=new Map();this.labels=new Map();this.obstacles=[];this.fx=[];this.clouds=[];this.time=0;this.beatAt=-9;this.strength=.5;this.focus=0;this.lastSeq=0;this.reduceMotion=false;this.fps=60;this.quality='balanced';this.mapKey='';this.roundKey=-1;this.lastAuto=0;
  this.build();this.mergeScenery();this.setQuality(localStorage.getItem('caos-quality')||'balanced');window.addEventListener('resize',()=>this.engine.resize());this.engine.runRenderLoop(()=>this.render());
 }
 mat(name,color,emissive=0){if(this.materials.has(name))return this.materials.get(name);const m=new B.StandardMaterial(name,this.scene);m.diffuseColor=C.FromHexString(color);m.specularColor=new C(.05,.06,.08);m.emissiveColor=m.diffuseColor.scale(emissive);this.materials.set(name,m);return m;}
 mergeScenery(){const names=new Set(['track','underside','bumper','lane-mark','island','island-moss','palm','leaf','foam','ocean','start-column','start-arch','finish-column','finish-arch','podium-island']),groups=new Map();for(const m of this.scene.meshes){if(!names.has(m.name))continue;const key=m.material.uniqueId+':'+!!m.receiveShadows;const list=groups.get(key)||[];list.push(m);groups.set(key,list);}for(const list of groups.values())if(list.length>1){const shadow=list[0].receiveShadows,m=B.Mesh.MergeMeshes(list,true,true,undefined,false,false);if(m){m.name='scenery-batch';m.receiveShadows=shadow;m.freezeWorldMatrix();}}}
 box(name,size,pos,material,parent){const m=B.MeshBuilder.CreateBox(name,{width:size[0],height:size[1],depth:size[2]},this.scene);m.position.set(...pos);m.material=material;m.parent=parent||null;return m;}
 sphere(name,size,pos,material,parent){const m=B.MeshBuilder.CreateSphere(name,{diameter:1,segments:8},this.scene);m.scaling.set(...size);m.position.set(...pos);m.material=material;m.parent=parent||null;return m;}
 build(){
  this.deckMat=this.mat('sand','#f4d69a');this.edgeMat=this.mat('mint','#27d9c0',.1);this.coral=this.mat('coral','#ff796f',.15);this.cream=this.mat('cream','#fff3d4');this.dark=this.mat('ink','#22334b');this.yellow=this.mat('gold','#ffcd66',.15);this.oceanMat=this.mat('ocean','#1a7286',.12);
  const ocean=this.box('ocean',[180,.3,220],[0,-5,52],this.oceanMat);ocean.receiveShadows=false;
  this.road=[];for(let z=-8;z<=108;z+=4){const x=center(z);const deck=this.box('track',[8,.45,4.08],[x,-.28,z],this.deckMat);deck.receiveShadows=true;this.road.push(deck);this.box('underside',[8.3,.25,4.1],[x,-.64,z],this.dark);for(const side of [-1,1]){this.box('bumper',[.16,.20,4.1],[x+side*4.02,.02,z],this.edgeMat);if(z%8===0)this.box('lane-mark',[.045,.012,1],[x+side*2,.015,z],this.cream);} }
  const lineTex=new B.DynamicTexture('finish-checker',{width:256,height:64},this.scene,false),c=lineTex.getContext();for(let x=0;x<16;x++)for(let y=0;y<4;y++){c.fillStyle=(x+y)%2?'#fff6df':'#263247';c.fillRect(x*16,y*16,16,16);}lineTex.update();const lm=new B.StandardMaterial('checker',this.scene);lm.diffuseTexture=lineTex;lm.emissiveTexture=lineTex;lm.specularColor=C.Black();this.box('finish-line',[7.8,.018,1.45],[center(100),.018,100],lm);
  for(const side of[-1,1]){this.box('finish-column',[.35,4.3,.45],[center(100)+side*4.3,2.1,101],this.edgeMat);this.box('start-column',[.25,3.4,.35],[center(-3)+side*4.2,1.6,-3],this.coral);}this.box('finish-arch',[9,.42,.45],[center(100),4.2,101],this.yellow);this.sign('CHEGADA',center(100),4.2,101,4.7,.8);this.box('start-arch',[8.8,.38,.4],[center(-3),3.25,-3],this.edgeMat);this.sign('LARGADA',center(-3),3.27,-3,3.8,.7);
  this.box('podium-island',[11,.6,9],[center(112),-.35,112],this.deckMat);for(const [i,x,h]of [[0,0,1],[1,-2.4,.62],[2,2.4,.3]]){this.box('podium-'+i,[2,.3+h,2],[center(112)+x,h/2,112],i===0?this.yellow:i===1?this.edgeMat:this.coral);this.sign(String(i+1),center(112)+x,h*.5,113.01,.65,.6);}
  // Stylised islands and palms remain outside the racers' line of sight.
  for(let i=0;i<24;i++){
   const z=-8+i*5.6,side=i%2?1:-1,x=center(z)+side*(8+(i%4)*2.2);const island=this.sphere('island',[5.3,1.5,5.7],[x,-2.5,z],this.deckMat);this.sphere('island-moss',[4.7,.5,5.1],[x,-1.75,z],this.edgeMat);
   const trunk=B.MeshBuilder.CreateCylinder('palm',{height:3.6,diameterTop:.15,diameterBottom:.32,tessellation:6},this.scene);trunk.position.set(x,-.12,z);trunk.rotation.z=side*.12;trunk.material=this.mat('trunk','#a4745b');
   for(let k=0;k<5;k++){const leaf=this.sphere('leaf',[.65,.17,2.7],[x+Math.sin(k*1.26)*.7,1.75,z+Math.cos(k*1.26)*.7],this.edgeMat);leaf.rotation.y=k*1.26;leaf.rotation.x=.15;}
  }
  const cloudMat=this.mat('cloud','#e9e9e2',.2);cloudMat.alpha=.65;for(let i=0;i<14;i++){const m=this.sphere('cloud',[5+i%3,1.2,3],[(i%2?1:-1)*(19+i%4*3),7+i%3,-10+i*10],cloudMat);this.clouds.push(m);}
  for(let i=0;i<32;i++){const m=this.sphere('foam',[2.2,.025,.11],[((i*17)%70)-35,-4.7,-15+i*5.2],this.cream);m.visibility=.25;}
  for(let i=0;i<30;i++){const m=this.box('confetti',[.10,.10,.10],[0,-20,0],i%3===0?this.yellow:i%3===1?this.coral:this.edgeMat);m.setEnabled(false);this.fx.push({mesh:m,at:-10,vx:0,vy:0,vz:0});}
 }
 sign(text,x,y,z,w,h){const tx=new B.DynamicTexture('sign-'+text,{width:512,height:128},this.scene,false);const c=tx.getContext();c.fillStyle='#22334b';c.fillRect(0,0,512,128);c.font='bold 70px sans-serif';c.fillStyle='#fff3d4';c.textAlign='center';c.fillText(text,256,90);tx.update();const mat=new B.StandardMaterial('sign-'+text,this.scene);mat.diffuseTexture=mat.emissiveTexture=tx;mat.disableLighting=true;mat.backFaceCulling=false;const m=B.MeshBuilder.CreatePlane('sign',{width:w,height:h},this.scene);m.position.set(x,y,z+.24);m.material=mat;m.rotation.y=Math.PI;return m;}
 setQuality(q){if(!['low','balanced','high'].includes(q))q='balanced';this.quality=q;const dpr=window.devicePixelRatio||1;this.engine.setHardwareScalingLevel(q==='low'?1.25:1/Math.min(dpr,q==='high'?1.8:1.25));this.scene.shadowsEnabled=q!=='low';this.factory.profile='low';localStorage.setItem('caos-quality',q);this.engine.resize();}
 update(state){if(state.phase==='podium'&&this.state?.phase!=='podium'){const x=center(112);this.focus=110;this.camera.position.set(x+3,9,127);for(const a of this.actors.values())a.fresh=true;}this.state=state;this.received=performance.now();if(this.mapKey!==state.map.name){this.mapKey=state.map.name;this.deckMat.diffuseColor=C.FromHexString(state.map.deck);this.edgeMat.diffuseColor=C.FromHexString(state.map.edge);this.coral.diffuseColor=C.FromHexString(state.map.accent);this.scene.clearColor=B.Color4.FromHexString(state.map.sky+'ff');this.scene.fogColor=C.FromHexString(state.map.sky);}
  if(this.roundKey!==state.round){this.roundKey=state.round;for(const o of this.obstacles)o.root.dispose();this.obstacles=state.track.map(o=>this.buildObstacle(o));}
 }
 buildObstacle(o){const root=new B.TransformNode('obstacle-'+o.id,this.scene);root.position.set(center(o.z),0,o.z);let arm,hammer;
  if(o.kind==='sweeper'){this.box('sweeper-base',[.3,.3,.3],[0,.12,0],this.dark,root);arm=this.box('swinging-bumper',[2,.44,.5],[0,.35,0],this.coral,root);for(const side of[-1,1])this.sphere('end-cap',[.45,.45,.45],[side*.95,.36,0],this.yellow,arm);}
  else if(o.kind==='hammers'){for(const side of[-1,1]){this.box('hammer-frame',[.25,3.3,.3],[side*3.6,1.6,0],this.dark,root);}this.box('hammer-beam',[7.4,.25,.35],[0,3.2,0],this.edgeMat,root);hammer=this.box('bonk-hammer',[2.7,.65,1.0],[0,2.4,0],this.coral,root);}
  else{arm=this.box('jump-pad',[2.5,.12,1.6],[0,.07,0],this.yellow,root);for(let k=0;k<3;k++){const m=this.box('turbo-chevron',[.15,.03,.5],[0,.15,-.45+k*.4],this.dark,arm);m.rotation.y=.7;}}
  return {...o,root,arm,hammer};
 }
 actor(p){let a=this.actors.get(p.id);if(a)return a;a=this.factory.mascot(p,true);a.label.setEnabled(false);a.root.scaling.setAll(.75);a.pos=new V(0,0,0);a.root.position.copyFrom(a.pos);a.emitter=this.sphere('turbo-orb',[.24,.24,.24],[0,.4,-.42],this.yellow,a.root);a.emitter.setEnabled(false);this.shadow.addShadowCaster(a.torso);for(const m of a.head.getChildMeshes())if(m.name==='crânio')this.shadow.addShadowCaster(m);
  const el=document.createElement('div');el.className='runner-label';el.dataset.user=p.id;const pic=document.createElement('img');pic.alt='';pic.referrerPolicy='no-referrer';const initial=document.createElement('b');initial.textContent=p.name.slice(0,1).toUpperCase();const name=document.createElement('span');name.textContent=p.name;el.append(pic,initial,name);if(p.avatar){pic.src=p.avatar;pic.onerror=()=>{pic.hidden=true;};}else pic.hidden=true;el.classList.toggle('npc',!!p.npc);this.labelLayer.append(el);a.el=el;this.actors.set(p.id,a);return a;}
 burst(id){const a=this.actors.get(id);if(!a)return;let i=0;for(const f of this.fx){if(this.time-f.at<1.2)continue;f.at=this.time;f.origin=a.root.position.clone().add(new V(0,1,0));f.vx=Math.sin(i*2.4)*2;f.vz=Math.cos(i*2.4)*2;f.vy=2+i%4*.5;f.mesh.setEnabled(true);if(++i>=12)break;}}
 action(a){if(a.seq<=this.lastSeq)return;this.lastSeq=a.seq;if(['gift','collective','podium','finish','hit','entry'].includes(a.kind)){if(a.user)this.burst(a.user);else for(const id of [...this.actors.keys()].slice(0,3))this.burst(id);}if(a.kind==='gift'){this.giftFocus={id:a.user,until:this.time+2.5};}}
 beat(strength=.5){this.beatAt=this.time;this.strength=strength;}
 render(){const dt=Math.min(.25,this.engine.getDeltaTime()/1000||.016);this.time+=dt;const s=this.state;if(!s){this.scene.render();return;}const now=s.serverTime+(performance.now()-this.received),time=(now-s.startedAt)/1000;
  const pulse=Math.max(0,1-(this.time-this.beatAt)/.22)*this.strength;
  const source=s.phase==='racing'||s.phase==='podium'?s.racers:s.queue.length?s.queue.slice(0,12):Array.from({length:4},(_,i)=>({id:'npc:lobby:'+i,name:['Pipoca','Soneca','Foguinho','Trombada'][i],archetype:['fox','hippo','raccoon','ram'][i],seed:i*65,npc:true}));
  const ids=new Set(source.map(p=>p.id));for(const [id,a]of this.actors)if(!ids.has(id)){a.el.remove();a.dispose();this.actors.delete(id);}
  const podium=s.phase==='podium',list=s.phase==='racing'?[...source].sort((a,b)=>b.progress-a.progress):source;
  let focus=s.phase==='racing'?Math.max(0,list[0]?.progress||0):podium?110:0;this.focus+=(focus-this.focus)*Math.min(1,dt*(podium?3:1.8));
  for(let i=0;i<source.length;i++){
   const p=source[i],a=this.actor(p);let z=s.phase==='lobby'?-Math.floor(i/6)*1.35:(p.progress||0),x=s.phase==='lobby'?(i%6-2.5)*1.08:p.x||0,y=.14;
   if(podium){const place=s.results.findIndex(r=>r.id===p.id);if(place<3){z=112;x=[0,-2.4,2.4][place];y=[1.4,1.0,.68][place];}else{z=108-Math.floor((place-3)/6)*1.5;x=((place-3)%6-2.5)*1.05;}}
   if(p.jumpUntil>now)y+=Math.sin(clamp((p.jumpUntil-now)/650,0,1)*Math.PI)*.75;
   const run=s.phase==='racing'&&!p.finishAt,cycle=this.time*(p.boostUntil>now?19:13)+(p.seed||0),swing=Math.sin(cycle),hit=p.anim?.kind==='tumble'&&p.anim.until>now,dance=podium||p.anim?.kind==='dance'&&p.anim.until>now;
   if(run)y+=Math.abs(Math.sin(cycle))*.055;else if(dance)y+=Math.max(0,Math.sin(cycle*.45))*.14;
   const target=new V(center(z)+x,y,z);if(a.fresh!==false){a.root.position.copyFrom(target);a.fresh=false;}else a.root.position=B.Vector3.Lerp(a.root.position,target,Math.min(1,dt*12));
   a.root.rotation.set(hit?0:run?-.10:0,run?Math.sin(this.time*.4+p.seed)*.04:Math.sin(this.time*.8+p.seed)*.14,hit?Math.sin((p.anim.until-now)/900*Math.PI*2)*1.15:dance?Math.sin(cycle*.4)*.10:0);
   a.head.rotation.y=dance?Math.sin(cycle*.3)*.15:Math.sin(cycle*.5)*.025;a.torso.scaling.y=1.2+(run?Math.sin(cycle*2)*.025:0);
   for(const l of a.legs){const v=run?swing*l.side: dance?Math.sin(cycle*.4)*l.side:.05;const knee=[l.side*.17,.36,v*.11],foot=[l.side*.2,.08,v*.22];this.factory.link(l.upper,[l.side*.17,.65,0],knee);this.factory.link(l.lower,knee,foot);l.foot.position.set(...foot);}
   for(const arm of a.arms){const v=run?-swing*arm.side:dance?Math.sin(cycle*.4+arm.side):.1,elbow=[arm.side*(dance?.48:.40),dance?1.28+v*.13:.98,v*.10],hand=[arm.side*(dance?.56:.4),dance?1.48+v*.15:.80,v*.22+.12];this.factory.link(arm.upper,[arm.side*.30,1.16,0],elbow);this.factory.link(arm.lower,elbow,hand);arm.glove.position.set(...hand);}
   const turbo=p.boostUntil>now;a.emitter.setEnabled(turbo);a.emitter.scaling.setAll(.7+pulse*.5);a.el.classList.toggle('turbo',turbo);a.el.classList.toggle('winner',podium&&s.roundWinner===p.id);
   const pos=V.Project(a.root.position.add(new V(0,1.72,0)),B.Matrix.Identity(),this.scene.getTransformMatrix(),this.camera.viewport.toGlobal(this.engine.getRenderWidth(),this.engine.getRenderHeight()));const xCss=pos.x/this.engine.getRenderWidth()*this.canvas.clientWidth,yCss=pos.y/this.engine.getRenderHeight()*this.canvas.clientHeight;
   a.el.style.transform=`translate(${xCss.toFixed(1)}px,${yCss.toFixed(1)}px) translate(-50%,-100%)`;a.el.style.visibility=pos.z>0&&pos.z<1&&yCss>145&&yCss<this.canvas.clientHeight-140&&xCss>0&&xCss<this.canvas.clientWidth?'visible':'hidden';
  }
  for(const o of this.obstacles){if(o.arm)o.arm.position.x=obstacleX(o,time);if(o.hammer){o.hammer.position.y=.65+Math.abs(Math.sin(time*2+o.phase))*2.2;o.hammer.position.x=Math.sin(time*.8+o.phase)*2.1;}}
  for(const f of this.fx){const age=this.time-f.at;if(age>1.2){f.mesh.setEnabled(false);continue;}if(f.origin){f.mesh.position.set(f.origin.x+f.vx*age,f.origin.y+f.vy*age-2.5*age*age,f.origin.z+f.vz*age);f.mesh.rotation.set(age*6,age*4,age*8);f.mesh.visibility=1-age/1.2;}}
  for(const m of this.factory.toonMaterials){m.setVector3('eyePosition',this.camera.position);m.setFloat('pulse',this.reduceMotion?0:pulse);}
  for(let i=0;i<this.clouds.length;i++)this.clouds[i].position.x+=Math.sin(this.time*.1+i)*dt*.04;
  const cx=center(this.focus),target=new V(cx,podium?1:0,podium?112:this.focus+3),cam=new V(cx+(podium?3:7.5),podium?9:18,podium?127:this.focus+23);
  this.camera.position=V.Lerp(this.camera.position,cam,Math.min(1,dt*2.5));this.camera.setTarget(target);this.camera.fov=.79-(this.reduceMotion?0:pulse*.008);
  this.scene.render();this.fps=this.engine.getFps();if(this.time-this.lastAuto>12&&this.time>15&&this.fps<27&&this.engine.getHardwareScalingLevel()<1.7){this.lastAuto=this.time;this.engine.setHardwareScalingLevel(Math.min(1.7,this.engine.getHardwareScalingLevel()+.15));}
 }
}
