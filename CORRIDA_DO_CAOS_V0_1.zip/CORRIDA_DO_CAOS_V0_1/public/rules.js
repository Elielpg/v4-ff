export const VERSION='0.1.0';
export const RULES={lobbyMs:10000,raceMs:35000,podiumMs:6500,maxRacers:12,maxQueue:100,maxPlayers:2000,finish:100,likeGoal:150,freeBoostCooldown:8000,roseBoostMs:2500,maxBoostMs:6000};
export const SPECIES=['fox','hippo','raccoon','ram'];
export const MAPS=[{name:'ILHAS DO CAOS',sky:'#142b48',deck:'#f4d69a',edge:'#27d9c0',accent:'#ff796f'},{name:'NOITE ELÉTRICA',sky:'#10142e',deck:'#403a73',edge:'#b9fa57',accent:'#bc81fc'},{name:'PÔR DO SOL',sky:'#603e68',deck:'#eec09b',edge:'#62d9eb',accent:'#ffab61'}];
export function hash(s){let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);h=Math.imul(h^(h>>>16),0x85ebca6b);h=Math.imul(h^(h>>>13),0xc2b2ae35);return (h^(h>>>16))>>>0;}
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export function track(round=1){return [14,29,44,61,77,90].map((z,i)=>({id:i,z,kind:['sweeper','hammers','pads','sweeper','hammers','pads'][(i+(round%3))%6],phase:((round*17+i*41)%100)/100*Math.PI*2}));}
export function obstacleX(o,t){return Math.sin(t*1.8+o.phase)*2.45;}
export function giftEffect(name,id){const n=String(name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();if(/rose|rosa/.test(n)||Number(id)===5655)return 'turbo';if(/heart|coracao|love/.test(n))return 'shield';if(/galax|lion|leao|confetti|confete|rocket|foguete|lightning/.test(n))return 'wind';return 'sparkle';}
