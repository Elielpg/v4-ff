import {toonMaterial} from './toon.js';
const B=BABYLON,V=B.Vector3,C=B.Color3;
// Original Pulso Arena mascots, adapted for the independent racing project.
export class MascotFactory {
 constructor(scene,camera,shadow){Object.assign(this,{scene,camera,shadow,materials:new Map(),toonMaterials:new Set(),slots:[],profile:'low',attackTracks:new Map(),hitTracks:new Map(),blinks:new Map()});}
  mat(n, hex, emit = 0, alpha = 1) {
    if (this.materials.has(n)) return this.materials.get(n);
    const m = new B.StandardMaterial(n, this.scene);
    m.diffuseColor = C.FromHexString(hex);
    m.specularColor = new C(0.08, 0.08, 0.08);
    m.emissiveColor = m.diffuseColor.scale(emit);
    m.alpha = alpha;
    m.maxSimultaneousLights = 4;
    this.materials.set(n, m);
    return m;
  }
  toon(n, color) {
    const key = "toon-" + n;
    if (!this.materials.has(key)) this.materials.set(key, toonMaterial(this, key, color));
    const material = this.materials.get(key);
    return material.fallbackMaterial || material;
  }
  box(n, sz, m, parent, pos = [0, 0, 0]) {
    const q = B.MeshBuilder.CreateBox(
      n,
      { width: sz[0], height: sz[1], depth: sz[2] },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    return q;
  }
  ball(n, d, m, parent, pos = [0, 0, 0], scale = [1, 1, 1], segments = 12) {
    const q = B.MeshBuilder.CreateSphere(
      n,
      { diameter: d, segments },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    q.scaling.set(...scale);
    return q;
  }
  cylinder(n, d, h, m, parent, pos = [0, 0, 0], tess = 12) {
    const q = B.MeshBuilder.CreateCylinder(
      n,
      { diameter: d, height: h, tessellation: tess },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    return q;
  }
  node(n, p) {
    const x = new B.TransformNode(n, this.scene);
    x.parent = p || null;
    return x;
  }
  link(o, a, b) {
    const aa = V.FromArray(a),
      bb = V.FromArray(b),
      d = bb.subtract(aa),
      len = d.length(),
      dir = d.scale(1 / Math.max(len, 0.0001)),
      axis = V.Cross(B.Axis.Y, dir),
      dot = Math.max(-1, Math.min(1, V.Dot(B.Axis.Y, dir)));
    o.position.copyFrom(V.Lerp(aa, bb, 0.5));
    o.scaling.y = len;
    o.rotationQuaternion =
      axis.lengthSquared() < 1e-8
        ? B.Quaternion.RotationAxis(B.Axis.X, dot < 0 ? Math.PI : 0)
        : B.Quaternion.RotationAxis(axis.normalize(), Math.acos(dot));
  }
  smileMaterial() {
    if (this.materials.has("sorriso")) return this.materials.get("sorriso");
    const tx = new B.DynamicTexture("sorriso", { width: 256, height: 96 }, this.scene, false);
    tx.hasAlpha = true;
    const c = tx.getContext();
    c.clearRect(0, 0, 256, 96);
    c.beginPath(); c.moveTo(14, 20); c.quadraticCurveTo(125, 60, 242, 5);
    c.quadraticCurveTo(170, 123, 14, 20); c.closePath();
    c.fillStyle = "#fff5db"; c.fill(); c.strokeStyle = "#171c30"; c.lineWidth = 12; c.stroke();
    tx.update();
    const m = new B.StandardMaterial("sorriso", this.scene);
    m.diffuseTexture = m.emissiveTexture = tx;
    m.disableLighting = true; m.useAlphaFromDiffuseTexture = true; m.backFaceCulling = false;
    this.materials.set("sorriso", m);
    return m;
  }
  face(kind) {
    const key = "rosto-" + kind;
    if (this.materials.has(key)) return this.materials.get(key);
    const tx = new B.DynamicTexture(
        key,
        { width: 512, height: 256 },
        this.scene,
        false,
      ),
      c = tx.getContext();
    tx.hasAlpha = true;
    c.clearRect(0, 0, 512, 256);
    for (const side of [-1, 1]) {
      const x = 256 + side * 133;
      c.strokeStyle = "#161523";
      c.lineWidth = 13;
      c.lineCap = "round";
      if (kind === "ko") {
        c.beginPath();
        c.moveTo(x - 40, 76);
        c.lineTo(x + 40, 138);
        c.moveTo(x + 40, 76);
        c.lineTo(x - 40, 138);
        c.stroke();
        continue;
      }
      c.fillStyle = "#fff4df";
      c.beginPath();
      c.moveTo(x - 73, 116);
      c.quadraticCurveTo(x, kind === "happy" ? 28 : 60, x + 73, 86);
      c.quadraticCurveTo(x, kind === "happy" ? 173 : 151, x - 73, 116);
      c.fill();
      c.fillStyle = "#242239";
      c.beginPath();
      c.ellipse(x + side * 4, 106, 21, 32, 0, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = "#fff";
      c.beginPath();
      c.arc(x - 5, 89, 9, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = "#232135";
      c.lineWidth = 14;
      c.beginPath();
      c.moveTo(x - 65, 41 - side * 12);
      c.lineTo(x + 62, 45 + side * 12);
      c.stroke();
    }
    tx.update();
    const m = new B.StandardMaterial(key, this.scene);
    m.diffuseTexture = tx;
    m.emissiveTexture = tx;
    m.emissiveColor = new C(0.18, 0.18, 0.18);
    m.useAlphaFromDiffuseTexture = true;
    m.backFaceCulling = false;
    m.specularColor = C.Black();
    this.materials.set(key, m);
    return m;
  }
  mascot(p, small) {
    const root = this.node(p.id),
      head = this.node("cabeça", root),
      type = p.archetype || "fox";
    head.position.y = 1.46;
    const bodyColors = {
        fox: "#ee8548",
        hippo: "#a681d5",
        raccoon: "#6ca7ba",
        ram: "#d9b991",
      },
      body = this.toon(type, bodyColors[type]),
      cream = this.toon("creme", "#f1d9b7"),
      black = this.toon("preto", "#172138");
    const hue = (p.seed % 360) / 360,
      color = C.FromHSV(hue * 360, 0.65, 0.95),
      gloves = toonMaterial(this, "luvas-" + p.id, color);
    const locals = [gloves];
    const torso = this.ball(
      "corpo",
      0.7,
      body,
      root,
      [0, 0.87, 0],
      [type === "hippo" ? 1.35 : 1, 1.2, 0.76],
      small ? 10 : 18,
    );
    // Original mascot species, now in a competitive anime outfit.
    const belt = this.cylinder("faixa-cintura", type === "hippo" ? 0.79 : 0.6, 0.12, gloves, root, [0, 0.64, 0]);
    belt.scaling.z = 0.75;
    this.ball("emblema-pulso", 0.13, cream, root, [0, 0.99, 0.315], [0.8, 1.2, 0.25], 8);
    const headband = this.cylinder("bandana", type === "hippo" ? 0.91 : 0.78, 0.07, gloves, head, [0, 0.245, 0]);
    headband.scaling.z = 0.9;
    if (!small) {
      for (const s of [-1, 1]) {
        this.ball("ombreira", 0.23, gloves, root, [s * 0.32, 1.13, 0], [1.2, 0.75, 1], 12);
        const ribbon = this.box("ponta-bandana", [0.08, 0.34, 0.035], gloves, head, [s * 0.13, 0.03, -0.36]);
        ribbon.rotation.z = s * 0.45;
      }
    }
    this.ball(
      "colete",
      0.59,
      black,
      root,
      [0, 0.96, 0.07],
      [type === "hippo" ? 1.4 : 1.13, 1.25, 0.73],
      small ? 10 : 18,
    );
    this.ball(
      "crânio",
      type === "hippo" ? 0.93 : 0.79,
      body,
      head,
      [0, 0, 0],
      [type === "hippo" ? 1.08 : 1, 1, 0.9],
      small ? 12 : 24,
    );
    if (type === "fox") {
      for (const side of [-1, 1]) {
        const ear = B.MeshBuilder.CreateCylinder(
          "orelha",
          {
            diameterTop: 0,
            diameterBottom: 0.32,
            height: 0.53,
            tessellation: 3,
          },
          this.scene,
        );
        ear.parent = head;
        ear.position.set(side * 0.25, 0.42, -0.02);
        ear.rotation.z = side * -0.22;
        ear.material = body;
        const inside = this.ball(
          "dentro-orelha",
          0.2,
          cream,
          head,
          [side * 0.25, 0.43, 0.07],
          [0.7, 1.2, 0.3],
          8,
        );
      }
      const tail = B.MeshBuilder.CreateTube(
        "cauda",
        {
          path: [
            new V(0, 0.43, -0.2),
            new V(0.1, 0.43, -0.65),
            new V(0.25, 0.78, -0.94),
          ],
          radius: 0.14,
          tessellation: 10,
        },
        this.scene,
      );
      tail.parent = root;
      tail.material = body;
      this.ball(
        "ponta-cauda",
        0.29,
        cream,
        root,
        [0.25, 0.78, -0.94],
        [1, 1.1, 1],
        8,
      );
    }
    if (type === "raccoon") {
      for (const side of [-1, 1]) {
        this.ball(
          "orelha",
          0.24,
          body,
          head,
          [side * 0.28, 0.31, -0.01],
          [1, 1, 0.6],
          10,
        );
        this.ball(
          "máscara",
          0.28,
          black,
          head,
          [side * 0.18, 0.03, 0.27],
          [1.13, 0.8, 0.35],
          12,
        );
      }
      for (let i = 0; i < 5; i++)
        this.ball(
          "cauda-listrada",
          0.2,
          i % 2 ? black : body,
          root,
          [0.1 + i * 0.025, 0.4 + i * 0.055, -0.32 - i * 0.12],
          [1, 1, 1.25],
          8,
        );
    }
    if (type === "ram") {
      for (const side of [-1, 1]) {
        const horn = B.MeshBuilder.CreateTorus(
          "chifre",
          { diameter: 0.45, thickness: 0.12, tessellation: 20, arc: 0.88 },
          this.scene,
        );
        horn.parent = head;
        horn.position.set(side * 0.36, 0.15, -0.03);
        horn.rotation.z = Math.PI / 2;
        horn.material = cream;
      }
    }
    if (type === "hippo") {
      for (const side of [-1, 1])
        this.ball(
          "orelha-hipo",
          0.2,
          body,
          head,
          [side * 0.36, 0.32, -0.06],
          [1, 1, 0.6],
          10,
        );
    }
    const snout = this.ball(
      "focinho",
      type === "hippo" ? 0.64 : 0.43,
      type === "hippo" ? body : cream,
      head,
      [0, -0.12, 0.31],
      [1.1, 0.56, 0.75],
      small ? 10 : 18,
    );
    if (type === "hippo") {
      for (const side of [-1, 1])
        this.ball(
          "narina",
          0.065,
          black,
          head,
          [side * 0.16, -0.03, 0.55],
          [1, 0.5, 0.5],
          8,
        );
    } else
      this.ball(
        "nariz",
        0.13,
        black,
        head,
        [0, -0.035, 0.48],
        [1.2, 0.75, 0.7],
        12,
      );
    const eyes = B.MeshBuilder.CreatePlane(
      "expressão",
      { width: type === "hippo" ? 0.69 : 0.6, height: 0.29 },
      this.scene,
    );
    eyes.parent = head;
    eyes.position.set(0, 0.08, type === "hippo" ? 0.425 : 0.365);
    eyes.rotation.y = Math.PI;
    eyes.material = this.face("focus");
    if (!small) {
      const mouth = B.MeshBuilder.CreatePlane("sorriso", { width: 0.24, height: 0.08 }, this.scene);
      mouth.parent = head;
      mouth.position.set(0.025, -0.19, type === "hippo" ? 0.56 : 0.482);
      mouth.rotation.y = Math.PI;
      mouth.material = this.smileMaterial();
    }
    const arms = [-1, 1].map((side) => ({
      side,
      upper: this.cylinder("braço", 0.17, 1, body, root),
      lower: this.cylinder("antebraço", 0.18, 1, body, root),
      glove: this.ball(
        "luva",
        small ? 0.3 : 0.33,
        gloves,
        root,
        [0, 0, 0],
        [1, 1.1, 1.15],
        small ? 10 : 18,
      ),
    }));
    const legs = [-1, 1].map((side) => ({
      side,
      upper: this.cylinder("perna", 0.2, 1, black, root),
      lower: this.cylinder("canela", 0.18, 1, body, root),
      foot: this.ball("pé", 0.28, gloves, root, [0, 0, 0], [0.8, 0.6, 1.35], 10),
    }));
    const labelTex = new B.DynamicTexture(
      "nome-" + p.id,
      { width: 512, height: 160 },
      this.scene,
      false,
    );
    labelTex.hasAlpha = true;
    const lm = new B.StandardMaterial("etiqueta-" + p.id, this.scene);
    lm.diffuseTexture = labelTex;
    lm.emissiveTexture = labelTex;
    lm.emissiveColor = C.White();
    lm.useAlphaFromDiffuseTexture = true;
    lm.backFaceCulling = false;
    const label = B.MeshBuilder.CreatePlane(
      "nome",
      { width: 1.4, height: 0.43 },
      this.scene,
    );
    label.material = lm;
    label.parent = root;
    label.position.y = 2.15;
    label.billboardMode = B.Mesh.BILLBOARDMODE_ALL;
    let lastLabel = "";
    const a = {
      p,
      label,
      type,
      seed: p.seed,
      root,
      head,
      torso,
      arms,
      legs,
      eyes,
      small,
      phase: 0,
      updateLabel: (q, role) => {
        const hp = this.slots.includes(q.id) ? q.hp : q.reserveHp,
          txt = q.name + ":" + hp + ":" + role;
        if (txt === lastLabel) return;
        lastLabel = txt;
        const c = labelTex.getContext();
        c.clearRect(0, 0, 512, 160);
        c.fillStyle = "#101a2be8";
        c.beginPath();
        c.roundRect(5, 8, 502, 141, 30);
        c.fill();
        c.strokeStyle = role === "champion" ? "#ffda7c" : "#6edbe5";
        c.lineWidth = 4;
        c.stroke();
        c.font = "bold 40px sans-serif";
        c.fillStyle = "#f5fbff";
        c.textAlign = "center";
        c.fillText("@" + q.id.slice(0, 17), 256, 66);
        c.font = "bold 31px sans-serif";
        c.fillStyle = "#bdf66d";
        c.fillText(
          "♥ " +
            Math.round(hp) +
            "   " +
            (role === "champion"
              ? "CAMPEÃO"
              : role === "challenger"
                ? "DESAFIANTE"
                : role === "defeated"
                  ? "DERROTADO"
                  : "PLATEIA"),
          256,
          116,
        );
        labelTex.update();
      },
      dispose: () => {
        for (const q of root.getChildMeshes())
          this.shadow.removeShadowCaster(q, false);
        root.dispose();
        labelTex.dispose();
        lm.dispose();
        locals.forEach((m) => m.dispose());
        this.attackTracks.delete(p.id);
        this.hitTracks.delete(p.id);
        this.blinks.delete(p.id);
      },
    };
    if (!small)
      for (const q of root.getChildMeshes())
        if (!["nome", "expressão", "sorriso"].includes(q.name)) {
          this.shadow.addShadowCaster(q, false);
          q.renderOutline = this.profile !== "low" && ["crânio", "luva", "pé", "orelha", "cauda", "chifre", "cauda-listrada"].includes(q.name);
          q.outlineWidth = 0.012;
          q.outlineColor = new C(0.035, 0.045, 0.08);
        }
    return a;
  }
}
