import { readFile, realpath } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let valid = false,
  pid = 0;
try {
  pid = Number(await readFile(path.join(root, "data/supervisor.pid"), "utf8"));
  if (pid > 0) {
    const cmd = await readFile("/proc/" + pid + "/cmdline", "utf8"),
      cwd = await realpath("/proc/" + pid + "/cwd");
    valid =
      cmd.includes("supervisor.mjs") && (cmd.includes(root) || cwd === root);
  }
} catch {}
if (process.argv.includes("--stop")) {
  if (valid) {
    process.kill(pid, "SIGTERM");
    console.log("Encerramento solicitado somente à instalação Corrida do Caos.");
  } else console.log("Nenhum supervisor desta instalação encontrado.");
} else process.exitCode = valid ? 0 : 1;
