import {RULES,SPECIES,MAPS,track,hash,clamp,obstacleX,VERSION,giftEffect} from '../public/rules.js';
const clean=(s,n=64)=>String(s??'').replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,n);
const num=(n,max=100000)=>clamp(Math.floor(Number(n)||0),0,max);
export function avatarURL(s){try{const u=new URL(String(s));return u.protocol==='https:'&&u.href.length<1500?u.href:null;}catch{return null;}}
export class RaceEngine{
 constructor({mode='demo',now=Date.now,onAction=()=>{},saved=null}={}){
  Object.assign(this,{mode,now,onAction,players:new Map(),queue:[],racers:[],actions:[],seen:new Map(),round:1,phase:'lobby',startedAt:now(),phaseUntil:now()+RULES.lobbyMs,seq:0,likes:0,likeCharge:0,windUntil:0,lastWind:0,likesPending:0,results:[],roundWinner:null,totalEvents:0,lastTick:now()});
  if(saved?.project==='corrida-do-caos'&&saved.schema===1){
   this.round=num(saved.round,1e9)||1;this.likes=num(saved.likes,1e12);this.likeCharge=num(saved.likeCharge,RULES.likeGoal-1);this.seq=num(saved.seq,1e12);this.results=Array.isArray(saved.results)?saved.results.slice(0,12):[];
   for(const p of Array.isArray(saved.players)?saved.players.slice(0,RULES.maxPlayers):[]){const id=clean(p.id);if(!id||id.startsWith('npc:'))continue;this.players.set(id,{...this.profile(id,p.name),...p,id,name:clean(p.name,36)||id,avatar:avatarURL(p.avatar),points:num(p.points,1e12),wins:num(p.wins,1e9),races:num(p.races,1e9),history:Array.isArray(p.history)?p.history.slice(-3):[]});}
   const pending=[...(Array.isArray(saved.activeIds)?saved.activeIds:[]),...(Array.isArray(saved.queue)?saved.queue:[])];this.queue=[...new Set(pending.filter(id=>this.players.has(id)))].slice(0,RULES.maxQueue);
   for(const a of (saved.seen||[]).slice(-3000))if(Array.isArray(a)&&now()-a[1]<600000)this.seen.set(a[0],a[1]);
   if(saved.phase==='podium'){this.phase='podium';this.phaseUntil=now()+RULES.podiumMs;this.roundWinner=saved.roundWinner||null;this.queue=(saved.queue||[]).filter(id=>this.players.has(id)).slice(0,RULES.maxQueue);}
  }
 }
 profile(id,name){const seed=hash(id);return {id,name:clean(name,36)||id,seed,archetype:SPECIES[seed%4],avatar:null,points:0,wins:0,races:0,likes:0,gifts:0,followed:false,boostCredit:0,shieldCredit:0,lastBoost:0,lastSeen:this.now(),history:[]};}
 action(kind,data={}){const a={seq:++this.seq,kind,at:this.now(),...data};this.actions.push(a);if(this.actions.length>35)this.actions.shift();this.onAction(a);return a;}
 get(id,name,avatar){id=clean(id);if(!id||id.startsWith('npc:'))return null;let p=this.players.get(id);if(!p){if(this.players.size>=RULES.maxPlayers){const protectedIds=new Set([...this.queue,...this.racers.map(r=>r.id)]);const old=[...this.players.values()].filter(p=>!protectedIds.has(p.id)).sort((a,b)=>a.lastSeen-b.lastSeen)[0];if(!old)return null;this.players.delete(old.id);}p=this.profile(id,name);this.players.set(id,p);}if(name)p.name=clean(name,36)||p.name;const url=avatarURL(avatar);if(url)p.avatar=url;p.lastSeen=this.now();return p;}
 enter(p){if(!p)return false;if(this.racers.some(r=>r.id===p.id)&&this.phase==='racing')return false;if(this.queue.includes(p.id))return false;if(this.queue.length>=RULES.maxQueue){this.action('queueFull',{user:p.id});return false;}this.queue.push(p.id);this.action('entry',{user:p.id,name:p.name,avatar:p.avatar,next:this.phase!=='lobby'});return true;}
 ingest(e={}){
  if(!['join','comment','like','gift','follow','share'].includes(e.type))return false;
  if(e.type==='gift'&&e.repeatEnd===false)return false;
  const key=e.type==='gift'&&e.groupId?`g:${e.user}:${e.giftId||e.gift}:${e.groupId}`:e.id?`${e.type}:${clean(e.id,150)}`:null;
  if(key&&this.seen.has(key))return false;if(key){this.seen.set(key,this.now());while(this.seen.size>3000)this.seen.delete(this.seen.keys().next().value);}
  this.totalEvents++;const count=num(e.type==='like'?(e.count??0):(e.count??1),e.type==='like'?100000:99);
  if(e.type==='like'){this.likes+=count;this.likeCharge+=count;const gifts=Math.floor(this.likeCharge/RULES.likeGoal);this.likeCharge%=RULES.likeGoal;if(gifts){for(const r of this.racers)r.boostUntil=Math.max(r.boostUntil,this.now()+1800);this.action('collective',{count:gifts});}if(!e.user)return true;}
  const p=this.get(e.user,e.name,e.avatar);if(!p)return false;const r=this.racers.find(a=>a.id===p.id);
  if(e.type==='join'){this.action('welcome',{user:p.id,name:p.name,avatar:p.avatar});return true;}
  if(e.type==='like'){p.likes+=count;return true;}
  if(e.type==='follow'){if(!p.followed){p.followed=true;p.shieldCredit=1;if(r)r.shield=1;this.action('follow',{user:p.id,name:p.name});}return true;}
  if(e.type==='share'){if(this.now()-(p.lastShare||0)>=20000){p.lastShare=this.now();if(r)r.boostUntil=Math.max(r.boostUntil,this.now()+1500);else p.boostCredit=Math.min(RULES.maxBoostMs,p.boostCredit+1500);this.action('share',{user:p.id,name:p.name});}return true;}
  if(e.type==='gift'){
   this.enter(p);p.gifts+=count;const effect=giftEffect(e.gift,e.giftId);
   if(effect==='turbo'){const ms=Math.min(RULES.maxBoostMs,RULES.roseBoostMs+Math.log2(count)*600);if(r&&!r.finishAt)r.boostUntil=Math.min(this.now()+RULES.maxBoostMs,Math.max(this.now(),r.boostUntil)+ms);else p.boostCredit=Math.min(RULES.maxBoostMs,p.boostCredit+ms);}
   if(effect==='shield'){if(r)r.shield=1;else p.shieldCredit=1;}
   if(effect==='wind'&&this.now()-this.lastWind>4500){this.windUntil=this.now()+2800;this.lastWind=this.now();}
   this.action('gift',{user:p.id,name:p.name,avatar:p.avatar,gift:clean(e.gift,35)||'Presente',count,effect});return true;
  }
  const text=clean(e.text,180),command=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toUpperCase();
  if(/^(EU|JOGAR|ENTRAR|CORRER|BORA)[!. ]*$/.test(command))this.enter(p);
  else if(/^(VAI|TURBO|ACELERA)[!. ]*$/.test(command)){
   if(this.now()-p.lastBoost>=RULES.freeBoostCooldown){p.lastBoost=this.now();if(r&&!r.finishAt)r.boostUntil=Math.max(r.boostUntil,this.now()+1600);else p.boostCredit=Math.min(RULES.maxBoostMs,p.boostCredit+1600);this.action('turbo',{user:p.id,name:p.name});}
  }else if(/^(DANCA|DANCAR|PULAR|PULA)[!. ]*$/.test(command)){if(r)r.anim={kind:command.startsWith('DAN')?'dance':'jump',until:this.now()+1600};this.action('pose',{user:p.id,name:p.name});}
  else if(text)this.action('comment',{user:p.id,name:p.name,text,question:/[?？]|\b(como|quem|qual|porque|por que|voce|quanto|oi|ola)\b/i.test(command.toLowerCase())});
  return true;
 }
 startRace(){
  this.phase='racing';this.startedAt=this.now();this.phaseUntil=this.now()+RULES.raceMs;this.roundWinner=null;this.results=[];this.obstacles=track(this.round);
  const ids=this.queue.splice(0,RULES.maxRacers),people=ids.map(id=>this.players.get(id)).filter(Boolean);
  for(let i=people.length;i<4;i++)people.push({...this.profile('npc:'+i,['Pipoca','Soneca','Foguinho','Trombada'][i%4]),npc:true});
  this.racers=people.map((p,i)=>({id:p.id,name:p.name,avatar:p.avatar,seed:p.seed,archetype:p.archetype,npc:!!p.npc,progress:-Math.floor(i/6)*1.1,x:(i%6-2.5)*1.02,speed:3.35+(hash(p.id+this.round)%90)/1000,boostUntil:this.now()+(p.boostCredit||0),shield:p.shieldCredit||0,stunUntil:0,jumpUntil:0,seen:[],finishAt:0,anim:null}));
  for(const p of people){p.boostCredit=0;p.shieldCredit=0;if(!p.npc)p.races++;}
  this.action('raceStart',{round:this.round,count:this.racers.length});
 }
 finishRace(){
  if(this.phase!=='racing')return;
  const sorted=[...this.racers].sort((a,b)=>(a.finishAt&&b.finishAt?a.finishAt-b.finishAt:a.finishAt?-1:b.finishAt?1:b.progress-a.progress));
  this.results=sorted.map((r,i)=>({id:r.id,name:r.name,avatar:r.avatar,npc:r.npc,archetype:r.archetype,seed:r.seed,place:i+1,progress:Math.round(r.progress*10)/10,finished:!!r.finishAt}));
  const first=sorted.find(r=>!r.npc);this.roundWinner=sorted[0]?.id||null;
  for(let i=0;i<sorted.length;i++){const r=sorted[i],p=this.players.get(r.id);if(!p)continue;p.points+=[15,10,6][i]||2;if(i===0)p.wins++;p.lastRace=this.round;}
  this.phase='podium';this.startedAt=this.now();this.phaseUntil=this.now()+RULES.podiumMs;this.action('podium',{winner:sorted[0]?.name||'Caos',user:this.roundWinner,npc:sorted[0]?.npc||false,byDistance:sorted.some(r=>!r.finishAt)});
 }
 tick(){
  const at=this.now(),dt=Math.min(.25,Math.max(0,(at-this.lastTick)/1000));this.lastTick=at;
  if(this.phase==='lobby'&&at>=this.phaseUntil)this.startRace();
  if(this.phase==='podium'&&at>=this.phaseUntil){this.round++;this.phase='lobby';this.startedAt=at;this.phaseUntil=at+RULES.lobbyMs;this.racers=[];this.action('lobby',{round:this.round});return;}
  if(this.phase!=='racing')return;
  const t=(at-this.startedAt)/1000;
  for(const r of this.racers){
   if(r.finishAt)continue;const segment=Math.floor(Math.max(0,r.progress)/12);let desired=((hash(r.id+':'+this.round+':'+segment)%6)-2.5)*1.03;
   if(at<this.windUntil)desired+=Math.sin(t*6+r.seed)*.8;r.x+=(clamp(desired,-3.05,3.05)-r.x)*Math.min(1,dt*2.2);
   const before=r.progress;r.progress+=r.speed*dt*(at<r.stunUntil?.22:at<r.boostUntil?1.48:1);
   for(const o of this.obstacles){if(r.seen.includes(o.id)||before>=o.z||r.progress<o.z)continue;r.seen.push(o.id);
    if(o.kind==='pads'){if(Math.abs(r.x-obstacleX(o,t))<1.3){r.boostUntil=Math.max(r.boostUntil,at+1100);r.jumpUntil=at+650;this.action('pad',{user:r.id});}}
    else {const hit=o.kind==='sweeper'?Math.abs(r.x-obstacleX(o,t))<1.05:((Math.floor(t*2+o.phase)+(r.x>0?1:0))%4===0);
     if(hit){if(r.shield){r.shield=0;this.action('shield',{user:r.id});}else{r.stunUntil=at+850;r.progress=Math.max(0,r.progress-1.1);r.anim={kind:'tumble',until:at+900};this.action('hit',{user:r.id,name:r.name});}}else{r.jumpUntil=at+650;}}
   }
   if(r.progress>=RULES.finish){r.progress=RULES.finish;r.finishAt=at;this.action('finish',{user:r.id,name:r.name,npc:r.npc,place:this.racers.filter(a=>a.finishAt).length});}
  }
  if(at>=this.phaseUntil||this.racers.every(r=>r.finishAt))this.finishRace();
 }
 public(){const now=this.now();return {project:'corrida-do-caos',version:VERSION,mode:this.mode,serverTime:now,phase:this.phase,round:this.round,startedAt:this.startedAt,phaseUntil:this.phaseUntil,remaining:Math.max(0,this.phaseUntil-now),map:MAPS[(this.round-1)%MAPS.length],track:track(this.round),rules:RULES,likes:this.likes,likeCharge:this.likeCharge,windUntil:this.windUntil,totalEvents:this.totalEvents,players:this.players.size,queue:this.queue.slice(0,24).map(id=>{const p=this.players.get(id);return p?{id:p.id,name:p.name,avatar:p.avatar,seed:p.seed,archetype:p.archetype}:null;}).filter(Boolean),queueTotal:this.queue.length,racers:this.racers.map(({seen,...r})=>r),ranking:[...this.players.values()].filter(p=>p.points>0).sort((a,b)=>b.wins-a.wins||b.points-a.points).slice(0,10).map(({id,name,avatar,wins,points,races})=>({id,name,avatar,wins,points,races})),results:this.results,roundWinner:this.roundWinner,actions:this.actions.slice(-20)};}
 save(){return {project:'corrida-do-caos',schema:1,phase:this.phase,round:this.round,likes:this.likes,likeCharge:this.likeCharge,seq:this.seq,players:[...this.players.values()],queue:this.queue,activeIds:this.phase==='racing'?this.racers.filter(r=>!r.npc).map(r=>r.id):[],results:this.results,roundWinner:this.roundWinner,seen:[...this.seen.entries()].slice(-3000),at:this.now()};}
}
