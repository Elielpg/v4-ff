import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile,mkdir,appendFile,stat,rename} from 'node:fs/promises';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {RaceEngine,avatarURL} from './engine.mjs';
import {Store} from './storage.mjs';
import {TikTokAdapter} from './live.mjs';
import {ShowHost,settings} from './host.mjs';
import {RhythmBridge} from './rhythm.mjs';
import {VERSION} from '../public/rules.js';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),PORT=Number(process.env.PORT||3400),DATA=process.env.CORRIDA_DATA_DIR||path.join(ROOT,'data'),store=new Store(DATA),clients=new Set();
const bootId=randomBytes(8).toString('hex');
await mkdir(DATA,{recursive:true,mode:0o700});await mkdir(path.join(ROOT,'logs'),{recursive:true});
let mode='demo',running=false,closing=false,demoTimer=null,bridgeAt=0,speech=null,lastPulse=null;
let pausedRemaining=10000;
const session=await store.read('session');if(session?.project==='corrida-do-caos'&&session.mode==='live')mode='live';
running=!!session?.running;
const config=await store.read('config');
let hostConfig;try{hostConfig=settings(config?.host);}catch{hostConfig=settings();}
const rhythm=new RhythmBridge(),engines={};
const emit=(name,data)=>{const msg=`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`;for(const c of clients)if(c.writableLength>256000){c.destroy();clients.delete(c);}else c.write(msg);};
async function log(kind,data={}){try{const f=path.join(ROOT,'logs/server.jsonl');if((await stat(f).catch(()=>({size:0}))).size>1e6)await rename(f,f+'.1').catch(()=>{});await appendFile(f,JSON.stringify({at:new Date().toISOString(),kind,...data})+'\n');}catch{}}
const host=new ShowHost({dir:path.join(DATA,'voice-cache'),config:hostConfig,getState:()=>{const e=engines[mode];return {...e.public(),memory:Object.fromEntries([...e.players.values()].filter(p=>p.history?.length).map(p=>[p.id,p.history]))};},onSpeech:a=>{speech=a;emit('speech',a);if(a.kind==='local-ai'&&a.user){const p=engines[mode].players.get(a.user);if(p){p.history=[...(p.history||[]),{q:a.prompt,a:a.text}].slice(-3);void save();}}}});
for(const name of ['demo','live'])engines[name]=new RaceEngine({mode:name,saved:await store.read(name),onAction:a=>{if(name===mode){emit('action',a);host.event(a);}if(['podium','gift','entry','raceStart'].includes(a.kind)&&engines[name])void store.save(name,engines[name].save()).catch(e=>log('save-error',{message:e.message}));}});
let bridgeToken;try{bridgeToken=JSON.parse(await readFile(path.join(DATA,'bridge.json'),'utf8')).token;}catch{}if(!/^[a-f0-9]{64}$/.test(bridgeToken||'')){bridgeToken=randomBytes(32).toString('hex');await writeFile(path.join(DATA,'bridge.json'),JSON.stringify({token:bridgeToken}),{mode:0o600});}
const adapter=new TikTokAdapter(e=>{engines.live.ingest(e);},s=>{emit('connection',s);void log('connection',{status:s.status,message:s.message});});
const connection=()=>Date.now()-bridgeAt<30000?{status:'connected',message:'Ponte local recebendo eventos',provider:'bridge'}:adapter.state;
const snapshot=()=>({...engines[mode].public(),...(!running?{remaining:pausedRemaining}:{}),bootId,running,connection:connection(),host:{...host.status,enabled:host.config.enabled},speech: speech?.until>Date.now()?speech:null,rhythm:rhythm.status(),storageError:store.error});
async function save(){await Promise.all(Object.entries(engines).map(([n,e])=>store.save(n,e.save())));}
const saveSession=()=>store.save('session',{project:'corrida-do-caos',mode,running});
const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data));};
async function body(req){if(!String(req.headers['content-type']||'').startsWith('application/json'))throw Object.assign(Error('Use JSON'),{status:415});const origin=req.headers.origin;if(origin&&!['http://127.0.0.1:'+PORT,'http://localhost:'+PORT].includes(origin))throw Object.assign(Error('Origem recusada'),{status:403});let b='';for await(const v of req){b+=v;if(Buffer.byteLength(b)>32768)throw Object.assign(Error('Requisição muito grande'),{status:413});}try{return JSON.parse(b||'{}');}catch{throw Object.assign(Error('JSON inválido'),{status:400});}}
async function switchMode(next){if(!['demo','live'].includes(next))throw Error('Modo inválido');clearInterval(demoTimer);demoTimer=null;await adapter.disconnect();bridgeAt=0;rhythm.revoke();await save();mode=next;running=false;pausedRemaining=engines[mode].phase==='podium'?6500:engines[mode].phase==='racing'?35000:10000;speech=null;host.reset();await saveSession();emit('mode',{mode});}
function startDemo(){clearInterval(demoTimer);const e=engines.demo;for(const [i,name]of ['Luna','Pixel','Bia','Nando','Mika','Ravi'].entries())e.ingest({type:'comment',user:'demo_'+name.toLowerCase(),name:name+' · DEMO',text:'EU'});let step=0;demoTimer=setInterval(()=>{if(mode!=='demo')return;const names=['Luna','Pixel','Bia','Nando','Mika','Ravi'],name=names[step%6],user='demo_'+name.toLowerCase();step++;e.ingest({type:step%9===0?'gift':step%3===0?'like':'comment',user,name:name+' · DEMO',text:step%2?'VAI':'EU',gift:'Rosa',count:step%9===0?1:step%3===0?20:1,id:'demo-'+randomBytes(6).toString('hex'),repeatEnd:true});},2100);demoTimer.unref();}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.wav':'audio/wav','.mp3':'audio/mpeg','.json':'application/json','.ttf':'font/ttf','.apk':'application/vnd.android.package-archive'};
const server=http.createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://127.0.0.1'),p=url.pathname;
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
 if(req.method==='GET'&&p==='/api/health')return json(res,200,{ok:true,project:'corrida-do-caos',version:VERSION,pid:process.pid,mode,running});
 if(req.method==='GET'&&p==='/api/state')return json(res,200,snapshot());
 if(req.method==='GET'&&p==='/api/host')return json(res,200,await host.health());
 if(req.method==='GET'&&p==='/api/backup'){res.setHeader('content-disposition','attachment; filename="CORRIDA_BACKUP.json"');return json(res,200,engines[mode].save());}
 if(req.method==='GET'&&p==='/api/events'){
  if(clients.size>=12)return json(res,429,{error:'Muitas telas abertas'});
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});res.write('retry: 1800\n\n');clients.add(res);res.write('event: state\ndata: '+JSON.stringify(snapshot())+'\n\n');req.on('close',()=>clients.delete(res));return;
 }
 if(req.method==='POST'&&p.startsWith('/api/')){
  const b=await body(req);
  if(p==='/api/mode'){await switchMode(b.mode);return json(res,200,snapshot());}
  if(p==='/api/start'){if(!running){running=true;const e=engines[mode],duration=e.phase==='lobby'?10000:e.phase==='podium'?6500:35000;e.lastTick=Date.now();e.phaseUntil=Date.now()+pausedRemaining;e.startedAt=Date.now()-(duration-pausedRemaining);if(mode==='demo'&&b.simulate!==false)startDemo();await saveSession();}return json(res,200,snapshot());}
  if(p==='/api/stop'){if(running)pausedRemaining=Math.max(0,engines[mode].phaseUntil-Date.now());running=false;clearInterval(demoTimer);demoTimer=null;host.reset();speech=null;await saveSession();return json(res,200,snapshot());}
  if(p==='/api/test-event'){if(mode!=='demo')return json(res,403,{error:'Simulação disponível somente na demonstração'});engines.demo.ingest(b);return json(res,200,snapshot());}
  if(p==='/api/connect'){const username=String(b.username||'').replace(/^@/,'').trim();if(!/^[a-z0-9_.]{2,24}$/i.test(username))throw Error('Informe somente o @ da conta');if(mode!=='live')await switchMode('live');void adapter.connect(username).catch(e=>log('connect-error',{message:e.message}));return json(res,202,{ok:true,message:'Conexão solicitada; aguarde confirmação'});}
  if(p==='/api/disconnect'){await adapter.disconnect();bridgeAt=0;return json(res,200,{ok:true});}
  if(p==='/api/host-config'){host.configure(b);await store.save('config',{host:host.config});return json(res,200,{ok:true,config:host.config});}
  if(p==='/api/ask'){const user=String(b.user||'operador').slice(0,64),name=String(b.name||'Você').slice(0,36);engines[mode].get(user,name);const accepted=host.ask({user,name,text:String(b.text||'').slice(0,180)});return json(res,202,{accepted,status:host.status});}
  if(p==='/api/rhythm/code')return json(res,200,rhythm.issue());
  if(p==='/api/rhythm/pair')return json(res,200,rhythm.pair(b.code));
  if(p==='/api/rhythm/frame'){const r=rhythm.frame(req.headers.authorization,b);if(r.hit){lastPulse={at:Date.now(),strength:r.strength||.6};emit('beat',lastPulse);}return json(res,200,r);}
  if(p==='/api/rhythm/disconnect'){rhythm.revoke();return json(res,200,{ok:true});}
  if(p==='/api/bridge'){
   const token=String(req.headers.authorization||'').replace(/^Bearer /,'');if(!/^[a-f0-9]{64}$/.test(token)||!timingSafeEqual(Buffer.from(token),Buffer.from(bridgeToken)))return json(res,403,{error:'Token de ponte necessário'});
   if(mode!=='live')return json(res,409,{error:'Ative o modo LIVE antes da ponte'});bridgeAt=Date.now();engines.live.ingest(b);return json(res,200,{ok:true});
  }
  return json(res,404,{error:'Ação não encontrada'});
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Método não permitido'});
 if(p.startsWith('/api/'))return json(res,404,{error:'API não encontrada'});
 const decoded=decodeURIComponent(p);let file;
 if(/^\/voice-cache\/[a-f0-9]{64}\.wav$/.test(decoded))file=path.join(DATA,'voice-cache',path.basename(decoded));
 else{if(decoded.includes('\0')||decoded.split('/').some(x=>x==='..'||x.startsWith('.')))return json(res,403,{error:'Caminho recusado'});file=path.join(ROOT,'public',decoded==='/'?'index.html':decoded);if(!file.startsWith(path.join(ROOT,'public')+path.sep))return json(res,403,{error:'Caminho recusado'});}
 const bytes=await readFile(file);res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':/\.(js|css|html)$/.test(file)?'no-cache':'public, max-age=3600'});res.end(req.method==='HEAD'?undefined:bytes);
 }catch(e){if(!res.headersSent)json(res,e.status||((e.code==='ENOENT'||e.code==='EISDIR')?404:400),{error:e.code==='ENOENT'?'Arquivo não encontrado':String(e.message).slice(0,180)});else res.end();}});
server.on('error',e=>{void log('listen-error',{code:e.code});console.error(e.code==='EADDRINUSE'?'Porta '+PORT+' ocupada. Use bash stop.sh na instalação correspondente.':e.message);process.exitCode=e.code==='EADDRINUSE'?78:1;clearInterval(tick);clearInterval(broadcast);clearInterval(autosave);clearInterval(metrics);clearInterval(heartbeat);host.close();});
const tick=setInterval(()=>{if(running)engines[mode].tick();},50),broadcast=setInterval(()=>{if(clients.size)emit('state',snapshot());},200),autosave=setInterval(()=>{void save().catch(e=>log('save-error',{message:e.message}));},1500),metrics=setInterval(()=>{void log('health',{rss:process.memoryUsage().rss,mode,phase:engines[mode].phase,clients:clients.size,running,connection:connection().status});},60000),heartbeat=setInterval(()=>{for(const c of clients)c.write(': ping\n\n');},10000);
server.listen(PORT,'127.0.0.1',()=>{console.log('CORRIDA DO CAOS · v'+VERSION+'\nAbra http://127.0.0.1:'+PORT);void log('start',{version:VERSION,pid:process.pid,mode});});
async function shutdown(signal){if(closing)return;closing=true;running=false;host.close();clearInterval(demoTimer);for(const t of [tick,broadcast,autosave,metrics,heartbeat])clearInterval(t);await adapter.disconnect();await save().catch(()=>{});await store.flush();await log('stop',{signal});for(const c of clients)c.end();server.close();setTimeout(()=>process.exit(0),500).unref();}
process.on('SIGINT',()=>void shutdown('SIGINT'));process.on('SIGTERM',()=>void shutdown('SIGTERM'));
