const clean = (s) =>
  String(s || "")
    .replace(/https?:\/\/\S+/g, "[rede]")
    .replace(/\b(cookie|token|sessionid|ttwid)\s*[=:]\s*\S+/gi, "$1=[oculto]")
    .slice(0, 250);
const count = (v) => {
  if (v && typeof v === "object" && "low" in v) return Math.max(0, v.low >>> 0);
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0;
};
export function normalize(e, type) {
  const u = e.user || {},
    id = u.uniqueId || u.displayId || e.uniqueId || e.userId || u.id;
  return {
    id: String(e.common?.msgId ?? e.msgId ?? e.messageId ?? ""),
    type,
    user: id ? String(id) : null,
    name: u.nickname || e.nickname || id,
    avatar: (Array.isArray(u.profilePicture?.url)?u.profilePicture.url[0]:u.profilePicture?.url) || u.avatarThumb?.urlList?.[0] || u.avatarThumb?.url_list?.[0] || u.profilePictureUrl || e.profilePictureUrl || null,
    text: e.content || e.comment || "",
    gift: e.gift?.name || e.giftName || "",
    giftId: e.gift?.id || e.giftId,
    groupId: e.groupId || e.giftGroupId || e.gift?.groupId || null,
    count:
      type === "like"
        ? count(e.likeCount ?? e.count ?? e.likes)
        : count(e.repeatCount ?? e.count) || 1,
    repeatEnd:
      type === "gift"
        ? Number(e.gift?.type ?? e.giftType) !== 1 || Number(e.repeatEnd) === 1
        : true,
  };
}
export class TikTokAdapter {
  constructor(
    onEvent,
    onStatus,
    { load = () => import("piratetok-live-js") } = {},
  ) {
    this.onEvent = onEvent;
    this.onStatus = onStatus;
    this.load = load;
    this.generation = 0;
    this.state = {
      status: "offline",
      message: "LIVE não conectada",
      events: 0,
    };
    this.client = null;
    this.timer = null;
    this.cancelConnect = null;
  }
  status(status, message) {
    this.state = { ...this.state, status, message };
    this.onStatus(this.state);
  }
  async connect(value) {
    const username = String(value || "")
      .replace(/^@/, "")
      .trim()
      .toLowerCase();
    if (!/^[a-z0-9_.]{2,24}$/.test(username))
      throw Error("Digite somente o @ da conta, sem link.");
    await this.disconnect();
    const g = this.generation;
    this.state = {
      status: "connecting",
      message: "Abrindo WebSocket da LIVE pública…",
      username,
      events: 0,
    };
    this.onStatus(this.state);
    let client, timer, cancel;
    try {
      const mod = await this.load();
      if (g !== this.generation) return;
      client = new mod.TikTokLiveClient(username).timeout(12000).maxRetries(0);
      this.client = client;
      client.language?.("pt");
      client.region?.("BR");
      const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
      if (proxy) client.proxy?.(proxy);
      const current = () => g === this.generation && this.client === client;
      for (const [name, type] of Object.entries({
        chat: "comment",
        gift: "gift",
        like: "like",
        follow: "follow",
        share: "share",
        join: "join",
      }))
        client.on(name, (e) => {
          if (!current()) return;
          const out = normalize(e, type);
          if (type === "like" && !out.count) return;
          this.state.events++;
          this.onEvent(out);
          this.status("connected", "Recebendo eventos da LIVE");
        });
      client.on("connected", () => {
        if (current())
          this.status(
            "connecting",
            "Sala localizada; aguardando confirmação do WebSocket…",
          );
      });
      client.on("error", (e) => {
        if (current()) this.status("error", clean(e?.message || e));
      });
      client.on("disconnected", () => {
        if (current())
          this.status("offline", "Conexão encerrada. Reconecte pelo painel.");
      });
      client.on("liveEnded", () => {
        if (current()) void this.disconnect();
      });
      const connecting = Promise.resolve(client.connect());
      connecting.then(
        () => {
          if (!current()) {
            try {
              Promise.resolve(client.disconnect()).catch(() => {});
            } catch {}
          }
        },
        () => {},
      );
      const cancelled = new Promise((_, reject) => {
        cancel = () => reject(Error("Conexão cancelada"));
        this.cancelConnect = cancel;
      });
      const result = await Promise.race([
        connecting,
        cancelled,
        new Promise((_, reject) => {
          timer = setTimeout(
            () => reject(Error("Tempo esgotado ao abrir a LIVE")),
            25000,
          );
          this.timer = timer;
        }),
      ]);
      clearTimeout(timer);
      if (this.timer === timer) this.timer = null;
      if (this.cancelConnect === cancel) this.cancelConnect = null;
      if (!current()) {
        client.disconnect();
        return;
      }
      if (result === undefined || result === null)
        throw Error("A conexão não confirmou o WebSocket.");
      this.status("connected", "WebSocket da LIVE confirmado");
    } catch (e) {
      clearTimeout(timer);
      if (this.timer === timer) this.timer = null;
      if (this.cancelConnect === cancel) this.cancelConnect = null;
      if (g !== this.generation) return;
      try {
        client?.disconnect();
      } catch {}
      this.client = null;
      const missing = e.code === "ERR_MODULE_NOT_FOUND";
      this.status(
        "error",
        missing
          ? "Conector não instalado. Execute bash install.sh."
          : clean(e.message),
      );
    }
  }
  async disconnect() {
    this.generation++;
    clearTimeout(this.timer);
    this.cancelConnect?.();
    this.cancelConnect = null;
    const c = this.client;
    this.client = null;
    if (c) {
      c.removeAllListeners?.();
      try {
        await c.disconnect();
      } catch {}
    }
    this.status("offline", "LIVE não conectada");
  }
}
