# Origens e licenças

- Corrida, regras, layout, pista, falas e trilha instrumental criados para esta entrega. Não foram incluídas músicas comerciais enviadas em outras tarefas.
- Mascotes originais, utilitários de áudio/batida, shader, adaptador, persistência e supervisor adaptados dos projetos Pulso Arena e Torre TNT já desenvolvidos nesta conversa. O prompt e o apresentador desta versão têm identidade própria.
- Babylon.js **9.32.1**, Apache-2.0. Cópia da licença em `public/vendor/BABYLON-LICENSE.md`.
- `piratetok-live-js` **0.3.0**, 0BSD conforme pacote e lockfile. Dependências transitivas instaladas pelo npm conservam suas licenças. Não foi trocado pelo conector AGPL encontrado na pesquisa.
- Fontes **Anton**, por Vernon Adams, e **Space Grotesk**, por Florian Karsten: SIL OFL 1.1. Licenças em `Anton-OFL.txt` e `SpaceGrotesk-OFL.txt`.
- Falas incluídas sintetizadas com Piper 1.8.0 e `pt_BR-faber-medium`, com velocidade e ruído ajustados. Modelo: https://huggingface.co/rhasspy/piper-voices/tree/main/pt/pt_BR/faber/medium . O model card copiado em `VOICE_MODEL_CARD.md` descreve o conjunto de dados como CC0 e informa o treinamento. Não é clonagem de personagem ou dublador. O motor e o arquivo ONNX não são redistribuídos neste ZIP.
- Imagens de presentes reutilizadas da Torre TNT; URLs de origem estão em `PRESENTES_ORIGEM.json`. Marcas e imagens pertencem aos respectivos titulares. O projeto não representa parceria com TikTok.
- Captador Pulso Batida 0.2.1 reutilizado do projeto anterior, com APK e fontes em `android/`. O jogo usa pareamento e porta próprios, 3400.
- Pesquisa de referências: ThorVG Marble Race, TikTok Live Games e SlimeTiktok. Nesta versão, não foi importado código desses jogos. A base foi criada sobre os componentes próprios já existentes.

Pesquisa de seleção em `PESQUISA_E_SELECAO.md`, incluída nesta pasta.
