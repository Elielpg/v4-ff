# Testes, correções e limites — 0.1.0

## Evidências desta entrega

- **19 testes Node aprovados**, incluindo entrada gratuita, próxima bateria, curtidas agregadas, combos, deduplicação, limites, pódio, ranking, memória, limpeza de fala e restauração de dados.
- Integração HTTP: isolamento demo/LIVE, bloqueio de simulação na LIVE, SSE, origem de requisições, pausa/retomada, persistência e mudança de identificador após reinício.
- Supervisor: processo de teste falha, é recuperado e para ao atingir o limite configurado. Não é apresentado como solução para o encerramento completo do Termux pelo Android.
- Navegador: rodada completa, música liberada por clique, presente, fila, menus, avanço com música pausada e pódio. Sem erro de JavaScript ou requisição falhada na execução registrada. Layout sem transbordamento horizontal na viewport testada.
- Regressão de voz após reinício: uma fala com contador novo é aceita após mudança de sessão, mesmo que a página já tenha recebido contadores maiores.
- Fluxo de voz: texto de fixture HTTP controlada, síntese real por Piper e reprodução de WAV no elemento de áudio do navegador, com legenda correspondente. **Não foi uma avaliação do modelo Qwen real.** Um WAV previamente gerado pode ser reutilizado pelo cache.
- Doze falas neurais foram verificadas como WAV mono de 22.050 Hz, com sinal audível e sem amostras no limite máximo digital. A trilha instrumental foi criada para esta entrega.
- Simulação acelerada: duas horas da lógica, 18 participantes recorrentes e cerca de 150 rodadas; filas, corredores e deduplicação mantiveram seus limites. Os números exatos e uso de memória estão em `SOAK_ENGINE.json`.

Arquivos: `unit-tests.log`, `BROWSER_CHECK.json`, `VOICE_FLOW.json`, `AUDIO_ASSETS.json`, `SOAK_ENGINE.json` e capturas `PREVIA_*.png`.

## Correções encontradas durante o desenvolvimento

1. Importação ausente no acionamento de presentes: corrigida e coberta pelos testes de rosa/combos.
2. Contagem zero podia ser convertida em uma curtida: corrigida; curtidas anônimas só alimentam a meta coletiva.
3. Formato de avatar como string podia virar uma única letra: normalização corrigida.
4. Cache de voz podia excluir a fala recém-gerada ao atingir o limite: escrita atômica e expurgo com preservação do arquivo atual; regressão incluída.
5. Contadores de fala menores após reinício podiam ser ignorados: identificador de inicialização e reinicialização da sequência no cliente.
6. Legenda de uma mensagem recém-chegada podia substituir a fala ainda tocando: apresentação agora acompanha a fila de reprodução.
7. Música/IA poderiam paralisar a ação se herdássemos a dependência da Arena: a nova lógica de corrida tem relógio independente.
8. Ajustes de legibilidade: luz mais suave, contraste no topo, aviso de presentes lateral, resultado abaixo dos personagens e acompanhamento de câmera em FPS baixo.
9. Agrupamento da geometria estática reduz a quantidade de objetos de cenário enviados ao renderer.

## Ambiente e limitações das medições

Os testes foram realizados no computador Cloud, com Node 24 e Chromium usando WebGL por software. Os FPS registrados nesse ambiente **não são um benchmark do Realme GT3**. A simulação acelerada da lógica não substitui duas horas reais de transmissão, nem mede temperatura, bateria, GPU ou concorrência com Qwen no Android.

O teste de voz confirma o encadeamento HTTP → áudio → navegador e o cache. Não comprova a qualidade de respostas do Qwen, pronúncia de todos os nomes, timbre ideal ou o tempo de geração no celular. O iniciador Android/Termux de IA foi inspecionado e verificado sintaticamente; sua execução no ambiente `ben10-ai` do aparelho ainda precisa de validação.

## Pendências reais

- Validar o conector numa LIVE real da conta: entrada, comentário, curtida identificada/agregada, presente e fim de combo. A integração é comunitária e pode mudar.
- Executar sessão prolongada no GT3, primeiro com o jogo e depois com IA, verificando FPS, temperatura, memória, áudio, bateria e logs.
- Validar o captador Android e sua compensação na saída Bluetooth utilizada. O sinal de aplicativos terceiros pode não estar disponível.
- Ajustar a voz com feedback de escuta real de nomes, R/L e frases; não foi feita avaliação auditiva humana sistemática nesta entrega.
- Ampliar pistas, variações de obstáculos, expressões e animações após testar a participação do público.
- Medir primeira interação, pessoas que voltam a jogar e retenção nas estatísticas da LIVE. Não há comprovação de audiência ou faturamento.

## Falha do Termux / LOCAL-010

Se o servidor Node encerrar enquanto o supervisor continuar vivo, há recuperação limitada e registro de código/sinal em `logs/supervisor.jsonl`. O progresso anterior é restaurado e uma corrida interrompida volta ao lobby.

Se o Android encerrar o aplicativo Termux inteiro, o supervisor local também morre. Este projeto não se apresenta como uma correção definitiva dessa causa. O diagnóstico no aparelho deve incluir os últimos logs, uso de memória, temperatura e configurações de bateria. Após reabrir o Termux, `bash start.sh` retoma a instalação; a voz do navegador pode exigir um novo toque.
