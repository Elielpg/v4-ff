# Seleção de jogo para LIVE interativa — 20/11/2026

## Resultado

Recomendação para o primeiro protótipo: **Corrida do Caos**, com mascotes originais, participação gratuita por comentário, avatares identificáveis e rodadas curtas. A proposta combina corrida automática, obstáculos cômicos e um apresentador virtual com falas curtas.

Esta é uma seleção de produto e viabilidade técnica. Não comprova audiência, viralização ou faturamento. Foram examinados resultados de nove buscas públicas no GitHub e documentação, dependências ou licenças de dezesseis repositórios. Nos candidatos mais relevantes, também foram lidos trechos de implementação. Nenhum desses projetos foi instalado ou executado no Realme GT3 durante esta pesquisa.

O acesso desta sessão permitiu consultar GitHub e seus arquivos públicos. A pesquisa não inclui uma auditoria das políticas atuais de monetização do TikTok, estatísticas privadas de canais, receitas ou testes reais de distribuição no feed.

## Por que esta escolha

- Objetivo visível: chegar ao fim da pista.
- Uma instrução principal: **COMENTE EU PARA ENTRAR**.
- Nome e foto disponíveis nos eventos tornam a participação reconhecível.
- Rodadas propostas de aproximadamente 45–60 segundos criam novas oportunidades de entrada e desfechos frequentes.
- A corrida anda automaticamente; ações do público acrescentam acontecimentos.
- Pode funcionar com poucos participantes, usando personagens de cenário identificados como NPCs.
- A voz acrescenta personalidade, enquanto o jogo continua durante síntese lenta, ausência de música ou falha de um serviço.

Esses são argumentos de design e hipóteses a validar. Não são resultados de um experimento de retenção.

## Comparação de conceitos

| Conceito | Ação gratuita inicial | O que aparece na tela | Papel dos presentes | Avaliação |
|---|---|---|---|---|
| Corrida do Caos | Comentar EU | Corredor com nome/foto, obstáculos e linha de chegada | Turbo curto, aura, efeito de pista anunciado | Melhor primeiro teste: leitura visual simples e rodadas curtas |
| Chat contra o Desastre | Comentar EU e escolher 1/2 | Mascotes escapando de lava, vento ou plataforma móvel | Evento visual ou auxílio temporário | Boa segunda opção; precisa de comandos tolerantes ao atraso da LIVE |
| Laboratório do Mascote | Escolher ingredientes pelo chat | Personagem preparando misturas e reagindo | Ingredientes e transformações visíveis | Forte em personalidade; exige mais animações e direção de voz |

## Projetos encontrados e decisão de uso

### 1. vamnguyen/tiktok-live-games

Fonte: https://github.com/vamnguyen/tiktok-live-games

O README e `package.json` descrevem Node.js 18+, Express, Socket.IO, normalização de eventos e uma corrida de cavalos em Canvas 2D. O código `public/games/horse-racing/race-engine.js` separa as regras da apresentação e usa fases de espera, contagem, corrida, resultado e intervalo.

**Utilidade:** referência de organização das rodadas, eventos, contribuições e reconexão.

**Limites verificados:** a entrada em contagem depende de interação; o `tick()` consultado não oferece avanço automático contínuo dos corredores. O projeto utiliza `tiktok-live-connector` da série 1.x. O pacote declara MIT, mas a consulta ao caminho raiz `LICENSE` retornou 404; isso não prova a ausência de licença em outros caminhos. Conferir os termos completos antes de redistribuir código ou arte.

**Decisão:** referência de arquitetura e regras; implementar a adaptação sobre componentes próprios, com progressão automática.

### 2. thorvg/thorvg.demo.marblerace

Fonte: https://github.com/thorvg/thorvg.demo.marblerace

Demo de corrida com nomes, obstáculos e animação física. README documenta até vinte participantes, Node.js 20+ e renderização WebGL, WebGPU ou software. `LICENSE` e `package.json` indicam MIT.

**Utilidade:** referência visual de pista, colisões e identificação dos corredores; código com licença permissiva.

**Limite:** usa Next.js/React e ThorVG. Não foi validado no Termux e não recebe eventos do TikTok por si só. A existência do modo software não comprova desempenho adequado no GT3.

**Decisão:** melhor referência aberta de corrida entre as examinadas para estudar a apresentação e o comportamento da pista. Não é necessário incorporar toda a aplicação Next.js.

### 3. oguzhankayan/SlimeTiktok

Fonte: https://github.com/oguzhankayan/SlimeTiktok

Documentação descreve mascote 3D, reações por presentes, direção de pequenos shows, cache de voz, estado no servidor e ponte de eventos separada. Código principal sob MIT. Em `src/server/dialogue.ts`, foram encontrados limites de fila, prioridades, expiração de falas e interrupção de falas menos prioritárias.

**Utilidade:** boa referência para apresentador, fila de voz e pequenos acontecimentos durante intervalos.

**Limites:** TTS documentado por padrão depende de provedor externo; adaptar para nossa voz local. O arquivo `THIRD_PARTY.md` distingue licença do núcleo, recursos de arte e ponte opcional. O conector dessa ponte tem obrigações próprias. A documentação cita testes, mas esses testes não foram executados nesta pesquisa.

**Decisão:** selecionar componentes de direção e fila; adaptar a personalidade para um mascote original e aproveitar os serviços locais existentes.

### 4. liabru/matter-js

Fonte: https://github.com/liabru/matter-js

Motor de física 2D em JavaScript para navegador, com licença MIT confirmada em `LICENSE`.

**Utilidade:** opção para colisões, quique, rampas e obstáculos de uma versão 2D/2.5D. Deve ser medido com uma quantidade limitada de corpos no aparelho.

**Decisão:** biblioteca candidata para protótipo leve; não exige importar um jogo inteiro ou trocar o servidor existente.

### 5. northoniserhardt/tiktok-live-game

Fonte: https://github.com/northoniserhardt/tiktok-live-game

Cabo de guerra com dois times, entrada por comentário e força por curtidas. Node.js, Express e WebSocket; `package.json` declara ISC. A documentação credita a arte separadamente. Dependências de integração são antigas.

**Utilidade:** referência de regra que cabe em uma frase e de participação gratuita.

**Decisão:** referência de interação; não copiar arte sem verificar seus termos. Exigiria revisão do conector.

### Referências comerciais ou que exigem adaptação maior

- https://github.com/livecade/marble-race-tiktok-live-game — descrição detalhada de um produto hospedado, com avatares, pistas e presentes. Serve como referência de experiência. Nesta consulta, não foi identificada uma base de código licenciada para simplesmente copiar o jogo.
- https://github.com/landsbetween/tiktok-marble-race — implementação documentada em Godot 4 com iniciador Windows. Avatar, comentários, curtidas e pistas aleatórias são boas referências; não é uma instalação direta para Termux. Termos completos ainda precisam ser confirmados.
- https://github.com/LeoDevsn/games-live — biblioteca em português que documenta Windows, Node 24, TikFinity e LIVE Studio. Não é um pacote Android pronto; a pesquisa não confirmou licença geral para reutilizar todo o conjunto.
- https://github.com/characterMi/marble-race — corrida 3D de jogador único em React/Three/Rapier. Não equivale a uma corrida coletiva de LIVE. Consulta ao caminho `LICENSE` retornou 404.
- https://github.com/k0d1r/tiktok-live-interactive-game — batalha entre torres, com entrada por time e eventos. O próprio README informa que não inclui licença; tratar como referência, não como código liberado para redistribuição.
- https://github.com/rongrianthai/last-10-seconds — pacote examinado usa Node, ponte TikTok e PostgreSQL; documentação/licença não foram confirmadas nas URLs consultadas. Não selecionar como base neste momento.
- https://github.com/Andrewj1834/streamer-vs-the-lava — README muito curto; insuficiente para atestar maturidade e licença. Ideia de sobrevivência, sem recomendação de reutilização direta.
- https://github.com/broneotodak/tiktokgame — pacote Node/Express/Socket.IO, ISC declarada; README e termos completos não confirmados nos caminhos consultados.
- https://github.com/DougDougGithub/TwitchPlays — demonstração de controle de teclado/mouse por chat. O caminho de automação de programas de desktop não é a melhor base para o navegador Android.
- https://github.com/phaserjs/phaser — alternativa de engine 2D web; pacote declara MIT. A adoção não é necessária só porque foi encontrada na pesquisa.

## Integração TikTok: ponto material

Fonte: https://github.com/zerodytrash/TikTok-Live-Connector

O repositório atual consultado declara `AGPL-3.0-only`. Seu README também informa que se trata de engenharia reversa e que não é uma API pronta para produção. Não presumir que a licença ou as condições de versões antigas continuam iguais.

Os nossos projetos Pulso Arena/Torre já têm adaptador para `piratetok-live-js`, filas, estado e testes simulados. A documentação local registra que a conexão e os eventos reais ainda precisam de validação no aparelho/conta. A seleção do novo jogo não resolve automaticamente esse risco de integração.

Antes de uma sessão que dependa de presentes, conferir um comentário real, curtidas identificadas quando disponíveis, um presente, o combo final e a reconexão. Curtidas agregadas devem alimentar uma meta coletiva, sem atribuir falsamente ações a um usuário.

## O que aproveitar dos nossos projetos

| Origem | Componentes examinados | Aplicação proposta |
|---|---|---|
| Pulso Arena | `server/live.mjs`, `server/storage.mjs`, `scripts/supervisor.mjs` | Adaptador, persistência, estado real de conexão e recuperação limitada |
| Pulso Arena | `public/world.js`, `public/combat-fx.js`, `public/choreo.js` | Mascotes originais, comemorações, efeitos e enquadramento |
| Pulso Arena | `public/audio.js`, `public/onset.js`, `server/rhythm.mjs`, captador Android documentado | Música, energia da batida e iluminação, com funcionamento independente da corrida |
| Torre TNT | `server/engine.mjs`, `server/storage.mjs`, apresentações de presentes documentadas | Regras simples, metas coletivas, presentes e progresso |
| Ben 10 local | `server/local-ai.js`, `server/conversation.js`, `server/voice.js` | Qwen/voz locais, com nova personalidade e fila limitada |
| Vídeos recentes | Tipografia e edição reativa ao áudio | Clipes curtos mostrando participação real e resultado visível |

**Achado no código existente:** `pulso-arena/server/engine.mjs`, em torno da linha 519, condiciona o andamento da luta à música não estar pausada e, em modo externo, a haver batida recente. Isso pode produzir uma sessão parada quando o sinal musical some. Não é uma prova de que essa foi a causa da baixa audiência do usuário.

**Mudança recomendada no novo jogo:** o relógio das rodadas funciona independentemente de música, IA ou síntese de voz. A narração é uma camada adicional. A falha de áudio mantém animação, nomes e legendas.

## Primeira versão proposta

1. Um cenário vertical de corrida e quatro bases de mascotes originais.
2. Ciclo inicial proposto: 10 segundos de entrada, 35 segundos de corrida e 5 segundos de pódio. Ajustar após observar o público.
3. Comentário `EU`: identificação aparece imediatamente; se a corrida já começou, o usuário entra na próxima bateria.
4. Movimento automático e comandos tolerantes ao atraso do chat; não exigir saltos de precisão por comentários.
5. Curtidas carregam um efeito coletivo. Quando houver identificação confiável, podem alimentar contribuições individuais.
6. Rosa: turbo curto, aura e enquadramento breve do participante. Os valores e limites devem ficar visíveis.
7. Outros efeitos: vento, pista escorregadia ou obstáculo cômico, com aviso e duração limitada.
8. Vitórias rendem pontos, posição no ranking e destaque no pódio.
9. Apresentador com boas-vindas e comemorações em cache. IA responde perguntas curtas, sem atrasar as ações.
10. Estado salvo, logs, modo de teste identificado e retomada após falha. O supervisor não consegue sobreviver ao encerramento completo do Termux pelo Android.

Essas funcionalidades são uma especificação proposta, não uma nova versão já implementada.

## Como escolher com evidência de público

Primeiro validar a leitura dos eventos e uma sessão prolongada no GT3. Depois comparar algumas sessões em condições semelhantes. Amostras pequenas não permitem afirmar causalidade sobre o algoritmo.

Medir:

- Entrada de espectadores e tempo médio de visualização nas estatísticas do próprio TikTok, quando disponíveis.
- Participantes únicos do jogo e primeira interação por sessão.
- Usuários que jogam outra rodada e usuários recorrentes entre sessões.
- Atraso entre evento recebido e reação; falas abandonadas ou atrasadas; FPS, memória e quedas.
- Presentes processados corretamente e receita líquida efetiva informada pela plataforma, sem converter moedas em uma taxa fixa inventada.

Produzir clipes curtos demonstrando o comentário, o avatar e o efeito na mesma sequência. Exemplo de gancho: **“Comenta EU na live. Seu personagem entra na próxima corrida.”** O conteúdo de divulgação deve corresponder ao funcionamento implementado.

Automatizar a sessão ajuda a manter o jogo andando. A escolha do jogo, por si só, não garante que novas pessoas recebam a transmissão no feed nem que enviem presentes. O melhor primeiro investimento é um protótipo pequeno, uma conexão comprovada e medições reais de retenção antes de ampliar os sistemas.
