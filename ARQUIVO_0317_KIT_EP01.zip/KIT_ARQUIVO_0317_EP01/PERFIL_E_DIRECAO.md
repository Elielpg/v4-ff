# Arquivo 03:17

**Nicho escolhido:** suspense urbano e mistérios sobrenaturais em histórias
animadas originais. O criador não precisa aparecer nem gravar a própria voz.

**Nome de exibição:** Arquivo 03:17.
**Nome de usuário sugerido:** `arquivo0317` ou `arquivo.0317`; disponibilidade
precisa ser conferida no cadastro do TikTok. Nenhuma conta foi criada.

**Bio:** Mistérios animados. Toda porta tem uma regra. 🗝️ Ficção original.

**Identidade:** azul petróleo, dourado/âmbar e creme; textura de ilustração,
personagens próprios e chave/relógio como motivos recorrentes. Fonte Anton nas
chamadas e legendas. O relógio 03:17 funciona como assinatura da série.

## Formato editorial

- Episódios de aproximadamente 40–60 segundos, verticais 9:16.
- A primeira frase já apresenta uma situação impossível; sem apresentação longa.
- Personagens recorrentes e pequenas regras que o público consegue compreender.
- Mudança de plano a cada poucos segundos, misturando detalhe, rosto e cenário.
- Narração brasileira em primeiro plano; música original abaixo da voz.
- Uma revelação dentro de cada vídeo e uma pergunta ligada à história no final.
- Identificar os relatos como ficção. Não usar a alegação “aconteceu de verdade”.

O piloto é uma animação ilustrada **2.5D**, feita com poses recortadas, deslocamento
dos personagens, movimento de câmera, parallax, portas, botões, crachá animado,
luzes e partículas. Não é animação tradicional desenhada quadro a quadro de cada
membro do corpo, nem filmagem de pessoas reais.

## Piloto entregue

**EP. 01 — O botão que não existia.** Nina encontra um sétimo andar, sua versão
mais velha e um ascensorista que já conhece seu nome. O vídeo contém a primeira
revelação; o roteiro dos próximos dois episódios continua esse mistério.

Entregues: MP4, capa, foto do perfil, SRT, texto para postar, roteiro, arquivos de
produção e os roteiros escritos de EP. 02/03. Os episódios 02/03 ainda não foram
renderizados. Não há publicação automática nem postagem na conta do TikTok.

## Publicar o piloto

1. Envie o MP4 original ao TikTok para preservar a resolução.
2. Escolha a capa com “O BOTÃO QUE NÃO EXISTIA”; o PNG separado está no pacote.
3. Copie o texto de `LEGENDA_PARA_POSTAR.txt`.
4. Identifique a produção com IA na opção disponível no TikTok.
5. Como já há legendas na imagem, confira se uma segunda legenda automática não
   ficou sobreposta. O SRT também está disponível para reeditar.
6. Ouça no alto-falante e no fone antes de publicar. Evite adicionar outra música
   por cima da narração; a trilha original já foi mixada.

**Comentário sugerido para fixar:** “0, 6 ou 7? E qual foi a pista que você percebeu?”

## Plano de conteúdo

A preferência por uma história em três partes por dia pode ser mantida após
produzir os três vídeos. Para começar, publique o piloto e use os roteiros 02/03
para fechar esse primeiro arco. Depois repita o padrão com novos mistérios.
Horários de teste possíveis: 12h, 17h e 21h, em Brasília; não são horários de
alcance comprovado desta conta nem uma agenda já configurada.

| Arco | Gancho | Pista visual | Revelação planejada |
|---|---|---|---|
| O botão que não existia | O prédio tinha seis andares; apareceu o sete. | Crachá, espelho, chave, visor | O nome confirmado permite transferir a dívida de tempo. |
| A mensagem de amanhã | O áudio chega com a data do dia seguinte. | Ruído de trem e um relógio parado | Quem avisa tenta impedir o próprio encontro. |
| O apartamento sem janela | Toda noite uma janela nova aparece na parede. | Luz de uma casa demolida | A vista mostra a memória de quem morava ali. |
| O passageiro que não desce | A mesma pessoa aparece em três pontos de ônibus. | Bilhete com hora repetida | O percurso segue uma promessa que não foi cumprida. |
| A rua que muda de nome | O GPS chama a rua pelo nome de uma pessoa. | Placa e mapa discordam | A cidade está devolvendo uma lembrança apagada. |
| O retrato atrasado | Na foto, o personagem se move segundos depois. | Reflexo e fotografia não coincidem | A imagem tenta revelar algo fora do enquadramento. |
| A chave sem porta | Uma chave abre apenas um som. | Marcas de uso e uma fita antiga | A porta é uma recordação, não uma parede. |

Observe no TikTok onde as pessoas saem do vídeo, tempo médio assistido,
conclusões, compartilhamentos e comentários sobre a história. Compare aberturas e
ritmo com base nesses dados. Esta proposta não inclui uma medição de alcance nem
promete viralização.
