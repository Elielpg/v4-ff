const fs=require('node:fs');const path=require('node:path');const{spawn}=require('node:child_process');const{once}=require('node:events');const{createCanvas,loadImage,GlobalFonts}=require('@napi-rs/canvas');
const ROOT=__dirname,W=1080,H=1920,FPS=30,story=JSON.parse(fs.readFileSync(path.join(ROOT,'timeline.json'))),timeline=story.timeline,DURATION=Math.ceil((story.duration+.25)*FPS)/FPS;
GlobalFonts.registerFromPath(path.join(ROOT,'assets/Anton-Regular.ttf'),'Anton');
const canvas=createCanvas(W,H),ctx=canvas.getContext('2d');let corridor,cast,extra,captions=[];
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},lerp=(a,b,t)=>a+(b-a)*t;
function rr(x,y,w,h,r,fill,stroke=null,lw=2){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw;ctx.stroke()}}
function ellipse(x,y,rx,ry,fill){ctx.beginPath();ctx.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill()}
function line(x1,y1,x2,y2,color,width=3){ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.stroke()}
function polygon(points,color,stroke=null,width=3){ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.closePath();ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke()}}
function gradient(x0,y0,x1,y1,stops){const g=ctx.createLinearGradient(x0,y0,x1,y1);stops.forEach(([p,c])=>g.addColorStop(p,c));return g}
function text(str,x,y,size=70,color='#fff1d7',align='center',stroke=6,font='Anton'){ctx.font=`${size}px ${font}`;ctx.textAlign=align;ctx.textBaseline='middle';if(stroke){ctx.lineJoin='round';ctx.lineWidth=stroke;ctx.strokeStyle='#080f16';ctx.strokeText(str,x,y)}ctx.fillStyle=color;ctx.fillText(str,x,y)}
function glow(x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
function imageCover(image,zoom=1,x=.5,y=.5){const scale=Math.max(W/image.width,H/image.height)*zoom,w=image.width*scale,h=image.height*scale;ctx.drawImage(image,(W-w)*x,(H-h)*y,w,h)}
function shade(alpha=.25){ctx.fillStyle=`rgba(3,12,20,${alpha})`;ctx.fillRect(0,0,W,H)}
function particles(t,count=65){for(let i=0;i<count;i++){const x=(i*173.71+Math.sin(t*.2+i)*35)%W,y=(i*277.31-t*(11+i%9)+H*20)%H;ellipse(x,y,1+i%3,1+i%3,`rgba(255,224,176,${.07+(i%5)*.02})`)}}
function sprite(index,x,y,height,t,{flip=false,alpha=1,variant=false,angle=0,walk=false,shadow=true}={}){
 const img=variant?extra:cast,sw=img.width/3,sh=img.height,width=height*sw/sh,bob=walk?Math.abs(Math.sin(t*8))*12:Math.sin(t*2.1+index)*3;
 if(shadow)ellipse(x,y-5,width*.36,19,'#02080d66');ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y-bob);ctx.rotate(angle+(walk?Math.sin(t*8)*.011:Math.sin(t*.9+index)*.003));ctx.scale(flip?-1:1,1+Math.sin(t*2)*.0015);ctx.drawImage(img,index*sw,0,sw,sh,-width/2,-height,width,height);ctx.restore();
}
function hallway(t,zoom=1){imageCover(corridor,zoom,.5,.5);shade(.08);particles(t);glow(500,350,480,'#e89d2633');}
function metal(x,y,w,h){rr(x,y,w,h,8,gradient(x,y,x+w,y,[[0,'#101f27'],[.17,'#3d4c4f'],[.49,'#23373e'],[.84,'#4d5c5b'],[1,'#10242f']]),'#9b805b',6);for(let k=0;k<24;k++)line(x+(k+.5)*w/24,y+5,x+(k+.5)*w/24,y+h-5,'#b6c3b507',1)}
function elevator(t,{open=0,mirror=false,display='6'}={}){
 ctx.fillStyle='#0b1c24';ctx.fillRect(0,0,W,H);polygon([[90,220],[990,220],[880,1410],[205,1410]],'#263c42','#151e23',8);polygon([[0,0],[140,220],[205,1410],[0,H]],'#173139');polygon([[1080,0],[950,220],[880,1410],[1080,H]],'#122b32');
 polygon([[205,1410],[880,1410],[W,H],[0,H]],gradient(0,1400,0,H,[[0,'#243035'],[1,'#10242e']]));for(let i=0;i<12;i++)line(i*120,1920,540+(i*120-540)*.45,1410,'#94aaa821',3);
 metal(105,210,870,1230);rr(450,240,185,135,16,'#0d1b20','#ba9864',5);text(display,542,304,100,display==='8'?'#ff816a':'#f6cb72');
 if(mirror){rr(170,425,590,910,16,'#224f5a','#c0a06c',12);polygon([[185,440],[330,440],[745,1240],[745,1320],[650,1320]],'#b3ecdd13')}
 else{metal(180,425,720,1000);line(540,430,540,1420,'#070c10',8);if(open>0){ctx.save();ctx.beginPath();ctx.rect(180,425,720,1000);ctx.clip();ctx.save();ctx.translate(90,200);ctx.scale(.85,.85);hallway(t,1);ctx.restore();metal(180-350*open,425,360*(1-open)+15,1000);metal(540+350*open,425,360*(1-open)+15,1000);ctx.restore()}}
 line(140,1010,940,1010,'#bea67b',14);line(140,1020,940,1020,'#090f13',5);glow(540,60,550,'#dfb67426');rr(340,75,400,55,16,'#fff4cf');
 for(const x of[65,1010])line(x,220,x,1630,'#b89057',6);
}
function cabFrame(t){metal(-30,0,100,1920);metal(1010,0,100,1920);line(75,0,75,1920,'#e0ad62',5);line(1005,0,1005,1920,'#d7a760',5);}
function button(x,y,label,active=false,r=65,t=0){if(active)glow(x,y,r*2.4,'#f8b95655');ellipse(x,y,r+8,r+8,'#080f13');ellipse(x,y,r,r,gradient(x-r,y-r,x+r,y+r,[[0,active?'#ffe0a0':'#a7b1aa'],[.42,active?'#d5a044':'#4d696a'],[1,active?'#92542a':'#152b33']]));ellipse(x,y,r-11,r-11,active?'#e2bc76':'#102933');text(String(label),x,y+2,r*1.08,active?'#25170b':'#b2cfcc','center',0);if(active){ctx.strokeStyle='#fff0b1';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,r+13+Math.sin(t*4)*2,0,Math.PI*2);ctx.stroke()}}
function panel(t,p=0,{digits=true,choice=false,eight=false}={}){
 ctx.fillStyle='#102730';ctx.fillRect(0,0,W,H);metal(120,130,840,1630);rr(240,250,600,250,24,'#0b181e','#a4895f',7);text(eight?'8':p>.35?'7':'6',540,370,205,eight?'#ff8067':'#ffd58a','center',0);text('03:17',540,565,47,'#a4c1be','center',0,'DejaVu Sans');
 if(choice){for(const[i,n]of['0','6','7'].entries())button(270+i*270,1000,n,n==='7',93,t);text('QUAL BOTÃO?',540,760,110,'#ffe9b2');}
 else{for(let i=0;i<6;i++){const x=320+(i%3)*220,y=780+Math.floor(i/3)*230;button(x,y,i+1,false,75,t);}if(digits){const a=ease((p-.03)*5);ctx.globalAlpha=a;button(540,1295,7,true,95,t);ctx.globalAlpha=1;}}
}
function finger(t,p){const x=lerp(1120,630,ease(p)),y=lerp(1880,1395,ease(p));ctx.save();ctx.translate(x,y);ctx.rotate(-.35);ctx.beginPath();ctx.moveTo(0,220);ctx.bezierCurveTo(-35,140,-90,55,-92,-50);ctx.bezierCurveTo(-96,-150,-40,-165,-20,-110);ctx.lineTo(15,0);ctx.bezierCurveTo(95,-25,135,10,152,75);ctx.lineTo(185,220);ctx.closePath();ctx.fillStyle='#bc835c';ctx.fill();ctx.strokeStyle='#432d29';ctx.lineWidth=8;ctx.stroke();line(-64,-67,-41,-75,'#e9b48a',8);ctx.restore()}
function badge(t,p){const turn=clamp((p-.28)/.3),s=Math.abs(Math.cos(turn*Math.PI));ctx.save();ctx.translate(540,990+Math.sin(t*2)*7);ctx.scale(Math.max(.04,s),1);ctx.rotate(-.035+Math.sin(t)*.01);rr(-395,-230,790,460,35,gradient(-390,-250,380,250,[[0,'#fff0ad'],[.3,'#ce9b4e'],[.75,'#f5cc7c'],[1,'#86532b']]),'#30251c',13);rr(-370,-207,740,414,22,null,'#fff1b7',5);if(turn>.5)text('NINA',0,0,210,'#2c2420','center',0);else text('?',0,0,200,'#62482d','center',0);ctx.save();ctx.beginPath();ctx.roundRect(-388,-222,776,444,28);ctx.clip();polygon([[-700+t*210,-250],[-565+t*210,-250],[-170+t*210,250],[-310+t*210,250]],'#fffbe52a');ctx.restore();ctx.restore();}
function keyProp(x,y,scale,t){ctx.save();ctx.translate(x,y);ctx.rotate(Math.sin(t)*.08);ctx.scale(scale,scale);ellipse(0,0,37,37,'#d8ad5b');ellipse(0,0,23,23,'#183039');rr(-10,27,20,130,4,'#c99443','#3a2b1f',3);rr(5,112,37,18,3,'#e0b565','#3a2b1f',3);rr(5,141,26,18,3,'#e0b565','#3a2b1f',3);ctx.restore()}
function mirrorScene(t,p,{boy=false,gray=false}={}){
 elevator(t,{mirror:true,display:'8'});ctx.save();ctx.beginPath();ctx.roundRect(175,430,580,900,12);ctx.clip();ctx.fillStyle=gradient(180,430,750,1350,[[0,'#204d5a'],[1,'#0c222c']]);ctx.fillRect(175,430,580,900);if(boy)sprite(2,650,1470,1060,t,{variant:true,flip:true,alpha:ease(p*2),shadow:false});sprite(0,390,1520,1050,t,{variant:gray,flip:true,shadow:false});ctx.fillStyle='#bbead913';ctx.fillRect(175,430,580,900);polygon([[180,430],[255,430],[755,1250],[755,1320],[700,1320]],'#bafff516');ctx.restore();sprite(0,860,1920,1180,t,{variant:gray,flip:false,shadow:false});cabFrame(t);
}
function shot(t,seg,p){const id=seg.id,local=t-seg.start;
 ctx.save();const zoom=id==='hook'?1:1+.018*Math.sin(p*Math.PI);ctx.translate(W/2,H/2);ctx.scale(zoom,zoom);ctx.rotate(Math.sin(t*.7)*.002);ctx.translate(-W/2,-H/2);
 if(id==='hook'){panel(t,p);text(p<.5?'SÓ EXISTIAM':'MAS APARECEU',540,215,76,'#ffe2a0');text(p<.5?'6 ANDARES.':'UM BOTÃO A MAIS.',540,640,82,'#fff5dc');}
 if(id==='press'){panel(t,1);finger(t,ease(p*1.6));glow(540,1295,180,'#fff2bc22');}
 if(id==='corridor'){hallway(t,1+ease(p)*.045);cabFrame(t);if(p<.34){const open=ease(p/.34);metal(-420*open,0,540*(1-open),1920);metal(540+540*open,0,540*(1-open),1920);}else sprite(0,lerp(950,720,ease((p-.3)/.6)),1780,1060,t,{walk:p<.8});}
 if(id==='key'){hallway(t,1.04+p*.045);sprite(1,570,1580,lerp(680,1120,ease(p)),t);if(p>.6)glow(530,650,210,'#ffc96418');}
 if(id==='future'){hallway(t,1.15);shade(.18);const alpha=ease(p*5);sprite(0,220,2140,1740,t,{alpha:1,flip:false});sprite(1,850,2110,1740,t,{alpha});line(540,360,540,1360,'#e1bc6b77',2);if(p>.32)text('ERA EU.',540,250,138,'#ffe4a9');}
 if(id==='warning'){hallway(t,1.14);shade(.15);sprite(1,550,1830,1540,t,{variant:true});text('NÃO DIGA SEU NOME.',540,245,80,'#f0c372');}
 if(id==='boy'){hallway(t,1.08);sprite(2,lerp(800,560,ease(p)),1650,lerp(750,1080,ease(p)),t,{walk:true});glow(570,560,400,'#1f81a122');}
 if(id==='question'){hallway(t,1.12);shade(.1);sprite(2,550,1990,1680,t,{variant:p>.45});}
 if(id==='silence'){elevator(t,{display:'7'});sprite(0,530,2050,1740,t);text('...',770,600,130,'#fff1d5');}
 if(id==='badge'){hallway(t,1.13);sprite(2,555,1770,1250,t,{variant:true});shade(.35);badge(t,p);}
 if(id==='pull'){hallway(t,1.05);const move=ease(p);sprite(0,lerp(730,420,move),1810,1190,t,{walk:true,angle:move*-.055});sprite(1,lerp(400,300,move),1770,1180,t,{walk:true,flip:true});cabFrame(t);if(p>.78){const a=ease((p-.78)/.22);metal(-540+540*a,0,540,1920);metal(1080-540*a,0,540,1920);}}
 if(id==='eight'){panel(t,p,{digits:false,eight:true});glow(540,375,420,'#ff69552b');text('NÃO ERA O TÉRREO.',540,1000,98,'#ffe5bd');}
 if(id==='cry'){elevator(t,{display:'8'});sprite(1,550,1980,1730,t,{variant:false});shade(.05);glow(500,650,500,'#d6843316');text('O PREÇO ERA O TEMPO.',540,225,77,'#f7d29b');}
 if(id==='mirror'){mirrorScene(t,p,{gray:p>.25});if(p>.5)glow(355,620,100,'#effaff35');}
 if(id==='reflection'){mirrorScene(t,p,{gray:true,boy:true});if(p>.4)shade(.08);}
 if(id==='cta'){panel(t,1,{choice:true});text('NÃO DEMORE.',540,1300,84,'#f0c67b');}
 ctx.restore();
 // Cut accents: a brief amber sweep, restrained instead of hard strobing.
 if(local>=0&&local<.12&&id!=='hook'){ctx.globalAlpha=(1-local/.12)*.12;ctx.fillStyle='#f9d99e';ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;}
}
function brand(t){const vg=ctx.createLinearGradient(0,0,0,H);vg.addColorStop(0,'#030b1390');vg.addColorStop(.23,'transparent');vg.addColorStop(.66,'transparent');vg.addColorStop(1,'#030b13c0');ctx.fillStyle=vg;ctx.fillRect(0,0,W,H);rr(50,72,460,76,18,'#0b2024b0','#b28f5466',2);text('ARQUIVO 03:17',82,111,40,'#e9c587','left',0);rr(822,72,198,76,18,'#0b2024b0','#b28f5466',2);text('EP. 01',920,111,40,'#e9d9b7','center',0);text('FICÇÃO ORIGINAL • ANIMAÇÃO COM IA',540,1736,24,'#e2d8c5b0','center',0,'DejaVu Sans');
 const progress=t/DURATION;rr(70,1800,940,4,2,'#dec18c23');rr(70,1800,Math.max(1,940*progress),4,2,'#e3c68c90');
}
function subtitles(t){const cue=captions.find(c=>t>=c.start&&t<c.end);if(!cue)return;const words=cue.words||cue.text.split(' ').map(text=>({text}));const full=words.map(w=>w.text).join(' ').toUpperCase();ctx.font='76px Anton';let rows=[words];if(ctx.measureText(full).width>850){let best=1,delta=1e9;for(let i=1;i<words.length;i++){const a=ctx.measureText(words.slice(0,i).map(w=>w.text).join(' ').toUpperCase()).width,b=ctx.measureText(words.slice(i).map(w=>w.text).join(' ').toUpperCase()).width;if(Math.max(a,b)<delta){delta=Math.max(a,b);best=i}}rows=[words.slice(0,best),words.slice(best)]}
 const startY=rows.length>1?1445:1485;ctx.save();ctx.translate(0,(1-ease((t-cue.start)*18))*8);ctx.shadowColor='#02070bee';ctx.shadowBlur=18;ctx.shadowOffsetY=5;
 for(let row=0;row<rows.length;row++){const group=rows[row],spaces=18,width=group.reduce((n,w)=>n+ctx.measureText(w.text.toUpperCase()).width,0)+(group.length-1)*spaces;let x=505-width/2;for(const w of group){const str=w.text.toUpperCase(),size=ctx.measureText(str).width,active=w.start!==undefined&&t>=w.start-.025&&t<=w.end+.045;const emphasis=/^(NINA|SETE|OITO|NOME|ANOS|EU\.?|NÃO|7|8)[!?.,:]?$/.test(str);ctx.lineWidth=12;ctx.strokeStyle='#050b11';ctx.textAlign='left';ctx.textBaseline='middle';ctx.lineJoin='round';ctx.strokeText(str,x,startY+row*94);ctx.fillStyle=active?'#ffd77d':emphasis?'#ffe1a3':'#fff7e5';ctx.fillText(str,x,startY+row*94);x+=size+spaces;}}
 ctx.restore();}
function render(t){ctx.clearRect(0,0,W,H);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';const seg=timeline.find(x=>t>=x.start&&t<x.end+x.pause)||(t<timeline[0].start?timeline[0]:timeline.at(-1)),p=clamp((t-seg.start)/Math.max(.01,seg.duration));shot(t,seg,p);brand(t);subtitles(t);}
async function init(){fs.mkdirSync(path.join(ROOT,'output'),{recursive:true});fs.mkdirSync(path.join(ROOT,'delivery'),{recursive:true});[corridor,cast,extra]=await Promise.all(['corredor.png','personagens.png','personagens_extra.png'].map(f=>loadImage(path.join(ROOT,'assets',f))));captions=JSON.parse(fs.readFileSync(path.join(ROOT,'captions.json')));}
async function main(){await init();const args=process.argv.slice(2);if(args.includes('--stills')){for(const id of ['hook','corridor','future','warning','badge','eight','mirror','reflection','cta']){const s=timeline.find(s=>s.id===id);render(s.start+s.duration*.64);fs.writeFileSync(path.join(ROOT,'output',`frame_${id}.png`),canvas.toBuffer('image/png'));}hallway(0,1.1);shade(.17);sprite(2,840,1690,1010,0,{variant:true});sprite(0,390,1940,1420,0);glow(775,1260,250,'#e6b55530');button(780,1260,7,true,120,0);brand(0);text('O BOTÃO QUE',540,250,105,'#fff1d6');text('NÃO EXISTIA',540,390,132,'#ffd379');fs.writeFileSync(path.join(ROOT,'delivery','CAPA_ARQUIVO_0317_EP01.png'),canvas.toBuffer('image/png'));console.log('STILLS_OK');return;}
 const total=Math.ceil(DURATION*FPS),outfile=path.join(ROOT,'output/video_sem_audio.mp4');const ff=spawn('ffmpeg',['-y','-hide_banner','-loglevel','warning','-f','rawvideo','-pixel_format','rgba','-video_size',`${W}x${H}`,'-framerate',String(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','4','-pix_fmt','yuv420p','-profile:v','high','-level:v','4.2','-movflags','+faststart',outfile],{stdio:['pipe','ignore','inherit']});ff.stdin.on('error',()=>{});const start=Date.now();
 for(let frame=0;frame<total;frame++){render(frame/FPS);const raw=canvas.data();if(!ff.stdin.write(raw))await once(ff.stdin,'drain');if(frame%150===0)console.log(JSON.stringify({frame,total,seconds:Math.round((Date.now()-start)/1000)}));}
 ff.stdin.end();const[code]=await once(ff,'exit');if(code)throw Error('ffmpeg '+code);console.log(JSON.stringify({done:true,frames:total,duration:DURATION,seconds:(Date.now()-start)/1000}));}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1});
