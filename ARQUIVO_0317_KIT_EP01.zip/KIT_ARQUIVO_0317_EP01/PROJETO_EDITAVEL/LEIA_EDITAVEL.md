# Arquivo 03:17 — projeto de produção do piloto

O vídeo pronto está na raiz do kit. Esta pasta é a fonte editável em código,
com as artes, a narração existente e os arquivos de tempo. Não é um projeto
proprietário do CapCut/Premiere. As imagens/áudios/SRT também podem ser importados
no editor de sua preferência.

## Reexportar com a voz existente

Pipeline validado em Linux/desktop. Requer Node 22+, Python 3.12+ e FFmpeg com libx264/AAC:

```bash
npm ci
python3 -m venv .venv
.venv/bin/pip install numpy scipy soundfile
.venv/bin/python soundtrack.py
node render.cjs
.venv/bin/python finish.py
.venv/bin/python validate.py
```

`node render.cjs --stills` gera as prévias/capa sem renderizar todo o filme.
As artes são recortadas pelo compositor a partir de duas folhas de personagens.
Não há alteração dos arquivos originais da geração.

- `story.json`: roteiro por fala/voz/ritmo.
- `timeline.json`: duração real dos segmentos de voz produzidos.
- `captions.json`: palavras e blocos de legenda sincronizados.
- `render.cjs`: cenas 2.5D, tipografia, movimentos e câmera.
- `soundtrack.py`: trilha e efeitos originais, com redução sob a fala.
- `finish.py`: masterização e MP4, incluindo corte de 100ms de preparação inicial
  aplicado igualmente ao áudio/vídeo e ao SRT externo.
- `audio/`: narração, falas separadas, trilha e efeitos existentes.
- `assets/`: imagens e fonte; licenças incluídas.

## Trocar o texto da voz

Instale `requirements.txt` e baixe os modelos públicos nos caminhos abaixo.
Não é necessário baixar modelos para usar o MP4 pronto ou editar as imagens.

Kokoro, em `assets/`:

- https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/kokoro-v1.0.onnx
- https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/voices-v1.0.bin

Whisper base, em `assets/whisper-base/`, baixe `model.bin`, `config.json`,
`tokenizer.json` e `vocabulary.txt` do repositório público:
https://huggingface.co/Systran/faster-whisper-base/tree/main

Depois:

```bash
.venv/bin/python tts.py
.venv/bin/python captions.py --asr
.venv/bin/python soundtrack.py
node render.cjs
.venv/bin/python finish.py
.venv/bin/python validate.py
```

A narração e a duração precisam ser regeneradas juntas após mudar o texto.
O vídeo entregue usa 1080×1920, 30fps, H.264 e AAC estéreo. O áudio foi medido
após a exportação, e a reprodução/decodificação foi conferida. Consulte o JSON de
validação no kit para valores efetivamente medidos.
