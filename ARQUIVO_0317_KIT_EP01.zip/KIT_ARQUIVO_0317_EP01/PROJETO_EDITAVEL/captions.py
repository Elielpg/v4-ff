from pathlib import Path
import json,re,unicodedata,difflib,sys
root=Path(__file__).resolve().parent;story=json.loads((root/'timeline.json').read_text());known=[]
for seg in story['timeline']:
 words=seg['text'].split();weights=[max(2,len(w.strip('.,!?;:')))for w in words];denom=sum(weights);pos=seg['start']
 for w,k in zip(words,weights):
  d=seg['duration']*k/denom;known.append({'text':w,'start':pos,'end':pos+d,'segment':seg['id'],'min':seg['start'],'max':seg['end']});pos+=d
mode='weighted phrase timing'
if '--asr'in sys.argv:
 from faster_whisper import WhisperModel
 model=WhisperModel(str(root/'assets/whisper-base'),device='cpu',compute_type='int8',cpu_threads=4,num_workers=1)
 import soundfile as sf
 from scipy.signal import resample_poly
 audio,sample_rate=sf.read(root/'audio/narracao.wav',dtype='float32')
 audio=resample_poly(audio,16000,sample_rate)
 segments,info=model.transcribe(audio,language='pt',beam_size=5,word_timestamps=True,condition_on_previous_text=False,initial_prompt='História em português brasileiro. Nina, elevador, crachá, térreo, seis andares, sete, oito.')
 recognized=[]
 for s in segments:
  print(round(s.start,2),round(s.end,2),s.text,flush=True)
  recognized.extend({'text':w.word.strip(),'start':w.start,'end':w.end,'probability':w.probability}for w in(s.words or[]))
 (root/'output/recognized_words.json').write_text(json.dumps(recognized,ensure_ascii=False,indent=2))
 def norm(w):
  w=re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFD',w.lower()).encode('ascii','ignore').decode());return {'seis':'6','sete':'7','oito':'8','trinta':'30'}.get(w,w)
 seq=difflib.SequenceMatcher(a=[norm(w['text'])for w in known],b=[norm(w['text'])for w in recognized],autojunk=False);matched={}
 for block in seq.get_matching_blocks():
  for k in range(block.size):
   a=block.a+k;b=block.b+k;r=recognized[b];q=known[a]
   if r['start']>=q['min']-.3 and r['end']<=q['max']+.4:matched[a]=r
 for seg in story['timeline']:
  ids=[i for i,w in enumerate(known)if w['segment']==seg['id']]
  last=seg['start']
  for i in ids:
   if i in matched:
    r=matched[i];known[i]['start']=max(last,min(seg['end']-.015,r['start']));known[i]['end']=max(known[i]['start']+.015,min(seg['end'],r['end']));last=known[i]['end']
  # Fill unrecognized words between neighboring aligned words without inventing transcript.
  j=0
  while j<len(ids):
   if ids[j]in matched:j+=1;continue
   a=j
   while j<len(ids)and ids[j]not in matched:j+=1
   start=known[ids[a-1]]['end']if a>0 else seg['start'];end=known[ids[j]]['start']if j<len(ids)else seg['end'];end=max(start+.02*(j-a),end);weights=[max(2,len(known[ids[k]]['text']))for k in range(a,j)];cursor=start
   for k,weight in zip(range(a,j),weights):
    d=(end-start)*weight/sum(weights);known[ids[k]]['start']=cursor;known[ids[k]]['end']=cursor+d;cursor+=d
 mode='Whisper base word timestamps aligned to original script'
 (root/'output/ALIGNMENT.json').write_text(json.dumps({'method':mode,'matchedWords':len(matched),'scriptWords':len(known),'ratio':len(matched)/len(known),'language':info.language,'languageProbability':info.language_probability},indent=2))
# Group by short phrases, retaining authored punctuation/case; avoid an unreadable word-at-a-time stream.
cues=[];group=[]
for i,w in enumerate(known):
 if group and(group[-1]['segment']!=w['segment']or len(group)>=4 or len(' '.join(v['text']for v in group))+len(w['text'])>27):
  cues.append(group);group=[]
 group.append(w)
 if w['text'].endswith(('.', '?','!',':')):
  cues.append(group);group=[]
if group:cues.append(group)
stop={'a','o','as','os','de','do','da','dos','das','em','no','na','e','um','uma','meu','minha','seu','sua'}
for i in range(len(cues)-1):
 while len(cues[i])>1 and cues[i][-1]['text'].lower()in stop and cues[i][-1]['segment']==cues[i+1][0]['segment']:
  cues[i+1].insert(0,cues[i].pop())
final=[]
for i,g in enumerate(cues):
 start=max(0,g[0]['start']-.025);end=min(story['duration'],g[-1]['end']+.07)
 if i+1<len(cues):end=min(end,max(start+.04,cues[i+1][0]['start']-.01))
 final.append({'start':round(start,3),'end':round(max(start+.04,end),3),'text':' '.join(w['text']for w in g),'words':[{'text':w['text'],'start':round(w['start'],3),'end':round(w['end'],3)}for w in g]})
(root/'captions.json').write_text(json.dumps(final,ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
(root/'delivery/LEGENDAS_EP01.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}'for i,c in enumerate(final))+'\n',encoding='utf-8')
print(json.dumps({'method':mode,'cues':len(final),'words':len(known)},ensure_ascii=False))
