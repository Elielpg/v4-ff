from pathlib import Path
import json,math
import numpy as np,soundfile as sf
from scipy.signal import butter,sosfilt,resample_poly
root=Path(__file__).resolve().parent;s=json.loads((root/'timeline.json').read_text());sr=48000;duration=math.ceil((s['duration']+.25)*30)/30;N=int(duration*sr);rng=np.random.default_rng(317);music=np.zeros((N,2),np.float32);fx=np.zeros_like(music)
voice,vsr=sf.read(root/'audio/narracao.wav',dtype='float32');voice=resample_poly(voice,sr,vsr);voice=np.pad(voice,(0,max(0,N-len(voice))))[:N];voices=np.column_stack([voice,voice]);
def env(n,attack=.03,release=.3):
 x=np.ones(n,np.float32);a=min(n//2,int(sr*attack));b=min(n//2,int(sr*release));x[:a]=np.linspace(0,1,a);x[-b:]=np.linspace(1,0,b);return x

def put(target,signal,at,level=1,pan=0):
 i=max(0,int(at*sr));signal=np.asarray(signal,np.float32);m=min(N-i,len(signal));
 if m<=0:return
 gains=np.array([math.cos((pan+1)*math.pi/4),math.sin((pan+1)*math.pi/4)],np.float32)
 if signal.ndim==1:target[i:i+m]+=signal[:m,None]*gains*level
 else:target[i:i+m]+=signal[:m]*level

def bell(f,secs=2.5):
 t=np.arange(int(sr*secs))/sr;return((np.sin(2*np.pi*f*t)+.33*np.sin(2*np.pi*f*2.71*t)*np.exp(-t*3)+.16*np.sin(2*np.pi*f*4.16*t)*np.exp(-t*6))*np.exp(-t*2.9)*env(len(t),.004,.18)).astype(np.float32)
# Original score: low E pedal, slow minor-color bells, subtle pulse. No sampled recording.
t=np.arange(N)/sr;pad=(np.sin(2*np.pi*41.203*t)+.35*np.sin(2*np.pi*61.735*t)+.16*np.sin(2*np.pi*82.407*t))*(.8+.2*np.sin(t*.31));pad=sosfilt(butter(2,180,fs=sr,output='sos'),pad).astype(np.float32);put(music,pad,0,.018)
notes=[329.628,293.665,246.942,261.626,329.628,391.995,293.665,246.942];beat=60/82
for i,at in enumerate(np.arange(.7,duration,beat*2)):
 sound=bell(notes[i%len(notes)]*(.5 if i%7==6 else 1),3.4);put(music,sound,at,.052,math.sin(i*1.3)*.6)
 put(music,sound,at+.24,.011,math.sin(i*1.3+.8)*.6)
for at in np.arange(.2,duration,beat):
 q=np.arange(int(sr*.18))/sr;k=np.sin(2*np.pi*(54*q-25*q*q))*np.exp(-q*24);put(music,k,at,.024)

def whoosh(at,secs=.5,level=.10,pan=0):
 n=int(sr*secs);a=rng.normal(0,1,n);a=sosfilt(butter(2,[400,5000],btype='bandpass',fs=sr,output='sos'),a);a*=np.sin(np.linspace(0,np.pi,n))**2;put(fx,a,at,level,pan)
def ding(at,pitch=880):
 put(fx,bell(pitch,.9),at,.11,.1);put(fx,bell(pitch*1.5,.8),at+.12,.055,-.1)
def dark_hit(at):
 x=np.arange(int(sr*1.1))/sr;a=(np.sin(2*np.pi*(49*x-14*x*x))*.6+rng.normal(0,.10,len(x)))*np.exp(-x*5);put(fx,a,at,.13)
def tick(at):
 x=np.arange(int(sr*.08))/sr;a=(rng.normal(0,.15,len(x))+np.sin(2*np.pi*1500*x)) *np.exp(-x*110);put(fx,a,at,.06,.25)
T={x['id']:x for x in s['timeline']}
ding(T['hook']['start']+4.25,740);tick(T['press']['start']+.32);whoosh(T['corridor']['start'],.9,.095)
# Elevator motor and sliding mechanism.
for id in ['press','pull']:
 at=T[id]['start'];n=int(sr*(T[id]['duration']+.2));x=np.arange(n)/sr;a=(np.sin(2*np.pi*93*x)+.18*rng.normal(0,1,n))*env(n,.2,.3);put(fx,a,at,.025)
whoosh(T['future']['start']-.08,.55,.075,-.3);dark_hit(T['future']['start']+.1)
ding(T['boy']['start'],660);tick(T['badge']['start']+T['badge']['duration']*.55);dark_hit(T['badge']['start']+T['badge']['duration']*.55)
whoosh(T['pull']['start']+.7,.8,.075);ding(T['eight']['start']+.2,530);dark_hit(T['eight']['start']+.15)
for off in [.2,.62,1.1]:tick(T['mirror']['start']+off)
whoosh(T['reflection']['start']+.45,.8,.055,.55);dark_hit(T['reflection']['start']+.65)
# Subtle cinematic tails and automatic dialogue ducking, without a distorted voice.
for stem in [music,fx]:
 for delay,gain in [(.17,.13),(.34,.07)]:
  d=int(sr*delay);stem[d:]+=stem[:-d].copy()*gain
power=np.convolve(np.abs(voice),np.ones(960)/960,mode='same');duck=1-.75*np.clip(power/.1,0,1);music*=duck[:,None]
# A short quiet pocket emphasizes the choice not to answer the boy.
a=int(T['silence']['start']*sr);b=int((T['silence']['end']+.12)*sr);music[a:b]*=.18
fade=env(N,.08,.5);music*=fade[:,None];fx*=fade[:,None];mix=voices+music+fx
peak=float(np.max(np.abs(mix)));mix*=min(1,.94/max(peak,.001))
sf.write(root/'audio/trilha_original.wav',music,sr,subtype='PCM_16');sf.write(root/'audio/efeitos.wav',fx,sr,subtype='PCM_16');sf.write(root/'audio/mix_pre_master.wav',mix,sr,subtype='PCM_24')
# Useful during editable re-renders; speech envelope is not a speech-recognition model.
energy=[]
for frame in range(math.ceil(duration*30)):
 z=voice[int(frame*sr/30):int((frame+1)*sr/30)];energy.append(round(float(np.sqrt(np.mean(z*z))) if len(z) else 0,4))
(root/'audio/energy.json').write_text(json.dumps(energy));print(json.dumps({'seconds':duration,'sampleRate':sr,'music':'original synthesis','preMasterPeak':float(np.max(np.abs(mix)))},indent=2))
