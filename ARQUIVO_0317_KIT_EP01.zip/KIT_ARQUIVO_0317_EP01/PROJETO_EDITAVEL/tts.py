from pathlib import Path
import json,time,wave
import numpy as np,soundfile as sf,onnxruntime as ort
from kokoro_onnx import Kokoro
root=Path(__file__).resolve().parent
opts=ort.SessionOptions();opts.intra_op_num_threads=4;opts.inter_op_num_threads=1
session=ort.InferenceSession(str(root/'assets/kokoro-v1.0.onnx'),sess_options=opts,providers=['CPUExecutionProvider'])
k=Kokoro.from_session(session,str(root/'assets/voices-v1.0.bin'))
print('VOICES',[x for x in k.voices.files if x.startswith('p')],flush=True)
story=json.loads((root/'story.json').read_text());timeline=[];full=[];sr=24000;cursor=.1;full.append(np.zeros(int(cursor*sr),np.float32));start=time.time()
for item in story['segments']:
 speech,sr=k.create(item['text'],voice=item['voice'],speed=item['speed'],lang='pt-br',sentence_pause=.16,clause_pause=.06)
 # Preserve articulation, avoid extreme pitch/time processing or clipped endings.
 speech=np.asarray(speech,dtype=np.float32);nz=np.flatnonzero(np.abs(speech)>.002)
 if len(nz):speech=speech[max(0,nz[0]-int(.035*sr)):min(len(speech),nz[-1]+int(.10*sr))]
 peak=np.max(np.abs(speech)) or 1;speech*=min(1.4,.78/peak)
 fade=min(int(.012*sr),len(speech)//2);speech[:fade]*=np.linspace(0,1,fade);speech[-fade:]*=np.linspace(1,0,fade)
 sf.write(root/'audio'/f'{item["id"]}.wav',speech,sr)
 duration=len(speech)/sr;timeline.append({**item,'start':round(cursor,4),'end':round(cursor+duration,4),'duration':round(duration,4)})
 full.extend([speech,np.zeros(int(item['pause']*sr),np.float32)]);cursor+=duration+item['pause'];print(item['id'],round(duration,2),flush=True)
full=np.concatenate(full);sf.write(root/'audio/narracao.wav',full,sr)
story['timeline']=timeline;story['duration']=len(full)/sr
(root/'timeline.json').write_text(json.dumps(story,ensure_ascii=False,indent=2))
print(json.dumps({'duration':len(full)/sr,'generationSeconds':time.time()-start,'sampleRate':sr},indent=2),flush=True)
