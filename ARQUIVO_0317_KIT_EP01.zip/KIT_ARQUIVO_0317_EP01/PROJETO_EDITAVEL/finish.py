"""Master audio, combine the video and export the matching external subtitles."""
from pathlib import Path
import json,subprocess,re,math
root=Path(__file__).resolve().parent;out=root/'output';out.mkdir(exist_ok=True);delivery=root/'delivery';delivery.mkdir(exist_ok=True)

def run(args,log):
 with (out/log).open('w')as f:subprocess.run(args,check=True,stdout=f,stderr=subprocess.STDOUT)

run(['ffmpeg','-hide_banner','-i',str(root/'audio/mix_pre_master.wav'),'-af','loudnorm=I=-14:TP=-1.5:LRA=8:print_format=json','-f','null','-'],'loudnorm-pass1.log')
s=(out/'loudnorm-pass1.log').read_text();d=json.loads(s[s.rfind('{'):s.rfind('}')+1]);af=f'loudnorm=I=-14:TP=-1.5:LRA=8:measured_I={d["input_i"]}:measured_TP={d["input_tp"]}:measured_LRA={d["input_lra"]}:measured_thresh={d["input_thresh"]}:offset={d["target_offset"]}:linear=true'
run(['ffmpeg','-y','-hide_banner','-i',str(root/'audio/mix_pre_master.wav'),'-af',af,'-ar','48000','-c:a','pcm_s24le',str(root/'audio/master.wav')],'loudnorm-pass2.log')
run(['ffmpeg','-y','-hide_banner','-ss','0.1','-i',str(out/'video_sem_audio.mp4'),'-ss','0.1','-i',str(root/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','17','-threads','4','-pix_fmt','yuv420p','-profile:v','high','-level:v','4.2','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-shortest',str(delivery/'ARQUIVO_0317_EP01_O_BOTAO_QUE_NAO_EXISTIA.mp4')],'final-export.log')

cues=json.loads((root/'captions.json').read_text());last=0;final=[]
for c in cues:
 start=math.ceil(max(c['start'],last)*30-1e-6)/30;end=math.ceil(c['end']*30-1e-6)/30;final.append({'text':c['text'],'start':round(max(0,start-.1),3),'end':round(end-.1,3)});last=c['end']
(delivery/'LEGENDAS_TIMING_FINAL.json').write_text(json.dumps(final,ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
(delivery/'LEGENDAS_EP01.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(x["start"])} --> {stamp(x["end"])}\n{x["text"]}'for i,x in enumerate(final))+'\n',encoding='utf-8')
print('EXPORT_COMPLETE')
