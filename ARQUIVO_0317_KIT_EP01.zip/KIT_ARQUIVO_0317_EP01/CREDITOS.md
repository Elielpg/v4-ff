# Créditos e origem

- História, direção, roteiro, cenas, composição, edição e música: produzidos para
  este projeto. Não foi usado um relato real ou copiado um vídeo de outro perfil.
- Cenário ilustrado, seis poses de personagens e foto do perfil: imagens criadas
  com IA especificamente para Arquivo 03:17. Não são fotografias de pessoas reais.
- Movimento 2.5D, câmera, montagem, tipografia, luzes, portas, botões e crachá:
  composição própria em Canvas/Skia, exportada por FFmpeg.
- Vozes brasileiras sintéticas: Kokoro v1.0, `pf_dora` e `pm_alex`, modelo público
  Apache-2.0: https://huggingface.co/hexgrad/Kokoro-82M . Não foi usado áudio de
  dublador nem clonagem da voz de uma pessoa enviada pelo usuário.
- Executor kokoro-onnx: MIT,
  https://github.com/thewh1teagle/kokoro-onnx . Modelos grandes não estão no ZIP.
- Alinhamento: faster-whisper/Whisper base, com revisão da grafia pelo roteiro
  original. Os tempos reconhecidos foram associados às palavras do roteiro;
  palavras não reconhecidas foram interpoladas dentro da própria fala.
- Fonte Anton: Vernon Adams, licença SIL OFL incluída.
  https://github.com/google/fonts/tree/main/ofl/anton
- @napi-rs/canvas: MIT, usado para renderizar o vídeo. Dependência fixada no projeto.
- FFmpeg/libx264/AAC: ferramentas de exportação; binários não são distribuídos.
- Trilha e efeitos: sintetizados originalmente para este vídeo, sem amostras de
  músicas comerciais. A música já está mixada abaixo da fala.

As licenças de ferramentas/modelos não devem ser confundidas com uma afirmação
sobre os direitos de qualquer conteúdo de terceiros. Este pacote contém as artes
criadas para o projeto, o vídeo e arquivos de produção, sem modelos neurais.
