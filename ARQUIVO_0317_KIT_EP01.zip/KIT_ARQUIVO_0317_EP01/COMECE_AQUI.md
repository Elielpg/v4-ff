# Arquivo 03:17 — primeiro vídeo pronto

O episódio **O botão que não existia** é uma história original de suspense urbano
animado. Formato vertical 1080×1920, 30 fps, cerca de 45 segundos, com narração
brasileira, trilha original, efeitos e legendas na imagem.

## Para usar agora

1. Abra `ARQUIVO_0317_EP01_O_BOTAO_QUE_NAO_EXISTIA.mp4`.
2. Use `FOTO_PERFIL_ARQUIVO0317.png` e a bio de `PERFIL_E_DIRECAO.md` para montar o
   perfil, se ainda não tiver criado a conta.
3. Envie o MP4 original ao TikTok, escolha uma capa e copie
   `LEGENDA_PARA_POSTAR.txt`.
4. Confira volume e legendas na tela de publicação. O SRT separado é opcional
   para reeditar, pois as legendas já aparecem no vídeo.

A capa separada está em `CAPA_ARQUIVO_0317_EP01.png`. O pacote também inclui o
roteiro, o planejamento e roteiros escritos dos próximos dois episódios.
**Somente o episódio 01 está renderizado neste kit.** Nenhum vídeo foi publicado
na conta do TikTok e nenhum resultado de alcance foi medido.

## Arquivos editáveis

`PROJETO_EDITAVEL/` contém as cenas em código, arte, textos, tempos de fala,
legendas, narração, trilha e efeitos. Leia `LEIA_EDITAVEL.md` nessa pasta para
reexportar. Modelos neurais e dependências grandes não estão no ZIP.

`VALIDACAO_EP01.json` registra os codecs, dimensões, duração, sincronismo,
loudness e as verificações efetivamente executadas. `MANIFEST.sha256` permite
conferir os arquivos do kit; o SHA-256 do ZIP é entregue separadamente.
