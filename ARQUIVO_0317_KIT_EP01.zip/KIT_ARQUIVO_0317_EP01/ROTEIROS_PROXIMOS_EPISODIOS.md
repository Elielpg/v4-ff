# Continuação planejada — roteiros escritos, ainda não renderizados

## EP. 02 — Ele precisava de um “sim”

**Gancho:** “O menino sabia meu nome. Mas ainda precisava que eu confirmasse.”

O elevador parou no oito. A mulher mais velha segurou meu braço.
“Ele pode copiar o seu rosto. Mas o seu nome... você precisa entregar.”
Perguntei por que o meu cabelo estava ficando branco.
“Cada viagem cobra tempo. Responder é diferente. Aí ele pode levar tudo.”
O menino apontou para o crachá com o meu nome.
“Nina. É você, não é?”
Eu olhei para a mulher. Ela tinha a mesma cicatriz que eu, na mão da chave.
Era mesmo a minha versão mais velha. E já conhecia aquela pergunta.
Atrás dela, o espelho mostrou trinta elevadores. Em cada um, uma Nina mais velha.
A mulher abriu a boca para responder.
Eu cobri o crachá com a mão e disse: “Espera. Por que o nome está em você?”
O menino parou de sorrir.

**Pergunta final:** “Quem precisava confirmar o nome de quem?”

**Direção:** close no crachá; cicatriz discreta; espelhos com versões estilizadas;
nenhuma morte gráfica. Manter a regra de não confirmar a identidade e o custo
progressivo de tempo. O visor é parte do mistério, não uma contagem de HP.

## EP. 03 — A pergunta voltou para ele

**Gancho:** “Para sair daquele elevador, eu fiz o menino cair na própria pergunta.”

O crachá estava no peito dele. E dizia Nina.
Eu apontei: “Nina é você?”
Ele olhou para baixo e respondeu, sem pensar: “Sim.”
O elevador ficou em silêncio.
No espelho, foi o cabelo dele que começou a embranquecer.
A mulher mais velha soltou a chave e sorriu.
As outras Ninas desapareceram dos reflexos, uma por uma.
O painel voltou a mostrar só os seis andares que sempre existiram.
Eu apertei o seis. Minha porta estava lá. O corredor não tinha poeira.
No bolso, encontrei o crachá. Estava em branco.
Ainda tenho uma mecha branca no cabelo.
E nunca mais confirmo meu nome antes de saber quem está perguntando.

**Fechamento:** “Você teria percebido a pista no crachá?”

**Direção:** a resposta do menino transfere a dívida; o efeito é envelhecimento
fantástico estilizado, sem ferimentos. O público já viu o nome no episódio 1,
portanto a resolução usa uma pista existente. A mecha permanece como consequência.
Depois dessa conclusão, iniciar outro caso original com novos personagens ou Nina.
