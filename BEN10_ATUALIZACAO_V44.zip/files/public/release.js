export const BUILD_ID='44.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 44.0.0';
