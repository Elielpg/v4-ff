import {mkdirSync,appendFileSync,existsSync,statSync,renameSync,readFileSync} from 'node:fs';
import path from 'node:path';
export class RuntimeLog {
 constructor(root,{maxBytes=1024*1024,copies=3}={}){this.root=root;this.maxBytes=maxBytes;this.copies=copies;mkdirSync(root,{recursive:true,mode:0o700});}
 event(type,details={}){try{const file=path.join(this.root,'supervisor.jsonl');if(existsSync(file)&&statSync(file).size>=this.maxBytes){for(let i=this.copies-1;i>0;i--)if(existsSync(file+'.'+i))renameSync(file+'.'+i,file+'.'+(i+1));renameSync(file,file+'.1');}appendFileSync(file,JSON.stringify({at:new Date().toISOString(),type,...details})+'\n',{mode:0o600});}catch{/* Logging cannot terminate the game. */}}
}
export function residentBytes(pid){try{const match=readFileSync('/proc/'+pid+'/status','utf8').match(/^VmRSS:\s+(\d+) kB/m);return match?Number(match[1])*1024:null;}catch{return null;}}
export function supervisorAlive(state,root,build,{now=Date.now(),alive=pid=>{process.kill(pid,0);return true;}}={}){if(!state||state.gameRoot!==root||state.build!==build||!Number.isInteger(state.pid)||state.pid<2||!Number.isFinite(state.updatedAt)||now-state.updatedAt>12000||state.updatedAt>now+5000)return false;try{return !!alive(state.pid);}catch{return false;}}
