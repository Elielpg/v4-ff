import {supervisorAlive} from './runtime-log.js';
import {readFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createConnection} from 'node:net';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {localSettings,loopbackRequest} from '../../server/local-ai.js';
import {BUILD_ID} from '../../public/release.js';
import {stopProject} from './project-processes.js';

const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\/$/,''),localRoot=path.resolve(process.env.BEN10_LOCAL_ROOT||path.join(os.homedir(),'.local/share/ben10-local-ai'));
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const portOpen=port=>new Promise(resolve=>{const socket=createConnection({host:'127.0.0.1',port});const done=value=>{socket.destroy();resolve(value);};socket.setTimeout(500,()=>done(false));socket.once('connect',()=>done(true));socket.once('error',()=>done(false));});
const readHealth=async(port,route)=>{try{const r=await loopbackRequest(port,route,{timeout:1800,limit:256*1024});return r.status===200?JSON.parse(r.data):null;}catch{return null;}};

async function main(){
 const args=process.argv.slice(2);if(args.some(arg=>!['--ensure','--local','--stop'].includes(arg)))throw Error('Use bash restart.sh ou bash local-ai.sh start.');
 let config={},manifest=null;try{config=JSON.parse(await readFile(path.join(root,'data/config.json'),'utf8'));}catch{}try{manifest=JSON.parse(await readFile(path.join(localRoot,'install.json'),'utf8'));}catch{}
 const local=args.includes('--local')||!!manifest&&config.conversationProvider==='local'&&config.voiceProvider==='local';
 if(local&&!manifest&&!args.includes('--stop'))throw Error('Instale primeiro: bash local-ai.sh install');
 const settings=localSettings(config.localAi||{}),port=Number(process.env.PORT||3000);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('PORT inválida.');
 const [game,text,voice]=await Promise.all([readHealth(port,'/api/health'),local?readHealth(settings.textPort,'/health'):null,local?readHealth(settings.voicePort,'/health'):null]);
 let runtime=null;try{runtime=JSON.parse(await readFile(path.join(localRoot,'runtime-status.json'),'utf8'));}catch{}const sameResources=(!config.runtimeProfile||runtime?.runtimeProfile===config.runtimeProfile)&&(!local||supervisorAlive(runtime,root,BUILD_ID));
 const sameGame=game?.runtime?.root===root;
 const sameVoice=voice?.build===BUILD_ID&&voice?.jobsSupported===true&&voice?.provider===({openvoice:'openvoice','qwen3-clone':'qwen3-clone'}[manifest?.voiceEngine]||'piper');
 if(args.includes('--ensure')&&sameResources&&sameGame&&game.build===BUILD_ID&&(!local||text?.status==='ok'&&voice?.ready===true&&sameVoice)){
  console.log('Jogo e serviços já estão na V'+BUILD_ID+'. Abra http://127.0.0.1:'+port+'/?v='+BUILD_ID+'. Mantenha a sessão original aberta.');return;
 }
 if(game&&!sameGame)throw Error('A porta do jogo pertence a outra instalação. Nenhum processo foi encerrado.');
 console.log('Conferindo e reiniciando somente os processos desta instalação…');
 if(sameGame&&game.build!==BUILD_ID)console.log('Servidor antigo detectado: '+game.build+'; arquivos instalados: '+BUILD_ID+'.');
 await stopProject(root,localRoot,{textPort:settings.textPort,onStop:kind=>console.log('Encerrando '+kind+' desta instalação…')});
 if(args.includes('--stop')){console.log('Processos desta instalação encerrados. Modelos e configuração preservados.');return;}
 const ports=local?[port,settings.textPort,settings.voicePort]:[port];let busy=[];
 for(let i=0;i<30;i++){busy=(await Promise.all(ports.map(async value=>await portOpen(value)?value:null))).filter(Boolean);if(!busy.length)break;await pause(150);}
 if(busy.length)throw Error('Porta(s) '+busy.join(', ')+' ainda ocupada(s) por serviço não confirmado. Pare a sessão original; nenhum processo externo foi encerrado.');
 const child=spawn(process.execPath,[...(existsSync(path.join(root,'.env'))?['--env-file=.env']:[]),...(local?['scripts/local-ai/run.js','start']:['server/index.js'])],{cwd:root,env:process.env,stdio:'inherit'});
 for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>child.kill(signal));
 child.once('error',error=>{console.error(error.message);process.exitCode=1;});child.once('exit',(code,signal)=>{console.log('Sessão encerrada: código='+code+' sinal='+(signal||'nenhum')+'. Diagnóstico: logs/inicializacao.log e logs/supervisor.jsonl na raiz da IA local.');process.exitCode=code??(signal==='SIGINT'?0:1);});
}
main().catch(error=>{console.error('Reinício interrompido: '+error.message);process.exitCode=1;});
