export class ArenaAudio {
  constructor(
    element,
    { onBeat = () => {}, onLevel = () => {}, onStatus = () => {} } = {},
  ) {
    this.element = element;
    Object.assign(this, { onBeat, onLevel, onStatus });
    this.offset = 120;
    this.intervals = [];
    this.lastHit = 0;
    this.objectURL = null;
    this.generation = 0;
    this.enabled = false;
  }
  async unlock() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.7;
      this.musicGain.connect(this.ctx.destination);
      this.effects = this.ctx.createGain();
      this.effects.gain.value = 0.2;
      this.effects.connect(this.ctx.destination);
    }
    await this.ctx.resume();
    this.enabled = this.ctx.state === "running";
    return this.enabled;
  }
  async load(file) {
    await this.unlock();
    if (this.objectURL) URL.revokeObjectURL(this.objectURL);
    this.element.pause();
    this.objectURL = URL.createObjectURL(file);
    this.element.src = this.objectURL;
    this.intervals = [];
    this.lastHit = 0;
    if (!this.source) {
      this.source = this.ctx.createMediaElementSource(this.element);
      this.source.connect(this.musicGain);
      this.band = this.ctx.createBiquadFilter();
      this.band.type = "bandpass";
      this.band.frequency.value = 110;
      this.band.Q.value = 0.6;
      this.source.connect(this.band);
      this.silent = this.ctx.createGain();
      this.silent.gain.value = 0;
      this.silent.connect(this.ctx.destination);
      try {
        await this.ctx.audioWorklet.addModule("/beat-meter.js");
        this.meter = new AudioWorkletNode(this.ctx, "pulso-meter");
        this.band.connect(this.meter);
        this.meter.connect(this.silent);
        this.meter.port.onmessage = (e) => {
          this.onLevel(Math.min(1, e.data.level * 4));
          if (e.data.hit && !this.element.paused) this.hit(e.data.at * 1000);
        };
        this.onStatus("Análise de batida ativa");
      } catch {
        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 1024;
        this.band.connect(this.analyser);
        this.analyser.connect(this.silent);
        this.data = new Float32Array(1024);
        this.avg = 0.002;
        this.poll = setInterval(() => {
          if (this.element.paused) return;
          this.analyser.getFloatTimeDomainData(this.data);
          const level = Math.sqrt(
            this.data.reduce((a, x) => a + x * x, 0) / this.data.length,
          );
          this.onLevel(Math.min(1, level * 4));
          const old = this.avg;
          this.avg = 0.97 * old + 0.03 * level;
          if (level > Math.max(0.01, old * 1.7))
            this.hit(this.ctx.currentTime * 1000);
        }, 20);
        this.onStatus("Análise de áudio básica ativa");
      }
    }
    return file.name;
  }
  hit(at) {
    if (at - this.lastHit < 270) return;
    const interval = this.lastHit ? at - this.lastHit : 545;
    this.lastHit = at;
    if (interval >= 300 && interval <= 1200) {
      this.intervals.push(interval);
      this.intervals = this.intervals.slice(-10);
    }
    const sorted = [...this.intervals].sort((a, b) => a - b),
      period = sorted[Math.floor(sorted.length / 2)] || 545,
      ticket = this.generation;
    setTimeout(() => {
      if (ticket !== this.generation || this.element.paused) return;
      this.onBeat({ interval: period, confidence: sorted.length >= 4 });
    }, this.offset);
  }
  tone(f, d = 0.1, type = "sine", volume = 0.25) {
    if (!this.enabled) return;
    const t = this.ctx.currentTime,
      o = this.ctx.createOscillator(),
      g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(35, f * 0.35), t + d);
    g.gain.setValueAtTime(volume, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g);
    g.connect(this.effects);
    o.start(t);
    o.stop(t + d + 0.02);
  }
  sfx(kind) {
    if (!this.enabled) return;
    if (kind === "welcome" || kind === "follow") {
      this.tone(660, 0.12, "sine", 0.25);
      setTimeout(() => this.tone(990, 0.14, "sine", 0.22), 90);
    } else if (kind === "victory") {
      for (let i = 0; i < 3; i++)
        setTimeout(
          () => this.tone([440, 554, 659][i], 0.25, "triangle", 0.3),
          i * 100,
        );
    } else if (kind === "special") {
      this.tone(180, 0.36, "sawtooth", 0.22);
      this.tone(65, 0.4, "sine", 0.55);
    } else if (kind === "block") {
      this.tone(640, 0.1, "triangle", 0.3);
    } else if (kind === "dodge") {
      this.tone(350, 0.08, "sine", 0.13);
    } else if (kind === "attack") {
      this.tone(115, 0.13, "triangle", 0.5);
    } else if (kind === "entrance") {
      this.tone(240, 0.26, "sawtooth", 0.2);
    }
  }
  pause() {
    this.generation++;
    this.element.pause();
  }
}
