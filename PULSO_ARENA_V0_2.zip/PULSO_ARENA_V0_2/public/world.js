import {
  orbitPose,
  fightFootwork,
  strikeEnvelope,
  smooth,
  clamp,
} from "./choreo.js";
const B = BABYLON,
  V = B.Vector3,
  C = B.Color3;
export class ArenaWorld {
  constructor(canvas) {
    this.engine = new B.Engine(canvas, true, { adaptToDeviceRatio: false });
    this.scene = new B.Scene(this.engine);
    this.scene.clearColor = new B.Color4(0.028, 0.038, 0.072, 1);
    this.scene.fogMode = B.Scene.FOGMODE_EXP2;
    this.scene.fogDensity = 0.025;
    this.scene.fogColor = new C(0.025, 0.035, 0.065);
    this.camera = new B.FreeCamera("câmera", new V(6.8, 5.4, 8.6), this.scene);
    this.camera.minZ = 0.08;
    this.camera.maxZ = 65;
    this.camera.fov = 0.8;
    this.camera.setTarget(new V(0, 1.0, 0));
    this.camera.inputs.clear();
    const h = new B.HemisphericLight("ambiente", new V(0, 1, 0), this.scene);
    h.intensity = 0.86;
    h.groundColor = new C(0.15, 0.17, 0.25);
    const key = new B.DirectionalLight(
      "principal",
      new V(-0.45, -1, -0.35),
      this.scene,
    );
    key.position = new V(4, 9, 7);
    key.intensity = 1.3;
    key.diffuse = new C(1, 0.89, 0.85);
    this.shadow = new B.ShadowGenerator(512, key);
    this.shadow.useBlurExponentialShadowMap = true;
    this.shadow.blurKernel = 8;
    this.shadow.bias = 0.003;
    this.actors = new Map();
    this.materials = new Map();
    this.fx = [];
    this.beatAt = -10;
    this.lastSeenAction = 0;
    this.time = 0;
    this.slots = [];
    this.latestAttack = null;
    this.latestVictory = null;
    this.welcomeFocus = null;
    this.state = null;
    this.cinematic = true;
    this.orbitSeconds = 18;
    this.orbitAngle = 0.63;
    this.orbitDistance = 0;
    this.bubbles = new Map();
    this.commentLayer = document.getElementById("bubbles-layer");
    this.reduceMotion = false;
    this.limit = 16;
    this.profile = "balanced";
    this.labels = 0;
    this.buildArena();
    this.buildParty();
    this.setQuality("balanced");
    window.addEventListener("resize", () => this.engine.resize());
    this.engine.runRenderLoop(() => this.render());
  }
  mat(n, hex, emit = 0, alpha = 1) {
    if (this.materials.has(n)) return this.materials.get(n);
    const m = new B.StandardMaterial(n, this.scene);
    m.diffuseColor = C.FromHexString(hex);
    m.specularColor = new C(0.08, 0.08, 0.08);
    m.emissiveColor = m.diffuseColor.scale(emit);
    m.alpha = alpha;
    m.maxSimultaneousLights = 4;
    this.materials.set(n, m);
    return m;
  }
  box(n, sz, m, parent, pos = [0, 0, 0]) {
    const q = B.MeshBuilder.CreateBox(
      n,
      { width: sz[0], height: sz[1], depth: sz[2] },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    return q;
  }
  ball(n, d, m, parent, pos = [0, 0, 0], scale = [1, 1, 1], segments = 12) {
    const q = B.MeshBuilder.CreateSphere(
      n,
      { diameter: d, segments },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    q.scaling.set(...scale);
    return q;
  }
  cylinder(n, d, h, m, parent, pos = [0, 0, 0], tess = 12) {
    const q = B.MeshBuilder.CreateCylinder(
      n,
      { diameter: d, height: h, tessellation: tess },
      this.scene,
    );
    q.material = m;
    q.parent = parent || null;
    q.position.set(...pos);
    return q;
  }
  node(n, p) {
    const x = new B.TransformNode(n, this.scene);
    x.parent = p || null;
    return x;
  }
  link(o, a, b) {
    const aa = V.FromArray(a),
      bb = V.FromArray(b),
      d = bb.subtract(aa),
      len = d.length(),
      dir = d.scale(1 / Math.max(len, 0.0001)),
      axis = V.Cross(B.Axis.Y, dir),
      dot = Math.max(-1, Math.min(1, V.Dot(B.Axis.Y, dir)));
    o.position.copyFrom(V.Lerp(aa, bb, 0.5));
    o.scaling.y = len;
    o.rotationQuaternion =
      axis.lengthSquared() < 1e-8
        ? B.Quaternion.RotationAxis(B.Axis.X, dot < 0 ? Math.PI : 0)
        : B.Quaternion.RotationAxis(axis.normalize(), Math.acos(dot));
  }
  buildArena() {
    const dark = this.mat("arena-escura", "#151d33"),
      floor = this.mat("chão", "#141e34"),
      steel = this.mat("metal", "#3e4b62"),
      cyan = this.mat("ciano", "#51d9ed", 0.75),
      coral = this.mat("coral", "#ff6479", 0.7),
      lime = this.mat("lima", "#bdf66d", 0.6);
    this.neon = [cyan, coral, lime];
    const ground = this.box("piso", [32, 0.2, 32], dark, null, [0, -0.25, 0]);
    ground.receiveShadows = true;
    const stage = this.box("ringue", [6.3, 0.5, 6.3], floor, null, [0, 0.1, 0]);
    stage.receiveShadows = true;
    const tex = new B.DynamicTexture(
        "lona",
        { width: 1024, height: 1024 },
        this.scene,
        false,
      ),
      c = tex.getContext();
    c.fillStyle = "#1d2b43";
    c.fillRect(0, 0, 1024, 1024);
    c.strokeStyle = "#33445f";
    c.lineWidth = 2;
    for (let x = 0; x < 1024; x += 64) {
      c.beginPath();
      c.moveTo(x, 0);
      c.lineTo(x, 1024);
      c.moveTo(0, x);
      c.lineTo(1024, x);
      c.stroke();
    }
    c.strokeStyle = "#4dc3d355";
    c.lineWidth = 12;
    c.beginPath();
    c.arc(512, 512, 360, 0, Math.PI * 2);
    c.stroke();
    c.fillStyle = "#79e0eabb";
    c.font = "900 84px sans-serif";
    c.textAlign = "center";
    c.fillText("PULSO", 512, 460);
    c.fillStyle = "#ff6a83bb";
    c.fillText("ARENA", 512, 560);
    c.strokeStyle = "#ffffff55";
    c.lineWidth = 9;
    c.beginPath();
    c.moveTo(330, 650);
    c.lineTo(440, 650);
    c.lineTo(479, 600);
    c.lineTo(520, 710);
    c.lineTo(570, 650);
    c.lineTo(700, 650);
    c.stroke();
    tex.update();
    const mm = new B.StandardMaterial("lona-mat", this.scene);
    mm.diffuseTexture = tex;
    mm.specularColor = C.Black();
    const canvas = B.MeshBuilder.CreateGround(
      "lona",
      { width: 5.95, height: 5.95 },
      this.scene,
    );
    canvas.position.y = 0.356;
    canvas.material = mm;
    canvas.receiveShadows = true;
    for (let x of [-3, 3])
      for (let z of [-3, 3]) {
        const p = this.cylinder(
          "poste",
          0.25,
          1.85,
          steel,
          null,
          [x, 1.15, z],
          12,
        );
        this.box("proteção", [0.36, 0.75, 0.36], x < 0 ? coral : cyan, null, [
          x,
          1.5,
          z,
        ]);
      }
    const faint = this.mat("corda-frente", "#ff758f", 0.25, 0.38);
    for (let y of [0.95, 1.3, 1.65])
      for (const side of [-1, 1]) {
        let q = this.cylinder(
          "corda",
          0.045,
          6.0,
          side > 0 ? faint : coral,
          null,
          [0, y, side * 3],
          8,
        );
        q.rotation.z = Math.PI / 2;
        q = this.cylinder("corda", 0.045, 6.0, cyan, null, [side * 3, y, 0], 8);
        q.rotation.x = Math.PI / 2;
      }
    for (let r = 0; r < 3; r++)
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2,
          rad = 5.2 + r * 1.15;
        const seat = this.box("arquibancada", [0.78, 0.23, 0.7], dark, null, [
          Math.sin(a) * rad,
          0.15 + r * 0.5,
          Math.cos(a) * rad,
        ]);
        seat.rotation.y = a;
      }
    for (let x of [-7, 7])
      for (let z of [-6, 6]) {
        this.box("coluna", [0.35, 7, 0.35], steel, null, [x, 3, z]);
        for (let y of [2.2, 3.7, 5.2])
          this.box(
            "painel-led",
            [0.38, 0.12, 0.8],
            x * z > 0 ? cyan : coral,
            null,
            [x, y, z],
          );
      }
    this.box("painel-fundo", [10, 3.8, 0.2], dark, null, [0, 3, -8.5]);
    this.equalizer = [];
    for (let i = 0; i < 15; i++)
      this.equalizer.push(
        this.box("equalizador", [0.32, 1, 0.08], i % 3 ? cyan : coral, null, [
          -4.2 + i * 0.6,
          2.5,
          -8.32,
        ]),
      );
    const tor = B.MeshBuilder.CreateTorus(
      "onda-impacto",
      { diameter: 1, thickness: 0.055, tessellation: 48 },
      this.scene,
    );
    tor.position.y = 0.39;
    tor.material = lime;
    tor.setEnabled(false);
    this.shock = tor;
    this.glow = new B.GlowLayer("brilho", this.scene, {
      mainTextureFixedSize: 256,
      blurKernelSize: 10,
    });
    this.glow.intensity = 0.26;
    this.glow.addIncludedOnlyMesh(tor);
    for (const q of this.equalizer) this.glow.addIncludedOnlyMesh(q);
  }
  buildParty() {
    this.beams = [];
    this.partyLights = [];
    this.danceTiles = [];
    const hues = ["#57dfed", "#ff6479", "#bdf66d", "#a48aff"];
    for (let i = 0; i < 4; i++) {
      const m = this.mat("feixe-" + i, hues[i], 1.2, 0.055);
      m.disableLighting = true;
      m.backFaceCulling = false;
      m.alphaMode = B.Engine.ALPHA_ADD;
      const q = B.MeshBuilder.CreateCylinder(
        "feixe",
        { diameterTop: 0.1, diameterBottom: 2.0, height: 1, tessellation: 14 },
        this.scene,
      );
      q.material = m;
      q.isPickable = false;
      this.beams.push(q);
      this.glow.addIncludedOnlyMesh(q);
    }
    for (let i = 0; i < 2; i++) {
      const l = new B.SpotLight(
        "luz-festa-" + i,
        new V(i ? -5 : 5, 5.5, 0),
        new V(0, -1, 0),
        1.35,
        1,
        this.scene,
      );
      l.diffuse = C.FromHexString(hues[i]);
      l.intensity = 0.45;
      l.range = 13;
      l.renderPriority = -1;
      this.partyLights.push(l);
    }
    for (let i = 0; i < 16; i++) {
      const angle = (i / 16) * Math.PI * 2,
        rad = 3.9;
      const m = this.mat("piso-led-" + i, hues[i % 4], 0.35);
      const tile = this.box("piso-led", [0.64, 0.025, 0.64], m, null, [
        Math.sin(angle) * rad,
        -0.13,
        Math.cos(angle) * rad,
      ]);
      tile.rotation.y = angle;
      this.danceTiles.push(tile);
      this.glow.addIncludedOnlyMesh(tile);
    }
    this.disco = this.ball(
      "globo",
      0.65,
      this.mat("globo-metal", "#b9dcf0", 0.25),
      null,
      [0, 6.6, 0],
      [1, 1, 1],
      10,
    );
    this.disco.convertToFlatShadedMesh();
    this.impactRings = [];
    for (let i = 0; i < 4; i++) {
      const q = B.MeshBuilder.CreateTorus(
        "impacto-ritmico",
        { diameter: 0.6, thickness: 0.045, tessellation: 24 },
        this.scene,
      );
      q.material = this.mat("impacto", "#fff1b0", 1);
      q.setEnabled(false);
      this.glow.addIncludedOnlyMesh(q);
      this.impactRings.push({ mesh: q, at: -10 });
    }
  }
  party(t, impulse) {
    const calm = this.reduceMotion,
      amp = calm ? 0.06 : 0.35;
    for (let i = 0; i < this.beams.length; i++) {
      const a = (i * Math.PI) / 2,
        from = [Math.sin(a) * 5.2, 5.8, Math.cos(a) * 5.2];
      const sweep = calm ? a : a + t * 0.28 + Math.sin(t * 0.4 + i) * 0.4;
      const to = [Math.sin(sweep) * 2.4, 0.03, Math.cos(sweep) * 2.4];
      this.link(this.beams[i], from, to);
      this.beams[i].material.alpha = 0.035 + impulse * (calm ? 0.005 : 0.035);
    }
    this.partyLights.forEach((l, i) => {
      l.intensity = 0.25 + impulse * amp;
      l.direction = new V(
        Math.sin(t * 0.4 + i) * 2,
        0,
        Math.cos(t * 0.4 + i) * 2,
      )
        .subtract(l.position)
        .normalize();
    });
    this.danceTiles.forEach(
      (q, i) =>
        (q.material.emissiveColor = q.material.diffuseColor.scale(
          0.25 +
            (0.25 + 0.5 * impulse) *
              (calm ? 0.15 : Math.max(0, Math.sin(i * 0.8 - t * 1.4))),
        )),
    );
    this.disco.rotation.y = calm ? 0 : t * 0.28;
    this.impactRings.forEach((f) => {
      const age = t - f.at;
      f.mesh.setEnabled(age >= 0 && age < 0.38);
      if (age < 0.38) f.mesh.scaling.setAll(0.6 + age * 3);
    });
  }
  renderBubbles() {
    if (!this.commentLayer) return;
    const now = this.state?.serverTime || Date.now(),
      width = innerWidth,
      height = innerHeight;
    const ids = new Set();
    for (const a of this.actors.values()) {
      if (!a.p.chat || a.p.chat.until < now) continue;
      ids.add(a.p.id);
      let el = this.bubbles.get(a.p.id);
      if (!el) {
        el = document.createElement("div");
        el.className = "speech-bubble";
        el.dataset.user = a.p.id;
        this.commentLayer.append(el);
        this.bubbles.set(a.p.id, el);
      }
      if (el.textContent !== a.p.chat.text) el.textContent = a.p.chat.text;
      const point = a.root.position.add(new V(0, a.small ? 1.65 : 2.56, 0));
      const v = V.Project(
        point,
        B.Matrix.Identity(),
        this.scene.getTransformMatrix(),
        this.camera.viewport.toGlobal(
          this.engine.getRenderWidth(),
          this.engine.getRenderHeight(),
        ),
      );
      const x = (v.x * width) / this.engine.getRenderWidth(),
        y = (v.y * height) / this.engine.getRenderHeight();
      el.style.visibility =
        v.z > 0 &&
        v.z < 1 &&
        x > 16 &&
        x < width - 16 &&
        y > 200 &&
        y < height - 210
          ? "visible"
          : "hidden";
      el.style.left = Math.max(90, Math.min(width - 90, x)) + "px";
      el.style.top = y + "px";
      if (ids.size >= 6) break;
    }
    for (const [id, el] of this.bubbles)
      if (!ids.has(id)) {
        el.remove();
        this.bubbles.delete(id);
      }
  }
  face(kind) {
    const key = "rosto-" + kind;
    if (this.materials.has(key)) return this.materials.get(key);
    const tx = new B.DynamicTexture(
        key,
        { width: 512, height: 256 },
        this.scene,
        false,
      ),
      c = tx.getContext();
    tx.hasAlpha = true;
    c.clearRect(0, 0, 512, 256);
    for (const side of [-1, 1]) {
      const x = 256 + side * 133;
      c.strokeStyle = "#161523";
      c.lineWidth = 13;
      c.lineCap = "round";
      if (kind === "ko") {
        c.beginPath();
        c.moveTo(x - 40, 76);
        c.lineTo(x + 40, 138);
        c.moveTo(x + 40, 76);
        c.lineTo(x - 40, 138);
        c.stroke();
        continue;
      }
      c.fillStyle = "#fff4df";
      c.beginPath();
      c.moveTo(x - 73, 116);
      c.quadraticCurveTo(x, kind === "happy" ? 28 : 45, x + 73, 103);
      c.quadraticCurveTo(x, kind === "happy" ? 173 : 144, x - 73, 116);
      c.fill();
      c.fillStyle = "#242239";
      c.beginPath();
      c.ellipse(x + side * 4, 104, 24, 37, 0, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = "#fff";
      c.beginPath();
      c.arc(x - 5, 89, 9, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = "#232135";
      c.lineWidth = 14;
      c.beginPath();
      c.moveTo(x - 65, 41 - side * 12);
      c.lineTo(x + 62, 45 + side * 12);
      c.stroke();
    }
    tx.update();
    const m = new B.StandardMaterial(key, this.scene);
    m.diffuseTexture = tx;
    m.emissiveTexture = tx;
    m.emissiveColor = new C(0.18, 0.18, 0.18);
    m.useAlphaFromDiffuseTexture = true;
    m.backFaceCulling = false;
    m.specularColor = C.Black();
    this.materials.set(key, m);
    return m;
  }
  mascot(p, small) {
    const root = this.node(p.id),
      head = this.node("cabeça", root),
      type = p.archetype || "fox";
    head.position.y = 1.46;
    const bodyColors = {
        fox: "#ee8548",
        hippo: "#a681d5",
        raccoon: "#6ca7ba",
        ram: "#d9b991",
      },
      body = this.mat(type, bodyColors[type]),
      cream = this.mat("creme", "#f1d9b7"),
      black = this.mat("preto", "#172138");
    const hue = (p.seed % 360) / 360,
      color = C.FromHSV(hue * 360, 0.65, 0.95),
      gloves = new B.StandardMaterial("luvas-" + p.id, this.scene);
    gloves.diffuseColor = color;
    gloves.specularColor = new C(0.12, 0.12, 0.12);
    const locals = [gloves];
    const torso = this.ball(
      "corpo",
      0.7,
      body,
      root,
      [0, 0.87, 0],
      [type === "hippo" ? 1.35 : 1, 1.2, 0.76],
      small ? 10 : 18,
    );
    this.ball(
      "colete",
      0.59,
      black,
      root,
      [0, 0.96, 0.07],
      [type === "hippo" ? 1.4 : 1.13, 1.25, 0.73],
      small ? 10 : 18,
    );
    this.ball(
      "crânio",
      type === "hippo" ? 0.93 : 0.79,
      body,
      head,
      [0, 0, 0],
      [type === "hippo" ? 1.08 : 1, 1, 0.9],
      small ? 12 : 24,
    );
    if (type === "fox") {
      for (const side of [-1, 1]) {
        const ear = B.MeshBuilder.CreateCylinder(
          "orelha",
          {
            diameterTop: 0,
            diameterBottom: 0.32,
            height: 0.53,
            tessellation: 3,
          },
          this.scene,
        );
        ear.parent = head;
        ear.position.set(side * 0.25, 0.42, -0.02);
        ear.rotation.z = side * -0.22;
        ear.material = body;
        const inside = this.ball(
          "dentro-orelha",
          0.2,
          cream,
          head,
          [side * 0.25, 0.43, 0.07],
          [0.7, 1.2, 0.3],
          8,
        );
      }
      const tail = B.MeshBuilder.CreateTube(
        "cauda",
        {
          path: [
            new V(0, 0.43, -0.2),
            new V(0.1, 0.43, -0.65),
            new V(0.25, 0.78, -0.94),
          ],
          radius: 0.14,
          tessellation: 10,
        },
        this.scene,
      );
      tail.parent = root;
      tail.material = body;
      this.ball(
        "ponta-cauda",
        0.29,
        cream,
        root,
        [0.25, 0.78, -0.94],
        [1, 1.1, 1],
        8,
      );
    }
    if (type === "raccoon") {
      for (const side of [-1, 1]) {
        this.ball(
          "orelha",
          0.24,
          body,
          head,
          [side * 0.28, 0.31, -0.01],
          [1, 1, 0.6],
          10,
        );
        this.ball(
          "máscara",
          0.28,
          black,
          head,
          [side * 0.18, 0.03, 0.27],
          [1.13, 0.8, 0.35],
          12,
        );
      }
      for (let i = 0; i < 5; i++)
        this.ball(
          "cauda-listrada",
          0.2,
          i % 2 ? black : body,
          root,
          [0.1 + i * 0.025, 0.4 + i * 0.055, -0.32 - i * 0.12],
          [1, 1, 1.25],
          8,
        );
    }
    if (type === "ram") {
      for (const side of [-1, 1]) {
        const horn = B.MeshBuilder.CreateTorus(
          "chifre",
          { diameter: 0.45, thickness: 0.12, tessellation: 20, arc: 0.88 },
          this.scene,
        );
        horn.parent = head;
        horn.position.set(side * 0.36, 0.15, -0.03);
        horn.rotation.z = Math.PI / 2;
        horn.material = cream;
      }
    }
    if (type === "hippo") {
      for (const side of [-1, 1])
        this.ball(
          "orelha-hipo",
          0.2,
          body,
          head,
          [side * 0.36, 0.32, -0.06],
          [1, 1, 0.6],
          10,
        );
    }
    const snout = this.ball(
      "focinho",
      type === "hippo" ? 0.64 : 0.43,
      type === "hippo" ? body : cream,
      head,
      [0, -0.12, 0.31],
      [1.1, 0.56, 0.75],
      small ? 10 : 18,
    );
    if (type === "hippo") {
      for (const side of [-1, 1])
        this.ball(
          "narina",
          0.065,
          black,
          head,
          [side * 0.16, -0.03, 0.55],
          [1, 0.5, 0.5],
          8,
        );
    } else
      this.ball(
        "nariz",
        0.13,
        black,
        head,
        [0, -0.035, 0.48],
        [1.2, 0.75, 0.7],
        12,
      );
    const eyes = B.MeshBuilder.CreatePlane(
      "expressão",
      { width: type === "hippo" ? 0.69 : 0.6, height: 0.29 },
      this.scene,
    );
    eyes.parent = head;
    eyes.position.set(0, 0.08, type === "hippo" ? 0.425 : 0.365);
    eyes.rotation.y = Math.PI;
    eyes.material = this.face("focus");
    const arms = [-1, 1].map((side) => ({
      side,
      upper: this.cylinder("braço", 0.17, 1, body, root),
      lower: this.cylinder("antebraço", 0.18, 1, body, root),
      glove: this.ball(
        "luva",
        0.3,
        gloves,
        root,
        [0, 0, 0],
        [1, 1.1, 1.15],
        small ? 10 : 18,
      ),
    }));
    const legs = [-1, 1].map((side) => ({
      side,
      upper: this.cylinder("perna", 0.2, 1, black, root),
      lower: this.cylinder("canela", 0.18, 1, body, root),
      foot: this.ball("pé", 0.25, black, root, [0, 0, 0], [0.8, 0.6, 1.35], 10),
    }));
    const labelTex = new B.DynamicTexture(
      "nome-" + p.id,
      { width: 512, height: 160 },
      this.scene,
      false,
    );
    labelTex.hasAlpha = true;
    const lm = new B.StandardMaterial("etiqueta-" + p.id, this.scene);
    lm.diffuseTexture = labelTex;
    lm.emissiveTexture = labelTex;
    lm.emissiveColor = C.White();
    lm.useAlphaFromDiffuseTexture = true;
    lm.backFaceCulling = false;
    const label = B.MeshBuilder.CreatePlane(
      "nome",
      { width: 1.4, height: 0.43 },
      this.scene,
    );
    label.material = lm;
    label.parent = root;
    label.position.y = 2.15;
    label.billboardMode = B.Mesh.BILLBOARDMODE_ALL;
    let lastLabel = "";
    const a = {
      p,
      type,
      seed: p.seed,
      root,
      head,
      torso,
      arms,
      legs,
      eyes,
      small,
      phase: 0,
      updateLabel: (q, role) => {
        const hp =
            this.state?.champion === q.id || this.state?.challenger === q.id
              ? q.hp
              : q.reserveHp,
          txt = q.name + ":" + hp + ":" + role;
        if (txt === lastLabel) return;
        lastLabel = txt;
        const c = labelTex.getContext();
        c.clearRect(0, 0, 512, 160);
        c.fillStyle = "#101a2be8";
        c.beginPath();
        c.roundRect(5, 8, 502, 141, 30);
        c.fill();
        c.strokeStyle = role === "champion" ? "#ffda7c" : "#6edbe5";
        c.lineWidth = 4;
        c.stroke();
        c.font = "bold 40px sans-serif";
        c.fillStyle = "#f5fbff";
        c.textAlign = "center";
        c.fillText("@" + q.id.slice(0, 17), 256, 66);
        c.font = "bold 31px sans-serif";
        c.fillStyle = "#bdf66d";
        c.fillText(
          "♥ " +
            Math.round(hp) +
            "   " +
            (role === "champion"
              ? "CAMPEÃO"
              : role === "challenger"
                ? "DESAFIANTE"
                : "PLATEIA"),
          256,
          116,
        );
        labelTex.update();
      },
      dispose: () => {
        for (const q of root.getChildMeshes())
          this.shadow.removeShadowCaster(q, false);
        root.dispose();
        labelTex.dispose();
        lm.dispose();
        locals.forEach((m) => m.dispose());
      },
    };
    if (!small)
      for (const q of root.getChildMeshes())
        if (!["nome", "expressão"].includes(q.name))
          this.shadow.addShadowCaster(q, false);
    return a;
  }
  setQuality(q) {
    this.profile = q;
    this.limit = q === "high" ? 24 : q === "low" ? 8 : 16;
    this.engine.setHardwareScalingLevel(
      q === "high" ? 1 : q === "low" ? 2 : 1.4,
    );
    this.scene.shadowsEnabled = q !== "low";
    this.glow.isEnabled = q !== "low";
    this.partyLights.forEach((l) => l.setEnabled(q !== "low"));
    this.engine.resize();
  }
  update(s) {
    this.state = s;
    if (
      ["entrance", "fighting"].includes(s.phase) &&
      s.champion &&
      s.challenger
    )
      this.slots = [s.champion, s.challenger];
    else if (s.phase === "waiting") this.slots = [s.champion].filter(Boolean);
    const ids = new Set([
      ...this.slots,
      ...s.players
        .filter((p) => !this.slots.includes(p.id))
        .sort(
          (a, b) =>
            (b.chat?.until || b.lastSeen) - (a.chat?.until || a.lastSeen),
        )
        .slice(0, this.limit)
        .map((p) => p.id),
    ]);
    for (const [id, a] of this.actors)
      if (!ids.has(id)) {
        a.dispose();
        this.actors.delete(id);
      }
    for (const id of ids) {
      const p =
        s.players.find((q) => q.id === id) ||
        s.ranking.find((q) => q.id === id);
      if (!p) continue;
      const small = !this.slots.includes(id);
      let a = this.actors.get(id);
      if (
        a &&
        (a.small !== small || a.type !== p.archetype || a.seed !== p.seed)
      ) {
        a.dispose();
        this.actors.delete(id);
        a = null;
      }
      if (!a) {
        a = this.mascot(p, small);
        this.actors.set(id, a);
      }
      a.p = p;
      a.updateLabel(
        p,
        id === s.champion
          ? "champion"
          : id === s.challenger
            ? "challenger"
            : "audience",
      );
    }
  }
  action(a) {
    if (a.id <= this.lastSeenAction) return;
    this.lastSeenAction = a.id;
    const t = performance.now() / 1000;
    if (a.kind === "beat") {
      this.beatAt = t;
      return;
    }
    if (a.kind === "entrance") {
      this.entranceAt = t;
      this.slots = [a.target, a.player];
    }
    if (a.kind === "welcome")
      this.welcomeFocus = { id: a.player, until: t + 2.2 };
    if (a.kind === "attack") {
      this.latestAttack = {
        ...a,
        time: t,
        duration: a.duration || (a.special ? 1.0 : 0.5),
      };
      this.shakeAt = t;
      const center =
        this.actors.get(a.target)?.root.position.add(new V(0, 1.1, 0)) ||
        new V(0, 1.4, 0);
      const ring = this.impactRings[a.id % this.impactRings.length];
      ring.at = t;
      ring.mesh.position.copyFrom(center);
      ring.mesh.rotation.set(Math.PI / 2, 0, 0);
      this.particles(
        a.defense === "dodge"
          ? 0
          : a.special
            ? 30
            : a.defense === "block"
              ? 7
              : 12,
        center,
        a.defense === "block" ? "#57dfed" : a.special ? "#bdf66d" : "#ffcc7c",
      );
      if (a.special) {
        this.shockAt = t;
        this.shock.setEnabled(true);
      }
    }
    if (a.kind === "victory") {
      this.latestVictory = { ...a, time: t };
      this.particles(40, new V(0, 2.7, 0), "#ffe09a");
    }
    if (a.kind === "likes") {
      const actor = this.actors.get(a.player);
      if (actor)
        this.particles(3, actor.root.position.add(new V(0, 1, 0)), "#bdf66d");
    }
  }
  particles(n, pos, hex) {
    const material = this.mat("partícula-" + hex, hex, 1);
    for (let i = 0; i < n && this.fx.length < 80; i++) {
      const q = this.ball(
        "faísca",
        0.05,
        material,
        null,
        pos.asArray(),
        [1, 1, 1],
        6,
      );
      this.fx.push({
        mesh: q,
        start: performance.now() / 1000,
        life: 0.4 + Math.random() * 0.5,
        velocity: new V(
          (Math.random() - 0.5) * 5,
          Math.random() * 4,
          (Math.random() - 0.5) * 5,
        ),
        origin: pos.clone(),
      });
    }
  }
  animate(a, t, beat, slot) {
    const root = a.root,
      active = slot >= 0,
      phase = this.state?.phase;
    let pos,
      yaw,
      step = 0;
    if (active) {
      const f = fightFootwork(t, slot, this.state?.rhythm?.bpm || 110);
      pos = new V(f.x, 0.4, f.z);
      yaw = f.yaw;
      step = f.step;
      if (phase === "entrance" && slot === 1) {
        const p = smooth((t - (this.entranceAt ?? t)) / 1.1);
        pos.x = 5 + (pos.x - 5) * p;
        pos.z = 2 * (1 - p) + pos.z * p;
        pos.y += Math.sin(p * Math.PI) * 0.55;
      }
    } else {
      const crowd = [...this.actors.keys()].filter(
          (id) => !this.slots.includes(id),
        ),
        i = Math.max(0, crowd.indexOf(a.p.id));
      const angle = (i / Math.max(8, crowd.length)) * Math.PI * 2,
        r = 4.8 + (i % 2) * 0.45;
      pos = new V(Math.sin(angle) * r, 0.25, Math.cos(angle) * r);
      yaw = angle + Math.PI;
    }
    root.scaling.setAll(active ? 1 : 0.62);
    const atk = this.latestAttack,
      p = atk ? (t - atk.time) / atk.duration : 2;
    const involved = active && p >= 0 && p <= 1,
      attacking = involved && atk.player === a.p.id,
      defending = involved && atk.target === a.p.id;
    const force = attacking ? strikeEnvelope(p) : 0,
      hit = defending ? strikeEnvelope(p) : 0;
    const blocked = defending && atk.defense === "block",
      dodged = defending && atk.defense === "dodge";
    const dancing =
      !active || (a.p.danceUntil || 0) > (this.state?.serverTime || 0);
    const groove = Math.sin(beat),
      bounce = (1 - Math.cos(beat)) * (dancing ? 0.065 : 0.025);
    const forward = new V(Math.sin(yaw), 0, Math.cos(yaw)),
      side = new V(Math.cos(yaw), 0, -Math.sin(yaw));
    if (attacking)
      pos.addInPlace(
        forward.scale(force * (atk.move === "special" ? 0.85 : 0.62)),
      );
    if (defending)
      pos.addInPlace(
        (dodged ? side : forward).scale(
          hit * (dodged ? 0.65 : blocked ? -0.08 : -0.24),
        ),
      );
    pos.addInPlace(side.scale(groove * (dancing ? 0.12 : 0.035)));
    const lost =
        this.latestVictory?.target === a.p.id &&
        t - this.latestVictory.time < 3.6,
      won =
        this.latestVictory?.player === a.p.id &&
        t - this.latestVictory.time < 3.6;
    root.position.copyFrom(pos);
    root.position.y += bounce + Math.abs(step);
    root.rotation.set(
      dodged ? -hit * 0.4 : 0,
      yaw +
        (attacking && atk.move === "spin"
          ? smooth(p) * Math.PI * 2
          : groove * (dancing ? 0.12 : 0.015)),
      lost ? Math.min(1, (t - this.latestVictory.time) * 2) * 1.25 : 0,
    );
    a.torso.rotation.z =
      groove * (dancing ? 0.12 : 0.035) + (attacking ? force * 0.12 : 0);
    a.head.rotation.z =
      defending && !blocked && !dodged
        ? hit * 0.2
        : groove * (dancing ? 0.1 : 0);
    a.eyes.material = this.face(
      lost ? "ko" : won || dancing ? "happy" : "focus",
    );
    const move = attacking ? atk.move : null,
      jab = ["jab", "cross", "uppercut", "special"].includes(move) ? force : 0,
      kick = ["kick", "entryKick", "spin"].includes(move) ? force : 0;
    const guard =
      blocked || (a.p.guardUntil || 0) > (this.state?.serverTime || 0);
    for (const arm of a.arms) {
      const s = arm.side,
        shoulder = [s * 0.33, 1.12, 0];
      let elbow = [s * 0.42, 0.98, 0.18],
        hand = [s * 0.28, 1.25, 0.36];
      if (dancing) {
        elbow = [s * 0.48, 1.03 + Math.sin(beat + s) * 0.2, 0.12];
        hand = [
          s * 0.54,
          1.31 + Math.sin(beat + s) * 0.24,
          0.23 + Math.cos(beat * 0.5 + s) * 0.12,
        ];
      }
      if (jab && s === (move === "cross" ? -1 : 1)) {
        elbow = [s * 0.28, 1.13, 0.36 + jab * 0.28];
        hand = [
          s * 0.13,
          move === "uppercut" ? 1.0 + jab * 0.5 : 1.21,
          0.4 + jab * 0.92,
        ];
      }
      if (guard) {
        elbow = [s * 0.31, 1.16, 0.3];
        hand = [s * 0.2, 1.49, 0.43];
      }
      if (dodged) {
        elbow = [s * 0.42, 0.99, 0.1];
        hand = [s * 0.34, 1.28, 0.2];
      }
      if (won) {
        elbow = [s * 0.45, 1.4, 0.1];
        hand = [s * 0.5, 1.8 + groove * 0.06, 0.12];
      }
      this.link(arm.upper, shoulder, elbow);
      this.link(arm.lower, elbow, hand);
      arm.glove.position.set(...hand);
      arm.glove.scaling.setAll(
        1 + (attacking && atk.special ? force * 0.24 : 0),
      );
    }
    for (const leg of a.legs) {
      const s = leg.side,
        hip = [s * 0.17, 0.7, 0],
        swing = Math.sin(beat + (s * Math.PI) / 2);
      let knee = [
          s * 0.2,
          0.4 + Math.max(0, swing) * 0.045,
          0.05 + swing * 0.06,
        ],
        foot = [
          s * 0.23,
          0.1 + Math.max(0, swing) * 0.07,
          0.1 + swing * (dancing ? 0.19 : 0.09),
        ];
      if (kick && s === 1) {
        knee = [0.18, 0.44 + kick * 0.5, 0.08 + kick * 0.5];
        foot = [0.18, 0.1 + kick * 0.95, 0.1 + kick * 1.22];
      }
      this.link(leg.upper, hip, knee);
      this.link(leg.lower, knee, foot);
      leg.foot.position.set(...foot);
    }
  }
  render() {
    const t = performance.now() / 1000,
      dt = Math.min(0.2, t - (this.time || t));
    this.time = t;
    const period = (this.state?.rhythm?.bpm || 110) / 60,
      beat = (t - this.beatAt) * Math.PI * 2 * period,
      impulse = Math.exp(-Math.max(0, t - this.beatAt) * 7);
    for (const a of this.actors.values())
      this.animate(a, t, beat, this.slots.indexOf(a.p.id));
    for (let i = 0; i < this.equalizer.length; i++) {
      const q = this.equalizer[i],
        height =
          0.3 + Math.abs(Math.sin(i * 1.78 + t * 2)) * 1.0 + impulse * 0.5;
      q.scaling.y = height;
      q.position.y = 2.2 + height * 0.5;
    }
    for (let i = 0; i < this.neon.length; i++)
      this.neon[i].emissiveColor = this.neon[i].diffuseColor.scale(
        0.45 + (this.reduceMotion ? 0.12 : 0.5) * impulse,
      );
    this.party(t, impulse);
    if (this.cinematic && !this.reduceMotion) {
      const delta = (dt * Math.PI * 2) / this.orbitSeconds;
      this.orbitAngle += delta;
      this.orbitDistance += delta;
    }
    const special = !!(
      this.latestAttack?.special && t - this.latestAttack.time < 1.05
    );
    const cp = orbitPose(this.orbitAngle, {
      special,
      reduceMotion: this.reduceMotion || !this.cinematic,
    });
    let target = new V(0, 1.05, 0),
      cam = new V(cp.x, cp.y, cp.z);
    if (
      this.cinematic &&
      !this.reduceMotion &&
      this.state?.phase === "waiting" &&
      this.welcomeFocus?.until > t
    ) {
      const p = this.actors.get(this.welcomeFocus.id)?.root.position;
      if (p) {
        target = p.add(new V(0, 0.7, 0));
        cam = p.add(new V(2.8, 2.0, 4.2));
      }
    }
    this.camera.position.copyFrom(
      V.Lerp(this.camera.position, cam, Math.min(1, dt * 5)),
    );
    this.camera.setTarget(target);
    this.camera.rotation.z = this.reduceMotion
      ? 0
      : Math.sin(beat) * impulse * 0.009;
    if (this.shakeAt && t - this.shakeAt < 0.3 && !this.reduceMotion) {
      const k = Math.exp(-(t - this.shakeAt) * 14);
      this.camera.position.x += Math.sin(t * 121) * 0.055 * k;
      this.camera.position.y += Math.cos(t * 103) * 0.025 * k;
    }
    this.camera.fov = 0.8 - (this.reduceMotion ? 0 : impulse * 0.012);
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const p = this.fx[i],
        age = t - p.start;
      if (age > p.life) {
        p.mesh.dispose();
        this.fx.splice(i, 1);
        continue;
      }
      p.mesh.position.copyFrom(
        p.origin.add(p.velocity.scale(age)).add(new V(0, -3 * age * age, 0)),
      );
      p.mesh.scaling.setAll(1 - age / p.life);
    }
    if (this.shockAt && t - this.shockAt < 0.8) {
      this.shock.scaling.setAll(1 + (t - this.shockAt) * 6);
    } else this.shock.setEnabled(false);
    this.scene.render();
    this.renderBubbles();
  }
  metrics() {
    return {
      fps: Math.round(this.engine.getFps()),
      meshes: this.scene.meshes.length,
      visible: this.actors.size,
      particles: this.fx.length,
      profile: this.profile,
      orbitDegrees: Math.round((this.orbitDistance * 180) / Math.PI),
      bubbles: this.bubbles.size,
    };
  }
}
