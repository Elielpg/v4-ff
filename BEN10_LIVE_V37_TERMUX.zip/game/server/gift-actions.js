import {FORM_IDS} from '../public/transformations.js';

// A final TikTok streak is one bundle: its full count earns points, and its
// configured animation runs once. EventHub already filters intermediate streaks.
export function giftVariant(name){
 let hash=0;for(const character of String(name||'').toLowerCase())hash=(hash*31+character.charCodeAt(0))>>>0;
 return hash%3;
}
export class GiftActionQueue {
 constructor({adventure,onChange=()=>{},onNotice=()=>{},now=Date.now,capacity=8}={}){
  if(!adventure)throw Error('A aventura é obrigatória');
  this.adventure=adventure;this.onChange=onChange;this.onNotice=onNotice;this.now=now;
  this.capacity=Math.max(1,Math.min(8,Math.floor(capacity)||8));this.items=[];this.active=null;this.completed=0;this.failed=0;this.sequence=0;this.lastTick=null;this.seen=new Set();
 }
 describe(item){if(!item)return null;return {id:item.id,user:item.user,gift:item.gift,count:item.count,form:item.form,power:item.power,powerLevel:item.powerLevel,movement:item.movement,direction:item.direction,powerVariant:item.powerVariant,mission:item.mission,missionKind:item.missionKind,stage:item.stage,status:item.status};}
 snapshot(){return {active:this.describe(this.active),waiting:this.items.map(item=>this.describe(item)),length:this.items.length+(this.active?1:0),capacity:this.capacity,completed:this.completed,failed:this.failed};}
 emit(){this.onChange(this.snapshot());}
 enqueue(event){
  if(!event||event.type!=='gift'||!(event.action||event.power||event.movement||event.mission))return false;
  const eventId=event.id?String(event.id):null;if(eventId&&this.seen.has(eventId))return false;
  if(event.action&&!FORM_IDS.includes(event.action))throw Error('Forma de presente inválida');
  if(event.movement&&!['walk','run','dash','fly','jump','spin','land','roll'].includes(event.movement))throw Error('Movimento de presente inválido');
  if(eventId){this.seen.add(eventId);if(this.seen.size>1024)this.seen.delete(this.seen.values().next().value);}
  if(this.items.length+(this.active?1:0)>=this.capacity){this.onNotice({text:'Pontos de '+String(event.user||'Visitante').slice(0,40)+' registrados. A fila de poderes está cheia; a animação deste presente não foi adicionada.'});return false;}
  this.items.push({id:eventId||'gift-'+(++this.sequence),user:String(event.user||'Visitante').slice(0,40),gift:String(event.gift||'Presente').slice(0,80),count:event.count||1,form:event.action||null,power:!!event.power,powerLevel:Math.max(1,Math.min(5,Math.floor(Number(event.powerLevel)||1))),movement:event.movement||null,direction:event.direction||null,powerVariant:event.powerVariant??null,mission:!!event.mission,missionKind:event.missionKind||null,stage:'queued',status:'Na fila',steps:[],elapsed:0});this.emit();return true;
 }
 stage(stage,status){if(this.active.stage===stage&&this.active.status===status)return;this.active.stage=stage;this.active.status=status;this.emit();}
 finish(error){const item=this.active;if(!item)return;if(error){this.failed++;this.onNotice({text:'O presente de '+item.user+' somou pontos, mas a ação não terminou: '+String(error.message||error).slice(0,120)});}else this.completed++;this.active=null;this.emit();}
 tick(now=this.now(),busy=false){
  const dt=this.lastTick===null?0:Math.max(0,Math.min(2000,now-this.lastTick));this.lastTick=now;
  if(!this.active&&this.items.length){this.active=this.items.shift();this.active.steps=[...(this.active.power?['power']:[]),...(this.active.movement?['movement']:[]),...(this.active.mission?['mission']:[])];this.active.stage='transform';this.active.status='Aguardando a vez de '+this.active.user;this.emit();}
  const item=this.active;if(!item)return;
  // Reserving the automatic lane prevents a quest from immediately undoing a
  // viewer's alien. Explicit queue transforms and movement still use Adventure.
  this.adventure.holdExternalAction?.(now+1600);
  if(busy){item.resumeStatus??=item.status;this.stage(item.stage,'Aguardando a fala ou o treino terminar');return;}
  if(item.resumeStatus){const status=item.resumeStatus;delete item.resumeStatus;this.stage(item.stage,status);}
  item.elapsed+=dt;if(item.elapsed>120000){this.finish(Error('tempo da ação esgotado'));return;}
  try{
   if(item.stage==='transform'){
    if(item.form&&this.adventure.form!==item.form){if(this.adventure.pending?.form!==item.form||this.adventure.pending?.source!=='gift')this.adventure.requestTransform(item.form,'gift');this.stage('transform','Transformando para '+item.user);return;}
    if(!item.steps.length){this.finish();return;}
    item.stage='next';
   }
   if(item.stage==='power'){
    if(now<item.until)return;item.stage='next';
   }
   if(item.stage==='movement'){
    const motion=this.adventure.motion;
    if(motion&&motion.id!==item.previousMotion&&motion.mode===item.movement){item.motionId=motion.id;if(motion.status==='active')return;item.stage='next';}
    else if(!this.adventure.pendingMovement&&now>=this.adventure.nextMovement){this.adventure.requestMovement(item.movement,now,item.direction);return;}
    else return;
   }
   if(item.stage==='mission')return; // Promise resolution owns this stage.
   if(item.stage!=='next')return;
   const step=item.steps[0];if(!step){this.finish();return;}
   if(step==='power'){
    if(this.adventure.watch?.phase==='recharging'){this.stage('next','Omnitrix vermelho · aguardando a recarga');return;}
    if(item.form&&this.adventure.form!==item.form){item.stage='transform';return;}
    if(now<this.adventure.nextPower){this.stage('next','Poder recarregando');return;}
     const power=this.adventure.usePower(now,false,item.powerLevel,item.powerVariant??giftVariant(item.gift));item.steps.shift();item.until=now+(power.duration||3000)+100;this.adventure.holdExternalAction?.(item.until);this.stage('power','Poder nível '+power.strength+' ativado por '+item.user);return;
   }
   if(step==='movement'){
    if(now<this.adventure.nextMovement){this.stage('next','Movimento recarregando');return;}
    item.previousMotion=this.adventure.motion?.id;this.adventure.requestMovement(item.movement,now,item.direction);item.steps.shift();this.stage('movement','Movimento ativado por '+item.user);return;
   }
   if(step==='mission'){
    item.steps.shift();this.stage('mission','Pedido de missão de '+item.user);
    Promise.resolve(this.adventure.startMission(now,item.missionKind?{kind:item.missionKind}:{})).then(()=>{if(this.active!==item)return;item.stage='next';this.emit();},error=>{if(this.active===item)this.finish(error);});
   }
  }catch(error){this.finish(error);}
 }
}
