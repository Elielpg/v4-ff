import {WatchVisuals} from './watch-visuals.js';
import {CampWorld} from './camp-world.js';
import {arenaFraming} from './arena-framing.js';
import {refinedAlienParts} from './refined-aliens.js';

import {GiftSpectacle} from './gift-spectacle.js';
import {LocomotionVisuals} from './locomotion-visuals.js';

import {CITIES_BY_ID,MOVEMENT_PRESETS,canMove,cityForDistance,WALK_SPEED} from './traversal.js';

import {animatePedestrian} from './pedestrian-motion.js';
import {npcParts} from './npc.js';
import {npcSpeaker} from './characters.js';
import {createMotionRig,MOTION_PROFILES} from './model-motion.js';
import {QuestVisuals} from './quest-visuals.js';

import {heroParts,heroJoints} from './hero.js';
export const forms=['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'];
export const names=['Ben · clássico','Chama','XLR8','Diamante','Fantasmático','Aquático','Alien X','Besta','Quatro Braços','Bola de Canhão','Cipó Selvagem'];
export const districts=['Praça Aurora','Jardim das Águas','Mercado Solar','Vila Cristal','Parque das Estrelas','Centro Cultural'];
export function waypoint(distance){return [0,0,Math.max(0,distance)];}
export function blocked(x,z){return Math.abs(x)>9||z<0;}
// Interpolate around the actor rather than across its body when switching views.
export function smoothCameraOrbit(previous,target,dt,minRadius=6){
 const alpha=1-Math.exp(-Math.max(0,Math.min(.12,dt))*4),start=previous||target;
 const difference=((target.angle-start.angle+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;
 return {angle:start.angle+difference*alpha,radius:Math.max(minRadius,start.radius+(target.radius-start.radius)*alpha),height:start.height+(target.height-start.height)*alpha};
}
const colors=[[.15,.9,.44],[1,.28,.05],[.1,.7,1],[.3,1,.9],[.8,.8,1],[.15,.4,.85],[.09,.1,.2],[.6,.3,.12],[.85,.12,.14],[.6,.6,.65],[.3,.65,.1]];
export function character(form=0){
 if(form===0)return heroParts();if([6,8,10].includes(form))return refinedAlienParts(form);
 const c=colors[form]||colors[0];const out=[];const box=(p,s,col=c,kind='box')=>out.push({p,s,c:col,kind});
 if(form===9){box([0,.9,0],[1.6,1.6,1.6],c,'sphere');box([0,.9,-.77],[1,.1,.1],[.1,.9,.3]);return out;}
 const height=form===7?1.1:form===8?1.9:1.5;const width=form===8?1.1:form===2?.38:.65;
 box([0,height,0],[width,.95,.45]);box([0,height+.75,0],[.56,.6,.52],form===0?[.91,.71,.5]:c,form===3?'crystal':'sphere');
 for(const side of [-1,1]){
  box([side*.23,.46,form===7?.25:0],[.23,.92,.28],form===0?[.16,.2,.25]:c);
  box([side*(width/2+.18),height-.1,0],[.22,.9,.25]);
  if(form===8)box([side*.85,height-.48,0],[.24,.7,.28]);
  if(form===7)box([side*.35,height+.8,-.12],[.25,.4,.25],c,'crystal');
  if(form===5)box([side*.46,height+.1,0],[.55,.6,.12],c,'crystal');
  if(form===10)for(let k=0;k<3;k++)box([side*(.5+k*.13),height+.2-k*.33,0],[.13,.6,.13]);
  box([side*.13,height+.8,-.26],[.1,.07,.05],[.1,1,.55]);
 }
 if(form===0)box([0,height+1.02,.05],[.59,.16,.48],[.2,.11,.06]);
 if(form===1)for(let k=0;k<5;k++)box([(k-2)*.14,height+1.15+(k%2)*.2,0],[.18,.6,.2],[1,.7,.05],'crystal');
 if(form===2)box([0,.7,.65],[.15,.15,1.3],c,'crystal');
 if(form===3)for(let k=0;k<5;k++)box([(k-2)*.18,height+.7,0],[.22,1,.25],c,'crystal');
 if(form===4)box([0,.45,0],[.55,.8,.45],c,'crystal');
 if(form===6)for(let k=0;k<12;k++)box([Math.sin(k*7)*.25,height-.35+(k%4)*.3,-.24],[.035,.035,.035],[1,1,1]);
 box([0,height,-.25],[.23,.23,.07],[.07,.1,.1]);box([0,height,-.3],[.13,.13,.03],[.4,1,.2]);return out;
}
export class World {
 constructor(canvas,onStatus){
  if(!globalThis.BABYLON)throw Error('Babylon.js local não instalado; execute npm run build');const B=BABYLON;this.canvas=canvas;this.onStatus=onStatus;this.time=0;this.distance=0;this.laneX=0;this.originZ=0;this.heading=Math.PI;this.form=0;this.talking=false;this.quality='balanced';this.visitors=[];this.imported=null;this.flash=0;this.materials=new Map();this.actors=[];this.visitorActors=[];
  this.engine=new B.Engine(canvas,true,{preserveDrawingBuffer:true,stencil:true});this.scene=new B.Scene(this.engine);this.scene.clearColor=new B.Color4(.65,.8,.85,1);this.scene.fogMode=B.Scene.FOGMODE_LINEAR;this.scene.fogStart=40;this.scene.fogEnd=115;this.scene.fogColor=new B.Color3(.65,.8,.85);this.scene.collisionsEnabled=true;
  this.camera=new B.FreeCamera('front',new B.Vector3(0,4,-12),this.scene);this.camera.minZ=.2;this.camera.maxZ=150;this.camera.fov=.95;this.scene.activeCamera=this.camera;
  this.sun=new B.DirectionalLight('sun',new B.Vector3(-.5,-1,.4),this.scene);this.sun.position=new B.Vector3(20,40,-20);this.sun.intensity=.85;const sky=new B.HemisphericLight('sky',new B.Vector3(0,1,0),this.scene);sky.intensity=.85;sky.groundColor=new B.Color3(.40,.45,.43);
  this.shadow=new B.ShadowGenerator(512,this.sun);this.shadow.useBlurExponentialShadowMap=true;this.shadow.blurKernel=8;
  this.endlessCity={chunks:new Map(),update(){},stats(){return {resident:0};}};
  this.avatar=this.makeActor(0,'Linel');
  this.labels=document.createElement('div');this.labels.id='world-labels';document.body.append(this.labels);for(const actor of this.actors){actor.label=document.createElement('span');actor.label.className='visitor-label npc-label';actor.label.textContent=actor.name;this.labels.append(actor.label);}this.questVisuals=new QuestVisuals(this);this.locomotionVisuals=new LocomotionVisuals(this);this.camp=new CampWorld(this);this.wristWatch=new WatchVisuals(this);this.arena={enabled:true,setEnabled(){}};this.renderPosition=new B.Vector3(0,0,0);this.giftSpectacle=new GiftSpectacle(this);this.mouthLevel=0;this.last=performance.now();this.engine.runRenderLoop(()=>this.frame());addEventListener('resize',()=>this.engine.resize());
 }
 cycleDay(){this.dayOffset=(this.dayOffset||0)+Math.PI/2;return this.dayOffset;}
 getPlayerPosition(){return this.renderPosition?.asArray()||[0,0,0];}
 toLocalPosition(position){const p=Array.isArray(position)?position:[position.x,position.y,position.z];return new BABYLON.Vector3(p[0],p[1],p[2]-this.originZ);}
 rebase(){const origin=Math.floor(this.distance/256)*256;if(origin===this.originZ)return;const delta=origin-this.originZ;this.originZ=origin;this.camera.position.z-=delta;this.avatar.root.position.z-=delta;if(this.imported)this.imported.root.position.z-=delta;this.questVisuals?.rebase(delta);this.locomotionVisuals?.rebase?.(delta);}
 material(c){const key=c.join(',');if(this.materials.has(key))return this.materials.get(key);const m=new BABYLON.StandardMaterial('mat-'+key,this.scene);m.diffuseColor=new BABYLON.Color3(...c);m.specularColor=new BABYLON.Color3(.08,.08,.08);if(c[1]>.9&&c[0]<.5)m.emissiveColor=new BABYLON.Color3(...c.map(v=>v*.2));this.materials.set(key,m);return m;}
 mesh(o,name){const B=BABYLON;let m;if(o.kind==='capsule')m=B.MeshBuilder.CreateCapsule(name,{height:2,radius:.5,tessellation:12,capSubdivisions:3},this.scene);else if(o.kind==='cylinder')m=B.MeshBuilder.CreateCylinder(name,{height:1,diameter:1,tessellation:16},this.scene);else if(o.kind==='sphere')m=B.MeshBuilder.CreateSphere(name,{diameter:1,segments:12},this.scene);else if(o.kind==='crystal')m=B.MeshBuilder.CreatePolyhedron(name,{type:1,size:.5},this.scene);else m=B.MeshBuilder.CreateBox(name,{size:1},this.scene);if(o.skinJoint)m.metadata={skinJoint:o.skinJoint};m.position.set(...o.p);m.scaling.set(...o.s);if(o.kind==='capsule')m.scaling.y*=.5;m.material=this.material(o.c);if(o.rotation)m.rotation.set(...o.rotation);return m;}
 makeActor(form,name){const B=BABYLON,root=new B.TransformNode(name,this.scene),parts=[],rig={};const isNPC=name!=='Linel'&&form<=0,detailed=form===0||isNPC;if(detailed)for(const [id,spec] of Object.entries(heroJoints)){const node=new B.TransformNode(name+'-'+id,this.scene),parent=spec.parent;node.parent=parent?rig[parent]:root;const origin=parent?heroJoints[parent].origin:[0,0,0];node.position.set(...spec.origin.map((v,i)=>v-origin[i]));rig[id]=node;}
 const geometry=isNPC?npcParts(npcSpeaker(name)):character(detailed?0:form);for(const [i,o] of geometry.entries()){const m=this.mesh(o,name+i);m.parent=detailed?rig[o.joint]:root;if(detailed)m.position.subtractInPlace(new B.Vector3(...heroJoints[o.joint].origin));m.isPickable=false;if(!isNPC&&Math.max(...o.s)>.25)this.shadow.addShadowCaster(m);parts.push({m,p:[...o.p],role:o.role,basePosition:m.position.clone(),baseScale:m.scaling.clone()});}let motionRig=null;if(name==='Linel'&&[6,8,10].includes(form)){motionRig=createMotionRig(parts.map(p=>p.m),root,forms[form],this.scene,form===8?{rotation:[0,0,0],height:3,shoulder:.74,hip:.39,width:.20,armAngle:-1.18,pairArmOffset:0,four:true}:{});for(const part of parts)this.shadow.removeShadowCaster(part.m);for(const mesh of motionRig.meshes)this.shadow.addShadowCaster(mesh);}if(isNPC){const merged=[],groups=new Map();for(const part of parts){if(part.role){merged.push(part);continue;}const key=part.m.parent.uniqueId+':'+part.m.material.uniqueId;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(part);}for(const group of groups.values()){const parent=group[0].m.parent,mesh=group.length>1?B.Mesh.MergeMeshes(group.map(p=>p.m),true,true):group[0].m;if(!mesh)continue;if(group.length>1){mesh.parent=parent;const inverse=B.Matrix.Invert(parent.computeWorldMatrix(true));mesh.bakeTransformIntoVertices(inverse);mesh.position.setAll(0);mesh.rotation.setAll(0);mesh.scaling.setAll(1);}mesh.isPickable=false;merged.push({m:mesh,p:[0,1,0],basePosition:mesh.position.clone(),baseScale:mesh.scaling.clone()});}parts.splice(0,parts.length,...merged);}return {root,parts,name,speaker:isNPC?npcSpeaker(name):null,rig:detailed?rig:null,motionRig};}

 transform(id){const n=forms.indexOf(id);if(n<0)return;const old=this.avatar.root;for(const part of this.avatar.parts)this.shadow.removeShadowCaster(part.m);if(this.avatar.motionRig){for(const mesh of this.avatar.motionRig.meshes)this.shadow.removeShadowCaster(mesh);this.avatar.motionRig.skeleton.dispose();}const a=this.makeActor(n,'Linel');a.root.position.copyFrom(old.position);a.root.rotation.copyFrom(old.rotation);a.root.scaling.setAll(.76);old.dispose();this.avatar=a;this.form=n;if(this.imported)this.imported.root.setEnabled(false);this.importTicket=(this.importTicket||0)+1;this.flash=1;this.transformMotion={at:performance.now(),duration:950};this.startTransformationEffect(n);const source=this.previewActive?this.previewModelUrl:this.modelSources?.[id];this.modelLoadPromise=source?this.importGLB(source).catch(error=>{document.getElementById('model-result').textContent=error.message;}):Promise.resolve();}
 startTransformationEffect(form){
  if(this.transformationEffect){this.transformationEffect.root.dispose();for(const m of this.transformationEffect.materials||[this.transformationEffect.material])m.dispose();}const B=BABYLON,root=new B.TransformNode('omnitrix-transformation',this.scene),material=new B.StandardMaterial('transformation-glow-'+Date.now(),this.scene);const red=form===0&&this.adventureState?.watch?.phase==='recharging';material.diffuseColor=new B.Color3(red?1:.3,red?.15:1,red?.08:.38);material.emissiveColor=material.diffuseColor.clone();material.disableLighting=true;material.alpha=.9;
  const rings=Array.from({length:3},(_,i)=>{const mesh=B.MeshBuilder.CreateTorus('transform-wave-'+i,{diameter:1,thickness:.07-i*.012,tessellation:36},this.scene);mesh.parent=root;mesh.material=material;mesh.isPickable=false;mesh.rotation.x=Math.PI/2;return mesh;});
  const sparks=Array.from({length:10},(_,i)=>{const mesh=B.MeshBuilder.CreatePolyhedron('transform-spark-'+i,{type:1,size:.12},this.scene);mesh.parent=root;mesh.material=material;mesh.isPickable=false;return mesh;});
   const accent=material.clone('omnitrix-dna-core');accent.emissiveColor=new B.Color3(red?1:.7,red?.35:1,red?.2:.65);const dna=Array.from({length:this.quality==='economy'?12:24},(_,i)=>{const m=B.MeshBuilder.CreateSphere('omnitrix-dna-'+i,{diameter:.055,segments:6},this.scene);m.parent=root;m.material=i%2?material:accent;m.isPickable=false;return m;});
   const rune=new B.Mesh('omnitrix-hourglass-seal',this.scene),vertices=new B.VertexData();vertices.positions=[-.5,.025,-.65,.5,.025,-.65,0,.025,0,-.5,.025,.65,.5,.025,.65,0,.025,0];vertices.indices=[0,1,2,3,5,4];vertices.normals=[0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,1,0];vertices.applyToMesh(rune);rune.parent=root;rune.material=accent;rune.isPickable=false;accent.backFaceCulling=false;
   this.transformationEffect={root,material,rings,sparks,dna,rune,accent,materials:[material,accent],at:performance.now(),duration:1200};
 }
 updateTransformation(dt){
  const B=BABYLON,now=performance.now(),motion=this.transformMotion;
  if(motion){const t=Math.min(1,Math.max(0,(now-motion.at)/motion.duration)),ease=1-Math.pow(1-t,3),bounce=Math.sin(Math.PI*t)*.055,scale=.76+.24*ease+bounce,actor=this.imported?.root.isEnabled()?this.imported.root:this.avatar.root;actor.scaling.setAll(scale);if(t>=1){actor.scaling.setAll(1);this.transformMotion=null;}}
  const fx=this.transformationEffect;if(!fx)return;fx.root.position.copyFrom(this.avatar.root.position);fx.root.position.y+=.08;
  const elapsed=(now-fx.at)/fx.duration,t=Math.min(1,Math.max(0,elapsed)),fade=1-t;
  fx.rings.forEach((ring,i)=>{const p=Math.min(1,Math.max(0,(t-i*.12)/(1-i*.12)));ring.position.y=.04+i*.035;ring.scaling.set(.5+p*(2.2+i*.45),.5+p*(2.2+i*.45),.5+p*(2.2+i*.45));ring.rotation.y=t*(i%2?1:-1)*1.6;});
  fx.sparks.forEach((spark,i)=>{const angle=i/10*Math.PI*2+t*2.2,radius=.35+t*(1.5+(i%3)*.3);spark.position.set(Math.cos(angle)*radius,.35+t*(1.5+(i%4)*.22),Math.sin(angle)*radius);spark.scaling.setAll(Math.max(.001,(.18+(i%3)*.04)*fade));spark.rotation.set(t*5+i,t*3,t*4-i);});
  fx.dna?.forEach((m,i)=>{const pair=Math.floor(i/2),height=pair/Math.max(1,fx.dna.length/2-1),angle=height*Math.PI*4+t*8+(i%2?Math.PI:0),radius=.55+Math.sin(t*Math.PI)*.35;m.position.set(Math.cos(angle)*radius,.12+height*2.8,Math.sin(angle)*radius);m.scaling.setAll(Math.max(.001,Math.sin(t*Math.PI)));});if(fx.rune){fx.rune.rotation.y=t*.5;fx.rune.scaling.setAll(1+t*.5);}fx.material.alpha=.9*fade;if(fx.accent)fx.accent.alpha=.8*fade;if(t>=1){fx.root.dispose();for(const m of fx.materials||[fx.material])m.dispose();this.transformationEffect=null;}
 }
 async loadFormModel(id){try{await this.importGLB(this.modelSources[id]);}catch(e){document.getElementById('model-result').textContent='Falha no modelo '+id+': '+e.message;}}
 async importGLB(url){const ticket=this.importTicket=(this.importTicket||0)+1,B=BABYLON;const result=await B.SceneLoader.ImportMeshAsync(null,'',url,this.scene);if(ticket!==this.importTicket){for(const m of result.meshes)if(!m.parent)m.dispose();for(const g of result.animationGroups)g.dispose();return null;}
 const wrapper=new B.TransformNode('GLB actor',this.scene),content=new B.TransformNode('source-content',this.scene);for(const m of result.meshes)if(!m.parent)m.parent=content;content.computeWorldMatrix(true);for(const m of result.meshes)m.computeWorldMatrix(true);
 const formId=forms[this.form],bundled=url.includes('/bundled-models/')&&MOTION_PROFILES[formId];let motionRig=null;
 if(bundled){motionRig=createMotionRig(result.meshes,wrapper,formId,this.scene);content.parent=wrapper;content.setEnabled(false);}else{const bounds=content.getHierarchyBoundingVectors(),height=bounds.max.y-bounds.min.y;if(!(height>0)){wrapper.dispose();content.dispose();throw Error('GLB sem geometria visível');}const scale=2.6/height;content.scaling.setAll(scale);content.position.set(-(bounds.min.x+bounds.max.x)/2*scale,-bounds.min.y*scale,-(bounds.min.z+bounds.max.z)/2*scale);content.parent=wrapper;}
 const visibleMeshes=motionRig?.meshes||result.meshes;for(const mesh of visibleMeshes){mesh.isPickable=false;this.shadow.addShadowCaster(mesh);}if(this.imported){for(const mesh of this.imported.root.getChildMeshes())this.shadow.removeShadowCaster(mesh);for(const g of this.imported.groups)g.dispose();this.imported.root.dispose(false,true);for(const skeleton of this.imported.skeletons)skeleton.dispose();}
 const mouthTargets=[];if(!motionRig)for(const mesh of result.meshes){const manager=mesh.morphTargetManager;if(manager)for(let i=0;i<manager.numTargets;i++){const t=manager.getTarget(i);if(/^(jawopen|mouthopen|visemeaa|visemea)$/i.test(t.name.replace(/[^a-z]/gi,'')))mouthTargets.push(t);}}
 this.imported={formId,root:wrapper,content,motionRig,skeletons:[...result.skeletons,...(motionRig?[motionRig.skeleton]:[])],proceduralRig:motionRig?Object.values(motionRig.bones):[],mouthTargets,groups:result.animationGroups,last:null,weights:new Map(),target:null,bounds:motionRig?.bounds||{height:2.6,width:1.5,depth:1}};
 for(const g of result.animationGroups){g.stop();this.imported.weights.set(g,0);}this.avatar.root.setEnabled(false);this.animateImported();return {meshes:visibleMeshes.length,skeletons:this.imported.skeletons.length,animations:result.animationGroups.map(g=>g.name),mouthTargets:mouthTargets.map(t=>t.name),proceduralWalk:!!motionRig};}
  animateImportedRig(dt=.016){this.imported?.motionRig?.update(dt,this.heroAnimationState(),{distance:this.distance,variant:this.powerAction?.variant||0});}

 animateImported(dt=.016){if(!this.imported)return;const imported=this.imported,desired=this.heroAnimationState();if(imported.last!==desired){imported.last=desired;const match=imported.groups.find(g=>g.name.toLowerCase().includes(desired))||(['run','dash'].includes(desired)?imported.groups.find(g=>g.name.toLowerCase().includes('walk')):null)||imported.groups.find(g=>g.name.toLowerCase().includes('idle'));imported.target=match;if(match&&!match.isPlaying){match.start(true,1);match.setWeightForAllAnimatables(0);}}
  for(const g of imported.groups){const target=g===imported.target?1:0,old=imported.weights.get(g)||0,weight=old+(target-old)*Math.min(1,dt*8);imported.weights.set(g,weight);if(g.isPlaying)g.setWeightForAllAnimatables(weight);if(!target&&weight<.005&&g.isPlaying)g.stop();}
 }

 setAdventure(state){this.setArenaState(state);}
 setArenaState(state){this.adventureState=state;document.documentElement.style.setProperty('--flash-color',state.watch.phase==='recharging'?'#ff655c':'#baff75');if(!this.lastArenaState){this.renderPosition.set(...state.position);this.heading=state.heading||0;this.lastArenaState=true;}if(forms[this.form]!==state.form){this.questVisuals.disposeEffect();this.powerUntil=0;this.powerAction=null;this.transform(state.form);}if(!state.power&&this.questVisuals.effect)this.questVisuals.disposeEffect();this.questVisuals.sync({...state,quest:null});}

 async previewAbility(form,{duration=6500}={}){
  if(!forms.includes(form))throw Error('Forma inválida');if(this.previewActive)this.endPreview(false);
  this.previewActive=true;this.previewUntil=Infinity;this.previewAnchor={time:this.time,distance:this.distance,laneX:this.laneX,heading:this.heading};this.talking=false;this.localMovement=null;this.questVisuals.disposeEffect();
  try{this.previewManifest??=await fetch('/bundled-models/manifest.json').then(response=>response.json());this.previewModelUrl=this.previewManifest.find(entry=>entry.form===form)?.url||null;this.transform(form);await this.modelLoadPromise;this.previewUntil=Date.now()+duration;this.previewStartedAt=Date.now();this.flash=.35;
   const position=this.getPlayerPosition(),forward=new BABYLON.Vector3(-Math.sin(this.previewAnchor.heading),0,-Math.cos(this.previewAnchor.heading)),target=this.toLocalPosition(position).add(forward.scale(form==='fourarms'?1:form==='rock'?2.6:4));
   this.questVisuals.spawnPower({id:Date.now(),form,position,at:Date.now()},null,target);return {form,duration};
  }catch(error){this.endPreview();throw error;}
 }
 endPreview(restore=true){this.cameraOrbit=null;if(this.previewActive&&this.previewAnchor){this.distance=this.previewAnchor.distance;this.laneX=this.previewAnchor.laneX;this.time=this.previewAnchor.time;this.rebase();this.avatar.root.position.copyFrom(this.toLocalPosition(this.getPlayerPosition()));}this.previewActive=false;this.previewUntil=0;this.previewModelUrl=null;this.localMovement=null;this.questVisuals.disposeEffect();this.powerUntil=0;this.powerAction=null;if(restore&&this.adventureState?.form)this.transform(this.adventureState.form);return true;}
 triggerLocomotion(mode,duration=1200,options={}){if(this.adventureState?.arena)return false;if(mode==='dash'&&this.form!==2||mode==='fly'&&![1,4,6].includes(this.form))return false;this.localMovement={mode,at:Date.now(),duration,startZ:this.distance,recoil:options.recoil===true};return true;}
 heroAnimationState(){const s=this.adventureState;if(s?.watch.phase==='selecting')return 'select';if(s?.watch.phase==='transforming')return 'transform';if(Date.now()<this.powerUntil)return this.powerAction?.phase||'power';if(this.talking&&!['walk','run','dash','fly','roll'].includes(this.locomotionState))return 'talk';if(s?.gesture&&Date.now()<s.gesture.until)return s.gesture.kind;if(this.locomotionState==='jump')return 'idle';if(this.locomotionState==='spin')return 'spin';if(['walk','run','dash','fly','roll'].includes(this.locomotionState))return this.locomotionState==='roll'?'dash':this.locomotionState;return 'idle';}

 advanceLocomotion(dt,quest){
  const now=Date.now(),motion=this.previewActive?null:this.adventureState?.motion,local=this.localMovement;let mode='walk',height=0;this.distance??=0;this.laneX??=0;const before=this.distance;
  if(this.previewActive&&!local){this.distance=this.previewAnchor.distance;this.laneX=this.previewAnchor.laneX;this.locomotionState='idle';this.altitude=0;return {mode:'idle',height:0};}
  if(motion?.status==='complete'&&!motion.cancelled&&this.lastActiveMotionId===motion.id&&this.completedMotionId!==motion.id){this.distance=motion.toZ;this.laneX=motion.toX||0;this.completedMotionId=motion.id;}
  if(motion?.status==='active'&&forms[this.form]===motion.form){mode=motion.mode;this.lastActiveMotionId=motion.id;if(!this.talking&&!motion.paused){const t=Math.max(0,Math.min(1,(now-motion.at)/motion.duration));this.distance=motion.fromZ+(motion.toZ-motion.fromZ)*t;this.laneX=(motion.fromX||0)+((motion.toX||0)-(motion.fromX||0))*t;height=mode==='fly'?Math.sin(t*Math.PI)*2.8:0;}else height=this.altitude||0;}
  else if(local&&now-local.at<local.duration&&!this.talking){mode=local.mode;const speed=mode==='dash'?19:mode==='roll'?8:6;if(local.recoil)this.distance=local.startZ+Math.sin(Math.min(1,(now-local.at)/local.duration)*Math.PI)*2.4;else this.distance+=dt*speed;height=mode==='fly'?Math.sin((now-local.at)/local.duration*Math.PI)*2.5:0;}
  else if(local?.recoil){this.distance=local.startZ;this.localMovement=null;}
  else if(this.previewActive||this.talking||now<this.powerUntil){mode='idle';}
  else if(quest?.status==='active'){
   if(forms[this.form]!==quest.form){mode='idle';}
   else{
    const remaining=quest.position[2]-this.distance,travel=quest.stage==='travel',movingGoal=['escort','delivery','race'].includes(quest.goal?.phase),targeting=travel||movingGoal||Math.abs(remaining)>1.8;
    if(targeting&&Math.abs(remaining)>.18){mode=travel?quest.travel.mode:quest.kind==='race'?'dash':'run';if(!canMove(forms[this.form],mode))mode='run';const speed=(MOVEMENT_PRESETS[mode]?.speed||5.6),step=Math.sign(remaining)*Math.min(speed*dt,Math.abs(remaining));this.distance+=step;this.laneX+=(quest.position[0]-this.laneX)*Math.min(1,dt*3);height=mode==='fly'&&Math.abs(remaining)>2?1.8+Math.sin(now/450)*.18:0;}else mode='idle';
   }
  }else if(!this.helping&&!this.arena?.enabled){this.distance+=dt*WALK_SPEED;}else mode='idle';
  this.distance=Math.max(0,this.distance);this.time=this.distance/WALK_SPEED;if(this.distance!==before)this.heading=this.distance>=before?Math.PI:0;this.locomotionState=mode;this.altitude=(this.altitude||0)+(height-(this.altitude||0))*Math.min(1,dt*6);return {mode,height:this.altitude};
 }
 setSpeaker(id,active){this.activeSpeaker=active?id:null;this.talking=active&&forms.includes(id);this.speakingActor=active&&!forms.includes(id)?(this.questVisuals.helper?.speaker===id?this.questVisuals.helper:this.actors.find(a=>a.speaker===id)):null;}
 setMouthOpen(level){this.mouthLevel=Math.min(1,Math.max(0,level||0));}
 updateMouth(){const level=this.mouthLevel;for(const actor of [...this.actors,this.questVisuals.helper].filter(Boolean))for(const part of actor.parts)if(part.role==='mouth')part.m.scaling.y=part.baseScale.y+(actor===this.speakingActor?level*.1:0);const heroLevel=this.speakingActor?0:level;for(const part of this.avatar.parts){if(part.role==='mouth')part.m.scaling.y=part.baseScale.y+heroLevel*.10;else if(part.role==='jaw')part.m.position.y=part.basePosition.y-heroLevel*.035;else if(part.role==='teeth')part.m.position.y=part.basePosition.y+heroLevel*.012;}if(this.imported?.root.isEnabled())for(const target of this.imported.mouthTargets||[])target.influence=heroLevel;}
  animateActor(actor,dt,phase,talking=false){if(actor.motionRig){const hero=actor===this.avatar;actor.motionRig.update(dt,hero?this.heroAnimationState():talking?'talk':'walk',{distance:hero?this.distance:undefined,variant:hero?(this.powerAction?.variant||0):0});return;}if(actor.rig){const hero=actor===this.avatar,state=hero?this.heroAnimationState():(actor===this.speakingActor?'talk':actor.animationState||(talking?'idle':'walk'));animatePedestrian(actor,dt,{state:['dash','roll'].includes(state)?'run':state,speed:hero?(this.locomotionState==='run'?2:1):(actor.walkSpeed??1),phase:hero?this.distance*4:phase});actor.root.position.y=actor.gaitOffset||0;return;}const hero=actor===this.avatar,state=hero?this.heroAnimationState():actor.animationState;for(const {m,p} of actor.parts){if(p[1]<.8&&p[0]!==0)m.rotation.x=talking?0:Math.sin(phase+(p[0]<0?Math.PI:0))*.32;else if(p[1]>1&&Math.abs(p[0])>.35)m.rotation.x=talking?Math.sin(phase*1.8)*.16:Math.sin(phase+(p[0]<0?0:Math.PI))*.2;if(p[1]>1.35&&Math.abs(p[0])>.28){if(state==='wave'&&p[0]>0)m.rotation.z=.75+Math.sin(performance.now()/90)*.20;else if(state==='cheer')m.rotation.z=(p[0]<0?-1:1)*.65;else m.rotation.z+=(0-m.rotation.z)*Math.min(1,Math.max(0,dt)*12);}}if(hero&&state==='spin'){const g=this.adventureState?.gesture,p=Math.min(1,Math.max(0,(Date.now()-(g?.at||Date.now()))/1800));actor.root.rotation.y=this.heading+p*Math.PI*2;}actor.root.position.y=talking?0:state==='jump'?Math.max(0,Math.sin(performance.now()/110))*.65:Math.abs(Math.sin(phase))*.025;}
 projectLabel(actor,visible){if(!actor.label)return;const B=BABYLON,s=B.Vector3.Project(actor.root.position.add(new B.Vector3(0,2.6*actor.root.scaling.y,0)),B.Matrix.Identity(),this.scene.getTransformMatrix(),this.camera.viewport.toGlobal(this.engine.getRenderWidth(),this.engine.getRenderHeight()));actor.label.hidden=!visible||s.z<0||s.z>1||B.Vector3.Distance(actor.root.position,this.camera.position)>18;actor.label.style.left=s.x/this.engine.getRenderWidth()*100+'%';actor.label.style.top=s.y/this.engine.getRenderHeight()*100+'%';}
 frame(){const B=BABYLON,now=performance.now(),dt=Math.min(.12,(now-this.last)/1000);this.last=now;const s=this.adventureState;
  if(s){const desired=new B.Vector3(...s.position),step=1-Math.exp(-dt*14);this.renderPosition=B.Vector3.Lerp(this.renderPosition,desired,step);const delta=this.renderPosition.subtract(this.previousPosition||this.renderPosition);this.distance+=Math.hypot(delta.x,delta.z);this.previousPosition=this.renderPosition.clone();this.heading+=(Math.atan2(Math.sin(s.heading-this.heading),Math.cos(s.heading-this.heading)))*(1-Math.exp(-dt*12));this.locomotionState=s.motion?.status==='active'?s.motion.mode:'idle';this.altitude=this.renderPosition.y;}
  const p=this.renderPosition;this.avatar.root.position.set(p.x,0,p.z);this.avatar.root.rotation.y=this.heading;this.updateTransformation(dt);this.questVisuals.update(dt);const effect=this.questVisuals.effect;if(effect?.phase==='impact'&&this.lastAudibleHit!==effect){this.lastAudibleHit=effect;this.onPowerImpact?.(effect.form);}this.animateActor(this.avatar,dt,this.distance*4,this.talking);this.avatar.root.position.y+=p.y;
  if(this.imported?.root.isEnabled()){this.imported.root.position.copyFrom(p);this.imported.root.rotation.y=this.heading;this.animateImported(dt);this.animateImportedRig(dt);}
  this.locomotionVisuals.update(dt,this.locomotionState,p,this.heading);this.giftSpectacle.update(dt);this.camp.update(dt);
  const shape=this.imported?.root.isEnabled()?this.imported.bounds:(this.avatar.motionRig?.bounds||{height:2.6,width:1.6}),fit=arenaFraming({...shape,aspect:this.canvas.clientWidth/Math.max(1,this.canvas.clientHeight)});this.arenaFraming=fit;const radius=fit.radius*(this.cameraZoom||1),target=new B.Vector3(p.x,fit.targetHeight+p.y*.75,p.z),wanted=new B.Vector3(p.x+radius*.12,fit.cameraHeight+p.y*.8,p.z-radius);this.camera.position=B.Vector3.Lerp(this.camera.position,wanted,1-Math.exp(-dt*5));this.camera.setTarget(target);this.camera.fov+=(fit.fov-this.camera.fov)*(1-Math.exp(-dt*5));this.cameraMode='free-arena';
  if(effect?.phase==='impact'&&!this.reducedMotion){this.camera.position.x+=Math.sin(now*.08)*.018*(effect.strength||1);}
  if(this.quality!==this.appliedQuality){this.appliedQuality=this.quality;this.engine.setHardwareScalingLevel(this.quality==='economy'?1.7:this.quality==='high'?1:1.25);this.shadow.getShadowMap().refreshRate=this.quality==='economy'?5:2;this.engine.resize();}
  if(this.flash>0){this.flash-=dt*2;document.documentElement.style.setProperty('--flash',Math.max(0,this.flash)*.4);}this.wristWatch.update(s);this.updateMouth();this.scene.render();if(Math.floor(now/500)!==this.reported){this.reported=Math.floor(now/500);this.onStatus?.({fps:Math.round(this.engine.getFps()),pos:[p.x,p.y,p.z],mode:this.locomotionState});}
 }
}
