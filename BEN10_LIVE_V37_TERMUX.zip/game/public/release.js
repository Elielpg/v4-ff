export const BUILD_ID='37.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 37.0.0';
