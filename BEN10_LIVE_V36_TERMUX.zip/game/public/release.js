export const BUILD_ID='36.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 36.0.0';
