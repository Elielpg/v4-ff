import {mkdtemp,symlink,rm,writeFile,readFile,mkdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {stageArchive} from './phone-update.js';
import {BUILD_ID} from '../public/release.js';
const archive=path.resolve(process.argv[2]||'../BEN10_LIVE_V36_TERMUX.zip');
const temporary=await mkdtemp(path.join(os.tmpdir(),'ben31-archive-smoke-')),stage=path.join(temporary,'game');
let child;
try{
 const metadata=await stageArchive(archive,stage);assert.equal(metadata.version,BUILD_ID);
 await symlink(path.resolve('node_modules'),path.join(stage,'node_modules'),'dir');
 const port=41000+Math.floor(Math.random()*10000),base='http://127.0.0.1:'+port;
 child=spawn(process.execPath,['server/index.js'],{cwd:stage,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});
 let stderr='';child.stderr.on('data',chunk=>stderr+=chunk);
 await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw Error('Servidor do ZIP não iniciou: '+stderr);})]);
 const health=await fetch(base+'/api/health').then(r=>r.json());assert.equal(health.ok,true);assert.equal(health.build,BUILD_ID);assert.equal(health.runtime.root,stage);assert.equal(health.identity,'Ben Tennyson');assert.equal(health.giftActions.length,0);
 const html=await fetch(base+'/').then(r=>r.text());assert(html.includes('arena-app.js'));assert(html.includes('watch-charge'));assert(!html.includes('mission-hud'));const state=await fetch(base+'/api/adventure').then(r=>r.json());assert.equal(state.arena,true);assert.equal(state.quest,null);assert.equal(state.watch.phase,'ready');
  for(const asset of ['arena-app.js','arena.css','camp-world.js','arena-commands.js','arena-terrain.js','watch-visuals.js','arena-framing.js','ben-dialogue.js','gift-slides.js','refined-aliens.js','gift-spectacle.js','show-catalog.js','cinematic-audio.js','world.js','audience.js','live-engagement.js','vendor/babylon.js'])assert.equal((await fetch(base+'/'+asset)).status,200,asset);
 assert((await fetch(base+'/interaction-power.svg')).headers.get('content-type').includes('image/svg+xml'));
 const manifest=JSON.parse(await readFile(path.join(stage,'public/bundled-models/manifest.json'),'utf8'));assert.equal(manifest.length,9);
 const report={build:BUILD_ID,archive:path.basename(archive),files:metadata.files.length,health:true,html:true,localAssets:true,bundledModels:manifest.length,credentialsIncluded:false,note:'Extrai o ZIP real com o validador do atualizador e inicia seu servidor; reutiliza as dependências locais do mesmo lockfile.'};
  await mkdir('reports/v36',{recursive:true});await writeFile('reports/v36/archive-smoke.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{if(child?.exitCode===null){child.kill('SIGTERM');await once(child,'exit');}await rm(temporary,{recursive:true,force:true});}
