import {copyFile} from 'node:fs/promises';
await mkdir('public/vendor',{recursive:true});
for(const [src,dst] of [['node_modules/babylonjs/babylon.js','babylon.js'],['node_modules/babylonjs-loaders/babylonjs.loaders.min.js','babylonjs.loaders.min.js'],['node_modules/babylonjs/license.md','BABYLON-LICENSE.md'],['node_modules/babylonjs-loaders/license.md','LOADERS-LICENSE.md']])await copyFile(src,'public/vendor/'+dst);
import {mkdir,cp,readFile} from 'node:fs/promises';
const html=await readFile('public/index.html','utf8');for(const file of ['arena-app.js','world.js','arena.css','camp-world.js','arena-commands.js'])await readFile('public/'+file);if(!html.includes('arena-app.js')||!html.includes('arena.css'))throw Error('Assets da clareira ausentes');
await mkdir('dist',{recursive:true});await cp('public','dist/public',{recursive:true});console.log('Build local concluído. Nenhum CDN ou segredo no frontend.');
