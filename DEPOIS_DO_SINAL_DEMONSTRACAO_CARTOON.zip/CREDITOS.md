# Depois do Sinal — A passageira do último ônibus, parte 1

Ficção original desenvolvida para este projeto. Demonstração de linguagem visual cartoon a partir das referências gerais fornecidas pelo usuário. Não representa caso real nem reproduz um vídeo dos perfis apresentados.

Personagens, cenários, objetos e animação final: desenhos vetoriais originais criados por código Canvas 2D, renderizados em Chromium. Incluem articulação dos membros, piscar, olhos, movimentos de boca pelo envelope do áudio, movimento do ônibus, rodas, chuva, limpador de para-brisa, gesto de apontar e revelação do bilhete.

Foram criados estudos ilustrados com geração de imagem antes de o usuário enviar os prints de referência. Esses estudos foram substituídos na versão final e não compõem os quadros do vídeo entregue.

Vozes: Kokoro ONNX, pm_alex e pf_dora, vozes neurais padrão em português brasileiro. Sem amostras de dubladores ou clonagem de uma pessoa real.

Trilha, chuva, motor, ar da porta e transições: síntese original para a produção, sem gravações de músicas comerciais.

Fontes: Barlow Condensed ExtraBold, sob SIL Open Font License; DejaVu Sans, sob sua licença incluída no pacote. Alinhamento das legendas com faster-whisper. Codificação e masterização com FFmpeg.

A pesquisa registra as fontes efetivamente acessadas e os limites de acesso ao TikTok. Nenhuma imagem dos perfis de referência é distribuída neste pacote.
