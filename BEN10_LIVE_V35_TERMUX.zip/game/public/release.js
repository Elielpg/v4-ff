export const BUILD_ID='35.0.0';
export const BUILD_LABEL='Ben 10 · Arena Omnitrix LIVE · 35.0.0';
