// Original procedural silhouettes for the two forms without bundled GLB assets.
export function refinedAlienParts(form){const plant=form===10,parts=[],skin=plant?[.22,.56,.13]:[.035,.045,.08],accent=plant?[.45,.8,.18]:[.8,.91,1],dark=[.025,.07,.04];const add=(p,s,c=skin,kind='capsule',rotation=null)=>parts.push({p,s,c,kind,...(rotation?{rotation}:{})});
 add([0,1.37,0],[.88,1.16,.48]);add([0,.91,0],[.62,.45,.44]);add([0,2.12,0],[.53,.59,.48],skin,'sphere');
 for(const side of [-1,1]){add([side*.47,1.77,0],[.35,.35,.36],skin,'sphere');add([side*.57,1.48,0],[.27,.63,.27]);add([side*.61,1.02,-.015],[.22,.61,.23]);add([side*.61,.73,-.04],[.24,.24,.22],skin,'sphere');add([side*.22,.63,0],[.28,.76,.3]);add([side*.22,.24,-.02],[.22,.54,.24]);add([side*.22,.08,-.12],[.29,.17,.42],skin,'sphere');
  if(plant){for(let i=0;i<3;i++)add([side*(.54+i*.07),.56,-.04],[.05,.26,.06],accent,'capsule',[0,0,-side*.12]);for(let i=0;i<3;i++)add([side*(.27+i*.11),1.98-i*.1,.02],[.19,.58,.08],accent,'crystal',[0,0,-side*(.4+i*.22)]);}
  else{add([side*.21,2.48,.01],[.12,.46,.12],skin,'crystal',[0,0,-side*.2]);add([side*.11,2.16,-.225],[.17,.065,.045],[.75,1,.62],'sphere');}
 }
 if(plant){add([0,2.15,-.235],[.34,.24,.05],dark,'sphere');add([0,2.15,-.265],[.24,.17,.035],[.72,.95,.2],'sphere');add([0,2.15,-.286],[.065,.16,.02],dark,'sphere');for(let i=0;i<4;i++)add([0,1.4-i*.12,-.245],[.45-i*.04,.045,.035],accent,'sphere');}
 else for(let i=0;i<42;i++){const y=.95+(i%11)*.115,x=Math.sin(i*7.3)*(.22+(i%3)*.04),z=-.22-Math.cos(i*3.1)*.025;add([x,y,z],[.019+(i%3)*.006,.019+(i%3)*.006,.019],accent,'sphere');}
 add([0,1.63,-.26],[.22,.22,.07],dark,'sphere');add([0,1.63,-.30],[.13,.13,.025],[.6,1,.25],'sphere');return parts;}
