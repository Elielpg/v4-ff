# Ben 10 · Arena Omnitrix LIVE · V35

Personagem menor com câmera adaptativa, presentes em slides, 15 famílias de efeito, falas variadas do Ben para o público, articulação revista e novas formas procedurais de Alien X/Cipó Selvagem. [Novidades e atualização da V35](docs/V35_NOVIDADES.md).

```sh
bash install.sh
bash start.sh
```

Abra o endereço indicado no Chrome do mesmo aparelho e toque em ♫. Confira **35.0.0**. Para atualizar a V34 preservando configurações, use `bash update.sh --archive /caminho/BEN10_LIVE_V35_TERMUX.zip --start` na instalação anterior. Instruções completas no guia acima.

## Desenvolvimento

Node>=22.19 e Python para empacotamento/atualização. Use o checkout existente.

- `npm ci`: instalação pelo lockfile.
- `npm test`: domínio,40 missões, integração HTTP/SSE, fila de presentes, rigs/efeitos e conectores com transporte controlado.
- `npm run lint`: verificação de sintaxe JavaScript.
- `npm run build`: prepara Babylon e licenças locais, copia public/ para dist/public.
- `npm run package`: executa verificações e gera `BEN10_LIVE_V35_TERMUX.zip`, sem `data/`, `.env` ou `node_modules`.
- `bash doctor.sh`: diagnóstico do servidor sem expor chaves.
- `bash backup.sh`: exporta configuração/modelos locais sem chaves.

O jogo contém nove GLBs de terceiros com licençaCCBY4 e duas formas procedurais. Veja [créditos](docs/MODEL_CREDITS.md), [animações](docs/ANIMACOES.md) e third_party/NOTICE.md. Código do jogo sob AGPL3; fontes correspondentes do conector incluídas em third_party. Personalizações GLB em data/models continuam prevalecendo; o treino usa as formas incluídas.

A jornada percorre distância sem limite fixo, com quatro temas reutilizados em trechos variados; não representa um mapa geográfico infinito. Progresso de missão é da sessão do servidor. Performance Android, vozes de serviços externos e cada condição de rede devem ser verificados no aparelho.
