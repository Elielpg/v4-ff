# Plataforma Zero — Episódio 1, segunda edição

Ficção original de suspense. Lia, Davi, a estação técnica, o trem e a máquina Trio são modelos volumétricos 3D e rigs procedurais criados para esta produção. Renderização com Babylon.js em Chromium; edição, mixagem e codificação com FFmpeg. A referência enviada pelo usuário orienta o ritmo e a linguagem visual. Imagens, personagens, gravação de voz e trilha da referência não foram reutilizados.

A V2 redesenha os rostos com superfícies curvas, olhos em formato de amêndoa, sobrancelhas reativas e bocas animadas; adiciona dedos, roupas com alças curvas e detalhes à estação. A montagem inclui uma abertura de impacto, reações, aproximações, o contato entre os braços e o aviso falado por Lia. A boca acompanha a amplitude da voz nessa fala; não é alinhamento por fonemas nem captura de movimento.

Voz: Supertonic 3, timbres padrão M1 (narrador) e F4 (Lia), português. São vozes sintéticas de fábrica, sem clonagem. Modelo sob BigScience Open RAIL-M; licença incluída. Código do motor no arquivo público do projeto Supertonic, sob sua licença original. As descrições de cena não foram enviadas como fala.

Trilha original composta por notas e arranjo programados para o episódio: cordas, pizzicato, baixo, metais, ambiente e percussão, com pulsação que cresce durante a perseguição. Instrumentos renderizados com FluidSynth e GeneralUser GS, de S. Christian Collins. A licença do GeneralUser GS permite gravações musicais comerciais e privadas e está incluída. O banco de instrumentos não é redistribuído neste pacote. A trilha separada e o MIDI da composição acompanham o vídeo.

Efeitos originais sintetizados de portas, metal, passos, sensor, transições e impactos. Fontes Barlow Condensed sob SIL OFL e DejaVu: licenças incluídas.

O MP4 já possui narração, trilha, efeitos e legendas. O SRT separado é opcional. Esta entrega revisa somente o episódio 1; os episódios 2 a 9 continuam na etapa de roteiro. Nenhuma postagem no TikTok ou medição de alcance foi realizada.
