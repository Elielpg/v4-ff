# Plataforma Zero — o que mudou na V2

A segunda edição mantém a história de Lia e Davi na estação fora do mapa e revisa a apresentação do episódio 1.

| Item | V1 | V2 |
| --- | --- | --- |
| Duração medida | 77.23 s | 55.67 s |
| Planos de câmera | 26 | 33 |
| Tempo médio por plano | 2.97 s | 1.69 s |
| Narração | Kokoro pm_alex | Supertonic 3 M1 |
| Fala de personagem | Sem fala direta | Lia, com voz F4 e animação da boca |
| Música em relação à voz, RMS dos stems | -20.8 dB | -7.3 dB |
| Formato | 1080 × 1920, 30 fps | 1080 × 1920, 30 fps |

As medidas de RMS indicam o equilíbrio entre arquivos de música e voz antes da masterização. Não medem emoção, preferência do público ou alcance.

## Voz e música

O narrador usa outro motor e timbre. O texto ganhou frases mais curtas, exclamações e velocidades diferentes por cena. Lia fala diretamente com Davi no momento do perigo; essa fala inclui uma respiração gerada pelo motor, e a boca acompanha a amplitude do áudio.

A trilha foi composta para o episódio, com cordas, pizzicato, metais, baixo e percussão. O pulso aumenta durante a perseguição. Portas, metal, passos, sensor, transições e impactos possuem efeitos separados. A música da referência não foi copiada. O pacote inclui a trilha em MP3 e o MIDI da composição.

## Personagens, cenário e montagem

Os rostos têm nova geometria, olhos sobre uma superfície curva, sobrancelhas e expressões reativas. As mãos receberam dedos; as roupas, alças curvas, gola e outros detalhes. A estação ganhou texturas de piso e parede, tubulações, travessas, grelhas, placas, luzes de emergência e partículas discretas.

A montagem abre com uma antecipação do perigo e alterna planos de detalhe, reações e ação. Há closes do aviso, do celular, do contato entre os braços e da máquina. A iluminação foi reposicionada para deixar os rostos mais visíveis, com sombras suaves e contraste de tons frios e âmbar.

## Conferência

O MP4 possui 1670 quadros, H.264 e AAC estéreo a 48 kHz. A sequência de quadros, a duração entre som e imagem e a decodificação do arquivo completo passaram nos testes. A medição de volume final consta em `VALIDACAO.json`.

A transcrição automática da mixagem foi usada para localizar possíveis palavras encobertas. Ela contém diferenças de grafia, nomes e formas como “pra”/“para”; não substitui avaliação humana de timbre ou emoção. O registro não é uma promessa de desempenho de audiência.

A V1 permanece preservada. Esta entrega revisa somente o episódio 1; os episódios 2 a 9 continuam na etapa de roteiro.
