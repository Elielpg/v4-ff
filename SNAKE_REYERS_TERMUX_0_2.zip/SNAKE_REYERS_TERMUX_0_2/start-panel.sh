#!/usr/bin/env bash
set -euo pipefail
adapter_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ $# -lt 1 ]]; then
  printf 'Uso: bash start-panel.sh /caminho/da/pasta/SnakeReyers [--diagnose]\n' >&2
  exit 2
fi
project_dir="$1"
shift
adapter_python="${SNAKE_ADAPTER_PYTHON:-$adapter_dir/.venv/bin/python}"
if [[ ! -x "$adapter_python" ]]; then
  printf 'Prepare as dependências primeiro: bash install-panel.sh\n' >&2
  exit 1
fi
cd -- "$adapter_dir"
exec "$adapter_python" -m snake_termux --project "$project_dir" "$@"
