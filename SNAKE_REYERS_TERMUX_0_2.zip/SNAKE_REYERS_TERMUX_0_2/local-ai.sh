#!/usr/bin/env bash
set -euo pipefail
adapter_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "$adapter_dir"
exec .venv/bin/python -m snake_termux.reuse_ai --state "$adapter_dir/state" "$@"
