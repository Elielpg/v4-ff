# Snake Reyers 0.1.9 — adaptador Termux 0.3.3

Conversa Qwen local com contexto por espectador, respostas mais completas e ritmo de voz selecionável. Preserva jogo, áudio privado, biblioteca musical, progresso e integrações.

O Snake Reyers é de Thiago Reyes. Este complemento usa sua cópia original e preserva os avisos e licença. Não contém o EXE, fontes ou músicas originais nem modelos de IA. Inclui uma trilha instrumental própria, CC0.

## Conversa Qwen local e ritmo da voz — 0.3.3

Esta revisão mantém o **Qwen local já instalado**, com a personalidade original da Serpente do Abismo e sua atribuição. Não instala outro modelo no celular. O contexto da pergunta deixa de duplicar as instruções antigas, e a resposta direta passa a admitir até **220 caracteres**, com opção de **150** no painel. O início de uma explicação não deve ser cortado só para caber numa tirada sobre maçãs.

Para atualizar, pare o iniciador com **Ctrl+C**, espere o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_CONVERSA_LOCAL_V033.sh?v=0.3.3" -o "$HOME/atualizar-snake-local.sh" &&
bash "$HOME/atualizar-snake-local.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Mantenha o Tor na outra sessão. Recarregue http://127.0.0.1:9393 e confira **Termux 0.3.3** e **IA ATIVA: QWEN LOCAL**. O reparo seleciona respostas locais antes de iniciar e guarda a configuração privada anterior em backup. **Voz, chaves, portas, músicas, ranking e progresso são preservados.** O ZIP contém somente o complemento; sua cópia original do jogo continua necessária.

### Respostas e personalidade

A cobra conversa sobre assuntos gerais usando o conhecimento do modelo. Perguntas informativas priorizam uma explicação curta e precisa; comentários dirigidos à cobra mantêm sarcasmo gentil e humor. A separação usa regras simples de intenção: pode classificar casos ambíguos incorretamente. As saudações instantâneas e os presentes continuam no fluxo original. O modelo não executa comandos, não altera regras do jogo e não recebe ferramentas de sistema.

Em **Conversa Qwen**, escolha **Equilibrada** ou **Curta**. A memória local guarda no máximo duas trocas recentes por espectador, com validade de uma hora e até 128 espectadores. Ela usa chaves de usuário em hash e arquivo privado com permissão 0600, fora dos recursos públicos do painel. Desative a memória ou use **Apagar memória das conversas locais** quando quiser. O botão não apaga ranking, progresso ou credenciais. Uma falha de gravação mantém a conversa disponível na sessão, com aviso, sem descartar uma resposta já gerada.

Não há acesso à internet para responder. Algumas perguntas reconhecidas sobre clima, notícias, cotações, placares e contagens atuais sem telemetria recebem aviso explícito de indisponibilidade, em vez de um palpite apresentado como fato. Isso não é um classificador perfeito de todo dado atual. O modelo continua sujeito a erros de conhecimento, linguagem e interpretação; **não foi transformado em uma IA que acerta qualquer pergunta**.

### Voz

A voz selecionada é mantida. Se ela for **OpenAI/cedar**, continua dependendo da API para gerar áudio, mesmo com respostas Qwen locais. As orientações de dicção foram ajustadas sem trocar o timbre selecionado; a qualidade real OpenAI ainda precisa ser ouvida na sua conta. Para não usar API de voz, selecione **Piper local**, salve e reinicie o iniciador.

O Piper oferece **Clara**, **Natural** e **Ritmo anterior**. Clara reduz a pressa em relação ao perfil anterior; Natural usa o ritmo de referência do modelo. Não há clonagem, mudança artificial de R para L ou promessa de um novo timbre. Respostas de até 240 caracteres podem ser sintetizadas em uma chamada, evitando a quebra automática em 150 caracteres que reiniciava a prosódia. O WAV e a timeline continuam na fila original que anima a boca.

O cache distingue perfil, versão e arquivo de voz. O worker mantém duas threads de inferência e espera ativa desligada. O perfil atualizado entra quando este iniciador carrega seu worker; um Piper externo antigo é preservado e pode não oferecer controle de ritmo. **Salvar ritmo não troca automaticamente o motor de voz.** A opção anterior permanece para comparação/reversão.

### Evidências e limites

Passaram **276 testes Python** (67 originais e 209 do complemento), três testes Node e a verificação da interface móvel. O Qwen3-4B-Instruct-2507 Q4_K_M real respondeu às amostras de conhecimentos gerais e a uma continuação sobre o cachorro Thor. Os registros incluem as respostas completas, não apenas um indicador de sucesso. Os checks de tópico são parciais: ainda apareceram expressões técnicas incorretas, como “comprimida de onda”, e erros gramaticais. Isso permanece documentado, sem declarar precisão universal.

Piper real gerou os três perfis com WAV válido; a amostra Clara teve 5,805 s e a anterior 5,550 s. Isso confirma mudança de ritmo nesse arquivo, **não comprova melhora subjetiva de timbre/dicção**. O Godot original concluiu falas com mais de 150 caracteres e o mixer PulseAudio foi gravado. Tudo ocorreu em Linux x86_64, sem benchmark ou teste de alto-falante/Bluetooth do GT3. O ensaio Qwen usou prazo de desenvolvimento de 30 s; produção mantém o prazo de 18 s. Cache, carga concorrente e aquecimento impedem tratar essas amostras como garantia de velocidade no aparelho.

Backup dos arquivos próprios: `state/launcher-backups/local-social-v033.*`. A seleção de IA anterior fica em `state/launcher-backups/local-choice-v033-*.json`, com permissão 0600. Para reverter, pare o iniciador, restaure os arquivos próprios nos mesmos caminhos e, se desejar, copie o backup da seleção para `original/server/private/social_text_ai.json` da sua instalação. Também pode escolher Gemini/OpenAI novamente pelo painel, sem apagar as chaves. Os modelos e o jogo original não foram substituídos.

## LIVE movimentada, seleção da IA e espectadores — 0.3.2

O print recebido mostra **“Respondeu ao teste” no Gemini**, mas a pergunta termina com erro do **Qwen local**. São testes diferentes: verificar uma chave não seleciona o provedor de respostas. Também foi encontrada uma condição de corrida no iniciador: depois de carregar o Qwen, ele gravava novamente a seleção local, mesmo se o operador já tivesse escolhido Gemini. Essa gravação foi removida; um teste reproduz a troca durante o carregamento e verifica que Gemini e voz OpenAI permanecem selecionados.

### Atualizar e escolher quem responde

Pare o iniciador com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_LIVE_FLUIDA_V032.sh?v=0.3.2" -o "$HOME/atualizar-snake-live.sh" &&
bash "$HOME/atualizar-snake-live.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Mantenha o Tor na outra sessão. Recarregue http://127.0.0.1:9393 e confira **Termux 0.3.2**. Em **Respostas e voz**, clique em **Usar Gemini para responder · salvar seleção** e confira **IA ATIVA: GEMINI**. Depois faça uma pergunta em **Testar resposta**. A escolha da voz é independente: **OpenAI / cedar / Natural e clara** continua disponível, sem mudar o provedor de respostas. O teste de pergunta recusa uma seleção divergente antes de chamar o modelo, para não consultar Qwen por engano.

O catálogo Gemini agora aceita paginação, preserva o modelo que respondeu e evita gastar o limite pequeno de saída apenas em raciocínio. Se um modelo anunciado retornar 404, o modo auto pode tentar outra opção anunciada; se parâmetros opcionais forem recusados, há uma tentativa de compatibilidade no mesmo modelo. Limites: até duas chaves e três gerações, com prazo total controlado; nunca troca modelo/chave do mesmo projeto para contornar cota. O painel distingue configuração, modelo indisponível, faturamento, região, chave recusada e limite de saída. Cotas reais permanecem respeitadas, inclusive após reiniciar. Nenhuma chamada real com suas chaves foi realizada nesta máquina.

### Fila e nomes

Em **Ritmo das respostas e câmera**, mantenha **Resposta direta**. Em **LIVE movimentada · fila e nomes**, a opção vem ativa por padrão e pode ser desativada:

- Prepara no máximo **uma próxima resposta** durante a fala atual; há apenas uma voz reproduzindo por vez. O foco do próximo usuário só é enviado quando sua fala é despachada ao jogo. Cantoria, sequências manuais e o diálogo original mantêm seus bloqueios.
- Prioriza perguntas recentes dentro da prioridade original dos comentários, descarta comentários com mais de 18 s e limita o histórico de deduplicação de comentários a 512 entradas recentes. Presentes mantêm suas regras originais de prioridade e deduplicação.
- Agrupa saudações faladas em no máximo uma a cada 20 s; personagens/eventos de entrada continuam no fluxo visual. Uma voz não consegue responder a todos numa LIVE grande. Falha de IA gera aviso curto e espaçado, em vez de apresentar uma frase pronta sem relação como resposta à pergunta.
- Converte nomes decorados como **G U S T A V O** para **Gustavo** somente no texto enviado à voz. Não lê números/símbolos do identificador como parte do nome. Nome visível, foto, legenda e ranking permanecem originais. **Conferir nome falado** não gera áudio; **Salvar pronúncia** permite até 200 aliases por @. A dicção final depende do motor de voz e deve ser ouvida no aparelho.

No ensaio com Godot original, Piper e mixer PulseAudio reais no Linux, usando um atraso de geração controlado de 0,7 s, o intervalo entre duas falas foi **1,906 s → 0,864 s**. A segunda preparação ocorreu durante a primeira fala apenas no modo novo. Não é benchmark do Gemini, da internet, de uma LIVE real ou do GT3, nem garantia de latência semelhante no celular.

### Qualidade e painel do operador

Os perfis opcionais **720p · limite 45 FPS** e **Mais nítido · 864×1536 · limite 30 FPS** permitem testar nitidez e margem de processamento. O perfil atual não é alterado automaticamente; aumentos continuam condicionados à GPU verificada. Salve e feche/abra a janela pelos botões do painel para aplicar. Se estiver travando, comece pelo perfil **Estável · 640×1136 · limite 30 FPS**. Limite configurado não significa FPS alcançado. Serviços locais já carregados não são encerrados à força ao trocar para nuvem; reiniciar o iniciador libera os que ele próprio criou.

Abra **http://127.0.0.1:9393/termux/director** ou o link **Abrir painel do operador · espectadores e FPS**. Ele mostra espectadores simultâneos informados pelo TikTok, horário/idade do dado, FPS observado no log atual e GPU real do jogo. Não confunde espectadores totais, curtidas ou presentes com público atual. Antes do primeiro evento mostra “—”; desconexão ou dado com mais de 30 s fica identificado como desatualizado. Não há segunda renderização 3D.

**O contador fica fora do cenário, mas captura da tela inteira do celular pode mostrar o navegador quando você o abrir.** Para mantê-lo fora da LIVE é preciso captura somente do aplicativo do jogo, quando suportada, ou configuração apropriada de outro dispositivo. O painel permanece em loopback; não foi aberto acesso remoto.

### RTP, RTMP e transmissão

Para URL/chave de transmissão TikTok, o caminho usual é **RTMP/RTMPS**, não RTP. É preciso que a conta tenha acesso à URL e chave fornecidas pelo TikTok; não as envie pelo chat. Um aplicativo Android com MediaProjection e H.264 por hardware, como uma ferramenta de transmissão compatível, é o caminho para avaliar captura de imagem/áudio no aparelho. RTMP não corrige baixo FPS, aquecimento ou rede instável por si só.

Esta revisão acrescenta **diagnóstico e painel do operador**, não um transmissor Android. O botão de encoders consulta apenas a lista do FFmpeg, sem capturar nem transmitir. A presença de MediaCodec nessa lista não prova que funciona nessa instalação. O pipeline GStreamer/NVENC do original foi feito para desktop e não foi apresentado como compatível com o Termux. Nenhuma transmissão foi iniciada ou validada aqui.

Backup antes do reparo: `state/launcher-backups/live-load-v032.*`, somente dos arquivos próprios substituídos. Para reverter, pare o iniciador e restaure esses arquivos nos mesmos caminhos; músicas, credenciais, progresso e jogo original não são sobrescritos. As preferências novas também podem ser desativadas no painel. O ZIP distribui somente o complemento independente, sem jogo original, assets originais, modelos ou chaves.

## IA de respostas e voz na nuvem — 0.3.1

A revisão adiciona **Gemini com até dez chaves** e **OpenAI para respostas e voz**, mantendo Qwen, Piper e XTTS como opções. A IA que escreve e o motor que fala são independentes: Gemini + Piper, Gemini + voz OpenAI, OpenAI + Piper ou tudo local. Não há ligação com este chat, nem acesso à memória da sua conta ChatGPT. O modelo recebe a identidade original da cobra e a pergunta encaminhada pelo fluxo original do jogo.

**ChatGPT Plus/Pro e API são cobranças separadas.** Ter uma assinatura do ChatGPT não fornece créditos da API. O Gemini oferece faixa gratuita apenas em modelos/contas/projetos elegíveis, com limites. Um modelo anunciado no catálogo não comprova cota nem gratuidade. Não há consulta de saldo financeiro por chave; o painel mostra testes de disponibilidade e erros. Os botões de teste e as respostas reais podem consumir cota ou gerar cobrança conforme a conta/modelo.

Pare o iniciador com **Ctrl+C**, aguarde o prompt e atualize:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_IA_NUVEM_V031.sh?v=0.3.1" -o "$HOME/atualizar-snake-ia.sh" &&
bash "$HOME/atualizar-snake-ia.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

A pasta antiga é mantida. Recarregue http://127.0.0.1:9393 e confira **Termux 0.3.1**. Mantenha o Tor na outra sessão.

### Gemini: várias chaves e disponibilidade

1. Crie uma chave em https://aistudio.google.com/apikey. Confira a elegibilidade para faixa gratuita e as cotas no Google AI Studio.
2. No cartão **Respostas e voz**, selecione **Gemini**, ative as respostas e cole as chaves no campo próprio, uma por linha. Use o modelo **auto** para descobrir um modelo Flash de texto anunciado pela API, ou informe um modelo disponível na sua conta.
3. Salve. Os campos de chave ficam vazios depois de salvar, e nenhum valor completo é devolvido pelo servidor.
4. Clique **Verificar chaves Gemini**. Isso faz uma pequena geração por chave e usa cota. O painel diferencia chave recusada, resposta obtida e espera por cota. Não retorna saldo em reais/dólares.
5. Faça uma pergunta em **Testar resposta** antes de entrar na LIVE.

Por padrão, as chaves são tratadas como pertencentes ao mesmo projeto, pois o valor da chave não informa seu projeto. Chaves do mesmo projeto **compartilham os limites**. Se forem realmente de projetos diferentes, use uma linha como `projeto-a | SUA_CHAVE` e outra como `projeto-b | OUTRA_CHAVE`. Esses nomes são grupos locais; não alteram o projeto real no Google.

Quando uma chave é recusada, o sistema deixa de selecioná-la. Quando a API informa cota/limite de projeto, o grupo inteiro daquele modelo aguarda o intervalo, inclusive após reiniciar. Não há rodízio para furar a cota do mesmo projeto. Na 0.3.2, há no máximo duas chaves e três gerações por resposta, com prazo total limitado; uma verificação prévia ajuda a evitar tentativas em chaves inválidas. Outro projeto só é usado se estiver configurado e tiver disponibilidade dentro de suas próprias cotas.

### OpenAI: respostas e voz

Crie a chave em https://platform.openai.com/api-keys e configure o faturamento em https://platform.openai.com/settings/organization/billing/overview. Não envie a chave pelo chat, por comentário da LIVE ou em screenshots.

No painel, cole a chave em **Nova chave OpenAI** e use **Salvar IA e chaves**. O modelo padrão para respostas é `gpt-4.1-mini`, editável para outro modelo ao qual sua conta tenha acesso. Não é uma garantia de equivalência com o ChatGPT usado nesta conversa. Os modelos não recebem ferramentas de sistema ou navegação; perguntas sobre fatos atuais não ganham pesquisa automática na internet.

Para a voz, **não precisa baixar um modelo**. Selecione **OpenAI** na opção de voz, escolha uma voz como **cedar**, **marin** ou outra da lista e selecione:

- **Natural e clara** para priorizar dicção.
- **Cobra fanha leve** para nasalidade leve e humor, pedindo para não trocar R por L.
- **Animada e expressiva** para um personagem mais energético.

Salve e use **Ouvir teste** para comparar. O teste gera áudio na API e pode ser cobrado. O resultado do timbre/estilo depende do serviço e ainda precisa ser ouvido na sua conta; não foi prometida clonagem nem semelhança exata com outra voz. As características são enviadas em `instructions`; somente a frase vai em `input`. O áudio PCM 24 kHz é empacotado em WAV válido e entra na mesma fila/timeline que move a boca da cobra.

### Preservação, uso de recursos e falhas

Salvar configurações e consultar o estado não chama as APIs. Uma chave histórica no projeto não ativa automaticamente o provedor novo: a escolha precisa ser salva no painel. Não se inicia Qwen quando a IA de respostas selecionada é na nuvem; não se inicia Piper quando a voz é OpenAI. Serviços externos já em execução não são encerrados automaticamente. Gemini + Piper mantém algum uso local de CPU para a voz; o jogo continua precisando da GPU/CPU. Não há promessa de menor latência, pois internet, modelo, fila e limite do serviço também influenciam.

As chaves ficam no arquivo privado de configuração existente, com permissão 0600, e não são retornadas em GET, HTML, diagnósticos, cache público ou logs de erro da integração. OpenAI usa Authorization e Gemini usa x-goog-api-key em HTTPS com hosts fixos; não se colocam chaves Gemini na URL. Redirecionamentos não são seguidos. Respostas OpenAI usam `store:false`, sem alegação de eliminar toda retenção da plataforma.

Há limite local de 20 chamadas/minuto por serviço/grupo para conter filas; os limites do provedor também continuam valendo. A voz tem cache local de até 60 falas. Falhas de chave, rede ou cota aparecem no painel e não encerram o jogo. O fluxo original mantém suas saudações e falas de contingência; uma frase de contingência não comprova que a IA respondeu à pergunta. Não há troca silenciosa para outro provedor pago ou clonagem.

Backup dos arquivos do complemento: `state/launcher-backups/cloud-ai-v031.*`. Para reverter, pare o iniciador e restaure os arquivos próprios desse backup para os mesmos caminhos. Configurações, progresso, modelos e músicas não são substituídos pelo reparo. A seleção dos provedores pode ser alterada pelo painel a qualquer momento.

Validação: testes automatizados e de navegador com APIs simuladas e chaves fictícias, mais passagem pela fila, animação e áudio do jogo original no Linux. **Não foram realizadas chamadas reais pagas, nem validados saldo, modelos da sua conta, qualidade da voz OpenAI ou latência no GT3.** Use os testes do painel depois de configurar as chaves.

## Travadas e áudio engasgando — 0.3.0

O relato após a importação musical é de mais travadas e som entrecortado. Ainda não chegaram os logs da sessão afetada nem o resultado do teste pausando somente a música; portanto a causa exata no GT3 não está confirmada.

A auditoria encontrou concorrência que pode agravar a falta de tempo de CPU: o Piper criado pelo complemento usava o pool padrão do ONNX Runtime, com workers em espera ativa; a conversão FFmpeg concorria na prioridade normal. O áudio privado tinha buffer de 80 ms. A revisão 0.3.0 trata esses pontos sem alterar os recursos compilados do jogo:

- Piper com duas threads de inferência, execução sequencial e espera ativa desabilitada; mesmas configurações de voz, modelo e cache.
- Conversão FFmpeg de uma thread com prioridade `nice +10`, quando disponível, apenas para o processo filho de preparação.
- Buffer de áudio privado ampliado para 160 ms, usado tanto no módulo Android quanto pelo Godot. Essa margem acrescenta atraso à saída; não promete resposta de IA mais rápida. Uma latência explicitamente definida no ambiente é respeitada.
- Perfil opcional **Estável · 640×1136 · limite 30 FPS**. O perfil atual continua salvo; apenas o botão do painel muda a escolha.

Para atualizar, pare o iniciador com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_ESTABILIDADE_V030.sh?v=0.3.0" -o "$HOME/estabilizar-snake.sh" &&
bash "$HOME/estabilizar-snake.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

A pasta mantém o nome antigo para preservar sua instalação. Confira **Termux 0.3.0** no painel recarregado. Para reduzir a carga gráfica, escolha **Estável**, salve e use **Fechar janela do jogo / Abrir jogo original**. Mantenha o Tor na outra sessão. Prepare faixas longas antes da LIVE quando possível; mesmo com prioridade menor, a conversão ainda consome CPU e armazenamento.

O Piper corrigido entra quando este iniciador cria seu próprio serviço. Um Piper externo já em execução é reutilizado e não é encerrado pelo reparo. O patch não reinstala modelos, drivers ou pacotes, não apaga músicas e não muda a conexão TikTok. Backup dos arquivos próprios em `state/launcher-backups/stable-playback-v030.*`. Para reverter, pare o iniciador e restaure os arquivos desse backup para os mesmos caminhos. O perfil gráfico pode ser revertido pelo painel.

Validação: 201 testes Python e três Node; jogo original + PulseAudio privado reais no Linux, com música e fala Piper concluindo juntas; interface móvel e seleção de perfil. Na amostra de Piper do host Linux, o uso de CPU para a frase caiu de 1,03 para 0,58 CPU-segundo, com espera ativa medida de 0,19 para 0 CPU-segundo no segundo seguinte. O tempo de síntese foi de 0,250 para 0,325 s: a mudança reserva CPU, não demonstra aceleração da voz. É uma amostra de um host Linux x86_64, sem equivalência de performance com o GT3.

Se persistir, faça um teste de 20 segundos com somente a música pausada e guarde `state/device-runtime.json`, `state/logs/audio-private.log` e as últimas linhas de `state/logs/game-native.log`. GPU em software, Bluetooth, temperatura ou pressão de memória não podem ser descartados sem esses dados. Nenhuma dessas hipóteses foi marcada como causa confirmada.

## Música importada e biblioteca — 0.2.9

Durante uma pausa, pare o iniciador com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_BIBLIOTECA_MUSICAS_V029.sh" -o "$HOME/atualizar-snake-musicas.sh" &&
bash "$HOME/atualizar-snake-musicas.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Mantenha o Tor na outra sessão. Abra http://127.0.0.1:9393 e atualize a página; confira **Termux 0.2.9** no cartão do jogo. Em **Biblioteca de músicas**:

1. As faixas enviadas anteriormente já aparecem. Escolha **Barões** e toque em **Tocar / salvar seleção**. A primeira preparação pode levar alguns minutos; as próximas usam a conversão salva.
2. Para outras faixas, selecione vários arquivos e use **Salvar músicas**. Salvar não interrompe a faixa atual; depois escolha qual tocar.
3. **Repetir a faixa escolhida** mantém somente essa música na fila do jogo.
4. Para várias músicas, marque as desejadas, selecione **Automático · sortear somente as marcadas** e toque em **Tocar / salvar seleção**. Não marque Neon Garden se não quiser a trilha padrão.
5. **Próxima faixa**, pausa e volume ficam no mesmo cartão. A seleção e o modo permanecem após reiniciar. O volume anterior de 9% é preservado até você alterá-lo.

Formatos: MP3, OGG, WAV, M4A, AAC, FLAC e OPUS. Limites: 200 MB por arquivo e até quatro horas por faixa. O upload é feito um arquivo por vez; o painel pode enviar vários em sequência. A conversão usa FFmpeg com uma thread, fora do loop de eventos, e é limitada a 15 minutos por arquivo. FFmpeg faz parte da instalação existente; o reparo não consulta APT nem baixa modelos.

A extensão `.mp3` não garante conteúdo MP3. O novo importador verifica o áudio real com FFprobe e converte para OGG/Vorbis antes de confirmar que foi salvo. Se o arquivo estiver truncado, vazio, for uma página de download ou não puder ser decodificado, o painel mostra o erro e conserva a reprodução anterior. Nesse caso é preciso obter outro arquivo de áudio válido; renomear não resolve.

Os arquivos antigos são preservados. Novos originais ficam em `state/music-originals/`, os OGG compatíveis em `original/server/assets/music/background/` e a seleção em `state/music-library.json`. A rota de upload antiga também passa pela validação. O diretório `assets/singing/originals` continua reservado à cantoria por presentes; é uma função diferente da música de fundo.

Backup dos arquivos do complemento: `state/launcher-backups/music-library-v029.*`. Para reverter, pare o iniciador e copie os arquivos próprios desse backup de volta para os mesmos caminhos, incluindo `start.sh` e `snake_termux/`. O reparo guarda `native.py` e `ui.js` anteriores; o jogo original, progresso, configurações, modelos e músicas permanecem fora da substituição. Uma cópia de segurança de toda a instalação é recomendada antes de restaurar dados manualmente.

Teste Linux com o jogo original, FFmpeg e PulseAudio reais: AAC/M4A e WAV com nome MP3 foram convertidos e reproduzidos; a faixa manual repetiu, o automático alternou só entre as duas marcadas e Neon Garden ficou fora. A saída do mixer foi gravada com sinal de áudio. Piper continuou enviando falas após pausar a música. Não é uma medição do alto-falante/Bluetooth do GT3, nem uma validação de uma LIVE longa ou de faixas de uma hora no aparelho.

## Respostas diretas e menos trocas de foco — 0.2.8

O fluxo original prepara duas falas por comentário e aguarda ambas: o personagem do usuário lê e depois a cobra responde. A revisão adiciona **Resposta direta**, ativada por padrão: o usuário continua aparecendo com nome/foto, mas apenas a resposta da cobra entra na fila. O **Diálogo original** continua disponível em `Ritmo das respostas e câmera`, com alteração válida para os próximos comentários.

Durante uma pausa da LIVE, pare esta execução com Ctrl+C, aguarde o prompt e aplique:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_RITMO_LIVE_V028.sh" -o "$HOME/atualizar-snake-ritmo.sh" &&
bash "$HOME/atualizar-snake-ritmo.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Mantenha a sessão do Tor aberta e reconecte o monitor pelo painel se necessário. Não há reinstalação de IA/voz nem mudança no modo de conectar ao TikTok. O reparo guarda os arquivos próprios anteriores em `state/launcher-backups/live-pacing-v028.*`.

No modo direto, a preparação do avatar e a geração da resposta acontecem em paralelo, com ambas concluídas antes do enfileiramento, evitando uma seleção tardia do avatar durante a fala. A consulta de avatar usa timeout de até dois segundos em vez do padrão de oito. A foto original é mantida; um PNG derivado de até 256×256 é enviado para o jogo, reduzindo o trabalho de decodificar imagens grandes na câmera. As respostas diretas usam limite de 120 caracteres e preservam a personalidade original com o apelido dado pelo público: Cofra do Afismo.

Também há o perfil opcional **Modo LIVE · 640×1136 · limite 45 FPS** para reservar margem de processamento. Seu perfil atual é preservado. Para trocar, salve a qualidade e feche/abra a janela pelos botões do painel. O valor de 45 FPS é um limite configurado, não um resultado de benchmark.

O teste A/B com o jogo original e Piper real confirmou duas falas/um foco no usuário no modo original contra uma fala/nenhum desses focos no modo direto. Isso reduz a troca intermediária, sem modificar a interpolação interna da câmera do jogo compilado. O efeito sobre travadas e tempo total no GT3 ainda precisa ser observado. O Qwen foi simulado no A/B; não há alegação de velocidade do modelo no aparelho.

## Recuperar imagem e isolar o áudio — 0.2.7

O último relatório do GT3 confirmou GPU e tela em 640×1136, mas `pactl list short sinks` excedeu oito segundos. O novo log Godot chegou à inicialização gráfica sem chegar ao carregamento da arena. Foi reproduzido no Linux um serviço PulseAudio que aceita conexão e não responde: ele também atrasou a entrada do jogo no cenário.

Pare a execução atual com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_RECUPERAR_IMAGEM_SOM_V027.sh" -o "$HOME/recuperar-snake-imagem-som.sh" &&
bash "$HOME/recuperar-snake-imagem-som.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O iniciador deixa de consultar/iniciar o daemon compartilhado antes da janela. Para o jogo local, cria um PulseAudio exclusivo, com socket Unix numa pasta privada, sem listener TCP. Não carrega `default.pa` compartilhado nem o módulo de suspensão por inatividade. A saída Android e o PCM são preparados nesse servidor; o botão **Testar som do jogo** também usa essa mesma saída. O painel mostra `Termux 0.2.7`.

Se o áudio privado não responder ou não aceitar PCM, o complemento encerra somente o processo de áudio que criou e inicia Godot explicitamente com Dummy. A imagem continua abrindo, e o painel informa que ela está sem som. Não se deve interpretar esse fallback como conserto do áudio.

Ao fechar a janela/servidor, o processo privado é encerrado pelo próprio complemento. Um processo privado que não atende ao encerramento recebe término forçado após espera limitada. Não há reinício em ciclo nem encerramento do PulseAudio compartilhado ou de outros projetos. Uma saída explicitamente configurada pelo plano original de captura permanece preservada.

Logs relevantes: `state/logs/audio-private.log`, `state/logs/game-native.log` e `state/device-runtime.json`. O campo `audio.server` aponta para o socket desta execução. Um `pactl` executado sem esse endereço consulta o servidor compartilhado e pode continuar travando; não representa o estado do áudio privado do jogo.

O reparo guarda os arquivos anteriores em `state/launcher-backups/private-audio-v027.*`. Não instala drivers, modelos ou dependências e não muda o original em Downloads. Os testes Linux confirmaram imagem com áudio indisponível, conexão por servidor privado, gravação da fala e encerramento do processo próprio. A saída AAudio física do GT3 ainda precisa de confirmação.

## Reparo de áudio silencioso — 0.2.6

O log atual do GT3 confirmou `All audio drivers failed, falling back to the dummy driver`, com apenas `auto_null` no PulseAudio. O jogo recebeu os WAVs e informou início/fim de fala, mas o driver Dummy não produz áudio. A confirmação de som da sessão anterior não garantia a saída da sessão seguinte.

Pare o jogo com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_SOM_V026.sh" -o "$HOME/reparar-snake-som.sh" &&
bash "$HOME/reparar-snake-som.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Esta revisão mantém o jogo e os perfis existentes e muda a preparação do áudio:

- Quando precisa criar a saída AAudio, usa a opção oficial `no_close_hack=true`, modo de desempenho normal e buffer de 80 ms. O código do módulo Termux documenta essa opção como proteção contra falhas de `AAudioStream_close()`. A causa exata do desaparecimento da saída no aparelho ainda não foi reproduzida.
- Depois dos ajustes de tela, verifica novamente a saída, abre um PCM silencioso de 0,2 s e confirma se a saída permanece presente antes de iniciar o Godot. Isso não equivale a confirmar áudio audível.
- Para o jogo local usa a saída padrão do servidor, que pode ser reencaminhada pelo PulseAudio, sem prender a sessão a um nome temporário. Uma saída de captura explicitamente configurada é preservada.
- Usa `--audio-output-latency 80` no jogo quando o teste PCM passa. Não aumenta o volume geral nem reinicia o daemon ou outros projetos.
- O painel mostra `Termux 0.2.6`, detecta o fallback Dummy no log da execução atual e informa que uma fala enfileirada ainda não confirma reprodução.

É necessário reabrir o jogo para sair do driver Dummy. O complemento não instala outra IA/voz, não apaga a fila e não cria ciclos automáticos de reinício. Guarda os arquivos anteriores em `state/launcher-backups/audio-launch-v026.*`. No teste Linux, a fala Piper foi gravada do monitor de uma saída PulseAudio real; a saída AAudio física do Android continua pendente de confirmação.

## Atualizar tela e música — 0.2.5

Pare o jogo com **Ctrl+C** e aguarde voltar ao prompt. Execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_TELA_MUSICA_V025.sh" -o "$HOME/ajustar-snake-tela-musica.sh" &&
bash "$HOME/ajustar-snake-tela-musica.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo contém a trilha e os arquivos próprios necessários. Não reinstala drivers, voz ou modelos. Guarda os arquivos anteriores em `state/launcher-backups/display-music-v025.*`.

- **Tela limpa:** oculta teclas extras e auxiliar de mouse, ativa tela cheia em retrato e configura o X11 na mesma resolução do jogo, sem esticar os personagens. Usa apenas as preferências oficiais do Termux:X11; não exige root/ADB. As barras do Android podem reaparecer durante os gestos do sistema.
- **Qualidade:** o painel mostra `Termux 0.2.5` e permite escolher Equilibrado (720×1280), Leve (640×1136) ou Mais nítido (864×1536), todos com limite de 60 FPS quando a GPU foi verificada. Para aplicar uma troca, feche e abra a janela pelos botões do painel. O perfil leve desenha cerca de 21% menos pixels que o equilibrado; isso não é uma medição de ganho de FPS.
- **Fallback:** sem GPU confirmada, mantém o limite de 30 FPS e usa 536×960, largura compatível com o arredondamento de 8 pixels do X11. Um perfil de maior qualidade não força o modo pesado na CPU.
- **Trilha:** adiciona Neon Garden, instrumental original de 76,8 segundos, apenas se a biblioteca estiver vazia. Não substitui suas músicas nem altera pausa/volume. Se você já havia desativado música, ative-a nos controles originais do painel. É possível continuar adicionando músicas próprias por MP3/OGG/WAV.

A exibição só é indicada como aplicada depois da leitura das preferências e da confirmação da resolução por `xdpyinfo`. Falha ou timeout dessa etapa não encerra o jogo. Veja `state/display-runtime.json` e `state/device-runtime.json`.

As preferências alteradas afetam o aplicativo Termux:X11 também em outras sessões. A cópia anterior fica em `state/x11-display-before-v025.json`. Com o aplicativo X11 aberto, para restaurá-las e desativar a aplicação automática:

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 &&
.venv/bin/python -m snake_termux.presentation --restore-display
```

Para reverter os arquivos do complemento, pare o servidor e copie de volta os arquivos guardados na pasta de backup indicada pelo reparo. A pasta original de Downloads e os modelos nunca foram alterados. A faixa própria adicionada pode ser removida da biblioteca; não será recolocada automaticamente depois da primeira instalação.

## Histórico: reparo de lentidão e áudio — 0.2.4

O diagnóstico recebido mostrou SM8475, Mesa llvmpipe, Freedreno sem versão instalada e somente a saída PulseAudio `auto_null`. Isso explica renderização pela CPU e uma saída silenciosa. Também havia zero faixas de música de fundo.

Pare a sessão atual com **Ctrl+C** no terminal que executa o jogo. Depois aplique:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_GPU_AUDIO_V024.sh" -o "$HOME/reparar-snake-gpu-audio.sh" &&
bash "$HOME/reparar-snake-gpu-audio.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo preserva jogo, configuração original e modelos. Instala somente os pacotes ausentes `mesa-vulkan-icd-freedreno`, `mesa-demos` e `vulkan-tools`, com as fontes assinadas principal/X11 existentes. Não faz upgrade geral nem desativa assinaturas. Guarda os arquivos próprios anteriores em `state/launcher-backups/gpu-audio-v024.*`.

No próximo início, o jogo verifica Zink/Turnip com `glxinfo`. Só indica GPU confirmada se o renderizador mencionar Adreno/Turnip/Qualcomm e não for llvmpipe/softpipe/lavapipe. Caso contrário abre um perfil de CPU reduzido e registra o motivo em `state/device-runtime.json`.

Os perfis são 720×1280 com limite de 60 FPS quando a GPU é confirmada, ou 540×960 com limite de 30 FPS e três threads llvmpipe no fallback. **São limites de configuração, não FPS medido ou garantido.** Modelos, cenário e regras originais permanecem intactos.

Para áudio, reutiliza uma saída real existente ou tenta os módulos Android oficiais `module-sles-sink` e `module-aaudio-sink`. Seleciona essa saída para o jogo e não aumenta o volume geral do celular. A configuração é verificada em cada início, sem reescrever `default.pa`.

Atualize a página do painel e use:

- **Testar som do jogo**: envia um sinal curto pelo PulseAudio; confirme se ouviu.
- **Testar fala no jogo**: envia uma frase à fila original/Piper e ao jogo.
- **Adicionar música ao jogo**: escolha um MP3, OGG/Vorbis ou WAV do celular, até 200 MB. O arquivo é guardado na pasta de música original, sem substituir faixas existentes. O complemento não inclui músicas comerciais.

O estado do teste diferencia saída disponível de som realmente ouvido. Após esse reparo, o usuário confirmou GPU no relatório e áudio audível nos testes. O teste Cloud validou a lógica, o fallback, o painel, o envio de música e a fila do jogo; não possui hardware Adreno nem OpenSL/AAudio Android.

## Janela padrão do Termux:X11

A revisão 0.2.3 abre a janela padrão do aplicativo, correspondente ao serviço iniciado sem `-tag`. Abrir com `-d main` criava outra janela e podia mostrar Not connected mesmo com Godot e o servidor funcionando.

O usuário confirmou que o jogo apareceu no GT3 ao executar, com a sessão ainda ativa:

```bash
am start --user 0 -n com.termux.x11/com.termux.x11.MainActivity
```

Para guardar essa correção no iniciador existente, sem parar a sessão atual:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_JANELA_V023.sh" -o "$HOME/reparar-snake-janela.sh" &&
bash "$HOME/reparar-snake-janela.sh"
```

Esse reparo altera apenas `start.sh` e guarda a versão anterior. Antes da 0.2.4 os logs reais do GT3 mostravam Mesa llvmpipe pela CPU. O relatório posterior confirmou Zink/Turnip Adreno; não foi medido o desempenho real.

## Correção para Godot 4.7.stable.termux

O GT3 informou `4.7.stable.termux`. A verificação anterior exigia três números e recusava essa identificação antes de iniciar o jogo. O reconhecimento agora aceita o formato sem patch da série 4.7 e diferencia versão incompatível, erro do executável e timeout.

O carregador PCK do próprio Godot não usa o número de patch para validar o pacote. A execução do jogo original foi repetida com Godot 4.7 estável, incluindo renderização e confirmação de início/fim de fala com Piper real, no Linux.

Para atualizar uma instalação existente, execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_GODOT_V022.sh" -o "$HOME/reparar-snake-godot.sh" &&
bash "$HOME/reparar-snake-godot.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Esse reparo inclui a correção X11 anterior, faz backup dos três arquivos próprios da adaptação e preserva jogo original, configurações e modelos. Não instala outro Godot.

## Correção para Termux:X11 instalado, mas não detectado

A versão 0.2 consultava `pm path` antes de iniciar. Essa consulta pode falhar no Termux mesmo com o aplicativo instalado e impedia qualquer tentativa de conexão. A 0.2.1 verifica os comandos necessários e a resposta real do serviço X11. Se o serviço falhar, mostra as últimas mensagens do log.

Se você já instalou a adaptação, aplique somente o reparo:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_X11_V021.sh" -o "$HOME/reparar-snake-x11.sh" &&
bash "$HOME/reparar-snake-x11.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo altera apenas o iniciador e guarda sua versão anterior em `state/launcher-backups`. Modelos, configuração e progresso permanecem intactos. O ZIP completo também inclui a correção.

## Primeira instalação

1. Instale o aplicativo oficial [Termux:X11](https://github.com/termux/termux-x11/releases/download/nightly/termux-x11-universal-release.apk).
2. Baixe `SNAKE_REYERS_TERMUX_0_2.zip` em Downloads e execute no Termux:

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/SNAKE_REYERS_TERMUX_0_2.zip . &&
cd ~/SNAKE_REYERS_TERMUX_0_2 &&
bash install-termux.sh &&
bash start.sh
```

O instalador procura o original no caminho já identificado no celular: `~/storage/downloads/Bluetooth/SNACK/SnakeReyers`. Se você mudou essa pasta, informe o novo caminho:

```bash
bash install-termux.sh "/caminho/da/pasta/SnakeReyers"
```

A pasta deve conter `VERSION`, `LICENSE`, `server` e `game/windows/SnakeReyers.exe`. O instalador confere o SHA-256 e cria a cópia interna em `~/SnakeReyers-Termux/original`. A pasta de Downloads permanece intacta. Uma cópia interna existente é preservada, incluindo configurações e progresso.

A instalação inicial usa internet para dependências, sem baixar novos modelos Qwen/Piper. O preparo APT mantém a verificação de assinaturas e usa temporariamente as fontes principal/X11 existentes, preservando os repositórios extras. Se uma assinatura falhar, a instalação para com o erro original.

## Iniciar novamente

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

- Jogo: aplicativo **Termux:X11**.
- Painel: **http://127.0.0.1:9393** no navegador.
- Encerrar: **Ctrl+C** na sessão do Termux.

No painel, use **Monitor TikTok** para informar o **@ do perfil ao vivo** e conectar. O monitor original requer Node >=22, Tor e acesso atual ao TikTok; suas dependências são preparadas pelo instalador.

Para a execução local, use o iniciador e o monitor. Os recursos originais de sessão/captura/RTMP para desktop continuam no código, mas **a captura e transmissão direta pelo Android não foram validadas**. Use a janela Termux:X11 com o aplicativo de transmissão de tela habitual.

## IA e voz anteriores

O iniciador reutiliza serviços prontos ou a instalação `~/.local/share/ben10-local-ai/install.json`:

- Qwen: padrão **8081**, modelo detectado por `/v1/models`, sem chave de API.
- Piper: normalmente **8083** ou **8082**, com a voz `.onnx` e o ambiente `ben10-ai` já instalados.
- O clonador não é iniciado, e serviços de outras instalações não são encerrados.

Use os botões de detectar/testar na seção Inteligência artificial do painel. O texto enviado ao Piper preserva acentos e R/L, sem substituições fonéticas específicas do XTTS. O XTTS original permanece selecionável; sua instalação no Android não foi comprovada.

Se a IA foi desativada, o iniciador respeita a configuração. Para reativar: marque Ativar respostas por IA, salve e execute em outra sessão:

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash local-ai.sh
```

Mantenha essa sessão aberta enquanto usa serviços que ela iniciou. Nenhum modelo é reinstalado silenciosamente.

## Logs e reversão

Os logs ficam em `state/logs`: `panel.log`, `game-native.log`, `x11.log`, `local-ai.log`, `qwen.log` e `piper.log`. O código de saída do painel fica em `state/launcher-exit-code.txt`; saídas observadas do jogo ficam em `state/process-events.jsonl`. O painel distingue processo gráfico ativo de ponte conectada. Não há reinício automático em ciclo.

Diagnóstico sem abrir janela:

```bash
bash start-panel.sh "$(cat state/project-path.txt)" --game --diagnose
```

O preparador guarda `server/private` e `server/config` antes dos primeiros ajustes em `state/original-private-backup`. Esse backup pode conter credenciais: mantenha-o privado.

Para reverter, pare a execução e volte a usar a pasta original em Downloads. Para desfazer só os ajustes da cópia interna, restaure `server/private/social_text_ai.json` do backup com o servidor parado. Os hooks desaparecem ao encerrar o processo; os modelos locais permanecem intactos.

Leia [TESTES.md](docs/TESTES.md), [ARQUITETURA_E_PENDENCIAS.md](docs/ARQUITETURA_E_PENDENCIAS.md) e [VALIDACAO_NATIVA.md](docs/VALIDACAO_NATIVA.md).
