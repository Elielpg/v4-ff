# Snake Reyers 0.1.9 — adaptador Termux 0.2.6

O jogo original carregou e conectou ao servidor no Realme GT3. O usuário confirmou que os testes de som e voz funcionam, e o relatório mostrou Zink/Turnip Adreno. Os ajustes de tela da 0.2.5 ainda precisam de confirmação no aparelho. Não há medição de FPS nem teste de LIVE prolongada.

O Snake Reyers é de Thiago Reyes. Este complemento usa sua cópia original e preserva os avisos e licença. Não contém o EXE, fontes ou músicas originais nem modelos de IA. Inclui uma trilha instrumental própria, CC0.

## Reparo de áudio silencioso — 0.2.6

O log atual do GT3 confirmou `All audio drivers failed, falling back to the dummy driver`, com apenas `auto_null` no PulseAudio. O jogo recebeu os WAVs e informou início/fim de fala, mas o driver Dummy não produz áudio. A confirmação de som da sessão anterior não garantia a saída da sessão seguinte.

Pare o jogo com **Ctrl+C**, aguarde o prompt e execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_SOM_V026.sh" -o "$HOME/reparar-snake-som.sh" &&
bash "$HOME/reparar-snake-som.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Esta revisão mantém o jogo e os perfis existentes e muda a preparação do áudio:

- Quando precisa criar a saída AAudio, usa a opção oficial `no_close_hack=true`, modo de desempenho normal e buffer de 80 ms. O código do módulo Termux documenta essa opção como proteção contra falhas de `AAudioStream_close()`. A causa exata do desaparecimento da saída no aparelho ainda não foi reproduzida.
- Depois dos ajustes de tela, verifica novamente a saída, abre um PCM silencioso de 0,2 s e confirma se a saída permanece presente antes de iniciar o Godot. Isso não equivale a confirmar áudio audível.
- Para o jogo local usa a saída padrão do servidor, que pode ser reencaminhada pelo PulseAudio, sem prender a sessão a um nome temporário. Uma saída de captura explicitamente configurada é preservada.
- Usa `--audio-output-latency 80` no jogo quando o teste PCM passa. Não aumenta o volume geral nem reinicia o daemon ou outros projetos.
- O painel mostra `Termux 0.2.6`, detecta o fallback Dummy no log da execução atual e informa que uma fala enfileirada ainda não confirma reprodução.

É necessário reabrir o jogo para sair do driver Dummy. O complemento não instala outra IA/voz, não apaga a fila e não cria ciclos automáticos de reinício. Guarda os arquivos anteriores em `state/launcher-backups/audio-launch-v026.*`. No teste Linux, a fala Piper foi gravada do monitor de uma saída PulseAudio real; a saída AAudio física do Android continua pendente de confirmação.

## Atualizar tela e música — 0.2.5

Pare o jogo com **Ctrl+C** e aguarde voltar ao prompt. Execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_TELA_MUSICA_V025.sh" -o "$HOME/ajustar-snake-tela-musica.sh" &&
bash "$HOME/ajustar-snake-tela-musica.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo contém a trilha e os arquivos próprios necessários. Não reinstala drivers, voz ou modelos. Guarda os arquivos anteriores em `state/launcher-backups/display-music-v025.*`.

- **Tela limpa:** oculta teclas extras e auxiliar de mouse, ativa tela cheia em retrato e configura o X11 na mesma resolução do jogo, sem esticar os personagens. Usa apenas as preferências oficiais do Termux:X11; não exige root/ADB. As barras do Android podem reaparecer durante os gestos do sistema.
- **Qualidade:** o painel mostra `Termux 0.2.5` e permite escolher Equilibrado (720×1280), Leve (640×1136) ou Mais nítido (864×1536), todos com limite de 60 FPS quando a GPU foi verificada. Para aplicar uma troca, feche e abra a janela pelos botões do painel. O perfil leve desenha cerca de 21% menos pixels que o equilibrado; isso não é uma medição de ganho de FPS.
- **Fallback:** sem GPU confirmada, mantém o limite de 30 FPS e usa 536×960, largura compatível com o arredondamento de 8 pixels do X11. Um perfil de maior qualidade não força o modo pesado na CPU.
- **Trilha:** adiciona Neon Garden, instrumental original de 76,8 segundos, apenas se a biblioteca estiver vazia. Não substitui suas músicas nem altera pausa/volume. Se você já havia desativado música, ative-a nos controles originais do painel. É possível continuar adicionando músicas próprias por MP3/OGG/WAV.

A exibição só é indicada como aplicada depois da leitura das preferências e da confirmação da resolução por `xdpyinfo`. Falha ou timeout dessa etapa não encerra o jogo. Veja `state/display-runtime.json` e `state/device-runtime.json`.

As preferências alteradas afetam o aplicativo Termux:X11 também em outras sessões. A cópia anterior fica em `state/x11-display-before-v025.json`. Com o aplicativo X11 aberto, para restaurá-las e desativar a aplicação automática:

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 &&
.venv/bin/python -m snake_termux.presentation --restore-display
```

Para reverter os arquivos do complemento, pare o servidor e copie de volta os arquivos guardados na pasta de backup indicada pelo reparo. A pasta original de Downloads e os modelos nunca foram alterados. A faixa própria adicionada pode ser removida da biblioteca; não será recolocada automaticamente depois da primeira instalação.

## Histórico: reparo de lentidão e áudio — 0.2.4

O diagnóstico recebido mostrou SM8475, Mesa llvmpipe, Freedreno sem versão instalada e somente a saída PulseAudio `auto_null`. Isso explica renderização pela CPU e uma saída silenciosa. Também havia zero faixas de música de fundo.

Pare a sessão atual com **Ctrl+C** no terminal que executa o jogo. Depois aplique:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_GPU_AUDIO_V024.sh" -o "$HOME/reparar-snake-gpu-audio.sh" &&
bash "$HOME/reparar-snake-gpu-audio.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo preserva jogo, configuração original e modelos. Instala somente os pacotes ausentes `mesa-vulkan-icd-freedreno`, `mesa-demos` e `vulkan-tools`, com as fontes assinadas principal/X11 existentes. Não faz upgrade geral nem desativa assinaturas. Guarda os arquivos próprios anteriores em `state/launcher-backups/gpu-audio-v024.*`.

No próximo início, o jogo verifica Zink/Turnip com `glxinfo`. Só indica GPU confirmada se o renderizador mencionar Adreno/Turnip/Qualcomm e não for llvmpipe/softpipe/lavapipe. Caso contrário abre um perfil de CPU reduzido e registra o motivo em `state/device-runtime.json`.

Os perfis são 720×1280 com limite de 60 FPS quando a GPU é confirmada, ou 540×960 com limite de 30 FPS e três threads llvmpipe no fallback. **São limites de configuração, não FPS medido ou garantido.** Modelos, cenário e regras originais permanecem intactos.

Para áudio, reutiliza uma saída real existente ou tenta os módulos Android oficiais `module-sles-sink` e `module-aaudio-sink`. Seleciona essa saída para o jogo e não aumenta o volume geral do celular. A configuração é verificada em cada início, sem reescrever `default.pa`.

Atualize a página do painel e use:

- **Testar som do jogo**: envia um sinal curto pelo PulseAudio; confirme se ouviu.
- **Testar fala no jogo**: envia uma frase à fila original/Piper e ao jogo.
- **Adicionar música ao jogo**: escolha um MP3, OGG/Vorbis ou WAV do celular, até 200 MB. O arquivo é guardado na pasta de música original, sem substituir faixas existentes. O complemento não inclui músicas comerciais.

O estado do teste diferencia saída disponível de som realmente ouvido. Após esse reparo, o usuário confirmou GPU no relatório e áudio audível nos testes. O teste Cloud validou a lógica, o fallback, o painel, o envio de música e a fila do jogo; não possui hardware Adreno nem OpenSL/AAudio Android.

## Janela padrão do Termux:X11

A revisão 0.2.3 abre a janela padrão do aplicativo, correspondente ao serviço iniciado sem `-tag`. Abrir com `-d main` criava outra janela e podia mostrar Not connected mesmo com Godot e o servidor funcionando.

O usuário confirmou que o jogo apareceu no GT3 ao executar, com a sessão ainda ativa:

```bash
am start --user 0 -n com.termux.x11/com.termux.x11.MainActivity
```

Para guardar essa correção no iniciador existente, sem parar a sessão atual:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_JANELA_V023.sh" -o "$HOME/reparar-snake-janela.sh" &&
bash "$HOME/reparar-snake-janela.sh"
```

Esse reparo altera apenas `start.sh` e guarda a versão anterior. Antes da 0.2.4 os logs reais do GT3 mostravam Mesa llvmpipe pela CPU. O relatório posterior confirmou Zink/Turnip Adreno; não foi medido o desempenho real.

## Correção para Godot 4.7.stable.termux

O GT3 informou `4.7.stable.termux`. A verificação anterior exigia três números e recusava essa identificação antes de iniciar o jogo. O reconhecimento agora aceita o formato sem patch da série 4.7 e diferencia versão incompatível, erro do executável e timeout.

O carregador PCK do próprio Godot não usa o número de patch para validar o pacote. A execução do jogo original foi repetida com Godot 4.7 estável, incluindo renderização e confirmação de início/fim de fala com Piper real, no Linux.

Para atualizar uma instalação existente, execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_GODOT_V022.sh" -o "$HOME/reparar-snake-godot.sh" &&
bash "$HOME/reparar-snake-godot.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Esse reparo inclui a correção X11 anterior, faz backup dos três arquivos próprios da adaptação e preserva jogo original, configurações e modelos. Não instala outro Godot.

## Correção para Termux:X11 instalado, mas não detectado

A versão 0.2 consultava `pm path` antes de iniciar. Essa consulta pode falhar no Termux mesmo com o aplicativo instalado e impedia qualquer tentativa de conexão. A 0.2.1 verifica os comandos necessários e a resposta real do serviço X11. Se o serviço falhar, mostra as últimas mensagens do log.

Se você já instalou a adaptação, aplique somente o reparo:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_X11_V021.sh" -o "$HOME/reparar-snake-x11.sh" &&
bash "$HOME/reparar-snake-x11.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo altera apenas o iniciador e guarda sua versão anterior em `state/launcher-backups`. Modelos, configuração e progresso permanecem intactos. O ZIP completo também inclui a correção.

## Primeira instalação

1. Instale o aplicativo oficial [Termux:X11](https://github.com/termux/termux-x11/releases/download/nightly/termux-x11-universal-release.apk).
2. Baixe `SNAKE_REYERS_TERMUX_0_2.zip` em Downloads e execute no Termux:

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/SNAKE_REYERS_TERMUX_0_2.zip . &&
cd ~/SNAKE_REYERS_TERMUX_0_2 &&
bash install-termux.sh &&
bash start.sh
```

O instalador procura o original no caminho já identificado no celular: `~/storage/downloads/Bluetooth/SNACK/SnakeReyers`. Se você mudou essa pasta, informe o novo caminho:

```bash
bash install-termux.sh "/caminho/da/pasta/SnakeReyers"
```

A pasta deve conter `VERSION`, `LICENSE`, `server` e `game/windows/SnakeReyers.exe`. O instalador confere o SHA-256 e cria a cópia interna em `~/SnakeReyers-Termux/original`. A pasta de Downloads permanece intacta. Uma cópia interna existente é preservada, incluindo configurações e progresso.

A instalação inicial usa internet para dependências, sem baixar novos modelos Qwen/Piper. O preparo APT mantém a verificação de assinaturas e usa temporariamente as fontes principal/X11 existentes, preservando os repositórios extras. Se uma assinatura falhar, a instalação para com o erro original.

## Iniciar novamente

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

- Jogo: aplicativo **Termux:X11**.
- Painel: **http://127.0.0.1:9393** no navegador.
- Encerrar: **Ctrl+C** na sessão do Termux.

No painel, use **Monitor TikTok** para informar o **@ do perfil ao vivo** e conectar. O monitor original requer Node >=22, Tor e acesso atual ao TikTok; suas dependências são preparadas pelo instalador.

Para a execução local, use o iniciador e o monitor. Os recursos originais de sessão/captura/RTMP para desktop continuam no código, mas **a captura e transmissão direta pelo Android não foram validadas**. Use a janela Termux:X11 com o aplicativo de transmissão de tela habitual.

## IA e voz anteriores

O iniciador reutiliza serviços prontos ou a instalação `~/.local/share/ben10-local-ai/install.json`:

- Qwen: padrão **8081**, modelo detectado por `/v1/models`, sem chave de API.
- Piper: normalmente **8083** ou **8082**, com a voz `.onnx` e o ambiente `ben10-ai` já instalados.
- O clonador não é iniciado, e serviços de outras instalações não são encerrados.

Use os botões de detectar/testar na seção Inteligência artificial do painel. O texto enviado ao Piper preserva acentos e R/L, sem substituições fonéticas específicas do XTTS. O XTTS original permanece selecionável; sua instalação no Android não foi comprovada.

Se a IA foi desativada, o iniciador respeita a configuração. Para reativar: marque Ativar respostas por IA, salve e execute em outra sessão:

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash local-ai.sh
```

Mantenha essa sessão aberta enquanto usa serviços que ela iniciou. Nenhum modelo é reinstalado silenciosamente.

## Logs e reversão

Os logs ficam em `state/logs`: `panel.log`, `game-native.log`, `x11.log`, `local-ai.log`, `qwen.log` e `piper.log`. O código de saída do painel fica em `state/launcher-exit-code.txt`; saídas observadas do jogo ficam em `state/process-events.jsonl`. O painel distingue processo gráfico ativo de ponte conectada. Não há reinício automático em ciclo.

Diagnóstico sem abrir janela:

```bash
bash start-panel.sh "$(cat state/project-path.txt)" --game --diagnose
```

O preparador guarda `server/private` e `server/config` antes dos primeiros ajustes em `state/original-private-backup`. Esse backup pode conter credenciais: mantenha-o privado.

Para reverter, pare a execução e volte a usar a pasta original em Downloads. Para desfazer só os ajustes da cópia interna, restaure `server/private/social_text_ai.json` do backup com o servidor parado. Os hooks desaparecem ao encerrar o processo; os modelos locais permanecem intactos.

Leia [TESTES.md](docs/TESTES.md), [ARQUITETURA_E_PENDENCIAS.md](docs/ARQUITETURA_E_PENDENCIAS.md) e [VALIDACAO_NATIVA.md](docs/VALIDACAO_NATIVA.md).
