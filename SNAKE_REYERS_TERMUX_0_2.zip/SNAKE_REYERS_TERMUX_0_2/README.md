# Snake Reyers 0.1.9 — adaptador Termux 0.2.2

O jogo original carregou, renderizou e conectou ao servidor em **Godot nativo 4.7 e 4.7.2 no Linux**. O iniciador Android/Termux está preparado. **A instalação no Realme GT3 e uma LIVE real ainda precisam ser validadas no aparelho.**

O Snake Reyers é de Thiago Reyes. Este complemento usa sua cópia original e preserva os avisos e licença. Não contém o EXE, fontes originais, músicas ou modelos de IA.

## Correção para Godot 4.7.stable.termux

O GT3 informou `4.7.stable.termux`. A verificação anterior exigia três números e recusava essa identificação antes de iniciar o jogo. O reconhecimento agora aceita o formato sem patch da série 4.7 e diferencia versão incompatível, erro do executável e timeout.

O carregador PCK do próprio Godot não usa o número de patch para validar o pacote. A execução do jogo original foi repetida com Godot 4.7 estável, incluindo renderização e confirmação de início/fim de fala com Piper real, no Linux.

Para atualizar uma instalação existente, execute:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_GODOT_V022.sh" -o "$HOME/reparar-snake-godot.sh" &&
bash "$HOME/reparar-snake-godot.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

Esse reparo inclui a correção X11 anterior, faz backup dos três arquivos próprios da adaptação e preserva jogo original, configurações e modelos. Não instala outro Godot.

## Correção para Termux:X11 instalado, mas não detectado

A versão 0.2 consultava `pm path` antes de iniciar. Essa consulta pode falhar no Termux mesmo com o aplicativo instalado e impedia qualquer tentativa de conexão. A 0.2.1 verifica os comandos necessários e a resposta real do serviço X11. Se o serviço falhar, mostra as últimas mensagens do log.

Se você já instalou a adaptação, aplique somente o reparo:

```bash
curl -fL "https://raw.githubusercontent.com/Elielpg/v4-ff/main/SNAKE_REYERS_REPARAR_X11_V021.sh" -o "$HOME/reparar-snake-x11.sh" &&
bash "$HOME/reparar-snake-x11.sh" &&
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

O reparo altera apenas o iniciador e guarda sua versão anterior em `state/launcher-backups`. Modelos, configuração e progresso permanecem intactos. O ZIP completo também inclui a correção.

## Primeira instalação

1. Instale o aplicativo oficial [Termux:X11](https://github.com/termux/termux-x11/releases/download/nightly/termux-x11-universal-release.apk).
2. Baixe `SNAKE_REYERS_TERMUX_0_2.zip` em Downloads e execute no Termux:

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/SNAKE_REYERS_TERMUX_0_2.zip . &&
cd ~/SNAKE_REYERS_TERMUX_0_2 &&
bash install-termux.sh &&
bash start.sh
```

O instalador procura o original no caminho já identificado no celular: `~/storage/downloads/Bluetooth/SNACK/SnakeReyers`. Se você mudou essa pasta, informe o novo caminho:

```bash
bash install-termux.sh "/caminho/da/pasta/SnakeReyers"
```

A pasta deve conter `VERSION`, `LICENSE`, `server` e `game/windows/SnakeReyers.exe`. O instalador confere o SHA-256 e cria a cópia interna em `~/SnakeReyers-Termux/original`. A pasta de Downloads permanece intacta. Uma cópia interna existente é preservada, incluindo configurações e progresso.

A instalação inicial usa internet para dependências, sem baixar novos modelos Qwen/Piper. O preparo APT mantém a verificação de assinaturas e usa temporariamente as fontes principal/X11 existentes, preservando os repositórios extras. Se uma assinatura falhar, a instalação para com o erro original.

## Iniciar novamente

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash start.sh
```

- Jogo: aplicativo **Termux:X11**.
- Painel: **http://127.0.0.1:9393** no navegador.
- Encerrar: **Ctrl+C** na sessão do Termux.

No painel, use **Monitor TikTok** para informar o **@ do perfil ao vivo** e conectar. O monitor original requer Node >=22, Tor e acesso atual ao TikTok; suas dependências são preparadas pelo instalador.

Para a execução local, use o iniciador e o monitor. Os recursos originais de sessão/captura/RTMP para desktop continuam no código, mas **a captura e transmissão direta pelo Android não foram validadas**. Use a janela Termux:X11 com o aplicativo de transmissão de tela habitual.

## IA e voz anteriores

O iniciador reutiliza serviços prontos ou a instalação `~/.local/share/ben10-local-ai/install.json`:

- Qwen: padrão **8081**, modelo detectado por `/v1/models`, sem chave de API.
- Piper: normalmente **8083** ou **8082**, com a voz `.onnx` e o ambiente `ben10-ai` já instalados.
- O clonador não é iniciado, e serviços de outras instalações não são encerrados.

Use os botões de detectar/testar na seção Inteligência artificial do painel. O texto enviado ao Piper preserva acentos e R/L, sem substituições fonéticas específicas do XTTS. O XTTS original permanece selecionável; sua instalação no Android não foi comprovada.

Se a IA foi desativada, o iniciador respeita a configuração. Para reativar: marque Ativar respostas por IA, salve e execute em outra sessão:

```bash
cd ~/SNAKE_REYERS_TERMUX_0_2 && bash local-ai.sh
```

Mantenha essa sessão aberta enquanto usa serviços que ela iniciou. Nenhum modelo é reinstalado silenciosamente.

## Logs e reversão

Os logs ficam em `state/logs`: `panel.log`, `game-native.log`, `x11.log`, `local-ai.log`, `qwen.log` e `piper.log`. O código de saída do painel fica em `state/launcher-exit-code.txt`; saídas observadas do jogo ficam em `state/process-events.jsonl`. O painel distingue processo gráfico ativo de ponte conectada. Não há reinício automático em ciclo.

Diagnóstico sem abrir janela:

```bash
bash start-panel.sh "$(cat state/project-path.txt)" --game --diagnose
```

O preparador guarda `server/private` e `server/config` antes dos primeiros ajustes em `state/original-private-backup`. Esse backup pode conter credenciais: mantenha-o privado.

Para reverter, pare a execução e volte a usar a pasta original em Downloads. Para desfazer só os ajustes da cópia interna, restaure `server/private/social_text_ai.json` do backup com o servidor parado. Os hooks desaparecem ao encerrar o processo; os modelos locais permanecem intactos.

Leia [TESTES.md](docs/TESTES.md), [ARQUITETURA_E_PENDENCIAS.md](docs/ARQUITETURA_E_PENDENCIAS.md) e [VALIDACAO_NATIVA.md](docs/VALIDACAO_NATIVA.md).
