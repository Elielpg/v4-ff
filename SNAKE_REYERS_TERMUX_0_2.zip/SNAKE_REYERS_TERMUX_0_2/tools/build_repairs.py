"""Rebuild self-contained repair payloads from the independent adapter sources."""
from pathlib import Path
import base64
import hashlib
import textwrap

root = Path(__file__).resolve().parents[1]

def refresh(path, relative, tag):
    body = path.read_text()
    marker = f'cat >"$repair_stage/{relative}" <<\'{tag}\'\n'
    begin = body.index(marker) + len(marker)
    end = body.index(tag + '\n', begin)
    path.write_text(body[:begin] + (root / relative).read_text() + body[end:])

refresh(root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh', 'snake_termux/native.py', 'SNAKE_NATIVE_V022')
refresh(root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh', 'start.sh', 'SNAKE_START_V022')
for name in ('SNAKE_REYERS_REPARAR_X11_V021.sh', 'SNAKE_REYERS_REPARAR_JANELA_V023.sh'):
    path = root / name
    content = path.read_text()
    tag = 'SNAKE_X11_LAUNCHER_V021'
    marker = f'cat >"$repair_temp" <<\'{tag}\'\n'
    begin = content.index(marker) + len(marker)
    end = content.index(tag + '\n', begin)
    path.write_text(content[:begin] + (root / 'start.sh').read_text() + content[end:])
old = root / 'SNAKE_REYERS_REPARAR_GPU_AUDIO_V024.sh'
files = ['start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py', 'snake_termux/device_runtime.py', 'snake_termux/ui.js', 'install-termux.sh']
for index, relative in enumerate(files):
    refresh(old, relative, f'SNAKE_DEVICE_V024_FILE_{index}')
# Keep the older, GPU-only repair usable when the new optional module is absent.
# Its UI checks the endpoint and hides unsupported profile controls.

body = old.read_text()
header = body[:body.index('cat >"$repair_stage/start.sh"')]
header = header.replace('gpu-audio-v024', 'display-music-v025')
extra = ['snake_termux/presentation.py', 'assets/music/Neon Garden.ogg', 'assets/music/CREDITS.md', 'snake_termux/audio_service.py', 'snake_termux/integration.py', 'snake_termux/live_tuning.py']
files += extra
array = 'repair_files=(' + ' '.join("'" + item + "'" for item in files) + ')'
start = header.index('repair_files=(')
end = header.index('\n', start)
header = header[:start] + array + header[end:]
blocks = []
for index, relative in enumerate(files):
    tag = f'SNAKE_DISPLAY_V025_FILE_{index}'
    if relative.endswith('.ogg'):
        data = (root / relative).read_bytes()
        encoded = '\n'.join(textwrap.wrap(base64.b64encode(data).decode(), 96))
        blocks.append('cat >"$repair_stage/track.b64" <<\'' + tag + "'\n" + encoded + '\n' + tag + '\n')
        blocks.append('"$repair_python" - "$repair_stage" <<\'SNAKE_DECODE_TRACK\'\n'
                      'import base64, hashlib, pathlib, sys\n'
                      'root = pathlib.Path(sys.argv[1])\n'
                      'data = base64.b64decode((root/"track.b64").read_bytes())\n'
                      'if hashlib.sha256(data).hexdigest() != ' + repr(hashlib.sha256(data).hexdigest()) + ':\n'
                      '    sys.exit("Falha de integridade na trilha instrumental.")\n'
                      '(root/"assets/music/Neon Garden.ogg").write_bytes(data)\n'
                      'SNAKE_DECODE_TRACK\n')
    else:
        blocks.append('cat >"$repair_stage/' + relative + '" <<\'' + tag + "'\n" + (root / relative).read_text() + tag + '\n')
footer = body[body.index('"$repair_python" - "$repair_stage" <<\'SNAKE_CHECK_FILES\''):]
footer = footer[:footer.index("printf 'Arquivos GPU/")]
footer = footer.replace('do mv -f -- "$repair_stage/$relative" "$repair_target/$relative"; done',
                        'do mkdir -p -- "$repair_target/$(dirname -- "$relative")"; mv -f -- "$repair_stage/$relative" "$repair_target/$relative"; done')
footer += '''printf 'Tela limpa, perfis e trilha preparados. Backup: %s\\n' "$repair_backup"
printf 'Não foram reinstalados drivers, voz ou IA. A trilha entra somente se a biblioteca estiver vazia.\\n'
printf 'Para iniciar: cd "%s" && bash start.sh\\n' "$repair_target"
'''
(root / 'SNAKE_REYERS_TELA_MUSICA_V025.sh').write_text(header + ''.join(blocks) + footer)
repair_audio = (header + ''.join(blocks) + footer).replace('display-music-v025', 'audio-launch-v026')
repair_audio = repair_audio.replace('Tela limpa, perfis e trilha preparados.', 'Preparação de áudio Android e detecção de driver Dummy atualizadas.')
(root / 'SNAKE_REYERS_REPARAR_SOM_V026.sh').write_text(repair_audio)
repair_private = repair_audio.replace('audio-launch-v026', 'private-audio-v027')
repair_private = repair_private.replace('Preparação de áudio Android e detecção de driver Dummy atualizadas.', 'Áudio privado do jogo e proteção da abertura da imagem preparados.')
(root / 'SNAKE_REYERS_RECUPERAR_IMAGEM_SOM_V027.sh').write_text(repair_private)
repair_pacing = repair_private.replace('private-audio-v027', 'live-pacing-v028')
repair_pacing = repair_pacing.replace('Áudio privado do jogo e proteção da abertura da imagem preparados.', 'Modo de resposta direta, avatares leves e perfil LIVE preparados.')
(root / 'SNAKE_REYERS_RITMO_LIVE_V028.sh').write_text(repair_pacing)
