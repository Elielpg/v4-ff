"""Compose Neon Garden, an original 76.8 s instrumental loop (100 BPM).

No samples, songs or external models are used. Python stdlib renders PCM;
FFmpeg/libvorbis encodes the distributable OGG. Run on the development machine,
not during the Android game. The composition and rendered audio are CC0-1.0.
"""
from array import array
from pathlib import Path
import math
import random
import subprocess
import sys
import tempfile
import wave

RATE, BPM, BARS = 32000, 100, 32
BEAT = 60 / BPM
LENGTH = int(BARS * 4 * BEAT * RATE)


def render(path):
    left, right = array('f', [0]) * LENGTH, array('f', [0]) * LENGTH
    rng = random.Random(25019)

    def add(start, duration, sound, gain, pan=0):
        offset = int(start * RATE)
        for index in range(int(duration * RATE)):
            position = (offset + index) % LENGTH  # Wrap tails for a seamless loop.
            value = sound(index / RATE) * gain
            left[position] += value * math.sqrt((1 - pan) / 2)
            right[position] += value * math.sqrt((1 + pan) / 2)

    def frequency(midi):
        return 440 * 2 ** ((midi - 69) / 12)

    progression = [(45, 57, 60, 64), (41, 57, 60, 65), (48, 55, 60, 64), (43, 55, 59, 62)]
    melody = [76, None, 72, 74, 76, 79, 76, 72, 69, None, 72, 76, 74, 72, 67, None]
    for bar in range(BARS):
        start = bar * 4 * BEAT
        chord = progression[(bar // 2) % 4]
        for beat in range(4):
            when = start + beat * BEAT
            add(when, .32, lambda t: math.sin(2 * math.pi * (48 * t + 3.8 * (1 - math.exp(-26 * t)))) * math.exp(-14 * t), .32)
            bass = frequency(chord[0])
            add(when + .5 * BEAT, .29, lambda t, f=bass: (math.sin(2 * math.pi * f * t) + .16 * math.sin(4 * math.pi * f * t)) * min(1, t / .008) * math.exp(-10 * t), .18)
            if beat in (1, 3):
                noise = [rng.uniform(-1, 1) for _ in range(int(RATE * .17))]
                add(when, .17, lambda t, noise=noise: (noise[min(int(t * RATE), len(noise)-1)] * .75 + math.sin(2 * math.pi * 185 * t) * .25) * math.exp(-35 * t), .12)
            for half in range(2):
                noise = [rng.uniform(-1, 1) for _ in range(int(RATE * .05))]
                add(when + half * BEAT / 2, .05, lambda t, noise=noise: noise[min(int(t * RATE), len(noise)-1)] * math.exp(-90 * t), .045, .3 if half else -.3)
        # Soft chord stabs and sparse melodic replies leave space for game speech.
        for note in chord[1:]:
            f = frequency(note)
            add(start, 2.2, lambda t, f=f: (math.sin(2 * math.pi * f * t) + .12 * math.sin(4 * math.pi * f * t)) * min(1, t / .18) * math.exp(-1.6 * t), .035, -.2)
        if bar % 8 >= 2:
            for step in range(4):
                midi = melody[((bar % 4) * 4 + step) % len(melody)]
                if midi is None:
                    continue
                f = frequency(midi)
                t0 = start + step * BEAT + .12
                pluck = lambda t, f=f: (math.sin(2 * math.pi * f * t) + .23 * math.sin(2 * math.pi * f * 2 * t)) * min(1, t / .012) * math.exp(-7.5 * t)
                add(t0, .75, pluck, .075, .15)
                add(t0 + .45, .75, pluck, .020, -.45)
    # Gentle fixed limiter, normalized to a moderate -3 dB peak.
    peak = max(max(abs(x) for x in left), max(abs(x) for x in right))
    pcm = array('h')
    for lval, rval in zip(left, right):
        pcm.extend((int(lval / peak * 23150), int(rval / peak * 23150)))
    if sys.byteorder != 'little':
        pcm.byteswap()
    with wave.open(str(path), 'wb') as stream:
        stream.setnchannels(2)
        stream.setsampwidth(2)
        stream.setframerate(RATE)
        stream.writeframes(pcm.tobytes())


if __name__ == '__main__':
    target = Path(__file__).resolve().parents[1] / 'assets/music/Neon Garden.ogg'
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as directory:
        raw = Path(directory) / 'neon-garden.wav'
        render(raw)
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', str(raw),
                        '-c:a', 'libvorbis', '-q:a', '3', '-metadata', 'title=Neon Garden',
                        '-metadata', 'comment=Original procedural composition; CC0-1.0; 100 BPM',
                        str(target)], check=True)
    print(target)
