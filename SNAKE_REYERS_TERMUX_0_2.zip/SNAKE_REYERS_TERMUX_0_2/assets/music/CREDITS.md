# Neon Garden

Trilha instrumental original criada proceduralmente para esta adaptação.
100 BPM, 76,8 segundos, estéreo, OGG/Vorbis, sem voz e sem samples externos.
Composição, código de síntese e gravação disponibilizados sob **CC0-1.0**:
https://creativecommons.org/publicdomain/zero/1.0/

Fonte reproduzível: `tools/create_music.py`. A codificação Vorbis pode variar
conforme a versão do FFmpeg; o hash da gravação distribuída é conferido pelo
adaptador. A trilha não pertence ao pacote original do Snake Reyers.

Só é adicionada quando a biblioteca está vazia, uma única vez por instalação.
Arquivos existentes, seleção de música, pausa e volume não são substituídos.
