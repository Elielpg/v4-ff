from __future__ import annotations

import argparse
import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

from .client import valid_port


def configure_source(value: str) -> Path:
    root = Path(value).expanduser().resolve()
    source = root / 'server' / 'src'
    if not (source / 'cobrinha_server' / 'main.py').is_file():
        raise ValueError('Não encontrei server/src/cobrinha_server/main.py na pasta original informada.')
    version = (root / 'VERSION').read_text(encoding='utf-8').strip()
    if version.removeprefix('v') != '0.1.9':
        raise ValueError('Este adaptador foi conferido com Snake Reyers 0.1.9. Versão encontrada: ' + version)
    os.environ['COBRINHA_SERVER_DIR'] = str(root / 'server')
    sys.path.insert(0, str(source))
    return root


def main():
    parser = argparse.ArgumentParser(description='Adaptador local independente para Snake Reyers 0.1.9')
    parser.add_argument('--project', required=True, help='Pasta original contendo server, game e VERSION')
    parser.add_argument('--port', type=valid_port, default=9393)
    parser.add_argument('--diagnose', action='store_true', help='Testa serviços locais; não abre o jogo')
    parser.add_argument('--game', action='store_true', help='Conecta o jogo original ao Godot nativo e inicia a janela')
    parser.add_argument('--godot', help='Caminho opcional do Godot 4.7.2 nativo')
    parser.add_argument('--reuse-ai', action='store_true', help='Reutiliza a instalação Qwen/Piper existente sem baixar modelos')
    args = parser.parse_args()
    try:
        root = configure_source(args.project)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    from .integration import install
    original = importlib.import_module('cobrinha_server.main')
    binding = install(original.app)
    native = None
    if args.game:
        from .native import NativeGame, attach
        try:
            native = NativeGame(root, godot=args.godot, port=args.port)
            attach(binding, original.app, native, auto_start=not args.diagnose)
        except (ValueError, OSError) as exc:
            parser.error(str(exc))
    if args.diagnose:
        print(json.dumps({'project': str(root), 'text': binding.local_client().health(), 'voice': binding.local_voice().health(),
                          'graphics': native.status() if native else 'Modo apenas painel. Use --game para carregar o jogo no Godot nativo.'}, ensure_ascii=False, indent=2))
        return
    if args.reuse_ai:
        state = Path(__file__).resolve().parents[1] / 'state'
        (state / 'logs').mkdir(parents=True, exist_ok=True)
        service = {'process': None, 'log': None}

        def start_ai():
            service['log'] = (state / 'logs/local-ai.log').open('ab', buffering=0)
            service['process'] = subprocess.Popen([sys.executable, '-m', 'snake_termux.reuse_ai', '--port', str(args.port), '--state', str(state)], stdout=service['log'], stderr=subprocess.STDOUT)

        def stop_ai():
            process = service['process']
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            if service['log']:
                service['log'].close()
        original.app.add_event_handler('startup', start_ai)
        original.app.add_event_handler('shutdown', stop_ai)

        @original.app.get('/termux/services')
        def local_services_status():
            try:
                return json.loads((state / 'ai-services.json').read_text())
            except (OSError, ValueError):
                return {'state': 'starting'}
    import uvicorn
    print(f'Painel adaptado: http://127.0.0.1:{args.port} — Ctrl+C para parar.', flush=True)
    print('Jogo original via Godot nativo ativado.' if native else 'Modo apenas painel; o jogo gráfico não foi iniciado.', flush=True)
    uvicorn.run(original.app, host='127.0.0.1', port=args.port, loop='asyncio', http='h11', ws='wsproto')


if __name__ == '__main__':
    main()
