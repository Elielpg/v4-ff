from __future__ import annotations

import io
import json
import re
import threading
import unicodedata
import urllib.error
import urllib.request
import uuid
import wave
from pathlib import Path

from .client import LocalServiceError, loopback_opener, valid_port


def voice_chunks(text: str, max_chars: int = 150) -> list[str]:
    # Preserve Brazilian spelling, R/L and punctuation. XTTS-specific phonetic
    # substitutions from the original application do not suit Piper.
    text = re.sub(r'\s+', ' ', unicodedata.normalize('NFC', str(text))).strip()
    if len(text) > 2000:
        raise ValueError('Fala longa demais; use até 2000 caracteres.')
    limit = max(30, min(150, int(max_chars)))
    chunks, current = [], ''
    for word in text.split():
        if len(word) > limit:
            if current:
                chunks.append(current)
                current = ''
            chunks.extend(word[i:i + limit] for i in range(0, len(word), limit))
        elif len(current) + len(word) + bool(current) > limit:
            chunks.append(current)
            current = word
        else:
            current += (' ' if current else '') + word
    if current:
        chunks.append(current)
    return chunks


class PiperClient:
    def __init__(self, port: int):
        self.port = valid_port(port)
        self.base = f'http://127.0.0.1:{self.port}'
        self.opener = loopback_opener()
        self.lock = threading.Lock()
        self.ready = False

    def health(self) -> dict:
        try:
            with self.opener.open(self.base + '/health', timeout=2) as response:
                data = json.loads(response.read(8192))
            # Avoid accidentally selecting the much slower cloning service
            # merely because it happens to occupy the old voice port.
            model = str(data.get('model') or '')
            self.ready = data.get('ready') is True and 'piper' in model.lower()
            return {'ready': self.ready, 'port': self.port, 'model': model,
                    'message': 'Piper local disponível.' if self.ready else 'Esta porta não anunciou um Piper pronto. Confira 8082 ou 8083.'}
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            self.ready = False
            return {'ready': False, 'port': self.port, 'message': 'Piper local indisponível. Inicie o serviço de voz já instalado.'}

    def wav(self, text: str) -> bytes:
        if not self.ready and not self.health()['ready']:
            raise LocalServiceError('Piper local indisponível; confira a porta da voz no painel.')
        request = urllib.request.Request(self.base + '/synthesize', data=json.dumps({'text': text}, ensure_ascii=False).encode(), headers={'Content-Type': 'application/json'})
        if not self.lock.acquire(timeout=2):
            raise LocalServiceError('A voz local está ocupada. Aguarde a fala atual.')
        try:
            try:
                with self.opener.open(request, timeout=25) as response:
                    raw = response.read(8_000_001)
            except urllib.error.HTTPError as exc:
                raise LocalServiceError(f'Piper respondeu HTTP {exc.code}.') from exc
            except OSError as exc:
                self.ready = False
                raise LocalServiceError('Piper não respondeu dentro do prazo.') from exc
            if len(raw) > 8_000_000 or raw[:4] != b'RIFF' or raw[8:12] != b'WAVE':
                raise LocalServiceError('A voz local não devolveu um WAV válido.')
            try:
                with wave.open(io.BytesIO(raw), 'rb') as reader:
                    frames = reader.getnframes()
                    if not 8000 <= reader.getframerate() <= 96000 or reader.getnchannels() not in (1, 2) or not 0 < frames <= reader.getframerate() * 60:
                        raise ValueError('Parâmetros de áudio inválidos.')
                    actual = reader.readframes(frames)
                    if len(actual) != frames * reader.getnchannels() * reader.getsampwidth():
                        raise ValueError('Áudio truncado.')
            except (wave.Error, EOFError, ValueError) as exc:
                raise LocalServiceError('A voz local devolveu um WAV incompleto ou incompatível.') from exc
            return raw
        finally:
            self.lock.release()

    def synthesize(self, text: str, output_dir: Path) -> dict:
        return prepare_speech(text, output_dir, self.wav, 'piper-local')


def prepare_speech(text: str, output_dir: Path, make_wav, provider: str) -> dict:
    from cobrinha_server.services.audio_timeline import build_audio_timeline_payload, write_audio_timeline_json
    chunks = voice_chunks(text)
    if not chunks:
        raise ValueError('Texto vazio para síntese.')
    buffers, params = [], None
    for chunk in chunks:
        with wave.open(io.BytesIO(make_wav(chunk)), 'rb') as reader:
            current = reader.getparams()
            signature = (current.nchannels, current.sampwidth, current.framerate, current.comptype)
            if params and signature != (params.nchannels, params.sampwidth, params.framerate, params.comptype):
                raise LocalServiceError('Piper mudou o formato do áudio durante a fala.')
            params = current
            buffers.append(reader.readframes(reader.getnframes()))
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f'speech_{uuid.uuid4().hex}.wav'
    temporary = output.with_suffix('.part')
    timeline = output.with_suffix('.json')
    try:
        with wave.open(str(temporary), 'wb') as writer:
            writer.setparams(params)
            writer.writeframes(b''.join(buffers))
        temporary.replace(output)
        segments = write_audio_timeline_json(output, timeline)
        return {'audio_path': str(output.resolve()), 'timeline_path': str(timeline.resolve()),
                'timeline': build_audio_timeline_payload(output, segments), 'voice_path': '', 'chunks': chunks,
                'voice_provider': provider}
    except Exception:
        temporary.unlink(missing_ok=True)
        output.unlink(missing_ok=True)
        timeline.unlink(missing_ok=True)
        raise
