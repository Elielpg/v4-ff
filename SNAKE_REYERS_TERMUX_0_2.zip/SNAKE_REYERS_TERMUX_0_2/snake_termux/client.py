from __future__ import annotations

import json
import re
import threading
import time
import urllib.error
import urllib.request


def valid_port(value: object) -> int:
    if isinstance(value, bool):
        raise ValueError('Porta local inválida.')
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError('Porta local inválida.') from exc
    if str(value).strip() != str(port) or not 1024 <= port <= 65535:
        raise ValueError('Use uma porta local entre 1024 e 65535.')
    return port


def valid_model(value: object) -> str:
    model = str(value or 'auto').strip()
    if not re.fullmatch(r'[A-Za-z0-9_./:-]{1,240}', model):
        raise ValueError('Nome de modelo local inválido.')
    return model


class LocalServiceError(RuntimeError):
    pass


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def loopback_opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirects())


class LocalQwen:
    def __init__(self, port: int = 8081):
        self.port = valid_port(port)
        self.base = f'http://127.0.0.1:{self.port}'
        # This opener is limited to a fixed loopback host and does not send local
        # conversation requests through any environment-configured outbound proxy.
        self.opener = loopback_opener()
        self.lock = threading.RLock()
        self.model_ids: list[str] = []
        self.models_at = 0.0
        self.diagnostics = {'ready': None, 'requests': 0, 'answered': 0, 'failed': 0, 'last_error': None, 'latency_ms': None, 'selected_model': None}

    def _json(self, path: str, payload: dict | None = None, timeout: float = 2.0) -> dict:
        if path not in {'/v1/models', '/v1/chat/completions'}:
            raise ValueError('Rota local inválida.')
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(self.base + path, data=data, headers={'Content-Type': 'application/json'}, method='GET' if payload is None else 'POST')
        try:
            with self.opener.open(request, timeout=timeout) as response:
                body = response.read(1_000_001)
                if len(body) > 1_000_000:
                    raise LocalServiceError('Resposta do serviço local excedeu o limite.')
            value = json.loads(body)
            if not isinstance(value, dict):
                raise LocalServiceError('Resposta inválida do serviço local.')
            return value
        except urllib.error.HTTPError as exc:
            raise LocalServiceError(f'Serviço local respondeu HTTP {exc.code}. Confira a porta e o serviço Qwen.') from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise LocalServiceError('Qwen local indisponível ou demorou demais. Inicie a IA local e confira a porta.') from exc
        except (ValueError, UnicodeDecodeError) as exc:
            raise LocalServiceError('O serviço nesta porta não devolveu uma resposta JSON válida.') from exc

    def models(self, *, refresh: bool = False) -> list[str]:
        with self.lock:
            if not refresh and self.model_ids and time.monotonic() - self.models_at < 30:
                return list(self.model_ids)
            data = self._json('/v1/models')
            if not isinstance(data.get('data'), list):
                raise LocalServiceError('Catálogo de modelos locais inválido.')
            ids = []
            for item in data.get('data', []):
                if not isinstance(item, dict):
                    continue
                try:
                    model = valid_model(item.get('id'))
                except ValueError:
                    continue
                if model != 'auto' and model not in ids:
                    ids.append(model)
            if not ids:
                raise LocalServiceError('Nenhum modelo local foi anunciado em /v1/models.')
            self.model_ids, self.models_at = ids, time.monotonic()
            return list(ids)

    def health(self) -> dict:
        try:
            ids = self.models(refresh=True)
            self.diagnostics.update(ready=True, last_error=None)
            return {'ready': True, 'port': self.port, 'models': ids}
        except (LocalServiceError, TypeError) as exc:
            self.diagnostics.update(ready=False, last_error=str(exc))
            return {'ready': False, 'port': self.port, 'models': [], 'message': str(exc)}

    def reply(self, request_data: dict, *, identity: str) -> str:
        self.diagnostics['requests'] += 1
        started = time.monotonic()
        try:
            model = valid_model(request_data.get('model'))
            if model == 'auto':
                model = self.models()[0]
            timeout = max(2.0, min(30.0, float(request_data.get('timeout') or 18)))
            max_chars = max(60, min(170, int(request_data.get('max_chars') or 150)))
            payload = {'model': model, 'messages': [{'role': 'system', 'content': identity + '\nResponda diretamente, em uma ou duas frases curtas. Não inclua raciocínio, rubricas ou instruções de voz. Você apenas conversa; não executa comandos do sistema.'}, {'role': 'user', 'content': str(request_data.get('prompt') or '')}], 'max_tokens': min(160, max(60, max_chars // 2 + 35)), 'temperature': 0.55, 'stream': False, 'chat_template_kwargs': {'enable_thinking': False}}
            data = self._json('/v1/chat/completions', payload, timeout)
            try:
                text = data['choices'][0]['message']['content']
            except (KeyError, IndexError, TypeError) as exc:
                raise LocalServiceError('Qwen local não devolveu uma resposta de conversa válida.') from exc
            if not isinstance(text, str):
                raise LocalServiceError('Qwen local não devolveu texto.')
            text = re.sub(r'<think>.*?</think>', '', text, flags=re.I | re.S).strip()
            if not text or '<think>' in text.casefold():
                raise LocalServiceError('Qwen local não devolveu uma resposta final.')
            self.diagnostics.update(ready=True, last_error=None, selected_model=model)
            self.diagnostics['answered'] += 1
            return text
        except (LocalServiceError, ValueError, TypeError) as exc:
            self.diagnostics['failed'] += 1
            self.diagnostics.update(ready=False, last_error=str(exc))
            raise
        finally:
            self.diagnostics['latency_ms'] = round((time.monotonic() - started) * 1000)
