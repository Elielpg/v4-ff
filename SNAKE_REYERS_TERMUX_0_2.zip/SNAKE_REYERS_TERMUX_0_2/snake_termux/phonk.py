"""Reversible PHONK theme controls. Never captures microphone or Android app audio."""
from __future__ import annotations
import copy
import json
import re
import threading
import time
from pathlib import Path

from .device_runtime import atomic_json

DEFAULTS={'enabled':False,'base_color':'#08050f','palette':['#9c2cff','#d653ff','#6333ed'],
          'intensity':.60,'sensitivity':1.0,'pulses':True,'source':'music','manual_bpm':140,
          'color_mode':'beat','color_every':1,'track_palettes':{}}
LOCK=threading.RLock()
SCRIPT=Path(__file__).resolve().parent/'godot/phonk_scene.gd'


def available():
    return all(SCRIPT.with_name(name).is_file() for name in
               ('phonk_scene.gd','phonk_runtime.gd','phonk_beat.gd','phonk_skin.gdshader'))


def _read(state):
    try:
        path=Path(state)/'phonk-config.json'
        if path.stat().st_size>65536:return {}
        value=json.loads(path.read_text())
    except (OSError,ValueError):value={}
    return value if isinstance(value,dict) else {}


def color(value):
    if not isinstance(value,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',value):raise ValueError('Use cores no formato #RRGGBB.')
    return value.lower()


def palette(value):
    if not isinstance(value,list) or not 2<=len(value)<=6:raise ValueError('Escolha de duas a seis cores.')
    return [color(x) for x in value]


def validate(payload):
    if not isinstance(payload,dict) or not payload or set(payload)-set(DEFAULTS):raise ValueError('Controle PHONK desconhecido.')
    clean={}
    for key,value in payload.items():
        if key in ('enabled','pulses'):
            if type(value) is not bool:raise ValueError('Ative ou desative o controle.')
            clean[key]=value
        elif key=='base_color':clean[key]=color(value)
        elif key=='palette':clean[key]=palette(value)
        elif key in ('intensity','sensitivity'):
            minimum,maximum=(0.,1.) if key=='intensity' else (.3,2.)
            if type(value) not in (int,float) or not minimum<=value<=maximum:raise ValueError('Intensidade ou sensibilidade fora do intervalo.')
            clean[key]=float(value)
        elif key in ('manual_bpm','color_every'):
            lo,hi=(40,300) if key=='manual_bpm' else (1,16)
            if type(value) is not int or not lo<=value<=hi:raise ValueError('Ritmo fora do intervalo permitido.')
            clean[key]=value
        elif key in ('source','color_mode'):
            choices=('music','manual') if key=='source' else ('beat','track','fixed')
            if not isinstance(value,str) or value not in choices:raise ValueError('Modo PHONK inválido.')
            clean[key]=value
        elif key=='track_palettes':
            if not isinstance(value,dict) or len(value)>64:raise ValueError('Limite de 64 paletas por música.')
            records={}
            for track,colors in value.items():
                if not isinstance(track,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',track):raise ValueError('Identificador de música inválido.')
                records[track]=palette(colors)
            clean[key]=records
    return clean


def settings(state):
    raw=_read(state);result=copy.deepcopy(DEFAULTS)
    for key in DEFAULTS:
        if key in raw:
            try:result.update(validate({key:raw[key]}))
            except ValueError:pass
    return result


def save(state,payload,*,sync=False):
    values=validate(payload)
    with LOCK:
        raw={**_read(state),**values}
        if sync or ('source' in values and values['source']=='manual'):
            raw['manual_epoch']=time.time()
        previous=raw.get('revision',0)
        raw['revision']=(previous if type(previous) is int else 0)+1
        atomic_json(Path(state)/'phonk-config.json',raw)
    return settings(state)


def refresh(state,library,log_path):
    tracks={}
    if library is not None:
        for key,row in list(library.inventory().items())[:128]:
            playable=row.get('playable') or row.get('source')
            if playable:tracks[Path(playable).name]={'id':key,'title':row.get('title',Path(playable).stem)}
    with LOCK:
        raw=_read(state);value={'tracks':tracks,'native_log':str(log_path)}
        if raw.get('runtime')!=value:
            raw['runtime']=value
            atomic_json(Path(state)/'phonk-config.json',raw)


def launch(env,state):
    state=Path(state).resolve()
    (state/'phonk-runtime.json').unlink(missing_ok=True)
    return {**env,'SNAKE_PHONK_CONFIG':str(state/'phonk-config.json'),
            'SNAKE_PHONK_STATUS':str(state/'phonk-runtime.json')}


def status(state):
    runtime=None
    try:
        path=Path(state)/'phonk-runtime.json'
        if path.stat().st_size<32768:
            value=json.loads(path.read_text())
            if isinstance(value,dict):runtime=value
    except (OSError,ValueError):pass
    raw=_read(state)
    return {'settings':settings(state),'runtime':runtime,'available':available(),
            'runtime_age_seconds':round(max(0,time.time()-runtime.get('at',0)),1) if runtime else None,
            'tracks':list(raw.get('runtime',{}).get('tracks',{}).values()),
            'note':'Música analisa somente o bus Music do jogo. Manual usa o BPM informado; não escuta GreenTube, microfone ou outros apps.',
            'original_game_credit':'Snake Reyers — Thiago Reyes'}


def install(app,native,binding):
    from fastapi import HTTPException
    library=getattr(app.state,'snake_music_library',None)
    refresh(native.state_dir,library,native.log_path)
    binding.phonk_settings=lambda:settings(native.state_dir)
    if library is not None:
        old_broadcast=library.broadcast
        async def broadcast():
            refresh(native.state_dir,library,native.log_path)
            return await old_broadcast()
        library.broadcast=broadcast
        if hasattr(binding,'replacements'):binding.replacements.append((library,'broadcast',old_broadcast))

    @app.get('/termux/phonk')
    def read():
        refresh(native.state_dir,library,native.log_path)
        return status(native.state_dir)

    @app.post('/termux/phonk')
    def write(payload:dict):
        try:save(native.state_dir,payload)
        except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
        return status(native.state_dir)

    @app.post('/termux/phonk/sync')
    def sync(payload:dict):
        if set(payload)!={'manual_bpm'}:raise HTTPException(status_code=400,detail='Informe somente o BPM manual.')
        try:save(native.state_dir,{**payload,'source':'manual'},sync=True)
        except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
        return status(native.state_dir)
