"""Bounded one-job lookahead and current-chat selection; original game actions stay in use."""
from __future__ import annotations

import contextvars
import os
import re
import time

from .speech_names import normalize_text, spoken_name

_CONTEXT = contextvars.ContextVar('snake_live_prefetch', default=None)


def install(binding, app):
    from fastapi import HTTPException
    from cobrinha_server.services import event_decision_worker as worker, live_events, speech_queue
    from cobrinha_server.bridge.godot_bridge import godot_bridge

    original_transport = binding.transport if hasattr(binding, 'transport') else None
    original_gate = worker._speech_pipeline_can_accept_next
    original_once = worker.process_once
    original_activity = worker._send_spectator_activity
    original_enqueue = worker.enqueue_text
    original_prepare = speech_queue.prepare_pending_job
    original_sort = live_events._sort_events
    original_dedup = live_events._prune_comment_dedup
    original_pop = live_events.pop_next_event
    original_send = godot_bridge.send
    metrics = {'prefetched': 0, 'expired_comments': 0, 'welcome_speech_coalesced': 0, 'spoken_names_cleaned': 0, 'dedup_entries_trimmed': 0, 'unavailable_notices_coalesced': 0}
    last_welcome = [0.0]
    last_unavailable = [0.0]

    def transport(data):
        try:
            return original_transport(data)
        except Exception:
            record = _CONTEXT.get()
            if record is not None: record['model_failed'] = True
            raise

    if original_transport is not None:
        binding.transport = transport

    def settings():
        raw = binding.settings._raw()
        return {'busy_live': raw.get('termux_busy_live', True) is True}

    def busy():
        return settings()['busy_live']

    def gate():
        if not busy() or binding.settings._raw().get('termux_reply_mode') == 'dialogue':
            return original_gate()
        if worker.song_runtime.singing_blocks_speech() or worker.godot_runtime_state.heart_me_band_music_showcase_active():
            return False
        state = worker.speech_queue_status()
        if state.get('manual_sequence', {}).get('active') or state.get('active_pair') or state.get('pair_waiting_size'):
            return False
        if state.get('pending_size') or state.get('ready_size'):
            return False
        if worker.tts_worker_status().get('state') == 'preparing':
            return False
        if state.get('active'):
            with live_events._LOCK:
                events = live_events._read_state()
            # Don't prepare welcome chatter into the one slot reserved for a question/gift.
            return bool(events.get('comments') or events.get('gifts'))
        return True

    async def once():
        record = {}
        token = _CONTEXT.set(record)
        try:
            return await original_once()
        finally:
            _CONTEXT.reset(token)

    async def activity(event, *, source):
        record = _CONTEXT.get()
        if busy() and record is not None and source == 'social_comment' and speech_queue.active_job():
            avatar = await worker._cache_avatar_for_event(event)
            message = worker.spectator_user_message({
                'user_id': event.get('user_id'), 'username': event.get('username'),
                'display_name': event.get('display_name'), 'avatar_url': event.get('avatar_url') or event.get('profile_image'),
                'comment': event.get('text')}, avatar_path=avatar, source=source, preview=False)
            message.setdefault('payload', {}).update(snake_color=worker._snake_color_for_user(worker._event_user_key(event)), slot_limit=16, activity_kind='comment')
            record['deferred'] = message
            return avatar
        return await original_activity(event, source=source)

    async def send(message):
        if isinstance(message, dict) and message.get('type') == 'speech_ready':
            payload = dict(message.get('payload') or {})
            metadata = dict(payload.get('metadata') or {})
            deferred = metadata.pop('_termux_deferred_spectator', None)
            if deferred:
                await original_send(deferred)
                message = {**message, 'payload': {**payload, 'metadata': metadata}}
        return await original_send(message)

    def enqueue(text, **kwargs):
        metadata = dict(kwargs.get('metadata') or {})
        record = _CONTEXT.get()
        event = record.get('event') if record else None
        if event and event.get('kind') == 'system':
            # Original system jobs omit identity fields; keep them for speech normalization.
            metadata.update({key: event[key] for key in ('display_name', 'username', 'user_id') if event.get(key)})
        if record and record.get('model_failed') and metadata.get('source') == 'social_comment':
            if time.monotonic() - last_unavailable[0] < 20:
                metrics['unavailable_notices_coalesced'] += 1
                return {'id': '', 'suppressed': True, 'reason': 'model_unavailable_notice_coalesced'}
            last_unavailable[0] = time.monotonic()
            text = str(metadata.get('display_name') or 'Pessoal') + ', não consegui responder agora. Tenta de novo daqui a pouco?'
        welcome = metadata.get('source') in ('welcome', 'tiktok_member') or (metadata.get('audio_role') == 'system' and re.match(r'(?i)^bem[ -]vind', str(text)))
        if busy() and welcome:
            if time.monotonic() - last_welcome[0] < 20:
                metrics['welcome_speech_coalesced'] += 1
                return {'id': '', 'suppressed': True, 'reason': 'welcome_speech_coalesced'}
            last_welcome[0] = time.monotonic()
            text = 'Bem-vindos, pessoal! Manda sua pergunta pra cobra!'
        if record and record.get('deferred') and kwargs.get('actor', 'main') == 'main':
            metadata['_termux_deferred_spectator'] = record['deferred']
            metrics['prefetched'] += 1
        return original_enqueue(text, **{**kwargs, 'metadata': metadata})

    def sort_events(events):
        result = original_sort(events)
        if busy() and result and all(event.get('kind') == 'comment' for event in result):
            now = time.time()
            recent = [event for event in result if not live_events._event_created_at(event) or now - live_events._event_created_at(event) <= 18]
            metrics['expired_comments'] += len(result) - len(recent)
            def question(event):
                text = str(event.get('text') or '').casefold().strip()
                return '?' in text or bool(re.match(r'^(como|qual|quem|onde|quando|por que|porque|quanto|me explica|voce|você)\b', text))
            return sorted(recent, key=lambda e: (-int(e.get('priority') or 0), -int(question(e)), -live_events._event_created_at(e)))
        return result

    def dedup(history, now):
        result = original_dedup(history, now)
        if busy() and len(result) > 512:
            recent = sorted(result.items(), key=lambda pair: float(pair[1].get('created_at') or 0), reverse=True)[:512]
            metrics['dedup_entries_trimmed'] += len(result) - 512
            return dict(recent)
        return result

    def pop():
        event = original_pop()
        record = _CONTEXT.get()
        if record is not None and event: record['event'] = event
        return event

    def prepare(job):
        metadata = job.get('metadata') or {}
        spoken = normalize_text(job.get('text'), metadata, binding.settings._raw().get('termux_spoken_aliases', {}))
        if spoken != job.get('text'): metrics['spoken_names_cleaned'] += 1
        prepared = original_prepare({**job, 'text': spoken})
        return {**prepared, 'text': job.get('text', ''), 'spoken_text': spoken}

    for original, replacement in ((original_gate, gate), (original_once, once), (original_activity, activity),
            (original_enqueue, enqueue), (original_prepare, prepare), (original_sort, sort_events), (original_dedup, dedup), (original_pop, pop)):
        binding.replace_aliases(original, replacement)
    binding.replacements.append((godot_bridge, 'send', original_send))
    godot_bridge.send = send

    @app.get('/termux/live-load')
    def status():
        return {'settings': settings(), 'metrics': dict(metrics), 'lookahead_limit': 1,
                'note': 'Prioriza perguntas recentes. Uma única voz não consegue ler todos os eventos de uma LIVE grande.'}

    @app.post('/termux/live-load')
    def save(payload: dict):
        if set(payload) != {'busy_live'} or type(payload['busy_live']) is not bool:
            raise HTTPException(status_code=400, detail='Informe busy_live como verdadeiro ou falso.')
        raw = binding.settings._raw(); raw['termux_busy_live'] = payload['busy_live']
        binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
        os.chmod(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)
        return status()

    @app.post('/termux/spoken-name')
    def name(payload: dict):
        original = str(payload.get('name') or '').strip()
        if len(original) > 100: raise HTTPException(status_code=400, detail='Use um nome de até 100 caracteres.')
        if 'alias' in payload:
            username = str(payload.get('username') or '').strip().lstrip('@').casefold()
            if not re.fullmatch(r'[a-z0-9_.]{1,64}', username):
                raise HTTPException(status_code=400, detail='Informe o @ do usuário, sem espaços.')
            alias = spoken_name(payload.get('alias'))
            raw = binding.settings._raw(); aliases = dict(raw.get('termux_spoken_aliases', {}))
            if len(aliases) >= 200 and username not in aliases:
                raise HTTPException(status_code=400, detail='Limite de 200 pronúncias personalizadas atingido.')
            aliases[username] = alias; raw['termux_spoken_aliases'] = aliases
            binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
            os.chmod(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)
            return {'original': original, 'spoken': alias, 'saved': True}
        return {'original': original, 'spoken': spoken_name(original)}
