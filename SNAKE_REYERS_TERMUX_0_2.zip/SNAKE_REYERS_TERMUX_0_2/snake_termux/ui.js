(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const status = byId('openaiStatus');
  const key = byId('openaiApiKey');
  if (!status || !key) return;
  status.closest('section').classList.add('termux-ai-card');
  const styles = document.createElement('style');
  styles.textContent = '.termux-ai-card,.termux-ai-card *{box-sizing:border-box}.termux-ai-card input,.termux-ai-card select,.termux-ai-card audio{max-width:100%}.termux-ai-card fieldset{min-width:0;padding:12px;margin:16px 0 0}.termux-ai-card audio{display:block;margin-top:10px;width:100%}.termux-ai-card button{white-space:normal}';
  document.head.append(styles);
  key.hidden = true;
  key.style.setProperty('display', 'none', 'important');
  key.disabled = true;
  key.value = '';
  const keyLabel = document.querySelector('label[for="openaiApiKey"]');
  if (keyLabel) {keyLabel.hidden = true; keyLabel.style.setProperty('display', 'none', 'important');}
  const portLabel = document.createElement('label');
  portLabel.htmlFor = 'termuxQwenPort';
  portLabel.textContent = 'Porta do Qwen local';
  const port = document.createElement('input');
  port.id = 'termuxQwenPort'; port.type = 'number'; port.min = '1024'; port.max = '65535'; port.value = '8081';
  key.after(portLabel, port);
  byId('openaiModel').placeholder = 'auto · detectar o modelo já instalado';
  const note = document.createElement('p');
  note.textContent = 'Qwen local no Termux. Use auto para detectar o modelo. Não precisa de chave de API.';
  status.parentElement.prepend(note);

  window.renderOpenAISettings = function (settings) {
    if (document.activeElement !== byId('openaiModel')) byId('openaiModel').value = settings.model || 'auto';
    if (document.activeElement !== port) port.value = settings.local_port || 8081;
    byId('openaiEnabled').checked = !!settings.enabled;
    const local = settings.local_status || {};
    status.textContent = !settings.enabled ? 'IA local desativada.' : local.ready === true ? 'Qwen local conectado · ' + (local.selected_model || settings.model) : local.ready === false ? (local.last_error || 'Qwen local indisponível. Confira o serviço e a porta.') : 'IA local habilitada; toque em Detectar Qwen para conferir a conexão.';
  };
  window.saveOpenAISettings = async function (disable = false) {
    const response = await fetch('/api/settings/openai', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: 'local', enabled: disable ? false : byId('openaiEnabled').checked, model: byId('openaiModel').value.trim() || 'auto', local_port: Number(port.value)})});
    const body = await response.json();
    if (!response.ok || body.ok === false) throw new Error(body.error || body.detail || 'Não foi possível salvar.');
    window.renderOpenAISettings(body.settings);
    return body.settings;
  };
  function button(id, text, handler) {
    const old = byId(id), replacement = old.cloneNode(true);
    replacement.textContent = text;
    old.replaceWith(replacement);
    replacement.addEventListener('click', async () => {try {await handler();} catch (error) {status.textContent = error.message;}});
  }
  button('openaiSave', 'Salvar IA local', () => window.saveOpenAISettings(false));
  button('openaiRemove', 'Desativar IA local', () => window.saveOpenAISettings(true));
  const detect = document.createElement('button'); detect.id = 'termuxQwenDetect'; detect.type = 'button'; detect.textContent = 'Detectar Qwen local';
  byId('openaiSave').after(detect);
  detect.addEventListener('click', async () => {
    detect.disabled = true;
    try {
      await window.saveOpenAISettings(false);
      const response = await fetch('/termux/local-ai/detect', {method: 'POST'});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Não foi possível verificar a IA local.');
      window.renderOpenAISettings(body.settings);
    } catch (error) {status.textContent = error.message;} finally {detect.disabled = false;}
  });
  const question = document.createElement('input'); question.id = 'termuxQwenQuestion'; question.maxLength = 180; question.placeholder = 'Teste: quanto é sete vezes oito?';
  const ask = document.createElement('button'); ask.id = 'termuxQwenAsk'; ask.type = 'button'; ask.textContent = 'Testar resposta local';
  status.after(question, ask);
  ask.addEventListener('click', async () => {
    ask.disabled = true; status.textContent = 'Aguardando o Qwen local…';
    try {
      const response = await fetch('/termux/local-ai/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: question.value})});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'A IA local não respondeu.');
      status.textContent = body.text;
    } catch (error) {status.textContent = error.message;} finally {ask.disabled = false;}
  });
  const voiceBox = document.createElement('fieldset');
  const legend = document.createElement('legend'); legend.textContent = 'Voz local já instalada';
  const voiceProvider = document.createElement('select'); voiceProvider.id = 'termuxVoiceProvider';
  for (const [value, title] of [['piper-local', 'Piper local · sem clonagem'], ['xtts', 'XTTS original · exige instalação compatível']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = title; voiceProvider.append(option);
  }
  const voicePort = document.createElement('input'); voicePort.id = 'termuxVoicePort'; voicePort.type = 'number'; voicePort.min = '1024'; voicePort.max = '65535'; voicePort.value = '8083';
  const voiceLabel = document.createElement('label'); voiceLabel.htmlFor = voicePort.id; voiceLabel.textContent = 'Porta do Piper (geralmente 8082 ou 8083)';
  const voiceMessage = document.createElement('p'); voiceMessage.id = 'termuxVoiceStatus';
  const detectVoice = document.createElement('button'); detectVoice.type = 'button'; detectVoice.textContent = 'Salvar e detectar voz'; detectVoice.id = 'termuxVoiceDetect';
  const testVoice = document.createElement('button'); testVoice.type = 'button'; testVoice.textContent = 'Ouvir teste de voz'; testVoice.id = 'termuxVoiceTest';
  const player = document.createElement('audio'); player.controls = true; player.id = 'termuxVoicePlayer'; player.preload = 'none';
  const resume = document.createElement('button'); resume.type = 'button'; resume.textContent = 'Tocar áudio preparado'; resume.hidden = true;
  let audioURL = null;
  async function saveVoice() {
    const response = await fetch('/termux/voice', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: voiceProvider.value, port: Number(voicePort.value)})});
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar a voz.');
  }
  detectVoice.addEventListener('click', async () => {
    detectVoice.disabled = true;
    try {
      await saveVoice();
      if (voiceProvider.value === 'xtts') {voiceMessage.textContent = 'XTTS original selecionado. O teste depende do modelo e da referência originais.'; return;}
      const response = await fetch('/termux/voice/detect', {method: 'POST'});
      const body = await response.json(); voiceMessage.textContent = body.message;
    } catch (error) {voiceMessage.textContent = error.message;} finally {detectVoice.disabled = false;}
  });
  testVoice.addEventListener('click', async () => {
    testVoice.disabled = true; voiceMessage.textContent = 'Gerando áudio local…';
    try {
      await saveVoice();
      const response = await fetch('/termux/voice/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: 'Olá! Rosa, relógio, carro e clarão. A cobra está pronta para conversar.'})});
      if (!response.ok) {const error = await response.json(); throw new Error(error.detail || 'Falha na voz local.');}
      if (audioURL) URL.revokeObjectURL(audioURL);
      audioURL = URL.createObjectURL(await response.blob()); player.src = audioURL;
      voiceMessage.textContent = 'Áudio gerado. Use o player para ouvir.';
      try {await player.play(); resume.hidden = true;} catch (_) {resume.hidden = false; voiceMessage.textContent = 'Áudio pronto. Toque em Tocar áudio preparado para autorizar a reprodução.';}
    } catch (error) {voiceMessage.textContent = error.message;} finally {testVoice.disabled = false;}
  });
  resume.addEventListener('click', () => {player.play().then(() => {resume.hidden = true;}).catch(error => {voiceMessage.textContent = error.message;});});
  voiceBox.append(legend, voiceProvider, voiceLabel, voicePort, detectVoice, testVoice, voiceMessage, player, resume);
  status.parentElement.append(voiceBox);
  fetch('/termux/voice').then(response => response.json()).then(body => {voiceProvider.value = body.provider; voicePort.value = body.port;}).catch(error => {voiceMessage.textContent = error.message;});
  const username = byId('monitorUsername');
  if (username) {
    username.placeholder = '@seu.usuario';
    const label = document.querySelector('label[for="monitorUsername"]');
    if (label) label.textContent = '@ do perfil que está ao vivo';
  }
  window.loadOpenAISettings().catch(error => {status.textContent = error.message;});
  fetch('/termux/game').then(async response => {
    if (!response.ok) return;
    const card = document.createElement('section'); card.className = 'card termux-ai-card'; card.style.marginTop = '14px';
    const title = document.createElement('h2'); title.textContent = 'Jogo original · Termux 0.3.2';
    const message = document.createElement('p'); message.id = 'termuxGameStatus';
    const deviceMessage = document.createElement('p'); deviceMessage.id = 'termuxDeviceStatus';
    const start = document.createElement('button'); start.type = 'button'; start.textContent = 'Abrir jogo original';
    const stop = document.createElement('button'); stop.type = 'button'; stop.textContent = 'Fechar janela do jogo';
    async function refresh() {
      const response = await fetch('/termux/game'); const body = await response.json();
      message.textContent = body.running ? (body.bridge_connected ? 'Janela em execução · conectada ao servidor.' : 'Janela em execução · aguardando conexão com o servidor.') : 'Janela parada. Última saída: ' + (body.last_exit_code ?? 'nenhuma') + '. Logs: ' + body.log;
      const gpu = body.device?.graphics, output = body.device?.audio, display = body.device?.display;
      deviceMessage.textContent = gpu ? (gpu.hardware_verified ? 'GPU confirmada: ' + gpu.renderer : gpu.message) + ' · ' + gpu.resolution + ' · limite ' + gpu.max_fps + ' FPS. ' + (display?.message || output?.message || '') : '';
      if (body.performance?.fps != null) deviceMessage.textContent += ' FPS medido: ' + body.performance.fps + '.';
      if (body.performance?.software_renderer) deviceMessage.textContent += ' ⚠ O jogo está usando renderização por CPU: ' + body.performance.observed_renderer + '.';
      if (body.audio_runtime?.state === 'dummy') {
        deviceMessage.textContent += ' ⚠ ' + body.audio_runtime.message;
        deviceMessage.style.color = '#ffba6b';
      } else if (output && output.output_available === false) {
        deviceMessage.textContent += ' ⚠ ' + output.message;
        deviceMessage.style.color = '#ffba6b';
      } else {deviceMessage.style.color = '';}
    }
    for (const [button, action] of [[start, 'start'], [stop, 'stop']]) button.addEventListener('click', async () => {
      button.disabled = true;
      try {const r = await fetch('/termux/game/' + action, {method: 'POST'}); const b = await r.json(); if (!r.ok) throw new Error(b.detail || 'Falha no jogo nativo.'); await refresh();}
      catch (error) {message.textContent = error.message;} finally {button.disabled = false;}
    });
    const sound = document.createElement('button'); sound.type = 'button'; sound.textContent = 'Testar som do jogo'; sound.id = 'termuxGameSoundTest';
    const speech = document.createElement('button'); speech.type = 'button'; speech.textContent = 'Testar fala no jogo'; speech.id = 'termuxGameSpeechTest';
    const testMessage = document.createElement('p'); testMessage.id = 'termuxGameAudioStatus';
    for (const [button, path] of [[sound, '/termux/audio/test'], [speech, '/termux/audio/speech-test']]) button.addEventListener('click', async () => {
      button.disabled = true; testMessage.textContent = 'Preparando teste…';
      try {
        const response = await fetch(path, {method: 'POST'}); const body = await response.json();
        if (!response.ok) throw new Error(body.detail || 'Falha no teste.');
        testMessage.textContent = body.queued ? 'Fala enfileirada; ainda não confirma reprodução. Confirme se ouviu.' : body.test_sent ? 'Teste de som enviado. Confirme se ouviu o sinal.' : (body.message || 'A saída não ficou disponível.') + ' ' + (body.errors || []).join(' ');
        await refresh();
      } catch (error) {testMessage.textContent = error.message;} finally {button.disabled = false;}
    });
    const musicBox = document.createElement('fieldset'); musicBox.id = 'termuxMusicLibrary';
    const musicTitle = document.createElement('legend'); musicTitle.textContent = 'Biblioteca de músicas';
    const musicHelp = document.createElement('p'); musicHelp.textContent = 'Envie várias faixas. A preparação acontece uma vez e preserva o áudio original. Marque as músicas que participarão do automático.';
    const musicLabel = document.createElement('label'); musicLabel.htmlFor = 'termuxMusicFile'; musicLabel.textContent = 'MP3, OGG, WAV, M4A, AAC, FLAC ou OPUS · até 200 MB por arquivo';
    const musicFile = document.createElement('input'); musicFile.id = 'termuxMusicFile'; musicFile.type = 'file'; musicFile.multiple = true; musicFile.accept = '.mp3,.ogg,.wav,.m4a,.aac,.flac,.opus';
    const sendMusic = document.createElement('button'); sendMusic.type = 'button'; sendMusic.id = 'termuxMusicUpload'; sendMusic.textContent = 'Salvar músicas';
    const musicMessage = document.createElement('p'); musicMessage.id = 'termuxMusicStatus'; musicMessage.setAttribute('role', 'status');
    const musicSelect = document.createElement('select'); musicSelect.id = 'termuxMusicSelect'; musicSelect.setAttribute('aria-label', 'Faixa para tocar');
    const musicMode = document.createElement('select'); musicMode.id = 'termuxMusicMode'; musicMode.setAttribute('aria-label', 'Modo de reprodução');
    for (const [value, text] of [['single', 'Repetir a faixa escolhida'], ['shuffle', 'Automático · sortear somente as marcadas']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; musicMode.append(option);
    }
    const musicTracks = document.createElement('div'); musicTracks.id = 'termuxMusicTracks'; musicTracks.style.cssText = 'max-height:240px;overflow:auto;display:grid;gap:8px;margin:12px 0';
    const playMusic = document.createElement('button'); playMusic.id = 'termuxMusicPlay'; playMusic.type = 'button'; playMusic.textContent = 'Tocar / salvar seleção';
    const nextMusic = document.createElement('button'); nextMusic.id = 'termuxMusicNext'; nextMusic.type = 'button'; nextMusic.textContent = 'Próxima faixa';
    const pauseMusic = document.createElement('button'); pauseMusic.id = 'termuxMusicPause'; pauseMusic.type = 'button'; pauseMusic.textContent = 'Pausar';
    const musicVolumeLabel = document.createElement('label'); musicVolumeLabel.htmlFor = 'termuxMusicVolume'; musicVolumeLabel.textContent = 'Volume da música';
    const musicVolume = document.createElement('input'); musicVolume.type = 'range'; musicVolume.id = 'termuxMusicVolume'; musicVolume.min = '0'; musicVolume.max = '100';
    const musicVolumeValue = document.createElement('output'); musicVolumeValue.htmlFor = 'termuxMusicVolume';
    let library, musicBusy = false;
    const musicButtons = [sendMusic, playMusic, nextMusic, pauseMusic];
    function busyMusic(value) {musicBusy = value; for (const button of musicButtons) button.disabled = value; musicVolume.disabled = value;}
    async function musicRequest(path, options) {
      const response = await fetch(path, options); const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Não foi possível preparar a música.');
      return body;
    }
    function showLibrary(body) {
      library = body; musicMode.value = body.mode;
      musicSelect.replaceChildren(); musicTracks.replaceChildren();
      const selected = new Set(body.selected);
      for (const track of body.tracks) {
        const option = document.createElement('option'); option.value = track.id; option.textContent = track.title; musicSelect.append(option);
        const row = document.createElement('label'); row.style.cssText = 'display:flex;gap:10px;align-items:center';
        const check = document.createElement('input'); check.type = 'checkbox'; check.value = track.id; check.checked = selected.has(track.id); check.style.width = 'auto';
        const text = document.createElement('span'); text.textContent = track.title + (track.error ? ' · ' + track.error : track.ready ? ' · pronta' : ' · preparar ao tocar');
        row.append(check, text); musicTracks.append(row);
      }
      if (body.current) musicSelect.value = body.current;
      musicVolume.value = String(Math.round(body.volume * 100)); musicVolumeValue.textContent = musicVolume.value + '%';
      pauseMusic.textContent = body.enabled ? 'Pausar música' : 'Retomar música';
    }
    async function musicControl(payload) {
      const body = await musicRequest('/termux/music/control', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
      showLibrary(body.music);
      musicMessage.textContent = body.sent_to_game ? 'Configuração enviada ao jogo. ' + (body.music.mode === 'single' ? 'Repetindo a faixa escolhida.' : 'Automático: somente as faixas marcadas.') : 'Seleção salva. Abra o jogo para reproduzir.';
      return body;
    }
    musicRequest('/termux/music/library').then(body => {
      showLibrary(body); musicMessage.textContent = body.tracks.length + ' faixa(s) salvas. Escolha uma e toque em Tocar. Arquivos antigos serão preparados automaticamente.';
      const oldCard = document.getElementById('musicEnabled')?.closest('article'); if (oldCard) oldCard.hidden = true;
    }).catch(error => {musicMessage.textContent = error.message;});
    sendMusic.addEventListener('click', async () => {
      const files = Array.from(musicFile.files); if (!files.length) {musicMessage.textContent = 'Selecione uma ou mais músicas do celular.'; return;}
      busyMusic(true); let saved = 0; const errors = [];
      try {
        for (let i = 0; i < files.length; i++) {
          musicMessage.textContent = (i + 1) + '/' + files.length + ' · recebendo e preparando ' + files[i].name + '. Faixas longas podem levar alguns minutos.';
          try {
            if (files[i].size > 200 * 1024 * 1024) throw new Error('O arquivo deve ter até 200 MB.');
            const form = new FormData(); form.append('file', files[i]);
            const body = await musicRequest('/termux/music/import', {method: 'POST', body: form});
            showLibrary(body.music); musicSelect.value = body.id; saved++;
          } catch (error) {errors.push(files[i].name + ': ' + error.message);}
        }
        musicMessage.textContent = saved + ' música(s) preparadas e salvas. Escolha uma e toque em Tocar. ' + errors.join(' ');
        musicFile.value = '';
      } finally {busyMusic(false);}
    });
    playMusic.addEventListener('click', async () => {
      busyMusic(true); musicMessage.textContent = 'Preparando a seleção. Músicas longas podem levar alguns minutos na primeira vez…';
      try {await musicControl({mode: musicMode.value, selected: Array.from(musicTracks.querySelectorAll('input:checked'), item => item.value), current: musicSelect.value, play: true});}
      catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}
    });
    nextMusic.addEventListener('click', async () => {busyMusic(true); try {await musicControl({next: true, play: true});} catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}});
    pauseMusic.addEventListener('click', async () => {if (!library) return; busyMusic(true); try {await musicControl({enabled: !library.enabled}); musicMessage.textContent = library.enabled ? 'Música retomada.' : 'Música pausada. Voz e efeitos continuam disponíveis.';} catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}});
    musicVolume.addEventListener('input', () => {musicVolumeValue.textContent = musicVolume.value + '%';});
    musicVolume.addEventListener('change', async () => {try {const b = await musicRequest('/termux/music/control', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({volume: Number(musicVolume.value) / 100})}); library = b.music;} catch (error) {musicMessage.textContent = error.message;}});
    setInterval(async () => {
      if (musicBusy) return;
      try {const body = await musicRequest('/termux/music/library'); if (body.progress.busy) musicMessage.textContent = body.progress.message;} catch (_) {}
    }, 5000);
    musicBox.append(musicTitle, musicHelp, musicLabel, musicFile, sendMusic, musicMode, musicSelect, musicTracks, playMusic, nextMusic, pauseMusic, musicVolumeLabel, musicVolume, musicVolumeValue, musicMessage);
    const profileLabel = document.createElement('label'); profileLabel.htmlFor = 'termuxGraphicsProfile'; profileLabel.textContent = 'Qualidade da imagem · tela limpa em retrato';
    const profile = document.createElement('select'); profile.id = 'termuxGraphicsProfile';
    for (const [value, text] of [['balanced', 'Equilibrado · 720 × 1280'], ['light', 'Leve · 640 × 1136'], ['live', 'Modo LIVE · 640 × 1136 · limite 45 FPS'], ['sharp', 'Mais nítido · 864 × 1536'], ['stable', 'Estável · 640 × 1136 · limite 30 FPS'], ['clear', '720p · limite 45 FPS'], ['quality30', 'Mais nítido · 864 × 1536 · limite 30 FPS']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; profile.append(option);
    }
    const saveProfile = document.createElement('button'); saveProfile.type = 'button'; saveProfile.id = 'termuxSaveProfile'; saveProfile.textContent = 'Salvar qualidade';
    const profileMessage = document.createElement('p'); profileMessage.id = 'termuxProfileStatus';
    const profileBox = document.createElement('div'); profileBox.hidden = true;
    profileBox.append(profileLabel, profile, saveProfile, profileMessage);
    fetch('/termux/presentation').then(r => {if (!r.ok) throw new Error('Exibição não disponível nesta revisão.'); return r.json();}).then(body => {profile.value = body.settings.profile; profileBox.hidden = false;}).catch(() => {});
    saveProfile.addEventListener('click', async () => {
      saveProfile.disabled = true;
      try {
        const response = await fetch('/termux/presentation', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({profile: profile.value})});
        const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar.');
        profileMessage.textContent = 'Salvo. Use Fechar janela do jogo e depois Abrir jogo original para aplicar. O modo leve reduz a carga gráfica; os FPS reais dependem do aparelho.';
      } catch (error) {profileMessage.textContent = error.message;} finally {saveProfile.disabled = false;}
    });
    card.append(title, message, deviceMessage, start, stop, profileBox, sound, speech, testMessage, musicBox);
    const pacing = document.createElement('fieldset'); pacing.hidden = true;
    const pacingTitle = document.createElement('legend'); pacingTitle.textContent = 'Ritmo das respostas e câmera';
    const pacingMode = document.createElement('select'); pacingMode.id = 'termuxReplyMode';
    for (const [value, text] of [['direct', 'Resposta direta · menos espera e trocas de foco'], ['dialogue', 'Diálogo original · usuário lê, cobra responde']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; pacingMode.append(option);
    }
    const pacingSave = document.createElement('button'); pacingSave.type = 'button'; pacingSave.textContent = 'Salvar ritmo'; pacingSave.id = 'termuxSaveReplyMode';
    const pacingMessage = document.createElement('p'); pacingMessage.id = 'termuxReplyModeStatus';
    fetch('/termux/live-tuning').then(async r => {if (!r.ok) return; const b = await r.json(); pacingMode.value = b.settings.reply_mode; pacing.hidden = false;}).catch(() => {});
    pacingSave.addEventListener('click', async () => {
      pacingSave.disabled = true;
      try {const r = await fetch('/termux/live-tuning', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({reply_mode: pacingMode.value})}); const b = await r.json(); if (!r.ok) throw new Error(b.detail || 'Falha ao salvar.'); pacingMessage.textContent = 'Salvo para os próximos comentários. Nomes e personagens continuam aparecendo; o modo direto evita a leitura em voz alta antes da resposta.';}
      catch (error) {pacingMessage.textContent = error.message;} finally {pacingSave.disabled = false;}
    });
    pacing.append(pacingTitle, pacingMode, pacingSave, pacingMessage); card.append(pacing);
    const loadBox = document.createElement('fieldset'); loadBox.hidden = true;
    const loadTitle = document.createElement('legend'); loadTitle.textContent = 'LIVE movimentada · fila e nomes';
    const loadToggleLabel = document.createElement('label'); const loadToggle = document.createElement('input'); loadToggle.type = 'checkbox'; loadToggle.id = 'termuxBusyLive'; loadToggle.style.width = 'auto';
    loadToggleLabel.append(loadToggle, ' Preparar uma resposta adiantada e priorizar perguntas recentes');
    const loadSave = document.createElement('button'); loadSave.type = 'button'; loadSave.id = 'termuxLoadSave'; loadSave.textContent = 'Salvar modo da LIVE';
    const loadMessage = document.createElement('p'); loadMessage.id = 'termuxLoadStatus';
    fetch('/termux/live-load').then(async r => {if (!r.ok) return; const b = await r.json(); loadToggle.checked = b.settings.busy_live; loadMessage.textContent = b.note; loadBox.hidden = false;}).catch(() => {});
    loadSave.onclick = async () => {try {const r = await fetch('/termux/live-load', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({busy_live:loadToggle.checked})}); const b = await r.json(); if(!r.ok)throw new Error(b.detail);loadMessage.textContent='Modo salvo. '+b.note;}catch(e){loadMessage.textContent=e.message;}};
    const nameLabel = document.createElement('label'); nameLabel.htmlFor = 'termuxNameRaw'; nameLabel.textContent = 'Nome que está sendo soletrado';
    const nameRaw = document.createElement('input'); nameRaw.id = 'termuxNameRaw'; nameRaw.placeholder = 'Ex.: G U S T A V O'; nameRaw.maxLength = 100;
    const namePreview = document.createElement('button'); namePreview.type = 'button'; namePreview.id = 'termuxNamePreview'; namePreview.textContent = 'Conferir nome falado · sem gerar áudio';
    const userLabel = document.createElement('label'); userLabel.htmlFor = 'termuxNameUser'; userLabel.textContent = '@ do usuário para uma pronúncia personalizada';
    const nameUser = document.createElement('input'); nameUser.id = 'termuxNameUser'; nameUser.placeholder = '@gustavo123';
    const aliasLabel = document.createElement('label'); aliasLabel.htmlFor = 'termuxNameAlias'; aliasLabel.textContent = 'Como falar';
    const nameAlias = document.createElement('input'); nameAlias.id = 'termuxNameAlias'; nameAlias.placeholder = 'Gustavo';
    const aliasSave = document.createElement('button'); aliasSave.type = 'button'; aliasSave.id = 'termuxNameSave'; aliasSave.textContent = 'Salvar pronúncia para esse usuário';
    const nameMessage = document.createElement('p'); nameMessage.id = 'termuxNameStatus';
    async function nameRequest(save) {try {const p={name:nameRaw.value};if(save){p.username=nameUser.value;p.alias=nameAlias.value;}const r=await fetch('/termux/spoken-name',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});const b=await r.json();if(!r.ok)throw new Error(b.detail);nameMessage.textContent=(b.saved?'Pronúncia salva: ':'Nome falado: ')+b.spoken+'. Nome, foto e ranking permanecem iguais.';}catch(e){nameMessage.textContent=e.message;}}
    namePreview.onclick=()=>nameRequest(false);aliasSave.onclick=()=>nameRequest(true);
    const director = document.createElement('a'); director.href='/termux/director'; director.target='_blank'; director.rel='noopener'; director.id='termuxDirector'; director.textContent='Abrir painel do operador · espectadores e FPS'; director.style.display='block'; director.style.padding='14px 0';
    const directorNote=document.createElement('small');directorNote.textContent='Contador fora do jogo. Captura da tela inteira do celular pode mostrar o navegador; captura somente do jogo é necessária para separá-lo.';
    loadBox.append(loadTitle,loadToggleLabel,loadSave,loadMessage,nameLabel,nameRaw,namePreview,userLabel,nameUser,aliasLabel,nameAlias,aliasSave,nameMessage,director,directorNote);
    card.append(loadBox);
    status.closest('section').before(card);
    await refresh(); setInterval(() => refresh().catch(() => {}), 5000);
  }).catch(() => {});
})();
