(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const status = byId('openaiStatus');
  const key = byId('openaiApiKey');
  if (!status || !key) return;
  status.closest('section').classList.add('termux-ai-card');
  const styles = document.createElement('style');
  styles.textContent = '.termux-ai-card,.termux-ai-card *{box-sizing:border-box}.termux-ai-card input,.termux-ai-card select,.termux-ai-card audio{max-width:100%}.termux-ai-card fieldset{min-width:0;padding:12px;margin:16px 0 0}.termux-ai-card audio{display:block;margin-top:10px;width:100%}.termux-ai-card button{white-space:normal}';
  document.head.append(styles);
  key.hidden = true;
  key.style.setProperty('display', 'none', 'important');
  key.disabled = true;
  key.value = '';
  const keyLabel = document.querySelector('label[for="openaiApiKey"]');
  if (keyLabel) {keyLabel.hidden = true; keyLabel.style.setProperty('display', 'none', 'important');}
  const portLabel = document.createElement('label');
  portLabel.htmlFor = 'termuxQwenPort';
  portLabel.textContent = 'Porta do Qwen local';
  const port = document.createElement('input');
  port.id = 'termuxQwenPort'; port.type = 'number'; port.min = '1024'; port.max = '65535'; port.value = '8081';
  key.after(portLabel, port);
  byId('openaiModel').placeholder = 'auto · detectar o modelo já instalado';
  const note = document.createElement('p');
  note.textContent = 'Qwen local no Termux. Use auto para detectar o modelo. Não precisa de chave de API.';
  status.parentElement.prepend(note);

  window.renderOpenAISettings = function (settings) {
    if (document.activeElement !== byId('openaiModel')) byId('openaiModel').value = settings.model || 'auto';
    if (document.activeElement !== port) port.value = settings.local_port || 8081;
    byId('openaiEnabled').checked = !!settings.enabled;
    const local = settings.local_status || {};
    status.textContent = !settings.enabled ? 'IA local desativada.' : local.ready === true ? 'Qwen local conectado · ' + (local.selected_model || settings.model) : local.ready === false ? (local.last_error || 'Qwen local indisponível. Confira o serviço e a porta.') : 'IA local habilitada; toque em Detectar Qwen para conferir a conexão.';
  };
  window.saveOpenAISettings = async function (disable = false) {
    const response = await fetch('/api/settings/openai', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: 'local', enabled: disable ? false : byId('openaiEnabled').checked, model: byId('openaiModel').value.trim() || 'auto', local_port: Number(port.value)})});
    const body = await response.json();
    if (!response.ok || body.ok === false) throw new Error(body.error || body.detail || 'Não foi possível salvar.');
    window.renderOpenAISettings(body.settings);
    return body.settings;
  };
  function button(id, text, handler) {
    const old = byId(id), replacement = old.cloneNode(true);
    replacement.textContent = text;
    old.replaceWith(replacement);
    replacement.addEventListener('click', async () => {try {await handler();} catch (error) {status.textContent = error.message;}});
  }
  button('openaiSave', 'Salvar IA local', () => window.saveOpenAISettings(false));
  button('openaiRemove', 'Desativar IA local', () => window.saveOpenAISettings(true));
  const detect = document.createElement('button'); detect.id = 'termuxQwenDetect'; detect.type = 'button'; detect.textContent = 'Detectar Qwen local';
  byId('openaiSave').after(detect);
  detect.addEventListener('click', async () => {
    detect.disabled = true;
    try {
      await window.saveOpenAISettings(false);
      const response = await fetch('/termux/local-ai/detect', {method: 'POST'});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Não foi possível verificar a IA local.');
      window.renderOpenAISettings(body.settings);
    } catch (error) {status.textContent = error.message;} finally {detect.disabled = false;}
  });
  const question = document.createElement('input'); question.id = 'termuxQwenQuestion'; question.maxLength = 180; question.placeholder = 'Teste: quanto é sete vezes oito?';
  const ask = document.createElement('button'); ask.id = 'termuxQwenAsk'; ask.type = 'button'; ask.textContent = 'Testar resposta local';
  status.after(question, ask);
  ask.addEventListener('click', async () => {
    ask.disabled = true; status.textContent = 'Aguardando o Qwen local…';
    try {
      const response = await fetch('/termux/local-ai/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: question.value})});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'A IA local não respondeu.');
      status.textContent = body.text;
    } catch (error) {status.textContent = error.message;} finally {ask.disabled = false;}
  });
  const voiceBox = document.createElement('fieldset');
  const legend = document.createElement('legend'); legend.textContent = 'Voz local já instalada';
  const voiceProvider = document.createElement('select'); voiceProvider.id = 'termuxVoiceProvider';
  for (const [value, title] of [['piper-local', 'Piper local · sem clonagem'], ['xtts', 'XTTS original · exige instalação compatível']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = title; voiceProvider.append(option);
  }
  const voicePort = document.createElement('input'); voicePort.id = 'termuxVoicePort'; voicePort.type = 'number'; voicePort.min = '1024'; voicePort.max = '65535'; voicePort.value = '8083';
  const voiceLabel = document.createElement('label'); voiceLabel.htmlFor = voicePort.id; voiceLabel.textContent = 'Porta do Piper (geralmente 8082 ou 8083)';
  const voiceMessage = document.createElement('p'); voiceMessage.id = 'termuxVoiceStatus';
  const detectVoice = document.createElement('button'); detectVoice.type = 'button'; detectVoice.textContent = 'Salvar e detectar voz'; detectVoice.id = 'termuxVoiceDetect';
  const testVoice = document.createElement('button'); testVoice.type = 'button'; testVoice.textContent = 'Ouvir teste de voz'; testVoice.id = 'termuxVoiceTest';
  const player = document.createElement('audio'); player.controls = true; player.id = 'termuxVoicePlayer'; player.preload = 'none';
  const resume = document.createElement('button'); resume.type = 'button'; resume.textContent = 'Tocar áudio preparado'; resume.hidden = true;
  let audioURL = null;
  async function saveVoice() {
    const response = await fetch('/termux/voice', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: voiceProvider.value, port: Number(voicePort.value)})});
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar a voz.');
  }
  detectVoice.addEventListener('click', async () => {
    detectVoice.disabled = true;
    try {
      await saveVoice();
      if (voiceProvider.value === 'xtts') {voiceMessage.textContent = 'XTTS original selecionado. O teste depende do modelo e da referência originais.'; return;}
      const response = await fetch('/termux/voice/detect', {method: 'POST'});
      const body = await response.json(); voiceMessage.textContent = body.message;
    } catch (error) {voiceMessage.textContent = error.message;} finally {detectVoice.disabled = false;}
  });
  testVoice.addEventListener('click', async () => {
    testVoice.disabled = true; voiceMessage.textContent = 'Gerando áudio local…';
    try {
      await saveVoice();
      const response = await fetch('/termux/voice/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: 'Olá! Rosa, relógio, carro e clarão. A cobra está pronta para conversar.'})});
      if (!response.ok) {const error = await response.json(); throw new Error(error.detail || 'Falha na voz local.');}
      if (audioURL) URL.revokeObjectURL(audioURL);
      audioURL = URL.createObjectURL(await response.blob()); player.src = audioURL;
      voiceMessage.textContent = 'Áudio gerado. Use o player para ouvir.';
      try {await player.play(); resume.hidden = true;} catch (_) {resume.hidden = false; voiceMessage.textContent = 'Áudio pronto. Toque em Tocar áudio preparado para autorizar a reprodução.';}
    } catch (error) {voiceMessage.textContent = error.message;} finally {testVoice.disabled = false;}
  });
  resume.addEventListener('click', () => {player.play().then(() => {resume.hidden = true;}).catch(error => {voiceMessage.textContent = error.message;});});
  voiceBox.append(legend, voiceProvider, voiceLabel, voicePort, detectVoice, testVoice, voiceMessage, player, resume);
  status.parentElement.append(voiceBox);
  fetch('/termux/voice').then(response => response.json()).then(body => {voiceProvider.value = body.provider; voicePort.value = body.port;}).catch(error => {voiceMessage.textContent = error.message;});
  const username = byId('monitorUsername');
  if (username) {
    username.placeholder = '@seu.usuario';
    const label = document.querySelector('label[for="monitorUsername"]');
    if (label) label.textContent = '@ do perfil que está ao vivo';
  }
  window.loadOpenAISettings().catch(error => {status.textContent = error.message;});
  fetch('/termux/game').then(async response => {
    if (!response.ok) return;
    const card = document.createElement('section'); card.className = 'card termux-ai-card'; card.style.marginTop = '14px';
    const title = document.createElement('h2'); title.textContent = 'Jogo original · Termux 0.3.9';
    const message = document.createElement('p'); message.id = 'termuxGameStatus';
    const deviceMessage = document.createElement('p'); deviceMessage.id = 'termuxDeviceStatus';
    const start = document.createElement('button'); start.type = 'button'; start.textContent = 'Abrir jogo original';
    const stop = document.createElement('button'); stop.type = 'button'; stop.textContent = 'Fechar janela do jogo';
    async function refresh() {
      const response = await fetch('/termux/game'); const body = await response.json();
      message.textContent = body.running ? (body.bridge_connected ? 'Janela em execução · conectada ao servidor.' : 'Janela em execução · aguardando conexão com o servidor.') : 'Janela parada. Última saída: ' + (body.last_exit_code ?? 'nenhuma') + '. Logs: ' + body.log;
      const gpu = body.device?.graphics, output = body.device?.audio, display = body.device?.display;
      deviceMessage.textContent = gpu ? (gpu.hardware_verified ? 'GPU confirmada: ' + gpu.renderer : gpu.message) + ' · ' + gpu.resolution + ' · limite ' + gpu.max_fps + ' FPS. ' + (display?.message || output?.message || '') : '';
      if (body.performance?.fps != null) deviceMessage.textContent += ' FPS medido: ' + body.performance.fps + '.';
      if (body.performance?.software_renderer) deviceMessage.textContent += ' ⚠ O jogo está usando renderização por CPU: ' + body.performance.observed_renderer + '.';
      if (body.audio_runtime?.state === 'dummy') {
        deviceMessage.textContent += ' ⚠ ' + body.audio_runtime.message;
        deviceMessage.style.color = '#ffba6b';
      } else if (output && output.output_available === false) {
        deviceMessage.textContent += ' ⚠ ' + output.message;
        deviceMessage.style.color = '#ffba6b';
      } else {deviceMessage.style.color = '';}
    }
    for (const [button, action] of [[start, 'start'], [stop, 'stop']]) button.addEventListener('click', async () => {
      button.disabled = true;
      try {const r = await fetch('/termux/game/' + action, {method: 'POST'}); const b = await r.json(); if (!r.ok) throw new Error(b.detail || 'Falha no jogo nativo.'); await refresh();}
      catch (error) {message.textContent = error.message;} finally {button.disabled = false;}
    });
    const sound = document.createElement('button'); sound.type = 'button'; sound.textContent = 'Testar som do jogo'; sound.id = 'termuxGameSoundTest';
    const speech = document.createElement('button'); speech.type = 'button'; speech.textContent = 'Testar fala no jogo'; speech.id = 'termuxGameSpeechTest';
    const testMessage = document.createElement('p'); testMessage.id = 'termuxGameAudioStatus';
    for (const [button, path] of [[sound, '/termux/audio/test'], [speech, '/termux/audio/speech-test']]) button.addEventListener('click', async () => {
      button.disabled = true; testMessage.textContent = 'Preparando teste…';
      try {
        const response = await fetch(path, {method: 'POST'}); const body = await response.json();
        if (!response.ok) throw new Error(body.detail || 'Falha no teste.');
        testMessage.textContent = body.queued ? 'Fala enfileirada; ainda não confirma reprodução. Confirme se ouviu.' : body.test_sent ? 'Teste de som enviado. Confirme se ouviu o sinal.' : (body.message || 'A saída não ficou disponível.') + ' ' + (body.errors || []).join(' ');
        await refresh();
      } catch (error) {testMessage.textContent = error.message;} finally {button.disabled = false;}
    });
    const musicBox = document.createElement('fieldset'); musicBox.id = 'termuxMusicLibrary';
    const musicTitle = document.createElement('legend'); musicTitle.textContent = 'Biblioteca de músicas';
    const musicHelp = document.createElement('p'); musicHelp.textContent = 'Envie várias faixas. A preparação acontece uma vez e preserva o áudio original. Marque as músicas que participarão do automático.';
    const musicLabel = document.createElement('label'); musicLabel.htmlFor = 'termuxMusicFile'; musicLabel.textContent = 'MP3, OGG, WAV, M4A, AAC, FLAC ou OPUS · até 200 MB por arquivo';
    const musicFile = document.createElement('input'); musicFile.id = 'termuxMusicFile'; musicFile.type = 'file'; musicFile.multiple = true; musicFile.accept = '.mp3,.ogg,.wav,.m4a,.aac,.flac,.opus';
    const sendMusic = document.createElement('button'); sendMusic.type = 'button'; sendMusic.id = 'termuxMusicUpload'; sendMusic.textContent = 'Salvar músicas';
    const musicMessage = document.createElement('p'); musicMessage.id = 'termuxMusicStatus'; musicMessage.setAttribute('role', 'status');
    const musicSelect = document.createElement('select'); musicSelect.id = 'termuxMusicSelect'; musicSelect.setAttribute('aria-label', 'Faixa para tocar');
    const musicMode = document.createElement('select'); musicMode.id = 'termuxMusicMode'; musicMode.setAttribute('aria-label', 'Modo de reprodução');
    for (const [value, text] of [['single', 'Repetir a faixa escolhida'], ['shuffle', 'Automático · sortear somente as marcadas']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; musicMode.append(option);
    }
    const musicTracks = document.createElement('div'); musicTracks.id = 'termuxMusicTracks'; musicTracks.style.cssText = 'max-height:240px;overflow:auto;display:grid;gap:8px;margin:12px 0';
    const playMusic = document.createElement('button'); playMusic.id = 'termuxMusicPlay'; playMusic.type = 'button'; playMusic.textContent = 'Tocar / salvar seleção';
    const nextMusic = document.createElement('button'); nextMusic.id = 'termuxMusicNext'; nextMusic.type = 'button'; nextMusic.textContent = 'Próxima faixa';
    const pauseMusic = document.createElement('button'); pauseMusic.id = 'termuxMusicPause'; pauseMusic.type = 'button'; pauseMusic.textContent = 'Pausar';
    const musicVolumeLabel = document.createElement('label'); musicVolumeLabel.htmlFor = 'termuxMusicVolume'; musicVolumeLabel.textContent = 'Volume da música';
    const musicVolume = document.createElement('input'); musicVolume.type = 'range'; musicVolume.id = 'termuxMusicVolume'; musicVolume.min = '0'; musicVolume.max = '100';
    const musicVolumeValue = document.createElement('output'); musicVolumeValue.htmlFor = 'termuxMusicVolume';
    let library, musicBusy = false;
    const musicButtons = [sendMusic, playMusic, nextMusic, pauseMusic];
    function busyMusic(value) {musicBusy = value; for (const button of musicButtons) button.disabled = value; musicVolume.disabled = value;}
    async function musicRequest(path, options) {
      const response = await fetch(path, options); const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Não foi possível preparar a música.');
      return body;
    }
    function showLibrary(body) {
      library = body; musicMode.value = body.mode;
      musicSelect.replaceChildren(); musicTracks.replaceChildren();
      const selected = new Set(body.selected);
      for (const track of body.tracks) {
        const option = document.createElement('option'); option.value = track.id; option.textContent = track.title; musicSelect.append(option);
        const row = document.createElement('label'); row.style.cssText = 'display:flex;gap:10px;align-items:center';
        const check = document.createElement('input'); check.type = 'checkbox'; check.value = track.id; check.checked = selected.has(track.id); check.style.width = 'auto';
        const text = document.createElement('span'); text.textContent = track.title + (track.error ? ' · ' + track.error : track.ready ? ' · pronta' : ' · preparar ao tocar');
        row.append(check, text); musicTracks.append(row);
      }
      if (body.current) musicSelect.value = body.current;
      musicVolume.value = String(Math.round(body.volume * 100)); musicVolumeValue.textContent = musicVolume.value + '%';
      pauseMusic.textContent = body.enabled ? 'Pausar música' : 'Retomar música';
    }
    async function musicControl(payload) {
      const body = await musicRequest('/termux/music/control', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
      showLibrary(body.music);
      musicMessage.textContent = body.sent_to_game ? 'Configuração enviada ao jogo. ' + (body.music.mode === 'single' ? 'Repetindo a faixa escolhida.' : 'Automático: somente as faixas marcadas.') : 'Seleção salva. Abra o jogo para reproduzir.';
      return body;
    }
    musicRequest('/termux/music/library').then(body => {
      showLibrary(body); musicMessage.textContent = body.tracks.length + ' faixa(s) salvas. Escolha uma e toque em Tocar. Arquivos antigos serão preparados automaticamente.';
      const oldCard = document.getElementById('musicEnabled')?.closest('article'); if (oldCard) oldCard.hidden = true;
    }).catch(error => {musicMessage.textContent = error.message;});
    sendMusic.addEventListener('click', async () => {
      const files = Array.from(musicFile.files); if (!files.length) {musicMessage.textContent = 'Selecione uma ou mais músicas do celular.'; return;}
      busyMusic(true); let saved = 0; const errors = [];
      try {
        for (let i = 0; i < files.length; i++) {
          musicMessage.textContent = (i + 1) + '/' + files.length + ' · recebendo e preparando ' + files[i].name + '. Faixas longas podem levar alguns minutos.';
          try {
            if (files[i].size > 200 * 1024 * 1024) throw new Error('O arquivo deve ter até 200 MB.');
            const form = new FormData(); form.append('file', files[i]);
            const body = await musicRequest('/termux/music/import', {method: 'POST', body: form});
            showLibrary(body.music); musicSelect.value = body.id; saved++;
          } catch (error) {errors.push(files[i].name + ': ' + error.message);}
        }
        musicMessage.textContent = saved + ' música(s) preparadas e salvas. Escolha uma e toque em Tocar. ' + errors.join(' ');
        musicFile.value = '';
      } finally {busyMusic(false);}
    });
    playMusic.addEventListener('click', async () => {
      busyMusic(true); musicMessage.textContent = 'Preparando a seleção. Músicas longas podem levar alguns minutos na primeira vez…';
      try {await musicControl({mode: musicMode.value, selected: Array.from(musicTracks.querySelectorAll('input:checked'), item => item.value), current: musicSelect.value, play: true});}
      catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}
    });
    nextMusic.addEventListener('click', async () => {busyMusic(true); try {await musicControl({next: true, play: true});} catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}});
    pauseMusic.addEventListener('click', async () => {if (!library) return; busyMusic(true); try {await musicControl({enabled: !library.enabled}); musicMessage.textContent = library.enabled ? 'Música retomada.' : 'Música pausada. Voz e efeitos continuam disponíveis.';} catch (error) {musicMessage.textContent = error.message;} finally {busyMusic(false);}});
    musicVolume.addEventListener('input', () => {musicVolumeValue.textContent = musicVolume.value + '%';});
    musicVolume.addEventListener('change', async () => {try {const b = await musicRequest('/termux/music/control', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({volume: Number(musicVolume.value) / 100})}); library = b.music;} catch (error) {musicMessage.textContent = error.message;}});
    setInterval(async () => {
      if (musicBusy) return;
      try {const body = await musicRequest('/termux/music/library'); if (body.progress.busy) musicMessage.textContent = body.progress.message;} catch (_) {}
    }, 5000);
    musicBox.append(musicTitle, musicHelp, musicLabel, musicFile, sendMusic, musicMode, musicSelect, musicTracks, playMusic, nextMusic, pauseMusic, musicVolumeLabel, musicVolume, musicVolumeValue, musicMessage);
    const profileLabel = document.createElement('label'); profileLabel.htmlFor = 'termuxGraphicsProfile'; profileLabel.textContent = 'Qualidade da imagem · tela limpa em retrato';
    const profile = document.createElement('select'); profile.id = 'termuxGraphicsProfile';
    for (const [value, text] of [['gt3_live', 'GT3 LIVE · 720 × 1280 · limite 30 FPS'], ['gt3_detail', 'GT3 nítido · 864 × 1536 · limite 30 FPS'], ['gt3_high', 'GT3 alta nitidez · 1072 × 1920 · limite 30 FPS'], ['balanced', 'Equilibrado · 720 × 1280'], ['light', 'Leve · 640 × 1136'], ['live', 'Modo LIVE · 640 × 1136 · limite 45 FPS'], ['sharp', 'Mais nítido · 864 × 1536'], ['stable', 'Estável · 640 × 1136 · limite 30 FPS'], ['clear', '720p · limite 45 FPS'], ['quality30', 'Mais nítido · 864 × 1536 · limite 30 FPS']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; profile.append(option);
    }
    const saveProfile = document.createElement('button'); saveProfile.type = 'button'; saveProfile.id = 'termuxSaveProfile'; saveProfile.textContent = 'Salvar qualidade';
    const profileMessage = document.createElement('p'); profileMessage.id = 'termuxProfileStatus';
    const profileBox = document.createElement('div'); profileBox.hidden = true;
    profileBox.append(profileLabel, profile, saveProfile, profileMessage);
    fetch('/termux/presentation').then(r => {if (!r.ok) throw new Error('Exibição não disponível nesta revisão.'); return r.json();}).then(body => {profile.value = body.settings.profile; profileBox.hidden = false;}).catch(() => {});
    saveProfile.addEventListener('click', async () => {
      saveProfile.disabled = true;
      try {
        const response = await fetch('/termux/presentation', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({profile: profile.value})});
        const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar.');
        profileMessage.textContent = 'Salvo. Use Fechar janela do jogo e depois Abrir jogo original para aplicar. O modo leve reduz a carga gráfica; os FPS reais dependem do aparelho.';
      } catch (error) {profileMessage.textContent = error.message;} finally {saveProfile.disabled = false;}
    });
    card.append(title, message, deviceMessage, start, stop, profileBox, sound, speech, testMessage, musicBox);
    const pacing = document.createElement('fieldset'); pacing.hidden = true;
    const pacingTitle = document.createElement('legend'); pacingTitle.textContent = 'Ritmo das respostas e câmera';
    const pacingMode = document.createElement('select'); pacingMode.id = 'termuxReplyMode';
    for (const [value, text] of [['direct', 'Resposta direta · menos espera e trocas de foco'], ['dialogue', 'Diálogo original · usuário lê, cobra responde']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; pacingMode.append(option);
    }
    const pacingSave = document.createElement('button'); pacingSave.type = 'button'; pacingSave.textContent = 'Salvar ritmo'; pacingSave.id = 'termuxSaveReplyMode';
    const pacingMessage = document.createElement('p'); pacingMessage.id = 'termuxReplyModeStatus';
    fetch('/termux/live-tuning').then(async r => {if (!r.ok) return; const b = await r.json(); pacingMode.value = b.settings.reply_mode; pacing.hidden = false;}).catch(() => {});
    pacingSave.addEventListener('click', async () => {
      pacingSave.disabled = true;
      try {const r = await fetch('/termux/live-tuning', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({reply_mode: pacingMode.value})}); const b = await r.json(); if (!r.ok) throw new Error(b.detail || 'Falha ao salvar.'); pacingMessage.textContent = 'Salvo para os próximos comentários. Nomes e personagens continuam aparecendo; o modo direto evita a leitura em voz alta antes da resposta.';}
      catch (error) {pacingMessage.textContent = error.message;} finally {pacingSave.disabled = false;}
    });
    pacing.append(pacingTitle, pacingMode, pacingSave, pacingMessage); card.append(pacing);
    const loadBox = document.createElement('fieldset'); loadBox.hidden = true;
    const loadTitle = document.createElement('legend'); loadTitle.textContent = 'LIVE movimentada · fila e nomes';
    const loadToggleLabel = document.createElement('label'); const loadToggle = document.createElement('input'); loadToggle.type = 'checkbox'; loadToggle.id = 'termuxBusyLive'; loadToggle.style.width = 'auto';
    loadToggleLabel.append(loadToggle, ' Preparar uma resposta adiantada e priorizar perguntas recentes');
    const loadSave = document.createElement('button'); loadSave.type = 'button'; loadSave.id = 'termuxLoadSave'; loadSave.textContent = 'Salvar modo da LIVE';
    const loadMessage = document.createElement('p'); loadMessage.id = 'termuxLoadStatus';
    fetch('/termux/live-load').then(async r => {if (!r.ok) return; const b = await r.json(); loadToggle.checked = b.settings.busy_live; loadMessage.textContent = b.note; loadBox.hidden = false;}).catch(() => {});
    loadSave.onclick = async () => {try {const r = await fetch('/termux/live-load', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({busy_live:loadToggle.checked})}); const b = await r.json(); if(!r.ok)throw new Error(b.detail);loadMessage.textContent='Modo salvo. '+b.note;}catch(e){loadMessage.textContent=e.message;}};
    const nameLabel = document.createElement('label'); nameLabel.htmlFor = 'termuxNameRaw'; nameLabel.textContent = 'Nome que está sendo soletrado';
    const nameRaw = document.createElement('input'); nameRaw.id = 'termuxNameRaw'; nameRaw.placeholder = 'Ex.: G U S T A V O'; nameRaw.maxLength = 100;
    const namePreview = document.createElement('button'); namePreview.type = 'button'; namePreview.id = 'termuxNamePreview'; namePreview.textContent = 'Conferir nome falado · sem gerar áudio';
    const userLabel = document.createElement('label'); userLabel.htmlFor = 'termuxNameUser'; userLabel.textContent = '@ do usuário para uma pronúncia personalizada';
    const nameUser = document.createElement('input'); nameUser.id = 'termuxNameUser'; nameUser.placeholder = '@gustavo123';
    const aliasLabel = document.createElement('label'); aliasLabel.htmlFor = 'termuxNameAlias'; aliasLabel.textContent = 'Como falar';
    const nameAlias = document.createElement('input'); nameAlias.id = 'termuxNameAlias'; nameAlias.placeholder = 'Gustavo';
    const aliasSave = document.createElement('button'); aliasSave.type = 'button'; aliasSave.id = 'termuxNameSave'; aliasSave.textContent = 'Salvar pronúncia para esse usuário';
    const nameMessage = document.createElement('p'); nameMessage.id = 'termuxNameStatus';
    async function nameRequest(save) {try {const p={name:nameRaw.value};if(save){p.username=nameUser.value;p.alias=nameAlias.value;}const r=await fetch('/termux/spoken-name',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});const b=await r.json();if(!r.ok)throw new Error(b.detail);nameMessage.textContent=(b.saved?'Pronúncia salva: ':'Nome falado: ')+b.spoken+'. Nome, foto e ranking permanecem iguais.';}catch(e){nameMessage.textContent=e.message;}}
    namePreview.onclick=()=>nameRequest(false);aliasSave.onclick=()=>nameRequest(true);
    const director = document.createElement('a'); director.href='/termux/director'; director.target='_blank'; director.rel='noopener'; director.id='termuxDirector'; director.textContent='Abrir painel do operador · espectadores e FPS'; director.style.display='block'; director.style.padding='14px 0';
    const directorNote=document.createElement('small');directorNote.textContent='Contador fora do jogo. Captura da tela inteira do celular pode mostrar o navegador; captura somente do jogo é necessária para separá-lo.';
    loadBox.append(loadTitle,loadToggleLabel,loadSave,loadMessage,nameLabel,nameRaw,namePreview,userLabel,nameUser,aliasLabel,nameAlias,aliasSave,nameMessage,director,directorNote);
    card.append(loadBox);
    const perfBox=document.createElement('fieldset');perfBox.hidden=true;
    const perfTitle=document.createElement('legend');perfTitle.textContent='GT3 · recursos e diagnóstico';
    const perfNote=document.createElement('p');perfNote.textContent='RAM livre não mede o gargalo. O diagnóstico mostra FPS, memória e CPU dos processos próprios. 100% de CPU corresponde a um núcleo.';
    const threadLabel=document.createElement('label');threadLabel.htmlFor='termuxTextThreads';threadLabel.textContent='Threads da IA local · aplica após reiniciar o iniciador';
    const threads=document.createElement('select');threads.id='termuxTextThreads';for(const n of [1,2,3,4]){const o=document.createElement('option');o.value=n;o.textContent=n+' thread(s)';threads.append(o);}
    const niceLabel=document.createElement('label');const nice=document.createElement('input');nice.type='checkbox';nice.style.width='auto';nice.id='termuxTextNice';niceLabel.append(nice,' Dar prioridade de CPU ao jogo e áudio quando concorrem com Qwen');
    const perfSave=document.createElement('button');perfSave.type='button';perfSave.id='termuxPerfSave';perfSave.textContent='Salvar uso da IA';
    const perfRead=document.createElement('button');perfRead.type='button';perfRead.id='termuxPerfRead';perfRead.textContent='Iniciar medição de 15 segundos';
    const perfMessage=document.createElement('p');perfMessage.id='termuxPerfStatus';perfMessage.style.whiteSpace='pre-wrap';
    async function perfRequest(path,payload){const r=await fetch(path,payload?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}:{});const b=await r.json();if(!r.ok)throw new Error(b.detail||'Diagnóstico indisponível.');return b;}
    fetch('/termux/performance/settings').then(async r=>{if(!r.ok)return;const b=await r.json();threads.value=b.settings.text_threads;nice.checked=b.settings.text_nice>0;perfBox.hidden=false;}).catch(()=>{});
    perfSave.onclick=async()=>{try{await perfRequest('/termux/performance/settings',{text_threads:Number(threads.value),text_batch_threads:Number(threads.value),text_nice:nice.checked?5:0});perfMessage.textContent='Salvo. Reinicie o iniciador para aplicar aos serviços que ele cria. Modelos, voz e serviços externos foram preservados.';}catch(e){perfMessage.textContent=e.message;}};
    let perfSamples=[];
    const perfDownload=document.createElement('button');perfDownload.type='button';perfDownload.id='termuxPerfDownload';perfDownload.textContent='Baixar diagnóstico GT3';perfDownload.disabled=true;
    perfDownload.onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify({scope:'Medição durante uso; não comprova desempenho em outras cenas. CPU 100% = um núcleo. GPU = todo o aparelho.',samples:perfSamples},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='COFRA_GT3_DIAGNOSTICO.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
    function showPerf(report){perfSamples=report.samples||[];const b=perfSamples.at(-1);perfDownload.disabled=!b;if(!b)return;perfMessage.textContent=(report.running?'Medindo…':'Medição encerrada.')+' '+perfSamples.length+'/6 · pode deixar o jogo visível no Termux:X11.\nFPS: '+(b.render.fps??'aguardando')+' · GPU: '+(b.render.observed_renderer||'aguardando')+'\n'+b.processes.map(p=>p.label+': CPU '+(p.cpu_percent_one_core??'primeira amostra')+'% · RAM '+p.rss_mb+' MB · '+p.threads+' threads · CPUs '+p.allowed_cpus).join('\n')+'\nMemória disponível: '+(b.system.available_memory_mb??'indisponível')+' MB'+(report.error?'\n'+report.error:'');}
    perfRead.onclick=async()=>{perfRead.disabled=true;try{let report=await perfRequest('/termux/performance/record',{});perfMessage.textContent='Medição iniciada no servidor. Volte ao jogo durante 15 segundos e retorne ao painel.';while(report.running){await new Promise(resolve=>setTimeout(resolve,3000));report=await perfRequest('/termux/performance/record');showPerf(report);}}catch(e){perfMessage.textContent=e.message;}finally{perfRead.disabled=false;}};
    fetch('/termux/performance/record').then(r=>r.json()).then(showPerf).catch(()=>{});
    const engineSelect=document.createElement('select');engineSelect.id='termuxEngine';
    for(const [value,label] of [['gl_compatibility','OpenGL / Zink · já confirmado no GT3'],['mobile','Vulkan direto / Mobile · TESTE no aparelho']]){const option=document.createElement('option');option.value=value;option.textContent=label;engineSelect.append(option);}
    const engineSave=document.createElement('button');engineSave.type='button';engineSave.id='termuxEngineSave';engineSave.textContent='Salvar motor gráfico para a próxima abertura';
    const engineNote=document.createElement('p');engineNote.textContent='Vulkan direto carregou o jogo original no teste Linux. Ganho, imagem e estabilidade no GT3 ainda precisam de teste. Se piorar ou fechar, volte para OpenGL e abra novamente. Não é aplicado automaticamente.';
    fetch('/termux/game/engine').then(r=>r.json()).then(b=>{engineSelect.value=b.configured;}).catch(()=>{});
    engineSave.onclick=async()=>{try{await perfRequest('/termux/game/engine',{renderer:engineSelect.value});perfMessage.textContent='Motor salvo. Feche e abra somente a janela do jogo para aplicar. A mudança é reversível pelo mesmo seletor.';}catch(e){perfMessage.textContent=e.message;}};
    const studioHelp=document.createElement('p');studioHelp.textContent='Cofra Studio: rode o jogo aqui e transmita pelo aplicativo Android. A ponte de áudio envia somente o mixer do jogo para o app local; não altera o som que você ouve.';
    perfBox.append(perfTitle,perfNote,threadLabel,threads,niceLabel,perfSave,perfRead,perfMessage,perfDownload,engineSelect,engineSave,engineNote,studioHelp);card.append(perfBox);
    const sceneBox=document.createElement('fieldset');sceneBox.hidden=true;sceneBox.id='termuxSceneBox';
    const sceneTitle=document.createElement('legend');sceneTitle.textContent='Arena 3D · detalhe e fluidez';
    const sceneNote=document.createElement('p');sceneNote.textContent='Ajusta o detalhe interno do 3D e mantém o painel na resolução da janela. Decoração nas bordas, em lotes, sem novas luzes reais ou sombras. O cenário e os modelos originais continuam presentes.';
    function sceneCheck(id,text){const label=document.createElement('label');const input=document.createElement('input');input.type='checkbox';input.id=id;input.style.width='auto';label.append(input,' '+text);return [label,input];}
    const [sceneEnabledLabel,sceneEnabled]=sceneCheck('termuxSceneEnabled','Ativar complemento gráfico');
    const scenePreset=document.createElement('select');scenePreset.id='termuxScenePreset';scenePreset.setAttribute('aria-label','Perfil de detalhe 3D');
    for(const [value,label] of [['fluid','GT3 fluido · 3D adaptativo · limite 30 FPS'],['balanced','Equilibrado · mais detalhe · limite 30 FPS'],['detail','Mais detalhe · maior custo gráfico · limite 30 FPS']]){const o=document.createElement('option');o.value=value;o.textContent=label;scenePreset.append(o);}
    const [sceneDecorLabel,sceneDecor]=sceneCheck('termuxSceneDecor','Detalhes e sinalização nas bordas da arena');
    const [sceneAdaptiveLabel,sceneAdaptive]=sceneCheck('termuxSceneAdaptive','Ajustar a resolução interna do 3D durante a partida');
    const [sceneTerrainLabel,sceneTerrain]=sceneCheck('termuxSceneTerrain','Filtrar o terreno à distância para reduzir cintilação');
    const [sceneColorsLabel,sceneColors]=sceneCheck('termuxSceneColors','Suavizar as cores da grama');
    const sceneSave=document.createElement('button');sceneSave.type='button';sceneSave.id='termuxSceneSave';sceneSave.textContent='Salvar visual · aplica ao reabrir o jogo';
    const sceneOriginal=document.createElement('button');sceneOriginal.type='button';sceneOriginal.id='termuxSceneOriginal';sceneOriginal.textContent='Desativar complemento · manter visual original';
    const sceneRead=document.createElement('button');sceneRead.type='button';sceneRead.id='termuxSceneRead';sceneRead.textContent='Atualizar medição do cenário';
    const sceneDownload=document.createElement('button');sceneDownload.type='button';sceneDownload.id='termuxSceneDownload';sceneDownload.textContent='Baixar diagnóstico gráfico';sceneDownload.disabled=true;
    const sceneStatus=document.createElement('p');sceneStatus.id='termuxSceneStatus';sceneStatus.style.whiteSpace='pre-wrap';
    const sceneX11=document.createElement('p');sceneX11.textContent='Termux:X11: tela em retrato, teclas extras ocultas e ampliação bilinear quando disponível. Não é necessário trocar o APK. O motor Vulkan/OpenGL continua no seletor acima.';
    let sceneReport=null;
    function showScene(b,load=false){sceneReport=b;sceneBox.hidden=false;sceneDownload.disabled=false;if(load){sceneEnabled.checked=b.settings.enabled;scenePreset.value=b.settings.preset;sceneDecor.checked=b.settings.decorations;sceneAdaptive.checked=b.settings.adaptive_resolution;sceneTerrain.checked=b.settings.terrain_filtering;sceneColors.checked=b.settings.terrain_colors;}const r=b.runtime;sceneStatus.textContent=r?'Última medição: '+b.runtime_age_seconds+' s atrás · '+r.renderer+'\n3D observado: '+Math.round(r.scale_observed*100)+'% · FPS do motor: '+r.fps_engine+' · quadro médio: '+r.frame_ms_average+' ms · p95: '+r.frame_ms_p95+' ms\nDecoração: '+r.audit.decor_instances+' peças em '+r.audit.decor_batches+' lotes · texturas do terreno preparadas: '+r.audit.terrain_textures_mipmapped+'\nSão medidas do motor; a fluidez vista na tela Android ainda precisa ser conferida.':'Sem medição desta abertura. Salve o perfil, feche e abra a janela do jogo. A preparação espera a câmera original e não altera o HUD.';if(b.warning)sceneStatus.textContent=b.warning+'\n'+sceneStatus.textContent;}
    fetch('/termux/scene-graphics').then(r=>{if(!r.ok)throw new Error('não disponível');return r.json();}).then(b=>showScene(b,true)).catch(()=>{});
    sceneSave.onclick=async()=>{sceneSave.disabled=true;try{showScene(await perfRequest('/termux/scene-graphics',{enabled:sceneEnabled.checked,preset:scenePreset.value,decorations:sceneDecor.checked,adaptive_resolution:sceneAdaptive.checked,terrain_filtering:sceneTerrain.checked,terrain_colors:sceneColors.checked}),true);sceneStatus.textContent='Salvo. Feche e abra somente a janela do jogo para aplicar; a voz e as músicas são preservadas.';}catch(e){sceneStatus.textContent=e.message;}finally{sceneSave.disabled=false;}};
    sceneOriginal.onclick=async()=>{try{showScene(await perfRequest('/termux/scene-graphics',{enabled:false}),true);sceneStatus.textContent='Complemento desativado para a próxima abertura. Feche e abra a janela para restaurar a renderização original.';}catch(e){sceneStatus.textContent=e.message;}};
    sceneRead.onclick=async()=>{try{showScene(await perfRequest('/termux/scene-graphics'));}catch(e){sceneStatus.textContent=e.message;}};
    sceneDownload.onclick=()=>{if(!sceneReport)return;const url=URL.createObjectURL(new Blob([JSON.stringify(sceneReport,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='COFRA_GRAFICOS_GT3.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
    sceneBox.append(sceneTitle,sceneNote,sceneEnabledLabel,scenePreset,sceneDecorLabel,sceneAdaptiveLabel,sceneTerrainLabel,sceneColorsLabel,sceneSave,sceneOriginal,sceneRead,sceneStatus,sceneDownload,sceneX11);card.append(sceneBox);
    const responseBox=document.createElement('fieldset');responseBox.hidden=true;responseBox.id='termuxResponseBox';
    const responseTitle=document.createElement('legend');responseTitle.textContent='Tempo de resposta · IA, voz e câmera';
    const responseNote=document.createElement('p');responseNote.textContent='A geração local termina no tamanho aproveitável da fala. Quando livre, o personagem pode aparecer antes de baixar a foto. Não muda o modelo nem a voz. Durante outra fala, o próximo usuário aguarda sua vez.';
    const boundedLabel=document.createElement('label');const bounded=document.createElement('input');bounded.type='checkbox';bounded.style.width='auto';bounded.id='termuxBoundedGeneration';boundedLabel.append(bounded,' Evitar gerar texto que seria descartado');
    const focusLabel=document.createElement('label');const earlyFocus=document.createElement('input');earlyFocus.type='checkbox';earlyFocus.style.width='auto';earlyFocus.id='termuxEarlyFocus';focusLabel.append(earlyFocus,' Mostrar o personagem antes de terminar a resposta, quando livre');
    const responseSave=document.createElement('button');responseSave.type='button';responseSave.id='termuxResponseSave';responseSave.textContent='Salvar ajustes de resposta';
    const responseRead=document.createElement('button');responseRead.type='button';responseRead.id='termuxResponseRead';responseRead.textContent='Atualizar tempos das últimas respostas';
    const responseStatus=document.createElement('p');responseStatus.id='termuxResponseStatus';responseStatus.style.whiteSpace='pre-wrap';
    const responseDownload=document.createElement('button');responseDownload.type='button';responseDownload.id='termuxResponseDownload';responseDownload.textContent='Baixar diagnóstico de respostas';responseDownload.disabled=true;
    let responseReport=null;
    function showResponses(b,loadSettings=false){responseReport=b;responseBox.hidden=false;responseDownload.disabled=false;if(loadSettings){bounded.checked=b.settings.bounded_generation;earlyFocus.checked=b.settings.early_focus;}const rows=b.traces||[];const last=rows.at(-1);const seconds=n=>n==null?'aguardando':(n/1000).toFixed(2)+' s';responseStatus.textContent='IA: '+b.providers.text+' · voz: '+b.providers.voice+' · origem Termux: '+(b.termux_origin||'não informada')+'\n'+(last?'Última resposta: espera na fila '+seconds(last.queue_wait_ms)+'; IA '+seconds(last.ai_ms)+'; preparação da voz '+seconds(last.tts_ms)+'.\nDesde o início do atendimento: pedido de personagem '+seconds(last.viewer_requested_ms)+'; áudio pronto '+seconds(last.audio_ready_ms)+'; início confirmado pelo jogo '+seconds(last.speech_started_ms)+'.'+(last.error?'\nFalha: '+last.error:''):'Ainda não houve comentário atendido nesta sessão. Os testes isolados da IA não entram neste histórico.')+'\nO personagem aparecer não confirma que a câmera chegou até ele. O arquivo não inclui nomes, mensagens ou chaves.';}
    async function readResponses(loadSettings=false){showResponses(await perfRequest('/termux/responsiveness'),loadSettings);}
    fetch('/termux/responsiveness').then(r=>{if(!r.ok)throw new Error('indisponível');return r.json();}).then(b=>showResponses(b,true)).catch(()=>{});
    responseRead.onclick=()=>readResponses().catch(e=>{responseStatus.textContent=e.message;});
    responseSave.onclick=async()=>{responseSave.disabled=true;try{showResponses(await perfRequest('/termux/responsiveness',{bounded_generation:bounded.checked,early_focus:earlyFocus.checked}),true);}catch(e){responseStatus.textContent=e.message;}finally{responseSave.disabled=false;}};
    responseDownload.onclick=()=>{if(!responseReport)return;const url=URL.createObjectURL(new Blob([JSON.stringify(responseReport,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='COFRA_TEMPOS_RESPOSTAS.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
    responseBox.append(responseTitle,responseNote,boundedLabel,focusLabel,responseSave,responseRead,responseStatus,responseDownload);card.append(responseBox);
    status.closest('section').before(card);
    await refresh(); setInterval(() => refresh().catch(() => {}), 5000);
  }).catch(() => {});
})();
