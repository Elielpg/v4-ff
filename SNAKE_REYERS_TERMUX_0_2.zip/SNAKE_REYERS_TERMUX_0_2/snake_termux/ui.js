(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const status = byId('openaiStatus');
  const key = byId('openaiApiKey');
  if (!status || !key) return;
  status.closest('section').classList.add('termux-ai-card');
  const styles = document.createElement('style');
  styles.textContent = '.termux-ai-card,.termux-ai-card *{box-sizing:border-box}.termux-ai-card input,.termux-ai-card select,.termux-ai-card audio{max-width:100%}.termux-ai-card fieldset{min-width:0;padding:12px;margin:16px 0 0}.termux-ai-card audio{display:block;margin-top:10px;width:100%}.termux-ai-card button{white-space:normal}';
  document.head.append(styles);
  key.hidden = true;
  key.style.setProperty('display', 'none', 'important');
  key.disabled = true;
  key.value = '';
  const keyLabel = document.querySelector('label[for="openaiApiKey"]');
  if (keyLabel) {keyLabel.hidden = true; keyLabel.style.setProperty('display', 'none', 'important');}
  const portLabel = document.createElement('label');
  portLabel.htmlFor = 'termuxQwenPort';
  portLabel.textContent = 'Porta do Qwen local';
  const port = document.createElement('input');
  port.id = 'termuxQwenPort'; port.type = 'number'; port.min = '1024'; port.max = '65535'; port.value = '8081';
  key.after(portLabel, port);
  byId('openaiModel').placeholder = 'auto · detectar o modelo já instalado';
  const note = document.createElement('p');
  note.textContent = 'Qwen local no Termux. Use auto para detectar o modelo. Não precisa de chave de API.';
  status.parentElement.prepend(note);

  window.renderOpenAISettings = function (settings) {
    if (document.activeElement !== byId('openaiModel')) byId('openaiModel').value = settings.model || 'auto';
    if (document.activeElement !== port) port.value = settings.local_port || 8081;
    byId('openaiEnabled').checked = !!settings.enabled;
    const local = settings.local_status || {};
    status.textContent = !settings.enabled ? 'IA local desativada.' : local.ready === true ? 'Qwen local conectado · ' + (local.selected_model || settings.model) : local.ready === false ? (local.last_error || 'Qwen local indisponível. Confira o serviço e a porta.') : 'IA local habilitada; toque em Detectar Qwen para conferir a conexão.';
  };
  window.saveOpenAISettings = async function (disable = false) {
    const response = await fetch('/api/settings/openai', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: 'local', enabled: disable ? false : byId('openaiEnabled').checked, model: byId('openaiModel').value.trim() || 'auto', local_port: Number(port.value)})});
    const body = await response.json();
    if (!response.ok || body.ok === false) throw new Error(body.error || body.detail || 'Não foi possível salvar.');
    window.renderOpenAISettings(body.settings);
    return body.settings;
  };
  function button(id, text, handler) {
    const old = byId(id), replacement = old.cloneNode(true);
    replacement.textContent = text;
    old.replaceWith(replacement);
    replacement.addEventListener('click', async () => {try {await handler();} catch (error) {status.textContent = error.message;}});
  }
  button('openaiSave', 'Salvar IA local', () => window.saveOpenAISettings(false));
  button('openaiRemove', 'Desativar IA local', () => window.saveOpenAISettings(true));
  const detect = document.createElement('button'); detect.id = 'termuxQwenDetect'; detect.type = 'button'; detect.textContent = 'Detectar Qwen local';
  byId('openaiSave').after(detect);
  detect.addEventListener('click', async () => {
    detect.disabled = true;
    try {
      await window.saveOpenAISettings(false);
      const response = await fetch('/termux/local-ai/detect', {method: 'POST'});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'Não foi possível verificar a IA local.');
      window.renderOpenAISettings(body.settings);
    } catch (error) {status.textContent = error.message;} finally {detect.disabled = false;}
  });
  const question = document.createElement('input'); question.id = 'termuxQwenQuestion'; question.maxLength = 180; question.placeholder = 'Teste: quanto é sete vezes oito?';
  const ask = document.createElement('button'); ask.id = 'termuxQwenAsk'; ask.type = 'button'; ask.textContent = 'Testar resposta local';
  status.after(question, ask);
  ask.addEventListener('click', async () => {
    ask.disabled = true; status.textContent = 'Aguardando o Qwen local…';
    try {
      const response = await fetch('/termux/local-ai/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: question.value})});
      const body = await response.json();
      if (!response.ok) throw new Error(body.detail || 'A IA local não respondeu.');
      status.textContent = body.text;
    } catch (error) {status.textContent = error.message;} finally {ask.disabled = false;}
  });
  const voiceBox = document.createElement('fieldset');
  const legend = document.createElement('legend'); legend.textContent = 'Voz local já instalada';
  const voiceProvider = document.createElement('select'); voiceProvider.id = 'termuxVoiceProvider';
  for (const [value, title] of [['piper-local', 'Piper local · sem clonagem'], ['xtts', 'XTTS original · exige instalação compatível']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = title; voiceProvider.append(option);
  }
  const voicePort = document.createElement('input'); voicePort.id = 'termuxVoicePort'; voicePort.type = 'number'; voicePort.min = '1024'; voicePort.max = '65535'; voicePort.value = '8083';
  const voiceLabel = document.createElement('label'); voiceLabel.htmlFor = voicePort.id; voiceLabel.textContent = 'Porta do Piper (geralmente 8082 ou 8083)';
  const voiceMessage = document.createElement('p'); voiceMessage.id = 'termuxVoiceStatus';
  const detectVoice = document.createElement('button'); detectVoice.type = 'button'; detectVoice.textContent = 'Salvar e detectar voz'; detectVoice.id = 'termuxVoiceDetect';
  const testVoice = document.createElement('button'); testVoice.type = 'button'; testVoice.textContent = 'Ouvir teste de voz'; testVoice.id = 'termuxVoiceTest';
  const player = document.createElement('audio'); player.controls = true; player.id = 'termuxVoicePlayer'; player.preload = 'none';
  const resume = document.createElement('button'); resume.type = 'button'; resume.textContent = 'Tocar áudio preparado'; resume.hidden = true;
  let audioURL = null;
  async function saveVoice() {
    const response = await fetch('/termux/voice', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({provider: voiceProvider.value, port: Number(voicePort.value)})});
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar a voz.');
  }
  detectVoice.addEventListener('click', async () => {
    detectVoice.disabled = true;
    try {
      await saveVoice();
      if (voiceProvider.value === 'xtts') {voiceMessage.textContent = 'XTTS original selecionado. O teste depende do modelo e da referência originais.'; return;}
      const response = await fetch('/termux/voice/detect', {method: 'POST'});
      const body = await response.json(); voiceMessage.textContent = body.message;
    } catch (error) {voiceMessage.textContent = error.message;} finally {detectVoice.disabled = false;}
  });
  testVoice.addEventListener('click', async () => {
    testVoice.disabled = true; voiceMessage.textContent = 'Gerando áudio local…';
    try {
      await saveVoice();
      const response = await fetch('/termux/voice/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: 'Olá! Rosa, relógio, carro e clarão. A cobra está pronta para conversar.'})});
      if (!response.ok) {const error = await response.json(); throw new Error(error.detail || 'Falha na voz local.');}
      if (audioURL) URL.revokeObjectURL(audioURL);
      audioURL = URL.createObjectURL(await response.blob()); player.src = audioURL;
      voiceMessage.textContent = 'Áudio gerado. Use o player para ouvir.';
      try {await player.play(); resume.hidden = true;} catch (_) {resume.hidden = false; voiceMessage.textContent = 'Áudio pronto. Toque em Tocar áudio preparado para autorizar a reprodução.';}
    } catch (error) {voiceMessage.textContent = error.message;} finally {testVoice.disabled = false;}
  });
  resume.addEventListener('click', () => {player.play().then(() => {resume.hidden = true;}).catch(error => {voiceMessage.textContent = error.message;});});
  voiceBox.append(legend, voiceProvider, voiceLabel, voicePort, detectVoice, testVoice, voiceMessage, player, resume);
  status.parentElement.append(voiceBox);
  fetch('/termux/voice').then(response => response.json()).then(body => {voiceProvider.value = body.provider; voicePort.value = body.port;}).catch(error => {voiceMessage.textContent = error.message;});
  const username = byId('monitorUsername');
  if (username) {
    username.placeholder = '@seu.usuario';
    const label = document.querySelector('label[for="monitorUsername"]');
    if (label) label.textContent = '@ do perfil que está ao vivo';
  }
  window.loadOpenAISettings().catch(error => {status.textContent = error.message;});
  fetch('/termux/game').then(async response => {
    if (!response.ok) return;
    const card = document.createElement('section'); card.className = 'card termux-ai-card'; card.style.marginTop = '14px';
    const title = document.createElement('h2'); title.textContent = 'Jogo original · Termux 0.2.5';
    const message = document.createElement('p'); message.id = 'termuxGameStatus';
    const deviceMessage = document.createElement('p'); deviceMessage.id = 'termuxDeviceStatus';
    const start = document.createElement('button'); start.type = 'button'; start.textContent = 'Abrir jogo original';
    const stop = document.createElement('button'); stop.type = 'button'; stop.textContent = 'Fechar janela do jogo';
    async function refresh() {
      const response = await fetch('/termux/game'); const body = await response.json();
      message.textContent = body.running ? (body.bridge_connected ? 'Janela em execução · conectada ao servidor.' : 'Janela em execução · aguardando conexão com o servidor.') : 'Janela parada. Última saída: ' + (body.last_exit_code ?? 'nenhuma') + '. Logs: ' + body.log;
      const gpu = body.device?.graphics, output = body.device?.audio, display = body.device?.display;
      deviceMessage.textContent = gpu ? (gpu.hardware_verified ? 'GPU confirmada: ' + gpu.renderer : gpu.message) + ' · ' + gpu.resolution + ' · limite ' + gpu.max_fps + ' FPS. ' + (display?.message || output?.message || '') : '';
    }
    for (const [button, action] of [[start, 'start'], [stop, 'stop']]) button.addEventListener('click', async () => {
      button.disabled = true;
      try {const r = await fetch('/termux/game/' + action, {method: 'POST'}); const b = await r.json(); if (!r.ok) throw new Error(b.detail || 'Falha no jogo nativo.'); await refresh();}
      catch (error) {message.textContent = error.message;} finally {button.disabled = false;}
    });
    const sound = document.createElement('button'); sound.type = 'button'; sound.textContent = 'Testar som do jogo'; sound.id = 'termuxGameSoundTest';
    const speech = document.createElement('button'); speech.type = 'button'; speech.textContent = 'Testar fala no jogo'; speech.id = 'termuxGameSpeechTest';
    const testMessage = document.createElement('p'); testMessage.id = 'termuxGameAudioStatus';
    for (const [button, path] of [[sound, '/termux/audio/test'], [speech, '/termux/audio/speech-test']]) button.addEventListener('click', async () => {
      button.disabled = true; testMessage.textContent = 'Preparando teste…';
      try {
        const response = await fetch(path, {method: 'POST'}); const body = await response.json();
        if (!response.ok) throw new Error(body.detail || 'Falha no teste.');
        testMessage.textContent = body.queued ? 'Fala enviada à fila do jogo. Confirme se ouviu.' : body.test_sent ? 'Teste de som enviado. Confirme se ouviu o sinal.' : (body.message || 'A saída não ficou disponível.') + ' ' + (body.errors || []).join(' ');
      } catch (error) {testMessage.textContent = error.message;} finally {button.disabled = false;}
    });
    const musicLabel = document.createElement('label'); musicLabel.htmlFor = 'termuxMusicFile'; musicLabel.textContent = 'Música de fundo · MP3/OGG/WAV · até 200 MB';
    const musicFile = document.createElement('input'); musicFile.id = 'termuxMusicFile'; musicFile.type = 'file'; musicFile.accept = '.mp3,.ogg,.wav';
    const sendMusic = document.createElement('button'); sendMusic.type = 'button'; sendMusic.id = 'termuxMusicUpload'; sendMusic.textContent = 'Adicionar música ao jogo';
    const musicMessage = document.createElement('p'); musicMessage.id = 'termuxMusicStatus';
    fetch('/api/music/runtime').then(r => r.json()).then(body => {
      const music = body.music || body;
      musicMessage.textContent = music.track_count ? music.track_count + ' faixa(s) disponíveis. ' + (music.enabled ? 'Música ativada.' : 'Música pausada; ative nos controles de música do painel.') : 'Nenhuma faixa na biblioteca. Adicione uma música do celular.';
    }).catch(() => {});
    sendMusic.addEventListener('click', async () => {
      if (!musicFile.files[0]) {musicMessage.textContent = 'Selecione uma música do celular.'; return;}
      if (musicFile.files[0].size > 200 * 1024 * 1024) {musicMessage.textContent = 'O arquivo deve ter até 200 MB.'; return;}
      sendMusic.disabled = true; musicMessage.textContent = 'Enviando música…';
      try {
        const form = new FormData(); form.append('file', musicFile.files[0]);
        const response = await fetch('/termux/music/upload', {method: 'POST', body: form}); const body = await response.json();
        if (!response.ok) throw new Error(body.detail || 'Não foi possível adicionar a música.');
        musicMessage.textContent = 'Música adicionada. ' + body.track_count + ' faixa(s) disponíveis.';
      } catch (error) {musicMessage.textContent = error.message;} finally {sendMusic.disabled = false;}
    });
    const profileLabel = document.createElement('label'); profileLabel.htmlFor = 'termuxGraphicsProfile'; profileLabel.textContent = 'Qualidade da imagem · tela limpa em retrato';
    const profile = document.createElement('select'); profile.id = 'termuxGraphicsProfile';
    for (const [value, text] of [['balanced', 'Equilibrado · 720 × 1280'], ['light', 'Leve · 640 × 1136'], ['sharp', 'Mais nítido · 864 × 1536']]) {
      const option = document.createElement('option'); option.value = value; option.textContent = text; profile.append(option);
    }
    const saveProfile = document.createElement('button'); saveProfile.type = 'button'; saveProfile.id = 'termuxSaveProfile'; saveProfile.textContent = 'Salvar qualidade';
    const profileMessage = document.createElement('p'); profileMessage.id = 'termuxProfileStatus';
    const profileBox = document.createElement('div'); profileBox.hidden = true;
    profileBox.append(profileLabel, profile, saveProfile, profileMessage);
    fetch('/termux/presentation').then(r => {if (!r.ok) throw new Error('Exibição não disponível nesta revisão.'); return r.json();}).then(body => {profile.value = body.settings.profile; profileBox.hidden = false;}).catch(() => {});
    saveProfile.addEventListener('click', async () => {
      saveProfile.disabled = true;
      try {
        const response = await fetch('/termux/presentation', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({profile: profile.value})});
        const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'Não foi possível salvar.');
        profileMessage.textContent = 'Salvo. Use Fechar janela do jogo e depois Abrir jogo original para aplicar. O modo leve reduz a carga gráfica; os FPS reais dependem do aparelho.';
      } catch (error) {profileMessage.textContent = error.message;} finally {saveProfile.disabled = false;}
    });
    card.append(title, message, deviceMessage, start, stop, profileBox, sound, speech, testMessage, musicLabel, musicFile, sendMusic, musicMessage);
    status.closest('section').before(card);
    await refresh(); setInterval(() => refresh().catch(() => {}), 5000);
  }).catch(() => {});
})();
