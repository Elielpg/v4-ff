# Independent, reversible PHONK look using public runtime APIs only.
# No microphone, external-app capture, scene replacement or gameplay mutation.
extends Node
const BeatDetector=preload("phonk_beat.gd")
const SkinShader=preload("phonk_skin.gdshader")
var config: Dictionary={}
var active := false
var detector=BeatDetector.new()
var spectrum: AudioEffectSpectrumAnalyzer
var spectrum_instance: AudioEffectSpectrumAnalyzerInstance
var bus := -1
var clock := 0.0
var reload_time := 0.0
var report_time := 0.0
var pulse := 0.0
var beats := 0
var color_index := 0
var last_manual := -1
var track_id := ""
var track_title := ""
var track_path := ""
var player: AudioStreamPlayer
var main: Node
var skin := ShaderMaterial.new()
var accent := Color("9c2cff")
var overrides: Array=[]
var visited: Dictionary={}
var terrain_materials: Dictionary={}
var pending: Array[Node]=[]
var cameras: Array=[]
var current_camera: Camera3D
var themed_environment: Environment
var sky: GeometryInstance3D
var sky_visible := true
var own_decor: Array=[]
var own_root: Node3D
var revision := ""
var save_error := false

func _ready() -> void:
    skin.shader=SkinShader
    get_tree().node_added.connect(_node_added)
    _reload()

func _exit_tree() -> void:
    _disable()

func _reload() -> void:
    var path := OS.get_environment("SNAKE_PHONK_CONFIG")
    if path.is_empty() or not FileAccess.file_exists(path):return
    var file := FileAccess.open(path,FileAccess.READ)
    if file==null or file.get_length()>65536:return
    var parsed=JSON.parse_string(file.get_as_text())
    if not parsed is Dictionary:return
    config=parsed
    var enabled := bool(config.get("enabled",false))
    if enabled and not active:_enable()
    elif not enabled and active:_disable()
    if not active:return
    skin.set_shader_parameter("base_color",Color(str(config.get("base_color","#08050f"))))
    skin.set_shader_parameter("strength",float(config.get("intensity",.6)))
    var signature := JSON.stringify([config.get("revision",0),config.get("runtime",{})])
    if signature!=revision:
        revision=signature
        _select_color()
    _track()
    _camera()

func _enable() -> void:
    active=true
    main=get_tree().root.get_node_or_null("Cobrinha3D")
    if main!=null:
        player=main.get_node_or_null("MusicPlayer") as AudioStreamPlayer
        sky=main.get_node_or_null("VisibleSkyDome") as GeometryInstance3D
        if sky!=null:sky_visible=sky.visible;sky.visible=false
    pending=[get_tree().root]
    _analyzer()
    _build_neon()
    print("TERMUX_PHONK_READY Music bus only; original game and voice routing preserved")

func _analyzer() -> void:
    bus=AudioServer.get_bus_index("Music")
    if bus<0:return
    spectrum=AudioEffectSpectrumAnalyzer.new()
    spectrum.fft_size=AudioEffectSpectrumAnalyzer.FFT_SIZE_1024
    spectrum.buffer_length=.2
    AudioServer.add_bus_effect(bus,spectrum)
    spectrum_instance=AudioServer.get_bus_effect_instance(bus,AudioServer.get_bus_effect_count(bus)-1) as AudioEffectSpectrumAnalyzerInstance

func _disable() -> void:
    active=false;pulse=0.0;pending.clear()
    # Remove only the effect that this extension owns, never an existing one.
    var current_bus := AudioServer.get_bus_index("Music")
    if current_bus>=0 and spectrum!=null:
        for index in range(AudioServer.get_bus_effect_count(current_bus)-1,-1,-1):
            if AudioServer.get_bus_effect(current_bus,index)==spectrum:AudioServer.remove_bus_effect(current_bus,index)
    spectrum_instance=null;spectrum=null;bus=-1
    for row in overrides:
        if is_instance_valid(row.node):row.node.material_override=row.previous
    overrides.clear();visited.clear();terrain_materials.clear()
    for row in cameras:
        if is_instance_valid(row.node):row.node.environment=row.previous
    cameras.clear();current_camera=null;themed_environment=null
    if is_instance_valid(sky):sky.visible=sky_visible
    for row in own_decor:
        if is_instance_valid(row.node):
            row.node.material_override=row.previous
            for i in range(row.colors.size()):row.node.multimesh.set_instance_color(i,row.colors[i])
    own_decor.clear()
    if is_instance_valid(own_root):own_root.queue_free()
    own_root=null
    detector.reset()

func _node_added(node: Node) -> void:
    if active and node is MeshInstance3D:
        var path := str(node.get_path())
        if "/SnakeHead/" in path or path.ends_with("/ContinuousSnakeBody"):
            pending.append(node)

func _scan() -> void:
    var budget := 96
    while budget>0 and not pending.is_empty():
        budget-=1
        var node: Node=pending.pop_back()
        if not is_instance_valid(node):continue
        for child in node.get_children():pending.append(child)
        if node is MultiMeshInstance3D and "TermuxArenaDetails" in str(node.get_path()):
            var colors: Array=[]
            for i in range(node.multimesh.instance_count):
                colors.append(node.multimesh.get_instance_color(i))
                node.multimesh.set_instance_color(i,Color(1,1,1))
            own_decor.append({"node":node,"previous":node.material_override,"colors":colors})
            node.material_override=_neon_material()
        if not node is MeshInstance3D or node.mesh==null:continue
        var key := node.get_instance_id()
        if visited.has(key) or visited.size()>=4096:continue
        var path := str(node.get_path())
        var snake := path.ends_with("/ContinuousSnakeBody") or "/SnakeHead/" in path
        var excluded := false
        for word in ["eye","pupil","teeth","tooth","tongue","fang","gum","mouthinterior","nostril"]:
            if word in path.to_lower():excluded=true
        # Anonymous meshes in the original head include the eyes and tongue.
        if str(node.name).begins_with("@"):excluded=true
        if snake and not excluded:
            visited[key]=true
            overrides.append({"node":node,"previous":node.material_override})
            node.material_override=skin
        elif not snake:
            var material: Material=node.get_active_material(0) if node.mesh.get_surface_count()>0 else null
            if material is BaseMaterial3D:
                var source: String=material.albedo_texture.resource_path if material.albedo_texture!=null else ""
                var terrain := "/StaticWorldProcedural/" in path
                for group in ["piso","parede","elevacao","grama"]:
                    if source.begins_with("res://assets/textures/"+group+"/"):terrain=true
                if terrain:
                    visited[key]=true
                    var material_key := material.get_instance_id()
                    if not terrain_materials.has(material_key):
                        var copy: BaseMaterial3D=material.duplicate()
                        copy.albedo_color=material.albedo_color*Color(.24,.12,.34)
                        copy.roughness=.85
                        terrain_materials[material_key]=copy
                    overrides.append({"node":node,"previous":node.material_override})
                    node.material_override=terrain_materials[material_key]

func _neon_material() -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
    material.albedo_color=accent
    return material

func _build_neon() -> void:
    # Seven cheap static meshes, no particles, shadow maps or dynamic lights.
    own_root=Node3D.new();own_root.name="TermuxPhonkNeon";add_child(own_root)
    for radius in [13.0,13.3,13.6]:
        var mesh := TorusMesh.new();mesh.inner_radius=radius;mesh.outer_radius=radius+.045
        mesh.rings=64;mesh.ring_segments=6
        var node := MeshInstance3D.new();node.mesh=mesh;node.position.y=.02
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.material_override=_neon_material();own_root.add_child(node)
    for point in [Vector3(-13,1,-13),Vector3(13,1,-13),Vector3(-13,1,13),Vector3(13,1,13)]:
        var mesh := BoxMesh.new();mesh.size=Vector3(.05,2,.05)
        var node := MeshInstance3D.new();node.mesh=mesh;node.position=point
        node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        node.material_override=_neon_material();own_root.add_child(node)

func _camera() -> void:
    var camera := get_viewport().get_camera_3d()
    if camera==null or camera==current_camera:return
    current_camera=camera
    for row in cameras:
        if row.node==camera:
            themed_environment=row.themed
            camera.environment=themed_environment
            return
    var environment: Environment=camera.environment
    if environment==null and main!=null:
        var world := main.get_node_or_null("WorldEnvironment") as WorldEnvironment
        if world!=null:environment=world.environment
    themed_environment=environment.duplicate() if environment!=null else Environment.new()
    themed_environment.background_mode=Environment.BG_COLOR
    themed_environment.background_color=Color("07030f")
    themed_environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    themed_environment.ambient_light_color=Color("9866cc")
    themed_environment.ambient_light_energy=.65
    themed_environment.fog_enabled=false
    themed_environment.glow_enabled=false
    cameras.append({"node":camera,"previous":camera.environment,"themed":themed_environment})
    camera.environment=themed_environment

func _track() -> void:
    if not is_instance_valid(main):return
    # Public runtime state; no script/source/resource extraction.
    var value=main.get("music_current_track")
    if value==null:return
    var path := str(value)
    var table: Dictionary=config.get("runtime",{}).get("tracks",{})
    var row: Dictionary=table.get(path.get_file(),{})
    if path==track_path and str(row.get("id",""))==track_id:return
    track_path=path
    track_id=str(row.get("id",""));track_title=str(row.get("title",path.get_file().get_basename()))
    detector.reset();color_index=0;pulse=0.0
    _select_color()

func _select_color() -> void:
    var colors: Array=config.get("track_palettes",{}).get(track_id,config.get("palette",["#9c2cff","#d653ff","#6333ed"]))
    if colors.size()<2:return
    var mode := str(config.get("color_mode","beat"))
    var index := color_index if mode=="beat" else (absi(track_id.hash()) if mode=="track" else 0)
    accent=Color(str(colors[index%colors.size()]))
    skin.set_shader_parameter("accent",accent)

func _process(delta: float) -> void:
    clock+=delta;reload_time+=delta;report_time+=delta
    if reload_time>=.5:reload_time=0.0;_reload()
    if active:
        if not pending.is_empty():_scan()
        var hit := false
        if config.get("source","music")=="manual":
            var epoch := float(config.get("manual_epoch",0.0))
            var phase := int(floor((Time.get_unix_time_from_system()-epoch)*float(config.get("manual_bpm",140))/60.0))
            hit=last_manual>=0 and phase!=last_manual
            last_manual=phase
        elif spectrum_instance!=null and is_instance_valid(player) and player.playing:
            var bass := spectrum_instance.get_magnitude_for_frequency_range(35,220).length()
            var high := spectrum_instance.get_magnitude_for_frequency_range(1600,6500).length()
            hit=detector.update(bass,high,delta,clock,float(config.get("sensitivity",1.0)))
        if hit:
            beats+=1
            if beats%maxi(1,int(config.get("color_every",1)))==0:color_index+=1;_select_color()
            if config.get("pulses",true):pulse=1.0
        pulse*=exp(-delta/0.15)
        if not config.get("pulses",true):pulse=0.0
        skin.set_shader_parameter("pulse",pulse)
        var brightness := .45+float(config.get("intensity",.6))*(.45+pulse*.8)
        if is_instance_valid(own_root):
            for node in own_root.get_children():node.material_override.albedo_color=accent*brightness
        for row in own_decor:
            if is_instance_valid(row.node):row.node.material_override.albedo_color=accent*brightness
        if themed_environment!=null:themed_environment.ambient_light_energy=.6+pulse*.12*float(config.get("intensity",.6))
    if report_time>=1.0:report_time=0.0;_report()

func _report() -> void:
    var path := OS.get_environment("SNAKE_PHONK_STATUS")
    if path.is_empty():return
    var report := {"at":Time.get_unix_time_from_system(),"enabled":active,"source":config.get("source","music"),"analyzer_bus":"Music" if bus>=0 else "unavailable","playing":is_instance_valid(player) and player.playing,"beats":beats,"pulse":pulse,"color":"#"+accent.to_html(false),"track_id":track_id,"track_title":track_title,"themed_meshes":overrides.size(),"external_app_capture":false,"manual_bpm":config.get("manual_bpm",140)}
    var file := FileAccess.open(path+".tmp",FileAccess.WRITE)
    if file!=null:
        file.store_string(JSON.stringify(report));file.close()
        DirAccess.rename_absolute(path+".tmp",path)
    elif not save_error:save_error=true;push_warning("PHONK status unavailable; game continues")
