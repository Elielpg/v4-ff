// Independent material; the existing floor mesh/UV/texture remain in place.
shader_type spatial;
render_mode diffuse_burley;
uniform sampler2D floor_texture : source_color, filter_linear_mipmap, repeat_enable;
uniform bool use_texture = false;
uniform vec4 floor_tint : source_color = vec4(.24,.12,.34,1.);
uniform vec3 uv_scale = vec3(1.);
uniform vec3 uv_offset = vec3(0.);
uniform vec4 accent : source_color = vec4(.61,.17,1.,1.);
uniform float pulse = 0.;
uniform float flow_time = 0.;
uniform float strength = .8;
varying vec2 arena_position;
void vertex(){arena_position=(MODEL_MATRIX*vec4(VERTEX,1.)).xz;}
void fragment(){
    vec3 texture_color=use_texture?texture(floor_texture,UV*uv_scale.xy+uv_offset.xy).rgb:vec3(.35);
    vec2 cell=abs(fract(arena_position*.5+.5)-.5);
    vec2 width=max(fwidth(arena_position*.5),vec2(.003));
    vec2 lines=1.-smoothstep(vec2(.012),vec2(.024)+width,cell);
    float grid=max(lines.x,lines.y);
    float radial=length(arena_position);
    float wave=pow(max(0.,sin(radial*1.4-flow_time*4.)),14.);
    ALBEDO=texture_color*floor_tint.rgb;
    ROUGHNESS=.8;
    SPECULAR=.25;
    EMISSION=accent.rgb*(grid*(.16+pulse*1.15)+wave*(.02+pulse*.55))*strength;
}
