// Original theme shader. Does not read or copy the game's shaders.
shader_type spatial;
render_mode diffuse_burley;
uniform vec4 base_color : source_color = vec4(.031,.02,.059,1.);
uniform vec4 accent : source_color = vec4(.61,.17,1.,1.);
uniform float pulse = 0.;
uniform float strength = .6;
uniform float flow_time = 0.;
uniform float lightning_strength = 1.2;
uniform float lightning_speed = 1.;
float triangle(float x){return abs(fract(x)*2.-1.);}
void fragment(){
    // Three jagged lanes with travelling packets: no extra meshes or particles.
    // The original body repeats V along its length. Sparse zigs keep the bolts
    // readable rather than producing dense white speckles at phone resolution.
    float along=UV.y*.9;
    float phase=flow_time*lightning_speed;
    float zig=(triangle(along*2.2+floor(phase*8.)*.173)-.5)*.11;
    zig+=(triangle(along*5.7-floor(phase*6.)*.117)-.5)*.05;
    float distance=abs(fract(UV.x*3.+zig)-.5);
    float aa=clamp(fwidth(distance)*.65,.002,.018);
    float core=1.-smoothstep(.014-aa,.014+aa,distance);
    float halo=1.-smoothstep(.018,.075+aa,distance);
    float branch_distance=abs(fract(UV.x*3.+zig*2.+UV.y*.7)-.5);
    float branch=(1.-smoothstep(.005,.012+aa,branch_distance))*(1.-smoothstep(.1,.27,distance));
    float packet=.16+.84*pow(.5+.5*sin(UV.y*7.-phase*7.),4.);
    float bolt=(core+branch*.55)*packet*lightning_strength;
    float rim=pow(1.-max(dot(normalize(NORMAL),normalize(VIEW)),0.),2.1);
    ALBEDO=mix(base_color.rgb,accent.rgb*.4,clamp(rim*.28+bolt*.65,0.,1.));
    ROUGHNESS=.7;
    METALLIC=0.;
    SPECULAR=.25;
    EMISSION=accent.rgb*(rim*.8+halo*packet*lightning_strength*(.55+pulse*1.3))*strength;
    EMISSION+=mix(accent.rgb,vec3(1.),.72)*bolt*(1.1+pulse*4.)*strength;
}
