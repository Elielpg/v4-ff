// Original theme shader. Does not read or copy the game's shaders.
shader_type spatial;
render_mode diffuse_burley;
uniform vec4 base_color : source_color = vec4(.031,.02,.059,1.);
uniform vec4 accent : source_color = vec4(.61,.17,1.,1.);
uniform float pulse = 0.;
uniform float strength = .6;
void fragment(){
    float bands=smoothstep(.85,.98,sin(UV.x*12.566)*.5+.5);
    float rim=pow(1.-max(dot(normalize(NORMAL),normalize(VIEW)),0.),2.1);
    ALBEDO=mix(base_color.rgb,accent.rgb*.3,bands*.12+rim*.25);
    ROUGHNESS=.7;
    METALLIC=0.;
    SPECULAR=.25;
    EMISSION=accent.rgb*(rim*.65+bands*.025+pulse*.4)*strength;
}
