"""Validated local music library. Own runtime hooks; original game is untouched."""
from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import threading
import time
import uuid

MAX_BYTES = 200 * 1024 * 1024
EXTENSIONS = {'.mp3', '.ogg', '.wav', '.m4a', '.aac', '.opus', '.flac'}


def probe(path: Path) -> dict:
    if not shutil.which('ffprobe'):
        raise ValueError('FFprobe não está disponível. Instale o pacote ffmpeg do Termux para preparar músicas.')
    try:
        result = subprocess.run(['ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe',
                                 '-select_streams', 'a:0', '-show_entries',
                                 'stream=codec_name,duration:format=duration', '-of', 'json', str(path)],
                                capture_output=True, text=True, timeout=15)
        info = json.loads(result.stdout) if result.returncode == 0 else {}
        streams = info.get('streams', [])
        if not streams:
            raise ValueError('O arquivo não contém áudio decodificável. Envie outro download da música; renomear para MP3 não converte o áudio.')
        duration = float(info.get('format', {}).get('duration') or streams[0].get('duration') or 0)
        if not math.isfinite(duration) or duration > 4 * 3600:
            raise ValueError('Use uma faixa com duração de até quatro horas.')
        return {'codec': streams[0].get('codec_name'), 'duration': duration}
    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as exc:
        raise ValueError('Não foi possível analisar o áudio. Tente outro arquivo da música.') from exc


class MusicLibrary:
    def __init__(self, runtime, native):
        self.runtime, self.native = runtime, native
        self.file = native.state_dir / 'music-library.json'
        self.lock = threading.RLock()
        self.operation = threading.Lock()
        self.original_message = runtime.websocket_message
        self.original_choose = runtime.choose_session_start_track
        self.progress = {'busy': False, 'message': ''}
        try:
            self.data = json.loads(self.file.read_text())
            if not isinstance(self.data, dict):
                raise ValueError('Invalid library')
        except (OSError, ValueError):
            self.data = {}
        self.data.setdefault('records', {})
        self.data.setdefault('selected', [])
        self.data.setdefault('mode', 'single')
        self.data.setdefault('active', False)

    def save(self):
        self.file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.file.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.data, ensure_ascii=False, indent=2))
        os.replace(temporary, self.file)

    def inventory(self):
        with self.lock:
            records = self.data['records']
            hidden = {r.get('playable') for r in records.values()}
            for entry in self.runtime.track_entries():
                path = str(Path(entry['path']).resolve())
                if path in hidden or re.fullmatch(r'prepared-[0-9a-f]{24}\.ogg', Path(path).name):
                    continue
                key = hashlib.sha256(path.encode()).hexdigest()[:24]
                records.setdefault(key, {'source': path, 'title': entry.get('title') or Path(path).stem})
            return {key: record for key, record in records.items() if Path(record['source']).is_file()}

    def prepare(self, key):
        records = self.inventory()
        if key not in records:
            raise ValueError('Faixa não encontrada na biblioteca.')
        record = records[key]
        source = Path(record['source'])
        fingerprint = [source.stat().st_size, source.stat().st_mtime_ns]
        if record.get('fingerprint') == fingerprint and Path(record.get('playable') or '/nonexistent').is_file():
            return record
        self.progress = {'busy': True, 'message': 'Preparando: ' + record['title']}
        info = probe(source)
        # Even a mislabeled AAC/M4A called .mp3 is decoded by content, then
        # converted to Vorbis, which the original Godot loader supports.
        reusable = source.suffix.lower() == '.ogg' and info['codec'] == 'vorbis'
        if reusable and source.parent.resolve() == self.runtime.BACKGROUND_MUSIC_DIR.resolve():
            target = source
        else:
            if not reusable and not shutil.which('ffmpeg'):
                raise ValueError('FFmpeg não está disponível para converter esta música.')
            directory = self.runtime.BACKGROUND_MUSIC_DIR
            directory.mkdir(parents=True, exist_ok=True)
            target = directory / ('prepared-' + key + '.ogg')
            temporary = target.with_name('.' + target.stem + '-' + uuid.uuid4().hex + '.ogg')
            log_dir = self.native.state_dir / 'logs'
            log_dir.mkdir(parents=True, exist_ok=True)
            try:
                if reusable:
                    shutil.copyfile(source, temporary)
                else:
                    with (log_dir / 'music-conversion.log').open('a') as log:
                        log.write('\nPreparing ' + key + '\n'); log.flush()
                        # Lower only our own preparation child, never Godot,
                        # PulseAudio or processes belonging to another project.
                        prefix = [shutil.which('nice'), '-n', '10'] if shutil.which('nice') else []
                        converted = subprocess.run([*prefix, 'ffmpeg', '-nostdin', '-y', '-hide_banner', '-loglevel', 'error',
                            '-threads', '1', '-filter_threads', '1', '-protocol_whitelist', 'file,pipe',
                            '-i', str(source), '-map', '0:a:0', '-vn', '-sn', '-dn', '-ar', '48000',
                            '-ac', '2', '-c:a', 'libvorbis', '-q:a', '4', '-threads', '1', str(temporary)],
                            stdout=log, stderr=log, timeout=900)
                    if converted.returncode != 0 or not temporary.is_file():
                        raise ValueError('A conversão falhou. O arquivo pode estar incompleto; envie outro download da música.')
                checked = probe(temporary)
                if checked['codec'] != 'vorbis' or temporary.stat().st_size < 128:
                    raise ValueError('O arquivo convertido não passou na validação.')
                os.replace(temporary, target)
            except subprocess.TimeoutExpired as exc:
                raise ValueError('A preparação ultrapassou 15 minutos. Divida a faixa em arquivos menores.') from exc
            finally:
                temporary.unlink(missing_ok=True)
        with self.lock:
            record.update(playable=str(target.resolve()), fingerprint=fingerprint, duration=info['duration'], error='')
            self.save()
        return record

    def prepare_checked(self, key):
        try:
            return self.prepare(key)
        except ValueError as exc:
            with self.lock:
                if key in self.data['records']:
                    self.data['records'][key]['error'] = str(exc)
                    self.save()
            raise

    def message(self):
        with self.lock:
            message = self.original_message()
            if not self.data['active']:
                return message
            payload = dict(message['payload'])
            records = self.inventory()
            selected = [key for key in self.data['selected'] if key in records]
            if self.data['mode'] == 'single':
                selected = [self.data.get('current')] if self.data.get('current') in records else []
            tracks = [records[key]['playable'] for key in selected if records[key].get('playable') and Path(records[key]['playable']).is_file()]
            current = records.get(self.data.get('current'), {}).get('playable')
            payload.update(tracks=tracks, track_count=len(tracks),
                           current_track=current if current in tracks else (tracks[0] if tracks else ''),
                           track_metadata={path: {'title': record['title'], 'source_path': record['source'], 'processed': False}
                                           for record in records.values() if (path := record.get('playable')) in tracks})
            return {**message, 'payload': payload}

    def choose_session(self):
        # Preserve the saved manual choice across the original session reset.
        if not self.data['active']:
            return self.original_choose()
        return self.message()['payload']

    def status(self):
        with self.lock:
            records = self.inventory()
            runtime = self.runtime.status()
            return {'tracks': [{'id': key, 'title': record['title'],
                         'ready': bool(record.get('playable') and Path(record['playable']).is_file()),
                         'duration': record.get('duration', 0), 'error': record.get('error', '')}
                         for key, record in records.items()],
                    'selected': list(self.data['selected']), 'current': self.data.get('current', ''),
                    'mode': self.data['mode'], 'active': self.data['active'],
                    'enabled': runtime['enabled'], 'volume': runtime['volume'],
                    'progress': dict(self.progress)}

    async def broadcast(self):
        from cobrinha_server.bridge.godot_bridge import godot_bridge, preview_bridge
        sent = False
        for bridge in (godot_bridge, preview_bridge):
            if bridge.status()['connected']:
                await bridge.send(self.message())
                sent = True
        return sent

    async def upload(self, request):
        from fastapi import HTTPException
        from starlette.datastructures import UploadFile
        if not self.operation.acquire(blocking=False):
            raise HTTPException(status_code=409, detail='Há outra música sendo preparada. Aguarde a conclusão.')
        upload = None
        source = None
        try:
            form = await request.form(max_files=1, max_fields=0)
            upload = form.get('file')
            if not isinstance(upload, UploadFile):
                raise ValueError('Selecione um arquivo de música.')
            suffix = Path(upload.filename or '').suffix.lower()
            if suffix not in EXTENSIONS:
                raise ValueError('Use MP3, OGG, WAV, M4A, AAC, FLAC ou OPUS.')
            title = re.sub(r'[\x00-\x1f/\\]', '', Path(upload.filename.replace('\\', '/')).stem).strip()[:120] or 'Música'
            key = uuid.uuid4().hex[:24]
            directory = self.native.state_dir / 'music-originals'
            directory.mkdir(parents=True, exist_ok=True)
            source = directory / (key + suffix)
            size = 0
            self.progress = {'busy': True, 'message': 'Recebendo: ' + title}
            with source.open('wb') as output:
                while chunk := await upload.read(128 * 1024):
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError('Cada arquivo deve ter até 200 MB.')
                    output.write(chunk)
            with self.lock:
                self.data['records'][key] = {'source': str(source.resolve()), 'title': title}
            record = await asyncio.to_thread(self.prepare_checked, key)
            return {'ok': True, 'id': key, 'file': Path(record['playable']).name,
                    'track_count': len(self.inventory()), 'music': self.status()}
        except ValueError as exc:
            if source:
                source.unlink(missing_ok=True)
            with self.lock:
                if 'key' in locals():
                    self.data['records'].pop(key, None)
                    self.save()
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        finally:
            if upload is not None and hasattr(upload, 'close'):
                await upload.close()
            self.progress = {'busy': False, 'message': ''}
            self.operation.release()

    async def control(self, payload):
        from fastapi import HTTPException
        if not self.operation.acquire(blocking=False):
            raise HTTPException(status_code=409, detail='Aguarde a preparação da música atual.')
        try:
            allowed = {'mode', 'selected', 'current', 'enabled', 'volume', 'play', 'next'}
            if set(payload) - allowed:
                raise ValueError('Comando de música desconhecido.')
            mode = payload.get('mode', self.data['mode'])
            if mode not in ('single', 'shuffle'):
                raise ValueError('Modo de reprodução inválido.')
            for field in ('enabled', 'play', 'next'):
                if field in payload and type(payload[field]) is not bool:
                    raise ValueError('Controle inválido: ' + field)
            volume = payload.get('volume')
            if volume is not None and (isinstance(volume, bool) or not isinstance(volume, (int, float)) or not math.isfinite(volume) or not 0 <= volume <= 1):
                raise ValueError('O volume deve estar entre 0 e 100%.')
            records = self.inventory()
            selected = payload.get('selected', self.data['selected'])
            if not isinstance(selected, list) or any(not isinstance(key, str) or key not in records for key in selected):
                raise ValueError('Selecione faixas existentes na biblioteca.')
            selected = list(dict.fromkeys(selected))
            current = payload.get('current', self.data.get('current', ''))
            if not isinstance(current, str) or (current and current not in records):
                raise ValueError('Faixa não encontrada.')
            playing = payload.get('play') or payload.get('next') or 'mode' in payload or 'selected' in payload or 'current' in payload
            if playing:
                if mode == 'shuffle' and not selected:
                    raise ValueError('Marque pelo menos uma faixa para o automático.')
                if payload.get('next'):
                    pool = [key for key in selected if key != current] or selected
                    if mode == 'single':
                        pool = [key for key in records if key != current] or list(records)
                    current = random.choice(pool) if pool else ''
                elif mode == 'shuffle' and current not in selected:
                    current = selected[0]
                if not current:
                    raise ValueError('Escolha uma música para tocar.')
                for key in (selected if mode == 'shuffle' else [current]):
                    await asyncio.to_thread(self.prepare_checked, key)
                with self.lock:
                    self.data.update(active=True, mode=mode, selected=selected, current=current)
                    self.save()
            self.runtime.update(enabled=payload.get('enabled', True if payload.get('play') else None),
                                volume=volume,
                                current_track=self.data['records'].get(current, {}).get('playable') if playing else None)
            sent = await self.broadcast()
            return {'ok': True, 'sent_to_game': sent, 'music': self.status()}
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        finally:
            self.progress = {'busy': False, 'message': ''}
            self.operation.release()


def attach(binding, app, native):
    from cobrinha_server.services import music_runtime
    from starlette.requests import Request
    library = MusicLibrary(music_runtime, native)
    binding.replace_aliases(music_runtime.websocket_message, library.message)
    binding.replace_aliases(music_runtime.choose_session_start_track, library.choose_session)
    app.state.snake_music_library = library

    @app.get('/termux/music/library')
    def status():
        return library.status()

    @app.post('/termux/music/control')
    async def control(payload: dict):
        return await library.control(payload)

    async def upload(request):
        return await library.upload(request)
    upload.__annotations__['request'] = Request
    app.add_api_route('/termux/music/import', upload, methods=['POST'])
    return library
