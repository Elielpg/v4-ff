"""Opt-in cloud replies and speech. Fixed hosts, private keys, bounded requests."""
from __future__ import annotations

from collections import defaultdict, deque
import hashlib
import io
import os
import json
import re
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
import uuid
import wave
from pathlib import Path

from .client import LocalServiceError, NoRedirects

OPENAI = 'https://api.openai.com/v1'
GEMINI = 'https://generativelanguage.googleapis.com/v1beta'
VOICES = ('cedar', 'marin', 'coral', 'ash', 'alloy', 'echo', 'fable', 'onyx', 'nova', 'sage', 'shimmer', 'verse', 'ballad')
STYLES = {
    'clear': 'Voz natural, acolhedora e bem-humorada, com dicção nítida e ritmo de conversa.',
    'snake': 'Personagem original de cobra brincalhona, com nasalidade leve e humor. Priorize a clareza; não troque R por L nem altere fonemas.',
    'energetic': 'Personagem animado de live, expressivo e divertido, com energia e dicção clara, sem gritar.',
}


def model_name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,99}', value):
        raise ValueError('Nome de modelo inválido.')
    return value


def api_key(value):
    if not isinstance(value, str) or not 20 <= len(value.strip()) <= 512 or any(c.isspace() or ord(c) < 33 for c in value.strip()):
        raise ValueError('Chave inválida. Cole somente a chave de API, sem espaços.')
    return value.strip()


class APIError(LocalServiceError):
    def __init__(self, message, *, status=0, code='unavailable', retry=0, project=False):
        super().__init__(message)
        self.status, self.code, self.retry, self.project = status, code, retry, project


def classify(status, body, retry_header=''):
    """Never return the provider's error text, which could echo a credential."""
    content = json.dumps(body).lower()
    delay = 60
    try:
        delay = max(1, min(86400, int(float(retry_header))))
    except (TypeError, ValueError):
        pass
    for detail in (body.get('error', {}).get('details', []) if isinstance(body.get('error'), dict) else []):
        if not isinstance(detail, dict): continue
        match = re.fullmatch(r'(\d+(?:\.\d+)?)s', str(detail.get('retryDelay', '')))
        if match:
            delay = max(1, min(86400, int(float(match[1])) + 1))
    if status == 401 or 'api_key_invalid' in content or 'api key not valid' in content:
        return APIError('Chave recusada. Confira ou substitua a chave no painel.', status=status, code='invalid_key')
    if status == 429:
        daily = any(t in content for t in ('perday', 'per_day', 'insufficient_quota', 'billing_hard_limit'))
        return APIError('Cota esgotada ou limite de requisições atingido. Confira o projeto e aguarde o intervalo da API.',
                        status=status, code='quota' if daily else 'rate_limit', retry=max(delay, 3600) if daily else delay, project=True)
    if status == 403:
        return APIError('Chave/projeto sem permissão para este modelo. Confira as restrições e a disponibilidade na sua conta.', status=status, code='permission', project=any(term in content for term in ('service_disabled', 'billing_disabled')))
    if status == 400:
        if 'billing' in content or 'billing_not_enabled' in content:
            return APIError('Google exige configuração de faturamento para esse modelo/projeto. Não é uma chave inválida; confira um modelo elegível à faixa gratuita no AI Studio.', status=status, code='billing_required', project=True)
        if 'location' in content or 'region' in content or 'country' in content:
            return APIError('Gemini indisponível para a localização dessa conta/conexão. Confira a elegibilidade no Google AI Studio.', status=status, code='region_unavailable', project=True)
        return APIError('Gemini recusou a configuração da geração. Confira o modelo e os parâmetros.', status=status, code='invalid_request')
    if status == 404:
        return APIError('Modelo ou configuração indisponível para essa chave. Confira o nome do modelo e o projeto.', status=status, code='model_unavailable', project=True)
    return APIError('O serviço de IA está indisponível. Tente novamente mais tarde.', status=status, code='unavailable', retry=30)


class CloudAPI:
    def __init__(self, raw, state_file):
        self.raw, self.state_file = raw, state_file
        self.opener = urllib.request.build_opener(NoRedirects())
        self.lock = threading.RLock()
        self.key_states = {}
        self.project_cooldowns = {}
        self.provider_cooldowns = {}
        self.health_file = self.state_file.with_name('termux-cloud-health.json')
        try:
            saved = json.loads(self.health_file.read_text())
            now = time.time()
            for item in saved.get('projects', []):
                if now < item['until'] <= now + 86400:
                    self.project_cooldowns[(item['project'], item['model'])] = item['until']
            for item in saved.get('keys', []):
                self.key_states[(item['id'], item['model'])] = item['state']
            if saved.get('version', 1) < 2:
                # V031 grouped all 400 errors as unavailable models. Re-evaluate
                # that configuration error; never clear a genuine quota/401.
                for entry in self.entries():
                    for (key, model), state in list(self.key_states.items()):
                        if key == entry['id'] and state.get('state') == 'model_unavailable':
                            self.key_states.pop((key, model), None)
                            self.project_cooldowns.pop((entry['project'], model), None)
        except (OSError, ValueError, KeyError, TypeError):
            pass
        self.calls = defaultdict(deque)
        self.diagnostics = {p: {'ready': None, 'requests': 0, 'answered': 0, 'failed': 0, 'last_error': '', 'latency_ms': None} for p in ('openai', 'gemini', 'speech')}
        self.catalogs = {}
        self.voice_lock = threading.Lock()
        self.voice_ready = False

    def persist_health(self):
        try:
            self._persist_health()
        except OSError:
            self.diagnostics['gemini']['storage_warning'] = 'Não foi possível salvar o diagnóstico; a resposta foi preservada.'

    def _persist_health(self):
        # Only generated diagnostics and IDs are stored here, never key values.
        with self.lock:
            self.health_file.parent.mkdir(parents=True, exist_ok=True)
            data = {'version': 2, 'projects': [{'project': project, 'model': model, 'until': until}
                                for (project, model), until in self.project_cooldowns.items() if until > time.time()],
                    'keys': [{'id': key, 'model': model, 'state': state} for (key, model), state in self.key_states.items()]}
            temporary = self.health_file.with_suffix('.tmp')
            temporary.write_text(json.dumps(data, ensure_ascii=False))
            os.chmod(temporary, 0o600)
            temporary.replace(self.health_file)

    def request(self, provider, path, payload, key, timeout=18, limit=1_000_000, binary=False, query=None):
        if (provider == 'openai' and path not in ('/responses', '/audio/speech')) or (provider == 'gemini' and path != '/models' and not re.fullmatch(r'/models/[A-Za-z0-9._:-]+:generateContent', path)):
            raise ValueError('Rota da API inválida.')
        if provider not in ('openai', 'gemini'):
            raise ValueError('Provedor inválido.')
        headers = {'Content-Type': 'application/json', **({'Authorization': 'Bearer ' + key} if provider == 'openai' else {'x-goog-api-key': key})}
        suffix = ''
        if query:
            if provider != 'gemini' or path != '/models' or set(query) - {'pageSize', 'pageToken'}:
                raise ValueError('Consulta de catálogo inválida.')
            suffix = '?' + urllib.parse.urlencode(query)
        req = urllib.request.Request((OPENAI if provider == 'openai' else GEMINI) + path + suffix,
             data=None if payload is None else json.dumps(payload, ensure_ascii=False).encode(), headers=headers, method='GET' if payload is None else 'POST')
        try:
            with self.opener.open(req, timeout=max(1, min(25, timeout))) as response:
                data = response.read(limit + 1)
                if len(data) > limit:
                    raise APIError('Resposta da API excedeu o limite de tamanho.', code='invalid_response')
                if binary:
                    if str(response.headers.get('Content-Type', '')).startswith(('application/json', 'text/')):
                        raise APIError('A API não devolveu áudio.', code='invalid_audio')
                    return data
            result = json.loads(data)
            if not isinstance(result, dict):
                raise ValueError('object expected')
            return result
        except urllib.error.HTTPError as exc:
            try:
                body = json.loads(exc.read(8192))
                if not isinstance(body, dict): body = {}
            except (ValueError, OSError): body = {}
            raise classify(exc.code, body, exc.headers.get('Retry-After', '')) from None
        except APIError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError):
            raise APIError('Não foi possível alcançar a API. Confira a internet do celular.', code='network', retry=15) from None
        except (ValueError, UnicodeDecodeError):
            raise APIError('A API devolveu uma resposta inválida.', code='invalid_response') from None

    def reserve(self, bucket):
        with self.lock:
            now = time.monotonic()
            if self.provider_cooldowns.get(bucket, 0) > time.time():
                raise APIError('A API está aguardando liberação de cota. Confira o painel e o faturamento.', code='cooldown')
            queue = self.calls[bucket]
            while queue and now - queue[0] >= 60: queue.popleft()
            if len(queue) >= 20:
                raise APIError('Limite local de 20 chamadas por minuto atingido. Aguarde a fila.', code='local_limit', retry=60)
            queue.append(now)

    def entries(self):
        return self.raw().get('termux_gemini_keys', [])

    def keys_public(self, model=None):
        model = model or self.raw().get('termux_gemini_model', 'auto')
        result = []
        with self.lock:
            for entry in self.entries():
                state = dict(self.key_states.get((entry['id'], model), {}))
                until = max(state.get('retry_at', 0), self.project_cooldowns.get((entry['project'], model), 0))
                invalid = self.key_states.get((entry['id'], '*'), {}).get('state') == 'invalid_key'
                result.append({'id': entry['id'], 'label': entry['label'], 'project': entry['project'],
                    'state': 'invalid_key' if invalid else ('cooldown' if until > time.time() else state.get('state', 'untested')),
                    'retry_at': until, 'last_error': state.get('last_error', ''), 'model': model, 'resolved_model': state.get('resolved_model', ''), 'http_status': state.get('http_status', 0), 'code': state.get('state', '')})
        return result

    def gemini_models(self, entry, selected):
        if selected != 'auto': return [selected]
        cached = self.catalogs.get(entry['id'])
        if cached and time.monotonic() - cached[0] < 300: return list(cached[1])
        names, token = [], ''
        started = time.monotonic()
        for _ in range(3):
            query = {'pageSize': 100}
            if token: query['pageToken'] = token
            data = self.request('gemini', '/models', None, entry['value'], timeout=max(1, 7 - (time.monotonic() - started)), query=query)
            names.extend(item.get('name', '').removeprefix('models/') for item in data.get('models', [])
                         if isinstance(item, dict) and 'generateContent' in item.get('supportedGenerationMethods', []))
            token = str(data.get('nextPageToken') or '')
            if not token or time.monotonic() - started >= 6: break
        eligible = [name for name in names if name.startswith('gemini-') and 'flash' in name
                    and not any(word in name for word in ('tts', 'image', 'live', 'audio', 'robotics'))]
        stable = [name for name in eligible if 'preview' not in name and 'experimental' not in name]
        choices = stable or eligible
        if not choices: raise APIError('O catálogo não anunciou um Flash de texto. Informe no painel um modelo disponível para sua conta.', code='model_unavailable')
        choices.sort(key=lambda name: ('lite' in name, [int(x) for x in re.findall(r'\d+', name)], name), reverse=True)
        choices = list(dict.fromkeys(model_name(name) for name in choices))
        known = self.key_states.get((entry['id'], 'auto'), {}).get('resolved_model')
        if known in choices: choices.remove(known); choices.insert(0, known)
        self.catalogs[entry['id']] = (time.monotonic(), list(choices))
        return choices

    def gemini_model(self, entry, selected):
        return self.gemini_models(entry, selected)[0]

    def gemini_call(self, prompt, identity, model, *, only_id=None, check=False):
        entries = list(self.entries())
        if only_id: entries = [e for e in entries if e['id'] == only_id]
        if not entries: raise APIError('Adicione uma chave Gemini no painel.', code='missing_key')
        now = time.time()
        with self.lock:
            usable = [e for e in entries if self.key_states.get((e['id'], '*'), {}).get('state') != 'invalid_key'
                      and self.key_states.get((e['id'], model), {}).get('retry_at', 0) <= now
                      and self.project_cooldowns.get((e['project'], model), 0) <= now]
        if not usable: raise APIError('As chaves estão recusadas ou aguardando cota. Consulte o código e o prazo no painel.', code='no_available_key')
        started, attempts, last = time.monotonic(), 0, None
        for entry in usable[:1 if check else 2]:
            if self.project_cooldowns.get((entry['project'], model), 0) > time.time(): continue
            resolved = ''
            try:
                models = self.gemini_models(entry, model)
                for resolved in models[:2]:
                    if attempts >= 3 or time.monotonic() - started >= 17: break
                    payload = {'systemInstruction': {'parts': [{'text': identity}]},
                        'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
                        'generationConfig': {'temperature': .55, 'maxOutputTokens': 192 if check else 384}}
                    if resolved in ('gemini-2.5-flash-lite', 'gemini-2.5-flash'):
                        payload['generationConfig']['thinkingConfig'] = {'thinkingBudget': 0}
                    elif re.match(r'gemini-[3-9](?:\.|-)', resolved):
                        payload['generationConfig']['thinkingConfig'] = {'thinkingLevel': 'MINIMAL'}
                    for compatibility in range(2):
                        self.reserve('gemini:' + entry['project']); attempts += 1
                        try:
                            data = self.request('gemini', '/models/' + resolved + ':generateContent', payload, entry['value'],
                                                timeout=max(1, 18 - (time.monotonic() - started)))
                            break
                        except APIError as exc:
                            last = exc
                            if exc.code == 'invalid_request' and compatibility == 0 and attempts < 3 and time.monotonic() - started < 16:
                                # Retry this model once without optional controls;
                                # not a new key and not an attempt to bypass quota.
                                payload['generationConfig'].pop('thinkingConfig', None)
                                payload['generationConfig'].pop('temperature', None)
                                continue
                            if exc.code == 'model_unavailable' and model == 'auto':
                                data = None; break
                            raise
                    if data is None: continue
                    candidates = data.get('candidates') or []
                    candidate = candidates[0] if candidates and isinstance(candidates[0], dict) else {}
                    parts = candidate.get('content', {}).get('parts', [])
                    text = ' '.join(part.get('text', '') for part in parts if isinstance(part, dict) and not part.get('thought') and isinstance(part.get('text', ''), str)).strip()
                    if not text:
                        finish = str(candidate.get('finishReason') or '')
                        message = 'Gemini consumiu o limite antes de devolver texto. Teste um Flash Lite ou outro modelo disponível.' if finish == 'MAX_TOKENS' else 'Gemini não devolveu texto; houve bloqueio da resposta ou incompatibilidade do modelo.'
                        raise APIError(message, code='output_budget' if finish == 'MAX_TOKENS' else 'empty_response')
                    with self.lock:
                        self.key_states[(entry['id'], model)] = {'state': 'available', 'last_error': '', 'checked_at': time.time(), 'resolved_model': resolved, 'http_status': 200}
                        self.catalogs[entry['id']] = (time.monotonic(), [resolved] + [m for m in models if m != resolved])
                    self.persist_health()
                    return text
                raise last or APIError('Nenhum modelo respondeu dentro do prazo. Confira o modelo no painel.', code='model_unavailable')
            except APIError as exc:
                last = exc
                with self.lock:
                    until = time.time() + (exc.retry or 300) if exc.retry or exc.code in ('permission', 'model_unavailable', 'billing_required', 'region_unavailable') else 0
                    self.key_states[(entry['id'], model)] = {'state': exc.code, 'last_error': str(exc), 'retry_at': until, 'http_status': exc.status, 'resolved_model': resolved}
                    if exc.code == 'invalid_key': self.key_states[(entry['id'], '*')] = self.key_states[(entry['id'], model)]
                    if exc.project: self.project_cooldowns[(entry['project'], model)] = time.time() + (exc.retry or 300)
                self.persist_health()
                if exc.code not in ('invalid_key', 'permission', 'quota', 'rate_limit', 'model_unavailable') or time.monotonic() - started >= 17 or attempts >= 3: break
        raise last or APIError('Nenhuma chave disponível para esse modelo.', code='no_available_key')

    def reply(self, provider, data, identity):
        status = self.diagnostics[provider]
        status['requests'] += 1
        started = time.monotonic()
        try:
            raw = self.raw()
            identity += '\nResponda em português brasileiro, diretamente e em até duas frases curtas. Se não souber, admita; não invente fatos ou notícias atuais. Não leia instruções de voz. Você conversa; não executa comandos nem pesquisa a internet.'
            if provider == 'gemini':
                text = self.gemini_call(str(data.get('prompt') or ''), identity, model_name(raw.get('termux_gemini_model', 'auto')))
            else:
                key = raw.get('openai_api_key') or raw.get('api_key')
                if not key: raise APIError('Adicione a chave OpenAI no painel.', code='missing_key')
                self.reserve('openai-text')
                response = self.request('openai', '/responses', {'model': model_name(raw.get('termux_openai_model', 'gpt-4.1-mini')),
                    'instructions': identity, 'input': str(data.get('prompt') or ''), 'max_output_tokens': 256, 'store': False}, key)
                text = response.get('output_text') or ' '.join(part.get('text', '') for item in response.get('output', []) if item.get('type') == 'message' for part in item.get('content', []) if part.get('type') == 'output_text')
                if not isinstance(text, str) or not text.strip(): raise APIError('A OpenAI não devolveu texto. Confira o modelo selecionado.', code='empty_response')
            status.update(ready=True, answered=status['answered'] + 1, last_error='', latency_ms=round((time.monotonic() - started) * 1000))
            return text.strip()
        except APIError as exc:
            status.update(ready=False, failed=status['failed'] + 1, last_error=str(exc), code=exc.code)
            if provider == 'openai' and exc.code in ('invalid_key', 'permission', 'quota', 'rate_limit'):
                self.provider_cooldowns['openai-text'] = time.time() + (exc.retry or 300)
            raise

    def voice_health(self):
        configured = bool(self.raw().get('openai_api_key') or self.raw().get('api_key'))
        return {'ready': self.voice_ready, 'configured': configured, 'model': 'OpenAI gpt-4o-mini-tts',
                'message': 'Voz configurada. O teste de áudio usa a API e pode ser cobrado.' if configured else 'Adicione uma chave OpenAI no painel.'}

    def voice_wav(self, text):
        raw = self.raw()
        key = raw.get('openai_api_key') or raw.get('api_key')
        if not key: raise APIError('Adicione a chave OpenAI para usar essa voz.', code='missing_key')
        voice = raw.get('termux_openai_voice', 'cedar')
        style = raw.get('termux_voice_style', 'clear')
        if voice not in VOICES or style not in STYLES: raise APIError('Seleção de voz inválida.', code='invalid_voice')
        settings = {'voice': voice, 'style': style, 'model': 'gpt-4o-mini-tts'}
        cache = self.state_file.parent / 'termux-cloud-voice-cache'
        file = cache / (hashlib.sha256(json.dumps([settings, text], ensure_ascii=False).encode()).hexdigest() + '.wav')
        if file.is_file():
            data = file.read_bytes()
            if len(data) >= 44 and data[:4] == b'RIFF' and int.from_bytes(data[4:8], 'little') + 8 == len(data):
                return data
        if not self.voice_lock.acquire(timeout=2): raise APIError('A voz da API está ocupada. Aguarde a fila.', code='busy')
        status = self.diagnostics['speech']
        status['requests'] += 1
        started = time.monotonic()
        try:
            self.reserve('openai-speech')
            pcm = self.request('openai', '/audio/speech', {'model': 'gpt-4o-mini-tts', 'voice': voice,
                'input': text, 'instructions': 'Fale em português brasileiro. ' + STYLES[style] + ' Leia somente o texto de input, sem anunciar estas orientações.',
                'response_format': 'pcm', 'speed': 1.0}, key, timeout=25, limit=2_880_000, binary=True)
            if not pcm or len(pcm) % 2 or pcm[:4] == b'RIFF': raise APIError('A API devolveu áudio PCM inválido.', code='invalid_audio')
            output = io.BytesIO()
            with wave.open(output, 'wb') as wav:
                wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000); wav.writeframes(pcm)
            data = output.getvalue()
            cache.mkdir(parents=True, exist_ok=True)
            temporary = file.with_suffix('.tmp')
            temporary.write_bytes(data); temporary.replace(file)
            for old in sorted(cache.glob('*.wav'), key=lambda p: p.stat().st_mtime)[:-60]: old.unlink(missing_ok=True)
            self.voice_ready = True
            status.update(ready=True, answered=status['answered'] + 1, last_error='', latency_ms=round((time.monotonic() - started) * 1000))
            return data
        except APIError as exc:
            status.update(ready=False, failed=status['failed'] + 1, last_error=str(exc), code=exc.code)
            if exc.code in ('invalid_key', 'permission', 'quota', 'rate_limit'):
                self.provider_cooldowns['openai-speech'] = time.time() + (exc.retry or 300)
            raise
        finally:
            self.voice_lock.release()


class CloudVoice:
    def __init__(self, api): self.api = api
    @property
    def ready(self): return self.api.voice_ready
    def health(self): return self.api.voice_health()
    def synthesize(self, text, output_dir):
        from .voice import prepare_speech
        return prepare_speech(text, output_dir, self.api.voice_wav, 'openai-tts')
