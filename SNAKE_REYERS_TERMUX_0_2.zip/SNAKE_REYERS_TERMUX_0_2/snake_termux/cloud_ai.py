"""Opt-in cloud replies and speech. Fixed hosts, private keys, bounded requests."""
from __future__ import annotations

from collections import defaultdict, deque
import hashlib
import io
import os
import json
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
import wave
from pathlib import Path

from .client import LocalServiceError, NoRedirects

OPENAI = 'https://api.openai.com/v1'
GEMINI = 'https://generativelanguage.googleapis.com/v1beta'
VOICES = ('cedar', 'marin', 'coral', 'ash', 'alloy', 'echo', 'fable', 'onyx', 'nova', 'sage', 'shimmer', 'verse', 'ballad')
STYLES = {
    'clear': 'Voz natural, acolhedora e bem-humorada, com dicção nítida e ritmo de conversa.',
    'snake': 'Personagem original de cobra brincalhona, com nasalidade leve e humor. Priorize a clareza; não troque R por L nem altere fonemas.',
    'energetic': 'Personagem animado de live, expressivo e divertido, com energia e dicção clara, sem gritar.',
}


def model_name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,99}', value):
        raise ValueError('Nome de modelo inválido.')
    return value


def api_key(value):
    if not isinstance(value, str) or not 20 <= len(value.strip()) <= 512 or any(c.isspace() or ord(c) < 33 for c in value.strip()):
        raise ValueError('Chave inválida. Cole somente a chave de API, sem espaços.')
    return value.strip()


class APIError(LocalServiceError):
    def __init__(self, message, *, status=0, code='unavailable', retry=0, project=False):
        super().__init__(message)
        self.status, self.code, self.retry, self.project = status, code, retry, project


def classify(status, body, retry_header=''):
    """Never return the provider's error text, which could echo a credential."""
    content = json.dumps(body).lower()
    delay = 60
    try:
        delay = max(1, min(86400, int(float(retry_header))))
    except (TypeError, ValueError):
        pass
    for detail in (body.get('error', {}).get('details', []) if isinstance(body.get('error'), dict) else []):
        if not isinstance(detail, dict): continue
        match = re.fullmatch(r'(\d+(?:\.\d+)?)s', str(detail.get('retryDelay', '')))
        if match:
            delay = max(1, min(86400, int(float(match[1])) + 1))
    if status == 401 or 'api_key_invalid' in content or 'api key not valid' in content:
        return APIError('Chave recusada. Confira ou substitua a chave no painel.', status=status, code='invalid_key')
    if status == 429:
        daily = any(t in content for t in ('perday', 'per_day', 'insufficient_quota', 'billing_hard_limit'))
        return APIError('Cota esgotada ou limite de requisições atingido. Confira o projeto e aguarde o intervalo da API.',
                        status=status, code='quota' if daily else 'rate_limit', retry=max(delay, 3600) if daily else delay, project=True)
    if status == 403:
        return APIError('Chave/projeto sem permissão para este modelo. Confira as restrições e a disponibilidade na sua conta.', status=status, code='permission', project=any(term in content for term in ('service_disabled', 'billing_disabled')))
    if status in (400, 404):
        return APIError('Modelo ou configuração indisponível para essa chave. Confira o nome do modelo e o projeto.', status=status, code='model_unavailable', project=True)
    return APIError('O serviço de IA está indisponível. Tente novamente mais tarde.', status=status, code='unavailable', retry=30)


class CloudAPI:
    def __init__(self, raw, state_file):
        self.raw, self.state_file = raw, state_file
        self.opener = urllib.request.build_opener(NoRedirects())
        self.lock = threading.RLock()
        self.key_states = {}
        self.project_cooldowns = {}
        self.provider_cooldowns = {}
        self.health_file = self.state_file.with_name('termux-cloud-health.json')
        try:
            saved = json.loads(self.health_file.read_text())
            now = time.time()
            for item in saved.get('projects', []):
                if now < item['until'] <= now + 86400:
                    self.project_cooldowns[(item['project'], item['model'])] = item['until']
            for item in saved.get('keys', []):
                self.key_states[(item['id'], item['model'])] = item['state']
        except (OSError, ValueError, KeyError, TypeError):
            pass
        self.calls = defaultdict(deque)
        self.diagnostics = {p: {'ready': None, 'requests': 0, 'answered': 0, 'failed': 0, 'last_error': '', 'latency_ms': None} for p in ('openai', 'gemini', 'speech')}
        self.catalogs = {}
        self.voice_lock = threading.Lock()
        self.voice_ready = False

    def persist_health(self):
        # Only generated diagnostics and IDs are stored here, never key values.
        with self.lock:
            self.health_file.parent.mkdir(parents=True, exist_ok=True)
            data = {'projects': [{'project': project, 'model': model, 'until': until}
                                for (project, model), until in self.project_cooldowns.items() if until > time.time()],
                    'keys': [{'id': key, 'model': model, 'state': state} for (key, model), state in self.key_states.items()]}
            temporary = self.health_file.with_suffix('.tmp')
            temporary.write_text(json.dumps(data, ensure_ascii=False))
            os.chmod(temporary, 0o600)
            temporary.replace(self.health_file)

    def request(self, provider, path, payload, key, timeout=18, limit=1_000_000, binary=False):
        if (provider == 'openai' and path not in ('/responses', '/audio/speech')) or (provider == 'gemini' and path != '/models' and not re.fullmatch(r'/models/[A-Za-z0-9._:-]+:generateContent', path)):
            raise ValueError('Rota da API inválida.')
        if provider not in ('openai', 'gemini'):
            raise ValueError('Provedor inválido.')
        headers = {'Content-Type': 'application/json', **({'Authorization': 'Bearer ' + key} if provider == 'openai' else {'x-goog-api-key': key})}
        req = urllib.request.Request((OPENAI if provider == 'openai' else GEMINI) + path,
             data=None if payload is None else json.dumps(payload, ensure_ascii=False).encode(), headers=headers, method='GET' if payload is None else 'POST')
        try:
            with self.opener.open(req, timeout=max(1, min(25, timeout))) as response:
                data = response.read(limit + 1)
                if len(data) > limit:
                    raise APIError('Resposta da API excedeu o limite de tamanho.', code='invalid_response')
                if binary:
                    if str(response.headers.get('Content-Type', '')).startswith(('application/json', 'text/')):
                        raise APIError('A API não devolveu áudio.', code='invalid_audio')
                    return data
            result = json.loads(data)
            if not isinstance(result, dict):
                raise ValueError('object expected')
            return result
        except urllib.error.HTTPError as exc:
            try:
                body = json.loads(exc.read(8192))
                if not isinstance(body, dict): body = {}
            except (ValueError, OSError): body = {}
            raise classify(exc.code, body, exc.headers.get('Retry-After', '')) from None
        except APIError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError):
            raise APIError('Não foi possível alcançar a API. Confira a internet do celular.', code='network', retry=15) from None
        except (ValueError, UnicodeDecodeError):
            raise APIError('A API devolveu uma resposta inválida.', code='invalid_response') from None

    def reserve(self, bucket):
        with self.lock:
            now = time.monotonic()
            if self.provider_cooldowns.get(bucket, 0) > time.time():
                raise APIError('A API está aguardando liberação de cota. Confira o painel e o faturamento.', code='cooldown')
            queue = self.calls[bucket]
            while queue and now - queue[0] >= 60: queue.popleft()
            if len(queue) >= 20:
                raise APIError('Limite local de 20 chamadas por minuto atingido. Aguarde a fila.', code='local_limit', retry=60)
            queue.append(now)

    def entries(self):
        return self.raw().get('termux_gemini_keys', [])

    def keys_public(self, model=None):
        model = model or self.raw().get('termux_gemini_model', 'auto')
        result = []
        with self.lock:
            for entry in self.entries():
                state = dict(self.key_states.get((entry['id'], model), {}))
                until = max(state.get('retry_at', 0), self.project_cooldowns.get((entry['project'], model), 0))
                invalid = self.key_states.get((entry['id'], '*'), {}).get('state') == 'invalid_key'
                result.append({'id': entry['id'], 'label': entry['label'], 'project': entry['project'],
                    'state': 'invalid_key' if invalid else ('cooldown' if until > time.time() else state.get('state', 'untested')),
                    'retry_at': until, 'last_error': state.get('last_error', ''), 'model': model, 'resolved_model': state.get('resolved_model', '')})
        return result

    def gemini_model(self, entry, selected):
        if selected != 'auto': return selected
        cached = self.catalogs.get(entry['id'])
        if cached and time.monotonic() - cached[0] < 300: return cached[1]
        data = self.request('gemini', '/models', None, entry['value'], timeout=5)
        names = [item.get('name', '').removeprefix('models/') for item in data.get('models', [])
                 if 'generateContent' in item.get('supportedGenerationMethods', [])]
        eligible = [name for name in names if name.startswith('gemini-') and 'flash' in name
                    and not any(word in name for word in ('tts', 'image', 'live', 'audio', 'robotics'))]
        stable = [name for name in eligible if 'preview' not in name and 'experimental' not in name]
        choices = stable or eligible
        if not choices: raise APIError('Não foi encontrado um modelo Flash de texto. Informe um modelo disponível na sua conta.', code='model_unavailable')
        choices.sort(key=lambda name: ('lite' in name, [int(x) for x in re.findall(r'\d+', name)], name), reverse=True)
        model = model_name(choices[0])
        self.catalogs[entry['id']] = (time.monotonic(), model)
        return model

    def gemini_call(self, prompt, identity, model, *, only_id=None, check=False):
        entries = list(self.entries())
        if only_id: entries = [e for e in entries if e['id'] == only_id]
        if not entries:
            raise APIError('Adicione uma chave Gemini no painel.', code='missing_key')
        now = time.time()
        with self.lock:
            usable = [e for e in entries if self.key_states.get((e['id'], '*'), {}).get('state') != 'invalid_key'
                      and self.key_states.get((e['id'], model), {}).get('retry_at', 0) <= now
                      and self.project_cooldowns.get((e['project'], model), 0) <= now]
        if not usable:
            raise APIError('As chaves estão recusadas ou aguardando liberação da cota. Consulte o estado no painel.', code='no_available_key')
        started = time.monotonic()
        last = None
        # At most two attempts; no round-robin through exhausted project keys.
        for entry in usable[:1 if check else 2]:
            with self.lock:
                if self.project_cooldowns.get((entry['project'], model), 0) > time.time(): continue
            try:
                self.reserve('gemini:' + entry['project'])
                payload = {'systemInstruction': {'parts': [{'text': identity}]},
                    'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
                    'generationConfig': {'temperature': .55, 'maxOutputTokens': 32 if check else 180}}
                if model in ('gemini-2.5-flash-lite', 'gemini-2.5-flash'):
                    payload['generationConfig']['thinkingConfig'] = {'thinkingBudget': 0}
                resolved = self.gemini_model(entry, model)
                if resolved in ('gemini-2.5-flash-lite', 'gemini-2.5-flash'):
                    payload['generationConfig']['thinkingConfig'] = {'thinkingBudget': 0}
                data = self.request('gemini', '/models/' + resolved + ':generateContent', payload, entry['value'],
                                    timeout=max(1, (8 if check else 18) - (time.monotonic() - started)))
                candidates = data.get('candidates') or []
                parts = candidates[0].get('content', {}).get('parts', []) if candidates else []
                text = ' '.join(part.get('text', '') for part in parts if isinstance(part, dict) and not part.get('thought')).strip()
                if not text:
                    raise APIError('O Gemini não devolveu texto. Confira o modelo ou um possível bloqueio da resposta.', code='empty_response')
                with self.lock:
                    self.key_states[(entry['id'], model)] = {'state': 'available', 'last_error': '', 'checked_at': time.time(), 'resolved_model': resolved}
                self.persist_health()
                return text
            except APIError as exc:
                last = exc
                with self.lock:
                    state = {'state': exc.code, 'last_error': str(exc), 'retry_at': time.time() + (exc.retry or 300) if exc.retry or exc.code in ('permission', 'model_unavailable') else 0}
                    self.key_states[(entry['id'], model)] = state
                    if exc.code == 'invalid_key': self.key_states[(entry['id'], '*')] = state
                    if exc.project:
                        self.project_cooldowns[(entry['project'], model)] = time.time() + (exc.retry or 300)
                self.persist_health()
                if exc.code not in ('invalid_key', 'permission', 'quota', 'rate_limit', 'model_unavailable') or time.monotonic() - started >= 17:
                    break
        raise last or APIError('Nenhuma chave liberada para esse modelo.', code='no_available_key')

    def reply(self, provider, data, identity):
        status = self.diagnostics[provider]
        status['requests'] += 1
        started = time.monotonic()
        try:
            raw = self.raw()
            identity += '\nResponda em português brasileiro, diretamente e em até duas frases curtas. Se não souber, admita; não invente fatos ou notícias atuais. Não leia instruções de voz. Você conversa; não executa comandos nem pesquisa a internet.'
            if provider == 'gemini':
                text = self.gemini_call(str(data.get('prompt') or ''), identity, model_name(raw.get('termux_gemini_model', 'auto')))
            else:
                key = raw.get('openai_api_key') or raw.get('api_key')
                if not key: raise APIError('Adicione a chave OpenAI no painel.', code='missing_key')
                self.reserve('openai-text')
                response = self.request('openai', '/responses', {'model': model_name(raw.get('termux_openai_model', 'gpt-4.1-mini')),
                    'instructions': identity, 'input': str(data.get('prompt') or ''), 'max_output_tokens': 256, 'store': False}, key)
                text = response.get('output_text') or ' '.join(part.get('text', '') for item in response.get('output', []) if item.get('type') == 'message' for part in item.get('content', []) if part.get('type') == 'output_text')
                if not isinstance(text, str) or not text.strip(): raise APIError('A OpenAI não devolveu texto. Confira o modelo selecionado.', code='empty_response')
            status.update(ready=True, answered=status['answered'] + 1, last_error='', latency_ms=round((time.monotonic() - started) * 1000))
            return text.strip()
        except APIError as exc:
            status.update(ready=False, failed=status['failed'] + 1, last_error=str(exc), code=exc.code)
            if provider == 'openai' and exc.code in ('invalid_key', 'permission', 'quota', 'rate_limit'):
                self.provider_cooldowns['openai-text'] = time.time() + (exc.retry or 300)
            raise

    def voice_health(self):
        configured = bool(self.raw().get('openai_api_key') or self.raw().get('api_key'))
        return {'ready': self.voice_ready, 'configured': configured, 'model': 'OpenAI gpt-4o-mini-tts',
                'message': 'Voz configurada. O teste de áudio usa a API e pode ser cobrado.' if configured else 'Adicione uma chave OpenAI no painel.'}

    def voice_wav(self, text):
        raw = self.raw()
        key = raw.get('openai_api_key') or raw.get('api_key')
        if not key: raise APIError('Adicione a chave OpenAI para usar essa voz.', code='missing_key')
        voice = raw.get('termux_openai_voice', 'cedar')
        style = raw.get('termux_voice_style', 'clear')
        if voice not in VOICES or style not in STYLES: raise APIError('Seleção de voz inválida.', code='invalid_voice')
        settings = {'voice': voice, 'style': style, 'model': 'gpt-4o-mini-tts'}
        cache = self.state_file.parent / 'termux-cloud-voice-cache'
        file = cache / (hashlib.sha256(json.dumps([settings, text], ensure_ascii=False).encode()).hexdigest() + '.wav')
        if file.is_file():
            data = file.read_bytes()
            if len(data) >= 44 and data[:4] == b'RIFF' and int.from_bytes(data[4:8], 'little') + 8 == len(data):
                return data
        if not self.voice_lock.acquire(timeout=2): raise APIError('A voz da API está ocupada. Aguarde a fila.', code='busy')
        status = self.diagnostics['speech']
        status['requests'] += 1
        started = time.monotonic()
        try:
            self.reserve('openai-speech')
            pcm = self.request('openai', '/audio/speech', {'model': 'gpt-4o-mini-tts', 'voice': voice,
                'input': text, 'instructions': 'Fale em português brasileiro. ' + STYLES[style] + ' Leia somente o texto de input, sem anunciar estas orientações.',
                'response_format': 'pcm', 'speed': 1.0}, key, timeout=25, limit=2_880_000, binary=True)
            if not pcm or len(pcm) % 2 or pcm[:4] == b'RIFF': raise APIError('A API devolveu áudio PCM inválido.', code='invalid_audio')
            output = io.BytesIO()
            with wave.open(output, 'wb') as wav:
                wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000); wav.writeframes(pcm)
            data = output.getvalue()
            cache.mkdir(parents=True, exist_ok=True)
            temporary = file.with_suffix('.tmp')
            temporary.write_bytes(data); temporary.replace(file)
            for old in sorted(cache.glob('*.wav'), key=lambda p: p.stat().st_mtime)[:-60]: old.unlink(missing_ok=True)
            self.voice_ready = True
            status.update(ready=True, answered=status['answered'] + 1, last_error='', latency_ms=round((time.monotonic() - started) * 1000))
            return data
        except APIError as exc:
            status.update(ready=False, failed=status['failed'] + 1, last_error=str(exc), code=exc.code)
            if exc.code in ('invalid_key', 'permission', 'quota', 'rate_limit'):
                self.provider_cooldowns['openai-speech'] = time.time() + (exc.retry or 300)
            raise
        finally:
            self.voice_lock.release()


class CloudVoice:
    def __init__(self, api): self.api = api
    @property
    def ready(self): return self.api.voice_ready
    def health(self): return self.api.voice_health()
    def synthesize(self, text, output_dir):
        from .voice import prepare_speech
        return prepare_speech(text, output_dir, self.api.voice_wav, 'openai-tts')
