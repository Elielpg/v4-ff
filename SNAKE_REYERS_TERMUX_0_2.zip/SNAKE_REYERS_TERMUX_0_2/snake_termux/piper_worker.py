"""Small loopback-only Piper service; runs inside the existing Ubuntu voice environment."""
import argparse,json,wave,io,threading,hashlib,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from piper import PiperVoice,SynthesisConfig
p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--port',type=int,default=8083);p.add_argument('--cache-dir',required=True);a=p.parse_args()
voice=PiperVoice.load(a.model);lock=threading.Lock();cache=Path(a.cache_dir);cache.mkdir(parents=True,exist_ok=True)
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send_json(self,code,data):
        b=json.dumps(data).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        if self.path=='/health':self.send_json(200,{'ready':True,'model':'Piper-pt_BR-local','busy':lock.locked()})
        else:self.send_json(404,{'error':'not found'})
    def do_POST(self):
        if self.path!='/synthesize':return self.send_json(404,{'error':'not found'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<1 or size>4096:return self.send_json(413,{'error':'request too large'})
            text=json.loads(self.rfile.read(size)).get('text','')
            if not isinstance(text,str) or not text.strip() or len(text)>400:return self.send_json(400,{'error':'invalid text'})
            if not lock.acquire(blocking=False):return self.send_json(409,{'error':'busy'})
            try:
                file=cache/(hashlib.sha256(text.encode()).hexdigest()+'.wav')
                b=file.read_bytes() if file.exists() else b''
                if not (len(b)>=44 and b[:4]==b'RIFF' and b[8:12]==b'WAVE' and int.from_bytes(b[4:8],'little')+8==len(b)):
                    target=io.BytesIO()
                    with wave.open(target,'wb') as w:voice.synthesize_wav(text,w,syn_config=SynthesisConfig(length_scale=.96,noise_scale=.4,noise_w_scale=.28,volume=.85))
                    b=target.getvalue();temp=file.with_suffix('.tmp');temp.write_bytes(b);temp.replace(file)
                    files=sorted(cache.glob('*.wav'),key=lambda f:f.stat().st_mtime)
                    for old in files[:-60]:old.unlink(missing_ok=True)
            finally:lock.release()
            self.send_response(200);self.send_header('Content-Type','audio/wav');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:self.send_json(500,{'error':type(e).__name__})
print('Voz Piper local pronta em 127.0.0.1:'+str(a.port),flush=True)
ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
