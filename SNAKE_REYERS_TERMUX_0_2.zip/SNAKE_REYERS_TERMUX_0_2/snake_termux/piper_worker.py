"""Loopback-only Piper with bounded CPU usage, run in the installed voice environment."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import threading
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PROFILES = {
    'clear': {'length_scale': 1.06, 'noise_scale': .5, 'noise_w_scale': .333, 'volume': .85},
    'natural': {'length_scale': 1.0, 'noise_scale': .5, 'noise_w_scale': .333, 'volume': .85},
    'legacy': {'length_scale': .96, 'noise_scale': .4, 'noise_w_scale': .28, 'volume': .85},
}


def load_voice(model):
    import onnxruntime as ort
    from piper import PiperVoice
    from piper.config import PiperConfig
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    # Spinning workers compete with Godot/Qwen even between short requests.
    options.add_session_config_entry('session.intra_op.allow_spinning', '0')
    options.add_session_config_entry('session.inter_op.allow_spinning', '0')
    config = json.loads(Path(str(model) + '.json').read_text())
    return PiperVoice(config=PiperConfig.from_dict(config), session=ort.InferenceSession(
        str(model), sess_options=options, providers=['CPUExecutionProvider']))


def main():
    from piper import SynthesisConfig
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--port', type=int, default=8083)
    parser.add_argument('--cache-dir', required=True)
    args = parser.parse_args()
    voice = load_voice(args.model)
    lock = threading.Lock()
    cache = Path(args.cache_dir)
    cache.mkdir(parents=True, exist_ok=True)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def send_json(self, code, data):
            raw = json.dumps(data).encode()
            self.send_response(code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if self.path == '/health':
                self.send_json(200, {'ready': True, 'model': 'Piper-pt_BR-local',
                    'busy': lock.locked(), 'inference_threads': 2, 'worker_spinning': False,
                    'prosody_profiles': list(PROFILES), 'worker_version': '0.3.3'})
            else:
                self.send_json(404, {'error': 'not found'})

        def do_POST(self):
            if self.path != '/synthesize':
                return self.send_json(404, {'error': 'not found'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 1 <= size <= 4096:
                    return self.send_json(413, {'error': 'request too large'})
                payload = json.loads(self.rfile.read(size))
                text = payload.get('text', '')
                profile = payload.get('profile', 'clear')
                if not isinstance(profile, str) or profile not in PROFILES:
                    return self.send_json(400, {'error': 'invalid profile'})
                if not isinstance(text, str) or not text.strip() or len(text) > 400:
                    return self.send_json(400, {'error': 'invalid text'})
                if not lock.acquire(blocking=False):
                    return self.send_json(409, {'error': 'busy'})
                try:
                    signature = json.dumps({'text': text, 'profile': profile, 'version': '0.3.3',
                        'model': str(Path(args.model).resolve()), 'modified': Path(args.model).stat().st_mtime_ns}, sort_keys=True)
                    file = cache / (hashlib.sha256(signature.encode()).hexdigest() + '.wav')
                    raw = file.read_bytes() if file.exists() else b''
                    if not (len(raw) >= 44 and raw[:4] == b'RIFF' and raw[8:12] == b'WAVE'
                            and int.from_bytes(raw[4:8], 'little') + 8 == len(raw)):
                        target = io.BytesIO()
                        with wave.open(target, 'wb') as output:
                            voice.synthesize_wav(text, output, syn_config=SynthesisConfig(**PROFILES[profile]))
                        raw = target.getvalue()
                        temp = file.with_suffix('.tmp')
                        temp.write_bytes(raw)
                        temp.replace(file)
                        files = sorted(cache.glob('*.wav'), key=lambda item: item.stat().st_mtime)
                        for old in files[:-60]:
                            old.unlink(missing_ok=True)
                finally:
                    lock.release()
                self.send_response(200)
                self.send_header('Content-Type', 'audio/wav')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                self.send_json(500, {'error': type(exc).__name__})

    print('Voz Piper local pronta em 127.0.0.1:' + str(args.port) + ' · CPU limitada a 2 threads', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()


if __name__ == '__main__':
    main()
