from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path

from .native import verify_original


def prepare(source: Path, destination: Path) -> Path:
    source, destination = source.expanduser().resolve(), destination.expanduser().resolve()
    if (source / 'VERSION').read_text().strip().removeprefix('v') != '0.1.9':
        raise ValueError('Escolha a pasta original SnakeReyers 0.1.9.')
    if not (source / 'server/src/cobrinha_server/main.py').is_file():
        raise ValueError('Esta pasta não contém o servidor original completo.')
    verify_original(source / 'game/windows/SnakeReyers.exe')
    if destination == source:
        return source
    if source in destination.parents:
        raise ValueError('O destino não pode ficar dentro da pasta original.')
    if destination.exists():
        verify_original(destination / 'game/windows/SnakeReyers.exe')
        if not (destination / 'server/src/cobrinha_server/main.py').is_file():
            raise ValueError('Destino incompleto. Preserve-o e selecione outra pasta.')
        print('Cópia interna existente preservada, incluindo configurações e progresso.', flush=True)
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + '.copying')
    if temporary.exists():
        raise ValueError('Existe uma cópia interrompida em ' + str(temporary) + '. Confira-a antes de tentar novamente.')
    shutil.copytree(source, temporary, symlinks=True)
    verify_original(temporary / 'game/windows/SnakeReyers.exe')
    temporary.replace(destination)
    return destination


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', nargs='?', type=Path, default=Path.home() / 'storage/downloads/Bluetooth/SNACK/SnakeReyers')
    parser.add_argument('--destination', type=Path, default=Path.home() / 'SnakeReyers-Termux/original')
    args = parser.parse_args()
    try:
        result = prepare(args.source, args.destination)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    state = Path(__file__).resolve().parents[1] / 'state'
    state.mkdir(exist_ok=True)
    (state / 'project-path.txt').write_text(str(result) + '\n')
    # Local private backup before first configuration changes. Never packaged.
    backup = state / 'original-private-backup'
    if not backup.exists():
        backup.mkdir(mode=0o700)
        for name in ('private', 'config'):
            path = result / 'server' / name
            if path.is_dir():
                shutil.copytree(path, backup / name)
        (backup / 'backup.json').write_text(json.dumps({'project': str(result), 'created_at': time.time()}))
    print('Projeto pessoal preparado em: ' + str(result))


if __name__ == '__main__':
    main()
