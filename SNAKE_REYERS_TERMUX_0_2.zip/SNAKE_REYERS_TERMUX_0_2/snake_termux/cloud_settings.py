"""Reversible optional cloud integration over the existing local adapter."""
from __future__ import annotations

import os
import re
import uuid
from pathlib import Path

from .cloud_ai import CloudAPI, CloudVoice, APIError, VOICES, STYLES, api_key, model_name


def install(binding, app):
    from fastapi import HTTPException
    from starlette.concurrency import run_in_threadpool
    base_config, base_update = binding.config, binding.update
    base_public, base_transport = binding.public_status, binding.transport
    base_voice_config, base_voice = binding.voice_config, binding.local_voice
    api = CloudAPI(binding.settings._raw, binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE)
    voice = CloudVoice(api)
    binding.cloud_api = api

    def save(raw):
        binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
        os.chmod(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)

    def provider():
        value = binding.settings._raw().get('termux_response_provider', 'local')
        return value if value in ('local', 'openai', 'gemini') else 'local'

    def config():
        local = base_config()
        selected = provider()
        if selected == 'local': return local
        raw = binding.settings._raw()
        key_present = bool(raw.get('openai_api_key') or raw.get('api_key')) if selected == 'openai' else bool(api.entries())
        return {**local, 'provider': selected,
                'model': raw.get('termux_openai_model', 'gpt-4.1-mini') if selected == 'openai' else raw.get('termux_gemini_model', 'auto'),
                'api_key_present': key_present, 'auto_external_call': local['enabled'] and key_present, 'auto_local_call': False}

    def public():
        selected = provider()
        status = base_public()  # Existing local diagnostics remain available.
        status.update(config())
        raw = binding.settings._raw()
        status.update(requires_api_key=selected != 'local',
            openai_key_present=bool(raw.get('openai_api_key') or raw.get('api_key')),
            openai_model=raw.get('termux_openai_model', 'gpt-4.1-mini'),
            gemini_model=raw.get('termux_gemini_model', 'auto'),
            local_model=raw.get('model', 'auto') if raw.get('provider') == 'local' else raw.get('local_model', 'auto'),
            cloud_status={key: dict(value) for key, value in api.diagnostics.items()},
            gemini_keys=api.keys_public(), cloud_requires_internet=True,
            billing_note='ChatGPT e API têm cobranças separadas. Gemini gratuito depende do modelo, da conta e da cota disponível.')
        return status

    def update(payload):
        raw = binding.settings._raw()
        selected = payload.get('provider', provider())
        if selected not in ('local', 'openai', 'gemini'):
            raise ValueError('Escolha Qwen local, Gemini ou OpenAI.')
        for key in ('enabled', 'clear_key'):
            if key in payload and type(payload[key]) is not bool:
                raise ValueError('Estado inválido: ' + key)
        if payload.get('api_key'):
            raw['openai_api_key'] = api_key(payload['api_key'])
            raw.pop('api_key', None)
        if payload.get('clear_key'):
            raw.pop('openai_api_key', None); raw.pop('api_key', None)
        if 'gemini_keys' in payload:
            additions = payload['gemini_keys']
            if not isinstance(additions, list) or len(additions) > 10:
                raise ValueError('Adicione até dez chaves Gemini.')
            entries = list(raw.get('termux_gemini_keys', []))
            for addition in additions:
                if not isinstance(addition, dict): raise ValueError('Entrada de chave Gemini inválida.')
                value = api_key(addition.get('key'))
                project = str(addition.get('project') or 'default').strip()
                if not re.fullmatch(r'[A-Za-z0-9._-]{1,60}', project):
                    raise ValueError('Use um nome simples para o grupo de projeto, sem espaços.')
                if any(entry['value'] == value for entry in entries): continue
                entries.append({'id': uuid.uuid4().hex, 'label': 'Gemini ' + str(len(entries) + 1) + ' · …' + value[-4:], 'project': project, 'value': value})
            if len(entries) > 10: raise ValueError('A biblioteca aceita até dez chaves Gemini.')
            raw['termux_gemini_keys'] = entries
        if 'remove_gemini_key' in payload:
            remove = payload['remove_gemini_key']
            if not isinstance(remove, str): raise ValueError('ID de chave inválido.')
            raw['termux_gemini_keys'] = [entry for entry in raw.get('termux_gemini_keys', []) if entry['id'] != remove]
        if selected == 'openai' and 'model' in payload and 'openai_model' not in payload:
            raw['termux_openai_model'] = model_name(payload['model'])
        if selected == 'gemini' and 'model' in payload and 'gemini_model' not in payload:
            raw['termux_gemini_model'] = model_name(payload['model'])
        if 'openai_model' in payload: raw['termux_openai_model'] = model_name(payload['openai_model'])
        if 'gemini_model' in payload: raw['termux_gemini_model'] = model_name(payload['gemini_model'])
        raw['termux_response_provider'] = selected  # Only explicit save opts into cloud calls.
        # Keep legacy key/provider history intact. Local model remains independent.
        enabled = False if payload.get('clear_key') and selected == 'openai' else payload.get('enabled', config()['enabled'])
        if selected == 'local':
            from .client import valid_model, valid_port
            raw['model'] = valid_model(payload.get('model') or (raw.get('model') if raw.get('provider') == 'local' else raw.get('local_model')) or 'auto')
            raw['provider'] = 'local'
            raw['local_port'] = valid_port(payload.get('local_port', config()['local_port']))
        raw['enabled'] = enabled
        if enabled and selected == 'openai' and not (raw.get('openai_api_key') or raw.get('api_key')):
            raise ValueError('Adicione uma chave OpenAI antes de ativar essa opção.')
        if enabled and selected == 'gemini' and not raw.get('termux_gemini_keys'):
            raise ValueError('Adicione pelo menos uma chave Gemini antes de ativar essa opção.')
        previous_key = binding.settings._raw().get('openai_api_key') or binding.settings._raw().get('api_key')
        save(raw)
        if previous_key != (raw.get('openai_api_key') or raw.get('api_key')):
            api.provider_cooldowns.clear()
            api.voice_ready = False
            for name in ('openai', 'speech'):
                api.diagnostics[name].update(ready=None, last_error='', code='')
        return public()

    def transport(data):
        selected = provider()
        if selected == 'local': return base_transport(data)
        identity = binding.ai.CHAT_IDENTITY_PROMPT + '\nO público te apelidou de Cofra do Afismo. Preserve a identidade original e responda com humor sem ofender o espectador.'
        return api.reply(selected, data, identity)

    def voice_config():
        raw = binding.settings._raw()
        if raw.get('termux_cloud_voice_enabled') is True:
            return {**base_voice_config(), 'provider': 'openai', 'voice': raw.get('termux_openai_voice', 'cedar'),
                    'style': raw.get('termux_voice_style', 'clear'), 'model': 'gpt-4o-mini-tts', 'ai_generated': True}
        return base_voice_config()

    def local_voice():
        return voice if voice_config()['provider'] == 'openai' else base_voice()

    binding.config, binding.public_status, binding.update = config, public, update
    binding.transport, binding.voice_config, binding.local_voice = transport, voice_config, local_voice

    @app.get('/termux/cloud-ui.js')
    def cloud_ui():
        from fastapi.responses import FileResponse
        return FileResponse(Path(__file__).with_name('cloud_ui.js'), media_type='application/javascript', headers={'Cache-Control': 'no-store'})

    @app.get('/termux/cloud/settings')
    def status():
        return public()

    @app.post('/termux/cloud/settings')
    def settings(payload: dict):
        try: return update(payload)
        except ValueError as exc: raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post('/termux/ai/test')
    async def test(payload: dict):
        question = str(payload.get('text') or '').strip()
        if not question or len(question) > 180:
            raise HTTPException(status_code=400, detail='Teste: até 180 caracteres.')
        if not config()['enabled']: raise HTTPException(status_code=409, detail='Ative o provedor de respostas primeiro.')
        answer = await run_in_threadpool(binding.ai.generate_chat_reply, display_name='Teste', comment=question, user_key='operator-cloud-test')
        selected = provider()
        diagnostics = binding.local_client().diagnostics if selected == 'local' else api.diagnostics[selected]
        if not answer: raise HTTPException(status_code=503, detail=diagnostics.get('last_error') or 'A IA não devolveu resposta.')
        return {'ok': True, 'provider': selected, 'text': answer, 'diagnostics': dict(diagnostics)}

    @app.post('/termux/gemini/check')
    async def check(payload: dict):
        key_id = payload.get('id')
        if not isinstance(key_id, str) or not any(e['id'] == key_id for e in api.entries()):
            raise HTTPException(status_code=400, detail='Selecione uma chave cadastrada.')
        try:
            await run_in_threadpool(api.gemini_call, 'Responda apenas OK.', 'Verificação de disponibilidade. Responda OK.',
                                    model_name(binding.settings._raw().get('termux_gemini_model', 'auto')), only_id=key_id, check=True)
            return {'ok': True, 'keys': api.keys_public(), 'note': 'A chave respondeu agora; o teste não informa saldo futuro e consome cota.'}
        except APIError as exc:
            return {'ok': False, 'keys': api.keys_public(), 'error': str(exc), 'code': exc.code}

    @app.post('/termux/cloud/voice')
    def voice_settings(payload: dict):
        selected = payload.get('provider', 'piper-local')
        if selected not in ('openai', 'piper-local', 'xtts'):
            raise HTTPException(status_code=400, detail='Escolha Piper, OpenAI ou XTTS.')
        try:
            from .client import valid_port
            port = valid_port(payload.get('port', base_voice_config()['port']))
            voice_name = payload.get('voice', binding.settings._raw().get('termux_openai_voice', 'cedar'))
            style = payload.get('style', binding.settings._raw().get('termux_voice_style', 'clear'))
            if voice_name not in VOICES or style not in STYLES: raise ValueError('Voz ou estilo inválido.')
            raw = binding.settings._raw()
            if selected == 'openai' and not (raw.get('openai_api_key') or raw.get('api_key')):
                raise ValueError('Salve uma chave OpenAI no painel antes de selecionar essa voz.')
            raw.update(termux_cloud_voice_enabled=selected == 'openai', voice_provider=selected if selected != 'openai' else 'piper-local',
                       voice_local_port=port, termux_openai_voice=voice_name, termux_voice_style=style)
            save(raw)
            return voice_config()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
