from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

EXPECTED_BYTES = 193264984
EXPECTED_SHA256 = '9a16a7f9596146927ececdbba523b8f0aefc59f0568d898e097f6f2bd598cd97'
NVIDIA_ENV = ('DRI_PRIME', '__GLX_VENDOR_LIBRARY_NAME', '__NV_PRIME_RENDER_OFFLOAD', '__VK_LAYER_NV_optimus')


def prepare_device(env: dict, state: Path) -> tuple[dict, dict]:
    try:
        from .device_runtime import prepare_game
    except ModuleNotFoundError as exc:
        # Older version-only repairs can still run without the optional module.
        if exc.name != 'snake_termux.device_runtime':
            raise
        return dict(env), {}
    try:
        from .device_runtime import prepare_graphics
    except ImportError:
        return prepare_game(env, state)
    return prepare_graphics(env, state)


def prepare_presentation(env: dict, state: Path, device: dict) -> dict:
    try:
        from .presentation import prepare_display
    except ModuleNotFoundError as exc:
        if exc.name != 'snake_termux.presentation':
            raise
        return device
    return prepare_display(state, env, device)


def finalize_device_audio(env: dict, state: Path, device: dict) -> tuple[dict, dict]:
    try:
        from .device_runtime import finalize_audio
    except ImportError:
        return env, device  # Older optional GPU modules keep their prior behavior.
    try:
        return finalize_audio(env, state, device, requested_sink=os.environ.get('PULSE_SINK'))
    except Exception as exc:
        # Audio is optional for opening the game. Filesystem/adapter errors
        # during this preflight must not abort FastAPI's startup and kill X11.
        error = f'{type(exc).__name__}: {exc}'[:900]
        print('Preparação de áudio falhou; abrindo a imagem mesmo assim. ' + error, flush=True)
        report = {**device, 'audio': {**device.get('audio', {}), 'output_available': False,
                  'stream_preflight_ok': False, 'message': 'Áudio não preparado; a janela pode abrir sem som.',
                  'preparation_error': error}}
        return dict(env), report


def verify_original(path: Path) -> dict:
    if not path.is_file() or path.stat().st_size != EXPECTED_BYTES:
        raise ValueError('Não encontrei o SnakeReyers.exe original 0.1.9 completo em game/windows.')
    digest = hashlib.sha256()
    with path.open('rb') as file:
        while chunk := file.read(1024 * 1024):
            digest.update(chunk)
    if digest.hexdigest() != EXPECTED_SHA256:
        raise ValueError('O SHA-256 do jogo difere da versão 0.1.9 conferida. O arquivo foi preservado.')
    return {'bytes': EXPECTED_BYTES, 'sha256': digest.hexdigest(), 'verified': True}


def parse_godot_version(stdout: str, stderr: str = '') -> tuple[int, int, int] | None:
    output = stdout + '\n' + stderr
    output = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', output).replace('\ufeff', '')
    match = re.search(r'(?m)^\s*(?:Godot Engine\s+v?)?(\d+)\.(\d+)(?:\.(\d+))?(?=[.\s+\-]|$)', output)
    if not match:
        return None
    return int(match[1]), int(match[2]), int(match[3] or 0)


def resolve_godot(value: str | None = None) -> Path:
    binary = value or os.environ.get('SNAKE_GODOT_BIN') or shutil.which('godot') or shutil.which('godot-4')
    if not binary:
        raise ValueError('Falta Godot nativo da série 4.7. Prepare os pacotes Termux/X11.')
    path = Path(binary).expanduser().resolve()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError('O caminho do Godot nativo não é executável.')
    try:
        result = subprocess.run([str(path), '--version'], capture_output=True, text=True, timeout=10)
    except subprocess.TimeoutExpired as exc:
        raise ValueError('Godot demorou demais ao consultar --version: ' + str(path)) from exc
    details = ' '.join((result.stdout + '\n' + result.stderr).split())[:700] or '(sem saída)'
    if result.returncode:
        raise ValueError(f'Godot não conseguiu executar --version (código {result.returncode}): {details}')
    version = parse_godot_version(result.stdout, result.stderr)
    if version is None:
        raise ValueError('Não foi possível reconhecer a versão do Godot. Saída recebida: ' + details)
    # Godot's PCK loader checks the engine's major/minor, not patch. Termux
    # legitimately prints 4.7.stable.termux; treating a missing patch as an
    # incompatible binary blocked the service before the game could start.
    if version[:2] != (4, 7):
        raise ValueError(f'Godot encontrado: {version[0]}.{version[1]}.{version[2]}. Esta adaptação foi validada com a série 4.7. Executável: {path}')
    return path


def native_command(godot: Path, pack: Path, args: list[str], *, workdir: Path, renderer: str = 'gl_compatibility', audio_driver: str | None = None) -> list[str]:
    if renderer not in ('gl_compatibility', 'mobile'):
        raise ValueError('Renderizador inválido; use gl_compatibility ou mobile.')
    # Desktop launch plans target a second monitor. Termux:X11 normally has one.
    args = list(args)
    for index, value in enumerate(args[:-1]):
        if value == '--':
            break
        if value == '--screen':
            args[index + 1] = '0'
    defaults = ['--main-pack', str(pack), '--path', str(workdir), '--rendering-method', renderer]
    if '--headless' not in args:
        if '--display-driver' not in args:
            defaults += ['--display-driver', 'x11']
        if '--audio-driver' not in args:
            audio_driver = audio_driver or os.environ.get('SNAKE_AUDIO_DRIVER', 'PulseAudio')
            if audio_driver not in ('PulseAudio', 'Dummy'):
                raise ValueError('Driver de áudio inválido; use PulseAudio ou Dummy para diagnóstico.')
            defaults += ['--audio-driver', audio_driver]
    return [str(godot), *defaults, *args]


class NativeGame:
    def __init__(self, project: Path, *, godot: str | None = None, port: int = 9393, state_dir: Path | None = None):
        self.project = project.resolve()
        self.pack = self.project / 'game/windows/SnakeReyers.exe'
        self.godot = resolve_godot(godot)
        self.integrity = verify_original(self.pack)
        self.port = port
        self.state_dir = (state_dir or Path(__file__).resolve().parents[1] / 'state').resolve()
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.state_dir / 'logs/game-native.log'
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.wrapper = self.state_dir / 'bin/SnakeReyers-native'
        self.process: subprocess.Popen | None = None
        self.log = None
        self.log_offset = 0
        self.audio_service = None
        self.audio_driver = None
        self.audio_env = None
        self.started_at = 0.0
        self.last_exit_code = None
        self.device_report = {}
        self.observed_renderer = None
        self.lock = threading.RLock()
        self.renderer = os.environ.get('SNAKE_RENDERER', 'gl_compatibility')
        native_command(self.godot, self.pack, [], workdir=self.state_dir, renderer=self.renderer)

    def prepare_wrapper(self) -> Path:
        self.wrapper.parent.mkdir(parents=True, exist_ok=True)
        shell = shutil.which('bash')
        if not shell:
            raise ValueError('Falta bash para o iniciador nativo.')
        module_root = Path(__file__).resolve().parents[1]
        text = f'#!{shell}\n# Independent adapter; original game remains unchanged.\nexport PYTHONPATH={shlex.quote(str(module_root))}\nexec {shlex.quote(sys.executable)} -m snake_termux.native --project {shlex.quote(str(self.project))} --godot {shlex.quote(str(self.godot))} --workdir {shlex.quote(str(self.state_dir))} -- "$@"\n'
        temporary = self.wrapper.with_suffix('.tmp')
        temporary.write_text(text, encoding='utf-8')
        temporary.chmod(0o700)
        temporary.replace(self.wrapper)
        return self.wrapper

    def status(self) -> dict:
        with self.lock:
            if self.process and self.process.poll() is not None:
                self.last_exit_code = self.process.returncode
                self.process = None
                if self.audio_service:
                    self.audio_service.stop()
                if self.log:
                    self.log.close()
                    self.log = None
                with (self.state_dir / 'process-events.jsonl').open('a') as file:
                    file.write(json.dumps({'event': 'game_exit', 'at': time.time(), 'code': self.last_exit_code}) + '\n')
            audio_runtime = {'state': 'pending', 'message': 'Aguardando inicialização do áudio do jogo.'}
            if self.process and self.audio_driver == 'Dummy':
                audio_runtime = {'state': 'dummy', 'driver': 'Dummy',
                                 'message': 'Imagem em execução sem som: a saída de áudio não ficou disponível.'}
            if self.process and self.log_path.exists():
                with self.log_path.open('rb') as stream:
                    stream.seek(self.log_offset)
                    startup = stream.read(8192).decode('utf-8', errors='replace')
                    stream.seek(max(self.log_offset, self.log_path.stat().st_size - 16384))
                    output = startup + '\n' + stream.read(16384).decode('utf-8', errors='replace')
                match = re.search(r'Using Device:\s*(.+)', startup)
                if match: self.observed_renderer = match[1].strip()
                fps_matches = re.findall(r'(?:Project\s+)?FPS:\s*(\d+(?:\.\d+)?)', output, flags=re.I)
            else:
                fps_matches = []
            if self.process and self.log_path.exists():
                if 'falling back to the dummy driver' in output.lower():
                    audio_runtime = {'state': 'dummy', 'driver': 'Dummy',
                                     'message': 'Jogo sem som: Godot iniciou com driver Dummy. Feche e abra a janela após preparar o áudio Android.'}
                elif self.audio_driver != 'Dummy' and ('SPEECH_AUDIO_STARTED' in output or 'MUSIC_TRACK_STARTED' in output):
                    audio_runtime = {'state': 'playback-requested',
                                     'message': 'O jogo iniciou reprodução interna; isso não confirma som audível.'}
            return {'running': self.process is not None, 'pid': self.process.pid if self.process else None,
                    'started_at': self.started_at, 'last_exit_code': self.last_exit_code, 'log': str(self.log_path),
                    'godot': str(self.godot), 'renderer': self.renderer, 'original_verified': self.integrity['verified'],
                    'device': self.device_report,
                    'audio_runtime': audio_runtime,
                    'performance': {'fps': float(fps_matches[-1]) if fps_matches else None,
                        'observed_renderer': self.observed_renderer,
                        'software_renderer': any(word in (self.observed_renderer or '').lower() for word in ('llvmpipe','softpipe','lavapipe','swrast'))},
                    'automatic_restarts': 0, 'android_validation': 'pending'}

    def start(self) -> dict:
        with self.lock:
            if self.status()['running']:
                return self.status()
            if not os.environ.get('DISPLAY'):
                raise ValueError('DISPLAY não configurado. Inicie Termux:X11 antes do jogo.')
            env = os.environ.copy()
            for name in NVIDIA_ENV:
                env.pop(name, None)
            env, self.device_report = prepare_device(env, self.state_dir)
            self.device_report = prepare_presentation(env, self.state_dir, self.device_report)
            try:
                from .device_runtime import config
            except ImportError:
                managed_audio = False
            else:
                managed_audio = env.get('PREFIX', '').startswith('/data/') and config(self.state_dir).get('enabled') is True
            # Explicit capture routes belong to the original capture launcher.
            if managed_audio and not os.environ.get('PULSE_SINK'):
                try:
                    from .audio_service import PrivateAudio
                except ImportError:
                    env, self.device_report = finalize_device_audio(env, self.state_dir, self.device_report)
                else:
                    self.audio_service = PrivateAudio(self.state_dir)
                    env, self.device_report = self.audio_service.start(env, self.device_report)
            else:
                env, self.device_report = finalize_device_audio(env, self.state_dir, self.device_report)
            env['COBRINHA_LIVE_SERVER_URL'] = f'ws://127.0.0.1:{self.port}/ws/godot'
            env['COBRINHA_TERRAIN_EDITOR_FILE'] = str(self.project / 'server/private/cobrinha_terrain_editor.json')
            graphics = self.device_report.get('graphics', {})
            full = self.device_report.get('display', {}).get('fullscreen', False)
            args = ['--fullscreen' if full else '--windowed', '--resolution', graphics.get('resolution', '720x1280')]
            if graphics.get('max_fps'):
                args.extend(['--max-fps', str(graphics['max_fps'])])
            if self.device_report.get('audio', {}).get('godot_latency_ms'):
                args.extend(['--audio-output-latency', str(self.device_report['audio']['godot_latency_ms'])])
            args.extend(['--print-fps', '--', '--cobrinha-live'])
            output = self.device_report.get('audio', {})
            audio_driver = 'PulseAudio' if output.get('output_available') else ('Dummy' if 'output_available' in output else None)
            self.audio_driver = audio_driver
            self.audio_env = dict(env)
            command = native_command(self.godot, self.pack, args, workdir=self.state_dir, renderer=self.renderer, audio_driver=audio_driver)
            self.log = self.log_path.open('ab', buffering=0)
            self.log_offset = self.log_path.stat().st_size
            try:
                self.process = subprocess.Popen(command, cwd=self.state_dir, env=env, stdout=self.log, stderr=subprocess.STDOUT)
            except Exception:
                self.log.close()
                self.log = None
                if self.audio_service:
                    self.audio_service.stop()
                raise
            self.observed_renderer = None
            self.started_at = time.time()
            return self.status()

    def stop(self) -> dict:
        with self.lock:
            if self.process and self.process.poll() is None:
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=5)
            if self.audio_service:
                self.audio_service.stop()
            return self.status()


def attach(binding, app, native: NativeGame, *, auto_start: bool = False):
    from fastapi import HTTPException
    from cobrinha_server.services import preview_renderer, session_executor_plan
    old_executable = session_executor_plan.EXPORTED_GAME_EXECUTABLE
    old_dir = session_executor_plan.EXPORTED_GAME_DIR
    wrapper = native.prepare_wrapper()
    binding.replace_aliases(old_executable, wrapper)
    binding.replace_aliases(old_dir, wrapper.parent)
    app.state.snake_native_game = native

    # Optional for older, version-only repairs. Music is installed before the
    # game's initial websocket handshake, only when its library is empty.
    try:
        from . import presentation
    except ImportError:
        presentation = None
    if presentation is not None:
        def starter_music():
            from cobrinha_server.services import music_runtime
            try:
                result = presentation.provision_music(music_runtime, native.state_dir)
                if result.get('added'):
                    print(result['message'], flush=True)
            except (OSError, ValueError) as exc:
                print('Trilha opcional: ' + str(exc), flush=True)
        app.add_event_handler('startup', starter_music)

        @app.get('/termux/presentation')
        def presentation_status():
            return {'settings': presentation.settings(native.state_dir),
                    'display': native.device_report.get('display', {})}

        @app.post('/termux/presentation')
        def presentation_settings(payload: dict):
            try:
                saved = presentation.save_settings(native.state_dir, payload)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            return {'settings': saved, 'restart_required': True}

    @app.get('/termux/game')
    def status():
        from cobrinha_server.bridge.godot_bridge import godot_bridge
        return {**native.status(), 'bridge_connected': godot_bridge.status()['connected']}

    @app.post('/termux/game/start')
    def start():
        try:
            return native.start()
        except (ValueError, OSError) as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.post('/termux/game/stop')
    def stop():
        return native.stop()

    @app.post('/termux/audio/test')
    def audio_test():
        from .device_runtime import test_audio
        if native.audio_service:
            if not native.device_report.get('audio', {}).get('output_available'):
                return native.device_report.get('audio', {})
            return test_audio(native.state_dir, base=native.audio_env)
        return test_audio(native.state_dir)

    @app.post('/termux/audio/speech-test')
    def speech_test():
        from cobrinha_server.bridge.godot_bridge import godot_bridge
        from cobrinha_server.services.speech_queue import enqueue_manual_sequence
        if not godot_bridge.status()['connected']:
            raise HTTPException(status_code=409, detail='Abra o jogo primeiro para testar sua fala.')
        try:
            sequence = enqueue_manual_sequence('Olá! A cobra está pronta para conversar com vocês.')
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return {'queued': True, 'sequence': sequence}

    # Own validated playlist controller; optional for old partial repair packages.
    try:
        from .music_library import attach as attach_music
    except ImportError:
        library = None
    else:
        library = attach_music(binding, app, native)

    from starlette.requests import Request
    from starlette.datastructures import UploadFile

    async def music_upload(request):
        if library is not None:
            return await library.upload(request)
        from .device_runtime import save_music
        from cobrinha_server.services import music_runtime
        from cobrinha_server.bridge.godot_bridge import godot_bridge, preview_bridge
        form = await request.form(max_files=1, max_fields=0)
        upload = form.get('file')
        if not isinstance(upload, UploadFile):
            raise HTTPException(status_code=400, detail='Selecione um arquivo de música.')
        try:
            target = await save_music(upload, music_runtime.BACKGROUND_MUSIC_DIR)
        except ValueError as exc:
            await upload.close()
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        music = music_runtime.update(enabled=True, current_track=str(target))
        for bridge in (godot_bridge, preview_bridge):
            if bridge.status()['connected']:
                await bridge.send(music_runtime.websocket_message())
        return {'ok': True, 'file': target.name, 'track_count': len(music.get('tracks', []))}

    # Keep native.py importable before FastAPI is installed by the bootstrap.
    music_upload.__annotations__['request'] = Request
    app.add_api_route('/termux/music/upload', music_upload, methods=['POST'])

    if auto_start:
        app.add_event_handler('startup', native.start)

    def shutdown():
        native.stop()
        # Version 0.1.9 exposes process handles but has no public stop_preview.
        # Only terminate children actually launched by this server instance.
        for name in ('_PREVIEW_PROCESS', '_TERRAIN_EDITOR_PROCESS'):
            process = getattr(preview_renderer, name, None)
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
        preview_renderer._refresh_process()
    app.add_event_handler('shutdown', shutdown)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', required=True, type=Path)
    parser.add_argument('--godot', required=True)
    parser.add_argument('--workdir', required=True, type=Path)
    parser.add_argument('engine_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    # Used only by launch plans of the original server, never by model output.
    game = NativeGame(args.project, godot=args.godot, state_dir=args.workdir)
    engine_args = args.engine_args[1:] if args.engine_args[:1] == ['--'] else args.engine_args
    env = os.environ.copy()
    for name in NVIDIA_ENV:
        env.pop(name, None)
    env, device = prepare_device(env, game.state_dir)
    env, device = finalize_device_audio(env, game.state_dir, device)
    graphics = device.get('graphics', {})
    if graphics.get('max_fps') and '--max-fps' not in engine_args:
        engine_args = ['--max-fps', str(graphics['max_fps']), *engine_args]
    if device.get('audio', {}).get('godot_latency_ms') and '--audio-output-latency' not in engine_args:
        engine_args = ['--audio-output-latency', str(device['audio']['godot_latency_ms']), *engine_args]
    output = device.get('audio', {})
    audio_driver = 'PulseAudio' if output.get('output_available') else ('Dummy' if 'output_available' in output else None)
    command = native_command(game.godot, game.pack, engine_args, workdir=game.state_dir, renderer=game.renderer, audio_driver=audio_driver)
    os.execvpe(command[0], command, env)


if __name__ == '__main__':
    main()
