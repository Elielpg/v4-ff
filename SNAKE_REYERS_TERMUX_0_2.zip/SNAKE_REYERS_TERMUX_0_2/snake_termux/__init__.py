"""Independent local-service adapter for the user's own Snake Reyers installation."""
