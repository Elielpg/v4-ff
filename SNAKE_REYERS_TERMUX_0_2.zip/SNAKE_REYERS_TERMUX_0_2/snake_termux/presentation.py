"""Portrait X11 presentation and an optional, bundled original soundtrack.

Only documented Termux:X11 preferences are changed. No Android global settings,
game resources or voice output routes are modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import time
from pathlib import Path

from .device_runtime import atomic_json

ROOT = Path(__file__).resolve().parents[1]
PROFILES = {'balanced': ('720x1280', 60), 'light': ('640x1136', 60), 'sharp': ('864x1536', 60), 'live': ('640x1136', 45), 'stable': ('640x1136', 30), 'clear': ('720x1280', 45), 'quality30': ('864x1536', 30)}
PROFILES.update(gt3_live=('720x1280', 30), gt3_detail=('864x1536', 30), gt3_high=('1072x1920', 30))
TRACK = ROOT / 'assets/music/Neon Garden.ogg'
# Filled from the reproducibly generated, original audio in tools/create_music.py.
TRACK_SHA256 = '482b4e4afbce75d1b810f1b981a0529ef4fb9fe211d6b8656e5e78530ac243f7'
DISPLAY_KEYS = {
    'fullscreen': 'true', 'showAdditionalKbd': 'false',
    'additionalKbdVisible': 'false', 'showMouseHelper': 'false',
    'displayResolutionMode': 'custom', 'displayResolutionCustom': '720x1280',
    'displayStretch': 'false', 'adjustResolution': 'false',
    'forceOrientation': 'portrait',
}


def settings(state: Path) -> dict:
    try:
        raw = json.loads((state / 'presentation-config.json').read_text())
    except (OSError, ValueError):
        raw = {}
    if not isinstance(raw, dict):
        raw = {}
    return {'profile': raw.get('profile') if isinstance(raw.get('profile'), str) and raw['profile'] in PROFILES else 'balanced',
            'clean_display': raw.get('clean_display', True) is True}


def save_settings(state: Path, payload: dict) -> dict:
    current = settings(state)
    if set(payload) - {'profile', 'clean_display'}:
        raise ValueError('Opção de exibição desconhecida.')
    if 'profile' in payload:
        if not isinstance(payload['profile'], str) or payload['profile'] not in PROFILES:
            raise ValueError('Escolha um perfil de qualidade disponível no painel.')
        current['profile'] = payload['profile']
    if 'clean_display' in payload:
        if not isinstance(payload['clean_display'], bool):
            raise ValueError('clean_display deve ser true ou false.')
        current['clean_display'] = payload['clean_display']
    atomic_json(state / 'presentation-config.json', current)
    return current


def pref_command(args: list[str], env: dict) -> str:
    # The official tool can wait indefinitely if the Android activity is absent.
    # DEVNULL also prevents its stdin settings parser from waiting on our terminal.
    result = subprocess.run(['termux-x11-preference', *args], env=env,
                            stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=7)
    if result.returncode:
        raise ValueError((result.stderr or result.stdout or 'Termux:X11 não respondeu.')[-800:])
    return result.stdout


def read_preferences(env: dict) -> dict:
    output = pref_command(['list'], env)
    # Read only our own, documented keys; never store clipboard/keyboard content.
    pairs = re.findall(r'^"([A-Za-z]+)"="([^"\r\n]*)"\s*$', output, flags=re.MULTILINE)
    values = {key: value for key, value in pairs if key in DISPLAY_KEYS}
    if not values:
        raise ValueError('A lista de preferências X11 não foi reconhecida.')
    return values


def clean_display(state: Path, env: dict, resolution: str) -> dict:
    report = {'applied': False, 'resolution': resolution, 'fullscreen': False}
    try:
        before = read_preferences(env)
        required = {'fullscreen', 'showAdditionalKbd', 'displayResolutionMode', 'displayResolutionCustom'}
        if not required <= before.keys():
            raise ValueError('O aplicativo X11 não oferece todas as opções necessárias; ajuste-o pelas preferências.')
        target = {key: value for key, value in DISPLAY_KEYS.items() if key in before}
        target['displayResolutionCustom'] = resolution
        backup = state / 'x11-display-before-v025.json'
        if not backup.exists():
            atomic_json(backup, before)
        changes = [f'{key}:{value}' for key, value in target.items() if before[key] != value]
        if changes:
            pref_command(changes, env)
        after = read_preferences(env)
        mismatches = [key for key, value in target.items() if after.get(key) != value]
        if mismatches:
            raise ValueError('Preferências X11 não confirmadas: ' + ', '.join(mismatches))
        # Preference changes recreate the Android view asynchronously. Do not
        # start a fullscreen game on the old landscape/native X screen.
        dimensions = None
        for attempt in range(16):
            result = subprocess.run(['xdpyinfo', '-display', env.get('DISPLAY', ':1')], env=env,
                                    capture_output=True, text=True, timeout=2)
            match = re.search(r'dimensions:\s+(\d+x\d+)\s+pixels', result.stdout)
            dimensions = match[1] if match else None
            if result.returncode == 0 and dimensions == resolution:
                break
            if attempt < 15:
                time.sleep(.2)
        else:
            raise ValueError(f'A tela X11 ainda informa {dimensions or "dimensão desconhecida"}; esperado {resolution}.')
        report.update(applied=True, fullscreen=True, preferences=after,
                      message='Tela cheia em retrato; teclas extras ocultas; proporção preservada.')
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report['message'] = 'Tela limpa não confirmada: ' + str(exc)[:900]
    atomic_json(state / 'display-runtime.json', report)
    return report


def restore_display(state: Path, env: dict) -> dict:
    previous = json.loads((state / 'x11-display-before-v025.json').read_text())
    if not isinstance(previous, dict):
        raise ValueError('Backup de exibição inválido.')
    previous = {key: value for key, value in previous.items()
                if key in DISPLAY_KEYS and isinstance(value, str) and re.fullmatch(r'[a-zA-Z0-9 x]+', value)}
    if not previous:
        raise ValueError('Backup de exibição vazio.')
    pref_command([f'{key}:{value}' for key, value in previous.items()], env)
    actual = read_preferences(env)
    if any(actual.get(key) != value for key, value in previous.items()):
        raise ValueError('O aplicativo não confirmou a restauração das preferências.')
    save_settings(state, {'clean_display': False})
    return {'restored': True, 'preferences': actual}


def prepare_display(state: Path, env: dict, device: dict) -> dict:
    if not env.get('PREFIX', '').startswith('/data/'):
        return device
    result = dict(device)
    graphics = dict(result.get('graphics', {}))
    chosen = settings(state)
    if graphics.get('hardware_verified'):
        graphics.update(zip(('resolution', 'max_fps'), PROFILES[chosen['profile']]))
        graphics['profile'] = chosen['profile']
        result['graphics'] = graphics
    resolution = graphics.get('resolution', '720x1280')
    # libxcvt used by Termux:X11 rounds custom widths down to a multiple of 8.
    width, height = map(int, resolution.split('x'))
    resolution = f'{max(8, width - width % 8)}x{height}'
    if graphics:
        graphics['resolution'] = resolution
        result['graphics'] = graphics
    if chosen['clean_display']:
        result['display'] = clean_display(state, env, resolution)
    else:
        result['display'] = {'applied': False, 'fullscreen': False, 'message': 'Modo de janela preservado.'}
    if result:
        atomic_json(state / 'device-runtime.json', result)
    return result


def provision_music(music_runtime, state: Path) -> dict:
    """Fill an empty library once; preserve existing files, selection and mute."""
    marker = state / 'starter-music.json'
    if marker.exists() or music_runtime.tracks():
        return {'added': False}
    if not TRACK.is_file() or hashlib.sha256(TRACK.read_bytes()).hexdigest() != TRACK_SHA256:
        raise ValueError('A trilha instrumental não passou na verificação de integridade.')
    directory = music_runtime.BACKGROUND_MUSIC_DIR
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / TRACK.name
    # Exclusive creation: never replace any user-provided audio.
    with target.open('xb') as file:
        file.write(TRACK.read_bytes())
    atomic_json(marker, {'file': str(target), 'sha256': TRACK_SHA256, 'added_at': time.time()})
    return {'added': True, 'file': target.name, 'message': 'Trilha instrumental Neon Garden adicionada.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state', type=Path, default=ROOT / 'state')
    parser.add_argument('--profile', choices=tuple(PROFILES))
    parser.add_argument('--restore-display', action='store_true')
    args = parser.parse_args()
    if args.profile:
        print(json.dumps(save_settings(args.state, {'profile': args.profile}), ensure_ascii=False))
    if args.restore_display:
        print(json.dumps(restore_display(args.state, dict(os.environ)), ensure_ascii=False))


if __name__ == '__main__':
    main()
