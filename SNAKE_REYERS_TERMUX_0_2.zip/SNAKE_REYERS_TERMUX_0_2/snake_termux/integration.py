from __future__ import annotations

import functools
import importlib
import os
import re
import sys
from pathlib import Path

from .client import LocalQwen, valid_model, valid_port
from .voice import PiperClient, voice_chunks


def normalize_username(value: object) -> str:
    username = str(value or '').strip().lstrip('@')
    if not re.fullmatch(r'[A-Za-z0-9_.]{1,24}', username):
        raise ValueError('Informe o @ do perfil que está ao vivo, por exemplo @seu.usuario.')
    return username


class LocalBinding:
    """Installs reversible runtime hooks; no upstream source or game asset is rewritten."""
    def __init__(self):
        from cobrinha_server.services import social_text_ai, user_ai_settings
        self.ai, self.settings = social_text_ai, user_ai_settings
        self.original_load = self.ai.load_config
        self.original_chat = self.ai.generate_chat_reply
        self.original_gift = self.ai.generate_gift_reply
        self.original_update = self.settings.update
        self.original_public = self.settings.public_status
        self.original_start = None
        self.client: LocalQwen | None = None
        self.voice_client: PiperClient | None = None
        self.replacements: list[tuple[object, str, object]] = []

    def config(self) -> dict:
        raw = self.settings._raw()
        local = raw.get('provider') == 'local'
        model = raw.get('model', 'auto') if local else raw.get('local_model', 'auto')
        try:
            port, model = valid_port(raw.get('local_port', 8081)), valid_model(model)
        except ValueError:
            port, model = 8081, 'auto'
        length = 150 if raw.get('termux_reply_mode') == 'dialogue' else 120
        if raw.get('termux_local_smart', True) is True and raw.get('termux_reply_mode') != 'dialogue':
            length = 150 if raw.get('termux_local_length') == 'short' else 220
        return {'enabled': raw.get('enabled', True) is True, 'provider': 'local', 'model': model, 'local_port': port, 'timeout': 18.0, 'max_chars': length, 'api_key_present': False, 'project_id_present': False, 'auto_external_call': False, 'auto_local_call': raw.get('enabled', True) is True}

    def local_client(self) -> LocalQwen:
        config = self.config()
        if self.client is None or self.client.port != config['local_port']:
            self.client = LocalQwen(config['local_port'])
        return self.client

    def public_status(self) -> dict:
        config = self.config()
        client = self.local_client()
        return {**config, 'local_status': dict(client.diagnostics), 'requires_api_key': False}

    def voice_config(self) -> dict:
        raw = self.settings._raw()
        try:
            port = valid_port(raw.get('voice_local_port', 8083))
        except ValueError:
            port = 8083
        return {'provider': 'xtts' if raw.get('voice_provider') == 'xtts' else 'piper-local', 'port': port}

    def local_voice(self) -> PiperClient:
        port = self.voice_config()['port']
        style = self.settings._raw().get('termux_piper_profile', 'clear')
        if style not in ('clear', 'natural', 'legacy'): style = 'clear'
        if self.voice_client is None or self.voice_client.port != port or self.voice_client.profile != style:
            self.voice_client = PiperClient(port)
            self.voice_client.profile = style
        return self.voice_client

    def update(self, payload: dict) -> dict:
        if payload.get('provider', 'local') != 'local':
            raise ValueError('Esta adaptação usa a IA local do Termux.')
        if 'enabled' in payload and not isinstance(payload['enabled'], bool):
            raise ValueError('O estado da IA deve ser verdadeiro ou falso.')
        current = self.settings._raw()
        config = self.config()
        model = valid_model(payload.get('model') or config['model'])
        port = valid_port(payload.get('local_port', config['local_port']))
        enabled = False if payload.get('clear_key') else payload.get('enabled', config['enabled'])
        # Any old credentials remain private and untouched; they are never sent
        # to the local service or returned by these settings endpoints.
        current.update(provider='local', enabled=enabled, model=model, local_port=port)
        self.settings.write_json_atomic(self.settings.SOCIAL_TEXT_AI_CONFIG_FILE, current)
        try:
            os.chmod(self.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)
        except OSError:
            pass
        return self.public_status()

    def transport(self, request_data: dict) -> str:
        identity = self.ai.CHAT_IDENTITY_PROMPT + '\nO público te apelidou de Cofra do Afismo. Aceite esse apelido com bom humor; a identidade e o criador originais continuam os mesmos.'
        if 'local_question' in request_data:
            identity = '\n'.join(line for line in self.ai.CHAT_IDENTITY_PROMPT.splitlines() if line.startswith(('Nome:', 'Criador:')))
            identity += '\nVocê é a cobra que conversa com o público na live Cobrinha. Não se apresente nem cite seu próprio nome em toda resposta.\n' + self.ai.AI_AUDIENCE_RULE
        if getattr(self,'phonk_settings',lambda:{})().get('enabled'):
            identity += '\nNeste tema seu apelido na live é Cobra do PHONK. Use esse apelido se perguntarem seu nome. Preserve a identidade e o criador originais. Responda à pergunta antes de fazer brincadeiras.'
        return self.local_client().reply(request_data, identity=identity)

    def replace_aliases(self, original, replacement) -> None:
        for module in list(sys.modules.values()):
            if module is None or not getattr(module, '__name__', '').startswith('cobrinha_server'):
                continue
            for name, value in list(vars(module).items()):
                if value is original:
                    self.replacements.append((module, name, value))
                    setattr(module, name, replacement)

    def install_hooks(self) -> None:
        def wrapped(original):
            @functools.wraps(original)
            def generate(**kwargs):
                if kwargs.get('transport') is None:
                    kwargs['transport'] = self.transport
                return original(**kwargs)
            return generate
        self.replace_aliases(self.original_load, self.config)
        self.replace_aliases(self.original_chat, wrapped(self.original_chat))
        self.replace_aliases(self.original_gift, wrapped(self.original_gift))
        self.replace_aliases(self.original_update, self.update)
        self.replace_aliases(self.original_public, self.public_status)
        monitor = importlib.import_module('cobrinha_server.services.tiktok_monitor')
        self.original_start = monitor.start_monitor

        @functools.wraps(self.original_start)
        def start_monitor(username, **kwargs):
            return self.original_start(normalize_username(username), **kwargs)
        self.replace_aliases(self.original_start, start_monitor)
        tts = importlib.import_module('cobrinha_server.services.tts_service')
        original_synthesize, original_chunks, original_ready = tts.synthesize_for_job, tts.safe_tts_chunks, tts.voice_ready

        @functools.wraps(original_synthesize)
        def synthesize(text, *, voice_path=None, language='pt'):
            if self.voice_config()['provider'] == 'xtts':
                return original_synthesize(text, voice_path=voice_path, language=language)
            if language not in ('pt', 'pt-br', 'pt-BR'):
                raise ValueError('A voz Piper configurada é brasileira.')
            return self.local_voice().synthesize(text, tts.PREPARED_AUDIO_DIR)

        def chunks(text, *, max_chars=150):
            return original_chunks(text, max_chars=max_chars) if self.voice_config()['provider'] == 'xtts' else voice_chunks(text, max_chars)

        def voice_ready():
            return original_ready() if self.voice_config()['provider'] == 'xtts' else self.local_voice().ready

        self.replace_aliases(original_synthesize, synthesize)
        self.replace_aliases(original_chunks, chunks)
        self.replace_aliases(original_ready, voice_ready)

    def restore(self) -> None:
        for module, name, value in reversed(self.replacements):
            setattr(module, name, value)
        self.replacements.clear()

    def install_routes(self, app) -> None:
        from fastapi import HTTPException
        from fastapi.responses import FileResponse, HTMLResponse
        from starlette.concurrency import run_in_threadpool

        @app.get('/termux/local-ai')
        async def local_ai_status():
            return self.public_status()

        @app.post('/termux/local-ai/detect')
        async def local_ai_detect():
            health = await run_in_threadpool(self.local_client().health)
            return {'ok': health['ready'], **health, 'settings': self.public_status()}

        @app.post('/termux/local-ai/test')
        async def local_ai_test(payload: dict):
            text = str(payload.get('text') or '').strip()
            if not text or len(text) > 180:
                raise HTTPException(status_code=400, detail='Envie uma pergunta de até 180 caracteres.')
            if not self.config()['enabled']:
                raise HTTPException(status_code=409, detail='Ative a IA local primeiro.')
            reply = await run_in_threadpool(self.ai.generate_chat_reply, display_name='Teste', comment=text, user_key='operator-test')
            if not reply:
                raise HTTPException(status_code=503, detail=self.local_client().diagnostics.get('last_error') or 'A IA local não devolveu resposta.')
            return {'ok': True, 'text': reply, 'provider': 'local', 'diagnostics': dict(self.local_client().diagnostics)}

        @app.get('/termux/ui.js')
        def termux_ui():
            return FileResponse(Path(__file__).with_name('ui.js'), media_type='application/javascript', headers={'Cache-Control': 'no-store'})

        @app.get('/termux/phonk-ui.js')
        def phonk_ui():
            return FileResponse(Path(__file__).with_name('phonk_ui.js'), media_type='application/javascript', headers={'Cache-Control': 'no-store'})

        @app.get('/termux/voice')
        def voice_status():
            return {**self.voice_config(), 'ready': self.local_voice().ready}

        @app.post('/termux/voice')
        def voice_update(payload: dict):
            provider = payload.get('provider', 'piper-local')
            if provider not in ('piper-local', 'xtts'):
                raise HTTPException(status_code=400, detail='Escolha Piper local ou XTTS original.')
            try:
                port = valid_port(payload.get('port', self.voice_config()['port']))
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            raw = self.settings._raw()
            raw.update(voice_provider=provider, voice_local_port=port)
            self.settings.write_json_atomic(self.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
            os.chmod(self.settings.SOCIAL_TEXT_AI_CONFIG_FILE, 0o600)
            return self.voice_config()

        @app.post('/termux/voice/detect')
        def voice_detect():
            return self.local_voice().health()

        @app.post('/termux/voice/test')
        def voice_test(payload: dict):
            text = str(payload.get('text') or 'Olá! A cobra está pronta para conversar.').strip()
            if not text or len(text) > 150:
                raise HTTPException(status_code=400, detail='Teste de voz: até 150 caracteres.')
            from cobrinha_server.services import tts_service
            try:
                result = tts_service.synthesize_for_job(text)
            except Exception as exc:
                raise HTTPException(status_code=503, detail='Falha na geração de voz: ' + str(exc)) from exc
            return FileResponse(result['audio_path'], media_type='audio/wav', headers={'Cache-Control': 'no-store'})

        @app.middleware('http')
        async def add_local_controls(request, call_next):
            if request.method == 'POST' and request.url.path == '/api/system-updates/install':
                from fastapi.responses import JSONResponse
                return JSONResponse({'ok': False, 'error': 'O atualizador original instala binários de desktop. Nesta adaptação, atualize manualmente após conferir a compatibilidade com Termux.'}, status_code=409)
            response = await call_next(request)
            if request.url.path == '/' and 'text/html' in response.headers.get('content-type', ''):
                body = b''.join([chunk async for chunk in response.body_iterator])
                marker = b'<script src="/termux/ui.js?v=1"></script>'
                if hasattr(self, 'cloud_api'):
                    marker += b'<script src="/termux/cloud-ui.js?v=31"></script>'
                if Path(__file__).with_name('phonk_ui.js').is_file():
                    marker += b'<script src="/termux/phonk-ui.js?v=37"></script>'
                body = body.replace(b'</body>', marker + b'</body>')
                headers = dict(response.headers)
                headers.pop('content-length', None)
                return HTMLResponse(body, status_code=response.status_code, headers=headers)
            return response


def install(app) -> LocalBinding:
    existing = getattr(app.state, 'snake_termux_binding', None)
    if existing:
        return existing
    binding = LocalBinding()
    try:
        from .cloud_settings import install as install_cloud
    except ImportError:
        pass  # Earlier partial repairs keep local-only behavior.
    else:
        install_cloud(binding, app)
    binding.install_hooks()
    binding.install_routes(app)
    try:
        from .local_social import install as install_social
    except ImportError:
        pass
    else:
        install_social(binding, app)
    try:
        from .live_tuning import install as install_tuning
    except ImportError:
        pass  # Optional in older partial repairs.
    else:
        install_tuning(binding, app)
    try:
        from .live_load import install as install_load
    except ImportError:
        pass
    else:
        install_load(binding, app)
    try:
        from .director import install as install_director
    except ImportError:
        pass
    else:
        install_director(binding, app)
    try:
        from .responsive import install as install_responsive
    except ImportError:
        pass
    else:
        install_responsive(binding,app)
    app.state.snake_termux_binding = binding
    return binding
