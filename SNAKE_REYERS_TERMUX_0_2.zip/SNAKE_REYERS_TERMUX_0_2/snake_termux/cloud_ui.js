(async function () {
  'use strict';
  const old = document.getElementById('openaiStatus')?.closest('section');
  if (!old) return;
  async function request(path, payload) {
    const response = await fetch(path, payload === undefined ? {} : {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || body.error || 'Não foi possível concluir.');
    return body;
  }
  let state;
  try {state = await request('/termux/cloud/settings');} catch (_) {return;}
  const card = document.createElement('section'); card.className = 'card termux-ai-card'; card.id = 'cloudControls';
  const heading = document.createElement('h2'); heading.textContent = 'Respostas e voz · IA local ou na nuvem';
  const note = document.createElement('p'); note.textContent = 'Gemini e OpenAI dependem de internet. ChatGPT não inclui créditos da API. Gemini pode ter cota gratuita; não há garantia de gratuidade para todo modelo/projeto. A voz é gerada por IA.';
  function field(tag, id, labelText) {
    const label = document.createElement('label'); label.htmlFor = id; label.textContent = labelText;
    const input = document.createElement(tag); input.id = id;
    card.append(label, input); return input;
  }
  function choices(input, values) {for (const [value, title] of values) {const option = document.createElement('option'); option.value = value; option.textContent = title; input.append(option);}}
  function button(id, text, action) {
    const element = document.createElement('button'); element.id = id; element.type = 'button'; element.textContent = text;
    element.addEventListener('click', async () => {element.disabled = true; try {await action();} catch (error) {message.textContent = error.message;} finally {element.disabled = false;}});
    card.append(element); return element;
  }
  card.append(heading, note);
  const brain = field('select', 'cloudBrain', 'Quem responde ao chat');
  choices(brain, [['local', 'Qwen local · sem chave'], ['gemini', 'Gemini · API com cota por projeto'], ['openai', 'OpenAI · API cobrada separadamente']]);
  const enabled = field('input', 'cloudEnabled', 'Ativar respostas por IA'); enabled.type = 'checkbox'; enabled.style.width = 'auto';
  const localModel = field('input', 'cloudLocalModel', 'Modelo Qwen · auto para detectar');
  const localPort = field('input', 'cloudLocalPort', 'Porta do Qwen local'); localPort.type = 'number'; localPort.min = '1024'; localPort.max = '65535';
  const openaiModel = field('input', 'cloudOpenaiModel', 'Modelo OpenAI para respostas'); openaiModel.placeholder = 'gpt-4.1-mini';
  const geminiModel = field('input', 'cloudGeminiModel', 'Modelo Gemini · auto escolhe um Flash de texto anunciado pela API'); geminiModel.placeholder = 'auto';
  const apiKey = field('input', 'cloudApiKey', 'Nova chave OpenAI · compartilhada pelas respostas e pela voz'); apiKey.type = 'password'; apiKey.autocomplete = 'new-password'; apiKey.spellcheck = false;
  const keyStatus = document.createElement('small'); keyStatus.id = 'cloudKeyStatus'; card.append(keyStatus);
  const geminiKeys = field('textarea', 'cloudGeminiKeys', 'Adicionar chaves Gemini · uma por linha'); geminiKeys.rows = 3; geminiKeys.spellcheck = false; geminiKeys.autocomplete = 'off'; geminiKeys.style.width = '100%';
  geminiKeys.placeholder = 'Cole uma chave por linha. Para projetos diferentes: nome-projeto | chave';
  const help = document.createElement('p'); help.textContent = 'Chaves do mesmo projeto compartilham os limites. Sem grupo informado, todas são tratadas como o mesmo projeto. Não há consulta de saldo: os testes verificam disponibilidade e consomem cota.'; card.append(help);
  const links = document.createElement('p');
  for (const [text, href] of [['Criar chave OpenAI', 'https://platform.openai.com/api-keys'], ['Configurar faturamento OpenAI', 'https://platform.openai.com/settings/organization/billing/overview'], ['Criar chave Gemini', 'https://aistudio.google.com/apikey']]) {
    const a = document.createElement('a'); a.textContent = text; a.href = href; a.target = '_blank'; a.rel = 'noopener noreferrer'; links.append(a, document.createElement('br'));
  }
  card.append(links);
  const message = document.createElement('p'); message.id = 'cloudStatus'; message.setAttribute('role', 'status');
  function render(body) {
    state = body; brain.value = body.provider; enabled.checked = body.enabled;
    localModel.value = body.local_model || 'auto'; localPort.value = body.local_port;
    openaiModel.value = body.openai_model; geminiModel.value = body.gemini_model;
    keyStatus.textContent = body.openai_key_present ? 'Chave OpenAI salva no servidor; seu valor não é devolvido ao painel.' : 'Nenhuma chave OpenAI salva.';
    renderKeys(body.gemini_keys || []);
  }
  async function save() {
    const additions = geminiKeys.value.split(/\r?\n/).map(x => x.trim()).filter(Boolean).map(line => {
      const parts = line.split('|').map(x => x.trim());
      return parts.length === 1 ? {key: parts[0], project: 'default'} : {key: parts[1], project: parts[0]};
    });
    const payload = {provider: brain.value, enabled: enabled.checked, model: localModel.value || 'auto', local_port: Number(localPort.value), openai_model: openaiModel.value || 'gpt-4.1-mini', gemini_model: geminiModel.value || 'auto'};
    if (apiKey.value.trim()) payload.api_key = apiKey.value.trim();
    if (additions.length) payload.gemini_keys = additions;
    const body = await request('/termux/cloud/settings', payload);
    apiKey.value = ''; geminiKeys.value = ''; render(body);
    message.textContent = 'Configuração salva. Nenhuma chamada de IA foi feita ao salvar.';
    return body;
  }
  button('cloudSave', 'Salvar IA e chaves', save);
  button('cloudDisable', 'Desativar respostas por IA', async () => {enabled.checked = false; await save();});
  button('cloudRemoveOpenai', 'Remover chave OpenAI salva', async () => {render(await request('/termux/cloud/settings', {clear_key: true})); message.textContent = 'Chave removida desta instalação. A revogação da chave é feita na conta OpenAI.';});
  button('cloudLocalDetect', 'Detectar Qwen local', async () => {if (brain.value !== 'local') throw new Error('Selecione Qwen local para usar esta verificação.'); await save(); const b = await request('/termux/local-ai/detect', {}); message.textContent = b.ready ? 'Qwen local conectado.' : (b.message || 'Qwen local indisponível.');});
  const keyRows = document.createElement('div'); keyRows.id = 'cloudGeminiRows'; card.append(keyRows);
  const keyLabels = {untested: 'Ainda não testada', available: 'Respondeu ao teste', invalid_key: 'Chave recusada', cooldown: 'Aguardando cota / intervalo', quota: 'Cota esgotada', rate_limit: 'Limite temporário', permission: 'Sem permissão', model_unavailable: 'Modelo indisponível'};
  function renderKeys(keys) {
    if (!keyRows) return;
    keyRows.replaceChildren();
    for (const key of keys) {
      const row = document.createElement('div'); row.style.cssText = 'border-top:1px solid #33444b;padding:10px 0;overflow-wrap:anywhere';
      const text = document.createElement('p'); text.textContent = key.label + ' · ' + key.project + ' · ' + (keyLabels[key.state] || key.state) + (key.resolved_model ? ' · ' + key.resolved_model : '');
      if (key.retry_at > Date.now() / 1000) text.textContent += ' · aguarde ' + Math.ceil(key.retry_at - Date.now() / 1000) + ' s';
      const check = document.createElement('button'); check.type = 'button'; check.textContent = 'Verificar esta chave';
      check.addEventListener('click', async () => {check.disabled = true; try {const b = await request('/termux/gemini/check', {id: key.id}); renderKeys(b.keys); message.textContent = b.ok ? b.note : b.error;} catch (error) {message.textContent = error.message;} finally {check.disabled = false;}});
      const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = 'Remover';
      remove.addEventListener('click', async () => {try {const payload = {remove_gemini_key: key.id}; if (state.provider === 'gemini' && state.gemini_keys.length === 1) payload.enabled = false; render(await request('/termux/cloud/settings', payload));} catch (error) {message.textContent = error.message;}});
      row.append(text, check, remove); keyRows.append(row);
    }
  }
  button('cloudGeminiCheckAll', 'Verificar chaves Gemini · usa cota', async () => {
    const ids = (state.gemini_keys || []).map(key => key.id); let failures = 0;
    for (let i = 0; i < ids.length; i++) {
      message.textContent = 'Verificando ' + (i + 1) + '/' + ids.length + '…';
      const b = await request('/termux/gemini/check', {id: ids[i]}); renderKeys(b.keys); if (!b.ok) failures++;
    }
    message.textContent = ids.length ? 'Verificação concluída. Falhas/indisponíveis: ' + failures + '. Isso não consulta saldo em dinheiro.' : 'Salve pelo menos uma chave Gemini primeiro.';
  });
  const question = field('input', 'cloudQuestion', 'Pergunta de teste para a IA selecionada'); question.maxLength = 180; question.placeholder = 'Por que o céu é azul?';
  button('cloudAsk', 'Testar resposta · API pode consumir cota', async () => {await save(); message.textContent = 'Aguardando a IA…'; const b = await request('/termux/ai/test', {text: question.value}); message.textContent = b.text;});
  const voiceProvider = field('select', 'cloudVoiceProvider', 'Voz da cobra · independente da IA de respostas');
  choices(voiceProvider, [['piper-local', 'Piper local · voz já instalada'], ['openai', 'OpenAI · voz pela API paga'], ['xtts', 'XTTS original · instalação compatível']]);
  const voicePort = field('input', 'cloudVoicePort', 'Porta do Piper local'); voicePort.type = 'number'; voicePort.value = '8083';
  const voiceName = field('select', 'cloudVoiceName', 'Voz OpenAI');
  choices(voiceName, ['cedar', 'marin', 'coral', 'ash', 'alloy', 'echo', 'fable', 'onyx', 'nova', 'sage', 'shimmer', 'verse', 'ballad'].map(x => [x, x]));
  const style = field('select', 'cloudVoiceStyle', 'Jeito de falar · voz OpenAI');
  choices(style, [['clear', 'Natural e clara'], ['snake', 'Cobra fanha leve · sem trocar R por L'], ['energetic', 'Animada e expressiva']]);
  async function saveVoice() {
    const result = await request('/termux/cloud/voice', {provider: voiceProvider.value, port: Number(voicePort.value), voice: voiceName.value, style: style.value});
    message.textContent = 'Voz salva. Salvar não gera áudio nem faz cobrança.'; return result;
  }
  button('cloudVoiceSave', 'Salvar voz', saveVoice);
  button('cloudVoiceDetect', 'Verificar motor de voz · sem gerar fala', async () => {await saveVoice(); if (voiceProvider.value === 'xtts') {message.textContent = 'XTTS original selecionado. Use o teste para conferir sua instalação e referência.'; return;} const b = await request('/termux/voice/detect', {}); message.textContent = b.message || 'Confira o teste de voz.';});
  const player = document.createElement('audio'); player.id = 'cloudVoicePlayer'; player.controls = true; player.preload = 'none'; let audioURL;
  button('cloudVoiceTest', 'Ouvir teste · OpenAI pode cobrar', async () => {
    await saveVoice(); message.textContent = 'Gerando o teste de voz…';
    const response = await fetch('/termux/voice/test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({text: 'Olá, pessoal! Eu sou a Cofra do Afismo. Manda sua pergunta que eu respondo!'})});
    if (!response.ok) {const b = await response.json(); throw new Error(b.detail || 'Falha na voz.');}
    if (audioURL) URL.revokeObjectURL(audioURL); audioURL = URL.createObjectURL(await response.blob()); player.src = audioURL;
    message.textContent = 'Áudio pronto. Use o player para comparar a voz.'; try {await player.play();} catch (_) {}
  });
  card.append(player, message);
  render(state);
  const voiceState = await request('/termux/voice'); voiceProvider.value = voiceState.provider; voicePort.value = voiceState.port; voiceName.value = voiceState.voice || 'cedar'; style.value = voiceState.style || 'clear';
  old.before(card); old.hidden = true;
  setInterval(async () => {try {const s = await request('/termux/cloud/settings'); const d = s.cloud_status[s.provider]; if (voiceProvider.value === 'openai' && s.cloud_status.speech?.last_error) message.textContent = s.cloud_status.speech.last_error; else if (d?.last_error) message.textContent = d.last_error;} catch (_) {}}, 10000);
})();
