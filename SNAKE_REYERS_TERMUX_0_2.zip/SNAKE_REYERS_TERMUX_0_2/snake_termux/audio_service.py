"""A private, owned PulseAudio server; a stuck shared daemon is never reused."""
from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import tempfile
import time

from . import device_runtime as device


class PrivateAudio:
    def __init__(self, state: Path):
        self.state = state
        self.process = None
        self.log = None
        self.directory = None

    def stop(self):
        # Only a Popen handle created by this object is ever signalled.
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=2)
        self.process = None
        if self.log is not None:
            self.log.close()
            self.log = None
        if self.directory is not None:
            shutil.rmtree(self.directory, ignore_errors=True)
            self.directory = None

    def start(self, base: dict, report: dict) -> tuple[dict, dict]:
        self.stop()
        env = dict(base)
        output = {'output_available': False, 'ownership': 'private-game-audio',
                  'audibility_confirmed': False, 'errors': []}
        try:
            for name in ('pulseaudio', 'pactl', 'paplay'):
                if not shutil.which(name, path=env.get('PATH')):
                    raise ValueError('Comando de áudio ausente: ' + name)
            # Short private Unix path also works with Android's socket limit.
            self.directory = Path(tempfile.mkdtemp(prefix='snake-audio-', dir=env.get('TMPDIR') or None))
            self.directory.chmod(0o700)
            env['PULSE_RUNTIME_PATH'] = str(self.directory)
            env['PULSE_SERVER'] = 'unix:' + str(self.directory / 'native')
            env.pop('PULSE_SINK', None)
            env.pop('PULSE_SOURCE', None)
            # More scheduling margin for local music + speech under game load.
            # Explicit latency chosen by the user/capture environment is retained.
            env.setdefault('PULSE_LATENCY_MSEC', '160')
            self.state.joinpath('logs').mkdir(parents=True, exist_ok=True)
            self.log = (self.state / 'logs/audio-private.log').open('ab', buffering=0)
            # -n skips the shared default.pa. In particular no suspend-on-idle
            # module is loaded. No TCP listener or shared daemon kill is used.
            command = ['pulseaudio', '-n', '--daemonize=no', '--use-pid-file=no',
                       '--exit-idle-time=-1', '--disable-shm=yes', '--log-target=stderr',
                       '-L', 'module-native-protocol-unix socket=' + str(self.directory / 'native') + ' auth-anonymous=1',
                       '-L', 'module-always-sink']
            print('Abrindo serviço de áudio exclusivo do jogo…', flush=True)
            self.process = subprocess.Popen(command, env=env, stdout=self.log, stderr=subprocess.STDOUT)
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    raise ValueError('O serviço de áudio privado encerrou. Veja state/logs/audio-private.log.')
                try:
                    probe = device.run(['pactl', 'info'], env=env, timeout=1)
                    if probe.returncode == 0:
                        break
                except subprocess.TimeoutExpired:
                    pass
                time.sleep(.1)
            else:
                raise ValueError('O serviço privado não respondeu dentro de cinco segundos.')
            env, prepared = device.finalize_audio(env, self.state, report)
            output = {**prepared.get('audio', {}), 'ownership': 'private-game-audio',
                      'server': env['PULSE_SERVER'], 'daemon_pid': self.process.pid}
            if not output.get('stream_preflight_ok'):
                raise ValueError(output.get('message') or 'A saída Android não aceitou o teste PCM.')
            output['message'] = 'Áudio exclusivo do jogo preparado; confirme a fala no aparelho.'
            result = {**prepared, 'audio': output}
            self.store(result)
            return env, result
        except Exception as exc:
            output.update(output_available=False, stream_preflight_ok=False,
                          message='Áudio indisponível; abrindo a imagem sem conectar ao servidor travado.')
            output.setdefault('errors', []).append(f'{type(exc).__name__}: {exc}'[:900])
            self.stop()
            print(output['message'], flush=True)
            result = {**report, 'audio': output}
            self.store(result)
            return dict(base), result

    def store(self, report):
        try:
            device.atomic_json(self.state / 'device-runtime.json', report)
        except OSError as exc:
            print('Não foi possível gravar diagnóstico de áudio: ' + str(exc), flush=True)
