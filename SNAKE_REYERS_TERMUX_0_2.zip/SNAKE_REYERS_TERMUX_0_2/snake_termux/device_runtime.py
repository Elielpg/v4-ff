"""Bounded Termux GPU/audio setup; configuration applies only to this game."""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import struct
import subprocess
import time
import unicodedata
import uuid
import wave
from pathlib import Path

STATE = Path(__file__).resolve().parents[1] / 'state'
GPU_PACKAGES = ('mesa-vulkan-icd-freedreno', 'mesa-demos', 'vulkan-tools')
MAX_MUSIC_BYTES = 200 * 1024 * 1024


def run(command: list[str], *, env: dict | None = None, timeout: float = 8) -> subprocess.CompletedProcess:
    return subprocess.run(command, env=env, capture_output=True, text=True, timeout=timeout)


def atomic_json(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.part')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def config(state: Path) -> dict:
    try:
        data = json.loads((state / 'device-config.json').read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def ensure_packages():
    prefix = Path(os.environ.get('PREFIX', ''))
    if not str(prefix).startswith('/data/'):
        raise ValueError('Os drivers devem ser preparados no Termux do celular.')
    missing = []
    for package in GPU_PACKAGES:
        result = run(['dpkg-query', '-W', '-f=${db:Status-Status}', package])
        if result.returncode or result.stdout.strip() != 'installed':
            missing.append(package)
    if missing:
        from snake_termux.termux_packages import apt
        print('Preparando somente os pacotes ausentes: ' + ', '.join(missing), flush=True)
        apt(prefix / 'etc/apt', ['update'], x11=True)
        apt(prefix / 'etc/apt', ['install', '-y', *missing], x11=True)
    else:
        print('Drivers e ferramentas já instalados; sem consultar APT.', flush=True)


def find_freedreno(prefix: Path) -> Path | None:
    for path in sorted((prefix / 'share/vulkan/icd.d').glob('freedreno_icd*.json')):
        try:
            data = json.loads(path.read_text())
            library = str(data.get('ICD', {}).get('library_path', ''))
            if 'freedreno' in library.lower():
                return path.resolve()
        except (OSError, ValueError, AttributeError):
            pass
    return None


def graphics(base: dict, prefix: Path) -> tuple[dict, dict]:
    env = dict(base)
    icd = find_freedreno(prefix)
    report = {'hardware_verified': False, 'renderer': None, 'resolution': '540x960', 'max_fps': 30}
    if icd:
        for name in ('LIBGL_ALWAYS_SOFTWARE', 'GALLIUM_DRIVER', 'MESA_LOADER_DRIVER_OVERRIDE', 'VK_ICD_FILENAMES', 'VK_DRIVER_FILES'):
            env.pop(name, None)
        env.update(GALLIUM_DRIVER='zink', MESA_LOADER_DRIVER_OVERRIDE='zink', VK_ICD_FILENAMES=str(icd), VK_DRIVER_FILES=str(icd), TU_DEBUG='noconform')
        try:
            probe = run(['glxinfo', '-B'], env=env, timeout=15)
            match = re.search(r'(?im)^\s*OpenGL renderer string:\s*(.+)', probe.stdout)
            renderer = match[1].strip() if match else ''
            report['renderer'] = renderer or None
            software = any(word in renderer.lower() for word in ('llvmpipe', 'softpipe', 'lavapipe', 'swrast'))
            adreno = any(word in renderer.lower() for word in ('adreno', 'turnip', 'qualcomm'))
            if probe.returncode == 0 and renderer and adreno and not software:
                report.update(hardware_verified=True, resolution='720x1280', max_fps=60, driver_file=str(icd), message='GPU Adreno confirmada por glxinfo.')
                return env, report
            report['message'] = 'A GPU não foi confirmada; usando perfil reduzido de CPU.'
            report['probe_error'] = (probe.stderr or probe.stdout)[-1800:]
        except (OSError, subprocess.TimeoutExpired) as exc:
            report['message'] = 'Falha ao verificar GPU; usando perfil reduzido de CPU.'
            report['probe_error'] = str(exc)[:800]
    else:
        report['message'] = 'Freedreno não localizado; usando perfil reduzido de CPU.'
    # A failed Vulkan probe must not leave half-configured GPU overrides active.
    env = dict(base)
    for name in ('VK_ICD_FILENAMES', 'VK_DRIVER_FILES', 'MESA_LOADER_DRIVER_OVERRIDE'):
        env.pop(name, None)
    env.update(GALLIUM_DRIVER='llvmpipe', LIBGL_ALWAYS_SOFTWARE='1', LP_NUM_THREADS='3')
    return env, report


def sinks(env: dict) -> list[dict]:
    result = run(['pactl', 'list', 'short', 'sinks'], env=env)
    if result.returncode:
        raise ValueError((result.stderr or 'PulseAudio não respondeu.').strip())
    entries = []
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) >= 3:
            entries.append({'index': fields[0], 'name': fields[1], 'module': fields[2]})
    return entries


def real_sinks(entries: list[dict]) -> list[dict]:
    return [item for item in entries if item['name'] != 'auto_null' and 'null-sink' not in item['module']]


def audio(base: dict) -> tuple[dict, dict]:
    env = dict(base)
    report = {'output_available': False, 'sink': None, 'audibility_confirmed': False, 'errors': []}
    try:
        available = sinks(env)
        requested = env.get('PULSE_SINK')
        capture = next((item for item in available if item['name'] == requested and requested != 'auto_null' and 'null-sink' in item['module']), None)
        if capture:
            # Original RTMP launch plans deliberately use a named null sink
            # for capture. Preserve that explicit route; auto_null is different.
            report.update(output_available=True, sink=capture['name'], virtual_capture=True,
                          message='Saída de captura configurada preservada; o monitor controla o som local.')
            return env, report
        entries = real_sinks(available)
        created = False
        if not entries:
            for module in ('module-sles-sink', 'module-aaudio-sink'):
                options = []
                if module == 'module-aaudio-sink':
                    # The official Termux module documents this workaround for
                    # AAudioStream_close() crashes when an idle sink resumes.
                    # Normal performance mode is also friendlier to Bluetooth.
                    options = ['sink_name=snake_android_audio', 'no_close_hack=true', 'pm=0', 'latency=80']
                result = run(['pactl', 'load-module', module, *options], env=env, timeout=3)
                if result.returncode:
                    report['errors'].append(module + ': ' + result.stderr.strip()[:500])
                    continue
                entries = real_sinks(sinks(env))
                if entries:
                    created = True
                    report['loaded_module'] = module
                    report['module_id'] = result.stdout.strip()
                    report['module_arguments'] = options
                    break
        if not entries:
            env.pop('PULSE_SINK', None)
            report['message'] = 'PulseAudio ainda não tem saída real; auto_null é silenciosa.'
            return env, report
        current = run(['pactl', 'get-default-sink'], env=env)
        requested = env.get('PULSE_SINK') or current.stdout.strip()
        selected = next((item for item in entries if item['name'] == requested), None)
        if selected is None:
            selected = next((item for item in entries if any(part in item['module'] for part in ('sles', 'aaudio'))), entries[0])
        name = selected['name']
        if current.stdout.strip() not in {item['name'] for item in entries}:
            changed = run(['pactl', 'set-default-sink', name], env=env)
            if changed.returncode:
                report['errors'].append(changed.stderr.strip()[:500])
        if created:
            unmute = run(['pactl', 'set-sink-mute', name, '0'], env=env)
            if unmute.returncode:
                report['errors'].append(unmute.stderr.strip()[:500])
        env['PULSE_SINK'] = name
        report.update(output_available=True, sink=name, message='Saída PulseAudio selecionada; confirme o som no teste.')
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report['message'] = 'Não foi possível preparar a saída PulseAudio.'
        report['errors'].append(str(exc)[:800])
    return env, report


def finalize_audio(base: dict, state: Path, device: dict, *, requested_sink: str | None = None) -> tuple[dict, dict]:
    """Recheck after X11 reconfiguration and open a real PCM stream once.

    A module ID returned by pactl is not proof that the output survived idle or
    route changes. No game/daemon restart loop is used. Capture sinks stay intact.
    """
    if config(state).get('enabled') is not True or not base.get('PREFIX', '').startswith('/data/'):
        return dict(base), device
    env = dict(base)
    if not requested_sink and not device.get('audio', {}).get('virtual_capture'):
        env.pop('PULSE_SINK', None)
    env, output = audio(env)
    if output.get('output_available'):
        path = state / 'audio-startup-silence.wav'
        path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(path), 'wb') as stream:
            stream.setnchannels(1)
            stream.setsampwidth(2)
            stream.setframerate(24000)
            stream.writeframes(b'\0' * (24000 // 5 * 2))
        try:
            env.setdefault('PULSE_LATENCY_MSEC', '80')
            played = run(['paplay', '--device=' + output['sink'], str(path)], env=env, timeout=6)
            available = sinks(env)
            retained = next((item for item in available if item['name'] == output['sink']), None)
            if played.returncode or retained is None:
                raise ValueError((played.stderr or 'A saída de áudio desapareceu durante o teste PCM.').strip())
            output.update(stream_preflight_ok=True, godot_latency_ms=80,
                          message='Saída de áudio aceitou PCM antes de abrir o jogo; confirme se ouviu a fala.')
            if not requested_sink and not output.get('virtual_capture'):
                # Do not bind Godot permanently to an ephemeral Android sink.
                # PulseAudio can then move its stream if the output reconnects.
                env.pop('PULSE_SINK', None)
                output['route_mode'] = 'server-default'
        except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
            output.update(output_available=False, stream_preflight_ok=False,
                          message='A saída Android falhou no teste PCM; o jogo pode ficar sem som.')
            output['errors'].append(str(exc)[:800])
            if not output.get('virtual_capture'):
                env.pop('PULSE_SINK', None)
    result = {**device, 'audio': output}
    atomic_json(state / 'device-runtime.json', result)
    print('Áudio antes de abrir o jogo: ' + output['message'], flush=True)
    return env, result


def prepare_graphics(base: dict, state: Path) -> tuple[dict, dict]:
    settings = config(state)
    prefix = Path(base.get('PREFIX', ''))
    if settings.get('enabled') is not True or not str(prefix).startswith('/data/'):
        return dict(base), {}
    env, gpu = graphics(base, prefix)
    report = {'updated_at': time.time(), 'graphics': gpu}
    atomic_json(state / 'device-runtime.json', report)
    print('Gráficos: ' + gpu['message'] + (' ' + str(gpu['renderer']) if gpu.get('renderer') else ''), flush=True)
    return env, report


def prepare_game(base: dict, state: Path) -> tuple[dict, dict]:
    env, report = prepare_graphics(base, state)
    if not report:
        return env, report
    env, output = audio(env)
    report['audio'] = output
    atomic_json(state / 'device-runtime.json', report)
    print('Áudio: ' + output['message'], flush=True)
    return env, report


def tone(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    rate, duration = 24000, 0.55
    frames = []
    for index in range(int(rate * duration)):
        t = index / rate
        envelope = min(1, t / .03, max(0, (duration - t) / .06))
        frames.append(struct.pack('<h', int(4500 * envelope * math.sin(2 * math.pi * 660 * t))))
    with wave.open(str(path), 'wb') as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(rate)
        stream.writeframes(b''.join(frames))


def test_audio(state: Path, *, base: dict | None = None) -> dict:
    env, output = audio(dict(os.environ) if base is None else dict(base))
    if not output['output_available']:
        return output
    path = state / 'audio-test.wav'
    tone(path)
    try:
        result = run(['paplay', '--device=' + output['sink'], str(path)], env=env, timeout=8)
        output['test_sent'] = result.returncode == 0
        if result.returncode:
            output['errors'].append(result.stderr.strip()[:800])
    except (OSError, subprocess.TimeoutExpired) as exc:
        output['test_sent'] = False
        output['errors'].append(str(exc)[:800])
    return output


async def save_music(upload, directory: Path) -> Path:
    name = unicodedata.normalize('NFC', str(getattr(upload, 'filename', '') or '').replace('\\', '/').split('/')[-1])
    name = re.sub(r'[^\w. -]', '_', name)[:140]
    source = Path(name)
    if source.suffix.lower() not in {'.mp3', '.ogg', '.wav'}:
        raise ValueError('Escolha música MP3, OGG/Vorbis ou WAV para reprodução direta no jogo.')
    if getattr(upload, 'size', 0) and upload.size > MAX_MUSIC_BYTES:
        raise ValueError('A música excede o limite de 200 MB.')
    directory.mkdir(parents=True, exist_ok=True)
    token = str(uuid.uuid4())
    target = directory / f'{source.stem or "musica"} [{token}]{source.suffix.lower()}'
    temporary = directory / ('.' + token + '.part')
    try:
        size = 0
        with temporary.open('xb') as file:
            while chunk := await upload.read(128 * 1024):
                size += len(chunk)
                if size > MAX_MUSIC_BYTES:
                    raise ValueError('A música excede o limite de 200 MB.')
                file.write(chunk)
        if size == 0:
            raise ValueError('O arquivo de música está vazio.')
        temporary.replace(target)
        return target
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state', type=Path, default=STATE)
    parser.add_argument('--install', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--audio-test', action='store_true')
    args = parser.parse_args()
    if args.install:
        ensure_packages()
        settings = config(args.state)
        settings.update(enabled=True)
        atomic_json(args.state / 'device-config.json', settings)
        print('Perfil GPU/áudio preparado. A GPU será verificada no próximo início do jogo.')
    if args.check:
        _env, report = prepare_game(dict(os.environ), args.state)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    if args.audio_test:
        print(json.dumps(test_audio(args.state), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
