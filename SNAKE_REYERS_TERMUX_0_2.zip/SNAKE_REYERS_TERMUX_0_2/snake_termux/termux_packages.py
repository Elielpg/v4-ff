"""Use existing signed main/X11 sources without touching unrelated repositories."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path


def source_files(apt_dir: Path, *, x11: bool) -> list[Path]:
    candidates = [apt_dir / 'sources.list', *sorted((apt_dir / 'sources.list.d').glob('*'))]
    chosen = []
    for path in candidates:
        if not path.is_file() or path.suffix not in ('.list', '.sources'):
            continue
        active = '\n'.join(line for line in path.read_text().splitlines() if not line.lstrip().startswith('#'))
        low = active.lower()
        # A file mixing unrelated repositories is not safe to isolate as a unit.
        if any(term in low for term in ('termux-glibc', 'tur.kcube', 'tur-packages', 'trusted=yes', 'allow-insecure=yes')):
            continue
        main = ('termux-main' in low or 'https://termux.net' in low) and 'termux-x11' not in low
        graphical = 'termux-x11' in low or '/x11' in low
        if main or (x11 and graphical):
            chosen.append(path)
    if not chosen:
        raise ValueError('Não encontrei a fonte principal assinada existente do Termux. As fontes APT não foram alteradas.')
    if x11 and not any('x11' in path.read_text().lower() for path in chosen):
        raise ValueError('O pacote x11-repo não adicionou uma fonte X11 reconhecida.')
    return chosen


def apt(apt_dir: Path, arguments: list[str], *, x11: bool):
    with tempfile.TemporaryDirectory(prefix='snake-apt-', dir=os.environ.get('TMPDIR')) as temp:
        sources = Path(temp) / 'sources.list.d'
        sources.mkdir()
        for index, source in enumerate(source_files(apt_dir, x11=x11)):
            shutil.copyfile(source, sources / f'{index:02d}-{source.name}')
        command = ['apt-get', '-o', 'Dir::Etc::sourcelist=-', '-o', f'Dir::Etc::sourceparts={sources}',
                   '-o', 'APT::Get::List-Cleanup=0', *arguments]
        subprocess.run(command, check=True)


def main():
    prefix = Path(os.environ.get('PREFIX', ''))
    if not str(prefix).startswith('/data/') or not (prefix / 'etc/apt').is_dir():
        raise SystemExit('Execute este preparo no aplicativo Termux do Android.')
    apt_dir = prefix / 'etc/apt'
    apt(apt_dir, ['update'], x11=False)
    apt(apt_dir, ['install', '-y', 'termux-keyring', 'x11-repo'], x11=False)
    apt(apt_dir, ['update'], x11=True)
    apt(apt_dir, ['install', '-y', 'godot', 'termux-x11-nightly', 'pulseaudio', 'python-pillow', 'nodejs-lts',
                  'tor', 'ffmpeg', 'clang', 'rust', 'xorg-xdpyinfo'], x11=True)


if __name__ == '__main__':
    main()
