"""Reuse installed Qwen/Piper; no model download and no voice cloning."""
from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

from .client import LocalQwen, loopback_opener, valid_port
from .voice import PiperClient


def occupied(port: int) -> bool:
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=.5):
            return True
    except OSError:
        return False


def installed_paths(root: Path, manifest: dict) -> tuple[Path, Path, Path]:
    root = root.resolve()
    binary = root / 'llama.cpp/build/bin/llama-server'
    text = Path(manifest.get('textModel') or '').expanduser().resolve()
    voice = Path(manifest.get('voiceModel') or '').expanduser().resolve()
    for path in (binary, text, voice):
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('A instalação anterior não contém o modelo/serviço esperado: ' + path.name)
    if voice.suffix != '.onnx' or not Path(str(voice) + '.json').is_file():
        raise ValueError('Falta a voz Piper .onnx e sua configuração. O clonador não será utilizado.')
    return binary, text, voice


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=valid_port, default=9393)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(os.environ.get('BEN10_LOCAL_ROOT', str(Path.home() / '.local/share/ben10-local-ai'))))
    args = parser.parse_args()
    args.state.mkdir(parents=True, exist_ok=True)
    stopping = threading.Event()
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, lambda *_: stopping.set())
    children = []
    status_file = args.state / 'ai-services.json'

    def record(**data):
        payload = {'updated_at': time.time(), 'automatic_restarts': 0, **data}
        temporary = status_file.with_suffix('.part')
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2))
        temporary.replace(status_file)

    def api(path, payload=None):
        allowed = {'/termux/local-ai', '/termux/voice', '/api/settings/openai'}
        if path not in allowed:
            raise ValueError('Rota de configuração inválida.')
        data = None if payload is None else json.dumps(payload).encode()
        request = urllib.request.Request(f'http://127.0.0.1:{args.port}' + path, data=data, headers={'Content-Type': 'application/json'})
        with loopback_opener().open(request, timeout=3) as response:
            return json.loads(response.read(64000))

    def launch(command, name):
        file = (args.state / 'logs' / name).open('ab', buffering=0)
        try:
            child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=file, stderr=subprocess.STDOUT, start_new_session=True)
        finally:
            file.close()
        children.append(child)
        return child

    def ready(check, child, label):
        for _ in range(120):
            if stopping.is_set():
                raise InterruptedError('Encerrado pelo usuário.')
            if child.poll() is not None:
                raise RuntimeError(label + ' encerrou com código ' + str(child.returncode) + '. Confira os logs.')
            if check()['ready']:
                return
            stopping.wait(1)
        raise RuntimeError(label + ' não ficou pronto dentro do prazo; sem reinício automático.')

    try:
        (args.state / 'logs').mkdir(exist_ok=True)
        record(state='waiting-for-panel')
        for _ in range(120):
            if stopping.is_set():
                return
            try:
                settings = api('/termux/local-ai')
                voice_settings = api('/termux/voice')
                break
            except OSError:
                stopping.wait(.5)
        else:
            raise RuntimeError('O painel não ficou disponível para configurar a IA.')
        text_enabled = settings['enabled'] and settings.get('provider', 'local') == 'local'
        text_port = valid_port(settings['local_port'])
        voice_port = valid_port(voice_settings['port'])
        text_client = LocalQwen(text_port)
        # Disabling AI replies must not mute instant greetings or game speech.
        text_ok = not text_enabled or text_client.health()['ready']
        voice_ok = PiperClient(voice_port).health()['ready'] if voice_settings['provider'] == 'piper-local' else True
        manifest = None
        if not text_ok or not voice_ok:
            try:
                manifest = json.loads((args.root / 'install.json').read_text())
            except (OSError, ValueError) as exc:
                raise RuntimeError('Instalação local anterior não localizada. Inicie seus serviços existentes ou configure suas portas no painel.') from exc
            binary, model, voice = installed_paths(args.root, manifest)
        if not text_ok:
            if occupied(text_port):
                raise RuntimeError('A porta do Qwen está ocupada por outro serviço. Nenhum processo foi encerrado.')
            record(state='loading-qwen')
            command = [str(binary), '--model', str(model), '--alias', 'ben-classico-local', '--host', '127.0.0.1', '--port', str(text_port), '--ctx-size', '2048', '--threads', '3', '--threads-batch', '3', '--batch-size', '128', '--ubatch-size', '128', '--parallel', '1', '--threads-http', '2', '--no-webui', '--reasoning', 'off']
            ready(text_client.health, launch(command, 'qwen.log'), 'Qwen local')
        if not voice_ok:
            # A still-running cloned voice may own an old port. Leave it alone.
            for candidate in dict.fromkeys((voice_port, 8083, 8082)):
                if PiperClient(candidate).health()['ready']:
                    voice_port, voice_ok = candidate, True
                    break
                if not occupied(candidate):
                    voice_port = candidate
                    break
            else:
                raise RuntimeError('As portas de voz estão ocupadas. Selecione outra porta no painel.')
            if not voice_ok:
                record(state='loading-piper')
                relative = voice.relative_to(args.root.resolve()).as_posix()
                worker_dir = Path(__file__).resolve().parent
                command = ['proot-distro', 'login', '--bind', str(args.root.resolve()) + ':/snake-local', '--bind', str(worker_dir) + ':/snake-worker', 'ben10-ai', '--', '/opt/ben10-voice/bin/python', '/snake-worker/piper_worker.py', '--model', '/snake-local/' + relative, '--cache-dir', '/snake-local/snake-piper-cache', '--port', str(voice_port)]
                ready(PiperClient(voice_port).health, launch(command, 'piper.log'), 'Piper local')
        if text_enabled:
            api('/api/settings/openai', {'enabled': True, 'provider': 'local', 'local_port': text_port, 'model': settings['model']})
        if voice_settings['provider'] == 'piper-local':
            api('/termux/voice', {'provider': 'piper-local', 'port': voice_port})
        record(state='ready', text_enabled=text_enabled, text_port=text_port, voice_port=voice_port, owned_pids=[p.pid for p in children])
        print('IA e voz configuradas. Serviços locais são iniciados somente quando selecionados.', flush=True)
        while not stopping.wait(1):
            for child in children:
                if child.poll() is not None:
                    raise RuntimeError('Um serviço local encerrou com código ' + str(child.returncode) + '. O painel e o jogo continuam.')
    except InterruptedError:
        pass
    except Exception as exc:
        record(state='error', message=str(exc))
        print('IA local: ' + str(exc), flush=True)
    finally:
        for child in children:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                    child.wait(timeout=5)
                except (OSError, subprocess.TimeoutExpired):
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=5)
                    except OSError:
                        pass


if __name__ == '__main__':
    main()
