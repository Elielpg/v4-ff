(function(){
  'use strict';
  const parent=document.getElementById('cloudControls')||document.querySelector('.termux-ai-card');if(!parent)return;
  const make=(tag,text)=>{const e=document.createElement(tag);if(text)e.textContent=text;return e;};
  const box=make('details');box.id='termuxPhonk';box.style.cssText='margin:18px 0;border:1px solid #9c2cff;border-radius:12px;padding:12px;background:#100919;color:#f4eaff';
  box.append(make('summary','Cobra do PHONK · cores e batidas'));
  box.append(make('p','Tema preto e roxo. Ajuste cores por música e a intensidade do pulso. O jogo continua sendo Snake Reyers, de Thiago Reyes.'));
  const controls=make('div');box.append(controls);
  function field(id,title,type,value){const label=make('label',title+' '),input=make('input');input.id=id;input.type=type;if(type==='checkbox'){input.checked=value;input.style.width='auto';}else input.value=value;label.append(input);label.style.cssText='display:block;margin:10px 0';controls.append(label);return input;}
  function select(id,title,choices){const label=make('label',title+' '),s=make('select');s.id=id;for(const [v,t] of choices){const o=make('option',t);o.value=v;s.append(o);}label.append(s);controls.append(label);return s;}
  function action(id,title,fn){const b=make('button',title);b.id=id;b.type='button';b.addEventListener('click',async()=>{b.disabled=true;try{await fn();}catch(e){message.textContent=e.message;}finally{b.disabled=false;}});controls.append(b);return b;}
  const enabled=field('phonkEnabled','Ativar tema', 'checkbox',false);
  const base=field('phonkBase','Cor escura da cobra','color','#08050f');
  const palette=['#9c2cff','#d653ff','#6333ed'].map((c,i)=>field('phonkColor'+i,'Cor '+(i+1),'color',c));
  const intensity=field('phonkIntensity','Intensidade do brilho (0–100)','range',60);intensity.min=0;intensity.max=100;
  const sensitivity=field('phonkSensitivity','Sensibilidade das batidas (30–200)','range',100);sensitivity.min=30;sensitivity.max=200;
  const pulses=field('phonkPulses','Pulsar com a batida','checkbox',true);
  const mode=select('phonkColorMode','Troca de cor',[['beat','A cada batida detectada'],['track','Ao trocar de música'],['fixed','Cor fixa']]);
  const every=select('phonkEvery','Intervalo da troca',[['1','1 batida'],['2','2 batidas'],['4','4 batidas'],['8','8 batidas'],['16','16 batidas']]);
  const source=select('phonkSource','Sincronia',[['music','Detectar a música tocada pelo jogo'],['manual','BPM manual · música de outro aplicativo']]);
  controls.append(make('p','GreenTube/fone/Bluetooth: este painel não captura áudio de outros aplicativos. Use BPM manual e marque o ritmo, ou envie a faixa pela Biblioteca de músicas para detecção automática. A fala da cobra não dispara as luzes.'));
  const bpm=field('phonkBpm','BPM manual','number',140);bpm.min=40;bpm.max=300;
  let current=null,taps=[],timer=null;
  const message=make('p');message.id='phonkMessage';message.setAttribute('role','status');
  const runtime=make('p');runtime.id='phonkRuntime';runtime.style.whiteSpace='pre-wrap';
  async function request(path,payload){const r=await fetch(path,payload===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const b=await r.json();if(!r.ok)throw Error(b.detail||'Não foi possível salvar o tema.');return b;}
  function show(b,fill=false){current=b;if(fill){const s=b.settings;enabled.checked=s.enabled;base.value=s.base_color;palette.forEach((e,i)=>e.value=s.palette[i]||s.palette[0]);intensity.value=s.intensity*100;sensitivity.value=s.sensitivity*100;pulses.checked=s.pulses;source.value=s.source;bpm.value=s.manual_bpm;mode.value=s.color_mode;every.value=s.color_every;const old=track.value;track.replaceChildren(make('option','Escolha uma música'));track.firstChild.value='';for(const row of b.tracks||[]){const o=make('option',row.title);o.value=row.id;track.append(o);}track.value=old;}
    const r=b.runtime;runtime.textContent=!r||b.runtime_age_seconds>5?'Reabra a janela do jogo depois da primeira ativação. Depois, as cores são aplicadas em até um segundo.':(r.enabled?'Tema ativo':'Tema desativado')+' · '+(r.source==='manual'?'BPM manual '+r.manual_bpm:'Detecção no canal '+r.analyzer_bus)+'\nMúsica: '+(r.track_title||'aguardando')+' · pulsos: '+r.beats+' · cor: '+r.color;}
  action('phonkSave','Salvar tema',async()=>{show(await request('/termux/phonk',{enabled:enabled.checked,base_color:base.value,palette:palette.map(e=>e.value),intensity:Number(intensity.value)/100,sensitivity:Number(sensitivity.value)/100,pulses:pulses.checked,source:source.value,manual_bpm:Number(bpm.value),color_mode:mode.value,color_every:Number(every.value)}));message.textContent='Salvo. Primeira ativação: reabra a janela do jogo. Com o tema carregado, ajustes e desativação são imediatos.';});
  action('phonkTap','Marcar batida · toque 4 vezes',async()=>{const now=performance.now();if(taps.length&&now-taps.at(-1)>1600)taps=[];taps.push(now);taps=taps.slice(-6);if(taps.length<4){message.textContent=taps.length+'/4 toques';return;}const intervals=taps.slice(1).map((t,i)=>t-taps[i]).sort((a,b)=>a-b);const n=Math.round(60000/intervals[Math.floor(intervals.length/2)]);if(n<40||n>300)throw Error('Marque uma batida regular, entre 40 e 300 BPM.');source.value='manual';bpm.value=n;show(await request('/termux/phonk/sync',{manual_bpm:n}));message.textContent='Relógio manual sincronizado em '+n+' BPM. Toque novamente para corrigir a fase.';});
  const track=select('phonkTrack','Paleta exclusiva da faixa',[]);
  const songPalette=['#9c2cff','#d653ff','#6333ed'].map((c,i)=>field('phonkSongColor'+i,'Cor da faixa '+(i+1),'color',c));
  track.onchange=()=>{const colors=current?.settings.track_palettes[track.value]||current?.settings.palette||[];songPalette.forEach((e,i)=>e.value=colors[i]||colors[0]||'#9c2cff');};
  action('phonkSongSave','Salvar cores desta música',async()=>{if(!track.value)throw Error('Escolha uma faixa da biblioteca.');const fresh=await request('/termux/phonk');const table={...fresh.settings.track_palettes,[track.value]:songPalette.map(e=>e.value)};show(await request('/termux/phonk',{track_palettes:table}));message.textContent='Paleta da faixa salva; será usada quando ela tocar.';});
  action('phonkSongReset','Usar cores gerais nesta música',async()=>{if(!track.value)throw Error('Escolha uma faixa.');const fresh=await request('/termux/phonk');const table={...fresh.settings.track_palettes};delete table[track.value];show(await request('/termux/phonk',{track_palettes:table}));track.onchange();message.textContent='Faixa usando as cores gerais.';});
  controls.append(message,runtime);
  const section=make('section');section.className='card termux-ai-card';section.id='phonkControls';section.append(box);parent.before(section);
  async function read(fill=false){try{show(await request('/termux/phonk'),fill);}catch(e){message.textContent=e.message;}}
  box.addEventListener('toggle',()=>{clearInterval(timer);if(box.open){read(true);timer=setInterval(()=>{if(!document.hidden)read();},2500);}});
  read(true);
})();
