#!/usr/bin/env bash
set -euo pipefail
adapter_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v python3 >/dev/null 2>&1; then
  printf 'Falta Python 3. No Termux, instale o pacote python e execute novamente.\n' >&2
  exit 1
fi
# Keep APT sources, keys, installed models and the original project intact.
# --system-site-packages allows an existing Termux python-pillow package.
python3 -m venv --system-site-packages "$adapter_dir/.venv"
"$adapter_dir/.venv/bin/python" -m pip install -r "$adapter_dir/requirements-panel.txt"
printf 'Dependências do painel preparadas. Este comando não instala nem inicia o jogo gráfico.\n'
printf 'Para o monitor TikTok, a instalação original também precisa de Node >=22, Tor e npm ci na pasta server/external/tiktok-live-monitoring-server.\n'
