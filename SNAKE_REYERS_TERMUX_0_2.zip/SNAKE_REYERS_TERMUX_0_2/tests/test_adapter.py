import io
import json
import wave

import pytest
from fastapi.testclient import TestClient

from snake_termux.client import LocalQwen, LocalServiceError, valid_model, valid_port
from snake_termux.integration import normalize_username
from snake_termux.voice import PiperClient, voice_chunks


@pytest.mark.parametrize('value', [True, False, 80, 65536, '8081.0', '8081;echo', '08081', None])
def test_port_rejects_invalid_values(value):
    with pytest.raises(ValueError):
        valid_port(value)


def test_username_and_model():
    assert normalize_username(' @Linel.exe ') == 'Linel.exe'
    assert valid_model('Qwen/Qwen3-4B-Q4_K_M.gguf')
    for bad in ('https://tiktok.com/@x', 'a b', 'a;sh', '', 'x' * 25):
        with pytest.raises(ValueError):
            normalize_username(bad)


def test_real_http_loopback_model_discovery_and_no_api_key(local_service):
    client = LocalQwen(local_service['port'])
    assert client.reply({'model': 'auto', 'prompt': 'Quanto é sete vezes oito?'}, identity='Serpente do Abismo') == local_service['text']
    client.reply({'model': 'auto', 'prompt': 'Olá'}, identity='Serpente do Abismo')
    assert sum(x['path'] == '/v1/models' for x in local_service['calls']) == 1
    request = local_service['calls'][1]
    assert request['path'] == '/v1/chat/completions'
    assert request['data']['model'] == 'ben-classico-local'
    assert request['data']['chat_template_kwargs']['enable_thinking'] is False
    assert not any(k.lower() == 'authorization' for k in request['headers'])
    assert client.diagnostics['answered'] == 2


def test_redirect_cannot_send_prompt_off_loopback(local_service):
    local_service['redirect'] = 'https://example.com/collect'
    with pytest.raises(LocalServiceError, match='HTTP 307'):
        LocalQwen(local_service['port']).reply({'model': 'fixed', 'prompt': 'private'}, identity='serpente')
    assert len(local_service['calls']) == 1


@pytest.mark.parametrize('text', ['', '<think>somente pensamento', None])
def test_empty_nonfinal_or_invalid_reply_is_error(local_service, text):
    local_service['text'] = text
    client = LocalQwen(local_service['port'])
    with pytest.raises(LocalServiceError):
        client.reply({'model': 'fixed', 'prompt': 'oi'}, identity='serpente')
    assert client.diagnostics['failed'] == 1


def test_settings_preserve_secret_but_never_expose_it(adapted, local_service):
    _app, binding = adapted
    path = binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE
    path.write_text(json.dumps({'openai_api_key': 'secret-keep-private', 'provider': 'openai', 'model': 'gpt-4.1-mini'}))
    assert binding.config()['model'] == 'auto'
    status = binding.update({'enabled': True, 'model': 'auto', 'local_port': local_service['port']})
    assert 'secret-keep-private' not in json.dumps(status)
    assert json.loads(path.read_text())['openai_api_key'] == 'secret-keep-private'
    assert path.stat().st_mode & 0o777 == 0o600
    assert not status['requires_api_key']


def test_original_social_reply_cached_alias_is_adapted(adapted, local_service):
    from cobrinha_server.services.social_reply import build_main_reply, build_gift_reply
    _app, binding = adapted
    binding.update({'enabled': True, 'local_port': local_service['port']})
    assert build_main_reply(display_name='Ana', comment='quanto é sete vezes oito?', user_key='ana') == local_service['text']
    count = len(local_service['calls'])
    assert build_main_reply(display_name='Ana', comment='oi', user_key='ana')
    assert len(local_service['calls']) == count  # Original instant greeting remains intact.
    assert build_gift_reply(display_name='Ana', gift_name='Rose', gift_count=1, user_key='ana')
    payload = local_service['calls'][-1]['data']
    assert 'Serpente do Abismo' in payload['messages'][0]['content']


def test_disabled_ai_does_not_call_local_service(adapted, local_service):
    _app, binding = adapted
    binding.update({'enabled': False, 'local_port': local_service['port']})
    assert binding.ai.generate_chat_reply(display_name='Ana', comment='quanto é sete vezes oito?') == ''
    assert not local_service['calls']


def test_monitor_preserves_username_and_original_call(adapted):
    from cobrinha_server.services import tiktok_monitor
    _app, binding = adapted
    calls = []
    binding.original_start = lambda username, **kwargs: calls.append((username, kwargs)) or {'ok': True}
    assert tiktok_monitor.start_monitor('@Linel.exe', prepare_local_node=False)['ok']
    assert calls == [('Linel.exe', {'prepare_local_node': False})]


def test_original_panel_local_endpoints_and_voice_failure(adapted, local_service):
    app, _binding = adapted
    client = TestClient(app)
    response = client.get('/')
    assert response.status_code == 200
    assert '/termux/ui.js?v=1' in response.text
    assert client.get('/termux/ui.js').status_code == 200
    assert client.post('/api/settings/openai', json={'enabled': True, 'local_port': local_service['port']}).status_code == 200
    assert client.post('/termux/local-ai/detect').json()['ready'] is True
    assert client.post('/termux/local-ai/test', json={'text': 'Quanto é sete vezes oito?'}).json()['text'] == local_service['text']
    assert client.post('/api/settings/openai', json={'enabled': 'true'}).status_code == 400
    assert client.post('/termux/local-ai/test', json={'text': 'x' * 181}).status_code == 400
    assert client.post('/termux/voice', json={'port': local_service['port']}).status_code == 200
    assert client.post('/termux/voice/detect').json()['ready'] is True
    audio = client.post('/termux/voice/test', json={'text': 'Rosa, relógio, carro e clarão.'})
    assert audio.status_code == 200 and audio.content[:4] == b'RIFF'
    local_service['wav'] = b'invalid audio'
    assert client.post('/termux/voice/test', json={'text': 'Rosa'}).status_code == 503
    assert client.get('/termux/local-ai').status_code == 200  # Voice failure did not stop backend.
    assert client.post('/api/system-updates/install').status_code == 409


def test_piper_spelling_and_original_audio_timeline_contract(adapted, local_service):
    from cobrinha_server.services import tts_service, speech_queue
    _app, binding = adapted
    text = 'Rosa, relógio, carro e clarão. Explosão!'
    assert voice_chunks(text) == [text]
    path = binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE
    path.write_text(json.dumps({'voice_local_port': local_service['port']}))
    assert speech_queue.synthesize_for_job is tts_service.synthesize_for_job
    result = tts_service.synthesize_for_job(text)
    assert result['voice_provider'] == 'piper-local'
    assert result['chunks'] == [text]
    assert result['timeline']['version'] == 2
    assert result['timeline']['speech_end'] > 0
    assert local_service['calls'][-1]['data']['text'] == text
    with wave.open(result['audio_path']) as reader:
        assert reader.getnframes() == 16000


def test_question_to_original_pending_queue_audio(adapted, local_service):
    from cobrinha_server.services import speech_queue
    from cobrinha_server.services.social_reply import build_main_reply
    _app, binding = adapted
    binding.update({'enabled': True, 'local_port': local_service['port']})
    raw = binding.settings._raw()
    raw['voice_local_port'] = local_service['port']
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
    answer = build_main_reply(display_name='Ana', comment='quanto é sete vezes oito?', user_key='ana')
    ready = speech_queue.prepare_pending_job({'id': 'fixture-ana', 'text': answer, 'metadata': {'user_key': 'ana'}})
    assert ready['id'] == 'fixture-ana'
    assert ready['audio_path'].endswith('.wav')
    assert ready['timeline_path'].endswith('.json')
    assert ready['timeline']
    assert local_service['calls'][-1]['data']['text'] == answer


def test_invalid_wav_never_creates_prepared_audio(adapted, local_service):
    from cobrinha_server.services import tts_service
    _app, binding = adapted
    binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE.write_text(json.dumps({'voice_local_port': local_service['port']}))
    local_service['wav'] = local_service['wav'][:-100]
    with pytest.raises(LocalServiceError, match='incompleto'):
        tts_service.synthesize_for_job('Rosa')
    assert not list(tts_service.PREPARED_AUDIO_DIR.glob('*.wav'))


def test_clone_service_not_mistaken_for_piper(local_service):
    local_service['voice_model'] = 'qwen3-tts-clone'
    client = PiperClient(local_service['port'])
    assert client.health()['ready'] is False
    with pytest.raises(LocalServiceError):
        client.wav('Olá!')
    assert all(x['path'] != '/synthesize' for x in local_service['calls'])


def test_xtts_original_remains_selectable(adapted, monkeypatch):
    app, binding = adapted
    client = TestClient(app)
    assert client.post('/termux/voice', json={'provider': 'xtts'}).status_code == 200
    from cobrinha_server.services import tts_service
    # Do not load a heavy model; the original reference validation must still run.
    monkeypatch.setattr(tts_service, 'DEFAULT_VOICE_PATH', binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE.parent / 'missing.wav')
    with pytest.raises(FileNotFoundError, match='XTTS'):
        tts_service.synthesize_for_job('Olá!')
