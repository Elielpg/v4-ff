import os
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
BASH = shutil.which('bash')


def executable(path, text):
    path.write_text('#!/bin/sh\n' + text)
    path.chmod(0o700)


def installation(tmp_path, *, existing_display=False, missing_cli=False, x11_failure=False):
    app = tmp_path / 'adapter'
    capture = tmp_path / 'capture'
    commands = tmp_path / 'bin'
    for directory in (app / 'state', app / 'snake_termux', app / '.venv/bin', capture, commands):
        directory.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'start.sh', app / 'start.sh')
    (app / 'state/project-path.txt').write_text('/original/game\n')
    for name in ('dirname', 'cat', 'mkdir', 'tee', 'tail', 'sleep', 'touch', 'cp', 'mktemp', 'chmod', 'mv', 'rm', 'bash'):
        (commands / name).symlink_to(shutil.which(name))
    executable(commands / 'pm', 'touch "$FAKE_CAPTURE/pm-called"; exit 255\n')
    executable(commands / 'pulseaudio', 'exit 0\n')
    executable(commands / 'xdpyinfo', 'test -f "$FAKE_CAPTURE/x11-ready"\n')
    executable(commands / 'am', 'printf "%s\\n" "$*" > "$FAKE_CAPTURE/am-args"; printf "activity-not-visible-to-test\\n"; exit 1\n')
    if not missing_cli:
        if x11_failure:
            executable(commands / 'termux-x11', 'printf "REAL_X11_START_ERROR\\n" >&2; exit 42\n')
        else:
            executable(commands / 'termux-x11', 'printf "%s\\n" "$*" > "$FAKE_CAPTURE/x11-args"; touch "$FAKE_CAPTURE/x11-started" "$FAKE_CAPTURE/x11-ready"; exec sleep 30\n')
    executable(app / '.venv/bin/python', 'printf "%s\\n" "$*" > "$FAKE_CAPTURE/python-args"; exit "${FAKE_GAME_EXIT:-0}"\n')
    if existing_display:
        (capture / 'x11-ready').touch()
    env = dict(os.environ, PREFIX='/data/local/snake-test', PATH=str(commands), TMPDIR=str(tmp_path), FAKE_CAPTURE=str(capture), DISPLAY=':77')
    return app, capture, env


@pytest.mark.parametrize('existing_display', [False, True])
def test_failed_android_package_query_does_not_block_game(tmp_path, existing_display):
    app, capture, env = installation(tmp_path, existing_display=existing_display)
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stdout + result.stderr
    assert not (capture / 'pm-called').exists()
    assert '--game --reuse-ai' in (capture / 'python-args').read_text()
    assert (capture / 'x11-started').exists() is not existing_display
    assert 'activity-not-visible' in (app / 'state/logs/x11-activity.log').read_text()
    # Android intent data creates a tagged window. An untagged server must be
    # opened with the default activity rather than an unrelated "main" tag.
    assert '-d' not in (capture / 'am-args').read_text().split()
    assert 'com.termux.x11/com.termux.x11.MainActivity' in (capture / 'am-args').read_text()
    if not existing_display:
        assert '-tag' not in (capture / 'x11-args').read_text().split()
    assert (app / 'state/launcher-exit-code.txt').read_text().strip() == '0'


def test_missing_companion_cli_reports_the_actual_dependency(tmp_path):
    app, capture, env = installation(tmp_path, missing_cli=True)
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 1
    assert 'Falta o comando termux-x11' in result.stderr
    assert not (capture / 'python-args').exists()


def test_failed_x11_service_shows_its_own_log(tmp_path):
    app, capture, env = installation(tmp_path, x11_failure=True)
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 1
    assert 'REAL_X11_START_ERROR' in result.stderr
    assert not (capture / 'python-args').exists()


@pytest.mark.parametrize('repair_name', ['SNAKE_REYERS_REPARAR_X11_V021.sh', 'SNAKE_REYERS_REPARAR_JANELA_V023.sh'])
def test_repair_backs_up_only_launcher_and_preserves_configuration(tmp_path, repair_name):
    app, _capture, env = installation(tmp_path)
    old = '#!/bin/sh\necho old-launcher\n'
    (app / 'start.sh').write_text(old)
    (app / 'state/private-settings.json').write_text('{"keep":"private"}')
    result = subprocess.run([BASH, str(ROOT / repair_name), str(app)], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert (app / 'start.sh').read_bytes() == (ROOT / 'start.sh').read_bytes()
    backups = list((app / 'state/launcher-backups').iterdir())
    assert len(backups) == 1 and backups[0].read_text() == old
    assert (app / 'state/private-settings.json').read_text() == '{"keep":"private"}'
    assert (app / 'state/project-path.txt').read_text() == '/original/game\n'


def test_nonzero_panel_exit_remains_visible(tmp_path):
    app, _capture, env = installation(tmp_path, existing_display=True)
    env['FAKE_GAME_EXIT'] = '7'
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 7
    assert (app / 'state/launcher-exit-code.txt').read_text().strip() == '7'


def test_failed_audio_daemon_does_not_prevent_the_game_window(tmp_path):
    app, capture, env = installation(tmp_path)
    executable(Path(env['PATH']) / 'pulseaudio', 'printf "AUDIO_DAEMON_FAILED\\n" >&2; exit 1\n')
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (capture / 'x11-started').exists()
    assert '--game --reuse-ai' in (capture / 'python-args').read_text()


def test_missing_audio_daemon_does_not_prevent_the_game_window(tmp_path):
    app, capture, env = installation(tmp_path)
    (Path(env['PATH']) / 'pulseaudio').unlink()
    result = subprocess.run([BASH, str(app / 'start.sh')], env=env, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stdout + result.stderr
    assert (capture / 'x11-started').exists()
    assert '--game --reuse-ai' in (capture / 'python-args').read_text()
