import json
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

from fastapi.testclient import TestClient
import uvicorn

from test_cloud_ai import configure


def test_question_does_not_silently_use_wrong_provider(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'local')
    monkeypatch.setattr(binding, 'local_client', lambda: (_ for _ in ()).throw(AssertionError('must not request Qwen')))
    response = TestClient(app).post('/termux/ai/test', json={'text': 'oi', 'provider': 'gemini'})
    assert response.status_code == 409 and 'provedor' in response.json()['detail']


def test_slow_qwen_startup_cannot_overwrite_new_gemini_selection(adapted, tmp_path):
    app, binding = adapted
    probe = socket.socket();probe.bind(('127.0.0.1',0));qwen_port=probe.getsockname()[1];probe.close()
    configure(binding, 'local', local_port=qwen_port)
    assert TestClient(app).post('/termux/cloud/voice', json={'provider': 'openai'}).status_code == 200
    root = tmp_path / 'installed';binary = root / 'llama.cpp/build/bin/llama-server';binary.parent.mkdir(parents=True)
    ready_file=tmp_path/'allow-model-ready'
    binary.write_text('#!'+sys.executable+'\n'+'''import json,sys
from pathlib import Path
from http.server import BaseHTTPRequestHandler,HTTPServer
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        models=['fixture-ready'] if Path('''+repr(str(ready_file))+''').exists() else []
        self.send_response(200);self.end_headers()
        self.wfile.write(json.dumps({'data':[{'id':x} for x in models]}).encode())
HTTPServer(('127.0.0.1',int(sys.argv[sys.argv.index('--port')+1])),Handler).serve_forever()
''');binary.chmod(0o700)
    text = root / 'text.gguf';text.write_text('fixture, not a model')
    voice = root / 'voice.onnx';voice.write_text('fixture, not a model');Path(str(voice) + '.json').write_text('{}')
    (root / 'install.json').write_text(json.dumps({'textModel': str(text), 'voiceModel': str(voice)}))
    sock = socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app,log_level='error',lifespan='off'))
    thread=threading.Thread(target=lambda:server.run(sockets=[sock]),daemon=True);thread.start()
    child=None;state=tmp_path/'service'
    try:
        for _ in range(100):
            if server.started:break
            time.sleep(.01)
        child=subprocess.Popen([sys.executable,'-m','snake_termux.reuse_ai','--state',str(state),'--port',str(port),'--root',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        def status():
            try:return json.loads((state/'ai-services.json').read_text())
            except (OSError,ValueError):return {}
        for _ in range(100):
            if status().get('state')=='loading-qwen':break
            time.sleep(.03)
        assert status().get('state')=='loading-qwen',status()
        configure(binding,'gemini')
        ready_file.touch()
        for _ in range(120):
            if status().get('state') in ('ready','error'):break
            time.sleep(.03)
        assert status().get('state')=='ready',status()
        assert binding.config()['provider']=='gemini'
        assert binding.voice_config()['provider']=='openai'
    finally:
        if child:
            child.terminate();child.wait(timeout=7)
        server.should_exit=True;thread.join(timeout=5);sock.close()
