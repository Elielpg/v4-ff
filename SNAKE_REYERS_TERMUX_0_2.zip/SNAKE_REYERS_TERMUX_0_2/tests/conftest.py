import io
import json
import math
import os
import struct
import sys
import threading
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

ROOT = Path(os.environ.get('SNAKE_TEST_PROJECT', '/workspace/snake-reyers-0.1.9-audit'))
os.environ['COBRINHA_SERVER_DIR'] = str(ROOT / 'server')
sys.path.insert(0, str(ROOT / 'server' / 'src'))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def local_service():
    state = {'calls': [], 'models': ['ben-classico-local'], 'text': 'Ana, sete vezes oito é cinquenta e seis!', 'redirect': None, 'wav': None}
    stream = io.BytesIO()
    with wave.open(stream, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(b''.join(struct.pack('<h', int(8000 * math.sin(2 * math.pi * 440 * i / 16000))) for i in range(16000)))
    state['wav'] = stream.getvalue()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def do_GET(self):
            self.handle_request()

        def do_POST(self):
            self.handle_request()

        def handle_request(self):
            size = int(self.headers.get('Content-Length', 0))
            payload = json.loads(self.rfile.read(size)) if size else None
            state['calls'].append({'path': self.path, 'data': payload, 'headers': dict(self.headers)})
            if state['redirect']:
                self.send_response(307)
                self.send_header('Location', state['redirect'])
                self.end_headers()
                return
            if self.path == '/v1/models':
                value = {'data': [{'id': x} for x in state['models']]}
            elif self.path == '/health':
                value = {'ready': True, 'model': state.get('voice_model', 'Piper-pt_BR-local')}
            elif self.path == '/synthesize':
                self.send_response(200)
                self.end_headers()
                self.wfile.write(state['wav'])
                return
            else:
                value = {'choices': [{'message': {'content': state['text']}}]}
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(value).encode())
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    state['port'] = server.server_port
    yield state
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


@pytest.fixture
def adapted(tmp_path, monkeypatch):
    from cobrinha_server.main import create_app
    from cobrinha_server.services import tts_service, user_ai_settings
    from snake_termux.integration import install
    monkeypatch.setattr(user_ai_settings, 'SOCIAL_TEXT_AI_CONFIG_FILE', tmp_path / 'social_text_ai.json')
    monkeypatch.setattr(tts_service, 'PREPARED_AUDIO_DIR', tmp_path / 'prepared_audio')
    app = create_app()
    binding = install(app)
    yield app, binding
    binding.restore()
