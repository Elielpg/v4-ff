import json
import subprocess
from pathlib import Path

from fastapi.testclient import TestClient

from snake_termux import audio_service, device_runtime as device, native


class Process:
    pid=456789
    returncode=None
    terminated=False
    def poll(self): return self.returncode
    def terminate(self): self.terminated=True; self.returncode=0
    def kill(self): self.returncode=-9
    def wait(self, **kwargs): return self.returncode


def private_fixture(tmp_path, monkeypatch):
    calls=[]
    process=Process()
    monkeypatch.setattr(audio_service.shutil,'which',lambda name,**kwargs:name)
    monkeypatch.setattr(audio_service.subprocess,'Popen',lambda command,**kwargs:calls.append((command,kwargs)) or process)
    monkeypatch.setattr(device,'run',lambda *a,**kw:subprocess.CompletedProcess([],0,'server ready',''))
    service=audio_service.PrivateAudio(tmp_path/'state')
    return service,process,calls


def test_private_server_bypasses_shared_daemon_and_stops_only_owned_child(tmp_path,monkeypatch):
    service,process,calls=private_fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(device,'finalize_audio',lambda env,state,report:(env,{**report,'audio':{'output_available':True,'stream_preflight_ok':True}}))
    base={'PULSE_SERVER':'unix:/shared/stuck','PULSE_SINK':'old-output','TMPDIR':str(tmp_path),'PATH':'/fixture'}
    env,report=service.start(base,{})
    directory=service.directory
    assert env['PULSE_SERVER']!='unix:/shared/stuck' and env['PULSE_SERVER'].startswith('unix:')
    assert 'PULSE_SINK' not in env and base['PULSE_SINK']=='old-output'
    assert env['PULSE_LATENCY_MSEC']=='160'
    assert 'PULSE_LATENCY_MSEC' not in base
    assert report['audio']['ownership']=='private-game-audio'
    command=calls[0][0]
    assert '-n' in command and '--daemonize=no' in command
    assert not any('tcp' in option or 'suspend-on-idle' in option for option in command)
    assert directory.stat().st_mode & 0o777 == 0o700
    service.stop()
    assert process.terminated and not directory.exists()


def test_hung_private_server_is_bounded_and_cannot_block_graphics(tmp_path,monkeypatch):
    service,process,calls=private_fixture(tmp_path,monkeypatch)
    moments=iter([0,0,6])
    monkeypatch.setattr(audio_service.time,'monotonic',lambda:next(moments))
    monkeypatch.setattr(audio_service.time,'sleep',lambda _:None)
    def timeout(*a,**kw): raise subprocess.TimeoutExpired(a[0],1)
    monkeypatch.setattr(device,'run',timeout)
    env,report=service.start({'TMPDIR':str(tmp_path)}, {})
    assert not report['audio']['output_available']
    assert process.terminated and service.process is None
    assert 'cinco segundos' in report['audio']['errors'][-1]


def test_failed_output_stops_private_daemon_without_touching_shared_one(tmp_path,monkeypatch):
    service,process,calls=private_fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(device,'finalize_audio',lambda env,state,report:(env,{'audio':{'output_available':False,'errors':[],'message':'Android output failed'}}))
    base={'PULSE_SERVER':'unix:/shared/stuck','TMPDIR':str(tmp_path)}
    env,report=service.start(base,{})
    assert env==base and process.terminated
    assert len(calls)==1 and calls[0][0][0]=='pulseaudio'
    assert report['audio']['stream_preflight_ok'] is False


def test_game_explicitly_uses_dummy_when_audio_failed_instead_of_connecting_to_hung_server(tmp_path,monkeypatch):
    monkeypatch.setattr(native,'resolve_godot',lambda _:Path('/fake-godot'))
    monkeypatch.setattr(native,'verify_original',lambda _: {'verified':True})
    monkeypatch.setenv('DISPLAY',':1')
    monkeypatch.setenv('PREFIX','/data/local/test')
    monkeypatch.delenv('PULSE_SINK',raising=False)
    monkeypatch.setattr(native,'prepare_device',lambda env,state:(env,{}))
    monkeypatch.setattr(native,'prepare_presentation',lambda env,state,report:report)
    class FailedAudio:
        def __init__(self,state):pass
        def start(self,env,report):return env,{'audio':{'output_available':False,'message':'server stuck'}}
        def stop(self):pass
    monkeypatch.setattr(audio_service,'PrivateAudio',FailedAudio)
    calls=[]
    monkeypatch.setattr(native.subprocess,'Popen',lambda command,**kwargs:calls.append(command) or Process())
    game=native.NativeGame(tmp_path,state_dir=tmp_path/'state')
    (game.state_dir/'device-config.json').write_text('{"enabled":true}')
    try:
        status=game.start()
        assert status['running'] and status['audio_runtime']['state']=='dummy'
        command=calls[0]
        assert command[command.index('--audio-driver')+1]=='Dummy'
    finally:game.stop()


def test_sound_button_uses_private_game_server(adapted,tmp_path,monkeypatch):
    app,binding=adapted
    monkeypatch.setattr(native,'resolve_godot',lambda _:Path('/fake-godot'))
    monkeypatch.setattr(native,'verify_original',lambda _: {'verified':True})
    game=native.NativeGame(tmp_path,state_dir=tmp_path/'state')
    game.audio_service=object()
    game.audio_env={'PULSE_SERVER':'unix:/private/game'}
    game.device_report={'audio':{'output_available':True}}
    calls=[]
    monkeypatch.setattr(device,'test_audio',lambda state,**kwargs:calls.append(kwargs['base']) or {'test_sent':True})
    native.attach(binding,app,game)
    assert TestClient(app).post('/termux/audio/test').json()['test_sent']
    assert calls==[game.audio_env]
