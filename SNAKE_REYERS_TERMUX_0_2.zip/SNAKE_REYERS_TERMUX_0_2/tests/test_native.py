import json
import os
import subprocess
import socket
import sys
import threading
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux import native, prepare_project
from snake_termux.reuse_ai import installed_paths
from snake_termux.termux_packages import source_files


def test_unsupported_or_incomplete_original_is_rejected(tmp_path):
    exe = tmp_path / 'SnakeReyers.exe'
    exe.write_bytes(b'not a real game')
    with pytest.raises(ValueError, match='completo'):
        native.verify_original(exe)


def test_native_command_keeps_game_mode_and_uses_screen_zero(tmp_path):
    command = native.native_command(Path('/godot'), Path('/original.exe'), ['--screen', '1', '--resolution', '720x1280', '--', '--cobrinha-preview'], workdir=tmp_path)
    assert command[:3] == ['/godot', '--main-pack', '/original.exe']
    assert command[command.index('--screen') + 1] == '0'
    assert command[-2:] == ['--', '--cobrinha-preview']
    assert '--rendering-method' in command
    with pytest.raises(ValueError):
        native.native_command(Path('/godot'), Path('/game'), [], workdir=tmp_path, renderer='bad;sh')


def test_old_godot_is_rejected(tmp_path):
    binary = tmp_path / 'fake-godot'
    binary.write_text('#!/bin/sh\nprintf "4.6.3.stable\\n"\n')
    binary.chmod(0o700)
    with pytest.raises(ValueError, match='4.7'):
        native.resolve_godot(str(binary))


def test_own_game_process_lifecycle_and_aliases(adapted, tmp_path, monkeypatch):
    app, binding = adapted
    binary = tmp_path / 'fake-native'
    binary.write_text('#!/bin/sh\nexec sleep 30\n')
    binary.chmod(0o700)
    monkeypatch.setattr(native, 'resolve_godot', lambda _value: binary)
    monkeypatch.setattr(native, 'verify_original', lambda _path: {'verified': True})
    monkeypatch.setenv('DISPLAY', ':77')
    game = native.NativeGame(tmp_path, state_dir=tmp_path / 'state')
    native.attach(binding, app, game)
    from cobrinha_server.services import preview_renderer, session_executor_plan
    assert preview_renderer.EXPORTED_GAME_EXECUTABLE == game.wrapper
    assert session_executor_plan.preferred_live_executable() == str(game.wrapper)
    assert game.wrapper.stat().st_mode & 0o777 == 0o700
    client = TestClient(app)
    try:
        started = client.post('/termux/game/start').json()
        assert started['running'] is True
        assert client.post('/termux/game/start').json()['pid'] == started['pid']
        assert client.get('/termux/game').json()['automatic_restarts'] == 0
        assert client.post('/termux/game/stop').json()['running'] is False
        assert client.get('/termux/local-ai').status_code == 200
        events = (game.state_dir / 'process-events.jsonl').read_text().splitlines()
        assert len(events) == 1
        assert json.loads(events[0])['event'] == 'game_exit'
    finally:
        game.stop()


def test_apt_isolation_preserves_deb822_signed_by(tmp_path):
    parts = tmp_path / 'sources.list.d'
    parts.mkdir()
    main = parts / 'termux.sources'
    content = 'Types: deb\nURIs: https://termux.net\nSuites: stable\nComponents: main\nSigned-By: /trusted/main.gpg\n'
    main.write_text(content)
    (parts / 'glibc.list').write_text('deb https://packages-cf.termux.dev/apt/termux-glibc glibc main\n')
    (parts / 'tur.sources').write_text('Types: deb\nURIs: https://tur.kcubeterm.com\nSuites: tur\n')
    graphical = parts / 'x11.list'
    graphical.write_text('deb https://packages.termux.dev/apt/termux-x11 x11 main\n')
    assert source_files(tmp_path, x11=False) == [main]
    assert set(source_files(tmp_path, x11=True)) == {main, graphical}
    assert main.read_text() == content


def test_project_copy_preserves_original_and_existing_private(tmp_path, monkeypatch):
    source = tmp_path / 'source'
    (source / 'server/src/cobrinha_server').mkdir(parents=True)
    (source / 'server/src/cobrinha_server/main.py').write_text('original code')
    (source / 'VERSION').write_text('0.1.9')
    monkeypatch.setattr(prepare_project, 'verify_original', lambda _path: {})
    destination = tmp_path / 'destination'
    assert prepare_project.prepare(source, destination) == destination
    private = destination / 'server/private'
    private.mkdir()
    (private / 'config.json').write_text('keep my config')
    prepare_project.prepare(source, destination)
    assert (private / 'config.json').read_text() == 'keep my config'
    assert (source / 'server/src/cobrinha_server/main.py').read_text() == 'original code'
    with pytest.raises(ValueError, match='dentro'):
        prepare_project.prepare(source, source / 'child')


def test_ai_manifest_does_not_select_an_external_file(tmp_path):
    outside = tmp_path.parent / (tmp_path.name + '-outside.gguf')
    outside.write_bytes(b'model')
    try:
        with pytest.raises(ValueError):
            installed_paths(tmp_path, {'textModel': str(outside), 'voiceModel': str(outside)})
    finally:
        outside.unlink()


@pytest.mark.parametrize('text_enabled', [True, False])
def test_existing_ai_services_reused_without_manifest_or_ownership(adapted, local_service, tmp_path, text_enabled):
    import uvicorn
    app, binding = adapted
    binding.update({'enabled': text_enabled, 'local_port': local_service['port']})
    raw = binding.settings._raw()
    raw['voice_local_port'] = local_service['port']
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE, raw)
    listener = socket.socket()
    listener.bind(('127.0.0.1', 0))
    port = listener.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, log_level='error', lifespan='off'))
    thread = threading.Thread(target=lambda: server.run(sockets=[listener]), daemon=True)
    thread.start()
    child = None
    try:
        for _ in range(100):
            if server.started:
                break
            time.sleep(.02)
        assert server.started
        state = tmp_path / 'service-state'
        child = subprocess.Popen([sys.executable, '-m', 'snake_termux.reuse_ai', '--state', str(state), '--port', str(port), '--root', str(tmp_path / 'no-model-installation')], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        status = {}
        for _ in range(100):
            try:
                status = json.loads((state / 'ai-services.json').read_text())
                if status['state'] in ('ready', 'error'):
                    break
            except (OSError, ValueError):
                pass
            time.sleep(.05)
        assert status.get('state') == 'ready', status
        assert status['owned_pids'] == []
        assert binding.config()['enabled'] is text_enabled
        assert status['text_enabled'] is text_enabled
        child.terminate()
        assert child.wait(timeout=5) == 0
        from snake_termux.voice import PiperClient
        assert PiperClient(local_service['port']).health()['ready']
    finally:
        if child and child.poll() is None:
            child.terminate()
            child.wait(timeout=5)
        server.should_exit = True
        thread.join(timeout=5)
        listener.close()
