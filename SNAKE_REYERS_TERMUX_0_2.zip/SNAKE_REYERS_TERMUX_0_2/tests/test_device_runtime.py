import asyncio
import io
import json
import subprocess
import os
import shutil
import sys
import wave
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux import device_runtime as device
from snake_termux import native


def result(stdout='', stderr='', code=0):
    return subprocess.CompletedProcess([], code, stdout, stderr)


def icd_file(tmp_path):
    path = tmp_path / 'share/vulkan/icd.d/freedreno_icd.aarch64.json'
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({'ICD': {'library_path': 'libvulkan_freedreno.so'}}))
    return path


def test_gpu_requires_measured_renderer_not_package_name(tmp_path, monkeypatch):
    path = icd_file(tmp_path)
    calls = []
    def probe(command, **kwargs):
        calls.append((command, kwargs))
        return result('OpenGL renderer string: zink Vulkan 1.4 (Turnip Adreno (TM) 730)\n')
    monkeypatch.setattr(device, 'run', probe)
    base = {'PREFIX': str(tmp_path), 'LIBGL_ALWAYS_SOFTWARE': '1', 'OTHER_SETTING': 'keep'}
    env, report = device.graphics(base, tmp_path)
    assert report['hardware_verified'] is True
    assert report['resolution'] == '720x1280' and report['max_fps'] == 60
    assert env['GALLIUM_DRIVER'] == 'zink' and 'LIBGL_ALWAYS_SOFTWARE' not in env
    assert env['VK_DRIVER_FILES'] == str(path)
    assert base['LIBGL_ALWAYS_SOFTWARE'] == '1' and env['OTHER_SETTING'] == 'keep'
    assert calls[0][0] == ['glxinfo', '-B']


@pytest.mark.parametrize('renderer', ['llvmpipe (LLVM 21)', 'zink (llvmpipe LLVM 21)', 'lavapipe', ''])
def test_software_vulkan_never_reported_as_gpu(tmp_path, monkeypatch, renderer):
    icd_file(tmp_path)
    monkeypatch.setattr(device, 'run', lambda *_a, **_k: result('OpenGL renderer string: ' + renderer))
    env, report = device.graphics({}, tmp_path)
    assert report['hardware_verified'] is False
    assert report['resolution'] == '540x960' and report['max_fps'] == 30
    assert env['GALLIUM_DRIVER'] == 'llvmpipe'
    assert env['LP_NUM_THREADS'] == '3'
    assert 'VK_DRIVER_FILES' not in env


def test_missing_gpu_package_gives_working_software_profile(tmp_path):
    env, report = device.graphics({}, tmp_path)
    assert report['hardware_verified'] is False
    assert 'Freedreno' in report['message']
    assert env['LIBGL_ALWAYS_SOFTWARE'] == '1'


def test_gpu_probe_timeout_is_contained(tmp_path, monkeypatch):
    icd_file(tmp_path)
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired(args[0], 15)
    monkeypatch.setattr(device, 'run', timeout)
    _env, report = device.graphics({}, tmp_path)
    assert report['hardware_verified'] is False and 'probe_error' in report


def test_null_sink_repaired_with_official_android_fallback(monkeypatch):
    calls, loaded = [], []
    def pulse(command, **kwargs):
        calls.append(command)
        if command[1:4] == ['list', 'short', 'sinks']:
            return result('0 auto_null module-null-sink.c s16le\n' + ('1 aaudio_sink module-aaudio-sink.c s16le\n' if loaded else ''))
        if command[1:3] == ['load-module', 'module-sles-sink']:
            return result(stderr='SLES unavailable', code=1)
        if command[1:3] == ['load-module', 'module-aaudio-sink']:
            loaded.append(True)
            return result('7\n')
        if command[1] == 'get-default-sink':
            return result('auto_null\n')
        return result()
    monkeypatch.setattr(device, 'run', pulse)
    env, report = device.audio({})
    assert report['output_available'] is True and report['audibility_confirmed'] is False
    assert report['loaded_module'] == 'module-aaudio-sink'
    assert env['PULSE_SINK'] == 'aaudio_sink'
    assert ['pactl', 'set-default-sink', 'aaudio_sink'] in calls
    assert not any('set-sink-volume' in command for command in calls)


def test_existing_real_output_reused_without_new_modules(monkeypatch):
    calls = []
    def pulse(command, **kwargs):
        calls.append(command)
        return result('1 OpenSL_ES_sink module-sles-sink.c s16le\n') if 'sinks' in command else result('OpenSL_ES_sink\n')
    monkeypatch.setattr(device, 'run', pulse)
    env, report = device.audio({})
    assert report['output_available'] is True and env['PULSE_SINK'] == 'OpenSL_ES_sink'
    assert not any('load-module' in command or 'set-default-sink' in command for command in calls)


def test_original_explicit_rtmp_capture_route_is_preserved(monkeypatch):
    calls = []
    def pulse(command, **kwargs):
        calls.append(command)
        return result('0 auto_null module-null-sink.c s16le\n1 cobrinha_session_live module-null-sink.c s16le\n')
    monkeypatch.setattr(device, 'run', pulse)
    env, report = device.audio({'PULSE_SINK': 'cobrinha_session_live'})
    assert env['PULSE_SINK'] == 'cobrinha_session_live'
    assert report['virtual_capture'] is True and report['audibility_confirmed'] is False
    assert len(calls) == 1


def test_no_real_audio_output_is_not_falsely_reported_ready(monkeypatch):
    def pulse(command, **kwargs):
        return result('0 auto_null module-null-sink.c s16le\n') if 'sinks' in command else result(stderr='module failed', code=1)
    monkeypatch.setattr(device, 'run', pulse)
    _env, report = device.audio({})
    assert report['output_available'] is False
    assert len(report['errors']) == 2


def test_package_blank_status_is_not_treated_as_installed(tmp_path, monkeypatch):
    from snake_termux import termux_packages
    monkeypatch.setenv('PREFIX', '/data/local/snake-test')
    monkeypatch.setattr(device, 'run', lambda command, **kwargs: result('' if command[-1] == 'mesa-vulkan-icd-freedreno' else 'installed'))
    calls = []
    monkeypatch.setattr(termux_packages, 'apt', lambda apt_dir, arguments, **kwargs: calls.append((arguments, kwargs)))
    device.ensure_packages()
    assert calls == [(['update'], {'x11': True}), (['install', '-y', 'mesa-vulkan-icd-freedreno'], {'x11': True})]


def test_audio_test_uses_a_bounded_pcm_tone(tmp_path, monkeypatch):
    monkeypatch.setattr(device, 'audio', lambda base: ({'PULSE_SINK': 'real_sink'}, {'output_available': True, 'sink': 'real_sink', 'errors': []}))
    calls = []
    monkeypatch.setattr(device, 'run', lambda command, **kwargs: calls.append(command) or result())
    status = device.test_audio(tmp_path)
    assert status['test_sent'] is True
    assert calls[0][:2] == ['paplay', '--device=real_sink']
    with wave.open(str(tmp_path / 'audio-test.wav')) as stream:
        assert stream.getnchannels() == 1 and stream.getframerate() == 24000
        assert .5 < stream.getnframes() / stream.getframerate() < .6


def test_unconfigured_profile_leaves_existing_launch_unchanged(tmp_path):
    base = {'DISPLAY': ':1', 'PULSE_SINK': 'my_sink'}
    env, report = device.prepare_game(base, tmp_path)
    assert env == base and report == {}


def test_music_upload_does_not_escape_or_overwrite(tmp_path):
    from starlette.datastructures import UploadFile
    upload = UploadFile(filename='../../my music.mp3', file=io.BytesIO(b'audio-fixture'))
    first = asyncio.run(device.save_music(upload, tmp_path))
    assert first.parent == tmp_path and first.read_bytes() == b'audio-fixture'
    second = asyncio.run(device.save_music(UploadFile(filename='my music.mp3', file=io.BytesIO(b'another')), tmp_path))
    assert first != second and first.read_bytes() == b'audio-fixture'


def test_music_limit_removes_partial_file(tmp_path, monkeypatch):
    from starlette.datastructures import UploadFile
    monkeypatch.setattr(device, 'MAX_MUSIC_BYTES', 4)
    upload = UploadFile(filename='large.mp3', file=io.BytesIO(b'12345'))
    with pytest.raises(ValueError, match='limite'):
        asyncio.run(device.save_music(upload, tmp_path))
    assert not list(tmp_path.iterdir())


def test_music_api_and_game_audio_test(adapted, tmp_path, monkeypatch):
    app, binding = adapted
    from cobrinha_server.services import music_runtime
    binary = tmp_path / 'native-game'
    binary.write_text('#!/bin/sh\nexit 0\n')
    binary.chmod(0o700)
    monkeypatch.setattr(native, 'resolve_godot', lambda _: binary)
    monkeypatch.setattr(native, 'verify_original', lambda _: {'verified': True})
    monkeypatch.setattr(music_runtime, 'BACKGROUND_MUSIC_DIR', tmp_path / 'music')
    monkeypatch.setattr(music_runtime, 'MUSIC_RUNTIME_FILE', tmp_path / 'music.json')
    monkeypatch.setattr(device, 'test_audio', lambda state: {'output_available': True, 'test_sent': True})
    game = native.NativeGame(tmp_path, state_dir=tmp_path / 'state')
    native.attach(binding, app, game)
    client = TestClient(app)
    assert client.post('/termux/audio/test').json()['test_sent'] is True
    assert client.post('/termux/audio/speech-test').status_code == 409
    assert client.post('/termux/music/upload', files={'file': ('song.mp3', b'fixture', 'audio/mpeg')}).json()['track_count'] == 1
    assert client.post('/termux/music/upload', files={'file': ('program.exe', b'executable', 'application/octet-stream')}).status_code == 400


def test_new_profile_reaches_game_arguments_and_audio_environment(tmp_path, monkeypatch):
    binary = tmp_path / 'godot'
    binary.write_text('placeholder')
    monkeypatch.setattr(native, 'resolve_godot', lambda _: binary)
    monkeypatch.setattr(native, 'verify_original', lambda _: {'verified': True})
    monkeypatch.setenv('DISPLAY', ':1')
    monkeypatch.setenv('SNAKE_AUDIO_DRIVER', 'Dummy')
    monkeypatch.setattr(native, 'prepare_device', lambda env, state: ({**env, 'PULSE_SINK': 'real-output'}, {'graphics': {'resolution': '540x960', 'max_fps': 30}, 'audio': {'output_available': True}}))
    calls = []
    class Process:
        pid = 123456
        returncode = None
        def poll(self): return self.returncode
        def terminate(self): self.returncode = 0
        def wait(self, **kwargs): return self.returncode
    monkeypatch.setattr(native.subprocess, 'Popen', lambda command, **kwargs: calls.append((command, kwargs)) or Process())
    game = native.NativeGame(tmp_path, state_dir=tmp_path / 'state')
    try:
        assert game.start()['running']
        command, kwargs = calls[0]
        assert command[command.index('--resolution') + 1] == '540x960'
        assert command[command.index('--max-fps') + 1] == '30'
        assert command[command.index('--audio-driver') + 1] == 'PulseAudio'
        assert kwargs['env']['PULSE_SINK'] == 'real-output'
    finally:
        game.stop()


def test_device_repair_preserves_personal_data_in_files_only_mode(tmp_path):
    root = Path(__file__).resolve().parents[1]
    app = tmp_path / 'adapter'
    (app / 'snake_termux').mkdir(parents=True)
    (app / '.venv/bin').mkdir(parents=True)
    (app / '.venv/bin/python').symlink_to(sys.executable)
    for name in ('start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py'):
        (app / name).write_text('# old adapter\n')
    (app / 'state').mkdir()
    (app / 'state/keep-private.json').write_text('keep config and progress')
    run_repair = subprocess.run([shutil.which('bash'), str(root / 'SNAKE_REYERS_REPARAR_GPU_AUDIO_V024.sh'), '--files-only', str(app)], capture_output=True, text=True, timeout=15)
    assert run_repair.returncode == 0, run_repair.stdout + run_repair.stderr
    for name in ('start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py', 'snake_termux/device_runtime.py', 'snake_termux/ui.js', 'install-termux.sh'):
        assert (app / name).read_bytes() == (root / name).read_bytes()
    assert (app / 'state/keep-private.json').read_text() == 'keep config and progress'
    backup = next((app / 'state/launcher-backups').iterdir())
    assert (backup / 'snake_termux/native.py').read_text() == '# old adapter\n'
