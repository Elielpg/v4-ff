import json
import subprocess
from pathlib import Path

from snake_termux import device_runtime as device, native


def completed(stdout='', code=0, stderr=''):
    return subprocess.CompletedProcess([], code, stdout, stderr)


def test_android_fallback_uses_official_aaudio_close_workaround(monkeypatch):
    loaded, calls = [], []
    def run(command, **kwargs):
        calls.append(command)
        if command[1:4] == ['list', 'short', 'sinks']:
            return completed('1 snake_android_audio module-aaudio-sink.c s16le\n' if loaded else '0 auto_null module-null-sink.c s16le\n')
        if command[1:3] == ['load-module', 'module-sles-sink']:
            return completed(code=1, stderr='SLES not available')
        if command[1:3] == ['load-module', 'module-aaudio-sink']:
            loaded.append(True)
            return completed('10\n')
        if command[1] == 'get-default-sink':
            return completed('auto_null\n')
        return completed()
    monkeypatch.setattr(device, 'run', run)
    env, report = device.audio({})
    command = next(c for c in calls if c[1:3] == ['load-module', 'module-aaudio-sink'])
    assert 'no_close_hack=true' in command and 'pm=0' in command and 'latency=80' in command
    assert env['PULSE_SINK'] == 'snake_android_audio' and report['output_available']


def test_preflight_opens_pcm_then_allows_default_rerouting(tmp_path, monkeypatch):
    (tmp_path / 'device-config.json').write_text('{"enabled":true}')
    monkeypatch.setattr(device, 'audio', lambda env: ({**env, 'PULSE_SINK':'snake_android_audio'},
        {'output_available':True, 'sink':'snake_android_audio', 'errors':[], 'audibility_confirmed':False, 'message':'selected'}))
    monkeypatch.setattr(device, 'sinks', lambda env: [{'name':'snake_android_audio','module':'module-aaudio-sink.c'}])
    calls=[]
    monkeypatch.setattr(device, 'run', lambda command, **kwargs: calls.append((command, kwargs)) or completed())
    env, report = device.finalize_audio({'PREFIX':'/data/local/test','PULSE_SINK':'stale-from-first-probe'},tmp_path, {})
    assert 'PULSE_SINK' not in env and env['PULSE_LATENCY_MSEC'] == '80'
    assert report['audio']['stream_preflight_ok'] and report['audio']['route_mode'] == 'server-default'
    assert report['audio']['audibility_confirmed'] is False
    assert calls[0][0][:2] == ['paplay','--device=snake_android_audio']
    assert calls[0][1]['timeout'] == 6


def test_disappearing_output_never_passes_preflight(tmp_path, monkeypatch):
    (tmp_path / 'device-config.json').write_text('{"enabled":true}')
    monkeypatch.setattr(device, 'audio', lambda env: ({**env, 'PULSE_SINK':'gone'},
        {'output_available':True, 'sink':'gone', 'errors':[], 'message':'selected'}))
    monkeypatch.setattr(device, 'sinks', lambda env: [{'name':'auto_null','module':'module-null-sink.c'}])
    monkeypatch.setattr(device, 'run', lambda *a, **kw: completed())
    env, report = device.finalize_audio({'PREFIX':'/data/local/test'},tmp_path,{})
    assert not report['audio']['output_available'] and not report['audio']['stream_preflight_ok']
    assert 'PULSE_SINK' not in env


def test_explicit_capture_output_is_preserved_during_preflight(tmp_path, monkeypatch):
    (tmp_path / 'device-config.json').write_text('{"enabled":true}')
    monkeypatch.setattr(device, 'audio', lambda env: (env, {'output_available':True,'sink':'capture',
        'virtual_capture':True,'errors':[],'message':'capture'}))
    monkeypatch.setattr(device, 'sinks', lambda env: [{'name':'capture','module':'module-null-sink.c'}])
    monkeypatch.setattr(device, 'run', lambda *a, **kw: completed())
    env, report=device.finalize_audio({'PREFIX':'/data/local/test','PULSE_SINK':'capture'},tmp_path,
                                    {'audio':{'virtual_capture':True}},requested_sink='capture')
    assert env['PULSE_SINK']=='capture' and report['audio']['stream_preflight_ok']


class Process:
    pid=123456
    returncode=None
    def poll(self): return self.returncode
    def terminate(self): self.returncode=0
    def wait(self, **kwargs): return self.returncode


def fake_game(tmp_path,monkeypatch):
    monkeypatch.setattr(native,'resolve_godot',lambda _:Path('/fake-godot'))
    monkeypatch.setattr(native,'verify_original',lambda _: {'verified':True})
    monkeypatch.setenv('DISPLAY',':1')
    return native.NativeGame(tmp_path,state_dir=tmp_path/'state')


def test_audio_is_rechecked_after_display_and_before_spawn(tmp_path,monkeypatch):
    game=fake_game(tmp_path,monkeypatch)
    order=[]
    monkeypatch.setattr(native,'prepare_device',lambda env,state: (order.append('device') or env,{}))
    monkeypatch.setattr(native,'prepare_presentation',lambda env,state,report: order.append('display') or report)
    monkeypatch.setattr(native,'finalize_device_audio',lambda env,state,report: (order.append('audio') or env,report))
    monkeypatch.setattr(native.subprocess,'Popen',lambda *a,**kw: order.append('spawn') or Process())
    try:
        game.start()
        assert order==['device','display','audio','spawn']
    finally: game.stop()


def test_dummy_detection_uses_current_launch_not_historical_log(tmp_path,monkeypatch):
    game=fake_game(tmp_path,monkeypatch)
    game.log_path.write_text('WARNING: All audio drivers failed, falling back to the dummy driver.\n')
    game.process=Process()
    game.log_offset=game.log_path.stat().st_size
    assert game.status()['audio_runtime']['state']=='pending'
    with game.log_path.open('a') as stream:
        stream.write('WARNING: All audio drivers failed, falling back to the dummy driver.\nSPEECH_AUDIO_STARTED job=fake\n')
    status=game.status()['audio_runtime']
    assert status['state']=='dummy' and status['driver']=='Dummy'


def test_internal_playback_does_not_claim_audibility(tmp_path,monkeypatch):
    game=fake_game(tmp_path,monkeypatch)
    game.process=Process()
    game.log_path.write_text('SPEECH_AUDIO_STARTED job=fake\n')
    status=game.status()['audio_runtime']
    assert status['state']=='playback-requested' and 'não confirma' in status['message']
