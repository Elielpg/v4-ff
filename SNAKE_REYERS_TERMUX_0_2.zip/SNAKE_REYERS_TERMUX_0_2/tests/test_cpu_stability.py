import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

from snake_termux import piper_worker, device_runtime as device, presentation
from test_music_library import library


def test_piper_inference_threads_and_spin_are_explicitly_limited(tmp_path, monkeypatch):
    configs = {}
    class Options:
        def add_session_config_entry(self, name, value):
            configs[name] = value
    options = Options()
    calls = []
    ort = SimpleNamespace(SessionOptions=lambda: options,
        ExecutionMode=SimpleNamespace(ORT_SEQUENTIAL='sequential'),
        InferenceSession=lambda model, **kwargs: calls.append((model, kwargs)) or 'session')
    monkeypatch.setitem(sys.modules, 'onnxruntime', ort)
    monkeypatch.setitem(sys.modules, 'piper', SimpleNamespace(PiperVoice=lambda **kwargs: kwargs))
    monkeypatch.setitem(sys.modules, 'piper.config', SimpleNamespace(PiperConfig=SimpleNamespace(from_dict=lambda x: x)))
    model = tmp_path / 'voice.onnx'
    Path(str(model) + '.json').write_text('{"espeak":{"voice":"pt-br"}}')
    result = piper_worker.load_voice(model)
    assert options.intra_op_num_threads == 2 and options.inter_op_num_threads == 1
    assert options.execution_mode == 'sequential'
    assert all(value == '0' for value in configs.values()) and len(configs) == 2
    assert calls[0][1]['providers'] == ['CPUExecutionProvider']
    assert result['config']['espeak']['voice'] == 'pt-br'


def test_private_latency_bounded_and_default_capture_unchanged():
    assert device.output_latency({}) == 80
    assert device.output_latency({'PULSE_LATENCY_MSEC': '160'}) == 160
    assert device.output_latency({'PULSE_LATENCY_MSEC': '99999'}) == 300
    assert device.output_latency({'PULSE_LATENCY_MSEC': '0'}) == 40
    assert device.output_latency({'PULSE_LATENCY_MSEC': 'bad'}) == 80


def test_stable_profile_is_optional_and_stays_behind_gpu_gate(tmp_path, monkeypatch):
    monkeypatch.setattr(presentation, 'clean_display', lambda *args: {})
    before = presentation.settings(tmp_path)
    assert before['profile'] == 'balanced'
    presentation.save_settings(tmp_path, {'profile': 'stable'})
    gpu = presentation.prepare_display(tmp_path, {'PREFIX': '/data/local/test'},
        {'graphics': {'hardware_verified': True, 'resolution': '720x1280', 'max_fps': 60}})
    assert gpu['graphics']['max_fps'] == 30 and gpu['graphics']['resolution'] == '640x1136'
    cpu = presentation.prepare_display(tmp_path, {'PREFIX': '/data/local/test'},
        {'graphics': {'hardware_verified': False, 'resolution': '540x960', 'max_fps': 30}})
    assert cpu['graphics']['resolution'] == '536x960'


def test_music_preparation_lowers_only_its_ffmpeg_child_priority(library, tmp_path, monkeypatch):
    from snake_termux import music_library
    from snake_termux.device_runtime import tone
    client, controller, runtime = library
    sample = tmp_path / 'tone.wav'
    tone(sample)
    commands = []
    real_run = music_library.subprocess.run
    def record(command, **kwargs):
        commands.append(command)
        return real_run(command, **kwargs)
    monkeypatch.setattr(music_library.subprocess, 'run', record)
    response = client.post('/termux/music/import', files={'file': ('song.mp3', sample.read_bytes(), 'audio/mpeg')})
    assert response.status_code == 200, response.text
    converted = next(command for command in commands if 'libvorbis' in command)
    assert Path(converted[0]).name == 'nice' and converted[1:3] == ['-n', '10']
    assert converted[3] == 'ffmpeg' and converted[converted.index('-threads') + 1] == '1'
    assert not any('pkill' in command or 'killall' in command for command in commands)
