import asyncio
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from snake_termux import phonk,scene_graphics


@pytest.mark.parametrize('bad',[{}, {'enabled':'true'},{'palette':['#123456']},{'palette':['purple','#123456']},
    {'base_color':'https://bad'},{'intensity':float('nan')},{'sensitivity':True},{'sensitivity':0},
    {'manual_bpm':301},{'manual_bpm':140.2},{'color_every':0},{'source':'microphone'},
    {'color_mode':'shell'},{'script':'rm -rf'},{'track_palettes':{'../secret':['#123456','#abcdef']}},
    {'lightning':1},{'floor_reactive':'yes'},{'lightning_strength':2.1},{'floor_strength':-1},
    {'lightning_speed':0},{'lightning_strength':float('inf')},{'aura':'yes'},{'aura_strength':1.1}])
def test_invalid_settings_cannot_change_previous_or_execute_commands(tmp_path,bad):
    phonk.save(tmp_path,{'enabled':True})
    before=(tmp_path/'phonk-config.json').read_bytes()
    with pytest.raises(ValueError):phonk.save(tmp_path,bad)
    assert (tmp_path/'phonk-config.json').read_bytes()==before


def test_api_preserves_voice_private_settings_and_keeps_manual_explicit(tmp_path):
    secret=tmp_path/'ai.json';secret.write_text('{"voice":"piper","key":"private"}')
    binding=SimpleNamespace(replacements=[])
    native=SimpleNamespace(state_dir=tmp_path,log_path=tmp_path/'native.log')
    app=FastAPI();phonk.install(app,native,binding);client=TestClient(app)
    r=client.post('/termux/phonk',json={'enabled':True,'palette':['#ABCDEF','#123456']})
    assert r.status_code==200 and r.json()['settings']['palette']==['#abcdef','#123456']
    assert 'não escuta GreenTube' in r.json()['note']
    assert client.post('/termux/phonk/sync',json={'manual_bpm':160}).json()['settings']['source']=='manual'
    assert json.loads((tmp_path/'phonk-config.json').read_text())['manual_epoch']>0
    assert client.post('/termux/phonk/sync',json={'manual_bpm':160,'path':'/secret'}).status_code==400
    assert secret.read_text()=='{"voice":"piper","key":"private"}'


def test_theme_entry_does_not_force_graphics_audio_or_override_custom_modes(tmp_path):
    phonk.save(tmp_path,{'enabled':True})
    env={'PULSE_SINK':'original','SNAKE_RENDERER':'mobile'}
    args=['--max-fps','24','--','--cobrinha-live']
    output,new=scene_graphics.launch(env,args,tmp_path)
    assert new==['--script',str(phonk.SCRIPT),*args]
    assert output['PULSE_SINK']=='original' and output['SNAKE_RENDERER']=='mobile'
    config=json.loads(Path(output['SNAKE_SCENE_GRAPHICS_CONFIG']).read_text())
    assert not config['enabled'] and not config['adaptive_resolution']
    assert 'SNAKE_PHONK_CONFIG' in output
    for mode in (['--script','user.gd',*args],['--','--cobrinha-terrain-editor'],['--editor']):
        assert scene_graphics.launch(env,mode,tmp_path)==(env,mode)


def test_music_hook_refreshes_track_identity_without_taking_over_playback(tmp_path):
    calls=[]
    async def broadcast():calls.append('original');return True
    rows={'a1':{'source':'/music/a.ogg','title':'Faixa A'}}
    library=SimpleNamespace(inventory=lambda:rows,broadcast=broadcast)
    app=FastAPI();app.state.snake_music_library=library;binding=SimpleNamespace(replacements=[])
    phonk.install(app,SimpleNamespace(state_dir=tmp_path,log_path=tmp_path/'native.log'),binding)
    phonk.save(tmp_path,{'track_palettes':{'a1':['#ff00ff','#7722ff']}})
    rows['a1']['playable']='/music/prepared-a1.ogg'
    assert asyncio.run(library.broadcast()) is True and calls==['original']
    saved=json.loads((tmp_path/'phonk-config.json').read_text())
    assert saved['runtime']['tracks']['prepared-a1.ogg']['id']=='a1'
    assert saved['track_palettes']['a1'][0]=='#ff00ff'
    assert binding.replacements[0]==(library,'broadcast',broadcast)


def test_missing_theme_dependency_keeps_the_original_game_openable(tmp_path,monkeypatch):
    phonk.save(tmp_path,{'enabled':True})
    monkeypatch.setattr(phonk,'available',lambda:False)
    env,args=scene_graphics.launch({'PULSE_SINK':'kept'},['--','--cobrinha-live'],tmp_path)
    assert args[:2]==['--script',str(scene_graphics.SCRIPT)]
    assert env['PULSE_SINK']=='kept' and 'SNAKE_PHONK_CONFIG' not in env
    assert not phonk.status(tmp_path)['available']


def test_freeze_diagnostic_distinguishes_a_stale_scene_without_restart_or_private_log_text(tmp_path):
    import os,time
    log=tmp_path/'native.log';log.write_text('USER secret-comment\nVK_ERROR_DEVICE_LOST\n')
    report=tmp_path/'phonk-runtime.json';report.write_text(json.dumps({'at':time.time()-20,'enabled':True}))
    native=SimpleNamespace(state_dir=tmp_path,log_path=log,process=SimpleNamespace(pid=os.getpid(),poll=lambda:None))
    result=phonk.diagnostic(native)
    assert result['diagnostic']['game_running'] and result['diagnostic']['render_updates_stale']
    assert result['diagnostic']['graphics_errors']==['vk_error_device_lost']
    assert not result['diagnostic']['automatic_restart'] and 'secret-comment' not in json.dumps(result)
    report.write_text(json.dumps({'at':time.time(),'enabled':True}))
    assert not phonk.diagnostic(native)['diagnostic']['render_updates_stale']


def test_phonk_update_is_once_only_and_rollback_restores_files_and_settings(tmp_path):
    root=Path(__file__).resolve().parents[1];target=tmp_path/'adapter';(target/'snake_termux').mkdir(parents=True)
    for relative in ('start.sh','snake_termux/native.py','snake_termux/__main__.py'):
        (target/relative).write_text('# old file\n')
    helper=root/'SNAKE_REYERS_PHONK_V037.sh'
    first=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert first.returncode==0,first.stdout+first.stderr
    assert phonk.settings(target/'state')['enabled']
    backup=next((target/'state/launcher-backups').glob('*/REVERTER.py'))
    phonk.save(target/'state',{'enabled':False,'palette':['#112233','#778899']})
    repeated=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert repeated.returncode==0,repeated.stderr
    assert not phonk.settings(target/'state')['enabled']
    assert phonk.settings(target/'state')['palette']==['#112233','#778899']
    restored=subprocess.run([sys.executable,str(backup)],capture_output=True,text=True,timeout=5)
    assert restored.returncode==0,restored.stderr
    assert not (target/'state/phonk-config.json').exists()
    assert not (target/'snake_termux/phonk.py').exists()
    assert (target/'snake_termux/native.py').read_text()=='# old file\n'


def test_neon_migration_applies_requested_look_once_and_preserves_music_voice_and_palettes(tmp_path):
    root=Path(__file__).resolve().parents[1];target=tmp_path/'adapter';(target/'snake_termux').mkdir(parents=True)
    for relative in ('start.sh','snake_termux/native.py','snake_termux/__main__.py'):
        (target/relative).write_text('# old\n')
    phonk.save(target/'state',{'enabled':True,'source':'manual','manual_bpm':160,
        'color_mode':'fixed','palette':['#ff00ff','#00aaff']})
    before=(target/'state/phonk-config.json').read_bytes()
    private=target/'state/voice-settings.json';private.write_text('{"voice":"keep"}')
    helper=root/'SNAKE_REYERS_NEON_FLUIDEZ_V038.sh'
    result=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert result.returncode==0,result.stdout+result.stderr
    config=phonk.settings(target/'state')
    assert config['lightning'] and config['floor_reactive'] and config['color_mode']=='random'
    assert config['source']=='manual' and config['manual_bpm']==160 and config['palette']==['#ff00ff','#00aaff']
    backup=next((target/'state/launcher-backups').glob('neon-v038.*/REVERTER.py'))
    phonk.save(target/'state',{'color_mode':'beat','lightning':False})
    repeated=subprocess.run(['bash',str(helper),str(target)],capture_output=True,text=True,timeout=20)
    assert repeated.returncode==0,repeated.stderr
    assert phonk.settings(target/'state')['color_mode']=='beat' and not phonk.settings(target/'state')['lightning']
    restored=subprocess.run([sys.executable,str(backup)],capture_output=True,text=True,timeout=5)
    assert restored.returncode==0,restored.stderr
    assert (target/'state/phonk-config.json').read_bytes()==before
    assert private.read_text()=='{"voice":"keep"}'
