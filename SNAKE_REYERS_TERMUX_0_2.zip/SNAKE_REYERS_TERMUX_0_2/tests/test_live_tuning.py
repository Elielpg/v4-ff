import asyncio
import json
from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image


def test_direct_mode_enqueues_one_reply_and_keeps_spectator_activity(adapted,monkeypatch):
    from cobrinha_server.services import event_decision_worker as worker
    app,binding=adapted
    sent=[];jobs=[]
    async def activity(event,**kwargs):sent.append(event);return '/cache/avatar.png'
    monkeypatch.setattr(worker,'_send_spectator_activity',activity)
    monkeypatch.setattr(worker,'_comment_reply',lambda *a,**kw:'Ana, sete vezes oito é cinquenta e seis!')
    monkeypatch.setattr(worker.top_supporters,'is_priority_comment',lambda _:False)
    monkeypatch.setattr(worker,'enqueue_text',lambda text,**kw:jobs.append({'text':text,**kw}) or {'id':'reply'})
    monkeypatch.setattr(worker,'_write_status',lambda **kw:None)
    result=asyncio.run(worker._process_comment({'id':'comment1','kind':'comment','text':'quanto é sete vezes oito?','username':'ana','display_name':'Ana'}))
    assert result['mode']=='direct' and result['user_job'] is None and len(jobs)==1 and len(sent)==1
    assert jobs[0]['actor']=='main' and jobs[0]['metadata']['display_name']=='Ana'
    assert 'chat_reference_sequence_id' not in jobs[0]['metadata']
    assert jobs[0]['metadata']['audio_role']=='direct_reply'


def test_dialogue_mode_restores_original_two_jobs(adapted,monkeypatch):
    from cobrinha_server.services import event_decision_worker as worker
    app,binding=adapted
    assert TestClient(app).post('/termux/live-tuning',json={'reply_mode':'dialogue'}).status_code==200
    async def activity(*a,**kw):return ''
    monkeypatch.setattr(worker,'_send_spectator_activity',activity)
    monkeypatch.setattr(worker,'_comment_reply',lambda *a,**kw:'Olá, Ana!')
    monkeypatch.setattr(worker.top_supporters,'is_priority_comment',lambda _:False)
    monkeypatch.setattr(worker,'_write_status',lambda **kw:None)
    jobs=[]
    monkeypatch.setattr(worker,'enqueue_text',lambda text,**kw:jobs.append(kw) or {'id':str(len(jobs))})
    result=asyncio.run(worker._process_comment({'text':'oi','username':'ana'}))
    assert len(jobs)==2 and result['user_job'] is not None
    assert jobs[0]['actor']=='user' and jobs[1]['actor']=='main'


def test_pacing_settings_preserve_secrets_and_reject_unknown_options(adapted):
    app,binding=adapted
    binding.settings.write_json_atomic(binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE,{'openai_api_key':'private-test-key','other':'keep'})
    client=TestClient(app)
    assert client.get('/termux/live-tuning').json()['settings']['reply_mode']=='direct'
    response=client.post('/termux/live-tuning',json={'reply_mode':'dialogue'})
    assert response.status_code==200 and 'private-test-key' not in response.text
    assert binding.settings._raw()['other']=='keep' and binding.settings._raw()['openai_api_key']=='private-test-key'
    assert client.post('/termux/live-tuning',json={'reply_mode':'anything'}).status_code==400


def test_avatar_is_cached_as_small_png_and_original_stays_intact(tmp_path,monkeypatch):
    # Install after replacing the upstream function, as an independent hook test.
    from cobrinha_server.services import avatar_cache,user_ai_settings
    from snake_termux import live_tuning
    source=tmp_path/'original.jpg';Image.new('RGB',(1600,1000),'blue').save(source)
    original_bytes=source.read_bytes();seen=[]
    def cache(*a,**kwargs):seen.append(kwargs);return {'ok':True,'path':str(source),'cached':True}
    monkeypatch.setattr(avatar_cache,'cache_profile_avatar',cache)
    class Binding:
        settings=user_ai_settings
        def replace_aliases(self,original,replacement):
            if original is cache:avatar_cache.cache_profile_avatar=replacement
    from fastapi import FastAPI
    live_tuning.install(Binding(),FastAPI())
    try:
        result=avatar_cache.cache_profile_avatar('https://example.test/profile',user_key='ana')
        with Image.open(result['path']) as image:assert max(image.size)<=256
        assert source.read_bytes()==original_bytes and seen[0]['timeout']==2
    finally:avatar_cache.cache_profile_avatar=cache


def test_live_graphics_profile_keeps_gpu_gate(tmp_path,monkeypatch):
    from snake_termux import presentation
    presentation.save_settings(tmp_path,{'profile':'live','clean_display':False})
    report=presentation.prepare_display(tmp_path,{'PREFIX':'/data/local/test'},{'graphics':{'hardware_verified':True,'resolution':'720x1280'}})
    assert report['graphics']['max_fps']==45 and report['graphics']['resolution']=='640x1136'
