"""Controlled browser fixture. Not a production launcher or a real TikTok LIVE."""
import json
from pathlib import Path

import uvicorn

from conftest import local_service
from cobrinha_server.main import create_app
from cobrinha_server.services import tts_service, user_ai_settings
from snake_termux.integration import install

target = Path('/workspace/snake-reyers-termux-adapter-test-data/browser')
target.mkdir(parents=True, exist_ok=True)
service = local_service.__wrapped__()
fixture = next(service)
user_ai_settings.SOCIAL_TEXT_AI_CONFIG_FILE = target / 'social_text_ai.json'
tts_service.PREPARED_AUDIO_DIR = target / 'audio'
user_ai_settings.SOCIAL_TEXT_AI_CONFIG_FILE.write_text(json.dumps({'voice_local_port': 38083}))
app = create_app()
binding = install(app)
binding.update({'enabled': True, 'local_port': fixture['port']})
try:
    uvicorn.run(app, host='127.0.0.1', port=37993, lifespan='off', log_level='warning')
finally:
    binding.restore()
    try:
        next(service)
    except StopIteration:
        pass
