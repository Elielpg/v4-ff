import subprocess
import os
import shutil
import sys
from pathlib import Path

import pytest

from snake_termux import native


@pytest.mark.parametrize('stdout,stderr,expected', [
    ('4.7.stable.termux\n', '', (4, 7, 0)),
    ('4.7.2.stable.official.ed1daf0bf\n', '', (4, 7, 2)),
    ('Godot Engine v4.7.stable.termux - https://godotengine.org\n', '', (4, 7, 0)),
    ('\ufeff\x1b[32m4.7.stable.termux\x1b[0m\n', '', (4, 7, 0)),
    ('', '4.7.stable.termux\n', (4, 7, 0)),
    ('WARNING: startup message\n  4.7.1.stable.termux\n', '', (4, 7, 1)),
    ('4.6.3.stable', '', (4, 6, 3)),
    ('4.8.stable', '', (4, 8, 0)),
    ('CANNOT LINK EXECUTABLE', '', None),
])
def test_version_output_formats(stdout, stderr, expected):
    assert native.parse_godot_version(stdout, stderr) == expected


@pytest.mark.parametrize('version', ['4.7.stable.termux', '4.7.1.stable', '4.7.2.stable'])
def test_series_47_accepted_without_changing_binary(tmp_path, version):
    binary = tmp_path / 'godot'
    source = '#!/bin/sh\nprintf "%s\\n" "' + version + '"\n'
    binary.write_text(source)
    binary.chmod(0o700)
    assert native.resolve_godot(str(binary)) == binary
    assert binary.read_text() == source


def test_linker_failure_not_reported_as_incompatible_version(tmp_path):
    binary = tmp_path / 'godot'
    binary.write_text('#!/bin/sh\nprintf "CANNOT LINK EXECUTABLE: missing library\\n" >&2\nexit 1\n')
    binary.chmod(0o700)
    with pytest.raises(ValueError, match='CANNOT LINK EXECUTABLE'):
        native.resolve_godot(str(binary))


def test_version_timeout_has_readable_error(tmp_path, monkeypatch):
    binary = tmp_path / 'godot'
    binary.write_text('#!/bin/sh\nexit 0\n')
    binary.chmod(0o700)
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired(args[0], 10)
    monkeypatch.setattr(native.subprocess, 'run', timeout)
    with pytest.raises(ValueError, match='demorou demais'):
        native.resolve_godot(str(binary))


def repair_fixture(tmp_path):
    app = tmp_path / 'adapter'
    (app / 'snake_termux').mkdir(parents=True)
    (app / '.venv/bin').mkdir(parents=True)
    (app / '.venv/bin/python').symlink_to(sys.executable)
    (app / 'snake_termux/__init__.py').write_text('')
    originals = {'start.sh': '#!/bin/sh\necho legacy\n', 'snake_termux/native.py': 'LEGACY = True\n', 'snake_termux/__main__.py': 'LEGACY_MAIN = True\n'}
    for name, body in originals.items():
        (app / name).write_text(body)
    (app / 'state').mkdir()
    (app / 'state/private-settings.json').write_text('keep settings')
    return app, originals


def test_version_repair_preserves_settings_and_accepts_phone_output(tmp_path):
    app, originals = repair_fixture(tmp_path)
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run([shutil.which('bash'), str(root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh'), str(app)], capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stdout + result.stderr
    backups = list((app / 'state/launcher-backups').iterdir())
    assert len(backups) == 1
    for name, body in originals.items():
        assert (backups[0] / name).read_text() == body
        assert (app / name).read_bytes() == (root / name).read_bytes()
    assert (app / 'state/private-settings.json').read_text() == 'keep settings'
    binary = tmp_path / 'termux-godot'
    binary.write_text('#!/bin/sh\nprintf "4.7.stable.termux\\n"\n')
    binary.chmod(0o700)
    env = dict(os.environ, PYTHONPATH=str(app))
    check = subprocess.run([sys.executable, '-c', 'from snake_termux.native import resolve_godot; import sys; print(resolve_godot(sys.argv[1]))', str(binary)], cwd=app, env=env, capture_output=True, text=True, timeout=10)
    assert check.returncode == 0, check.stderr
    assert check.stdout.strip() == str(binary)


def test_invalid_repair_payload_does_not_replace_installed_files(tmp_path):
    app, originals = repair_fixture(tmp_path)
    root = Path(__file__).resolve().parents[1]
    body = (root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh').read_text().replace('from __future__ import annotations', 'from __future__ import ?INVALID', 1)
    broken = tmp_path / 'invalid-repair.sh'
    broken.write_text(body)
    result = subprocess.run([shutil.which('bash'), str(broken), str(app)], capture_output=True, text=True, timeout=10)
    assert result.returncode != 0
    for name, original in originals.items():
        assert (app / name).read_text() == original
    assert not list(app.glob('.godot-v022.*'))
