import asyncio
import io
import json
import time
import urllib.error
import urllib.request
import wave
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from snake_termux.cloud_ai import CloudAPI, APIError, classify

KEY = 'sk-proj-fixture-private-not-a-real-key-123456'
G1 = 'AIza-fixture-private-gemini-key-one-123456'
G2 = 'AIza-fixture-private-gemini-key-two-123456'


def configure(binding, provider='openai', **extra):
    return binding.update({'provider': provider, 'enabled': True, 'api_key': KEY,
        'gemini_keys': [{'key': G1}, {'key': G2}], **extra})


def test_existing_keys_do_not_opt_into_cloud_and_saves_never_call_api(adapted, monkeypatch):
    app, binding = adapted
    binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE.write_text(json.dumps({'provider': 'openai', 'openai_api_key': KEY}))
    monkeypatch.setattr(binding.cloud_api, 'request', lambda *a, **kw: pytest.fail('Saving/status must not call API'))
    assert binding.config()['provider'] == 'local'
    client = TestClient(app)
    status = configure(binding)
    assert status['provider'] == 'openai' and status['openai_key_present']
    for path in ('/termux/cloud/settings', '/termux/local-ai', '/api/settings/openai', '/termux/voice', '/'):
        result = client.get(path)
        assert KEY not in result.text and G1 not in result.text and G2 not in result.text
    assert binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE.stat().st_mode & 0o777 == 0o600
    assert len(status['gemini_keys']) == 2
    configure(binding)
    assert len(binding.cloud_api.entries()) == 2  # Duplicate additions are ignored.


def test_openai_response_through_original_reply_pipeline(adapted, monkeypatch):
    app, binding = adapted
    configure(binding)
    calls = []
    def request(provider, path, payload, key, **kwargs):
        calls.append((provider, path, payload, key))
        return {'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': 'Ana, sete vezes oito é cinquenta e seis!'}]}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    result = TestClient(app).post('/termux/ai/test', json={'text': 'Quanto é sete vezes oito?'})
    assert result.status_code == 200 and result.json()['provider'] == 'openai'
    assert 'cinquenta e seis' in result.json()['text']
    provider, path, payload, key = calls[0]
    assert provider == 'openai' and path == '/responses' and key == KEY
    assert payload['store'] is False and 'tools' not in payload
    assert 'Cofra do Afismo' in payload['instructions']
    assert KEY not in json.dumps(payload)


def test_gemini_auto_catalog_is_cached_and_does_not_select_audio_model(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini')
    calls = []
    def request(provider, path, payload, key, **kwargs):
        calls.append(path)
        if path == '/models': return {'models': [
            {'name': 'models/gemini-3.8-flash-tts', 'supportedGenerationMethods': ['generateContent']},
            {'name': 'models/gemini-3.5-flash-lite', 'supportedGenerationMethods': ['generateContent']},
            {'name': 'models/gemini-2.5-flash', 'supportedGenerationMethods': ['generateContent']}]}
        assert 'x-goog-api-key' not in json.dumps(payload) and key == G1
        assert 'tools' not in payload
        return {'candidates': [{'content': {'parts': [{'thought': True, 'text': 'hidden reasoning'}, {'text': 'Ana, olá! Como você está?'}]}}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    for _ in range(2):
        result = TestClient(app).post('/termux/ai/test', json={'text': 'Como você está?'})
        assert result.status_code == 200 and 'hidden reasoning' not in result.text
    assert calls.count('/models') == 1
    assert calls.count('/models/gemini-3.5-flash-lite:generateContent') == 2
    assert binding.cloud_api.keys_public()[0]['state'] == 'available'


def test_gemini_invalid_key_fails_over_but_project_quota_is_not_bypassed(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    calls = []
    def request(provider, path, payload, key, **kwargs):
        calls.append(key)
        if key == G1: raise APIError('Chave recusada.', status=401, code='invalid_key')
        return {'candidates': [{'content': {'parts': [{'text': 'Olá, Ana!'}]}}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'como vai?'}).status_code == 200
    assert calls == [G1, G2]
    assert binding.cloud_api.keys_public()[0]['state'] == 'invalid_key'
    binding.cloud_api.key_states.clear(); calls.clear()
    def exhausted(provider, path, payload, key, **kwargs):
        calls.append(key)
        raise APIError('Cota do projeto.', status=429, code='rate_limit', retry=45, project=True)
    monkeypatch.setattr(binding.cloud_api, 'request', exhausted)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'qual a resposta?'}).status_code == 503
    assert calls == [G1]  # Second key from same project never bypasses 429.
    assert all(e['state'] == 'cooldown' for e in binding.cloud_api.keys_public())
    assert TestClient(app).post('/termux/ai/test', json={'text': 'outra pergunta'}).status_code == 503
    assert len(calls) == 1


def test_different_project_can_reply_without_reusing_exhausted_project(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite', gemini_keys=[{'key': G1, 'project': 'a'}, {'key': G2, 'project': 'b'}])
    def request(provider, path, payload, key, **kwargs):
        if key == G1: raise APIError('Cota.', status=429, code='quota', retry=3600, project=True)
        return {'candidates': [{'content': {'parts': [{'text': 'Ana, tudo certo!'}]}}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'você está bem?'}).status_code == 200
    assert [k['state'] for k in binding.cloud_api.keys_public()] == ['cooldown', 'available']


def test_gemini_check_reports_availability_not_credit_balance(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    monkeypatch.setattr(binding.cloud_api, 'request', lambda *a, **kw: {'candidates': [{'content': {'parts': [{'text': 'OK'}]}}]})
    client = TestClient(app)
    key = binding.cloud_api.keys_public()[0]
    result = client.post('/termux/gemini/check', json={'id': key['id']}).json()
    assert result['ok'] and 'consome cota' in result['note'] and 'saldo' in result['note']
    assert G1 not in json.dumps(result)


def test_cloud_voice_separates_style_from_spoken_text_and_caches(adapted, monkeypatch, tmp_path):
    app, binding = adapted
    configure(binding, 'local')
    client = TestClient(app)
    response = client.post('/termux/cloud/voice', json={'provider': 'openai', 'voice': 'cedar', 'style': 'snake'})
    assert response.status_code == 200
    calls = []
    def request(provider, path, payload, key, **kwargs):
        calls.append(payload)
        assert provider == 'openai' and path == '/audio/speech' and key == KEY
        return b'\x10\x00' * 24000
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    for _ in range(2):
        result = client.post('/termux/voice/test', json={'text': 'Rosa, relógio e carro.'})
        assert result.status_code == 200 and result.content[:4] == b'RIFF'
        with wave.open(io.BytesIO(result.content)) as wav:
            assert wav.getframerate() == 24000 and wav.getnchannels() == 1
    assert len(calls) == 1
    assert calls[0]['input'] == 'Rosa, relógio e carro.'
    assert 'nasalidade' in calls[0]['instructions'] and calls[0]['response_format'] == 'pcm'
    assert binding.config()['provider'] == 'local'  # Brain and voice independent.
    assert client.post('/termux/cloud/voice', json={'provider': 'piper-local'}).status_code == 200
    assert binding.voice_config()['provider'] == 'piper-local'


def test_api_failures_never_expose_key_or_stop_panel(adapted, monkeypatch):
    app, binding = adapted
    configure(binding)
    def failed(*a, **kw): raise APIError('Cota esgotada.', status=429, code='quota')
    monkeypatch.setattr(binding.cloud_api, 'request', failed)
    client = TestClient(app)
    response = client.post('/termux/ai/test', json={'text': 'como está? '})
    assert response.status_code == 503 and KEY not in response.text
    assert client.get('/termux/cloud/settings').status_code == 200
    client.post('/termux/cloud/voice', json={'provider': 'openai'})
    assert client.post('/termux/voice/test', json={'text': 'Olá!'}).status_code == 503
    assert client.get('/').status_code == 200


@pytest.mark.parametrize('status,body,code', [(401, {}, 'invalid_key'), (403, {}, 'permission'), (429, {'error': {'code': 'insufficient_quota'}}, 'quota'), (429, {}, 'rate_limit'), (404, {}, 'model_unavailable')])
def test_http_errors_sanitized_and_retry_interval_honored(status, body, code):
    body.setdefault('echo', KEY)
    error = classify(status, body, '45')
    assert KEY not in str(error) and error.code == code
    if code == 'rate_limit': assert error.retry == 45


def test_http_transport_uses_fixed_hosts_and_does_not_follow_redirects(tmp_path):
    api = CloudAPI(lambda: {}, tmp_path / 'settings.json')
    captured = []
    class Response(io.BytesIO):
        headers = {'Content-Type': 'application/json'}
    class Opener:
        def open(self, req, **kwargs):
            captured.append(req)
            return Response(b'{"output_text":"hello"}')
    api.opener = Opener()
    api.request('openai', '/responses', {}, KEY)
    assert captured[0].full_url == 'https://api.openai.com/v1/responses'
    assert captured[0].headers['Authorization'] == 'Bearer ' + KEY
    api.request('gemini', '/models', None, G1)
    assert captured[1].full_url == 'https://generativelanguage.googleapis.com/v1beta/models'
    assert 'AIza' not in captured[1].full_url
    with pytest.raises(ValueError): api.request('openai', 'https://evil.example', {}, KEY)
    class Redirect:
        def open(self, req, **kwargs): raise urllib.error.HTTPError(req.full_url, 307, 'redirect', {}, io.BytesIO())
    api.opener = Redirect()
    with pytest.raises(APIError): api.request('openai', '/responses', {}, KEY)


def test_local_rate_limit_is_bounded_without_sleep(tmp_path):
    api = CloudAPI(lambda: {}, tmp_path / 'settings.json')
    for _ in range(20): api.reserve('test')
    with pytest.raises(APIError, match='20 chamadas'): api.reserve('test')


def test_gemini_project_cooldown_survives_restart_without_storing_key_values(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    def exhausted(*a, **kw): raise APIError('Cota.', status=429, code='rate_limit', retry=45, project=True)
    monkeypatch.setattr(binding.cloud_api, 'request', exhausted)
    TestClient(app).post('/termux/ai/test', json={'text': 'como vai?'})
    stored = binding.cloud_api.health_file.read_text()
    assert G1 not in stored and G2 not in stored and KEY not in stored
    new = CloudAPI(binding.settings._raw, binding.settings.SOCIAL_TEXT_AI_CONFIG_FILE)
    assert all(row['state'] == 'cooldown' for row in new.keys_public())
    monkeypatch.setattr(new, 'request', lambda *a, **kw: pytest.fail('Cooldown must survive restart'))
    with pytest.raises(APIError): new.gemini_call('Oi', 'Identity', 'gemini-2.5-flash-lite')


def test_gemini_quota_response_does_not_loop_or_sleep(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    monkeypatch.setattr(binding.cloud_api, 'request', lambda *a, **kw: (_ for _ in ()).throw(classify(429, {'error': {'details': [{'retryDelay': '31s'}]}})))
    response = TestClient(app).post('/termux/ai/test', json={'text': 'uma pergunta'})
    assert response.status_code == 503
    state = binding.cloud_api.keys_public()[0]
    assert state['retry_at'] > time.time() + 29


def test_clearing_openai_key_preserves_active_gemini(adapted):
    app, binding = adapted
    configure(binding, 'gemini')
    binding.update({'clear_key': True})
    assert binding.config()['provider'] == 'gemini' and binding.config()['enabled']
    assert not binding.public_status()['openai_key_present']


def test_key_specific_403_can_try_another_key_without_project_quota_rotation(adapted, monkeypatch):
    app, binding = adapted
    configure(binding, 'gemini', gemini_model='gemini-2.5-flash-lite')
    calls = []
    def request(provider, path, payload, key, **kwargs):
        calls.append(key)
        if key == G1: raise classify(403, {'error': {'message': 'Key restriction'}})
        return {'candidates': [{'content': {'parts': [{'text': 'Ana, olá!'}]}}]}
    monkeypatch.setattr(binding.cloud_api, 'request', request)
    assert TestClient(app).post('/termux/ai/test', json={'text': 'como vai?'}).status_code == 200
    assert calls == [G1, G2]
    assert binding.cloud_api.keys_public()[1]['state'] == 'available'


def test_cloud_services_do_not_launch_qwen_or_piper(adapted, tmp_path):
    import socket
    import subprocess
    import sys
    import threading
    import uvicorn
    app, binding = adapted
    configure(binding, 'gemini')
    assert TestClient(app).post('/termux/cloud/voice', json={'provider': 'openai'}).status_code == 200
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, log_level='error', lifespan='off'))
    thread = threading.Thread(target=lambda: server.run(sockets=[sock]), daemon=True); thread.start()
    child = None
    try:
        for _ in range(100):
            if server.started: break
            time.sleep(.01)
        child = subprocess.Popen([sys.executable, '-m', 'snake_termux.reuse_ai', '--state', str(tmp_path / 'reuse'), '--port', str(port), '--root', str(tmp_path / 'no-models')], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        for _ in range(100):
            try:
                status = json.loads((tmp_path / 'reuse/ai-services.json').read_text())
                if status['state'] in ('ready', 'error'): break
            except (OSError, ValueError): pass
            time.sleep(.03)
        assert status['state'] == 'ready', status
        assert status['owned_pids'] == [] and status['text_enabled'] is False
    finally:
        if child:
            child.terminate(); child.wait(timeout=5)
        server.should_exit = True; thread.join(timeout=5); sock.close()


def test_new_openai_key_clears_old_key_error_without_claiming_verified(adapted):
    app, binding = adapted
    configure(binding)
    binding.cloud_api.diagnostics['openai'].update(ready=False, last_error='Chave antiga recusada.')
    binding.cloud_api.provider_cooldowns['openai-text'] = time.time() + 300
    result = binding.update({'api_key': KEY + '-new'})
    assert result['openai_key_present']
    assert result['cloud_status']['openai']['last_error'] == ''
    assert result['cloud_status']['openai']['ready'] is None
    assert not binding.cloud_api.provider_cooldowns


def test_legacy_model_setting_is_applied_to_cloud_without_changing_local_model(adapted):
    app, binding = adapted
    binding.update({'provider': 'local', 'model': 'auto'})
    result = TestClient(app).post('/api/settings/openai', json={'provider': 'openai', 'model': 'gpt-4.1', 'api_key': KEY, 'enabled': True})
    assert result.status_code == 200 and result.json()['settings']['model'] == 'gpt-4.1'
    assert binding.public_status()['local_model'] == 'auto'
