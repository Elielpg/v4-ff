import asyncio
import io
import json
import subprocess
from types import SimpleNamespace
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from snake_termux.music_library import MusicLibrary, attach
from snake_termux.device_runtime import tone


@pytest.fixture
def library(adapted, tmp_path, monkeypatch):
    from cobrinha_server.services import music_runtime
    app, binding = adapted
    monkeypatch.setattr(music_runtime, 'BACKGROUND_MUSIC_DIR', tmp_path / 'background')
    monkeypatch.setattr(music_runtime, 'BACKGROUND_MUSIC_PROCESSED_DIR', tmp_path / 'processed')
    monkeypatch.setattr(music_runtime, 'MUSIC_RUNTIME_FILE', tmp_path / 'runtime.json')
    music_runtime.BACKGROUND_MUSIC_DIR.mkdir()
    controller = attach(binding, app, SimpleNamespace(state_dir=tmp_path / 'state'))
    return TestClient(app), controller, music_runtime


def sample(tmp_path):
    path = tmp_path / 'sample.wav'
    tone(path)
    return path.read_bytes()


def test_invalid_mp3_is_rejected_without_replacing_current(library):
    client, controller, runtime = library
    runtime.update(enabled=False, volume=.37)
    response = client.post('/termux/music/import', files={'file': ('Barões.mp3', b'<html>not a song</html>', 'audio/mpeg')})
    assert response.status_code == 400 and 'áudio' in response.json()['detail']
    assert not controller.status()['tracks'] and runtime.status()['volume'] == .37
    assert not runtime.status()['enabled']
    assert not list((controller.native.state_dir / 'music-originals').iterdir())


def test_mislabeled_existing_file_converts_and_manual_mode_excludes_starter(library, tmp_path):
    client, controller, runtime = library
    source = runtime.BACKGROUND_MUSIC_DIR / 'Barões [old].mp3'
    source.write_bytes(sample(tmp_path))  # WAV data with MP3 extension reproduces loader mismatch.
    starter = runtime.BACKGROUND_MUSIC_DIR / 'Neon Garden.wav'
    starter.write_bytes(source.read_bytes())
    before = source.read_bytes()
    status = client.get('/termux/music/library').json()
    key = next(t['id'] for t in status['tracks'] if 'Barões' in t['title'])
    response = client.post('/termux/music/control', json={'current': key, 'play': True})
    assert response.status_code == 200, response.text
    message = runtime.websocket_message()['payload']
    assert len(message['tracks']) == 1 and message['current_track'].endswith('.ogg')
    assert Path(message['current_track']).read_bytes().startswith(b'OggS')
    assert source.read_bytes() == before  # Original upload preserved.
    assert len(controller.status()['tracks']) == 2  # Conversion is not a third library entry.
    assert controller.status()['active']
    assert runtime.choose_session_start_track()['current_track'] == message['current_track']
    restored = MusicLibrary(runtime, controller.native)
    assert restored.status()['current'] == key
    assert restored.message()['payload']['tracks'] == message['tracks']
    client.post('/termux/music/control', json={'enabled': False, 'volume': .09})
    assert not runtime.websocket_message()['payload']['enabled']
    assert runtime.status()['volume'] == .09


def test_upload_multiple_tracks_shuffle_selection_and_next(library, tmp_path):
    client, controller, runtime = library
    ids = []
    for title in ('First', 'Second', 'Excluded'):
        response = client.post('/termux/music/import', files={'file': (title + '.mp3', sample(tmp_path), 'audio/mpeg')})
        assert response.status_code == 200, response.text
        ids.append(response.json()['id'])
    chosen = ids[:2]
    result = client.post('/termux/music/control', json={'mode': 'shuffle', 'selected': chosen, 'play': True})
    assert result.status_code == 200, result.text
    tracks = runtime.websocket_message()['payload']['tracks']
    assert len(tracks) == 2 and all(controller.data['records'][key]['playable'] in tracks for key in chosen)
    excluded = controller.data['records'][ids[2]]['playable']
    assert excluded not in tracks
    current = result.json()['music']['current']
    result = client.post('/termux/music/control', json={'next': True, 'play': True})
    assert result.json()['music']['current'] in chosen and result.json()['music']['current'] != current
    assert len(controller.status()['tracks']) == 3


@pytest.mark.parametrize('payload', [{'volume': 2}, {'volume': True}, {'current': '/etc/passwd'}, {'mode': 'shell'}, {'selected': ['unknown']}, {'selected': 'x'}, {'command': 'rm'}, {'mode': 'shuffle', 'selected': [], 'play': True}])
def test_invalid_controls_leave_playback_unchanged(library, payload):
    client, controller, runtime = library
    before = runtime.status()
    response = client.post('/termux/music/control', json=payload)
    assert response.status_code == 400
    assert runtime.status() == before


def test_conversion_failure_preserves_playlist_and_records_error(library, tmp_path, monkeypatch):
    client, controller, runtime = library
    path = runtime.BACKGROUND_MUSIC_DIR / 'Broken.mp3'
    path.write_bytes(b'not audio')
    key = client.get('/termux/music/library').json()['tracks'][0]['id']
    before = runtime.status()
    response = client.post('/termux/music/control', json={'current': key, 'play': True})
    assert response.status_code == 400
    assert runtime.status() == before and not controller.data['active']
    assert controller.status()['tracks'][0]['error']
    assert path.read_bytes() == b'not audio'


def test_busy_import_does_not_block_status_or_change_controls(library):
    client, controller, runtime = library
    controller.operation.acquire()
    try:
        assert client.get('/termux/music/library').status_code == 200
        assert client.post('/termux/music/control', json={'play': True}).status_code == 409
        assert client.post('/termux/music/import', files={'file': ('a.mp3', b'data')}).status_code == 409
    finally:
        controller.operation.release()


def test_preparation_runs_off_event_loop(library, tmp_path, monkeypatch):
    import threading
    client, controller, runtime = library
    source = runtime.BACKGROUND_MUSIC_DIR / 'Waiting.wav'
    source.write_bytes(sample(tmp_path))
    key = controller.status()['tracks'][0]['id']
    entered, release = threading.Event(), threading.Event()
    prepare = controller.prepare_checked
    def delayed(key):
        entered.set()
        assert release.wait(3)
        return prepare(key)
    monkeypatch.setattr(controller, 'prepare_checked', delayed)
    async def exercise():
        task = asyncio.create_task(controller.control({'current': key, 'play': True}))
        for _ in range(100):
            if entered.is_set(): break
            await asyncio.sleep(.01)
        assert entered.is_set()
        # This coroutine and status still advance while FFmpeg's thread waits.
        assert not task.done() and controller.status()['tracks']
        release.set()
        result = await task
        assert result['ok']
    asyncio.run(exercise())


def test_uploaded_vorbis_is_available_to_legacy_runtime_and_not_reencoded(library, tmp_path):
    client, controller, runtime = library
    wav = tmp_path / 'tone.wav'
    tone(wav)
    ogg = tmp_path / 'tone.ogg'
    subprocess.run(['ffmpeg', '-nostdin', '-y', '-v', 'error', '-i', str(wav), '-c:a', 'libvorbis', str(ogg)], check=True)
    data = ogg.read_bytes()
    response = client.post('/termux/music/import', files={'file': ('Good.ogg', data, 'audio/ogg')})
    assert response.status_code == 200, response.text
    key = response.json()['id']
    record = controller.data['records'][key]
    assert Path(record['source']).read_bytes() == data
    assert Path(record['playable']).read_bytes() == data  # No quality loss for ready Vorbis.
    assert record['playable'] in runtime.tracks()
    response = client.post('/termux/music/control', json={'current': key, 'play': True})
    assert response.status_code == 200
    assert runtime.status()['current_track'] == record['playable']
