# Arquitetura e pendências — 24/11/2026

## Estrutura

Na 0.2.9, `music_library.py` instala hooks reversíveis sobre `music_runtime.websocket_message` e `choose_session_start_track`. Os arquivos e o player originais permanecem intactos. A mensagem mantém volume/pausa do runtime e filtra `tracks`/metadados para uma única faixa repetida ou para o subconjunto marcado. A biblioteca não adiciona outro player ao mixer nem interfere na fila de voz ou no TikTok.

Rotas: GET `/termux/music/library`, POST `/termux/music/import` (um multipart por arquivo), POST `/termux/music/control` e compatibilidade com POST `/termux/music/upload`. A API aceita IDs de faixas conhecidas, não comandos ou caminhos arbitrários. O conteúdo é analisado por FFprobe; FFmpeg roda com argumentos separados, protocolos locais, uma thread, timeout e arquivo temporário antes da substituição atômica. A preparação usa `asyncio.to_thread`, com uma operação por vez e status consultável. Seleção, modo, metadados e cache ficam em JSON próprio; os originais são mantidos.

Falha confirmada no aparelho: o Godot registra `MUSIC_LOAD_FAIL` e `Failed to decode mp3 file` para duas cópias de Barões, então volta à trilha padrão. O conteúdo exato desses arquivos não foi recebido; pode ser outro contêiner renomeado ou um download incompleto. Converter resolve contêiner compatível mal nomeado; não recupera áudio inexistente. Pendentes: validar os mesmos arquivos no GT3 e observar memória/temperatura em faixas longas. Biblioteca salva não é confirmação de saída física; o painel informa seleção enviada, e os testes Linux capturam o mixer.

Na 0.2.8, `live_tuning.py` instala hooks reversíveis sobre o tratamento de comentários e o cache de avatares. O modo direto enfileira apenas o ator principal, sem metadados de par que esperariam uma leitura prévia do usuário. Preserva a seleção visual do espectador e a prioridade dos apoiadores. O modo de diálogo chama a função original. Os presentes seguem o fluxo original.

Avatar e geração textual são aguardados em paralelo; o enfileiramento só acontece depois de ambos, sem tarefas atrasadas de seleção roubando o foco durante a fala. A imagem derivada de até 256 px fica ao lado do cache original. A opção `termux_reply_mode` fica no arquivo privado de IA existente, preservando os outros campos. `/termux/live-tuning` retorna apenas modo e métricas de preparação, sem texto de comentários, fotos ou chaves.

Pendências: validar o tempo entre comentário real e áudio no GT3, observar travadas no perfil LIVE e, para alterar a interpolação interna de câmera/oclusão por objetos, obter uma versão publicada do projeto Godot. A revisão atual reduz o acionamento do foco intermediário; não altera recursos privados do pacote.

A revisão 0.2.7 separa a preparação gráfica da consulta de áudio compartilhado. `audio_service.py` cria um servidor PulseAudio próprio para a janela nativa e acompanha seu processo. O socket Unix fica numa pasta com permissão 0700. O jogo e o teste de som recebem o mesmo `PULSE_SERVER`. Não se carrega a configuração compartilhada do daemon nem a suspensão por inatividade.

Falha de áudio passa a escolher Dummy explicitamente antes de iniciar Godot, evitando que o motor tente conectar a um servidor sem resposta. O jogo continua visual, com aviso de som indisponível. Os processos próprios recebem encerramento limitado e a limpeza fica restrita à pasta temporária que o complemento criou. O wrapper de captura mantém rotas explícitas do original. Não há mudanças de modelos/IA, game assets ou reinícios automáticos em ciclo.

O GT3 confirmou timeout de pactl com GPU/tela prontas. O caminho privado e o fallback visual foram testados com o jogo original no Linux; AAudio físico, calor e longa duração no aparelho permanecem pendentes.

A revisão 0.2.6 adiciona uma segunda verificação de áudio após as preferências X11 e antes do processo Godot. Ela usa um PCM silencioso para verificar abertura do stream e presença da saída, sem afirmar audibilidade. O fallback AAudio usa a proteção oficial contra fechamento/retomada problemática. O processo recebe latência de saída de 80 ms. O painel identifica driver Dummy no log da execução atual, mesmo que a reprodução interna informe início/fim.

Falha atual do GT3: áudio gerado e eventos de fala completos, mas Godot em Dummy e apenas auto_null disponível. O desaparecimento exato do módulo Android não foi reproduzido em hardware. Não foram acrescentados reinícios automáticos de processo/daemon, nem um segundo player que pudesse duplicar falas. A próxima validação é aplicar a 0.2.6 e conferir a fala no aparelho.

Na revisão 0.2.5, `presentation.py` aplica as preferências oficiais do Termux:X11 com backup e timeout, confirma a resolução pelo `xdpyinfo` e escolhe o modo fullscreen do processo original. O perfil só aumenta a resolução quando `device_runtime.py` confirmou GPU. O arquivo `presentation-config.json` guarda a opção de qualidade. Isso não altera shaders, personagens, câmera, regras nem os recursos internos do jogo.

O mesmo módulo adiciona a faixa própria `assets/music/Neon Garden.ogg` uma única vez numa biblioteca vazia. O runtime e o websocket originais continuam responsáveis pela playlist, pausa, volume e reprodução. Não há geração de música durante a LIVE nem uma segunda fila de áudio concorrendo com Piper.

Pendências atuais: confirmar a interface limpa e a nova trilha no GT3; medir FPS/temperatura/latência durante uma LIVE real prolongada; validar captura/transmissão Android. O usuário já confirmou GPU no relatório e testes de som/voz audíveis. Os limites de FPS são configurações, não resultados de benchmark.

```text
start.sh → Termux:X11 + PulseAudio → python -m snake_termux --game --reuse-ai
  └─ servidor FastAPI original 0.1.9
       ├─ painel original + controles locais ui.js
       ├─ monitor TikTok original ← @ normalizado
       ├─ regras/eventos/gameplay originais
       ├─ respostas sociais originais
       │    └─ client.py → Qwen em loopback, sem API externa
       └─ fila de fala original
            ├─ voice.py → Piper local → WAV + timeline originais
            └─ XTTS original, quando selecionado

jogo Godot original ← bridge original /ws/godot
  └─ native.py → Godot 4.7.2 --main-pack arquivo original
       ├─ execução e renderização Linux x86_64 comprovadas
       └─ execução ARM64/Android: pendente de validação no aparelho
```

`integration.py` instala hooks reversíveis depois de importar o servidor. Atualiza também referências já importadas por outros módulos: trocar apenas a função em `social_text_ai` deixaria algumas chamadas usando a função antiga que exige chave. `restore()` permite desfazer os hooks nos testes; encerrar o processo os desfaz no uso normal.

As chamadas de IA e Piper usam portas configuráveis somente em 127.0.0.1. Proxies de ambiente e redirecionamentos HTTP são desabilitados nesses clientes para não encaminhar o conteúdo a outro host. Não existe executor de comandos solicitado pelo modelo. A entrada @ é validada antes de chegar ao monitor original.

`voice.py` usa o serviço Piper já existente: `/health` deve anunciar um modelo Piper pronto e `/synthesize` deve devolver WAV PCM válido. Não instala modelos nem inicia automaticamente a clonagem. A configuração pode manter XTTS original. O retorno inclui `audio_path`, `timeline_path`, `timeline`, `voice_path` e `chunks`, consumidos pela fila original.

`device_runtime.py` acrescenta configuração por processo para Zink/Turnip, verificação do renderizador e fallback de CPU. O mesmo módulo prepara uma saída PulseAudio real, com fallback OpenSL ES → AAudio, e registra diagnóstico em `state/device-runtime.json`. O motor usa PulseAudio quando uma saída real é preparada, evitando uma variável antiga Dummy silenciar o jogo. Os novos controles permitem testar sinal, fala pela fila original e selecionar música local.

## Problemas encontrados e situação

| Problema | Evidência | Situação |
|---|---|---|
| IA original exige chave OpenAI e usa `/v1/responses` | Leitura de `social_text_ai.py` e `user_ai_settings.py` | Adaptada para chat/completions local; teste HTTP com servidor controlado passou. Falta Qwen real no GT3. |
| Referências antigas de funções na fila social | Imports por valor em `social_reply.py` | Hook cobre aliases; teste de pergunta e presente passou. |
| Fonética XTTS aplicada a outro motor pode alterar pronúncia | Substituições em `prepare_tts_input` | Piper recebe grafia brasileira sem essas trocas. Isso não prova qualidade perceptual de todos os nomes. |
| Clonador lento pode ocupar a porta anterior | Histórico e contratos dos serviços | Detecção do modelo evita confundir clonador com Piper. |
| Voz gerada sem reprodução no navegador | Histórico; política de autoplay | Player e botão de retomada implementados; WAV real decodificado no Chromium. Falta teste do jogo Android. |
| Motor Windows x86_64 incompatível diretamente com ARM64 | Cabeçalho PE | Godot nativo carrega os dados originais via main-pack; funcionamento e renderização comprovados no Linux. Falta validar Android. |
| Executável inicialmente incompleto | Manifesto dos oito fragmentos | Resolvido: oito partes válidas e SHA-256 completo correspondente. |
| Atualizador original instala pacotes de desktop | Leitura dos launchers/updater | Instalação automática de desktop bloqueada pelo adaptador; conferência manual necessária. |
| Python 3.13 remove `audioop` | Import em `audio_timeline.py` | Dependência `audioop-lts` prevista. Testes atuais em Python 3.12. |
| Instalador Linux pressupõe desktop e voz pesada | Leitura de install.sh, requisitos e launchers | Bootstrap Termux/X11 independente, com cópia interna, backup e reutilização dos modelos. Instalação Android ainda não testada. |
| Áudios completos não estão nos uploads | Apenas manifests/links recebidos | Preservados os mecanismos originais, sem afirmar que os pacotes musicais estão disponíveis. |
| Programa termina e volta ao prompt | Relato do usuário sobre projetos anteriores | Não reproduzido no celular. Logs e códigos de saída adicionados para obter evidência. Não há diagnóstico comprovado de memória/Android. |
| Jogo lento no GT3 | Log de OpenGL informa llvmpipe; Freedreno não instalado | Reparo instala driver oficial e mede renderer antes de ativar perfil GPU; verificação real do GT3 pendente. |
| Jogo sem áudio | PulseAudio informa apenas auto_null | Preparação de saída Android e teste de som implementados; confirmação auditiva no GT3 pendente. |
| Sem música de fundo | Log original informa tracks=0 | Seleção/upload de arquivo local adicionada ao painel, usando o runtime original. |

## Próximas verificações

1. Testar instalação Bionic/ARM64 e drivers Termux:X11 no GT3; o caminho de carga já foi comprovado no Linux.
2. Testar Qwen real, comentários e presentes numa LIVE curta; nenhum teste local comprova acesso atual do TikTok.
3. Medir estabilidade e memória/temperatura no GT3 com gráficos, IA, voz e captura juntos. Não há benchmark desse conjunto ainda.
4. Investigar encerramentos com os novos logs e código de saída. Este complemento não cria laços de reinicialização automática.

`reuse_ai.py` procura os serviços existentes e pode iniciar somente os binários/modelos da instalação anterior. `prepare_project.py` mantém a cópia original e faz backup privado. `termux_packages.py` isola temporariamente as fontes APT principal/X11, preservando formato Deb822, Signed-By e verificação de assinatura.

Nenhuma promessa de FPS, latência ou estabilidade no Android é feita com base nos resultados da máquina Cloud.
