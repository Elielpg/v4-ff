# Validação nativa — 24/11/2026

As oito partes foram recebidas e conferidas por CRC e SHA-256. O executável reunido tem 193.264.984 bytes e SHA-256:

`9a16a7f9596146927ececdbba523b8f0aefc59f0568d898e097f6f2bd598cd97`

## Caminho comprovado

O arquivo contém dados compilados Godot com rodapé reconhecido pelo motor. **O Godot nativo carrega esse contêiner com `--main-pack`.** Não é necessário executar o motor Windows x86_64 nem extrair ou decompilar o projeto-fonte privado.

O runtime oficial Linux 4.7.2 foi conferido com o SHA-512 publicado no release do Godot. A versão 4.6.3 falhou com `Pack version unsupported: 4`; a 4.7.2 carregou o jogo.

Na revisão 0.2.2, o runtime oficial 4.7 também foi obtido e conferido por SHA-512. Sua saída `4.7.stable.official.5b4e0cb0f` usa o mesmo formato sem patch informado pelo celular (`4.7.stable.termux`). O jogo original carregou, renderizou, conectou ao servidor e confirmou `speech_started`/`speech_finished` para a mesma fala. O motor de voz era Piper real; a resposta de Qwen era uma fixture HTTP e a saída de áudio usou Dummy para verificar término da reprodução.

O fonte público do [carregador PCK do Godot 4.7](https://github.com/godotengine/godot/blob/4.7-stable/core/io/file_access_pack.cpp) identifica explicitamente o patch como não usado para validação. A checagem rígida anterior era do adaptador, e foi corrigida. As evidências estão em `GODOT47_V022_INTEGRATION.json` e `original-native-godot47.png`.

No teste gráfico com X11 virtual e OpenGL Compatibility por Mesa llvmpipe, foram observados:

- Jogo em execução e ponte WebSocket original conectada.
- Tabuleiro original com 529 células lógicas, canhão e 16 espaços de espectadores.
- Cena renderizada e capturada em 720×1280, com cobra, tabuleiro, palco e cenário.
- Texturas e modelos carregados diretamente do contêiner original.

Não houve substituição de personagens, cenário, código de gameplay ou identidade. Não foi obtido o projeto-fonte Godot privado.

## Iniciador

`native.py` confere integridade e versão, cria um wrapper independente e redireciona em memória as referências de executável do servidor. Os fontes originais não são reescritos.

Os planos de desktop pedem a segunda tela e incluem variáveis NVIDIA. O wrapper seleciona a tela 0 e retira essas variáveis para o motor nativo. O `.exe` funciona como contêiner de dados; quem executa é o Godot da arquitetura instalada.

`start.sh` prepara Termux:X11 e PulseAudio. O pacote Godot do Termux tem receita oficial 4.7.2, mas a identificação real recebida do celular foi 4.7.stable.termux. A instalação Bionic/ARM64 não foi executada nesta máquina Linux x86_64.

## Limites dos testes

Atualização recebida do usuário: o jogo apareceu no GT3 ao abrir a janela padrão do Termux:X11 sem `-d main`. Os logs mostram Godot 4.7.stable.termux, OpenGL 4.5 Mesa 26.0.6/llvmpipe, 529 células e conexão WebSocket. Isso confirma abertura e execução no aparelho, mas o usuário relatou lentidão e ausência de som. Aceleração GPU, áudio e estabilidade continuam em diagnóstico.

- FPS, temperatura, consumo e estabilidade prolongada no GT3 ainda não foram medidos.
- TikTok real e captura/RTMP Android ainda não foram testados.
- Compatibilidade no Linux não comprova todos os drivers Android.
- O primeiro teste de captura foi invalidado pelo encerramento do display virtual do próprio teste. Foi repetido mantendo display, servidor e jogo no mesmo ciclo de vida. A captura válida está em `evidence/original-native-720x1280.png`.
- Houve aviso de V-Sync indisponível no display virtual; não foi considerado defeito comprovado no celular.
