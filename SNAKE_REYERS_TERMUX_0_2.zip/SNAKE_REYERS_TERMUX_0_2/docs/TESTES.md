# Registro de testes — 24/11/2026

Ambiente: Cloud Linux x86_64, Python 3.12, Node 24 e Chromium headless. Os resultados abaixo não são benchmarks do Realme GT3.

| Verificação | Resultado | Limite |
|---|---|---|
| Suíte Python original 0.1.9 | 67 passaram | Executada na cópia de auditoria, sem hooks |
| Política de conexão Node original | 3 passaram | Sem conexão com TikTok real |
| Testes do complemento na revisão 0.2.2 | 55 passaram | Qwen e parte das respostas WAV simulados por HTTP loopback |
| Navegador com painel original e complemento | Passou; nenhum erro JavaScript capturado | Chromium, não Chrome Android |
| Geração com Piper real pt_BR-faber-medium | WAV PCM 22.050 Hz, 4,389 s; timeline com 16 segmentos | Modelo carregado na Cloud; não avalia timbre subjetivo ou desempenho do celular |
| Reprodução do segundo teste Piper no navegador | Áudio de 4,957 s, readyState 4, sem erro, reprodução iniciada | Não confirma o áudio dentro do jogo Godot |
| Integridade dos arquivos originais | 127 conferidos, nenhum alterado | Comparados ao manifesto SHA-256 dos arquivos recebidos |
| Executável completo | Oito partes e SHA-256 final conferidos | Original preservado |
| Jogo gráfico original | Carregou e renderizou em 720×1280; ponte original conectada | Godot 4.7.2 Linux x86_64, X11/OpenGL por software |
| Resposta → Piper → fila original → Godot | Jogo informou speech_started e speech_finished para o mesmo job | Qwen simulado, Piper real; driver Dummy, sem gravação de alto-falante |
| LIVE real, captura/RTMP e longa duração | Não realizadas | Dependem da instalação Android e conta ao vivo |

## O que os testes do complemento verificam

- Validação de portas, modelos e @; entradas que parecem comando não são usadas como comandos.
- Descoberta automática do modelo, cache do catálogo e chamada chat/completions sem Authorization.
- Bloqueio de redirecionamento para outro host.
- Respostas vazias, inválidas ou sem resposta final geram falha identificável.
- Configuração sem chave; segredo antigo preservado no arquivo privado e ausente da resposta pública.
- Perguntas e presentes usando as referências importadas pelo módulo social original.
- Saudações instantâneas preservadas; IA desabilitada não faz requisições.
- Painel original com script local injetado, endpoints de teste e resposta de erro para voz inválida.
- Texto de Piper sem trocar R/L ou grafia brasileira; contrato WAV/timeline preservado.
- Caminho pergunta → resposta social original → preparação do job na fila original → áudio e timeline.
- WAV truncado rejeitado antes de aparecer como fala pronta.
- Clonador não confundido com Piper; XTTS original continua selecionável.
- Tentativa de instalar atualização de desktop interrompida nesta adaptação.
- Versão de Godot inadequada e arquivo original incompleto rejeitados.
- Argumentos do motor, modo original e seleção da tela preservados/adaptados.
- Ciclo de vida do processo próprio, sem lançamento duplicado ou reinício em ciclo.
- Cópia interna sem sobrescrever configuração existente; seleção de fontes APT com Signed-By preservado e extras excluídos.
- Manifesto de IA não seleciona modelos fora da instalação esperada.
- Serviços de IA existentes são reutilizados sem abrir modelos nem assumir sua propriedade; desativar respostas de IA mantém a voz independente.

O Qwen dos testes HTTP é controlado: a frase “sete vezes oito é cinquenta e seis” é uma resposta de fixture. Isso comprova a integração do protocolo e da fila, não a capacidade de raciocínio de um modelo real.

## Reprodução dos testes

Instale pytest no ambiente de desenvolvimento e indique sua cópia original de auditoria:

```bash
SNAKE_TEST_PROJECT="/caminho/da/copia/SnakeReyers" python -m pytest -q tests
```

Os testes de navegador em `tests/browser_server.py` e `tests/browser_check.mjs` registram o ambiente Cloud específico desta auditoria e exigem os caminhos de ferramentas ajustados em outro computador. O servidor de teste usa `lifespan=off` para não iniciar monitor, conteúdo externo ou sessão de LIVE.

Os avisos observados são deprecações de `audioop`, hooks `on_event` do FastAPI e alias do AnyIO. Não foram contabilizados como falhas nem alterados no código original.

## Evidências incluídas

`docs/evidence/` contém o log/XML dos testes do complemento, log da suíte original, resultado de integridade, metadados do Piper e resultado/captura do navegador. Não contém credenciais, fontes originais, executável ou modelos de IA.

## Reparo do iniciador 0.2.1

Seis testes adicionais do script passaram em Linux com comandos Android/X11 simulados:

- Falha da consulta de pacotes não bloqueia uma sessão X11 nova nem uma sessão existente.
- Comando de serviço ausente é informado como dependência, sem confundi-lo com APK ausente.
- Falha real do serviço mostra sua mensagem no terminal.
- Reparo guarda o iniciador antigo e preserva configurações existentes.
- Código de saída do painel permanece registrado.

Os dois primeiros casos pertencem ao mesmo teste parametrizado. São seis execuções no total. Os registros estão em `X11_V021_TESTS.log` e `X11_V021_TESTS.xml`. Isso comprova a lógica do iniciador; ainda não comprova o funcionamento do driver gráfico do GT3.

## Reparo do reconhecimento de versão 0.2.2

Foram testados os formatos oficiais e Termux, números com e sem patch, saída em stderr, prefixo Godot Engine, espaços e cores ANSI. A série 4.6 continua recusada. Erro de linker e timeout passam a ter mensagens próprias. O reparador foi testado com a identificação exata do celular, backup, preservação das configurações e rejeição de payload Python inválido antes da substituição.

O jogo compilado original também foi executado e renderizado com Godot 4.7 oficial. A ponte confirmou início e fim da fala Piper. Isso valida a série do motor no Linux; drivers e áudio físicos do GT3 continuam sem validação nesta máquina.

A suíte conjunta atual passou com 122 testes Python (67 originais e 55 do complemento) e três testes Node originais. O subconjunto de reconhecimento/reparo de versão passou em 17 execuções, incluindo a regressão da série 4.6. Os logs atuais são `ALL_TESTS_V022.log`, `ALL_TESTS_V022.xml`, `NODE_TESTS_V022.log` e `GODOT_V022_TESTS.*`.

## Janela X11 0.2.3

Foram repetidos os testes do iniciador e do reparo de versão, incluindo o novo reparo de janela. Os testes verificam que um serviço sem `-tag` não abre a atividade com `-d`, e que os reparos anteriores também preservam a correção. São 23 execuções aprovadas neste subconjunto, registradas em `WINDOW_V023_TESTS.*`.

A abertura da janela padrão também foi confirmada pelo usuário no GT3. O relato de lentidão corresponde ao renderer llvmpipe no log; não há medição de FPS nem confirmação de aceleração GPU.
