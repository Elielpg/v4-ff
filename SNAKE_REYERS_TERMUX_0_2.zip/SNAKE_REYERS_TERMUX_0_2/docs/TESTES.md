# Registro de testes — 24/11/2026

Ambiente: Cloud Linux x86_64, Python 3.12, Node 24 e Chromium headless. Os resultados abaixo não são benchmarks do Realme GT3.

## Atualização 0.3.2 — seleção da IA, fila e operador

**262 testes Python** passaram (**67 originais e 195 do complemento**), sem falhas; **3 testes Node** passaram. O reparador completo foi aplicado em instalação de teste, com backup, configuração preservada e módulos conferidos byte a byte. Bash e JavaScript foram verificados sintaticamente.

Casos novos: seleção Gemini preservada durante início lento do Qwen; recusa de pergunta com provedor divergente antes de fazer requisição; nomes decorados convertidos apenas na síntese e alias persistido; uma preparação adiantada sem voz simultânea; foco do espectador diferido até despacho; bloqueios de cantoria/diálogo/sequências; prioridade das perguntas recentes; limite do histórico de dedup de comentários; saudações/avisos de falha espaçados; catálogo Gemini paginado, compatibilidade de parâmetros, fallback 404, orçamento de saída, classificação de erros e preservação de cooldown real; viewerCount distinto de totalUser; dado ausente/desatualizado; FPS extraído do trecho atual do log; renderizador de software identificado.

No Chromium móvel **390×844**, foram conferidos: teste de chave bem-sucedido mantendo Qwen selecionado; botão **Usar Gemini** mudando o provedor ativo; pergunta com Gemini simulado; voz OpenAI independente com WAV válido; campos de chave limpos e valores ausentes em GET; nomes/alias e modo de fila salvos; painel do operador com viewerCount=42 distinguido de totalUser=8000; aviso explícito sobre captura da tela inteira; ausência de erros JavaScript e estouro horizontal nos cartões inspecionados. Os números do público são fixtures, não uma LIVE real.

### Ensaio A/B no jogo original

Godot 4.7 Linux, pacote original opaco, Piper e PulseAudio privado reais. Mesmas falas aquecidas em cache; geração com **atraso simulado de 0,7 s**, sem API real:

| Modo | Segunda geração durante a fala atual | Intervalo entre falas |
|---|---|---:|
| Fila anterior | Não | 1,906 s |
| Uma preparação adiantada | Sim | 0,864 s |

O jogo confirmou início/fim das duas falas em ambos. Legendas/nomes originais foram preservados; a voz recebeu Gustavo/Ana sem letras separadas. O mixer foi gravado com **3.909.872 bytes PCM** e RMS **3.785,1**, confirmando sinal nesse ambiente. Isso não confirma saída Android/Bluetooth nem a dicção da voz OpenAI selecionada pelo usuário.

O painel extraiu **7 FPS observados** e renderer **llvmpipe** nessa execução Linux por software. Esse valor confirma a coleta e a indicação de software; **não mede o GT3 nem demonstra melhoria de FPS**. Perfis 720p45/864p30 são limites opcionais configurados, não benchmarks.

Evidências: `ALL_TESTS_V032.*`, `NODE_TESTS_V032.log`, `LIVE_V032_NATIVE_AB.json`, `LIVE_V032_BROWSER.json`, `GT3_PROVIDER_SCREENSHOT_V032.json`, `live32-mobile.png`, `live32-director.png`. Os **127 arquivos originais** recebidos foram comparados por tamanho/SHA-256, sem mudanças. Não houve chamada real OpenAI/Gemini, validação de quota/voz da conta, LIVE prolongada, captura RTMP ou benchmark físico no GT3. Nenhuma transmissão foi iniciada.

## Atualização 0.3.1 — OpenAI/Gemini e voz

**224 testes Python** passaram (67 originais e 157 do complemento), sem falhas; **3 testes Node** passaram. Casos novos cobrem: ausência de chamadas ao salvar/consultar; credenciais históricas não ativam nuvem; segredos ausentes em respostas/HTML; modelo e provedor independentes; OpenAI Responses; catálogo Gemini em cache; seleção de modelo de texto; chave inválida com alternativa; cota compartilhada sem contorno por outra chave; projetos distintos; respeito ao intervalo 429; persistência de espera após reiniciar; verificação sem alegar saldo; voz com input separado de instructions; cache; PCM/WAV/timeline; tratamento de falhas; limite local; hosts fixos/sem redirects; e não iniciar Qwen/Piper quando as opções selecionadas são na nuvem.

No Chromium 390×844, as chaves fictícias foram inseridas e limpas após salvar; os estados de chave recusada e disponível apareceram; a pergunta recebeu resposta simulada Gemini; a voz OpenAI foi selecionada independentemente, o player recebeu um WAV válido; os provedores persistiram após recarga; não houve chave completa em GET, erro JS ou estouro horizontal. A inspeção do áudio do navegador foi feita pelo blob recebido no player e por uma leitura HTTP direta: o CDP retornava corpo vazio para a resposta audio/wav apesar do Content-Length correto, sem representar falha de reprodução.

No jogo original Godot 4.7 Linux, uma pergunta passou pelo fluxo Gemini simulado → resposta curta → OpenAI speech simulado → WAV/timeline → evento de fala iniciado/finalizado no ator da cobra. Música continuou habilitada no mesmo mixer PulseAudio privado, com buffer de 160 ms. O áudio de teste é PCM sintético; não é uma amostra de voz real da OpenAI. A gravação musical confirma a saída do mixer Linux, sem alegar alto-falante/Bluetooth Android.

Evidências: `ALL_TESTS_V031.*`, `NODE_TESTS_V031.log`, `CLOUD_V031_BROWSER.json`, `CLOUD_V031_NATIVE.json`, `CLOUD_V031_SOURCES.json` e `cloud31-mobile.png`. **Não foram feitas chamadas reais OpenAI/Gemini, nem consultadas contas, cotas ou créditos.** Modelos disponíveis, cobrança, timbre/pronúncia e latência reais devem ser conferidos com as chaves inseridas pelo usuário. Os arquivos originais recebidos continuam verificados por hash, sem alteração.

## Atualização 0.3.0 — concorrência e margem de áudio

**201 testes Python** passaram (67 originais e 134 do complemento), sem falhas; **3 testes Node** passaram. Os novos casos cobrem opções ONNX de inferência sequencial com duas threads e sem spinning, prioridade reduzida somente do filho FFmpeg, buffer privado de 160 ms e limites de override, opções do módulo AAudio, perfil gráfico opcional com bloqueio de aumento no fallback de CPU e payload completo do reparo.

Piper real foi medido antes/depois no mesmo host Linux. A amostra gerou WAV válido em ambos, usando 1,03/0,58 CPU-segundo; o segundo posterior à síntese usou 0,19/0 CPU-segundo. Tempo de parede: 0,250/0,325 s. Isso é uma redução de concorrência nessa amostra, não prova de menor latência nem benchmark do GT3. Os processos tinham 10/7 threads totais; duas são as threads de inferência configuradas na sessão nova.

O jogo original executou com PulseAudio privado e margem de 160 ms, reproduziu as faixas convertidas manual/automático e concluiu uma fala Piper com música ainda habilitada. PCM do mixer foi gravado. Isso não certifica áudio físico Android nem ausência de underruns no Bluetooth.

Evidências: `ALL_TESTS_V030.*`, `NODE_TESTS_V030.log`, `PIPER_V030_BEFORE.json`, `PIPER_V030_AFTER.json`, `STABILITY_V030_NATIVE.json` e `GT3_STUTTER_V030.json`. Ainda faltam os registros atuais do GT3 e o teste pausando apenas a música; não se declarou a regressão definitivamente resolvida no aparelho.

## Atualização 0.2.9 — importação e seleção musical

**195 testes Python** passaram (67 originais e 128 do complemento), sem falhas; **3 testes Node** passaram. Casos novos cobrem rejeição de falso MP3 sem interromper a reprodução, conversão de conteúdo com extensão errada, preservação do arquivo enviado, cache, seleção persistente, exclusão da trilha padrão, automático restrito ao subconjunto, próxima faixa, pausa/volume, erros de conversão e controles inválidos. A preparação em thread permite que o loop de eventos e a consulta de estado avancem durante o trabalho. O teste antigo que aceitava bytes sem áudio foi ajustado para exigir rejeição; não foi removido.

No runtime Godot 4.7 Linux com o pacote original opaco e servidor PulseAudio privado reais, foram importados AAC/M4A e WAV com nome `.mp3`. O player iniciou os OGG convertidos sem `MUSIC_LOAD_FAIL`. A faixa manual repetiu; o automático alternou entre as duas marcadas; `Neon Garden` não iniciou nesses modos. A captura PCM do mixer contém a frequência de teste de 440 Hz predominante, e não apenas um evento de início interno. Após pausar música, Piper real e a fila do jogo concluíram uma fala.

Chromium com viewport 390×844: upload de dois arquivos pelo painel, conversão, marcação de duas faixas, modo automático, recarga conservando seleção, pausa e volume persistidos, sem estouro horizontal do cartão nem erros JavaScript.

Evidências: `ALL_TESTS_V029.*`, `NODE_TESTS_V029.log`, `MUSIC_V029_NATIVE.json`, `MUSIC_V029_BROWSER.json`, `GT3_MUSIC_V029.json` e `music29-mobile.png`. Os arquivos comerciais enviados no telefone não foram recebidos nem redistribuídos. Testes de reprodução usam tons sintéticos. Não houve benchmark do GT3, saída física Android, LIVE real ou teste de faixa de uma hora. A confirmação do usuário sobre falas e conexão continua válida para a versão anterior; a nova importação ainda precisa ser aplicada no aparelho.

## Atualização 0.2.8 — ritmo da conversa

A suíte conjunta passou com **179 testes Python** (67 originais e 112 do complemento) e **3 testes Node**. Os novos casos verificam: uma resposta direta com atividade do usuário preservada; restauração do diálogo de duas falas; preferências sem perda/exposição de segredos; foto derivada menor e original intacta; perfil LIVE restrito à GPU confirmada; e presença dos novos módulos no reparador.

O A/B com o Godot compilado original e Piper real registrou:

| Modo | Jobs/falas iniciadas | Eventos de foco frontal no usuário | Fala concluída |
|---|---:|---:|---|
| Diálogo original | 2 | 1 | Sim |
| Resposta direta | 1 | 0 | Sim |

As respostas de Qwen nesse teste foram simuladas, e não foi medido ganho de latência no GT3. A câmera interna do pacote não foi reescrita. O Chromium móvel verificou salvamento dos dois modos e do perfil LIVE, sem transbordamento dos controles nem erro JavaScript.

Evidências: `ALL_TESTS_V028.*`, `NODE_TESTS_V028.log`, `LIVE_V028_NATIVE_AB.json`, `LIVE_V028_BROWSER.json` e `live28-mobile.png`.

## Atualização 0.2.7 — PulseAudio travado e imagem

Passaram **173 testes Python** (67 originais e 106 do complemento) e **3 testes Node**. Antes do ajuste, dois testes reproduziram o iniciador encerrando antes da janela quando PulseAudio falhava ou estava ausente. Há testes de exceção na preparação opcional, socket privado, timeout limitado, encerramento apenas do filho próprio, Dummy explícito diante de falha e botão de teste usando o servidor do jogo.

Nos testes integrados, um socket PulseAudio compartilhado aceitava conexões sem responder. O Godot original ligado a ele não chegou ao carregamento da arena na janela de observação de três segundos. O servidor privado da nova execução foi criado pelo código de produção; apenas a saída Android foi substituída por um sink virtual Linux para permitir gravação. O jogo conectou, a fala Piper foi gravada no monitor e teve correlação superior a 0,99 com o WAV gerado. Ao parar o jogo, o processo privado encerrou e o serviço compartilhado de teste continuou intacto.

Em outra execução foi simulada falha da saída Android. O processo privado que falhou foi encerrado, e o Godot original abriu/carregou a arena com Dummy explícito apesar do servidor compartilhado travado. A captura `render-without-audio-v027.png` registra a imagem real dessa execução. Isso confirma a proteção da abertura da imagem; não comprova som físico no Android.

Evidências: `ALL_TESTS_V027.*`, `NODE_TESTS_V027.log`, `AUDIO_V027_PRIVATE_PCM.json`, `AUDIO_V027_RENDER_FALLBACK.json`, `GT3_AUDIO_HANG_V027.json` e `AUDIO_WINDOW_V027_*`.

## Atualização 0.2.6 — falha de áudio

A suíte conjunta passou com **163 testes Python** (67 originais e 96 do complemento) e **3 testes Node**. Há cobertura da opção AAudio protegida, teste PCM anterior ao processo, saída que desaparece durante o teste, preservação de captura explícita, ordem tela → áudio → processo e detecção de Dummy apenas no trecho do log da execução atual. A fila e o driver não são reiniciados automaticamente.

Foi preparado um PulseAudio 17.0 isolado no diretório de teste, a partir de pacotes Debian com SHA-256 conferido. Um servidor indisponível reproduziu o aviso Dummy; apenas um nome de sink inexistente não o reproduziu no Linux. Essa diferença foi registrada para não atribuir uma causa não comprovada ao aparelho.

No teste positivo, o Godot original conectou por PulseAudio e apareceu como sink-input com seu PID. A música estava desativada. O monitor virtual foi gravado enquanto Piper real produzia e o jogo reproduzia uma frase. O sinal capturado apresentou alta correlação com o WAV Piper reamostrado. Isso verifica dados de áudio saindo do jogo para o mixer; não representa escuta no alto-falante Android. A opção `no_close_hack` foi conferida no código público do módulo oficial Termux, mas seu efeito físico no GT3 ainda precisa ser confirmado.

O teste Chromium com respostas de status simuladas verificou o aviso Dummy e a distinção entre enfileiramento e reprodução. Evidências: `ALL_TESTS_V026.*`, `NODE_TESTS_V026.log`, `AUDIO_V026_PCM.json`, `AUDIO_V026_UI.json` e `GT3_AUDIO_FAILURE_V026.json`.

## Atualização 0.2.5 — tela e trilha

A suíte atual passou com **155 testes Python** (67 originais e 88 do complemento) e **3 testes Node**. As novas verificações cobrem ocultação das teclas, correspondência de resolução, backup inicial preservado, restauração, timeout do aplicativo X11, recusa de uma tela ainda em paisagem, perfis restritos à GPU verificada, validação de configurações e trilha com integridade conferida. Uma biblioteca existente, pausa/volume e uma exclusão intencional da faixa são preservados. O reparador foi executado numa instalação de teste, incluindo criação das novas pastas, comparação dos arquivos instalados e preservação de configuração privada.

O jogo compilado original executou em tela cheia no Xvfb, em 536×960, com renderização por software e limite de 30 FPS. A resolução foi consultada pelo `xdpyinfo` real; somente o receptor de preferências Android foi simulado. O log do jogo confirmou `MUSIC_TRACK_STARTED path=Neon Garden.ogg`, além de início/fim da fala Piper real. O Chromium móvel validou seleção/salvamento de perfil, música inicial presente, upload adicional e controles sem transbordamento.

A faixa OGG decodificou como Vorbis estéreo, 32 kHz, 76,8 s, com pico de aproximadamente −3 dBFS e sem amostras NaN/Inf na análise FFmpeg. Esses dados descrevem o arquivo; não são um teste auditivo de alto-falante. O teste Cloud utilizou driver de áudio Dummy e não mediu FPS reais.

No aparelho, o usuário informou renderer Zink/Turnip Adreno e confirmou som e voz audíveis nos testes da 0.2.4. Confirmou também que faltava apenas a trilha de fundo. A tela limpa da 0.2.5 e a reprodução dessa nova faixa ainda dependem de confirmação no GT3.

Evidências: `ALL_TESTS_V025.*`, `NODE_TESTS_V025.log`, `DEVICE_V025_NATIVE_SMOKE.json`, `DEVICE_V025_BROWSER.json`, `DEVICE_V025_GAME_EVENTS.log`, `GT3_USER_FEEDBACK_V025.json` e as capturas `device25-*.png`.

| Verificação | Resultado | Limite |
|---|---|---|
| Suíte Python original 0.1.9 | 67 passaram | Executada na cópia de auditoria, sem hooks |
| Política de conexão Node original | 3 passaram | Sem conexão com TikTok real |
| Testes do complemento na revisão 0.2.2 | 55 passaram | Qwen e parte das respostas WAV simulados por HTTP loopback |
| Navegador com painel original e complemento | Passou; nenhum erro JavaScript capturado | Chromium, não Chrome Android |
| Geração com Piper real pt_BR-faber-medium | WAV PCM 22.050 Hz, 4,389 s; timeline com 16 segmentos | Modelo carregado na Cloud; não avalia timbre subjetivo ou desempenho do celular |
| Reprodução do segundo teste Piper no navegador | Áudio de 4,957 s, readyState 4, sem erro, reprodução iniciada | Não confirma o áudio dentro do jogo Godot |
| Integridade dos arquivos originais | 127 conferidos, nenhum alterado | Comparados ao manifesto SHA-256 dos arquivos recebidos |
| Executável completo | Oito partes e SHA-256 final conferidos | Original preservado |
| Jogo gráfico original | Carregou e renderizou em 720×1280; ponte original conectada | Godot 4.7.2 Linux x86_64, X11/OpenGL por software |
| Resposta → Piper → fila original → Godot | Jogo informou speech_started e speech_finished para o mesmo job | Qwen simulado, Piper real; driver Dummy, sem gravação de alto-falante |
| LIVE real, captura/RTMP e longa duração | Não realizadas | Dependem da instalação Android e conta ao vivo |

## O que os testes do complemento verificam

- Validação de portas, modelos e @; entradas que parecem comando não são usadas como comandos.
- Descoberta automática do modelo, cache do catálogo e chamada chat/completions sem Authorization.
- Bloqueio de redirecionamento para outro host.
- Respostas vazias, inválidas ou sem resposta final geram falha identificável.
- Configuração sem chave; segredo antigo preservado no arquivo privado e ausente da resposta pública.
- Perguntas e presentes usando as referências importadas pelo módulo social original.
- Saudações instantâneas preservadas; IA desabilitada não faz requisições.
- Painel original com script local injetado, endpoints de teste e resposta de erro para voz inválida.
- Texto de Piper sem trocar R/L ou grafia brasileira; contrato WAV/timeline preservado.
- Caminho pergunta → resposta social original → preparação do job na fila original → áudio e timeline.
- WAV truncado rejeitado antes de aparecer como fala pronta.
- Clonador não confundido com Piper; XTTS original continua selecionável.
- Tentativa de instalar atualização de desktop interrompida nesta adaptação.
- Versão de Godot inadequada e arquivo original incompleto rejeitados.
- Argumentos do motor, modo original e seleção da tela preservados/adaptados.
- Ciclo de vida do processo próprio, sem lançamento duplicado ou reinício em ciclo.
- Cópia interna sem sobrescrever configuração existente; seleção de fontes APT com Signed-By preservado e extras excluídos.
- Manifesto de IA não seleciona modelos fora da instalação esperada.
- Serviços de IA existentes são reutilizados sem abrir modelos nem assumir sua propriedade; desativar respostas de IA mantém a voz independente.

O Qwen dos testes HTTP é controlado: a frase “sete vezes oito é cinquenta e seis” é uma resposta de fixture. Isso comprova a integração do protocolo e da fila, não a capacidade de raciocínio de um modelo real.

## Reprodução dos testes

Instale pytest no ambiente de desenvolvimento e indique sua cópia original de auditoria:

```bash
SNAKE_TEST_PROJECT="/caminho/da/copia/SnakeReyers" python -m pytest -q tests
```

Os testes de navegador em `tests/browser_server.py` e `tests/browser_check.mjs` registram o ambiente Cloud específico desta auditoria e exigem os caminhos de ferramentas ajustados em outro computador. O servidor de teste usa `lifespan=off` para não iniciar monitor, conteúdo externo ou sessão de LIVE.

Os avisos observados são deprecações de `audioop`, hooks `on_event` do FastAPI e alias do AnyIO. Não foram contabilizados como falhas nem alterados no código original.

## Evidências incluídas

`docs/evidence/` contém o log/XML dos testes do complemento, log da suíte original, resultado de integridade, metadados do Piper e resultado/captura do navegador. Não contém credenciais, fontes originais, executável ou modelos de IA.

## Reparo do iniciador 0.2.1

Seis testes adicionais do script passaram em Linux com comandos Android/X11 simulados:

- Falha da consulta de pacotes não bloqueia uma sessão X11 nova nem uma sessão existente.
- Comando de serviço ausente é informado como dependência, sem confundi-lo com APK ausente.
- Falha real do serviço mostra sua mensagem no terminal.
- Reparo guarda o iniciador antigo e preserva configurações existentes.
- Código de saída do painel permanece registrado.

Os dois primeiros casos pertencem ao mesmo teste parametrizado. São seis execuções no total. Os registros estão em `X11_V021_TESTS.log` e `X11_V021_TESTS.xml`. Isso comprova a lógica do iniciador; ainda não comprova o funcionamento do driver gráfico do GT3.

## Reparo do reconhecimento de versão 0.2.2

Foram testados os formatos oficiais e Termux, números com e sem patch, saída em stderr, prefixo Godot Engine, espaços e cores ANSI. A série 4.6 continua recusada. Erro de linker e timeout passam a ter mensagens próprias. O reparador foi testado com a identificação exata do celular, backup, preservação das configurações e rejeição de payload Python inválido antes da substituição.

O jogo compilado original também foi executado e renderizado com Godot 4.7 oficial. A ponte confirmou início e fim da fala Piper. Isso valida a série do motor no Linux; drivers e áudio físicos do GT3 continuam sem validação nesta máquina.

A suíte conjunta atual passou com 122 testes Python (67 originais e 55 do complemento) e três testes Node originais. O subconjunto de reconhecimento/reparo de versão passou em 17 execuções, incluindo a regressão da série 4.6. Os logs atuais são `ALL_TESTS_V022.log`, `ALL_TESTS_V022.xml`, `NODE_TESTS_V022.log` e `GODOT_V022_TESTS.*`.

## Janela X11 0.2.3

Foram repetidos os testes do iniciador e do reparo de versão, incluindo o novo reparo de janela. Os testes verificam que um serviço sem `-tag` não abre a atividade com `-d`, e que os reparos anteriores também preservam a correção. São 23 execuções aprovadas neste subconjunto, registradas em `WINDOW_V023_TESTS.*`.

A abertura da janela padrão também foi confirmada pelo usuário no GT3. O relato de lentidão corresponde ao renderer llvmpipe no log; não há medição de FPS nem confirmação de aceleração GPU.

## Perfil GPU/áudio 0.2.4

Os novos testes cobrem: renderer real exigido para confirmar GPU; rejeição de Zink sobre llvmpipe/lavapipe; ICD ausente e timeout contidos; fallback de resolução/FPS/threads; auto_null seguido de módulo Android; reutilização de saída existente; falha de ambos os módulos sem falso sucesso; pacotes com status vazio; sinal PCM curto; upload sem escapar da pasta nem sobrescrever músicas; limite de tamanho; argumentos e saída real chegando ao processo; backup/preservação no reparo.

O teste integrado com o Godot original e Piper real repetiu fila e reprodução, conferiu os novos botões no Chromium móvel, adicionou um WAV local e confirmou a presença da faixa no runtime original. O perfil de CPU foi executado com 540×960 e limite de 30 FPS. A saída física foi simulada/Dummy e a GPU Adreno não está disponível na Cloud. Nenhum FPS real ou ganho de desempenho no GT3 foi inventado.

As evidências atuais estão em `ALL_TESTS_V024.*`, `DEVICE_V024_TESTS.*`, `DEVICE_V024_NATIVE_SMOKE.json`, `DEVICE_V024_BROWSER.json` e `device24-panel-mobile.png`.

A suíte final 0.2.4 passou com 142 testes Python (67 originais e 75 do complemento) e três testes Node originais. Também foi verificado que uma saída virtual nomeada explicitamente pelo plano de captura RTMP original é preservada, sem confundi-la com o fallback silencioso auto_null.
