# Ben 10 · Clareira LIVE · V38

**V38:** Gemini sem pular perguntas de identidade, várias chaves com seleção manual, voz grátis do aparelho, gestos durante as respostas, expressões, acenos, postura sentada e passeios ocasionais. Mantém os ícones, ranking, painel do chat e Omnitrix original da V37.

Uma clareira inspirada no acampamento do clássico, controlada por chat e presentes. Sem cidade ou missões: movimento livre em dois eixos, onze formas com três poderes cada e um Omnitrix com seleção, transformação, tempo restante e recarga verde/vermelha.

```sh
bash install.sh
bash start.sh
```

Abra no Chrome do mesmo aparelho o endereço indicado e toque em **♫ Ativar som**. Confira **38.0.0**. [Voz, chaves e movimentos da V38](docs/V38_VOZ_E_MOVIMENTOS.md).

Se instalou a versão anterior em `~/ben10-v34/game`, atualize preservando dados:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V38_TERMUX.zip --start
```

Comandos: `andar esquerda`, `correr direita`, `frente`, `trás`, `pular`, `girar`, `parar`, nome de um alien, `voar`, `pousar`, `dash` com XLR8 e `poder 1/2/3`. Também: `sentar`, `levantar`, `sorrir`, `acenar` e `comemorar`. O painel de comandos mantém o padrão anterior. Perguntas continuam na conversa.

## Desenvolvimento

Node >=22.19, npm e Python 3. Use o checkout existente; cada tarefa cloud já é isolada.

- `npm ci`: dependências fixadas no lockfile.
- `npm test`: testes de domínio, HTTP/SSE, relógio, filas, modelos e atualizador.
- `npm run lint`: sintaxe JavaScript.
- `npm run build`: assets e licenças Babylon locais, sem CDN.
- `npm run package`: verificações e ZIP, sem `data/`, `.env` pessoal ou `node_modules`.
- `node scripts/v38-browser-check.js`: integração no Chromium local com servidor já iniciado na porta 3004. Defina `GAME_TEST_URL` se usar outra porta.
- `node scripts/v36-clock-check.js`: ciclo real do Omnitrix no navegador.
- `node scripts/archive-smoke.js ../BEN10_LIVE_V38_TERMUX.zip`: extrai e inicia o pacote usando as dependências locais do mesmo lockfile.

Código AGPL-3.0 e fontes correspondentes do conector incluídos. Nove GLBs de terceiros e seus créditos/licenças permanecem no pacote; Quatro Braços, Alien X e Cipó Selvagem usam novas formas procedurais por padrão. [Créditos](docs/MODEL_CREDITS.md), `third_party/NOTICE.md`. Projeto de fã, sem afiliação oficial. Efeitos e vozes não são os arquivos/gravações oficiais.

A conversa livre exige uma chave Gemini com acesso e cota. A voz grátis usa Web Speech e as vozes em português do aparelho, com tom/ritmo ajustáveis; não usa chave TTS. Leia o guia V38 para ativar a opção após atualizar uma instalação antiga. Vozes externas e LIVE dependem de credenciais/acesso no aparelho. A validação cloud usa eventos simulados e não substitui teste em Android físico.
