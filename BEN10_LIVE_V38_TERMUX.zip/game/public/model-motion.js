import {gaitCycle} from './pedestrian-motion.js';
// Model coordinates are calibrated before scale/grounding; original GLBs stay untouched.
export const MOTION_PROFILES={
 nova:{rotation:[0,0,0],height:2.6,armAngle:-1.45,shoulder:.69,hip:.43,width:.13,float:true},
 wildvine:{rotation:[0,0,0],height:2.6,armAngle:-1.45,shoulder:.69,hip:.43,width:.13},
 base:{rotation:[0,Math.PI,0],height:2.6,armAngle:-.55,shoulder:.77,hip:.46,width:.12},
 blaze:{rotation:[0,Math.PI,0],height:2.65,armAngle:0,shoulder:.74,hip:.45,width:.14},
 volt:{skating:true,rotation:[0,Math.PI,0],height:2.45,armAngle:0,shoulder:.70,hip:.43,width:.13},
 rock:{rotation:[0,Math.PI,0],height:2.8,armAngle:-1.05,shoulder:.70,hip:.43,width:.16},
 shade:{rotation:[0,Math.PI/2+.27,0],height:2.6,armAngle:0,shoulder:.66,hip:.40,width:.13,tail:true,float:true},
 tide:{rotation:[0,Math.PI,0],height:2.55,armAngle:-1.12,shoulder:.68,hip:.40,width:.16,tail:true},
 beast:{rotation:[0,Math.PI,0],height:1.8,armAngle:0,targetArm:-.72,shoulder:.68,hip:.44,width:.18,quadruped:true},
 fourarms:{rotation:[Math.PI/2,Math.PI,0],height:2.9,armAngle:0,shoulder:.78,hip:.43,width:.18,four:true,skinSmoothing:2,armInfluence:1},
 cannon:{rotation:[0,Math.PI,0],height:2.1,armAngle:-.70,shoulder:.68,hip:.28,width:.26}
};
export const smooth=(a,b,x)=>{const t=Math.min(1,Math.max(0,(x-a)/(b-a)));return t*t*(3-2*t);};
export function dimensionsAfterRotation(points,rotation){const B=globalThis.BABYLON,m=B.Matrix.RotationYawPitchRoll(rotation[1],rotation[0],rotation[2]),min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<points.length;i+=3){const p=B.Vector3.TransformCoordinates(new B.Vector3(points[i],points[i+1],points[i+2]),m);for(const [j,v] of [p.x,p.y,p.z].entries()){min[j]=Math.min(min[j],v);max[j]=Math.max(max[j],v);}}return {min,max};}
function rotateX(p,a){const c=Math.cos(a),s=Math.sin(a);return [p[0],p[1]*c-p[2]*s,p[1]*s+p[2]*c];}
export function animationPose(phase,state='walk',profile={}){
 const seated=state==='sit',dashing=state==='dash'&&profile.skating,running=['run','dash'].includes(state),walk=state==='walk'||running,fly=state==='fly',talk=state==='talk',power=['power','charge','cast','impact','recover'].includes(state),gait=gaitCycle(phase*(running?1.35:1),{running,quadruped:profile.quadruped,skating:profile.skating&&running}),left=gait.left,right=gait.right;
 return {stride:walk?left.hip:fly?Math.sin(phase*.7)*.12:0,strideL:seated?1.48:dashing?-.38+Math.sin(phase*.3)*.035:walk?left.hip:fly?.10:0,strideR:seated?1.48:dashing?-.38-Math.sin(phase*.3)*.035:walk?right.hip:fly?-.10:0,kneeL:seated?1.48:dashing?.82:walk?left.knee:fly?.32:.04,kneeR:seated?1.48:dashing?.82:walk?right.knee:fly?.42:.04,ankleL:seated?0:dashing?1.2:walk?left.ankle:0,ankleR:seated?0:dashing?1.2:walk?right.ankle:0,stanceL:walk&&left.stance,stanceR:walk&&right.stance,armSwing:walk?-(left.hip-right.hip)*.36:talk?Math.sin(phase*1.6)*.12:0,elbow:state==='charge'?1.1:state==='impact'?.48:power?.22:running?.65:talk?.48+Math.sin(phase)*.13:state==='wave'?.38+Math.sin(phase*3)*.16:state==='cheer'?.10:.16,head:talk?Math.sin(phase*.65)*.06:Math.sin(phase*.3)*.018,breath:Math.sin(phase*.6)*.012,tail:Math.sin(phase*1.4)*(running?.32:walk?.20:.10),hover:(profile.float?.10+Math.sin(phase)*.06:0)+(state==='jump'?Math.max(0,Math.sin(phase*1.4))*.55:0),lean:dashing?.43:running?(profile.skating?.34:profile.quadruped?.12:.18):fly?.12:state==='charge'?-.08:state==='impact'?.12:0,pelvisY:walk?gait.pelvisY:0,hipYaw:state==='spin'?Math.sin(phase*.9)*.55:walk?gait.hipYaw:0,hipRoll:walk?gait.hipRoll:0,shoulderYaw:walk?gait.shoulderYaw:0,power,fly,running,dashing,wave:state==='wave',cheer:state==='cheer',gestureSwing:Math.sin(phase*3)};
}
export function actionChoreography(form,state,pair=0,variant=0){
 if(!['charge','cast','impact','recover','power'].includes(state)||state==='recover')return null;
 if(form==='fourarms'){
  if(variant===1)return state==='charge'?{upper:[.42,-.62,.18],lower:[.18,-.22,-.35],lean:-.08,knee:.12}:state==='cast'?{upper:[.36,-.28,-1],lower:[.14,-.12,-1],lean:.32,knee:.26}:{upper:[.38,-.3,-.94],lower:[.14,-.15,-.94],lean:.2,knee:.18};
  if(variant===2)return state==='charge'?{upper:[.72,.35,-.28],lower:[.5,.28,-.48],lean:-.1,knee:.16}:state==='cast'?{upper:[.62,.12,-.95],lower:[.42,.1,-.85],lean:.26,knee:.22}:{upper:[.6,.15,-.9],lower:[.4,.1,-.82],lean:.16,knee:.14};
  return state==='charge'?{upper:[.55,pair?.3:.75,.12],lower:[.25,.7,-.15],lean:-.12,knee:.20}:state==='cast'?{upper:[.40,-1,-.25],lower:[.20,-1,-.10],lean:.45,knee:.62}:{upper:[.45,-1,-.15],lower:[.20,-1,-.08],lean:.40,knee:.52};
 }
 if(form==='rock'){
  if(variant===1)return state==='charge'?{upper:[.62,-.62,-.08],lower:[.3,-.12,-.3],lean:-.08,knee:.14}:{upper:[.48,-.08,-.92],lower:[.22,.42,-.84],lean:.2,knee:.14};
  if(variant===2)return state==='charge'?{upper:[.55,.4,-.35],lower:[.3,.3,-.5],lean:0,knee:.1}:{upper:[.55,.34,-.64],lower:[.24,.2,-.64],lean:.02,knee:.08};
  return state==='charge'?{upper:[.45,-.7,-.25],lower:[.22,-.2,-.65],lean:.06,knee:.12}:state==='cast'?{upper:[.6,.1,-.75],lower:[.35,.7,-.5],lean:-.04,knee:.10}:{upper:[.8,-.1,-.6],lower:[.4,.15,-.65],lean:.02,knee:.08};
 }
 if(form==='volt')return {upper:[.22,-.48,.85],lower:[.1,-.2,.9],lean:.42,knee:.48};
 if(form==='beast')return {upper:[.75,-.8,-.25],lower:[.75,-1,-.15],lean:.25,knee:.45,head:.22};
 if(form==='shade')return {upper:[.95,-.1,-.4],lower:[.8,-.3,-.5],lean:state==='charge'?-.12:.08,knee:.18};
 if(form==='wildvine')return state==='charge'?{upper:[.6,-.6,-.3],lower:[.4,-.4,-.6],lean:-.06,knee:.12}:{upper:[.9,-.1,-.6],lower:[.8,-.1,-.85],lean:.1,knee:.15};
 if(form==='nova')return {upper:[.9,.25,-.4],lower:[.65,.7,-.2],lean:-.05,knee:.08};
 if(form==='cannon')return {upper:[.4,-.5,-.6],lower:[.2,-.3,-.8],lean:.32,knee:.6};
 if(form==='base')return {upper:[.45,-.45,-.55],lower:[.1,-.25,-.9],lean:0,knee:.07};
 if(form==='blaze'){
  if(variant===2)return state==='charge'?{upper:[.6,.2,-.4],lower:[.35,.2,-.55],lean:-.12,knee:.12}:{upper:[.78,.15,-.72],lower:[.4,.1,-.62],lean:.18,knee:.12};
  return state==='charge'?{upper:[.55,-.65,-.25],lower:[.25,-.1,-.65],lean:-.05,knee:.08}:{upper:[.34,-.06,-1],lower:[.18,.01,-1],lean:.12,knee:.08};
 }
 if(form==='tide')return variant===1&&state!=='charge'?{upper:[.48,.1,-.9],lower:[.24,.1,-.82],lean:.18,knee:.14}:state==='charge'?{upper:[.55,-.65,-.25],lower:[.25,-.1,-.65],lean:-.05,knee:.08}:{upper:[.34,-.06,-1],lower:[.18,.01,-1],lean:.12,knee:.08};
 return null;
}
export function createMotionRig(meshes,wrapper,form,scene,profileOverride={}){
 const B=globalThis.BABYLON;if(!MOTION_PROFILES[form])return null;const profile={...MOTION_PROFILES[form],...profileOverride};
 // Capture the rendered bind pose, including skin matrices, per mesh. No guessed scale is reused.
 for(const skeleton of new Set(meshes.map(m=>m.skeleton).filter(Boolean)))skeleton.prepare();
 const semantic=bone=>{if(!bone)return 'torso';const n=bone.name,side=/ L |Left/.test(n)?'L':/ R |Right/.test(n)?'R':null;if(side){if(/UpperArm/.test(n))return 'arm'+side+'0';if(/Forearm|LowerArm/.test(n))return 'elbow'+side+'0';if(/Hand|Finger|Thumb|Index|Middle|Pinkie/.test(n))return 'hand'+side+'0';if(/Thigh|UpperLeg/.test(n))return 'leg'+side;if(/Calf|LowerLeg/.test(n))return 'knee'+side;if(/Foot|Toe/.test(n))return 'foot'+side;}if(/Head|Neck|Ponytail/.test(n))return 'head';return bone.getParent()?semantic(bone.getParent()):'torso';};
 const authored=form==='base'||form==='beast',jointWorld={};if(authored)for(const sourceSkeleton of new Set(meshes.map(m=>m.skeleton).filter(Boolean)))for(const bone of sourceSkeleton.bones){const node=bone.getTransformNode(),id=semantic(bone);if(!node||jointWorld[id]||(id==='torso'&&!/Pelvis|Hips/.test(bone.name)))continue;node.computeWorldMatrix(true);jointWorld[id]=node.getAbsolutePosition().clone();}
 const rotation=B.Matrix.RotationYawPitchRoll(profile.rotation[1],profile.rotation[0],profile.rotation[2]),data=[];const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
 for(const mesh of meshes){if(!mesh.getTotalVertices()||!mesh.getVerticesData(B.VertexBuffer.PositionKind))continue;mesh.computeWorldMatrix(true);const positions=mesh.getPositionData(true,true),normals=mesh.getNormalsData(true,true);const world=mesh.getWorldMatrix().clone(),matrix=world.multiply(rotation),normalMatrix=B.Matrix.Transpose(B.Matrix.Invert(matrix));const out=new Float32Array(positions.length),outNormals=new Float32Array(positions.length);
  for(let i=0;i<positions.length;i+=3){const p=B.Vector3.TransformCoordinates(new B.Vector3(positions[i],positions[i+1],positions[i+2]),matrix);out[i]=p.x;out[i+1]=p.y;out[i+2]=p.z;for(const [j,v] of [p.x,p.y,p.z].entries()){min[j]=Math.min(min[j],v);max[j]=Math.max(max[j],v);}const n=normals?B.Vector3.TransformNormal(new B.Vector3(normals[i],normals[i+1],normals[i+2]),normalMatrix).normalize():new B.Vector3(0,1,0);outNormals.set([n.x,n.y,n.z],i);}
  data.push({source:mesh,positions:out,normals:outNormals,flipped:matrix.determinant()<0,authorIndices:authored?mesh.getVerticesData(B.VertexBuffer.MatricesIndicesKind):null,authorWeights:authored?mesh.getVerticesData(B.VertexBuffer.MatricesWeightsKind):null,authorNames:authored?mesh.skeleton?.bones.map(semantic):null});
 }
 if(!data.length||max[1]-min[1]<.00001)throw Error('Modelo sem geometria válida para articulação');
 const scale=profile.height/(max[1]-min[1]),center=[(min[0]+max[0])/2,min[1],(min[2]+max[2])/2];let maxX=0,maxZ=0;
 for(const d of data)for(let i=0;i<d.positions.length;i+=3){for(let j=0;j<3;j++)d.positions[i+j]=(d.positions[i+j]-center[j])*scale;maxX=Math.max(maxX,Math.abs(d.positions[i]));maxZ=Math.max(maxZ,Math.abs(d.positions[i+2]));}
 const authoredPositions={};for(const [id,position] of Object.entries(jointWorld)){const p=B.Vector3.TransformCoordinates(position,rotation);authoredPositions[id]=[p.x,p.y,p.z].map((v,i)=>(v-center[i])*scale);}
 const skeleton=new B.Skeleton('motion-'+form,'motion-'+form,scene),bones={},origins={},add=(name,pos,parent)=>{pos=authoredPositions[name]||pos;const origin=parent?origins[parent]:[0,0,0];const bone=new B.Bone(name,skeleton,parent?bones[parent]:null,B.Matrix.Translation(...pos.map((v,i)=>v-origin[i])));bones[name]=bone;origins[name]=pos;return bone;},H=profile.height;
 add('root',[0,0,0]);add('torso',[0,H*profile.hip,0],'root');add('head',[0,H*.83,0],'torso');
 const shoulderX=H*profile.width,shoulderY=H*profile.shoulder;
  const armLength=Math.min(H*.52,Math.abs(profile.armAngle)<.65?Math.max(H*.30,(maxX-shoulderX)/Math.max(.5,Math.cos(profile.armAngle))):H*.43);
 const arms=[];
 for(const side of [-1,1])for(let pair=0;pair<(profile.four?2:1);pair++){const angle=profile.armAngle-(pair?(profile.pairArmOffset??.55):0),length=armLength*(pair?.84:1);const suffix=(side<0?'L':'R')+pair,shoulder=[side*shoulderX,shoulderY-pair*H*(profile.four?.14:.18),0],elbow=[shoulder[0]+side*length*.51*Math.cos(angle),shoulder[1]+length*.51*Math.sin(angle),0],wrist=[shoulder[0]+side*length*Math.cos(angle),shoulder[1]+length*Math.sin(angle),0];add('arm'+suffix,shoulder,'torso');add('elbow'+suffix,elbow,'arm'+suffix);add('hand'+suffix,wrist,'elbow'+suffix);arms.push({side:Math.sign(origins['arm'+suffix][0])||side,pair,suffix,angle,shoulder:origins['arm'+suffix],elbow:origins['elbow'+suffix],wrist:origins['hand'+suffix]});}
 for(const side of [-1,1]){const suffix=side<0?'L':'R',x=side*H*(profile.quadruped?.17:.09);add('leg'+suffix,[x,H*profile.hip,0],'root');add('knee'+suffix,[x,H*profile.hip*.50,0],'leg'+suffix);add('foot'+suffix,[x,H*.055,-H*.035],'knee'+suffix);}
 add('tail',[0,H*profile.hip,0],'root');add('tailTip',[0,H*.18,0],'tail');
 const boneIndex=name=>skeleton.bones.indexOf(bones[name]);
 const segmentDistance=(x,y,z,a,b)=>{const vx=b[0]-a[0],vy=b[1]-a[1],vz=b[2]-a[2],t=Math.max(0,Math.min(1,((x-a[0])*vx+(y-a[1])*vy+(z-a[2])*vz)/(vx*vx+vy*vy+vz*vz)));return (x-a[0]-t*vx)**2+(y-a[1]-t*vy)**2+(z-a[2]-t*vz)**2;};
 function classify(x,y,z){const headWeight=smooth(H*.78,H*.88,y)*(1-smooth(H*.14,H*.26,Math.abs(x)));const lower=1-smooth(H*(profile.hip-.06),H*(profile.hip+.08),y);let body;
  if(lower>.001){if(profile.tail){const tip=1-smooth(H*.15,H*.34,y);body=[['tail',(1-tip)*lower],['tailTip',tip*lower],['torso',1-lower]];}else{const side=x<0?'L':'R',knee=1-smooth(H*profile.hip*.42,H*profile.hip*.61,y),foot=1-smooth(H*.07,H*.15,y);body=[['leg'+side,(1-knee)*lower],['knee'+side,knee*(1-foot)*lower],['foot'+side,knee*foot*lower],['torso',1-lower]];}}
  else body=[['head',headWeight],['torso',1-headWeight]];
  let arm,nearest=Infinity;for(const a of arms){if(a.side*x<0)continue;const distance=segmentDistance(x,y,z,a.shoulder,a.wrist);if(distance<nearest){nearest=distance;arm=a;}}
  const bodyDistance=segmentDistance(x,y,z,[0,H*profile.hip,0],[0,H*.84,0]);let legDistance=Infinity;for(const side of [-1,1])legDistance=Math.min(legDistance,segmentDistance(x,y,z,origins['leg'+(side<0?'L':'R')],origins['foot'+(side<0?'L':'R')]));
   const other=Math.min(bodyDistance,legDistance),relative=Math.sqrt(nearest/(other+H*H*.00001));const mask=smooth(shoulderX*.82,shoulderX*1.16,Math.abs(x))*(1-smooth(.54,1.08,relative))*(1-smooth(shoulderY+H*.18,shoulderY+H*.35,y))*(profile.armInfluence??1);
  if(!arm||mask<.00001)return body;
  const vx=arm.wrist[0]-arm.shoulder[0],vy=arm.wrist[1]-arm.shoulder[1],t=((x-arm.shoulder[0])*vx+(y-arm.shoulder[1])*vy)/(vx*vx+vy*vy),elbow=smooth(.38,.62,t);return [['arm'+arm.suffix,(1-elbow)*mask],['elbow'+arm.suffix,elbow*mask],...body.map(([name,w])=>[name,w*(1-mask)])];
 }

 const root=new B.TransformNode('articulated-'+form,scene);root.parent=wrapper;const result=[];
 for(const d of data){const source=d.source,mesh=source.clone(source.name+'-articulated',root,true);mesh.makeGeometryUnique();mesh.skeleton=null;mesh.morphTargetManager=null;if(mesh.material&&'metallic'in mesh.material){mesh.material.metallic=0;mesh.material.roughness=Math.max(.65,mesh.material.roughness||0);}mesh.position.setAll(0);mesh.rotation.setAll(0);mesh.rotationQuaternion=B.Quaternion.Identity();mesh.scaling.setAll(1);mesh.setEnabled(true);mesh.isVisible=true;
  mesh.setVerticesData(B.VertexBuffer.PositionKind,d.positions,true);mesh.setVerticesData(B.VertexBuffer.NormalKind,d.normals,true);const indices=source.getIndices()?.slice();if(indices&&d.flipped)for(let i=0;i<indices.length;i+=3)[indices[i+1],indices[i+2]]=[indices[i+2],indices[i+1]];if(indices)mesh.setIndices(indices);mesh.overrideMaterialSideOrientation=B.Material.CounterClockWiseSideOrientation;
  const weights=new Float32Array(d.positions.length/3*4),joints=new Float32Array(weights.length);for(let i=0;i<d.positions.length;i+=3){const mapped=new Map();if(d.authorNames&&d.authorIndices&&d.authorWeights)for(let c=0;c<4;c++){const id=d.authorNames[d.authorIndices[i/3*4+c]]||'torso',weight=d.authorWeights[i/3*4+c];mapped.set(id,(mapped.get(id)||0)+weight);}
   const list=(d.source.metadata?.skinJoint&&bones[d.source.metadata.skinJoint]?[[d.source.metadata.skinJoint,1]]:mapped.size?[...mapped]:classify(d.positions[i],d.positions[i+1],d.positions[i+2])).filter(([,w])=>w>.000001).sort((a,b)=>b[1]-a[1]).slice(0,4);const sum=list.reduce((v,[,w])=>v+w,0);list.forEach(([bone,w],k)=>{const offset=i/3*4+k;weights[offset]=w/sum;joints[offset]=boneIndex(bone);});}
   if(!d.authorNames&&!d.source.metadata?.skinJoint)smoothSkin(d.positions,indices,joints,weights,skeleton.bones.length,profile.skinSmoothing??2,H);
  mesh.setVerticesData(B.VertexBuffer.MatricesIndicesKind,joints,false);mesh.setVerticesData(B.VertexBuffer.MatricesWeightsKind,weights,false);mesh.skeleton=skeleton;mesh.numBoneInfluencers=4;mesh.isPickable=false;mesh.refreshBoundingInfo();source.setEnabled(false);result.push(mesh);
 }
 skeleton.prepare();const bounds={width:maxX*2,height:H,depth:maxZ*2};let time=0,lastDistance=null;
 const align=(a,b)=>{const from=a.normalize(),to=b.normalize(),dot=Math.max(-1,Math.min(1,B.Vector3.Dot(from,to)));if(dot>.999999)return B.Quaternion.Identity();let axis=B.Vector3.Cross(from,to);if(axis.length()<.00001)axis=B.Vector3.Cross(from,B.Axis.X);if(axis.length()<.00001)axis=B.Axis.Z.clone();return B.Quaternion.RotationAxis(axis.normalize(),Math.acos(dot));};
 const supportPoints=[];for(const mesh of result){const p=mesh.getVerticesData(B.VertexBuffer.PositionKind),j=mesh.getVerticesData(B.VertexBuffer.MatricesIndicesKind),w=mesh.getVerticesData(B.VertexBuffer.MatricesWeightsKind);for(let i=0;i<p.length;i+=3)if(p[i+1]<H*.15)supportPoints.push({p:[p[i],p[i+1],p[i+2]],j:Array.from(j.slice(i/3*4,i/3*4+4)),w:Array.from(w.slice(i/3*4,i/3*4+4))});}const supports=[];for(const side of [-1,1])supports.push(...supportPoints.filter(s=>s.p[0]*side>=0).sort((a,b)=>a.p[1]-b.p[1]).slice(0,128));
 function update(dt,state='walk',options={}){
   time+=dt;const gesture=['wave','cheer','jump','spin'].includes(state),moving=['walk','run','dash'].includes(state),phase=moving&&Number.isFinite(options.distance)?options.distance/(state==='run'||state==='dash'?2.7:1.45)*Math.PI*2:time*(gesture?5:2.2),pose=animationPose(phase,state,profile),variant=Math.abs(Math.floor(Number(options.variant)||0))%3,action=actionChoreography(form,state,0,variant);
  const expressive=!['charge','cast','impact','recover','power','select','transform','fly','dash'].includes(state),gestureKind=expressive?(options.gesture||(['wave','cheer'].includes(state)?state:options.talking?'explain':null)):null;pose.wave=gestureKind==='wave';pose.cheer=gestureKind==='cheer';pose.gestureSwing=Math.sin(time*9);const explain=gestureKind==='explain',shrug=gestureKind==='shrug',nod=gestureKind==='nod';
  const blend=dt>0?1-Math.exp(-Math.min(.12,dt)*9):1,orient=(id,target)=>bones[id].setRotationQuaternion(dt>0?B.Quaternion.Slerp(bones[id].getRotationQuaternion(),target,blend):target);
  orient('root',B.Quaternion.FromEulerAngles(0,pose.hipYaw,pose.hipRoll));orient('torso',B.Quaternion.FromEulerAngles(pose.breath+(action?.lean||pose.lean),pose.shoulderYaw,pose.breath*.3));orient('head',B.Quaternion.FromEulerAngles(nod?Math.sin(time*7)*.10:state==='talk'||options.talking?Math.sin(time*3.2)*.035:action?.head||0,pose.head+(explain?Math.sin(time*2)*.035:0),shrug?.07:0));
  for(const a of arms){
    const swing=pose.armSwing*a.side*(a.pair?-1:1),restUpper=new B.Vector3(...a.elbow.map((v,i)=>v-a.shoulder[i])),restLower=new B.Vector3(...a.wrist.map((v,i)=>v-a.elbow[i])),specific=actionChoreography(form,state,a.pair,variant),spread=profile.quadruped?.5:profile.four?(a.pair?.8:.6):.2;
   const selecting=state==='select'||state==='transform';const targetUpper=selecting?new B.Vector3(a.side<0?-.35:.3,a.side<0?-.05:-.35,-.65):specific?new B.Vector3(specific.upper[0]*a.side,specific.upper[1],specific.upper[2]):pose.wave&&a.side>0?new B.Vector3(.7,.45,-.1):pose.cheer?new B.Vector3(a.side*.75,.65,.28):shrug?new B.Vector3(a.side*.8,-.4,-.05):explain?new B.Vector3(a.side*.35,-.85,-.22):state==='sit'?new B.Vector3(a.side*.18,-.65,-.5):new B.Vector3(a.side*(pose.power?.55:pose.fly?.8:spread),state==='charge'?-.35:pose.power?-.12:pose.fly?-.5:-1,state==='charge'?-.35:pose.power?-1:pose.fly?-.3:pose.dashing?.65:swing);
   const upper=align(restUpper,targetUpper);orient('arm'+a.suffix,upper);
   const wantedLower=selecting?new B.Vector3(a.side<0?-.05:-.25,a.side<0?.25:.45,-.65):specific?new B.Vector3(specific.lower[0]*a.side,specific.lower[1],specific.lower[2]):pose.wave&&a.side>0?new B.Vector3(.25+pose.gestureSwing*.2,.85,-.18):pose.cheer?new B.Vector3(a.side*.15,.15,-.55):shrug?new B.Vector3(a.side*.5,.2,-.65):explain?new B.Vector3(a.side*.4,-.12+Math.sin(time*4+a.side)*.13,-.7):state==='sit'?new B.Vector3(a.side*.1,-.2,-.6):new B.Vector3(a.side*(pose.power?.25:pose.fly?.55:spread),state==='charge'?-.5:pose.power?0:pose.fly?-.45:-1,state==='charge'?-.15:pose.power?-1:pose.fly?-.3:pose.dashing?.85:swing-pose.elbow),inverse=new B.Matrix();upper.conjugate().toRotationMatrix(inverse);orient('elbow'+a.suffix,align(restLower,B.Vector3.TransformNormal(wantedLower,inverse)));orient('hand'+a.suffix,B.Quaternion.Identity());
  }
  for(const side of [-1,1]){const suffix=side<0?'L':'R',stride=(side<0?pose.strideL:pose.strideR)+(action?.knee?-.12:0),knee=action?.knee||(side<0?pose.kneeL:pose.kneeR);orient('leg'+suffix,B.Quaternion.RotationAxis(B.Axis.X,stride));orient('knee'+suffix,B.Quaternion.RotationAxis(B.Axis.X,-knee));orient('foot'+suffix,B.Quaternion.RotationAxis(B.Axis.X,action?.knee?-stride+knee:side<0?pose.ankleL:pose.ankleR));}

  orient('tail',B.Quaternion.FromEulerAngles(0,pose.tail,pose.tail*.3));orient('tailTip',B.Quaternion.FromEulerAngles(pose.tail*.5,0,pose.tail));skeleton.computeAbsoluteTransforms(true);skeleton.prepare(true);const matrices=skeleton.getTransformMatrices(result[0]);let lowest=Infinity;for(const sample of supports){let y=0;for(let k=0;k<4;k++){const o=sample.j[k]*16;y+=sample.w[k]*(sample.p[0]*matrices[o+1]+sample.p[1]*matrices[o+5]+sample.p[2]*matrices[o+9]+matrices[o+13]);}lowest=Math.min(lowest,y);}const wantedY=(Number.isFinite(lowest)?-lowest:0)+pose.hover;root.position.y=dt>0?root.position.y+(wantedY-root.position.y)*(1-Math.exp(-Math.min(.12,dt)*16)):wantedY;
 }
 update(0,'idle');skeleton.prepare(true);let lo=Infinity,hi=-Infinity;for(const mesh of result){const p=mesh.getPositionData(true);for(let i=0;i<p.length;i+=3){lo=Math.min(lo,p[i]);hi=Math.max(hi,p[i]);}}bounds.width=Math.max(H*.5,hi-lo);return {root,meshes:result,skeleton,bones,profile,bounds,update,get time(){return time;},dispose(){skeleton.dispose();root.dispose(false,false);}};
}

function smoothSkin(positions,indices,joints,weights,boneCount,iterations,height){
 if(!indices)return;const lookup=new Map(),groups=[],map=new Uint32Array(positions.length/3),precision=10000/height;
 for(let v=0;v<map.length;v++){const key=[positions[v*3],positions[v*3+1],positions[v*3+2]].map(x=>Math.round(x*precision)).join(',');let id=lookup.get(key);if(id===undefined){id=groups.length;lookup.set(key,id);groups.push({members:[],neighbors:new Set()});}groups[id].members.push(v);map[v]=id;}
 for(let i=0;i<indices.length;i+=3)for(let e=0;e<3;e++){const a=map[indices[i+e]],b=map[indices[i+(e+1)%3]];if(a!==b){groups[a].neighbors.add(b);groups[b].neighbors.add(a);}}
 let data=new Float32Array(groups.length*boneCount),next=new Float32Array(data.length);
 groups.forEach((group,id)=>{for(const v of group.members)for(let k=0;k<4;k++)data[id*boneCount+joints[v*4+k]]+=weights[v*4+k]/group.members.length;});
 for(let pass=0;pass<iterations;pass++){for(let id=0;id<groups.length;id++){const neighbors=groups[id].neighbors,offset=id*boneCount;if(!neighbors.size){next.set(data.subarray(offset,offset+boneCount),offset);continue;}for(let b=0;b<boneCount;b++){let sum=0;for(const n of neighbors)sum+=data[n*boneCount+b];next[offset+b]=data[offset+b]*.55+sum/neighbors.size*.45;}}[data,next]=[next,data];}
 groups.forEach((group,id)=>{const sorted=Array.from({length:boneCount},(_,b)=>[b,data[id*boneCount+b]]).sort((a,b)=>b[1]-a[1]).slice(0,4),sum=sorted.reduce((s,p)=>s+p[1],0);for(const v of group.members)sorted.forEach(([b,w],k)=>{joints[v*4+k]=b;weights[v*4+k]=w/sum;});});
}
