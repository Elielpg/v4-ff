export const BUILD_ID='38.0.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 38.0.0';
