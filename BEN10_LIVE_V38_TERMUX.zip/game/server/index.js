import {answerComment} from './conversation.js';
import {BUILD_ID,BUILD_LABEL} from '../public/release.js';

import {SPEAKERS,speakerId} from '../public/characters.js';
import {elevenlabs,elevenVoices} from './voice.js';
import {ArenaSession} from './arena-session.js';
import {GiftActionQueue} from './gift-actions.js';
import {normalizeGiftRules,normalizeCommandRules,mergeGiftSuggestions} from '../public/audience.js';
import http from 'node:http';
import {readFile,mkdir,writeFile,readdir,rename} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {EventHub,SpeechQueue,gemini,localReply,FORMS,DISTRICTS} from './core.js';
import {KeyStore} from './keys.js';
import {LiveAdapter} from './live.js';
const bundledModels=JSON.parse(await readFile(new URL('../public/bundled-models/manifest.json',import.meta.url),'utf8'));
const root=fileURLToPath(new URL('../',import.meta.url));const hub=new EventHub();const clients=new Set();
function broadcast(type,data){for(const c of clients)c.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);}
const queue=new SpeechQueue({timeout:120000,onChange:s=>broadcast('queue',s)});const live=new LiveAdapter((e,s)=>hub.ingest(e,s),s=>broadcast('live',s));
let config={voiceProvider:'browser',benPitch:1.08,benRate:1.08,conversationModel:process.env.GEMINI_MODEL||'gemini-2.5-flash',elevenVoiceId:'',speakerVoices:{},music:.15,voice:1,sfx:.3,quality:'balanced',giftRules:hub.giftRules,commandRules:hub.commandRules,giftCatalogVersion:0};
try{const saved=JSON.parse(await readFile(path.join(root,'data/config.json'),'utf8'));config={...config,...saved};}catch{}
try{config.giftRules=normalizeGiftRules(config.giftRules,{upgradeLegacy:config.rulesVersion!==28});}catch{config.giftRules=hub.giftRules;}
if((Number(config.giftCatalogVersion)||0)<4)config.giftRules=mergeGiftSuggestions(config.giftRules);
try{config.commandRules=normalizeCommandRules(config.commandRules);}catch{config.commandRules=hub.commandRules;}
config.giftRules=config.giftRules.map(({mission,missionKind,...rule})=>({...rule,power:rule.power||!!(mission||missionKind)}));config.commandRules=config.commandRules.filter(r=>!r.mission&&!r.missionKind);config.rulesVersion=36;config.giftCatalogVersion=4;hub.giftRules=config.giftRules;hub.commandRules=config.commandRules;

let configWrites=Promise.resolve();
function changeConfig(data){const task=configWrites.then(async()=>{
   const next={...config};if(data.adventure)next.adventure=data.adventure;
   if(data.voiceProvider!==undefined){if(!['browser','gemini','elevenlabs'].includes(data.voiceProvider))throw Error('Provedor de voz inválido');next.voiceProvider=data.voiceProvider;}
   for(const [key,min,max] of [['benPitch',.7,1.5],['benRate',.85,1.25]])if(data[key]!==undefined){if(!Number.isFinite(data[key])||data[key]<min||data[key]>max)throw Error('Tom ou ritmo de voz inválido');next[key]=data[key];}
   if(data.conversationModel!==undefined){if(typeof data.conversationModel!=='string'||!/^gemini-[a-zA-Z0-9._-]{1,90}$/.test(data.conversationModel))throw Error('Modelo Gemini inválido');next.conversationModel=data.conversationModel;}
   if(data.elevenVoiceId!==undefined){if(typeof data.elevenVoiceId!=='string'||(data.elevenVoiceId&&!/^[a-zA-Z0-9_-]{5,100}$/.test(data.elevenVoiceId)))throw Error('ID de voz inválido');next.elevenVoiceId=data.elevenVoiceId;}
   if(data.speakerVoices!==undefined){if(!data.speakerVoices||typeof data.speakerVoices!=='object'||Array.isArray(data.speakerVoices)||Object.keys(data.speakerVoices).length>Object.keys(SPEAKERS).length)throw Error('Mapa de vozes inválido');for(const [id,value] of Object.entries(data.speakerVoices))if(!Object.hasOwn(SPEAKERS,id)||typeof value!=='string'||(value&&!/^[a-zA-Z0-9_-]{5,100}$/.test(value)))throw Error('Voz de personagem inválida');next.speakerVoices={...data.speakerVoices};}
   for(const k of ['music','voice','sfx'])if(data[k]!==undefined)next[k]=Math.max(0,Math.min(1,Number(data[k])||0));
   if(['economy','balanced','high'].includes(data.quality))next.quality=data.quality;
   if(data.giftRules!==undefined){next.giftRules=normalizeGiftRules(data.giftRules).map(({mission,missionKind,...rule})=>({...rule,power:rule.power||!!(mission||missionKind)}));}
   if(data.commandRules!==undefined){next.commandRules=normalizeCommandRules(data.commandRules).filter(r=>!r.mission&&!r.missionKind);}
   await mkdir(path.join(root,'data'),{recursive:true});const configFile=path.join(root,'data/config.json'),configTemp=configFile+'.tmp';await writeFile(configTemp,JSON.stringify(next));await rename(configTemp,configFile);config=next;hub.giftRules=config.giftRules;hub.commandRules=config.commandRules;return config;
 });configWrites=task.catch(()=>{});return task;}
const keys=await new KeyStore(path.join(root,'data/private/gemini-keys.json')).load();
const voiceKeys=await new KeyStore(path.join(root,'data/private/elevenlabs-keys.json'),'ELEVENLABS_API_KEY').load();
const adventure=new ArenaSession({onChange:s=>broadcast('adventure',s)});
if(config.adventure)adventure.configure(config.adventure);
let trainingUntil=0;let localSpeechUntil=0;const adventureBusy=()=>Date.now()<localSpeechUntil||Date.now()<trainingUntil;
const giftActions=new GiftActionQueue({adventure,onChange:s=>broadcast('giftActions',s),onNotice:notice=>broadcast('gameNotice',notice)});
const adventureTimer=setInterval(()=>{const now=Date.now(),busy=adventureBusy();adventure.tick(now,busy);giftActions.tick(now,busy);},50);adventureTimer.unref();
const recent=new Map();
hub.listeners.add(e=>{e.mission=false;e.missionKind=null;broadcast('event',e);broadcast('ranking',hub.leaders());
 if(e.type==='join'||e.type==='follow')adventure.welcome(Date.now());
 if(e.type==='gift'){if(e.action||e.power||e.movement)giftActions.enqueue(e);return;}
 try{const c=e.control;
  if(c?.kind==='transform')adventure.requestTransform(c.form,e.source,Date.now());
  else if(c?.kind==='select')adventure.select(c.form,Date.now());
  else if(c?.kind==='confirm')adventure.confirm(Date.now());
  else if(c?.kind==='revert')adventure.revert(Date.now());
  else if(c?.kind==='stop')adventure.stop(Date.now());
  else if(c?.kind==='move')adventure.requestMovement(c.mode,Date.now(),c.direction);
  else if(c?.kind==='gesture')adventure.requestGesture(c.gesture,Date.now());
  else if(c?.kind==='power'){if(c.requiresForm&&c.requiresForm!==adventure.form)throw Error('Este poder precisa da forma '+(SPEAKERS[c.requiresForm]?.name||c.requiresForm));adventure.requestPower(adventure.form,Date.now(),c.variant);}
  else if(e.action)adventure.requestTransform(e.action,e.source,Date.now());
  else if(e.movement)adventure.requestMovement(e.movement,Date.now(),e.direction);
  else if(e.gesture)adventure.requestGesture(e.gesture);
  else if(e.power)adventure.requestPower();
  adventure.tick(Date.now(),adventureBusy());
 }catch(error){broadcast('gameNotice',{text:error.message});}
 if(e.type==='comment'&&!e.control&&!e.action&&!e.power&&!e.movement&&!e.gesture){const last=recent.get(e.user)||0;if(Date.now()-last<3000)return;recent.set(e.user,Date.now());if(recent.size>5000)recent.delete(recent.keys().next().value);queue.enqueue({speaker:e.speaker,user:e.user,prompt:e.text,source:e.source,priority:hub.ranking.get(e.user)?.giftCredit||0});const u=hub.ranking.get(e.user);if(u)u.giftCredit=Math.max(0,u.giftCredit-1);}
});
async function body(req,limit=65536){let bytes=0;const parts=[];for await(const b of req){bytes+=b.length;if(bytes>limit)throw Error('Corpo excede o limite');parts.push(b);}return Buffer.concat(parts);}
function json(res,status,data){res.writeHead(status,{'x-game-build':BUILD_ID,'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(data));}
export const server=http.createServer(async(req,res)=>{try{
 if(!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host))return json(res,403,{error:'Host não permitido'});
 const url=new URL(req.url,'http://127.0.0.1');const p=url.pathname;
 // A document opened from another app/site is a valid entry point. API requests remain origin-restricted.
 const entryNavigation=req.method==='GET'&&p==='/'&&req.headers['sec-fetch-mode']==='navigate'&&req.headers['sec-fetch-dest']==='document';
 if(!entryNavigation&&req.headers['sec-fetch-site']==='cross-site')return json(res,403,{error:'Origem não permitida'});
 if(!entryNavigation&&req.headers.origin && !['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin))return json(res,403,{error:'Origem não permitida'});
 if(p==='/events'){
  res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive'});clients.add(res);res.write(`event: ready\ndata: ${JSON.stringify({build:BUILD_ID,energy:hub.totalEnergy,queue:queue.snapshot(),ranking:hub.leaders(),live:live.state,adventure:adventure.snapshot(),giftActions:giftActions.snapshot()})}\n\n`);const heartbeat=setInterval(()=>res.write(': ping\n\n'),15000);req.on('close',()=>{clearInterval(heartbeat);clients.delete(res);});return;
 }
 if(p==='/api/health')return json(res,200,{ok:true,application:'LINEL_LIVE_CITY_V25',build:BUILD_ID,buildLabel:BUILD_LABEL,identity:'Ben Tennyson',runtime:{pid:process.pid,root:root.replace(/\/$/,''),port},training:Date.now()<trainingUntil,node:process.version,geminiConfigured:!!keys.key(),voiceProvider:config.voiceProvider,voiceConfigured:config.voiceProvider==='browser'?true:config.voiceProvider==='elevenlabs'?!!voiceKeys.key():!!keys.key(),live:live.state,forms:FORMS,arena:true,landmarks:['Clareira','Lata Velha','Lago','Acampamento'],queue:queue.snapshot(),giftActions:giftActions.snapshot(),uptime:process.uptime()});
 if(p==='/api/models'&&req.method==='GET'){let files=[];try{files=await readdir(path.join(root,'data/models'));}catch{}return json(res,200,FORMS.flatMap(form=>files.includes(form+'.glb')?[{form,url:'/models/'+form+'.glb',custom:true}]:bundledModels.filter(entry=>entry.form===form)));}
 if(p==='/api/speakers'&&req.method==='GET')return json(res,200,SPEAKERS);
 if(p==='/api/voice-library'&&req.method==='GET')return json(res,200,await elevenVoices({key:voiceKeys.key()}));
 if(p==='/api/voice-keys'&&req.method==='GET')return json(res,200,voiceKeys.status());
 if(p==='/api/adventure'&&req.method==='GET')return json(res,200,adventure.snapshot());
 if(p==='/api/keys'&&req.method==='GET')return json(res,200,keys.status());
 if(p==='/api/config'&&req.method==='GET')return json(res,200,config);
 if(req.method==='POST'&&p.startsWith('/api/')){
  if(p==='/api/model'){
   const form=url.searchParams.get('form');if(form&&!FORMS.includes(form))throw Error('Forma inválida');const filename=(form||'avatar')+'.glb';
   const b=await body(req,20*1024*1024);if(b.length<20||b.toString('ascii',0,4)!=='glTF'||b.readUInt32LE(4)!==2||b.readUInt32LE(8)!==b.length)throw Error('GLB 2.0 inválido');
   const jsonLength=b.readUInt32LE(12);if(b.readUInt32LE(16)!==0x4e4f534a||jsonLength%4||jsonLength+20>b.length)throw Error('Chunk JSON GLB inválido');const document=JSON.parse(b.toString('utf8',20,20+jsonLength));if(document.asset?.version!=='2.0')throw Error('Asset GLB 2.0 ausente');if(document.buffers?.some(x=>x.uri)||document.images?.some(x=>x.uri))throw Error('GLB precisa incorporar buffers e texturas');
   await mkdir(path.join(root,'data/models'),{recursive:true});await writeFile(path.join(root,'data/models',filename),b);return json(res,201,{url:'/models/'+filename,bytes:b.length,note:'GLB armazenado; carregamento disponível no painel.'});
  }
  const data=JSON.parse((await body(req)).toString()||'{}');
  if(p==='/api/voice-keys'){if(!String(req.headers['content-type']).startsWith('application/json'))throw Error('JSON obrigatório');return json(res,200,await voiceKeys.change(data.action,data));}
  if(p==='/api/keys'){if(!String(req.headers['content-type']).startsWith('application/json'))throw Error('JSON obrigatório');return json(res,200,await keys.change(data.action,data));}
  if(p==='/api/adventure'){const now=Date.now();if(data.action==='transform')adventure.requestTransform(data.form,'operator',now);else if(data.action==='select')adventure.select(data.form,now);else if(data.action==='confirm')adventure.confirm(now);else if(data.action==='revert')adventure.revert(now);else if(data.action==='stop')adventure.stop(now);else if(data.action==='react')adventure.react({gesture:data.gesture,expression:data.expression},now);else if(data.action==='gesture')adventure.requestGesture(data.kind,now);else if(data.action==='movement')adventure.requestMovement(data.mode,now,data.direction);else if(data.action==='power')adventure.usePower(now,adventureBusy(),data.strength,data.variant);else if(data.action==='locate'){if(data.speaking===true)localSpeechUntil=now+1800;else localSpeechUntil=0;}else if(data.action==='configure'){adventure.configure(data.options,now);await changeConfig({adventure:{...adventure.options}});}else throw Error('Ação da clareira inválida');adventure.tick(now,adventureBusy());return json(res,200,adventure.snapshot(now));}
  if(p==='/api/training'){if(typeof data.active!=='boolean')throw Error('Estado de treino inválido');const duration=data.duration??12000;if(!Number.isFinite(duration)||duration<1000||duration>60000)throw Error('Duração de treino inválida');trainingUntil=data.active?Date.now()+duration:0;adventure.tick(Date.now(),adventureBusy());return json(res,200,{active:Date.now()<trainingUntil,until:trainingUntil});}
  if(p==='/api/event')return json(res,200,{event:hub.ingest(data,'demo')});
  if(p==='/api/ack')return json(res,200,{accepted:queue.ack(data.id)});
  if(p==='/api/connect'){await live.connect(String(data.username||''),data.provider,{endpoint:data.endpoint||'auto'});return json(res,200,live.state);}
  if(p==='/api/disconnect'){await live.disconnect();return json(res,200,live.state);}
  if(p==='/api/answer'){
   if(!queue.active||queue.active.id!==data.id)return json(res,409,{error:'Fala não ativa'});
   return json(res,200,await answerComment(queue.active,{key:keys.key(),keyLabel:keys.status().selectedLabel,model:config.conversationModel,context:{form:adventure.form,arena:true,watch:adventure.watch,position:adventure.position}}));
  }
  if(p==='/api/test-gemini'){const answer=await gemini('Diga apenas: Omnitrix pronto!',{key:keys.key(),model:config.conversationModel,context:{speaker:'base',arena:true}});return json(res,200,{ok:true,model:answer.model,latency:answer.latency,keyLabel:keys.status().selectedLabel});}
  if(p==='/api/tts'){if(typeof data.text!=='string'||data.text.length>1000)throw Error('Texto inválido');if(config.voiceProvider==='browser')return json(res,200,{provider:'browser',model:'Voz gratuita do aparelho'});const speaker=speakerId(data.speaker||adventure.form),profile=SPEAKERS[speaker],voiceId=config.speakerVoices?.[speaker];if(config.voiceProvider==='elevenlabs'&&!voiceId&&speaker!=='base')throw Error('Escolha um ID ElevenLabs para '+profile.name+' no painel de vozes');return json(res,200,{...await (config.voiceProvider==='elevenlabs'?elevenlabs(data.text,{key:voiceKeys.key(),voiceId:voiceId||config.elevenVoiceId}):gemini(data.text,{tts:true,key:keys.key(),speaker})),speaker,name:profile.name});}
  if(p==='/api/config'){const {adventure:ignoredAdventure,...settings}=data;return json(res,200,await changeConfig(settings));}
  return json(res,404,{error:'Rota inexistente'});
 }
 if(req.method!=='GET')return json(res,405,{error:'Método não permitido'});
 const modelRoute=p.startsWith('/models/')&&['avatar',...FORMS].some(form=>p==='/models/'+form+'.glb');
 if(p.startsWith('/models/')&&!modelRoute)return json(res,404,{error:'Modelo não encontrado'});
 const base=modelRoute?path.join(root,'data/models'):path.join(root,'public');const relative=modelRoute?p.slice('/models'.length):p==='/'?'/index.html':p;const file=path.resolve(base,'.'+decodeURIComponent(relative));if(!file.startsWith(base+path.sep))return json(res,403,{error:'Caminho inválido'});
 const b=await readFile(file);res.writeHead(200,{'cache-control':'no-cache','x-game-build':BUILD_ID,'content-type':({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.glb':'model/gltf-binary','.svg':'image/svg+xml'})[path.extname(file)]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(b);
 }catch(e){json(res,e.code==='ENOENT'?404:400,{error:e.message});}});
const port=Number(process.env.PORT||3000);
if(!Number.isInteger(port)||port<1||port>65535){console.error('PORT inválida. Use um número entre 1 e 65535.');process.exit(1);}
server.once('error',async error=>{clearInterval(adventureTimer);queue.close();if(error.code==='EADDRINUSE'){
 let running=false;try{const r=await fetch('http://127.0.0.1:'+port+'/api/health',{signal:AbortSignal.timeout(1200)});const d=await r.json();running=d.application==='LINEL_LIVE_CITY_V25'||(Array.isArray(d.forms)&&d.forms.join(',')===FORMS.join(','));}catch{}
 console.error(running?'O jogo já está em execução nesta porta. Abra http://127.0.0.1:'+port+'/':'A porta '+port+' já está sendo usada por outro programa.');
 console.error('Para carregar uma atualização, pare o servidor anterior com Ctrl+C na sessão original e execute bash start.sh novamente.');
 console.error('Para usar outra porta: PORT='+Math.min(65535,port+1)+' bash start.sh');process.exit(running?0:1);
 }else{console.error('Não foi possível iniciar o servidor: '+error.code);process.exit(1);}});
server.listen(port,'127.0.0.1',()=>console.log(BUILD_LABEL+' iniciado. Abra http://127.0.0.1:'+port+'/'));

for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{clearInterval(adventureTimer);queue.close();live.disconnect();for(const c of clients)c.end();server.close(()=>process.exit(0));});
