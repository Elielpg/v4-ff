# Ben 10 · Clareira LIVE · V41.1

**Correção V41.1:** o sintetizador recebe somente a frase, sem instruções nem características de voz. Quem conversa é sempre Ben criança do clássico, mesmo transformado; a mesma voz IA é usada em todas as formas. [Guia da correção](docs/V41_1_CORRECAO_VOZ.md).

Recepção dos visitantes com avatar aleatório, câmera de chegada e nome/foto acima da cabeça. Ben caminha até novos seguidores para cumprimentá-los. Presentes priorizam mensagens e agradecimentos numa fila única. A conversa ganha respostas curtas, contexto recente por pessoa e convites espaçados para participar.

TAP TAP cria esferas 3D que saem do chão e entram no Omnitrix original, com luz e som. Há dia, tarde e noite, poderes emitidos pelas mãos e uma barra inferior com quatro botões. Ranking, ícones, comandos, metas coletivas, onze formas, três poderes por forma e recarga verde/vermelha permanecem. Sem tarefas de cidade.

**Somente voz de IA:** Gemini TTS ou ElevenLabs. A voz do aparelho não é usada, nem como substituta quando a IA falha. As legendas continuam disponíveis. Configure e teste a voz em **LIVE → IA e voz**; texto e áudio podem ter cotas/permissões diferentes. O acesso gratuito depende do provedor e não inclui a dublagem oficial.

```sh
bash install.sh
bash start.sh
```

Abra no Chrome do mesmo aparelho o endereço indicado e toque em **♫** para permitir áudio. Confira **41.1.0**. [Guia da V41](docs/V41_RECEPCAO_E_VOZ_IA.md).

Para atualizar a instalação anterior preservando dados:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V41_1_TERMUX.zip --start
```

Use sua pasta real caso tenha outro nome. O DNA começa com Ben humano; Chama libera com 100 curtidas acumuladas. **LIVE → Laboratório → DNA por TAP TAP** permite ajustar metas ou usar modo livre. DEMO e TikTok guardam progresso separado.

Comandos: `andar esquerda`, `correr direita`, `frente`, `trás`, `pular`, `girar`, `parar`, nome de um alien, `voar`, `pousar`, `dash` com XLR8 e `poder 1/2/3`. Também: `sentar`, `levantar`, `sorrir`, `acenar` e `comemorar`. Perguntas continuam na conversa. Ações manuais têm preferência sobre cumprimentos automáticos.

## Desenvolvimento

Node >=22.19, npm e Python 3. Dependências fixadas no lockfile. Assets Babylon locais, sem CDN.

- `npm ci`, `npm test`, `npm run lint`, `npm run build`.
- `node scripts/v41_1-isolated-check.js`: navegador em instalação temporária, sem dados pessoais, com Gemini e fotos simulados offline.
- `npm run package`: verificações e ZIP, sem `data/`, `.env` pessoal ou `node_modules`.
- `node scripts/archive-smoke.js ../BEN10_LIVE_V41_1_TERMUX.zip`: extrai e inicia o ZIP usando as dependências locais do mesmo lockfile.

Relatórios atuais em `reports/v41_1/`. Não houve validação com chave Google real, LIVE real ou Android físico. O áudio da fixture é uma onda WAV para testar transporte/reprodução, sem validar timbre ou qualidade do serviço externo. Guias anteriores são históricos; a V41 substitui suas instruções de voz do aparelho.

Código AGPL-3.0 e fontes correspondentes do conector incluídos. Nove GLBs de terceiros com créditos/licenças; Quatro Braços, Alien X e Cipó Selvagem usam formas procedurais por padrão. Visitantes usam geometria estilizada própria. [Créditos](docs/MODEL_CREDITS.md), `third_party/NOTICE.md`. Projeto de fã sem afiliação oficial; efeitos e vozes não são gravações oficiais.
