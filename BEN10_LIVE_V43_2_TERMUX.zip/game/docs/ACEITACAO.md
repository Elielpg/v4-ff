# Aceitação e evidências

Automatizados: domínio da fila de dez falas/ACK idempotente/prioridade sem interrupção; deduplicação, streak e pontuação; onze geometrias distintas; seis distritos e circuito sem área bloqueada; resposta Gemini e PCM TTS controlados; HTTP, SSE, configuração persistente, cabeçalho GLB, rejeição de upload inválido e origem externa; estados PirateTok antes/depois do handshake controlado.

Navegador: scripts/browser-check.js executa Chromium local com WebGL software, verifica meshes, onze botões/transformações, evento DEMO, atualização da fila, upload/import GLB de geometria real, câmera frontal e seis bairros. Gera reports/browser.json e reports/mobile-city.png. Requer npm ci incluindo dev e Chromium instalado. Não é executado na instalação Android.

Manuais ainda necessários: LIVE real; Gemini/TTS com chave válida; voz e autoplay Chrome Android; rig GLB redistribuível; desempenho e aquecimento Realme GT3; sessões longas/reconexão na rede real. Ausência desses testes não é marcada como aprovação.
