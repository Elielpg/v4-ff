# V40 · Respostas Gemini e energia de DNA por TAP TAP

A V40 mantém o acampamento, o personagem, as animações, os poderes, as missões coletivas, os ícones, o ranking, os painéis e o Omnitrix original. Corrige a seleção/validação de IA e transforma as curtidas em energia verde para liberar os aliens.

## IA cadastrada, mas sem responder

A atualização trata estes casos:

- Arquivos antigos com chaves cadastradas e nenhuma seleção ativa: se não houver chave do ambiente selecionada, uma chave salva volta a ser selecionada.
- **Adicionar e usar esta chave** passa a ativar a chave recém-adicionada. Colar uma chave já cadastrada nesse formulário seleciona a existente, sem criar outra cópia. A opção de lote continua com seleção manual.
- Teste e perguntas do público passam pelo mesmo serviço de conversa, com a mesma chave e modelo. O teste mostra uma resposta de exemplo à pergunta digitada pelo operador.
- **Chave salva** e **Gemini respondendo** são estados diferentes. O segundo só aparece depois de uma resposta bem-sucedida do Google.
- Chave inválida, acesso negado, cota, falta de internet e modelo indisponível aparecem com mensagens diferentes. Uma chave cadastrada com cota esgotada não é apresentada como chave ausente.
- O modo **auto** consulta os modelos de texto disponíveis para a chave e escolhe um Flash. Se um modelo salvo retornar indisponível, tenta um Flash listado pelo Google usando a mesma chave. Não há rodízio automático de chaves nem tentativa de contornar cotas.
- As instruções de cadastro/API ficam no painel do operador. O texto falado ao público não pede que os espectadores conectem chaves. Quando a geração falha, a interface identifica a resposta local.

### Conferir no celular

1. Abra **☷ LIVE → IA e voz**.
2. Cadastre a chave em **Adicionar e usar esta chave**, ou clique em **Usar e testar** na chave desejada.
3. Deixe o modelo em **auto**. Você também pode usar **Consultar modelos da minha chave** para ver os modelos retornados pelo Google e escolher um.
4. Digite uma pergunta de teste e clique em **Salvar modelo e testar chave selecionada**. Confira **GEMINI RESPONDENDO** e a resposta de exemplo.
5. Ative **♫**. Faça uma pergunta no chat de teste ou pela LIVE conectada. O indicador mostra quando a resposta veio do Gemini.

Se o Google recusar a chave ou informar cota/permissão, a atualização mostra a causa. Essas restrições da conta/projeto precisam ser resolvidas no Google AI Studio. Não compartilhe sua chave no chat; para suporte, basta a mensagem do teste.

Chaves em `GEMINI_API_KEY` continuam funcionando; `GOOGLE_API_KEY` também é reconhecida como alternativa. O provedor de voz é independente: **Gemini para gerar texto + voz gratuita do aparelho para falar** continua disponível. Gemini TTS e ElevenLabs usam suas próprias condições de acesso/cota. Veja [voz da V38](V38_VOZ_E_MOVIMENTOS.md).

## TAP TAP agora é energia verde

Os corações animados foram substituídos por esferas verdes com brilho e símbolo do Omnitrix. Elas sobem enquanto chegam eventos de curtidas. Um lote de muitas curtidas desenha um grupo limitado de esferas; a energia usa a quantidade recebida, não a quantidade de figuras.

A faixa permanente sob a energia coletiva mostra:

- o próximo alien a liberar;
- quantas curtidas ainda faltam;
- uma barra de energia;
- se os dados são da LIVE ou do DEMO.

As metas iniciais usam **curtidas acumuladas**, sem gastar energia ao transformar:

| DNA | Curtidas acumuladas |
| --- | ---: |
| Chama | 100 |
| Besta | 250 |
| Diamante | 500 |
| XLR8 | 800 |
| Quatro Braços | 1.200 |
| Aquático | 1.700 |
| Fantasmático | 2.300 |
| Cipó Selvagem | 3.000 |
| Bola de Canhão | 4.000 |
| Alien X · extra | 5.500 |

Exemplo: com 99 curtidas, falta uma para Chama. Ao chegar a 100, Chama é liberado e a faixa passa a mostrar Besta, com 150 curtidas restantes. Ben continua humano até o chat, um presente ou o operador pedir uma transformação. O tempo e a recarga do relógio continuam valendo.

Formas bloqueadas aparecem apagadas nos mesmos ícones e na seleção do Omnitrix. Pedir um alien bloqueado pelo chat informa o quanto falta. Presentes que escolherem uma forma bloqueada aguardam o DNA na fila, sem perder o pedido por esperar o desbloqueio; presentes elegíveis podem seguir antes deles. A capacidade da fila de presentes continua limitada.

### Ajustar ou liberar todas as formas

Em **☷ LIVE → Laboratório → DNA por TAP TAP**, você pode editar as metas ou desmarcar **Desbloquear aliens por curtidas** para usar o modo livre. Alterar uma meta não tira DNAs já conquistados. Reativar o desbloqueio volta a respeitar o progresso conquistado por curtidas.

O botão **Recomeçar DNA desta origem** zera deliberadamente o progresso da origem atual. Se a forma em uso deixar de estar liberada, Ben volta à forma humana com a recarga normal. Use esse botão somente quando quiser reiniciar a progressão.

## Progresso salvo e origem das curtidas

O progresso e os DNAs ficam em `data/alien-progress.json`, gravados de forma atômica e preservados pelo atualizador/backup normal. Um encerramento normal com Ctrl+C salva o estado antes de sair. Um encerramento forçado pode perder a pequena janela da última gravação.

**DEMO e TikTok são separados.** Curtidas de teste não liberam aliens da LIVE. Na demonstração, tocar no cenário ou em **TAP TAP — TESTE LOCAL** testa a energia. Durante a LIVE, o botão **PRÉVIA LOCAL** só produz animação, sem somar energia real. As curtidas reais chegam pelo conector.

As missões coletivas da V39 continuam com suas próprias rodadas. Concluir ou reiniciar uma missão de 500 curtidas não zera o total de DNA. A progressão de DNA é nova: instalações da V39 não tinham um total confiável de curtidas persistido para importar.

## Atualizar no Termux

Após baixar o ZIP, na pasta anterior (ajuste o caminho se necessário):

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V40_TERMUX.zip --start
```

Atualize a página no Chrome e confira **V40 / 40.0.0**. Chaves, `.env`, modelos personalizados e dados existentes são preservados. Para iniciar novamente: `bash start.sh`.

Instalação nova: extraia o ZIP, entre em `game`, rode `bash install.sh` e `bash start.sh`.

## Verificação

Os testes exercitam as rotas HTTP reais de chave, teste de IA e resposta pública usando um provedor Google offline de teste. Verificam seleção de chave, chave salva sem seleção, reativação de chave existente, modelo indisponível, cota e chave inválida. A resposta falada não pede API ao público.

Também verificam desbloqueio, deduplicação, origens, fila de presentes, persistência após reiniciar o servidor, relógio e modo livre. O Chromium confere as respostas, o cadastro, os erros, as esferas verdes, a liberação dos botões, a espera do presente e os layouts.

Para repetir a integração sem usar dados pessoais: `node scripts/v40-isolated-check.js`. O verificador cria uma instalação temporária sem copiar `data/` ou `.env`. `node scripts/v40-ui-preview.js` também usa uma instalação temporária. Os arquivos de teste não são carregados pelo início normal do jogo.

Não foi usada uma chave Google real, uma conta TikTok real ou Android físico. O acesso da sua chave precisa ser confirmado pelo teste no próprio aparelho. O ZIP não inclui chaves ou progresso pessoais.
