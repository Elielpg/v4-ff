# Revisão das transformações e articulações

Cada uma das onze formas possui um perfil em public/model-motion.js. O modelo é orientado antes de calcular altura e centro, em vez de aplicar o mesmo giro a todos. Quatro Braços é corrigido em 90 graus no eixo X; Fantasmático recebe sua própria orientação horizontal. Há alturas e proporções distintas e a câmera usa a silhueta para enquadrar formas largas.

## Skin e movimento

Os nove GLBs originais continuam idênticos aos arquivos creditados. Em runtime, a geometria da pose original é normalizada com seus materiais e UVs, e recebe um esqueleto de deformação de 17 juntas, ou 23 para Quatro Braços. Os pesos autorais do Ben e da Besta são reaproveitados e remapeados por anatomia; os modelos estáticos recebem pesos calculados com uma região de braço mais precisa e suavização reduzida para preservar melhor a silhueta. O comprimento automático dos braços também é limitado. Os dois modelos procedurais usam a mesma rotina. As cópias articuladas usam skin na GPU, não somente rotação do personagem inteiro.

A caminhada coordena ombros, cotovelos, quadris, joelhos e pés. Quatro Braços move os dois pares de braços. Fantasmático flutua e oscila a cauda; Aquático também usa movimento de cauda. Cada variação do poder passa uma pose correspondente ao rig. Fala usa gestos e movimentos suaves da cabeça, sem continuar a passada das pernas. Idle mantém respiração discreta. Há interpolação das rotações e o apoio vertical é calculado a partir de uma amostra dos vértices dos pés/da base deformada.

A mudança de forma mantém o passeio e a direção do avatar, descarta importações antigas e usa o efeito verde existente. A revisão do estado evita que um GET inicial atrasado reverta um evento mais novo do servidor.

## Validação

- npm test cobre perfis, eixos, poses, pesos normalizados e deformação efetiva de vértices sem alterar a geometria original.
- node scripts/motion-check.js verifica as onze formas no Chromium: movimento de vértices, pernas estáveis em idle, gestos de fala, geometria finita, apoio ao solo e limites de alongamento. Salva dois quadros de caminhada por forma em reports/motion/ e métricas em reports/motion-browser.json. Também testa uma resposta inicial atrasada após uma transformação.
- Os testes visuais usam a instância local de desenvolvimento e mudam opções temporariamente. Não execute com uma transmissão real em andamento.

## Limites

São animações procedurais criadas para estes modelos. Não são os clipes oficiais do desenho, captura de movimento nem um retargeting artesanal completo. A calibração melhora a forma durante os movimentos, mas não substitui a edição manual de pesos ou a troca por modelos oficiais fornecidos pelo usuário. Não foi validado desempenho nem aquecimento no Chrome Android.

Esta revisão não acrescenta rig facial aos nove GLBs. O sopro do Chama posiciona brilho e fogo no focinho, sem deformar a boca do modelo. O suporte de boca para modelos que já tenham morph targets compatíveis continua disponível. Importações GLB do usuário preservam seus próprios rigs e animation groups; não recebem automaticamente a calibração específica dos nove arquivos incluídos.
