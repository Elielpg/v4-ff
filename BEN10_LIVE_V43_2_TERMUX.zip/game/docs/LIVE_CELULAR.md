# TikTok LIVE usando somente o celular

O servidor roda no Termux; o Chrome desenha o jogo. O conector recebe os eventos públicos do @ pelo servidor Node. Não exige um computador. Iniciar/transmitir a LIVE continua sendo uma função do aplicativo TikTok e depende das modalidades disponíveis na conta; o jogo não concede permissão de transmissão nem publica uma LIVE.

## Atualizar e iniciar

A captura enviada pelo usuário mostrava a interface antiga (“Tentar conexão” e o diagnóstico genérico). Atualize o ZIP, pare o processo anterior com Ctrl+C na sessão original, execute a instalação da atualização e reinicie. Confirme o número de versão da nova entrega no jogo. Recarregar uma aba não atualiza um processo Node antigo.

No Termux:

```sh
cd ~/linel-v25/game
bash start.sh
```

Abra http://127.0.0.1:3000 no Chrome. Toque em ♫ para habilitar áudio. No TikTok, comece uma LIVE pública no @ escolhido; se a sua conta oferece compartilhamento de tela/jogos, escolha o Chrome/jogo como conteúdo. Não confunda a prévia flutuante do aplicativo com a confirmação de recebimento de comentários pelo jogo.

Mantenha o Termux aberto em segundo plano enquanto alterna entre TikTok e Chrome. Nas configurações Android, permita execução em segundo plano para Termux e evite que a economia de bateria encerre o processo durante a transmissão. Se disponível no Termux, `termux-wake-lock` evita suspensão da CPU; ao encerrar, use `termux-wake-unlock`. Isso não supera limites de RAM ou permissões de captura do TikTok/Android.

## Conectar o @

No painel LIVE, informe somente o nome de usuário, com ou sem @ e sem URL; por exemplo, `linel.exe`. Espaços nas extremidades são removidos e o nome fica em minúsculas. Escolha **Automático** e conecte. O pacote agora inclui PirateTok e o transporte assinado do TikTok-Live-Connector 2.5.0; não é necessário instalar um adaptador extra no celular. O modo automático tenta PirateTok e usa o protocolo público assinado do TikTok-Live-Connector se o socket direto falhar por transporte ou recusa de upgrade sem assinatura. O diagnóstico mostra o provedor realmente usado. Nos modos manuais você pode selecionar um dos dois transportes. A região global/US/EU afeta somente o transporte PirateTok; o assinado usa o servidor e os parâmetros retornados pelo serviço. Também pode fixar uma região no painel; no servidor, `TIKTOK_CDN=global`, `us`, `eu` ou `auto` fornece o padrão.

Estados têm significados diferentes:

- **Sala resolvida**: o TikTok retornou um roomId; isso não prova que o WebSocket abriu.
- **WebSocket confirmado**: a promessa do conector confirmou o handshake.
- **Recebendo eventos**: chegou pelo menos um evento. O contador e o horário são a evidência de recepção.
- **Reconectando**: o socket foi interrompido ou houve erro transitório; veja tentativa, região, próxima tentativa e causa real.
- **Erro**: terminou o limite de tentativas, a conta está offline/privada, houve bloqueio ou outro problema impeditivo. Nenhum desses estados é apresentado como sucesso.

Peça a um espectador para escrever “Chama”, “poder”, “missão” ou uma pergunta na LIVE pública e confira evento/transformação/fila no jogo. O @ é o identificador do canal do TikTok; ele nunca deve mudar a identidade do personagem para o nome do canal.

Há quatro tentativas no máximo, alternando os transportes no modo automático, antes de abrir o primeiro socket, com timeout de 30 segundos por tentativa e espera progressiva. Aberturas curtas seguidas de queda consomem o mesmo orçamento e param após o limite; uma sessão saudável de pelo menos 30 segundos restaura o orçamento ao cair. Não existem dois loops de reconexão sobrepostos: PirateTok usa `maxRetries(0)`, que executa a primeira sessão, e o jogo supervisiona as próximas. A cada nova sessão bem-sucedida o handshake é confirmado novamente, mesmo sem comentários. Desconectar ou mudar o @ cancela tentativas e ignora eventos de clientes antigos.

## Diagnóstico no próprio Termux

Com a conta transmitindo:

```sh
cd ~/linel-v25/game
node scripts/live-probe.js @linel.exe --seconds 45
```

Opcionalmente fixe `--provider piratetok` ou `--provider alternative`; o padrão é `auto`. `--endpoint global`, `us` ou `eu` afeta PirateTok. O teste recebe apenas eventos; não envia comentários nem presentes. Imprime estados/causas e contagem por tipo, sem texto de espectadores, cookies ou chaves. Salva `data/live-last-test.json`, excluído do ZIP de distribuição.

Códigos de saída: `0` recebeu evento real; `2` confirmou socket mas não recebeu evento na janela observada; `1` não confirmou ou ocorreu falha. Ctrl+C encerra o teste com limpeza. Um socket sem eventos não deve ser anunciado como conversa da LIVE validada.

Leitura das causas:

- `not currently live`/`UserNotFound`: confira o @ e se a transmissão já começou.
- `DEVICE_BLOCKED`, CAPTCHA ou bloqueio explícito do proxy: o TikTok ou a rede recusou. O jogo exibe a causa e encerra a sequência. Uma recusa de upgrade WSS 401/403 sem indício de proxy/bloqueio pode significar que o protocolo direto precisa de assinatura: nesse caso, o modo automático tenta a abertura pública assinada com o outro conector. Uma falha 403 no transporte assinado encerra a sequência. Uma conexão do Chrome ao TikTok não garante autorização do protocolo do conector.
- `429`: limite de consultas; aguarde antes de repetir.
- `18+`, sala privada ou autenticação exigida: este modo por @ não acessa essa sala. Não cole cookies ou credenciais no chat.
- `ENOTFOUND`, `EAI_AGAIN`, `ECONNRESET`, timeout: falha de DNS/rede/socket. Confira conexão do aparelho e tente novamente após estabilizar.
- `Proxy response (403) ... HTTP Tunneling`: o proxy de saída bloqueou o destino antes de chegar ao TikTok. Precisa de configuração de rede autorizada no ambiente que usa o proxy; não é evidência de que a conta esteja offline.

## Pesquisa e validação desta revisão

Em 28/10/2026, o registro npm informava `piratetok-live-js 0.3.0` como versão mais recente (modificado em 05/10/2026). A API e o supervisor foram inspecionados no código instalado. Referências: https://github.com/PirateTok/live-js e README distribuído pelo pacote. Nenhuma atualização de dependência foi inventada para prometer conserto do serviço.

Quinze testes verificam handshake, normalização/eventos, causa sanitizada, bloqueio sem loop, timeout/troca documentada de endpoint, perda e reabertura do socket, cancelamento durante lookup/backoff, exclusão de eventos antigos e limite de sockets instáveis com renovação após uma sessão saudável. Uma das verificações instancia o pacote real TikTok-Live-Connector 2.5.0, abre WebSocket local e decodifica um comentário protobuf controlado. As outras incluem o fallback automático e os formatos atuais displayId, gift.type e streamEnd. Esses testes não substituem uma transmissão real.

O teste de recepção de `@linel.exe` nesta cloud foi impedido pelo proxy: `UND_ERR_ABORTED: Proxy response (403) !== 200 when HTTP Tunneling`. A política de rede estava aplicada e não permitia os domínios TikTok. Não foi obtido handshake, roomId atual nem evento real nesta sessão. A captura do usuário mostra uma sala resolvida no celular, mas a causa original foi descartada pela versão antiga. Esta revisão preserva a causa para diagnosticar o aparelho. O conector continua comunitário e pode falhar por mudanças do TikTok; não há garantia de funcionamento universal.

## Compatibilidade adicional desta entrega

O adaptador alternativo antigo tentava `WebcastPushConnection`, que não é exportado pelo pacote 2.5.0 atual. Agora usa a API real `TikTokLiveConnection`, com históricos iniciais desativados para não contar presentes antigos como novos, e trata os campos atuais de usuário/presente e o encerramento da sala. Sala já resolvida pelo primeiro transporte pode ser reutilizada no transporte assinado, evitando uma consulta redundante.

O caminho assinado recebe URL de WebSocket, cursor e parâmetros pelo serviço comunitário Euler Stream. Não há polling HTTP de comentários inventado: os métodos públicos de consulta de sala não fornecem o fluxo de mensagens do chat. O serviço pode limitar conexões gratuitas ou exigir uma conta para outros recursos; nenhuma chave ou assinatura paga é fornecida. Este jogo não ativa conexão autenticada e não envia cookies de sessão TikTok ao provedor.

Proxy: os clientes got, ws e axios do caminho alternativo respeitam explicitamente o proxy herdado, com a verificação TLS e a cadeia de confiança preservadas. Domínios necessários incluem www.tiktok.com, webcast.tiktok.com, webcast-ws.tiktok.com, webcast-ws.us.tiktok.com, webcast-ws.eu.tiktok.com e api.eulerstream.com; o serviço pode retornar um hostname de push regional adicional, que também precisa estar autorizado em redes restritas. Não há contorno de política de rede.

O novo conector AGPL e seu código-fonte completo estão incluídos, com licença/notas em LICENSE e third_party/NOTICE.md. Os modelos 3D mantêm suas próprias licenças e créditos.
