# V32 · Formas, poderes e efeitos

A V32 ajusta a articulação dos modelos para que os movimentos preservem melhor a silhueta original: a influência automática dos braços é mais localizada, a suavização de pesos estáticos foi reduzida e o alcance dos braços tem um limite seguro. O movimento de Quatro Braços recebeu uma calibração mais controlada. Os arquivos GLB originais e seus créditos/licenças não foram alterados.

## Três habilidades por forma

O botão de poder avança para a próxima habilidade a cada ativação; após a terceira, volta à primeira. As formas também têm poses e efeitos próprios para as variações:

- **Chama:** sopro de fogo, bola de fogo e explosão de chamas.
- **Quatro Braços:** golpe no chão, soco duplo e palma de choque.
- **Diamante:** parede de cristais, disparo de estilhaços e escudo cristalino.
- **Aquático:** jato, onda e escudo de água.
- **Fantasmático:** fase espectral, avanço fantasma e tentáculos.
- **Besta:** rastreamento, bote e rugido sônico.
- **XLR8:** arrancada, raio e rastros de velocidade.
- **Cipó Selvagem:** agarrão, disparo de sementes e chicote de espinhos.
- **Cannonbolt:** rolamento, investida e ricochete.
- **Ultra-T:** varredura, escudo e pulso de energia.
- **Estrela Polar:** pulso cósmico, órbita de estrelas e poço gravitacional.

O sopro do Chama agora ilumina a região da boca, mostra um fluxo central de fogo e pequenas labaredas e termina com anéis/impacto no alvo. Como os modelos incluídos não têm rig facial, o brilho é um efeito visual separado e não altera a malha do rosto.

## Limite dos modelos

Esta versão melhora a deformação em runtime dos modelos licenciados já incluídos; não os substitui por modelos oficiais do desenho. Os originais permanecem intactos. Animações são procedurais e os modelos estáticos ainda podem exigir ajustes manuais de skinning para alcançar uma silhueta exata em todas as poses. Imagens oficiais ou modelos de referência do usuário podem orientar uma calibração artística mais precisa.

## Atualização no Termux

Extraia o ZIP sobre a instalação e execute:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V32_TERMUX.zip --start
```

O atualizador preserva `.env` e `data/`. Confirme **v32.0.0** no topo do jogo.
