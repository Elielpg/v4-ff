# V36 · Clareira LIVE · O chat escolhe a aventura

## Cenário e controle

A interface e o servidor ativos foram renovados: **não há cidade, viagem linear, pedestres nem missões**. A clareira tem floresta, trilha sinuosa, pedras, fogueira, barraca, lago ao redor e um trailer inspirado no Lata Velha. Cenário e novos elementos são procedurais e originais, inspirados no acampamento/viagem da série clássica.

A posição passa a ser controlada pelo servidor em dois eixos. Ben pode ir para esquerda/direita, frente/trás, correr, saltar, girar e parar. Há limites circulares e colisões simples com o trailer, fogueira e pedras. Não é um mundo infinito. O voo permite ultrapassar obstáculos baixos; ele termina com um pouso. A câmera acompanha de forma suave e mantém o personagem pequeno. Existe ajuste de distância em LIVE → Ajustes.

O passeio espontâneo vem **desativado**. Pode ser ligado em Ajustes; as interações continuam tendo prioridade. Configurações antigas de missões/transformações automáticas não reativam o jogo anterior.

## Comandos do chat

| Comente | Resultado |
| --- | --- |
| `Chama`, `XLR8`, `Diamante`, `Quatro Braços` etc. | Seleciona e transforma, se o relógio permitir |
| `selecionar Chama` e depois `transformar` | Seleção e confirmação separadas |
| `humano` | Retorna a Ben e inicia a recarga |
| `andar esquerda`, `andar direita`, `frente`, `trás` | Caminhada na clareira |
| `correr direita`, `correr frente` | Corrida na direção pedida |
| `pular`, `girar`, `parar` | Salto, rodopio ou interrupção do deslocamento |
| `voar frente`, `voar esquerda` | Voo de Chama, Fantasmático ou Alien X |
| `pousar` | Pouso da forma que estiver no ar |
| `dash direita`, `super velocidade` | Supervelocidade de XLR8; exige estar nessa forma |
| `poder 1`, `poder 2`, `poder 3` | Escolhe um dos três poderes da forma atual |
| Nome de um poder, como `Bola de fogo` | Pede essa habilidade; exige a forma correspondente |
| `acenar`, `comemorar` | Gestos para o público |

Perguntas como “como voar?” continuam sendo conversa. Comandos incompatíveis geram aviso, sem transformar silenciosamente em outra forma. O painel **Mover** oferece as mesmas ações para o operador; teclado WASD, Shift para correr, Espaço para pular e teclas 1/2/3 para poderes também estão disponíveis.

## Omnitrix

- **Verde e pronto:** Ben pode selecionar um alien. Clique no símbolo do relógio ou em Omnitrix, escolha uma forma e confirme.
- **Seleção:** pose de olhar/acionar o relógio, efeito sonoro e destaque do DNA escolhido.
- **Transformação:** sequência de 1,4 segundo com pose, anéis/partículas, flash e som sintetizado. Só então a forma fica ativa.
- **Forma ativa:** contador e barra verde mostram o tempo restante. Duração padrão: **45 segundos**.
- **Troca de forma:** há um intervalo de seleção de 7 segundos entre mudanças. Mudar de alien não renova a duração total da carga.
- **Tempo esgotado:** retorno automático a Ben, aviso sonoro e efeitos vermelhos. O símbolo no HUD e o relógio sobre o pulso do Ben ficam vermelhos.
- **Recarga:** barra vermelha avança por **18 segundos**, por padrão. Seleção manual é bloqueada; pedidos de presentes aguardam na fila. Ao terminar, o relógio fica verde novamente.

Duração da forma e recarga são ajustáveis em LIVE → Ajustes, com limites de 20–120 s e 8–60 s. O relógio não para durante falas nem se renova ao recarregar a página. A sessão é mantida em memória: reiniciar o servidor volta a Ben com o relógio pronto.

## Formas, poses e poderes

Cada uma das onze formas tem três habilidades selecionáveis, com recarga individual por uso. Chama mantém sopro, bola de fogo e explosão; XLR8 tem arrancada, tornado de velocidade e imagens residuais, sem tratar eletricidade como poder principal. O dash e a arrancada alteram a posição real no cenário. O voo só é aceito em formas compatíveis.

Quatro Braços ganhou uma nova malha procedural padrão, com quatro braços articulados por membro, quatro olhos, roupa branca/preta e pele vermelha. Isso evita o estiramento dos braços da malha anterior. Alien X e Cipó Selvagem mantêm as silhuetas procedurais renovadas. Outros modelos GLB incluídos são preservados, com suas limitações de resolução/articulação e créditos. Um GLB personalizado salvo pelo usuário continua prevalecendo sobre o padrão.

As poses incluem seleção do relógio, deslocamentos, salto, giro e cada poder. O corpo pode se mover durante falas e volta a encarar o público quando fica parado. Som, cores e efeitos são interpretações originais; não incluem gravações da dublagem ou arquivos oficiais de animação.

## Presentes e conversa

Os slides de presentes, quinze famílias de efeitos e conexão TikTok foram mantidos. A fila respeita transformação, relógio vermelho e recarga de poderes; pontos continuam registrados mesmo quando a fila está cheia. Regras pessoais são preservadas, e ações antigas de missão são retiradas da configuração ativa.

Além de `run`, `dash` e `fly`, regras de presentes agora aceitam `walk`, `jump`, `spin`, `land` e `roll` (este último exige Bola de Canhão). `direction` é um vetor `[x,z]`, e `powerVariant` seleciona o poder com índices **0, 1 ou 2**. Exemplo de regra para configurar no editor de Presentes:

```json
{"name":"Meu presente","points":10,"action":"base","power":true,"powerVariant":2,"movement":"spin"}
```

As falas continuam usando o provedor selecionado, com fallback da voz do navegador. Toque em **♫ Ativar som**. Há saudações e respostas locais básicas sem chave; conversa livre depende de Gemini. As chaves não acompanham o ZIP e não são exibidas no navegador após salvar.

## Atualizar no Termux

Se sua instalação está na pasta usada anteriormente:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V36_TERMUX.zip --start
```

O atualizador preserva `data/` e `.env`; opções antigas de cidade/missões são ignoradas. Se necessário, pare a sessão antiga com Ctrl+C. Abra o endereço indicado no Chrome e confira **V36 / 36.0.0**. Se instalou em outra pasta, use essa pasta no `cd`.

Instalação nova: extraia o ZIP, entre em `game`, execute `bash install.sh` e `bash start.sh`.

## Validação e limites

Os resultados atuais estão em `reports/v36/`: testes de relógio, movimento, colisão, capacidades, três poderes por forma, filas, HTTP/SSE, migração de configurações e privacidade; navegação em Chromium com comandos reais enviados pelo endpoint de eventos; ciclo completo real de expiração automática e recarga; extração e inicialização do ZIP.

Os testes de fala usam WAV controlado para comprovar reprodução e fluxo, sem validar uma voz externa. LIVE TikTok real, Gemini/ElevenLabs e desempenho em Android físico ainda precisam ser conferidos na conta/aparelho. Use qualidade Econômico em celulares mais fracos. Testes/módulos históricos ficam no código-fonte para regressão e compatibilidade; eles não reativam cidade ou missões no jogo V36.
