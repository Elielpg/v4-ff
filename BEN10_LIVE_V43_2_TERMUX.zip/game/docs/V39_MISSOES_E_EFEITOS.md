# V39 · Missões do chat, TAP TAP e efeitos 3D

A V39 mantém o acampamento, os personagens, o ranking, os ícones, o painel de comandos, o Omnitrix original e o sistema de voz/chaves da V38. Acrescenta missões coletivas de interação e efeitos 3D inspirados na linguagem visual do desenho: formas facetadas, contornos, núcleos de cor, chamas, raios e ondas de impacto.

## Missões coletivas

As quatro metas ficam ativas ao mesmo tempo. O cartão à esquerda alterna a missão exibida; os quatro ícones permitem escolher qual acompanhar. Os valores iniciais são:

| Missão | Ação coletiva | Meta inicial | Celebração 3D |
| --- | --- | ---: | --- |
| TAP TAP Omnitrix | Curtidas | 500 | Explosão Omnitrix, selo e ondas de energia |
| Voz dos heróis | Comentários | 20 | Cristais de Diamante surgindo ao redor do Ben |
| Chamar reforços | Compartilhamentos | 3 | Túnel e rastros de velocidade |
| Equipe do Ben | Novos seguidores | 3 | Sinal dos heróis subindo no cenário |

A meta concluída mostra o resultado e recomeça uma rodada após 12 segundos. Um lote de curtidas completa no máximo uma rodada; o excedente não é reutilizado. Os quatro tipos de missão são independentes. As celebrações aguardam uma transformação/poder em andamento e agrupam repetições do mesmo efeito quando há muitos eventos.

Em **☷ LIVE → Laboratório → Missões do chat**, você pode mudar as metas, desligá-las ou recomeçar o progresso. Alterar um valor recomeça apenas a missão desse tipo; ajustar voz, música ou qualidade conserva o progresso. A configuração fica salva. Progresso, rodadas e seguidores já contados pertencem à sessão do servidor e recomeçam ao reiniciar, assim como o ranking em memória.

Comentários vazios não contam; há intervalo de três segundos por pessoa para comentários e dez segundos para compartilhamentos. A mesma pessoa conta uma vez como novo seguidor durante a sessão. Identificadores repetidos não contam duas vezes. Presentes e entradas continuam com seus efeitos próprios, sem entrar nessas quatro contagens.

Estas missões são metas da comunidade. O cenário continua sendo a clareira; as antigas tarefas de cidade/NPC não voltaram. Ben pode explicar as metas e seu progresso ao responder perguntas sobre elas. As celebrações incluem novas poses de vitória ou de herói e agradecimentos curtos, se as falas estiverem ativadas.

## TAP TAP e corações

Com a LIVE conectada, os eventos de curtida recebidos pelo conector geram corações animados subindo pela lateral do jogo e preenchem a meta de curtidas. Um evento com várias curtidas gera um pequeno grupo de corações; o contador da meta usa a quantidade recebida, não a quantidade de figuras desenhadas.

Na demonstração local, tocar no cenário ou no botão **♥ TAP TAP — TESTE LOCAL** gera um evento DEMO para testar os corações e a meta. Durante uma LIVE, esse botão fica identificado como **PRÉVIA LOCAL**: produz apenas a animação no aparelho, sem somar curtidas reais nem enviar curtidas ao TikTok. As curtidas reais vêm dos espectadores pelo conector.

**Progresso DEMO e progresso TikTok são separados.** Testes feitos antes de conectar a transmissão não completam as metas reais. O cartão indica a origem. Ao desconectar explicitamente, o jogo volta ao DEMO; uma reconexão mantém o progresso recebido naquela sessão.

Os corações não bloqueiam botões. Há limites de elementos e fila para picos de TAP TAP, descarte após a animação e uma versão mais suave quando o aparelho pede movimento reduzido. O modo econômico reduz a quantidade de corações e detalhes dos efeitos.

## Poderes e animações

As onze formas receberam camadas adicionais:

- Chama: línguas de fogo 3D animadas, casca laranja e núcleo amarelo.
- XLR8: arcos elétricos com núcleo claro e rastros de velocidade.
- Diamante: cristais facetados, contornos e surgimento no chão.
- Aquático, Fantasmático e Cipó Selvagem: correntes/tubos 3D curvos para água, vórtices e cipós.
- Ben e Alien X: selos e escudos de energia em três dimensões.
- Quatro Braços, Besta e Bola de Canhão: detritos, ondas e acentos de impacto.

Transformações ganham um selo em volume, motes de DNA e rastros. A reversão durante a recarga usa a cor vermelha. O relógio original conserva sua geometria e sua mudança verde/vermelha. Os novos efeitos não recarregam o relógio nem escolhem aliens por conta própria.

A câmera se afasta suavemente durante os poderes para enquadrar o personagem e o ponto do efeito. O enquadramento normal retorna ao terminar.

Novos comandos: **`pose` / `pose de herói`** e **`vitória`**. As poses também estão em **Mover**. Continuam disponíveis sentar, levantar, sorrir, acenar, andar, correr, pular, girar, voo nas formas permitidas e poder 1/2/3.

## Instalar ou atualizar

Após baixar `BEN10_LIVE_V39_TERMUX.zip`, na instalação anterior:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V39_TERMUX.zip --start
```

Use a sua pasta real se for diferente. O atualizador preserva `data/`, chaves e `.env`; confira **V39 / 39.0.0** no Chrome. Para iniciar novamente: `bash start.sh`.

Instalação nova: extraia o ZIP, entre em `game`, rode `bash install.sh` e `bash start.sh`.

Ative **♫** para sons e falas. A voz gratuita e o cadastro de várias chaves continuam na aba **IA e voz**; veja [guia da V38](V38_VOZ_E_MOVIMENTOS.md). Para receber as interações reais, conecte a LIVE pelo seu @ na aba LIVE. Use a captura de tela do jogo no TikTok e mantenha o Chrome em primeiro plano.

## Verificações e limites

Testes de domínio/HTTP/SSE cobrem metas, origem confiável, deduplicação, rodadas, limites por participante, configuração e progresso. Os testes de geometria exercitam efeitos das onze formas e a liberação de recursos. A conferência no Chromium verifica os corações, quatro celebrações, limite da fila, prévia local durante um fluxo TikTok simulado, novas camadas de Chama/Diamante/XLR8, relógio vermelho e painéis em celular/paisagem.

Os eventos usados na validação são simulados; não foi conectada uma conta TikTok real nem usado Android físico. A chegada de curtidas, compartilhamentos e seguidores em produção depende do conector e do acesso da conta. A fidelidade visual é uma interpretação procedural para este projeto de fã, sem arquivos de efeitos ou sons extraídos do desenho.
