# V42.3 · Modelo público sem token

As ferramentas do Termux foram instaladas corretamente. O erro seguinte ocorreu antes do download de pesos: o perfil GT3 tentava primeiro `Qwen/Qwen3-4B-Instruct-2507-GGUF`. A consulta retornava HTTP 401 e o instalador parava antes de tentar o catálogo público alternativo. HTTP 401 na consulta não prova que é necessário cadastrar uma chave: o endereço pode estar indisponível, privado ou inexistente.

O usuário consultou sem autenticação `unsloth/Qwen3-4B-Instruct-2507-GGUF` e confirmou o ID e o arquivo `Qwen3-4B-Instruct-2507-Q4_K_M.gguf`. A V42.3 remove o primeiro endereço e usa esse catálogo público. Não pede token e não tenta obter acesso a modelos restritos.

## Correção curta na instalação existente

Na pasta da V42 original, o endereço antigo pode ser removido com backup e validação de sintaxe:

```sh
cd ~/ben10-v34/game &&
mkdir -p data/installer-backups &&
cp scripts/local-ai/download_models.py "data/installer-backups/download_models-$(date +%s).py" &&
sed -i 's@"Qwen/Qwen3-4B-Instruct-2507-GGUF", @@' scripts/local-ai/download_models.py &&
python3 -m py_compile scripts/local-ai/download_models.py &&
bash local-ai.sh install &&
bash local-ai.sh start
```

Isso altera apenas a entrada antiga na lista de catálogos. Não troca o modelo público por um menor nem reinstala as ferramentas que já estão prontas. Modelos e parciais já existentes são mantidos. O download de vários GB e a compilação ainda precisam terminar. A interface mantém a versão já instalada quando se usa só esta correção curta.

## Melhorias permanentes no pacote V42.3

O downloader agora identifica o catálogo antes da consulta. Uma opção inacessível com 401/403/404 só pode dar lugar a outra opção pública explicitamente configurada; não solicita credenciais nem usa serviços online de conversa. O limite 429 não gira catálogos. Modelos privados ou com acesso condicionado não são usados.

Os catálogos de conversa e voz e seus hashes são conferidos antes de iniciar o GGUF de vários GB. Erros de consulta e de arquivo mostram o repositório/arquivo público e o status HTTP, sem imprimir endereços temporários assinados de CDN. Downloads parciais podem ser retomados, e os pesos continuam sendo verificados por hash. Registros Git sem LFS aceitam o campo LFS ausente ou nulo.

Para verificar só os catálogos, sem baixar pesos:

```sh
python3 scripts/local-ai/download_models.py --root "$HOME/.local/share/ben10-local-ai" --model gt3 --check
```

`BEN10_REPARO_IA_V42_3.zip` oferece um reparo autônomo de cinco scripts, com backup. `BEN10_LIVE_V42_3_TERMUX.zip` já contém a correção completa. O pacote mantém o suporte Deb822 de `termux.sources` da V42.2 e não exige recriar `.env` ou chaves.

## Validação

O catálogo e o nome do GGUF foram confirmados pelo usuário no telefone. Os testes automatizados simulam a consulta pública sem autorização, o 401 de uma opção anterior, o bloqueio de catálogo restrito, a preservação de parciais e a conferência de hashes. Verificam que falha no catálogo da voz acontece antes de baixar o modelo de conversa e que o reparo curto conserva backup e sintaxe.

A validação cloud não baixou os pesos reais nem executou inferência no GT3. O teste de catálogo não mede velocidade ou qualidade da IA/voz. Relatórios em `reports/v42_3/`.
