# V29 · Mais interação e tela organizada

Esta versão mantém o jogo, a conexão pelo @, a fila de conversa e as regras de presentes que já existiam, e adiciona:

- **Boas-vindas e agradecimentos:** visitantes, novos seguidores, presentes e compartilhamentos recebem um cartão de alerta com animação e uma frase no ticker. Curtidas também entram no placar; os avisos de curtida são limitados para não cobrir o jogo.
- **Agradecimento falado:** no painel **LIVE**, a opção “Ben agradece em voz alta” vem ativada. Toque em **♫** uma vez para liberar o áudio do navegador. Ben agradece em voz PT-BR local, sem enviar nomes de espectadores a um serviço externo. As falas esperam conversas e missões terminarem e têm intervalo para não disputar o áudio.
- **Presentes com efeito:** presentes mostram quantidade, pontos e ação configurada, com som e partículas. A regra de transformação/poder continua editável em **Laboratório → Presentes**.
- **Ranking ao vivo:** painel no cenário mostra os três primeiros participantes e seus pontos, nível e progresso. A aba **Ranking** exibe os 20 primeiros e quantas curtidas, presentes, seguidores, comentários e visitas cada participante gerou.
- **Níveis:** Novato (0), Fã (25), Apoiador (100), Guardião (300), Lenda (750) e Mítico (2.000 pontos). Presentes usam os pontos definidos no Laboratório; seguidores valem 5, curtidas somam o total recebido e visitas/compartilhamentos/comentários valem 1 cada. A classificação é da sessão do servidor e não é salva após reiniciá-lo.
- **Painéis móveis:** abra **Ajustes → Organizar tela da LIVE**, toque em **Mover painéis** e arraste pelo ícone ⠿. Marque ou desmarque os widgets para mostrar/ocultar. As escolhas ficam no armazenamento local do navegador; **Restaurar tela** volta ao padrão.

Antes de ativar voz, teste os alertas em **Laboratório → Evento DEMO**. O demo é identificado no aviso e também atualiza o ranking da sessão. A conexão com eventos reais depende da disponibilidade dos conectores comunitários do TikTok.

## Instalar e iniciar no Termux

Extraia o ZIP recebido para uma pasta privada do Termux (por exemplo, `~/ben10-v29`). Para uma instalação nova:

```sh
cd ~/ben10-v29/game
bash install.sh
bash start.sh
```

Depois, abra no Chrome o endereço impresso, normalmente `http://127.0.0.1:3000/`. O comando de início para as próximas vezes é:

```sh
cd ~/ben10-v29/game
bash start.sh
```

Para atualizar uma instalação existente sem perder `data/` ou `.env`, deixe o ZIP em `~/storage/downloads/` e use o atualizador da pasta já instalada:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V29_TERMUX.zip --start
```

O Termux pode pedir autorização de armazenamento uma vez; nesse caso, execute `termux-setup-storage`. Pare servidores antigos apenas com **Ctrl+C** na sessão original se o atualizador informar que não conseguiu confirmar o processo.

O projeto requer Node.js **22.19 ou superior**. Para começar do zero, `install.sh` instala as dependências e `start.sh` inicia o servidor. Nenhuma chave de IA é necessária para os alertas, o placar ou a fala local do navegador.
