# V41.1 · Corrigir a leitura das características da voz

O problema vinha do pedido enviado ao Gemini TTS: a descrição da interpretação e o texto estavam no mesmo campo. O serviço podia ler a descrição antes da frase.

Agora, esse campo contém exclusivamente a fala do personagem. A escolha do timbre fica em `speechConfig`, separada do texto. Não acrescentamos frases como "Direção de voz", "Texto", "fale em português" ou fichas de personalidade ao conteúdo de áudio. A personalidade fica nas instruções da IA de conversa.

Na clareira, quem responde é apenas o Ben Tennyson criança da série clássica: confiante, brincalhão, competitivo, impulsivo e disposto a ajudar. As transformações mudam os poderes e a aparência, mantendo Ben como a pessoa que conversa. Chamar Gwen ou Max no chat não troca a personalidade. As instruções também proíbem narrar tom, características ou atuação antes da resposta.

Gemini usa a mesma voz selecionada em **LIVE → IA e voz** em todas as formas (Puck por padrão). ElevenLabs usa a voz geral do Ben, ou o mapeamento `base` já configurado. Mapas antigos por alien não trocam o timbre na clareira. O serviço continua sendo uma interpretação de IA, sem gravações da dublagem oficial.

## Atualizar

Dentro da pasta instalada:

```sh
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V41_1_TERMUX.zip --start
```

Abra novamente a página e confirme **V41.1 / 41.1.0**. Se ainda aparecer V41, atualize a página ou abra `http://127.0.0.1:3000/?v=41.1.0`. O atualizador preserva chaves, `.env`, configurações, modelos personalizados e progresso.

Em **LIVE → IA e voz**, salve o provedor e use **Testar voz IA**. A frase de teste deve começar diretamente por "E aí, pessoal!", sem descrição antes dela. Toque em **♫** para permitir áudio.

## Verificação

Os testes de regressão inspecionam o pedido enviado ao provedor, verificando que o texto é exatamente a frase e não contém instruções de interpretação. A integração HTTP exerce Ben, as dez formas alienígenas e chamadas de Gwen/Max, confirmando a mesma voz do Ben e ausência de prefixos. A conversa e a identidade são verificadas separadamente da forma visual.

A integração usa Google simulado offline e áudio WAV sintético. Isso verifica o contrato de texto/áudio, não a qualidade ou o timbre de uma voz Google real. Não foi usada uma chave real, LIVE real ou Android físico nesta validação. Os relatórios desta versão ficam em `reports/v41_1/`.

Os recursos de visitantes, fila de presentes, TAP TAP, relógio e cenário da V41 permanecem. O guia da V41 é histórico; esta correção substitui sua descrição de timbres diferentes por forma.
