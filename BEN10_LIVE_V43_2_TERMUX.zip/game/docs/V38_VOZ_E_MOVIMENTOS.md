# V38 · Gemini, voz grátis e Ben mais vivo

O visual da V37 foi preservado: ícones das formas, ranking da LIVE, quadro de comandos, cenário de acampamento, Omnitrix original no braço, seleção, transformação e recarga. Sem cidade ou missões.

## Ativar a conversa e a voz

1. Abra **☷ LIVE → IA e voz**. Cadastre a chave Gemini e clique em **Usar** na linha desejada. O campo aceita espaços externos e uma linha `GEMINI_API_KEY=...` copiada do arquivo de configuração.
2. Para várias chaves, abra **Adicionar várias chaves de uma vez**, cole **uma por linha** e clique em **Adicionar todas**. Limite: 20. Chaves repetidas no lote são ignoradas; o lote só é gravado se todas as linhas forem válidas. Os nomes automáticos são distintos. Excluir a ativa seleciona uma das restantes.
3. Clique em **Salvar modelo e testar chave selecionada**. O teste usa o serviço Google e informa chave pelo nome, modelo e latência. Só há seleção manual, sem rodízio automático. Cotas dependem do projeto Google, não da quantidade de chaves cadastradas. O modelo padrão de texto é `gemini-2.5-flash`; ajuste se o seu projeto exigir outro.
4. Em **Como falar**, selecione **Grátis · voz do aparelho, sem chave** e **Salvar provedor de voz**. Instalações novas já usam essa opção; ao atualizar, a escolha de voz anterior é preservada.
5. Toque em **♫ Ativar som**. Escolha uma voz em português, ajuste tom/ritmo do Ben e salve. Clique em **Testar fala do Ben**. Cada alien conserva seu próprio ritmo/tom.

A conversa Gemini e a voz são independentes: é possível usar **Gemini para pensar + voz gratuita do aparelho para falar**. A voz Web Speech usa o mecanismo de texto para voz do dispositivo; algumas vozes do sistema podem exigir internet. Não é a dublagem original nem uma voz clonada. O resultado depende da voz instalada. Gemini TTS e ElevenLabs continuam opcionais e podem ter cotas, créditos ou cobrança conforme a conta.

Se aparecer **Nenhuma voz em português disponível**, vá nas configurações Android, procure **Texto para voz / Saída de conversão de texto em fala**, habilite um mecanismo e instale **Português (Brasil)**. Reabra o Chrome e teste. Use o Chrome do aparelho com o jogo em primeiro plano e toque no botão de som após abrir. Não há áudio garantido em navegadores internos de outros aplicativos.

## Respostas e diagnóstico

Perguntas como “Quem é você?” agora também tentam o Gemini se houver chave. Respostas locais de contingência ficam identificadas como **RESPOSTA LOCAL**. Falhas de conexão, acesso, modelo ou cota aparecem no painel; não se diz que uma frase local veio do Gemini. Boas-vindas e agradecimentos rápidos continuam usando frases locais variadas para não gastar uma chamada por entrada/curtida; comentários de conversa seguem a fila Gemini.

A voz começa a animar o personagem quando a reprodução realmente inicia, depois da geração do texto/áudio. A fala do navegador é dividida em trechos menores e sequenciais para reduzir cortes em mensagens compridas. Se a voz online falhar, o sistema tenta a voz gratuita e informa a troca.

As chaves são armazenadas em `data/private/` no servidor local, com permissão privada. A listagem mostra apenas nomes/seleção/quantidade. Nunca compartilhe esse diretório nem coloque chaves em comentários da LIVE. O ZIP e o backup comum não incluem chaves pessoais. `.env` e `data/` existentes são preservados pelo atualizador.

## Gestos, expressão e movimento

- `sentar`: Ben se senta num banquinho de acampamento, com pernas flexionadas e os pés apoiados. `levantar` retoma a postura em pé. A postura sentada foi calibrada para Ben humano.
- `acenar`, `comemorar`, `sorrir`: gestos/expressão visíveis. Visitantes e seguidores recebem acenos com intervalo, para evitar repetição a cada evento.
- Respostas acionam gestos de explicação, concordância, comemoração ou dúvida. O rosto do modelo Ben pisca, movimenta sobrancelhas e acompanha a voz com um movimento sutil da mandíbula. Modelos personalizados conservam suas próprias capacidades de rosto.
- O aceno pode acontecer durante uma caminhada, sem trocar a animação das pernas por uma pose parada.
- **Ajustes → Gestos e pequenos passeios ocasionais** ativa pequenos deslocamentos, acenos, expressões e descansos em intervalos de aproximadamente 22–32 segundos, quando não há outra ação. O descanso espontâneo dura poucos segundos; o comando `sentar` permanece até `levantar`, movimentar, usar poder ou transformar.
- Comandos interrompem o passeio/descanso. Transformações e poderes têm prioridade. **Passeio contínuo** é uma opção separada e vem desligada.
- Andar/correr em duas direções, pular, girar, voar nas formas permitidas, XLR8 superveloz e os três poderes de cada forma continuam disponíveis.

## Instalar ou atualizar no Termux

Instalação nova: extraia o ZIP, entre na pasta `game`, rode `bash install.sh` e `bash start.sh`.

Na pasta anterior (ajuste o caminho se necessário), após baixar o ZIP:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V38_TERMUX.zip --start
```

Confira **V38 / 38.0.0**. O atualizador encerra apenas o processo confirmado desta instalação e preserva seus dados. Para iniciar novamente: `bash start.sh`.

## Validação

Testes de domínio e HTTP/SSE cobrem chaves, persistência, falhas do provedor, modos de resposta, voz fragmentada, interrupção de comportamentos, relógio, poderes e atualizador. O Chromium verifica postura sentada, morphs faciais, aceno andando, cadastro/seleção de três chaves, modos Gemini/local e ausência de requisição TTS paga no modo gratuito, além de formatos celular/paisagem. O fluxo Web Speech e a resposta Gemini no teste de interface usam fixtures; não foi usada uma chave Google real. A máquina cloud não tinha vozes PT-BR instaladas. Timbre/áudio em Android físico e conexão com uma LIVE real ainda precisam de teste no aparelho/conta.
