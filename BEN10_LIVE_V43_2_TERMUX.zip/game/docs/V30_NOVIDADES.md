# V30 · Mais gestos, transformações e poderes

A V30 amplia os comandos do público e deixa cada poder mais legível e recompensador:

- **Gestos pelo chat:** “acene”, “comemore” e “pule”, ou os comandos `/acenar`, `/comemorar` e `/pular`. O público pode pedir esses movimentos sem interromper a conversa falada em andamento.
- **Transformação com impacto:** as trocas de forma agora têm uma entrada com expansão suave do personagem, ondas verdes do Omnitrix e partículas ao redor.
- **Poderes inéditos em cena:** XLR8 cria descargas e ondas de velocidade; Besta solta pulsos de rastreamento e golpes de garra; Bola de Canhão produz um impacto com ondas e fragmentos; Ben ativa uma varredura holográfica do Omnitrix.
- **Presente mais forte, poder mais forte:** os pontos da regra do presente e a quantidade enviada determinam um nível de poder de 1 a 5. Níveis maiores aumentam escala visual e duração; o cartão do presente e a fila mostram o nível ativado. Os pontos continuam editáveis em **Laboratório → Presentes**.
- **Movimento mais suave:** as articulações usam uma interpolação independente da taxa de quadros, e as poses de aceno, comemoração e salto têm animação própria.

## Instalar e atualizar no Termux

Para uma instalação nova:

```sh
cd ~/ben10-v30/game
bash install.sh
bash start.sh
```

Para atualizar uma instalação existente sem perder `data/` ou `.env`, passe o arquivo recebido:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V30_TERMUX.zip --start
```

O atualizador mantém os modelos e configurações locais. A conexão real com TikTok e a fluidez final das animações precisam ser confirmadas no aparelho; os testes automatizados cobrem a lógica e a inicialização do pacote.
