# V35 · Personagem menor, presentes em slides e Ben mais participativo

## Enquadramento e personagens

A câmera da arena agora calcula a distância pela altura **e pela largura** de cada forma e pela proporção da tela. Em retrato, a meta é ocupar até cerca de 34% da altura e 68% da largura, antes de variações de perspectiva/pose. Isso deixa espaço para o cenário e protege os braços largos do Quatro Braços. O enquadramento de poder também respeita essa distância, com transição exponencial.

A articulação foi revista para reduzir a mistura indevida de vértices do tronco nos braços e o corte da máscara nos ombros. Quatro Braços tem pivôs inferiores e postura de repouso próprios. Transições das juntas e ajuste vertical dos pés ficaram mais graduais; respiração e cabeça continuam animando quando o personagem está parado.

Os nove GLBs originais e seus créditos continuam preservados. Não foram substituídos por modelos oficiais de maior resolução. A qualidade final ainda depende da malha original e de articulação procedural. Alien X e Cipó Selvagem, que não tinham GLB incluído, ganharam novas silhuetas procedurais: volumes arredondados, mãos/pés, olhos, detalhes vegetais e estrelas em vez de blocos simples.

## Presentes em slides

A faixa exibe três presentes por página, troca a cada 5,5 segundos e oferece anterior, próximo e pausa. O conteúdo vem das regras configuradas no aparelho; nomes equivalentes com a mesma ação são agrupados para evitar páginas repetidas. Não anuncia presentes que o operador removeu de suas regras. Respeita a opção de movimento reduzido do navegador.

O catálogo padrão passa a 40 nomes, incluindo aliases PT/EN, com 15 famílias de efeito. Às nove da V34 se juntam foguete em decolagem, chuva de meteoros, dragão de plasma segmentado, coroa com joias, borboletas com asas animadas e fogos com explosões radiais. São efeitos originais do jogo, não os vídeos oficiais do TikTok, e os pontos não representam moedas oficiais.

Atualizações acrescentam sugestões que faltam sem substituir regras pessoais. As filas visual e de ações continuam separadas e limitadas, com aviso em caso de saturação.

## Conversa e agradecimentos

Depois de tocar em **♫**, Ben recebe visitantes, agradece seguidores/presentes/compartilhamentos e comenta comandos usando frases variadas. A personalidade é uma interpretação escrita do Ben clássico: confiante, competitivo, brincalhão, impulsivo, corajoso e gentil com o público. Há humor leve sobre a Gwen, o vô Max e o Omnitrix, sem tentar copiar uma gravação da dublagem.

As falas de participação agora usam o provedor de voz selecionado em **☷ → IA e voz**, com fallback para a voz PT-BR disponível no navegador. A fila respeita falas de comentários, treinos e narrações habilitadas, prioriza agradecimentos de presentes, limita repetições de chegada e descarta falas muito antigas. Não fala por cima de outra fala iniciada pelo jogo. Em picos de público, algumas saudações podem ser descartadas; a fila não promete ler todos os eventos.

Comentários normais continuam na fila do servidor. Respostas agora se dirigem ao nome do espectador. Sem Gemini há respostas locais para cumprimentos, agradecimentos, perguntas simples, matemática básica e fatos do clássico. Conversa livre continua exigindo uma chave Gemini; a disponibilidade/qualidade de voz depende das vozes instaladas ou do serviço escolhido. Nenhuma chave ou gravação oficial acompanha o ZIP.

## Sons e fluidez

Novos timbres para os seis presentes, impacto no momento do contato e efeitos próprios de cristal, cipós, espectro e scanner. Sons são sintetizados localmente; o volume Efeitos controla a reprodução e há redução durante falas. Suavização não é garantia de uma taxa fixa de FPS. Em celular mais fraco, use **Ajustes → Qualidade → Econômico**.

## Instalação e atualização

Para instalação nova: extraia, entre em `game`, execute `bash install.sh` e `bash start.sh`. Abra o endereço indicado no Chrome do mesmo aparelho e confira **35.0.0**.

Se instalou a V34 em `~/ben10-v34/game`, preserve as configurações com o atualizador existente:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V35_TERMUX.zip --start
```

Pare a sessão antiga com Ctrl+C se necessário. O atualizador preserva `data/` e `.env` e valida o pacote antes de instalar. Não substitua `data/` por arquivos de outra instalação. Depois, use a mesma pasta para iniciar novamente com `bash start.sh`.

## Validação

Veja `reports/v35/`: testes de domínio/HTTP/filas, enquadramento projetado das onze formas, slides, efeitos 3D, reprodução serial de WAV de teste para chegada/comentário/seguidor/presente e extração do ZIP. Os WAVs controlados comprovam a fila e a reprodução, não a voz de um provedor externo. LIVE real, Android físico e vozes Gemini/ElevenLabs reais precisam de validação no aparelho/conta.
