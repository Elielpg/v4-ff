# Atualizar e executar no mesmo celular

A extração de um ZIP não reinicia o Node. Mesmo com os arquivos novos no armazenamento, um processo antigo pode continuar respondendo com a interface/identidade antiga. O navegador também pode estar aberto em outra porta ou em uma instalação diferente. A versão exibida no topo é a confirmação do que você está usando.

Para as melhorias atuais, siga primeiro [V33_NOVIDADES.md](V33_NOVIDADES.md). O pacote se chama **BEN10_LIVE_V33_TERMUX.zip**. A pasta de instalação pode continuar `~/linel-v25/game`, preservando chaves e configurações antigas. O nome da pasta não muda a identidade do Ben.

## Arquivos novos já extraídos

No Termux, dentro da pasta atualizada:

```sh
cd ~/linel-v25/game
bash update.sh --start
```

Com o arquivo baixado desta conversa, passe o caminho do ZIP explicitamente; o atualizador valida o pacote, encerra apenas processos confirmados desta instalação, preserva `.env` e `data/`, instala e inicia o jogo. Confira **v33.0.0** no topo da tela.

Se você já baixou o ZIP com um nome conhecido, evite baixá-lo novamente:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V33_TERMUX.zip --start
```

O arquivo em Downloads pode ter outro nome se o Android acrescentou `(1)`. Use o nome real e coloque o caminho entre aspas quando houver espaços/parênteses.

`bash update.sh` instala e deixa o comando de início no terminal. A opção `--start` também inicia o servidor após a instalação. Um arquivo diferente ou antigo, um ZIP danificado, caminhos inválidos, links simbólicos e arquivos privados embutidos são recusados.

## Quando o atualizador ainda não foi extraído

Baixe o novo pacote e extraia sobre `~/linel-v25`. Depois execute o comando com `--archive` acima. Em uma instalação antiga, `update.sh` também é antigo: primeiro é preciso extrair os arquivos desta entrega para ter o atualizador novo.

O pacote V33 é entregue como arquivo anexado nesta conversa; não use o endereço antigo de download V28, V29, V30, V31 ou V32. Copie o ZIP para Downloads e aplique a atualização:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V33_TERMUX.zip --start
```

O atualizador verifica o pacote antes de instalar. Sem um endereço remoto publicado, passe o arquivo com `--archive`; para iniciar uma instalação já pronta, basta `bash start.sh` na pasta correta.

## Como ele identifica o processo antigo

O encerramento automático exige usuário do processo igual ao atual, pasta real `/proc/PID/cwd` igual à instalação e executável Node com entrada exata `server/index.js` dessa pasta. Comandos `node -e`, testes, outros aplicativos ou instalações de outra pasta não são encerrados. O servidor novo também informa PID/pasta/porta no diagnóstico local para auxiliar a verificação. Nenhum cookie ou chave é usado para isso.

Não há `pkill node`, encerramento por nome genérico ou SIGKILL. O atualizador envia SIGTERM e aguarda até20segundos. Se o Android impedir a verificação do processo, se houver outro jogo na porta sem pasta confirmada ou se o processo não encerrar, ele interrompe antes de substituir os arquivos e orienta parar a sessão original com Ctrl+C. Depois repita o comando.

`start.sh` imprime a pasta real e a versão dos arquivos antes de iniciar. Isso permite perceber quando você abriu outra cópia do projeto. Uma porta ocupada por outro programa é mantida intacta; não é apresentada como uma atualização bem-sucedida.

## Dados e falhas de instalação

O ZIP não deve conter `.env`, `data/` ou `node_modules/`. Os arquivos locais desses diretórios são preservados durante a atualização; a instalação de dependências continua sendo feita pelo `npm ci` do projeto. Modelos GLB personalizados em `data/models` continuam prevalecendo sobre os incluídos.

A cópia dos arquivos do aplicativo mantém um backup temporário e restaura os arquivos anteriores se a cópia falhar. Se falhar o download, o pacote não é instalado. Se falhar a instalação de pacotes por falta de Internet ou outro erro, as configurações/chaves continuam preservadas: estabilize a conexão e execute `bash install.sh`, depois `bash start.sh`. Não foi implementado rollback de uma instalação parcial de dependências npm.

O atualizador foi testado em Linux com ZIPs controlados, incluindo preservação de dados, rollback de cópia, rejeição de traversal/symlinks e identificação/encerramento de um processo Node de teste. A verificação de processos no Android ainda depende das permissões de `/proc` do aparelho e deve ser confirmada no Termux.

## Recuperar erro NO_PUBKEY em termux-glibc

Na V27.0.0, install.sh chamava pkg mesmo quando Node, npm e Python já estavam instalados. Um repositório extra com chave ausente podia interromper a preparação com código100 antes de npmci. A correção27.0.1 só consulta pkg para ferramentas ausentes ou Node incompatível; não altera repositórios ou verificação de assinatura.

Se os arquivos já foram extraídos, como no log recebido, você pode terminar a instalação sem baixar novamente:

```sh
cd ~/linel-v25/game
npm ci --omit=dev --no-audit --no-fund &&
npm run build &&
bash start.sh
```

Isso prepara as dependências e o jogo usando as ferramentas existentes. O problema de chave do repositório opcional continua sendo uma configuração separada do Termux; esta recuperação não o modifica. Se faltar alguma ferramenta numa instalação nova, será necessário corrigir os repositórios confiáveis antes de instalá-la.
