# Ben 10 clássico e LIVE

O personagem responde como Ben Tennyson, dez anos, da série clássica de 2005. Gemini recebe estado real da forma/missão, regras de continuidade e uma referência local com 27 entradas sobre personagens, espécies, Omnitrix, adversários e séries. Também responde a perguntas gerais. Isso orienta o modelo; não representa uma enciclopédia completa nem elimina erros. O modo local usa fatos básicos e informa quando o comunicador está offline. A IA não tem busca web nem memória permanente das conversas.

Perguntas como “Quem é o Chama?” e “Quais os poderes do XLR8?” entram na fila de conversa, sem transformar. Nomes diretos e pedidos como “vira Chama” transformam. “poder” pede a habilidade atual. “missão” pede um objetivo; há cooldown, proximidade e pausa durante a fala. Alien X continua como extra manual, mas não é sorteado nas transformações e missões automáticas clássicas. As dez formas iniciais do desenho não estão todas modeladas nesta versão: Massa Cinzenta, Ultra T e Insectoide são conhecidos pela referência de conversa, mas não têm botão/modelo jogável.

## Banner e voz

O banner aparece após dois segundos e depois a cada 45 segundos, por 14 segundos. Alterna comandos, perguntas, ranking e regras reais de presentes/comandos do operador. Salvar as regras atualiza as próximas dicas. Só anuncia presentes configurados; não implica pagamento ou aquisição garantida. Pode ser fechado pelo ×.

A cada 150 segundos, fora de missão e de uma conversa, Ben pode explicar uma dica por voz. Desative em Ajustes → Ben explica as interações periodicamente. É necessário tocar em ♫. Dicas, chat e pedidos dos NPCs compartilham uma fila de áudio; sem fala sobreposta na aba operadora. Várias abas simultâneas continuam não suportadas.

Gemini TTS recebe timbre e direção por personagem, inclusive Gwen, Max e os três moradores. IDs e direções estão em public/characters.js. No fallback de navegador há variações de pitch/velocidade; os timbres disponíveis dependem do Android. Para ElevenLabs, abra IA e voz → Voz de cada alien e NPC, associe IDs de vozes da sua conta e salve. Um ID global antigo ainda serve para Ben; as demais formas precisam de seus próprios IDs. IDs não associados produzem diagnóstico e fallback local, sem fingir síntese de um timbre não configurado. As vozes são performances geradas, não áudios da dublagem original. Besta não fala no clássico: a fala aqui representa um tradutor de acessibilidade do Omnitrix.

## Missões, câmera e NPCs

Gwen e Vô Max usam geometria estilizada própria: cabelo, face, roupa clássica aproximada, olhos, boca e articulações. Moradores também têm roupas, cabelos e vozes diferentes. A malha é agrupada por material/articulação para reduzir chamadas de desenho. Não são modelos oficiais ou réplicas de produção. Os modelos dos aliens incluídos preservam seus créditos e variantes de origem; esta revisão acrescenta poses de uso de poder, não substitui as texturas/modelos por uma coleção uniforme clássica.

Com chave Gemini selecionada, uma missão pede JSON com título, fala do NPC, agradecimento, objeto e forma. Só são aceitas combinações que o jogo sabe executar. Nomes e textos não viram HTML nem código. Geração simultânea é deduplicada; erro de rede, quota ou conteúdo inválido produz missão local com aviso no painel. Sem chave, seleciona um dos dez pedidos locais evitando os quatro últimos títulos. Missões locais não são apresentadas como geradas pela IA. No HUD, a origem aparece como IA GEMINI ou MISSÃO LOCAL.

O objetivo fica próximo do trajeto seguro da cidade. Exige estar perto, na forma certa, e usar o poder três vezes. No automático, Ben se transforma, aproxima, para, usa habilidades e registra a conclusão. O personagem faz um gesto de habilidade; calor, água, cristais, intangibilidade, rastreamento, cipós, velocidade e impactos têm efeitos próprios. A câmera muda suavemente para trás durante a missão, permanece durante o último efeito e retorna à frente. A rota continua circular, não navegação livre por qualquer local. Missões são objetivos curtos, não histórias persistentes ou combate avançado.

## TikTok

Use Painel → LIVE → @ de uma conta pública atualmente transmitindo → Conectar pelo @. Não cole uma URL. Aguarde websocket confirmado e depois recebendo eventos; confira o contador e o horário do último evento no diagnóstico. Envie “Chama”, “poder”, “missão” ou uma pergunta no chat real. Confira o ranking e o evento na tela. No laboratório DEMO você pode testar a mesma normalização sem LIVE.

O conector é comunitário, sem garantia de funcionamento frente a alterações/bloqueios do TikTok. Testes controlados verificam handshake, eventos, erros e limpeza, mas não substituem teste numa transmissão real. Esta sessão não teve conta ao vivo nem credenciais Gemini/ElevenLabs. A rede cloud não tem os domínios desses serviços aplicados; no Termux usa a Internet do aparelho.

## Atualização no Termux

Pare o processo anterior com Ctrl+C na sessão que executa o jogo. Extraia o ZIP atualizado sobre ~/linel-v25; data/ e .env não estão no ZIP, preservando configurações e chaves locais. Depois:

```sh
cd ~/linel-v25/game
bash start.sh
```

Abra http://127.0.0.1:3000 e recarregue a página. Caso use um GLB próprio em data/models, ele continua prevalecendo sobre o modelo incluído e mantém o seu próprio rig; as correções automáticas dos assets incluídos não são aplicadas a GLBs desconhecidos.
