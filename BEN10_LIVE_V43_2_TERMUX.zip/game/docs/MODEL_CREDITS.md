# Modelos 3D de terceiros

Modelos obtidos do repositório público https://github.com/naviniitk/ben10_3d no commit `f86078ce88957be24f41b470c8ba04a4227b0224`. A licença de cada GLB está registrada em asset.extras. Os arquivos foram preservados byte a byte e estão cobertos pela atribuição abaixo e por public/bundled-models/manifest.json. Não são modelos oficiais certificados nem todos possuem animações. Os personagens são de seus titulares; a licença declarada pelos modeladores refere-se ao trabalho distribuído por eles.

## Classic Ben 10 - Ben Tennyson

Autor: Kabiidev (https://sketchfab.com/Kabiidev)

Fonte: https://sketchfab.com/3d-models/classic-ben-10-ben-tennyson-5acf37a253574360ad39dc2dae35383f

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: base.glb. SHA256: `af507215f3aee238a4993eb0c23a06b2919522d25908ad390e94fb3fc4980d96`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## Heatblast of Ben 10 Omniverse

Autor: Arturo.Wimbleton (https://sketchfab.com/Arturo.Wimbleton)

Fonte: https://sketchfab.com/3d-models/heatblast-of-ben-10-omniverse-9b3019a41b594c63b3dc88c4643c2c50

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: blaze.glb. SHA256: `0adfaa9eec6d8dc116a542f3c10fba7e8189fde6edaed8c7284d66c312a79df2`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## XLR8 -Ben 10

Autor: Nathan_zica (https://sketchfab.com/Nathan_zica)

Fonte: https://sketchfab.com/3d-models/xlr8-ben-10-4eb0c3c9eaa04fe6872504d94bec59e7

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: volt.glb. SHA256: `949fdf06e09aabd23a101f976bc8bb19a479edf3f4f9be21b42eea40c9e4fb7a`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## Diamondhead - Ben 10

Autor: thanhtp (https://sketchfab.com/thanhtp)

Fonte: https://sketchfab.com/3d-models/diamondhead-ben-10-14d80a6b70ce4732b35a6bf88899f2cc

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: rock.glb. SHA256: `f3a83383babb32416109e31ab26aea21d55dd9aa4c98f6e5c4dc7abc95149032`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## ghostfreak ben 10

Autor: Shavin vfx (https://sketchfab.com/shavinvfx)

Fonte: https://sketchfab.com/3d-models/ghostfreak-ben-10-0151df455f1b4b80804c14e625a73f49

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: shade.glb. SHA256: `eac050065e56ad10bc2a15708d75c3814b90be7f6845ec7b2c278ead9c8d7953`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## Ripjaws (Ben 10)

Autor: theamazingdonovan207 (https://sketchfab.com/theamazingdonovan207)

Fonte: https://sketchfab.com/3d-models/ripjaws-ben-10-4489444628a746d8a3a2eab1213eb965

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: tide.glb. SHA256: `188c199ba3433aee07a912f9bab28ada1aeb0155720c22be970050d090eb0510`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## Fourarms Ben 10

Autor: aliaalia (https://sketchfab.com/aliaalia)

Fonte: https://sketchfab.com/3d-models/fourarms-ben-10-403ef37d2286413598d9ab86d0570a2e

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: fourarms.glb. SHA256: `2030983434199c50e530b2f8d6130fcf416f25fd92e0c0e53eb0feff51be4201`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## Wildmutt (Ben 10: Vilgax Attacks fan model)

Autor: TacticalNerd1963 (https://sketchfab.com/TacticalNerd1963)

Fonte: https://sketchfab.com/3d-models/wildmutt-ben-10-vilgax-attacks-fan-model-1554c9e1fbe84dfa941ef6f7e697fe7e

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: beast.glb. SHA256: `af9c722ff7e8dde43dd7c0f38586b932cefbff2f1b28b937386a9b71c7dc6fb9`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

## CanonBolt Ben 10

Autor: kimni88 (https://sketchfab.com/gamervlogerkid)

Fonte: https://sketchfab.com/3d-models/canonbolt-ben-10-cdfe791d1b134d16813ec050be70348a

Licença: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Arquivo: cannon.glb. SHA256: `4636bcd102eeac318733678b513600930c5ca78ebe90d4de18eb2216e4df74e0`.

Mudanças: GLB original preservado; escala, orientação, skin/articulações e animações procedurais ajustadas em runtime. Materiais PBR adaptados à iluminação local; GLB original preservado.

