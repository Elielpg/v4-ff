# V41 · Visitantes, conversa e energia do Omnitrix

## Preparar a voz

1. Abra **LIVE → IA e voz**, adicione uma chave Gemini ou selecione uma das já salvas e use **Usar e testar**. O teste de conversa e as perguntas usam a mesma chave e o mesmo modelo selecionado.
2. Na seção de voz, escolha **Gemini · voz IA**, modelo automático e uma voz. **Salvar voz IA** e **Testar voz IA** verificam o áudio separadamente. Outra opção é ElevenLabs com sua própria chave e Voice ID.
3. Toque em **♫** na barra inferior para permitir áudio. Se o navegador bloquear a reprodução, toque novamente e teste.

O modelo automático consulta os modelos TTS disponíveis na chave. Modelos de texto e de áudio são serviços diferentes: texto funcionando não comprova acesso/cota de áudio. Erros de chave, acesso, cota ou conexão aparecem para o operador, com legenda mantida para o público. Não há substituição pela voz do aparelho. Uma configuração antiga com voz do navegador é migrada para Gemini.

O timbre pode variar por forma, usando as vozes disponíveis no provedor e direção em português brasileiro. Não é uma cópia da voz do dublador. As cotas gratuitas e condições podem mudar; não há promessa de voz ilimitada e gratuita. Ativar várias chaves não aumenta automaticamente as cotas do projeto do provedor.

## Conversa e fila

Ben responde à pergunta da pessoa, com nome e até duas trocas recentes por usuário durante dez minutos. As instruções favorecem frases curtas, humor confiante e uma chamada de participação por vez. A memória é temporária, não é salva no ZIP ou no disco. Recepção, agradecimentos e convites usam frases locais variadas, faladas pelo mesmo serviço de voz IA.

Existe uma fila única: um presente promove a pergunta já pendente do apoiador e acrescenta o agradecimento. Uma fala iniciada termina normalmente. Depois de duas falas prioritárias consecutivas, o comentário comum mais antigo tem uma vez, se houver. Há limite de fila e reserva para apoiadores, com aviso quando lota. Isso organiza a interação; não garante que todo comentário em uma LIVE movimentada seja lido.

Novas curtidas são agrupadas. Quando há espaço na fila, Ben comenta a energia ou convida ao TAP TAP, com intervalo mínimo de 25 segundos. Convites em momentos sem interação também respeitam intervalo e esperam a fila. **LIVE → LIVE → Ben recebe visitantes e agradece ao público** permite desligar as falas automáticas, mantendo as perguntas.

## Avatares e câmera

Entradas, comentários, presentes e novos seguidores criam visitantes entre cinco estilos visuais. Nome e foto ficam sobre a cabeça. A foto usa apenas endereços HTTPS reconhecidos de CDNs do TikTok, por uma rota local com limite de tamanho; se não vier pelo conector ou falhar, aparecem as iniciais.

Há até seis visitantes recentes por origem, com substituição dos mais antigos e saída após cinco minutos sem interação. Entradas aproximam a câmera, com limite entre trocas. Apoiadores recebem destaque dourado; uma resposta pode enquadrar Ben e o visitante. A câmera de poderes tem preferência.

Ao seguir, Ben calcula um caminho na clareira, desvia dos obstáculos e acena diante do visitante. Cumprimentos esperam seleção/transformação, poderes, treino e ações de presentes. Comandos explícitos do chat cancelam a caminhada automática. O cumprimento é um aceno próximo, sem contato físico entre as mãos.

Um conector sem evento de entrada/follow ou sem foto não permite mostrar uma chegada que não foi recebida. Teste em **LIVE → Laboratório** ou pelo chat de teste. Fotos e avatares não são persistidos no disco.

## TAP TAP, cenário e poderes

As curtidas recebidas geram um grupo de esferas verdes limitado por qualidade: o efeito representa a energia, não uma esfera para cada curtida. Elas sobem do chão, fazem uma curva e chegam ao relógio original no pulso animado. Nas formas alienígenas, o destino é o emblema do Omnitrix. Luz e som marcam a absorção. A curva e os limites evitam excesso de objetos no celular.

Somente os eventos de curtida alteram o progresso real. Toques locais durante a conexão TikTok fazem uma prévia visual, sem inventar curtidas reais. O alto mostra o próximo alien e o que falta. Chama começa com 100 curtidas; metas e modo livre ficam no Laboratório. O progresso é salvo por origem e preservado pelo atualizador. O presente não passa por cima de um DNA ainda bloqueado.

Em **LIVE → Ajustes → Dia, tarde e noite**, escolha ciclo de dia/tarde/noite entre 3 e 30 minutos, ou fixe um período. O ciclo sincroniza os navegadores conectados, muda céu, luz e ambiente sonoro. O volume de ambiente e o de efeitos continuam separados da voz.

Poderes usam o ponto animado da mão, ou a boca no sopro de fogo, quando disponível. Mantêm antecipação, emissão, impacto e encerramento com efeitos 3D. As transformações mantêm o relógio original, duração da forma e recarga, com verde para pronto e vermelho para descarregado.

## Interface e atualização

Quatro botões ficam embaixo: **Omnitrix**, **Ações**, **LIVE** e **♫**. Poderes, movimento, teste de chat, TAP TAP local e retorno da câmera ficam em Ações. Ranking, ícones e painel de comandos seguem o padrão anterior. Avisos de interação mostram o evento mais recente, longe dos rostos. Sem missões de cidade; continuam as metas coletivas de curtidas, comentários, compartilhamentos e seguidores.

Na pasta instalada, faça backup e atualize:

```sh
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V41_TERMUX.zip --start
```

O atualizador preserva `.env`, chaves e `data/`. O ZIP não contém dados pessoais nem credenciais. Atualize a página e confirme V41. Se quiser iniciar depois: `bash start.sh`.

## Validação e limites

Os testes usam servidores temporários, chaves inventadas e respostas Google offline. O navegador real verifica recepção/foto, caminhada, prioridade, esferas, relógio, poderes, luz e layout. A fixture de voz devolve um WAV sintético de teste; não mede a qualidade de uma voz real. A falha de cota também é exercitada, verificando que a voz do aparelho não é chamada.

Relatórios em `reports/v41/`. Não houve teste com chave Google real, LIVE real ou Android físico. Antes de transmitir, faça os testes de texto/voz da sua chave e uma LIVE de teste no aparelho. As estatísticas do vídeo de referência não foram verificadas; os recursos não garantem visualizações ou seguidores.
