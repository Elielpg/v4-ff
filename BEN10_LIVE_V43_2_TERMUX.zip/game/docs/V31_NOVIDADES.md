# V31 · Mais presentes e efeitos diferentes

A V31 reconhece novas sugestões de presente e combina cada uma com uma ação dentro da aventura. Entre os nomes incluídos estão **GG**, **Rosa / Rose**, **Rosa Branca / White Rose**, **Ice Cream / Sorvete**, **Finger Heart**, **Perfume**, **Heart Me**, **Hand Heart**, **Sunglasses**, **Cap**, **TikTok**, **Lightning Bolt**, **Doughnut**, **Swan**, **Money Gun**, **Lion / Leão**, **Galaxy** e **TikTok Universe / Universo TikTok**.

As ações combinam transformações e poderes de formas diferentes: por exemplo, Rosa Branca leva ao poder Aquático; Perfume e Swan ativam a forma Fantasmático e podem voar; Finger Heart, TikTok e Lightning Bolt ativam a arrancada de XLR8; Heart Me inicia uma missão de resgate; e os presentes maiores podem combinar superpoder e missão. A animação também escolhe um entre três estilos conforme o nome do presente. A pontuação acumulada define a intensidade de 1 a 5 e aumenta escala e duração.

Na primeira inicialização da V31, o catálogo novo é acrescentado às regras já salvas. Regras personalizadas existentes são mantidas; depois, você pode editar ou remover sugestões em **Laboratório → Presentes**. Os nomes precisam corresponder ao nome do presente recebido no evento LIVE. Se um presente vier com uma tradução diferente, adicione esse nome no painel. Os pontos são uma escala interna do jogo — não são preços nem valores atuais de moedas do TikTok.

## Atualizar no Termux

Copie o ZIP recebido para Downloads e rode:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V31_TERMUX.zip --start
```

O atualizador preserva `data/` e `.env`. A conexão e os nomes efetivamente enviados precisam ser confirmados durante uma LIVE real; os testes automatizados verificam a correspondência configurada, a fila e as animações, não a disponibilidade de cada presente em cada região/conta.
