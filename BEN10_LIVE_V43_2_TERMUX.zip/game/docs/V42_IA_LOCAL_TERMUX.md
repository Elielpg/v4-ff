# V42 · Conversa e voz locais no Termux

A integração permite que o Ben gere respostas e voz no celular, sem cadastro nem chave de provedor. O perfil inicial foi escolhido para o Realme GT3 ARM64 com 16 GB de RAM e bastante armazenamento. Não é promessa de ser mais inteligente ou mais natural que Gemini: modelos locais pequenos têm limites, e o desempenho durante a LIVE precisa ser medido no aparelho.

## Componentes

| Função | Componente | Perfil inicial |
| --- | --- | --- |
| Conversa | llama.cpp nativo no Termux | Qwen3-4B-Instruct-2507, Q4_K_M, sem raciocínio longo |
| Voz neural | Piper no Debian isolado pelo proot-distro | pt_BR-faber-medium |
| Perfil leve opcional | llama.cpp | Qwen2.5-1.5B-Instruct, Q4_K_M |

O llama.cpp é compilado para o próprio telefone. Piper/ONNX Runtime usam rodas Linux ARM64 com glibc; o Debian evita tentar instalar essas rodas diretamente no Android/Bionic. O ambiente se chama `ben10-ai` e não substitui outro Debian que você tenha. Não exige root.

A revisão do llama.cpp é `6c01da6278ab6c69ed67d9124806b50d2b299ba7`. Piper 1.8.0 e ONNX Runtime 1.31.1 estão fixados. O instalador consulta os modelos públicos, fixa a revisão retornada e confere SHA-256 de arquivos LFS ou o hash Git dos arquivos pequenos. Os cartões e créditos são baixados junto. Download interrompido pode continuar; arquivo com hash errado não é usado como instalado.

Fontes: [llama.cpp no Android](https://github.com/ggml-org/llama.cpp/blob/6c01da6278ab6c69ed67d9124806b50d2b299ba7/docs/android.md), [API local](https://github.com/ggml-org/llama.cpp/tree/6c01da6278ab6c69ed67d9124806b50d2b299ba7/tools/server), [Piper](https://github.com/OHF-Voice/piper1-gpl/tree/v1.8.0), [Qwen3](https://github.com/QwenLM/Qwen3), [proot-distro](https://github.com/termux/proot-distro).

## Primeira instalação

Atualize a instalação anterior sem iniciar o servidor ainda:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V42_TERMUX.zip
bash local-ai.sh install
bash local-ai.sh start
```

Ajuste a pasta conforme sua instalação. Em uma instalação nova, extraia o ZIP, entre em `game` e execute `bash install.sh` antes de instalar a IA local.

Use Termux ARM64 atualizado, mantenha internet durante a instalação e reserve pelo menos 8 GB livres. O primeiro processo baixa vários GB, instala ferramentas e compila código; não é instantâneo. O ZIP inclui a integração e o instalador, não os pesos da IA. Os modelos públicos usados não precisam de token do Hugging Face.

Os pesos, fontes do llama.cpp e logs ficam em `~/.local/share/ben10-local-ai`. O ambiente Debian fica no armazenamento privado do proot-distro. Não serão incluídos no ZIP do jogo nem no backup comum. O atualizador preserva chaves, `.env`, progresso e modelos personalizados anteriores. Para mudar a pasta local, use a variável de sessão `BEN10_LOCAL_ROOT` tanto na instalação quanto na inicialização.

## Iniciar depois

```sh
cd ~/ben10-v34/game
bash local-ai.sh start
```

O comando carrega os dois modelos, espera os serviços responderem e inicia o jogo. Se o jogo da mesma pasta já estiver rodando, usa essa instância; não encerra um jogo de outra pasta. Seleciona **conversa local e voz local** no painel, sem apagar as chaves antigas. Abra o endereço indicado e toque em **♫**.

Mantenha esta sessão aberta. Ctrl+C encerra somente os processos criados por esse comando. Se já existirem serviços locais ocupando as portas, o comando informa isso; não mata processos encontrados pelo nome. Com os serviços já prontos, `bash start.sh` pode iniciar só o jogo.

A conversa usa quatro threads, contexto de 2048 tokens, respostas curtas e uma geração por vez. Piper usa duas threads de inferência. Não foi configurada aceleração GPU Android; a GPU permanece disponível ao jogo. Isso não elimina a competição por memória, bateria e resfriamento durante uma transmissão.

Se houver atraso ou engasgos, pare a sessão e use o perfil mais leve:

```sh
bash local-ai.sh install --model light
bash local-ai.sh start
```

Esse perfil usa menos memória e cálculo, mas pode responder pior. Os tempos reais devem ser medidos no GT3 com a captura da LIVE ativa.

## Painel e comportamento

Em **LIVE → IA e voz**, escolha **IA no aparelho · sem chave** e **Piper · neural no aparelho**, ou use **Usar conversa e voz locais**. **Verificar serviços locais** informa separadamente conversa e voz. Só aparece **IA LOCAL RESPONDENDO** após uma resposta válida da IA, não apenas porque foi selecionada.

Use **Testar conversa selecionada** e **Testar voz IA** antes de transmitir. O texto e a voz são independentes: um pode estar funcionando enquanto o outro ainda carrega. Sem serviço local, o painel mostra a causa; não pede uma chave Gemini para o modo local e não muda para um serviço online. Frases locais básicas e legendas podem continuar, mas o painel distingue essas frases de uma resposta gerada pela IA.

Ben continua sendo a criança do clássico: brincalhão, confiante, impulsivo e bondoso. A forma real continua nas animações; quem conversa é Ben. O modelo recebe contexto recente curto, informações relevantes do clássico e estado real do relógio/DNA/metas. A fila mantém prioridade dos presentes sem interromper a fala atual.

O Piper recebe exclusivamente a frase, preservando a correção da V41.1. Não recebe a descrição da voz ou instruções de atuação. É uma voz neural pt-BR, não uma gravação nem uma cópia da dublagem do Ben. Nunca usa a voz do aparelho como substituta.

Conversa e voz funcionam sem internet depois de instalar. **A LIVE, fotos dos visitantes e eventos do TikTok continuam dependendo de internet e do conector.**

## Diagnóstico

```sh
bash local-ai.sh status
```

Logs em `~/.local/share/ben10-local-ai/logs/conversa.log` e `voz.log`. Se um modelo/serviço não carregar, confira o log e o espaço livre. Se o Android encerrar o Termux em segundo plano, mantenha a sessão ativa e ajuste o gerenciamento de bateria do Termux no aparelho.

O jogo se comunica apenas por HTTP em `127.0.0.1`: portas 8081 (conversa) e 8082 (voz). Não usa proxy de nuvem, autorização externa nem redirecionamentos. Os serviços não ficam expostos na rede Wi-Fi. O painel do jogo segue os controles locais de Host/Origin anteriores.

## Validação e limites

A integração foi testada com servidores locais simulando as respostas OpenAI compatíveis e o WAV do Piper. O worker Python é exercitado com uma voz de teste, incluindo frase literal, WAV válido e recusa de origem externa. Os hashes e a seleção do arquivo GGUF são verificados com arquivos temporários. O navegador verifica seleção sem chave, pergunta pública, áudio, diagnósticos e ausência da voz do aparelho quando há falha.

Não foram baixados os pesos GGUF/ONNX reais nem executada inferência neural nesta validação cloud. O ambiente não permite acesso aos hosts de pesos. O instalador verifica os repositórios e arquivos no seu telefone durante a primeira instalação. Não houve teste em Android/GT3 físico ou LIVE real. Portanto, qualidade, timbre, consumo e velocidade continuam pendentes de validação no aparelho. Não confunda o áudio sintético da fixture com uma amostra da voz Piper.

Relatórios em `reports/v42/`. Créditos 3D em `MODEL_CREDITS.md`. llama.cpp usa MIT, Piper GPL-3.0 e Qwen3 Apache-2.0. Consulte os cartões/licenças baixados em `licenses/` e `voices/MODEL_CARD` para os arquivos específicos instalados. Guias de versões anteriores são históricos.
