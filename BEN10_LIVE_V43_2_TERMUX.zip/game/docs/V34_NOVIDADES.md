# V34 · Arena Omnitrix LIVE

Atualização do ZIP V33 fornecido pelo usuário. Mantém os modelos Ben 10/aliens, créditos, missões, regras personalizadas, transporte TikTok e atualização local. A referência visual é a composição dos prints: personagem 3D em uma paisagem natural, barra de progressão, comandos, ranking e chamadas de ação. Não é uma reprodução exata do jogo dos prints.

## O que mudou

- Arena original com ilha, água, árvores, rochas e vegetação em geometria low-poly. O botão **Cidade** retorna à estrada e às missões existentes; **Arena** volta ao cenário natural. O herói fica parado na arena quando não há ação, fala ou missão em andamento.
- Câmera frontal para o personagem e enquadramento lateral de combate durante poderes. Impactos têm tremor leve; a preferência de movimento reduzido do sistema desativa esse tremor.
- Barra de energia coletiva da sessão, com seis patamares. Cada evento aceito soma seus pontos; a energia é fornecida pelo servidor e restaurada ao recarregar a página enquanto ele estiver rodando. Reiniciar o servidor zera essa energia, assim como o ranking original. Os níveis são da participação coletiva, não desbloqueios obrigatórios de alien.
- **Alien** percorre as formas; o painel Controles preserva a seleção direta das onze formas, movimentos e os três poderes de cada forma.
- Nove interpretações 3D originais de presentes: chuva de rosas modeladas, coração gigante e corações em órbita, galáxia com anéis e estrelas, confete, raios, totem de leão, chuva de notas, cristais gelados e energia para presentes desconhecidos. Não são os vídeos/arquivos oficiais dos presentes do TikTok.
- Fila visual de até seis presentes aguardando, além do efeito ativo. Sequências são uma animação com sua quantidade final. Quando a fila visual está cheia, o HUD informa que os pontos foram registrados. A fila existente de ações/poderes continua independente, com até oito ações; saturação também gera aviso.
- Sons originais sintetizados no aparelho: transformação, subida de nível, presentes e famílias de poder (fogo, água, eletricidade, cósmico e impacto). Não há gravações oficiais ou download de sons. O volume segue o controle Efeitos e cai durante falas.
- Treino com sentinela de pedra, reação ao contato e barra de resistência. Cada prévia demonstra um golpe e volta à sessão. **TREINAR** no chat também pede essa demonstração, se não houver fala ou outro treino em andamento.
- **Modo LIVE** abre por padrão com a interface inferior recolhida, para deixar o personagem visível; **Controles** a recupera. O painel de conexão, áudio e laboratório continuam disponíveis pelo botão ☷. A posição da interface é salva por aparelho.
- Os SVGs do painel antigo agora têm o tipo MIME correto, evitando ícones quebrados em navegadores que aplicam `nosniff`.

## Usar no Termux

Descompacte e entre na pasta `game`:

```sh
bash install.sh
bash start.sh
```

Abra o endereço que o terminal indicar no Chrome do mesmo aparelho. Confira **V34 / 34.0.0**. Toque em **♫** para liberar o som. Para um aparelho mais lento, selecione **☷ → Ajustes → Qualidade → Econômico**. Não feche o Termux enquanto joga.

**🎁 Testar presente** dispara uma demonstração local, sem comprar ou enviar presentes ao TikTok, alternando oito presentes. A indicação DEMO LOCAL identifica esses eventos. Para outro nome/quantidade, use o laboratório ou um evento real.

Para atualizar uma instalação existente preservando `data/` e `.env`, use o atualizador do ZIP:

```sh
bash update.sh --archive /caminho/BEN10_LIVE_V34_TERMUX.zip --start
```

Use um caminho real do aparelho. Faça backup antes de atualizar (`bash backup.sh`). É necessário permitir acesso ao armazenamento no Termux se o ZIP estiver em Downloads. Nenhuma chave pessoal acompanha esta distribuição.

## Limites da validação

Os resultados atuais ficam em `reports/v34/`. Testes do conector usam transporte controlado; conexão e presentes de uma LIVE real, captura/transmissão pelo TikTok, desempenho em Android físico, Gemini e ElevenLabs dependem do aparelho/conta e não foram comprovados nesta atualização. O modo de demonstração, os modelos e os efeitos locais funcionam sem chaves de IA. O acesso real ao TikTok continua usando os conectores comunitários já existentes.
