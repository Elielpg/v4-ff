# V42.1 · Reparo da instalação local no Termux

O log com `NO_PUBKEY 5A897D96E57CF20C` mostra uma falha no repositório extra `termux-glibc`. A atualização do jogo já terminou, mas a IA local parou antes de instalar ferramentas/modelos. Por isso `local-ai.sh start` diz "Instale primeiro". A mensagem de `.env` ausente não era a causa: IA local não exige chave nem esse arquivo.

O instalador da V42 chamava `pkg install` para todas as ferramentas, consultando também fontes extras. A correção verifica quais ferramentas faltam. Se todas estiverem prontas, não consulta APT. Se faltar alguma, usa uma lista temporária contendo somente o repositório principal oficial. Preserva `https://termux.net` ou `https://packages.termux.dev/apt/termux-main` já configurado, incluindo `Signed-By`; se não encontrar uma dessas entradas oficiais, usa o endereço padrão `termux-main`. Listas/cache de metadados ficam temporários, com validação de assinaturas habilitada. Não edita `sources.list`, `.list`, `.sources`, keyrings ou listas anteriores. Não usa `trusted=yes`, não aceita pacotes não autenticados e não importa chaves de origem desconhecida. Se o oficial também falhar na assinatura, interrompe.

Isso corrige a instalação do projeto sem reparar ou remover a fonte extra glibc para outros usos. Seus comandos gerais `pkg` podem continuar mostrando o erro dessa fonte até ela ser corrigida separadamente. A IA do projeto usa o repositório oficial e o Debian próprio já planejado.

## Quem já atualizou para V42

Não precisa baixar o projeto inteiro. Baixe `BEN10_REPARO_IA_V42_1.zip` e rode na pasta do jogo:

```sh
cd ~/ben10-v34/game
python3 -m zipfile -e ~/storage/downloads/BEN10_REPARO_IA_V42_1.zip "$TMPDIR/ben10-reparo-42-1" &&
bash "$TMPDIR/ben10-reparo-42-1/REPARAR_IA_LOCAL_V42_1.sh" &&
bash local-ai.sh install &&
bash local-ai.sh start
```

Ajuste o caminho se sua instalação tiver outro nome. Os `&&` fazem a sequência parar se uma etapa falhar. A instalação inicial ainda baixa vários GB e compila o modelo; mantenha a internet até terminar.

O reparo é autônomo, sem downloads adicionais de scripts. Confere o nome/versão do projeto, hashes e sintaxe; depois usa o atualizador existente para substituir somente quatro scripts. Faz backup deles em `data/installer-backups/`. `.env`, chaves, progresso, modelos e fontes APT são preservados. O script não instala modelos nem inicia serviços sozinho: os dois comandos seguintes fazem isso.

O reparo não muda o número da versão da interface já instalada. A V42.0 no topo pode permanecer após aplicar só o reparo do instalador; isso é esperado. O `.env` existente continua sendo carregado, e sua ausência deixa de gerar aviso.

## Instalação completa atualizada

O ZIP completo `BEN10_LIVE_V42_1_TERMUX.zip` já contém a correção. Para atualizar:

```sh
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V42_1_TERMUX.zip
bash local-ai.sh install && bash local-ai.sh start
```

Neste caso a interface mostra V42.1 / 42.1.0. Em instalação nova, execute `bash install.sh` antes dos comandos de IA. Não use `--start` no atualizador antes de instalar os modelos locais.

## Verificação

Os testes reproduzem o erro de chave extra usando APT simulado, confirmam que só o oficial é consultado, que fontes/listas originais não mudam e que uma assinatura oficial inválida ainda bloqueia tudo. Exercitam o instalador até o ponto de download, sem baixar modelos. Testam o reparo autônomo em uma V42 fictícia, seus backups e a preservação de dados, além dos dois casos com/sem `.env`.

Não houve instalação de pacotes no telefone ou inferência neural real nesta validação. O acesso do seu Termux ao repositório oficial e aos pesos será confirmado durante a instalação. O restante da validação de IA local continua com serviços simulados. Relatórios atuais em `reports/v42_1/`; guia de uso em `V42_IA_LOCAL_TERMUX.md`.
