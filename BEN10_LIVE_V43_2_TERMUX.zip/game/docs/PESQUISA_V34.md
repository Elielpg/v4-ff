# Referências utilizadas na V34

1. Prints enviados pelo usuário: composição vertical, barra de energia, personagem em destaque, paisagem natural, treinamento contra um boneco, comandos e chamadas de presentes. A implementação mantém Ben 10 e usa cenário e efeitos procedurais próprios.
2. Documentação pública do TikTok Live Connector: https://github.com/zerodytrash/TikTok-Live-Connector — README consultado durante a atualização; aponta a referência atual de eventos em https://ttlc.docs.isaackogan.com/events/gifts-and-goals/#gift . A dependência foi mantida na versão fixada pelo projeto, sem migração de transporte.
3. Referência da versão 2.5.0 incluída no ZIP: `third_party/tiktok-live-connector-2.5.0/README.md`, seção `gift`. Explica que presentes de tipo 1 emitem atualizações com `repeatCount` e uma confirmação `repeatEnd: true`, inclusive quando enviados uma única vez. Mantido o processamento só do resultado final e a deduplicação por ID, com testes de regressão.
4. Babylon.js 9.32.1 e seus loaders já fixados no lockfile: as novas geometrias usam MeshBuilder, TransformNode e StandardMaterial da distribuição local. A arena mescla geometria por material e reduz o número de partículas no modo econômico. Não usa CDN no runtime.
5. Web Audio API do Chrome: sons são criados por osciladores, envelopes de ganho e ruído filtrado; dependem de um gesto do usuário para liberar o AudioContext. Sem extração de áudio, personagens ou animações do jogo de referência/TikTok.

As referências não garantem acesso atual ao serviço TikTok nem ao catálogo de presentes de cada região. Os nomes das regras podem ser ajustados no Laboratório e os pontos são apenas energia do jogo, sem cotação oficial de moedas.
