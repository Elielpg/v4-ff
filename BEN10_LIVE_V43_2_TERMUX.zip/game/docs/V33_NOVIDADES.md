# V33 · Interações visuais, missões e caminhada

O HUD agora mantém um painel compacto de participação do público. Os cartões sobem com uma transição curta e mostram imagens vetoriais locais para presentes e comandos: o presente Rose/Rosa padrão ilustra Chama + poder; regras personalizadas atualizam o cartão automaticamente. O evento recebido também aparece com o nome do visitante e a ação indicada, sem depender só de emojis.

O quadro de missões usa imagens por categoria, mostra melhor a forma ligada ao pedido e ganhou uma barra visual de progresso no HUD. A caminhada recebe um pouco mais de elevação de pé, balanço de braço e movimento de quadril; os nove modelos GLB e suas licenças foram preservados.

## Atualização no Termux

Extraia o ZIP sobre a instalação existente e execute:

```sh
cd ~/linel-v25/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V33_TERMUX.zip --start
```

O atualizador preserva `.env` e `data/`. Confirme **v33.0.0** no topo do jogo. O teste final de desempenho visual ainda deve ser feito no aparelho Android que será usado na LIVE.
