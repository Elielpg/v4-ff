# Android / Termux

Use uma distribuição atual do Termux (F-Droid ou release oficial), Android com Chrome atualizado. Não requer root, Docker, PC ou VPS. Copie a pasta `game` para o diretório privado do Termux (evite executar diretamente em armazenamento compartilhado).

1. Execute `bash install.sh`. Instala Node LTS e Python pelo `pkg`, dependências pelo lockfile e arquivos Babylon locais. A primeira instalação exige Internet.
2. Para Gemini, cadastre as chaves em Painel → IA e voz e selecione qual usar. Alternativamente copie `.env.example` para `.env` e configure uma chave no servidor. Nunca publique esse arquivo. `PORT` é configurável; o host permanece 127.0.0.1.
3. Execute `bash start.sh` e abra o servidor no Chrome do mesmo Android. Libere áudio com um toque; escolha uma voz PT-BR instalada. Mantenha Termux ativo durante a transmissão.
4. Execute `bash doctor.sh` em outra sessão. `bash backup.sh` salva regras e GLB sem `.env`.

Se `pkg` informar versão antiga de Node, atualize os índices e pacotes do Termux pelos mecanismos oficiais. É necessário Node >=22.19. Não altere validação TLS nem checksums.

O perfil Econômico reduz NPCs, resolução e atualizações de sombra. Equilibrado é o padrão. Alto aumenta a resolução. O desempenho de 30 FPS no Realme GT3 NÃO FOI VALIDADO. Teste em uma transmissão de pelo menos 20 minutos, observando temperatura, áudio e consumo. Android pode suspender tarefas em segundo plano; desative a otimização de bateria para Termux se necessário.

Na restauração de um ambiente cloud, processos não persistem: inicie novamente `bash start.sh`. Cada tarefa já tem checkout isolado; use o checkout existente, sem criar worktree.

## Porta ocupada (EADDRINUSE)

Significa que já existe um processo escutando nessa porta. Se for o jogo, abra o endereço que ele já informou. Para atualizar o código, vá à sessão antiga do Termux, pressione Ctrl+C e só então inicie a nova versão. Não use um comando genérico para matar todos os processos Node.

Como alternativa explícita: `PORT=3001 bash start.sh`, depois abra a porta 3001 no Chrome do mesmo aparelho. Nessa sessão, o diagnóstico correspondente é `PORT=3001 bash doctor.sh`. Duas instâncias compartilham os arquivos locais, então prefira encerrar a antiga antes de fazer alterações de configuração.

A versão revisada reconhece EADDRINUSE, consulta o health local e mostra uma orientação curta, sem stack de erro. Não encerra processos alheios nem altera a porta silenciosamente.
