# V37 · Interface anterior recuperada

Esta atualização corrige a mudança visual excessiva da V36. Mantém a clareira, movimento livre, chat/presentes, três poderes por forma e o ciclo temporizado do Omnitrix. Cidade e missões continuam fora do jogo ativo.

## O padrão recuperado

- Cabeçalho com a marca verde e ícone, no padrão visual da V35.
- Barra de energia coletiva com nível circular, título e progresso. O tempo de carga do relógio fica em uma faixa própria, sem substituir a energia da LIVE.
- Ranking **🏆 TOP DA LIVE**, medalhas 🥇/🥈/🥉, nomes, níveis e barras de progresso. Os botões recolher/ocultar voltaram, e o ranking completo está na aba Ranking. Em Ajustes é possível reexibir o quadro.
- Painel permanente **💬 COMANDE NO CHAT**, com os mesmos seis comandos em pílulas: PULAR, CORRER, VOAR, TREINAR, CHAMA e PODER. Um toque no título abre os detalhes de movimento livre e poderes 1/2/3. TREINAR usa um poder da forma atual; não reativa missões.
- Ícones das onze formas no padrão anterior. O botão **Controles** abre/recolhe a faixa de ícones; as escolhas respeitam a seleção e a recarga do relógio.
- Alertas de chegada, presentes, curtidas, seguidores e compartilhamentos voltam a ter os ícones e cartões do padrão anterior. Os slides de presentes são preservados.

## Relógio original

A malha original do Omnitrix do GLB do Ben foi mantida, incluindo pulseira, caixa, desenho e textura. O símbolo flutuante acrescentado na V36 foi retirado. Durante a recarga, uma variante de textura troca somente os pixels verdes do próprio relógio para vermelho, preservando partes cinzas/pretas e transparência. Ao carregar, a textura original retorna. O arquivo GLB armazenado permanece intacto.

O ícone do relógio no painel também recebeu caixa cinza, aro escuro, detalhes e o símbolo clássico. Continua mostrando o tempo restante e o estado verde/vermelho. Os tempos e regras da V36 são preservados: padrão de 45 segundos por carga, 18 segundos de recarga e intervalo entre seleções, ajustáveis no painel.

## Transformações e poderes

Os três anéis e dez faíscas da transformação anterior foram preservados. Acrescentam-se uma hélice de partículas em torno do personagem e um selo do Omnitrix no chão, com fade e cores correspondentes ao estado. A postura de seleção/ativação e os sons continuam sincronizados com o relógio.

Os poderes mantêm as habilidades, coreografias e desenhos anteriores, com partículas luminosas adicionais na preparação, lançamento e impacto. O modo Econômico reduz a capacidade de partículas. Os recursos são liberados ao encerrar cada efeito, e uma única textura luminosa é compartilhada. O painel de poderes usa cartões com os ícones das formas, nomes e os comandos 1/2/3.

## Atualizar

Depois de baixar o ZIP no celular, na pasta usada desde a V34:

```sh
cd ~/ben10-v34/game
bash backup.sh
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V37_TERMUX.zip --start
```

Use sua pasta real se instalou em outro local. O atualizador preserva `data/` e `.env`, incluindo chaves e regras pessoais. Confira **V37 / 37.0.0** no Chrome e ative ♫. Para instalação nova: extraia, entre em `game`, execute `bash install.sh` e `bash start.sh`.

## Verificação

Resultados em `reports/v37/`: ícones, ranking/medalhas/progresso, recolher/ocultar/restaurar, painel de comandos sempre visível, seleção, transformação, poderes, relógio original vermelho/verde e telas de 360 px/retrato/paisagem. Os testes de geometria confirmam que o relógio original não é substituído nem redimensionado; testes de pixels preservam caixa/pulseira. Testes de efeitos verificam descarte de partículas e materiais.

A validação usa Chromium Linux e eventos simulados. LIVE TikTok real, vozes de serviços externos e desempenho em Android físico continuam precisando de teste no aparelho/conta. Os créditos/licenças das malhas originais são preservados; efeitos novos são procedurais e não usam gravações da dublagem.
