import {POWER_TIMINGS} from '../public/power-timeline.js';
import {FORM_IDS,POWERS,powerAbility} from '../public/transformations.js';
import {CITIES_BY_ID,MOVEMENT_PRESETS,canMove,routePosition,cityForDistance,nextCityDistance} from '../public/traversal.js';
import {MISSION_CATALOG,MISSION_KINDS,offersForCity} from '../public/mission-catalog.js';
import {OBJECT_KINDS,compatibleMission,validateMission} from './missions.js';
export const MISSIONS=MISSION_CATALOG;
const clone=value=>value===null?null:JSON.parse(JSON.stringify(value));
const near=(a,b,r=3)=>Math.hypot(a[0]-b[0],a[2]-b[2])<=r;
const modeFor=form=>form==='volt'?'dash':'run';
export class Adventure{
 constructor({now=Date.now(),onChange=()=>{},missionFactory=null,random=Math.random}={}){
  Object.assign(this,{missionFactory,random,onChange,missionPromise:null,missionState:{status:'idle',mode:'local',warning:null},history:[],completedHistory:[],completedByCity:{},revision:0,city:'bellwood',motion:null,pendingMovement:null,nextMovement:0,form:'base',pending:null,pendingPower:null,lastTransform:-Infinity,nextTransform:now+90000,expires:Infinity,nextMission:now+45000,quest:null,completed:0,power:null,nextPower:0,gesture:null,nextGesture:0,position:[0,0,0],sequence:0,lastLocateAt:now,acceptedDistance:0,externalActionUntil:0,missionToken:0,busy:false});
  this.options={autoTransform:true,autoMissions:true,autoPowers:true,npcSpeech:true,transformSeconds:90,missionSeconds:45};
 }
 snapshot(){return {city:this.city,worldDistance:this.position[2],acceptedDistance:this.acceptedDistance,offers:offersForCity(this.city),missionKinds:MISSION_KINDS,history:clone(this.completedHistory),completedByCity:{...this.completedByCity},motion:clone(this.motion),pendingMovement:clone(this.pendingMovement),pendingPower:clone(this.pendingPower),nextPower:this.nextPower,nextMovement:this.nextMovement,externalActionUntil:this.externalActionUntil,missionState:{...this.missionState},revision:this.revision,options:{...this.options},form:this.form,pending:clone(this.pending),quest:clone(this.quest),completed:this.completed,power:clone(this.power),gesture:clone(this.gesture),position:[...this.position]};}
 emit(){this.revision++;this.onChange(this.snapshot());}
 configure(data,now=Date.now()){for(const key of ['autoTransform','autoMissions','autoPowers','npcSpeech'])if(typeof data[key]==='boolean')this.options[key]=data[key];for(const key of ['transformSeconds','missionSeconds'])if(data[key]!==undefined){if(!Number.isFinite(data[key])||data[key]<15||data[key]>600)throw Error('Intervalo precisa estar entre 15 e 600 segundos');this.options[key]=data[key];}this.nextTransform=now+this.options.transformSeconds*1000;this.nextMission=now+this.options.missionSeconds*1000;this.emit();}
 locate(position,now=Date.now()){
  if(!Array.isArray(position)||position.length!==3||!position.every(value=>Number.isFinite(value)&&Math.abs(value)<=Number.MAX_SAFE_INTEGER)||Math.abs(position[0])>9||position[1]<-.3||position[1]>10||position[2]<0)throw Error('Posição fora da via linear');
  const dt=Math.max(0,(now-this.lastLocateAt)/1000),dz=position[2]-this.position[2],dx=Math.abs(position[0]-this.position[0]);
  // Reject teleports before replacing the accepted position or counting any objective.
  if(dz>48*Math.min(dt,10)+2.2||dz<-(8*Math.min(dt,10)+1.5)||dx>8*Math.min(dt,10)+1.5)throw Error('Deslocamento inválido; recarregue para sincronizar a posição');
  const elapsed=Math.min(dt,1.5),oldCity=this.city,before=this.quest?JSON.stringify(this.quest):null;
  this.position=[position[0],Math.max(0,position[1]),position[2]];this.lastLocateAt=now;this.acceptedDistance+=Math.max(0,dz);this.city=cityForDistance(position[2]).id;
  const q=this.quest;
  if(q?.status==='active'&&this.form===q.form&&!this.busy){
   if(q.stage==='travel'){
    q.travel.distance=Math.min(q.travel.requiredDistance,q.travel.distance+Math.max(0,dz));if(q.travel.mode==='fly')q.travel.peakY=Math.max(q.travel.peakY,position[1]);
    if(near(position,q.position)&&q.travel.distance>=q.travel.requiredDistance*.82&&(q.travel.mode!=='fly'||q.travel.peakY>=1)){q.stage='objective';q.travel.arrived=true;this.enterObjective(q,now);}
   }else if(q.stage==='objective')this.observeObjective(q,now,elapsed,Math.max(0,dz));
  }
  if(oldCity!==this.city||before!==(q?JSON.stringify(q):null))this.emit();
  return this.snapshot();
 }
 requestMovement(mode,now=Date.now()){
  if(!Object.hasOwn(MOVEMENT_PRESETS,mode))throw Error('Movimento inválido');if(now<this.nextMovement)throw Error('Movimento recarregando');
  const form=mode==='dash'?'volt':mode==='fly'?(canMove(this.form,'fly')?this.form:'blaze'):this.pending?.form||this.form;
  this.pendingMovement={mode,form,expires:now+30000};if(form!==this.form)this.requestTransform(form,'movement');this.emit();return this.snapshot();
 }
 startMovement(mode,now=Date.now()){
  if(!canMove(this.form,mode))throw Error('Esta forma não pode usar este movimento');const preset=MOVEMENT_PRESETS[mode];this.nextMovement=now+preset.cooldown;
  this.motion={id:++this.sequence,mode,form:this.form,at:now,duration:preset.duration,status:'active',paused:false,fromX:this.position[0],toX:this.position[0],fromZ:this.position[2],toZ:this.position[2]+preset.distance,cityId:this.city,distance:preset.distance};this.emit();return this.motion;
 }
 requestTransform(form,source='chat'){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pending={form,source};this.emit();}
 requestGesture(kind,now=Date.now()){if(!['wave','cheer','jump'].includes(kind))throw Error('Gesto inválido');if(now<this.nextGesture)throw Error('Gesto recarregando; tente novamente em instantes');this.gesture={id:++this.sequence,kind,at:now,until:now+1800};this.nextGesture=now+900;this.emit();return this.snapshot();}
 requestPower(form=this.pending?.form||this.form,now=Date.now()){if(!FORM_IDS.includes(form))throw Error('Forma inválida');this.pendingPower={form,expires:now+15000};this.emit();}
 holdExternalAction(until){if(!Number.isFinite(until))throw Error('Prazo da ação inválido');this.externalActionUntil=Math.max(this.externalActionUntil,until);}
 startMission(now=Date.now(),selection={}){
  if(this.quest?.status==='active')return this.quest;if(this.missionPromise)return this.missionPromise;if(typeof selection==='string')selection={missionKey:selection};
  const token=++this.missionToken;if(selection.kind&&!Object.hasOwn(MISSION_KINDS,selection.kind))throw Error('Tipo de missão inválido');
  const selected=selection.missionKey?MISSIONS.find(spec=>spec.key===selection.missionKey):null;if(selection.missionKey&&!selected)throw Error('Missão inexistente');
  const fallback=()=>{let pool=MISSIONS.filter(spec=>spec.city===this.city&&(!selection.kind||spec.kind===selection.kind));const fresh=pool.filter(spec=>!this.history.slice(-6).includes(spec.key));if(fresh.length)pool=fresh;return {...(selected||pool[Math.min(pool.length-1,Math.floor(this.random()*pool.length))]),generatedBy:'local'};};
  const finish=(spec,warning=null)=>{
   if(token!==this.missionToken)return null;
   spec={...spec,...validateMission(spec),generatedBy:spec.generatedBy||'local'};if(selection.kind&&spec.kind!==selection.kind)throw Error('Tipo diferente da missão solicitada');
   if(!spec||!FORM_IDS.includes(spec.form)||typeof spec.title!=='string')throw Error('Resposta de missão inválida');const kind=spec.kind||OBJECT_KINDS[spec.object];if(!compatibleMission(kind,spec.form,spec.object))throw Error('Mecânica de missão inválida');
   const requestedCity=spec.travel?.city||spec.city||this.city,base=nextCityDistance(this.position[2],requestedCity),distance=selected?34:30+Math.floor(this.random()*22),spawnZ=base+distance,mode=spec.travelMode||spec.travel?.mode||modeFor(spec.form);
   const totals={repair:2,fire:3,rescue:2,escort:35,delivery:2,race:3,search:2,defense:3};
   this.quest={...spec,key:spec.key||'generated:'+this.sequence,kind,id:++this.sequence,city:cityForDistance(spawnZ).id,position:routePosition(spawnZ),origin:routePosition(spawnZ),stage:'travel',travel:{mode,city:cityForDistance(spawnZ).id,fromCity:this.city,requiredDistance:spawnZ-this.position[2],distance:0,peakY:0,arrived:false},goal:{phase:'arrival',mode,label:'Chegue ao local do pedido de ajuda',distance:0,requiredDistance:0,heldMs:0,requiredMs:0,targetIndex:0},progress:0,total:totals[kind],status:'active',started:now,objectiveHint:MISSION_KINDS[kind].instruction};
   this.history.push(spec.key||spec.title);this.history=this.history.slice(-12);this.missionState={status:'ready',mode:spec.generatedBy||'local',warning};this.emit();return this.quest;
  };
  if(selected)return finish(fallback());let generated;try{generated=this.missionFactory?.({previous:[...this.history],city:this.city,kind:selection.kind});}catch(error){return finish(fallback(),error.message);}if(!generated)return finish(fallback());
  this.missionState={status:'generating',mode:'gemini',warning:null};this.emit();this.missionPromise=Promise.resolve(generated).then(spec=>finish(spec)).catch(error=>finish(fallback(),'IA indisponível: '+String(error.message).slice(0,140))).finally(()=>{if(token===this.missionToken)this.missionPromise=null;});return this.missionPromise;
 }
 abandonMission(now=Date.now()){
  this.missionToken++;this.missionPromise=null;this.nextMission=now+this.options.missionSeconds*1000;if(this.missionState.status==='generating'){this.missionState={status:'idle',mode:'local',warning:null};this.emit();}
  if(this.quest?.status==='active'){this.quest.status='abandoned';this.quest.stage='abandoned';this.quest.goal.label='Missão encerrada sem recompensa';this.pendingPower=null;this.nextMission=now+this.options.missionSeconds*1000;this.emit();}return this.snapshot();
 }
 cancelMission(now=Date.now()){return this.abandonMission(now);}
 enterObjective(q,now){
  const phases={repair:'repair',fire:'extinguish',rescue:'release',escort:'escort',delivery:'pickup',race:'race',search:'scan',defense:'defend'};q.goal.phase=phases[q.kind];q.goal.label=MISSION_KINDS[q.kind].instruction;q.goal.started=now;
  if(q.kind==='escort'){q.goal.fromZ=q.position[2];q.goal.requiredDistance=35;q.position[2]+=35;}
  if(q.kind==='race'){q.goal.fromZ=q.position[2];q.goal.requiredDistance=25;q.goal.deadline=now+30000;q.position[2]+=25;}
  if(q.kind==='delivery'){q.goal.requiredMs=900;q.goal.label='Aguarde junto à encomenda para recolhê-la';}
  if(q.kind==='defense'){q.goal.requiredMs=5000;q.goal.hits=0;}
 }
 complete(q,now){if(q.status!=='active')return;q.status='complete';q.stage='complete';q.goal.label='Missão concluída';q.progress=q.total;this.completed++;this.completedByCity[q.city]=(this.completedByCity[q.city]||0)+1;this.completedHistory.unshift({id:q.id,key:q.key,title:q.title,kind:q.kind,city:q.city,completedAt:now});this.completedHistory=this.completedHistory.slice(0,6);this.nextMission=now+this.options.missionSeconds*1000;}
 observeObjective(q,now,elapsed,dz){
  const g=q.goal,atTarget=near(this.position,q.position),moving=['escort','delivery','race'].includes(g.phase);
  if(moving)g.distance=Math.min(g.requiredDistance,g.distance+dz);
  if(q.kind==='escort'||q.kind==='rescue'&&g.phase==='escort'){
   q.progress=q.kind==='escort'?Math.floor(g.distance):1;if(atTarget&&g.distance>=g.requiredDistance*.82)this.complete(q,now);
  }else if(q.kind==='delivery'){
   if(g.phase==='pickup'&&atTarget){g.heldMs+=elapsed*1000;if(g.heldMs>=g.requiredMs){q.progress=1;g.phase='delivery';g.label='Transporte a encomenda até o destinatário';g.distance=0;g.requiredDistance=42;g.heldMs=0;g.fromZ=q.position[2];q.position[2]+=42;}}
   else if(g.phase==='delivery'&&atTarget&&g.distance>=g.requiredDistance*.82){g.heldMs+=elapsed*1000;g.label='Aguarde a confirmação da entrega';if(g.heldMs>=g.requiredMs)this.complete(q,now);}
  }else if(q.kind==='race'){
   if(g.pausedAt===undefined&&now>g.deadline){q.status='failed';q.stage='failed';g.label='Tempo esgotado; tente outro circuito';this.nextMission=now+this.options.missionSeconds*1000;}
   else if(atTarget&&g.distance>=g.requiredDistance*.82){q.progress++;if(q.progress>=q.total)this.complete(q,now);else{g.distance=0;g.targetIndex++;g.fromZ=q.position[2];q.position[2]+=25;}}
  }else if(q.kind==='defense'){
   if(atTarget)g.heldMs+=elapsed*1000;q.progress=Math.min(2,g.hits||0);if((g.hits||0)>=2&&g.heldMs>=g.requiredMs)this.complete(q,now);
  }
 }
 usePower(now=Date.now(),busy=false,strength=1,variant=0){
  if(busy)throw Error('Aguarde a fala terminar');if(now<this.nextPower)throw Error('Poder recarregando');const powerLevel=Math.max(1,Math.min(5,Math.floor(Number(strength)||1))),duration=Math.round((POWER_TIMINGS[this.form]||POWER_TIMINGS.base).reduce((a,b)=>a+b,0)*1000*(1+(powerLevel-1)*.22));this.nextPower=now+Math.max(2500,duration+100);let result='Efeito livre';const q=this.quest;
  if(q?.status==='active'){
   if(q.stage==='travel')result='Chegue ao destino da missão primeiro';else if(this.form!==q.form)result='A missão precisa de outra forma';else if(!near(this.position,q.position,4.5))result='Aproxime-se do objetivo';else{
    const g=q.goal;
    if(q.kind==='repair'){q.progress++;result='Estrutura reforçada';if(q.progress>=q.total)this.complete(q,now);}
    else if(q.kind==='fire'){q.progress++;result='Foco apagado';if(q.progress>=q.total)this.complete(q,now);else{g.targetIndex++;q.position[2]+=6;}}
    else if(q.kind==='search'){q.progress++;result='Pista encontrada';if(q.progress>=q.total)this.complete(q,now);else{g.targetIndex++;q.position[2]+=12;}}
    else if(q.kind==='rescue'&&g.phase==='release'){q.progress=1;g.phase='escort';g.label='Acompanhe o morador até o ponto seguro';g.distance=0;g.requiredDistance=28;g.fromZ=q.position[2];q.position[2]+=28;result='Morador liberado; acompanhe-o';}
    else if(q.kind==='defense'){g.hits=Math.min(2,(g.hits||0)+1);q.progress=g.hits;result='Área protegida; permaneça por perto';if(g.hits>=2&&g.heldMs>=g.requiredMs)this.complete(q,now);}
    else result='Esta etapa precisa de deslocamento ou presença, não de poder';
    if(q.status==='complete')result='Missão concluída';
   }
  }
    const selectedVariant=Math.abs(Math.floor(Number(variant)||0))%3,ability=powerAbility(this.form,selectedVariant);
    this.power={id:++this.sequence,form:this.form,name:ability?.name||POWERS[this.form].name,ability:ability?.id||this.form,position:[...this.position],at:now,duration,strength:powerLevel,variant:selectedVariant,result};this.emit();return this.power;
 }
 tick(now=Date.now(),busy=false){
  this.busy=busy;const timedQuest=this.quest;if(timedQuest?.status==='active'&&timedQuest.kind==='race'&&timedQuest.stage==='objective'){const goal=timedQuest.goal;if(busy||now<this.externalActionUntil){if(goal.pausedAt===undefined){goal.pausedAt=now;this.emit();}}else{if(goal.pausedAt!==undefined){goal.deadline+=Math.max(0,now-goal.pausedAt);delete goal.pausedAt;this.emit();}if(now>goal.deadline){timedQuest.status='failed';timedQuest.stage='failed';goal.label='Tempo esgotado; tente outro circuito';this.nextMission=now+this.options.missionSeconds*1000;this.emit();}}}
  if(this.gesture){if(busy)this.gesture.pausedAt??=now;else{if(this.gesture.pausedAt!==undefined){this.gesture.until+=Math.max(0,now-this.gesture.pausedAt);delete this.gesture.pausedAt;this.emit();}if(now>=this.gesture.until){this.gesture=null;this.emit();}}}
  if(this.motion?.status==='active'){if(busy&&!this.motion.paused){this.motion.paused=true;this.motion.pausedAt=now;this.emit();}else if(!busy&&this.motion.paused){this.motion.at+=Math.max(0,now-this.motion.pausedAt);delete this.motion.pausedAt;this.motion.paused=false;this.emit();}if(!this.motion.paused&&now-this.motion.at>=this.motion.duration){this.motion.status='complete';this.emit();}}
  if(busy)return;
  if(this.pending&&(!['mission','automatic','watch-timeout'].includes(this.pending.source)||now>=this.externalActionUntil)&&(this.pending.source==='operator'||this.pending.source==='gift'||now-this.lastTransform>=8000)){if(this.motion?.status==='active'&&this.motion.form!==this.pending.form){this.motion.status='complete';this.motion.cancelled=true;this.motion.paused=false;}this.form=this.pending.form;this.pending=null;this.lastTransform=now;this.expires=this.form==='base'?Infinity:now+60000;this.nextTransform=now+this.options.transformSeconds*1000;this.emit();}
  if(this.pendingMovement){if(now>this.pendingMovement.expires){this.pendingMovement=null;this.emit();}else if(this.pendingMovement.form===this.form&&now>=this.nextMovement&&this.motion?.status!=='active'){const {mode}=this.pendingMovement;this.pendingMovement=null;this.startMovement(mode,now);}}
  if(this.pendingPower){if(now>this.pendingPower.expires)this.pendingPower=null;else if(this.pendingPower.form===this.form&&now>=this.nextPower){this.pendingPower=null;this.usePower(now);}}
  if(now>=this.externalActionUntil&&this.options.autoMissions&&now>=this.nextMission&&this.quest?.status!=='active')this.startMission(now);
  if(now<this.externalActionUntil)return;
  const q=this.quest;if(q?.status==='active'){
   if(this.options.autoTransform&&this.form!==q.form&&!this.pending&&now-q.started>=1500)this.requestTransform(q.form,'mission');
   const needsPower=q.stage==='objective'&&['repair','fire','search','rescue','defense'].includes(q.kind)&&!(q.kind==='rescue'&&q.goal.phase==='escort')&&!(q.kind==='defense'&&q.goal.hits>=2);
   if(needsPower&&this.options.autoPowers&&this.form===q.form&&now>=this.nextPower&&near(this.position,q.position,4.5))this.usePower(now);
  }else if(!this.pending&&!this.pendingMovement&&this.motion?.status!=='active'){if(this.form!=='base'&&now>=this.expires)this.requestTransform('base','watch-timeout');else if(this.options.autoTransform&&now>=this.nextTransform)this.requestTransform(FORM_IDS.filter(id=>id!=='nova')[(FORM_IDS.filter(id=>id!=='nova').indexOf(this.form)+1)%10],'automatic');}
 }
}
