export async function geminiResponseError(response){
 let data={};try{data=await response.json();}catch{}const error=data.error||{},reasons=(error.details||[]).map(d=>String(d.reason||'')),status=response.status;
 let category='service',message='O Google Gemini está indisponível (HTTP '+status+').';
 if(reasons.some(r=>/API_KEY_INVALID|API_KEY_EXPIRED/.test(r))){category='key';message='O Google recusou esta chave Gemini. A chave está salva, mas precisa ser substituída por uma chave válida.';}
 else if(status===429){category='quota';message='A chave está salva, mas a cota do projeto Gemini foi atingida. Confira a cota no Google AI Studio ou aguarde sua renovação.';}
 else if(status===401||status===403){category='access';message='A chave está salva, mas o Google recusou o acesso. Confira as permissões e restrições da chave no projeto.';}
 else if(status===404||/not found|not supported for generateContent/i.test(String(error.message||''))){category='model';message='O modelo de conversa não está disponível para esta chave. Use a seleção automática de modelo.';}
 else if(status===400){category='request';message='O Google recusou a solicitação de conversa. Confira o modelo e a configuração da chave.';}
 const e=Error(message);e.code='gemini_'+status;e.status=status;e.category=category;return e;
}
export function geminiNetworkError(){const e=Error('A chave está salva, mas não foi possível alcançar o Google Gemini. Confira a internet e tente novamente.');e.code='gemini_network';e.category='network';return e;}
