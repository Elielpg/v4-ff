// AGPL-3.0 companion to tiktok-live-connector 2.5.0. Full corresponding source
// and upstream license ship in third_party/tiktok-live-connector-2.5.0/.
let proxyAgent,proxyAddress;
export async function createAlternativeClient(mod,username,{proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY}={}){
 if(typeof mod.TikTokLiveConnection!=='function')throw Error('Conector TikTok 2.5.0 incompatível: TikTokLiveConnection ausente');
 const options={processInitialData:false,fetchRoomInfoOnConnect:false,enableExtendedGiftInfo:false,authenticateWs:false,useMobile:false,webClientOptions:{timeout:{request:12000},retry:{limit:0}}};
 if(proxy){
  const {HttpsProxyAgent}=await import('https-proxy-agent');
  if(proxyAddress!==proxy){proxyAgent?.destroy();proxyAgent=new HttpsProxyAgent(proxy);proxyAddress=proxy;}
  options.webClientOptions.agent={http:proxyAgent,https:proxyAgent};options.wsClientOptions={agent:proxyAgent};
  // got and ws do not inherit HTTP_PROXY automatically. The signing SDK uses
  // axios: make its proxy path explicit too, preserving inherited CA trust.
  if(mod.SignConfig){mod.SignConfig.baseOptions={...mod.SignConfig.baseOptions,httpAgent:proxyAgent,httpsAgent:proxyAgent,proxy:false,timeout:12000};mod.SignConfig.cachedInstance=undefined;}
 }
 return new mod.TikTokLiveConnection(username,options);
}
export function normalizeAlternativeError(error){return error?.exception||error;}
export function normalizedGiftFinal(event){return Number(event.gift?.type??event.giftType??0)!==1||Number(event.repeatEnd??0)===1;}
