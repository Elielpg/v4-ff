import {clean} from '../public/transformations.js';
const greetings=[
 'E aí! Tudo certo com você?',
 'Opa! Que bom te ver por aqui. Como tá o seu dia?',
 'Fala! Beleza? Tô por aqui, pode conversar comigo.',
 'Oi! Chegou em boa hora. Como você tá?'
];
// Only complete social messages. A greeting followed by a question uses the LLM.
export function socialReply(text,index=0){
 const q=clean(text).replace(/^ben(?: 10)?\s+/,'').replace(/\s+ben(?: 10)?$/,'');
 if(/^(oi+|ola+|oie+|e ai|eae|salve|opa|alo|bom dia|boa tarde|boa noite)$/.test(q))return greetings[Math.abs(index)%greetings.length];
 if(/^(tudo bem|td bem|como vai|como voce esta|como vc esta|beleza)$/.test(q))return 'Tô bem! Um pouco de aventura e uma galera legal já deixam meu dia melhor. E você?';
 if(/^(valeu|obrigad[oa]|muito obrigad[oa]|tmj)$/.test(q))return 'Tamo junto! Pode falar comigo quando quiser.';
 return null;
}
