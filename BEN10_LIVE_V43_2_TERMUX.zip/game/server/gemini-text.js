import {createHash} from 'node:crypto';
import {gemini,providerFetch} from './core.js';
import {geminiResponseError,geminiNetworkError} from './gemini-errors.js';
const textModel=m=>m.supportedGenerationMethods?.includes('generateContent')&&/^models\/gemini-[\w.-]+$/.test(m.name||'')&&!/tts|image|native.audio|embedding|robotics|computer.use|deep.research/i.test(m.name);
const rank=name=>(/flash/.test(name)?100:0)+(!/lite/.test(name)?10:0)-(/preview|exp/.test(name)?8:0)+(Number(name.match(/gemini-(\d+(?:\.\d+)?)/)?.[1])||0)*3;
export class GeminiTextClient{
 constructor({fetcher=providerFetch,now=Date.now}={}){this.fetcher=fetcher;this.now=now;this.catalogs=new Map();this.resolved=new Map();}
 identity(key){return createHash('sha256').update(String(key)).digest('hex');}
 async models(key,{refresh=false}={}){if(!key)throw Object.assign(Error('Selecione uma chave Gemini antes de testar.'),{code:'missing_key',category:'missing'});const id=this.identity(key),cached=this.catalogs.get(id);if(!refresh&&cached&&this.now()-cached.at<1800000)return cached.models;let all=[],pageToken='';
  for(let page=0;page<3;page++){let response;try{response=await this.fetcher('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000'+(pageToken?'&pageToken='+encodeURIComponent(pageToken):''),{headers:{'x-goog-api-key':key},signal:AbortSignal.timeout(15000)});}catch{throw geminiNetworkError();}if(!response.ok)throw await geminiResponseError(response);const data=await response.json();all.push(...(data.models||[]).filter(textModel).map(m=>({id:m.name.slice(7),name:String(m.displayName||m.name.slice(7)).slice(0,100)})));pageToken=data.nextPageToken;if(!pageToken)break;}
  all=[...new Map(all.map(m=>[m.id,m])).values()].sort((a,b)=>rank(b.id)-rank(a.id)||b.id.localeCompare(a.id));this.catalogs.set(id,{at:this.now(),models:all});if(this.catalogs.size>20)this.catalogs.delete(this.catalogs.keys().next().value);return all;
 }
 async generate(text,{key,model='auto',context={},...rest}={}){if(!key)throw Object.assign(Error('Selecione uma chave Gemini antes de testar.'),{code:'missing_key',category:'missing'});const requested=model||'auto',cacheId=this.identity(key)+':'+requested,cached=this.resolved.get(cacheId);let selected=cached&&this.now()-cached.at<1800000?cached.model:requested,notice='';
  if(selected==='auto'){const list=await this.models(key);selected=list.find(m=>/flash/.test(m.id))?.id;if(!selected)throw Object.assign(Error('Nenhum modelo Flash de texto foi listado para esta chave. Consulte os modelos disponíveis e escolha um modelo acessível.'),{code:'gemini_no_text_model',category:'model'});}
  let answer;try{answer=await gemini(text,{...rest,key,model:selected,context,fetcher:this.fetcher});}
  catch(e){if(e.category!=='model'&&e.status!==404)throw e;const list=await this.models(key,{refresh:true}),replacement=list.find(m=>m.id!==selected&&/flash/.test(m.id));if(!replacement)throw e;notice='O modelo '+selected+' ficou indisponível; usando '+replacement.id+'.';selected=replacement.id;answer=await gemini(text,{...rest,key,model:selected,context,fetcher:this.fetcher});}
  this.resolved.set(cacheId,{at:this.now(),model:selected});if(this.resolved.size>40)this.resolved.delete(this.resolved.keys().next().value);return {...answer,...(notice?{modelNotice:notice}:{})};
 }
}
