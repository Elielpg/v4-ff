#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node --version
npm --version
node scripts/check.js
node --env-file-if-exists=.env --input-type=module -e 'console.log("Gemini em variável de ambiente: "+(process.env.GEMINI_API_KEY?"variável presente (valor oculto)":"não configurado"));const r=await fetch("http://127.0.0.1:"+(process.env.PORT||3000)+"/api/health");const d=await r.json();if(!r.ok||!d.ok)process.exit(1);console.log(JSON.stringify(d,null,2))'
