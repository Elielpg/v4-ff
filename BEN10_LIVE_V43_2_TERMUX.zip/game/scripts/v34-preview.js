import {chromium} from 'playwright-core';
import {mkdir,writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:540,height:960}});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.addInitScript(()=>localStorage.setItem('benWelcomeBuild','34.0.0'));
await page.goto('http://127.0.0.1:3000');await page.waitForTimeout(4500);await mkdir('reports/v34',{recursive:true});
console.log(await page.evaluate(()=>({world:!!window.linelWorld,arena:window.linelWorld?.arena?.enabled,meshes:window.linelWorld?.scene.meshes.length,model:window.linelWorld?.imported?.formId,show:!!window.benLiveShow,welcome:document.querySelector('#welcome').hidden})));
await page.screenshot({path:'reports/v34/arena-preview.png'});console.log(errors);await writeFile('reports/v34/preview-errors.json',JSON.stringify(errors,null,2));await browser.close();
