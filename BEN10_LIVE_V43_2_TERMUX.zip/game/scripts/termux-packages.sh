#!/usr/bin/env bash
# Install missing official Termux tools without refreshing unrelated repositories.
set -euo pipefail
task_missing=()
task_has_package() {
  case "$1" in
    git|cmake|ninja|curl|proot-distro) command -v "$1" >/dev/null 2>&1 ;;
    clang) command -v clang >/dev/null 2>&1 && command -v clang++ >/dev/null 2>&1 ;;
    python) command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1 ;;
    libandroid-spawn) [[ "$(dpkg-query -W -f='${Status}' libandroid-spawn 2>/dev/null || true)" == 'install ok installed' ]] ;;
    *) printf 'Pacote não previsto neste instalador: %s\n' "$1" >&2; return 2 ;;
  esac
}
for task_package in "$@"; do
  case "$task_package" in git|cmake|ninja|clang|python|curl|libandroid-spawn|proot-distro) ;; *) printf 'Pacote inválido: %s\n' "$task_package" >&2; exit 1 ;; esac
  if ! task_has_package "$task_package"; then task_missing+=("$task_package"); fi
done
if ((${#task_missing[@]} == 0)); then
  printf 'Ferramentas da IA já disponíveis. Sem consultar pkg/apt ou repositórios extras.\n'
  exit 0
fi
[[ -n "${PREFIX:-}" && -d "$PREFIX/etc/apt" ]] && command -v apt-get >/dev/null 2>&1 || {
  printf 'APT do Termux não encontrado. Execute este instalador no Termux atualizado.\n' >&2
  exit 1
}
umask 077
task_apt_work="$(mktemp -d "${TMPDIR:-$PREFIX/tmp}/ben10-apt.XXXXXXXX")"
trap 'rm -rf -- "$task_apt_work"' EXIT
mkdir -p "$task_apt_work/lists/partial" "$task_apt_work/sources.list.d"
# Prefer the edition's actual Deb822 main file. APT itself parses Signed-By,
# including inline public keys; do not convert it or substitute another edition.
task_main_file="$task_apt_work/termux.sources"
if [[ -f "$PREFIX/etc/apt/sources.list.d/termux.sources" ]]; then
  task_unsafe_deb822='^[[:space:]]*(trusted|allow-insecure|allow-weak|allow-downgrade-to-insecure)[[:space:]]*:[[:space:]]*(yes|true|1)([[:space:]]|$)'
  while IFS= read -r task_line || [[ -n "$task_line" ]]; do
    if [[ "${task_line,,}" =~ $task_unsafe_deb822 ]]; then
      printf 'A fonte principal contém uma opção que dispensa autenticação. A instalação parou sem enfraquecer assinaturas.\n' >&2
      exit 1
    fi
  done < "$PREFIX/etc/apt/sources.list.d/termux.sources"
  cp -- "$PREFIX/etc/apt/sources.list.d/termux.sources" "$task_main_file"
  printf 'Fonte principal: termux.sources existente (formato Deb822).\n'
else
  task_main_source=''
  task_main_pattern='^[[:space:]]*deb[[:space:]]+(\[[^]]*\][[:space:]]+)?(https://termux\.net/?|https://packages\.termux\.dev/apt/termux-main/?)[[:space:]]+stable[[:space:]]+main[[:space:]]*$'
  task_unsafe_pattern='(trusted|allow-insecure|allow-weak|allow-downgrade-to-insecure)[[:space:]]*=[[:space:]]*(yes|true|1)'
  for task_source_file in "$PREFIX/etc/apt/sources.list" "$PREFIX"/etc/apt/sources.list.d/*.list; do
    [[ -f "$task_source_file" ]] || continue
    while IFS= read -r task_line || [[ -n "$task_line" ]]; do
      task_entry="${task_line%%#*}"
      if [[ "$task_entry" =~ $task_main_pattern && ! "${task_entry,,}" =~ $task_unsafe_pattern ]]; then
        task_main_source="$task_entry"
        break 2
      fi
    done < "$task_source_file"
  done
  if [[ -z "$task_main_source" ]]; then
    printf 'Não localizei a fonte principal configurada. Nenhum endereço alternativo foi selecionado. Confira sources.list.d/termux.sources.\n' >&2
    exit 1
  fi
  task_main_file="$task_apt_work/termux.list"
  printf '%s\n' "$task_main_source" > "$task_main_file"
fi
task_apt_options=(
  -o "Dir::Etc::sourcelist=$task_main_file"
  -o "Dir::Etc::sourceparts=$task_apt_work/sources.list.d"
  -o "Dir::State::lists=$task_apt_work/lists"
  -o "Dir::Cache::pkgcache=$task_apt_work/pkgcache.bin"
  -o "Dir::Cache::srcpkgcache=$task_apt_work/srcpkgcache.bin"
  -o "APT::Update::Error-Mode=any"
  -o "Acquire::AllowInsecureRepositories=false"
  -o "Acquire::AllowDowngradeToInsecureRepositories=false"
  -o "APT::Get::AllowUnauthenticated=false"
)
printf 'Instalando somente ferramentas ausentes: %s\n' "${task_missing[*]}"
printf 'Usando somente o repositório principal oficial com assinaturas verificadas; fontes extras permanecem intactas.\n'
if ! apt-get "${task_apt_options[@]}" update; then
  printf 'A atualização verificada da fonte principal falhou. A instalação da IA parou; nenhuma assinatura foi ignorada.\n' >&2
  exit 1
fi
if ! apt-get "${task_apt_options[@]}" install -y --no-install-recommends "${task_missing[@]}"; then
  printf 'Não foi possível instalar as ferramentas pelo repositório oficial. A instalação da IA não foi concluída.\n' >&2
  exit 1
fi
for task_package in "${task_missing[@]}"; do
  task_has_package "$task_package" || { printf 'Ferramenta ainda ausente: %s\n' "$task_package" >&2; exit 1; }
done
printf 'Ferramentas prontas. Repositórios extras não foram alterados.\n'
