"""Public model download, immutable revision and hash checks; no HF token needed."""
import argparse
import hashlib
import json
import os
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath

MODELS = {
    "gt3": ["unsloth/Qwen3-4B-Instruct-2507-GGUF"],
    "light": ["Qwen/Qwen2.5-1.5B-Instruct-GGUF"],
}
VOICE_REPO = "rhasspy/piper-voices"
VOICE_BASE = "pt/pt_BR/faber/medium/"
VOICES = {"faber": "medium", "cadu": "medium", "jeff": "medium"}


def voice_plan(name="faber", info=None):
    if name not in VOICES:
        raise ValueError("Voz inválida: use cadu, faber ou jeff")
    info = metadata(VOICE_REPO) if info is None else info
    base = f"pt/pt_BR/{name}/{VOICES[name]}/"
    stem = f"pt_BR-{name}-{VOICES[name]}"
    files = []
    for filename in [stem + ".onnx", stem + ".onnx.json", "MODEL_CARD"]:
        entry = next((f for f in info["siblings"] if f["rfilename"] == base + filename), None)
        if entry is None:
            raise ValueError("Catálogo de voz sem o arquivo: " + base + filename)
        check_record(entry)
        files.append((filename, entry))
    return info, files


def switch_voice(root, name):
    # A voice change never downloads/rebuilds the conversation model or Debian.
    manifest_path = root / "install.json"
    if not manifest_path.is_file():
        raise ValueError("Instale a IA primeiro: bash local-ai.sh install")
    manifest = json.loads(manifest_path.read_text())
    info, files = voice_plan(name)
    target = root / "voices" / name
    for filename, entry in files:
        download(VOICE_REPO, info["sha"], entry, target / filename)
    model = target / f"pt_BR-{name}-{VOICES[name]}.onnx"
    config = json.loads(Path(str(model) + ".json").read_text())
    if config.get("espeak", {}).get("voice", "").lower() != "pt-br":
        raise ValueError("O modelo não é português brasileiro. A voz anterior foi preservada.")
    # Commit the selection only after every file passed hash/language checks.
    manifest.update(voiceModel=str(model.resolve()), voiceRepo=VOICE_REPO, voiceRevision=info["sha"], voiceEngine="piper")
    temp = manifest_path.with_suffix(".json.tmp")
    temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    os.replace(temp, manifest_path)
    print("Voz selecionada:", model.stem, flush=True)
    print("Reinicie com bash local-ai.sh start. Teste: Agora o relógio está pronto. Quatro Braços corre rápido.", flush=True)
    print("A outra voz e o modelo de conversa foram preservados. Créditos em", target / "MODEL_CARD", flush=True)


class CatalogError(ValueError):
    def __init__(self, repo, status, reason):
        self.repo, self.status = repo, status
        super().__init__(f"Catálogo {repo}: {reason}" + (f" (HTTP {status})" if status else ""))


def metadata(repo):
    print("Consultando catálogo público:", repo, flush=True)
    try:
        with urllib.request.urlopen("https://huggingface.co/api/models/" + repo + "?blobs=true", timeout=45) as response:
            raw = response.read(12 * 1024 * 1024 + 1)
    except urllib.error.HTTPError as error:
        raise CatalogError(repo, error.code, "consulta sem token recusada ou endereço indisponível") from None
    except (urllib.error.URLError, TimeoutError):
        raise CatalogError(repo, None, "falha de conexão; confira a internet e tente novamente") from None
    if len(raw) > 12 * 1024 * 1024:
        raise ValueError("Metadados muito grandes")
    result = json.loads(raw)
    if result.get("private") or result.get("gated") not in (None, False):
        raise CatalogError(repo, 403, "o modo local usa apenas modelos públicos sem acesso condicionado")
    if not re.fullmatch(r"[0-9a-f]{40}", result.get("sha", "")):
        raise ValueError("Revisão do modelo inválida")
    return result


def choose_model(profile):
    errors = []
    for repo in MODELS[profile]:
        try:
            info = metadata(repo)
            record = choose_quant(info)
            return repo, info, record
        except CatalogError as error:
            if error.status not in (401, 403, 404):
                raise
            errors.append(str(error))
            print(str(error) + "; consultando a próxima opção pública configurada, se houver.", flush=True)
        except ValueError as error:
            errors.append(repo + ": " + str(error))
    raise ValueError("Nenhum catálogo público compatível foi encontrado. " + " | ".join(errors) + ". O instalador não solicita chave; confira o diagnóstico ou use --model light.")


def check_record(record):
    digest = (record.get("lfs") or {}).get("sha256")
    if digest:
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("SHA-256 inválido: " + record["rfilename"])
    elif not re.fullmatch(r"[0-9a-f]{40}", record.get("blobId", "")):
        raise ValueError("Catálogo sem hash de integridade: " + record["rfilename"])


def catalog_plan(profile):
    repo, info, record = choose_model(profile)
    check_record(record)
    voice_info = metadata(VOICE_REPO)
    voice_files = []
    _, voice_files = voice_plan("faber", voice_info)
    print("Catálogos de conversa e voz conferidos. Não é necessária chave de API.", flush=True)
    return repo, info, record, voice_info, voice_files


def choose_quant(info):
    files = [f for f in info.get("siblings", []) if re.search(r"(?:^|[-_])q4_k_m\.gguf$", f.get("rfilename", ""), re.I) and PurePosixPath(f["rfilename"]).name == f["rfilename"]]
    if len(files) != 1:
        raise ValueError("O repositório não tem um único GGUF Q4_K_M. Use --model light ou confira o repositório.")
    return files[0]


def verify(path, record):
    if not path.is_file():
        return False
    size = (record.get("lfs") or {}).get("size", record.get("size"))
    if size is not None and path.stat().st_size != size:
        return False
    lfs = (record.get("lfs") or {}).get("sha256")
    oid = record.get("blobId")
    if not lfs and not oid:
        raise ValueError("Servidor não informou o hash de integridade")
    digest = hashlib.sha256() if lfs else hashlib.sha1()
    if not lfs:
        digest.update(b"blob " + str(path.stat().st_size).encode() + b"\0")
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest() == (lfs or oid)


def download(repo, revision, record, destination):
    check_record(record)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if verify(destination, record):
        print("Já conferido:", destination.name, flush=True)
        return
    filename = record["rfilename"]
    if ".." in PurePosixPath(filename).parts or filename.startswith("/"):
        raise ValueError("Nome de arquivo inválido")
    url = "https://huggingface.co/" + repo + "/resolve/" + revision + "/" + urllib.parse.quote(filename, safe="/")
    partial = destination.with_name(destination.name + ".part")
    if verify(partial, record):
        os.replace(partial, destination)
        return
    expected = (record.get("lfs") or {}).get("size", record.get("size"))
    if partial.exists() and expected is not None and partial.stat().st_size >= expected:
        partial.unlink()
    start = partial.stat().st_size if partial.exists() else 0
    request = urllib.request.Request(url, headers={"Range": f"bytes={start}-"} if start else {})
    print("Baixando:", destination.name, flush=True)
    try:
        response = urllib.request.urlopen(request, timeout=90)
    except urllib.error.HTTPError as error:
        raise ValueError(f"Arquivo {repo}/{filename}: download recusado (HTTP {error.code}). O parcial foi preservado; nenhum token foi solicitado.") from None
    except (urllib.error.URLError, TimeoutError):
        raise ValueError(f"Arquivo {repo}/{filename}: falha de conexão. Repita para continuar o download parcial.") from None
    with response:
        append = start > 0 and response.status == 206
        count = start if append else 0
        mark = count
        with partial.open("ab" if append else "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > 6 * 1024**3:
                    raise ValueError("Modelo excede o limite de download")
                output.write(chunk)
                if count - mark >= 100 * 1024**2:
                    print(f"  {count // 1024**2} MiB recebidos", flush=True)
                    mark = count
    if not verify(partial, record):
        partial.unlink(missing_ok=True)
        raise ValueError("Hash do modelo não confere. Repita o download.")
    os.replace(partial, destination)


def install(root, profile):
    root.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(root).free < 8 * 1024**3:
        raise ValueError("Reserve pelo menos 8 GB livres para modelos e ambiente local")
    # Check both catalogs before spending time/data on the multi-GB GGUF.
    repo, info, record, voice_info, voice_files = catalog_plan(profile)
    model = root / "models" / record["rfilename"]
    download(repo, info["sha"], record, model)
    for optional in ["README.md", "LICENSE"]:
        entry = next((f for f in info["siblings"] if f["rfilename"] == optional), None)
        if entry:
            download(repo, info["sha"], entry, root / "licenses" / ("text-" + optional))
    for name, entry in voice_files:
        download(VOICE_REPO, voice_info["sha"], entry, root / "voices" / name)
    manifest = {"profile": profile, "textModel": str(model.resolve()), "voiceModel": str((root / "voices/pt_BR-faber-medium.onnx").resolve()), "textRepo": repo, "textRevision": info["sha"], "voiceRepo": VOICE_REPO, "voiceRevision": voice_info["sha"], "alias": "ben-classico-local", "threads": 4, "context": 2048, "piperVersion": "1.8.0", "llamaRevision": "6c01da6278ab6c69ed67d9124806b50d2b299ba7"}
    temp = root / "install.json.tmp"
    temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    os.replace(temp, root / "install.json")
    print("Modelos conferidos. Créditos e licença da voz em", root / "voices/MODEL_CARD", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--model", choices=MODELS, default="gt3")
    parser.add_argument("--check", action="store_true", help="Conferir só os catálogos públicos, sem baixar pesos")
    parser.add_argument("--voice", choices=VOICES, help="Instalar e selecionar somente uma voz, preservando a conversa")
    args = parser.parse_args()
    try:
        if args.voice:
            switch_voice(args.root, args.voice)
        elif args.check:
            catalog_plan(args.model)
        else:
            install(args.root, args.model)
    except Exception as error:
        raise SystemExit("Download não concluído: " + str(error))
