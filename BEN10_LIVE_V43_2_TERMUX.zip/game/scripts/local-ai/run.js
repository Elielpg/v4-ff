import {spawn} from 'node:child_process';
import {createConnection} from 'node:net';
import {readFile,mkdir,access,open} from 'node:fs/promises';
import {constants,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {localHealth,loopbackRequest,localSettings} from '../../server/local-ai.js';
import {BUILD_ID} from '../../public/release.js';

const gameRoot=fileURLToPath(new URL('../../',import.meta.url));
const localRoot=path.resolve(process.env.BEN10_LOCAL_ROOT||path.join(os.homedir(),'.local/share/ben10-local-ai'));
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const children=[];let stopping=false;
async function cleanup(){if(stopping)return;stopping=true;for(const child of [...children].reverse())if(child.exitCode===null&&child.signalCode===null){try{process.kill(-child.pid,'SIGTERM');}catch{child.kill('SIGTERM');}}await pause(500);}
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>cleanup().then(()=>process.exit(0)));
function launch(command,args,{log,cwd=gameRoot}={}){
 if(stopping)throw Error('Inicialização cancelada');
 const child=spawn(command,args,{cwd,env:process.env,detached:true,stdio:log?['ignore',log,log]:'inherit'});
 children.push(child);child.on('error',error=>{child.startError=error;});return child;
}
function portOpen(port){return new Promise(resolve=>{const socket=createConnection({host:'127.0.0.1',port});const done=value=>{socket.destroy();resolve(value);};socket.setTimeout(700,()=>done(false));socket.once('connect',()=>done(true));socket.once('error',()=>done(false));});}
async function waitReady(read,predicate,child,label,timeout=180000){const deadline=Date.now()+timeout;let last=0;while(Date.now()<deadline&&!stopping){if(child&&(child.exitCode!==null||child.signalCode!==null||child.startError))throw Error(label+' encerrou. Consulte os logs em '+path.join(localRoot,'logs'));try{const value=await read();if(predicate(value))return value;}catch{}if(Date.now()-last>10000){console.log('Carregando '+label+'…');last=Date.now();}await pause(500);}throw Error(label+' não ficou pronto. Confira bash local-ai.sh status e os logs.');}
async function main(){
 const command=process.argv[2]||'status',settings=localSettings();let manifest=null;try{manifest=JSON.parse(await readFile(path.join(localRoot,'install.json'),'utf8'));}catch{}
 if(command==='status'){console.log(JSON.stringify({installed:!!manifest,model:manifest?.textRepo||null,modelsDirectory:localRoot,...await localHealth(settings)},null,2));return;}
 if(command!=='start')throw Error('Use start ou status');
 if(!manifest)throw Error('Instale primeiro: bash local-ai.sh install');
 const cloned=manifest.voiceEngine==='qwen3-clone';
 if(cloned)settings.voiceTimeoutSeconds=180;
 const llama=path.join(localRoot,'llama.cpp/build/bin/llama-server');
 await access(llama,constants.X_OK).catch(()=>{throw Error('llama-server ausente. Complete bash local-ai.sh install.');});
 for(const file of [manifest.textModel,...(cloned?[path.join(localRoot,'cloning/config.json'),path.join(localRoot,'cloning/reference.wav'),path.join(localRoot,'qwen3-tts.cpp/build/libqwen3tts.so')]:[manifest.voiceModel,manifest.voiceModel+'.json'])])await access(file);
 const voiceRelative=path.relative(localRoot,path.resolve(manifest.voiceModel));
 if(voiceRelative.startsWith('..')||path.isAbsolute(voiceRelative)||!voiceRelative.endsWith('.onnx'))throw Error('O modelo de voz precisa estar na pasta local da IA.');
 if(await portOpen(settings.textPort)||await portOpen(settings.voicePort))throw Error('Uma porta da IA local já está ocupada. Se a IA já estiver pronta, execute bash start.sh. Confira bash local-ai.sh status.');
 await mkdir(path.join(localRoot,'logs'),{recursive:true});
 const llmLog=await open(path.join(localRoot,'logs/conversa.log'),'a'),voiceLog=await open(path.join(localRoot,'logs/voz.log'),'a');
 const llm=launch(llama,['--model',manifest.textModel,'--alias',settings.model,'--host','127.0.0.1','--port',String(settings.textPort),'--ctx-size','4096','--threads','4','--threads-batch','4','--batch-size','128','--ubatch-size','128','--parallel','1','--threads-http','2','--no-webui','--reasoning','off'],{log:llmLog.fd});
 const tts=cloned?launch('python3',[path.join(gameRoot,'scripts/local-ai/clone_voice.py'),'--root',localRoot,'--port',String(settings.voicePort)],{log:voiceLog.fd}):launch('proot-distro',['login','--bind',localRoot+':/ben10-data','--bind',path.join(gameRoot,'scripts/local-ai')+':/opt/ben10-worker','ben10-ai','--','/opt/ben10-voice/bin/python','/opt/ben10-worker/tts_server.py','--model','/ben10-data/'+voiceRelative.split(path.sep).join('/'),'--port',String(settings.voicePort)],{log:voiceLog.fd});
 await llmLog.close();await voiceLog.close();
 await Promise.all([waitReady(async()=>JSON.parse((await loopbackRequest(settings.textPort,'/health',{timeout:2500})).data),s=>s.status==='ok',llm,'conversa'),waitReady(async()=>JSON.parse((await loopbackRequest(settings.voicePort,'/health',{timeout:2500})).data),s=>s.ready===true,tts,'voz')]);
 const gamePort=Number(process.env.PORT||3000);if(!Number.isInteger(gamePort)||gamePort<1024||gamePort>65535)throw Error('PORT do jogo inválida');
 let game=null,health;try{health=JSON.parse((await loopbackRequest(gamePort,'/api/health',{timeout:1500})).data);}catch{}
 if(health){if(health.runtime?.root!==gameRoot.replace(/\/$/,''))throw Error('A porta do jogo pertence a outra instalação. Pare essa sessão ou escolha outra PORT.');}
 else{if(await portOpen(gamePort))throw Error('A porta do jogo está ocupada.');game=launch(process.execPath,[...(existsSync(path.join(gameRoot,'.env'))?['--env-file=.env']:[]),'server/index.js']);await waitReady(async()=>JSON.parse((await loopbackRequest(gamePort,'/api/health',{timeout:1500})).data),s=>s.ok===true,game,'jogo',30000);}
 const saved=await loopbackRequest(gamePort,'/api/config',{body:{conversationProvider:'local',voiceProvider:'local',localAi:settings}});if(saved.status!==200)throw Error('Não foi possível selecionar IA local no jogo.');
 console.log('\nConversa e voz locais prontas, sem chave. Abra http://127.0.0.1:'+gamePort+'/?v='+BUILD_ID+' e toque em ♫.');
 console.log('Mantenha esta sessão aberta. Ctrl+C encerra somente os processos iniciados por este comando.');
 while(!stopping){for(const [child,label] of [[llm,'conversa'],[tts,'voz'],...(game?[[game,'jogo']]:[])])if(child.exitCode!==null||child.signalCode!==null||child.startError)throw Error('O serviço de '+label+' encerrou. Confira '+path.join(localRoot,'logs'));await pause(1000);}
}
main().catch(async error=>{console.error(error.message);await cleanup();process.exitCode=1;});
