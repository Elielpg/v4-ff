"""Local clone selection. Never modifies the installed Piper/text model paths."""
import argparse
import json
import os
import hashlib
from pathlib import Path
from clone_voice import configure_reference


def configure(root, action, source=None):
    root = Path(root)
    manifest_path = root / "install.json"
    manifest = json.loads(manifest_path.read_text())
    config_file = root / "cloning/config.json"
    if action == "reference":
        if not source:
            raise ValueError("Informe um arquivo WAV com a voz de referência")
        details = configure_reference(source, root / "cloning/reference.wav")
        temp = config_file.with_suffix(".tmp")
        temp.write_text(json.dumps(details)); os.replace(temp, config_file)
        (root / "cloning/preview.wav").unlink(missing_ok=True)
        (root / "cloning/preview.json").unlink(missing_ok=True)
        print("Amostra preparada localmente. Execute clone preview antes de selecionar a voz.")
        return
    if action == "status":
        print(json.dumps({"engine": manifest.get("voiceEngine", "piper"), "referenceConfigured": config_file.is_file(), "nativeLibrary": (root / "qwen3-tts.cpp/build/libqwen3tts.so").is_file()}, ensure_ascii=False))
        return
    if action == "use":
        for filename in ["cloning/config.json", "cloning/reference.wav", "qwen3-tts.cpp/build/libqwen3tts.so", "cloning/models/qwen3-tts-0.6b-f16.gguf", "cloning/models/qwen3-tts-tokenizer-f16.gguf", "cloning/preview.wav", "cloning/preview.json"]:
            if not (root / filename).is_file():
                raise ValueError("Complete instalação, amostra e preview antes de selecionar o clone")
        preview = json.loads((root / "cloning/preview.json").read_text())
        if preview.get("referenceSha256") != hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest():
            raise ValueError("A amostra mudou. Gere e ouça outro preview")
        manifest["voiceEngine"] = "qwen3-clone"
    elif action == "piper":
        manifest["voiceEngine"] = "piper"
    else:
        raise ValueError("Comando inválido")
    temp = manifest_path.with_suffix(".json.tmp")
    temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)); os.replace(temp, manifest_path)
    print("Selecionado:", manifest["voiceEngine"], "· reinicie bash local-ai.sh start")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("action", choices=["reference", "use", "piper", "status"])
    parser.add_argument("source", nargs="?")
    args = parser.parse_args()
    try:
        configure(args.root, args.action, args.source)
    except Exception as error:
        raise SystemExit("Seleção mantida: " + str(error))
