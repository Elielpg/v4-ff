"""Fetch public, hashed source weights for the pinned native converter."""
import argparse
import json
import os
import shutil
from pathlib import Path, PurePosixPath
from download_models import metadata, check_record, download

REPO = "Qwen/Qwen3-TTS-12Hz-0.6B-Base"
TOKENIZER_REPO = "Qwen/Qwen3-TTS-Tokenizer-12Hz"


def plan():
    info = metadata(REPO)
    required = {"config.json", "model.safetensors", "vocab.json", "merges.txt", "tokenizer_config.json"}
    names = {f["rfilename"] for f in info["siblings"]}
    if not required <= names:
        raise ValueError("Catálogo do Qwen3-TTS mudou; nenhum peso foi baixado")
    files = [f for f in info["siblings"] if f["rfilename"] in required | {"generation_config.json", "README.md", "LICENSE"} or f["rfilename"] in {"speech_tokenizer/config.json", "speech_tokenizer/model.safetensors"}]
    repositories = [(REPO, info, files, "source")]
    if not {"speech_tokenizer/config.json", "speech_tokenizer/model.safetensors"} <= names:
        tokenizer = metadata(TOKENIZER_REPO)
        token_files = [f for f in tokenizer["siblings"] if f["rfilename"] in {"config.json", "model.safetensors", "README.md", "LICENSE"}]
        if not {"config.json", "model.safetensors"} <= {f["rfilename"] for f in token_files}:
            raise ValueError("Catálogo do tokenizer incompleto")
        repositories.append((TOKENIZER_REPO, tokenizer, token_files, "source/speech_tokenizer"))
    for _, _, records, _ in repositories:
        for record in records:
            name = PurePosixPath(record["rfilename"])
            if name.is_absolute() or ".." in name.parts:
                raise ValueError("Caminho inválido no catálogo")
            check_record(record)
    return repositories


def install(root):
    root.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(root).free < 8 * 1024**3:
        raise ValueError("Reserve 8 GB livres para pesos, conversão e dependências iniciais")
    repositories = plan()  # Verify all catalogs before downloading any weight.
    for repo, info, records, folder in repositories:
        for record in records:
            download(repo, info["sha"], record, root / folder / record["rfilename"])
    temp = root / "sources.json.tmp"
    temp.write_text(json.dumps({"models": [{"repo": repo, "revision": info["sha"]} for repo, info, _, _ in repositories]}))
    os.replace(temp, root / "sources.json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    args = parser.parse_args()
    try:
        install(args.root)
    except Exception as error:
        raise SystemExit("Clonagem não instalada: " + str(error))
