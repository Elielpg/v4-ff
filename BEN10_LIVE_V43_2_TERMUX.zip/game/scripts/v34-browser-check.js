import {chromium} from 'playwright-core';
import {mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const base='http://127.0.0.1:3000';
const post=async(route,data)=>{const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});const b=await r.json();assert(r.ok,JSON.stringify(b));return b;};
await post('adventure',{action:'configure',options:{autoTransform:false,autoMissions:false,autoPowers:false,npcSpeech:false}});
await post('adventure',{action:'cancel'});
await post('adventure',{action:'transform',form:'base'});
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});
const results={build:'34.0.0',gifts:[],errors:[],liveTikTok:'não testado em live real',device:'Chromium Linux, 540×960 e 1280×720; não é um teste Android físico'};
try{
 const page=await browser.newPage({viewport:{width:540,height:960}});page.on('pageerror',e=>results.errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')results.errors.push(m.text());});
 await page.addInitScript(()=>{localStorage.setItem('benWelcomeBuild','34.0.0');localStorage.setItem('ben34Scene','arena');localStorage.setItem('ben34Clean','true');});
 await page.goto(base);await page.waitForFunction(()=>window.linelWorld?.imported?.formId==='base'&&window.benLiveShow);await page.waitForTimeout(2000);await mkdir('reports/v34',{recursive:true});
 assert(await page.locator('body').evaluate(e=>e.classList.contains('show-clean')));assert.equal(await page.locator('.bottom').isVisible(),false);await page.screenshot({path:'reports/v34/01-arena-ben.png'});
 await page.locator('#sound').click();await page.waitForFunction(()=>window.linelAudio.enabled&&window.linelAudio.ctx.state==='running');
 // Names with a suffix still get their visual interpretation but deliberately do not
 // match configured transform rules, isolating all visual styles from action cooldowns.
 const fixtures=[['Rose','rose'],['Heart Me','heart'],['Galaxy','galaxy'],['Confetti','confetti'],['Lightning Bolt','lightning'],['Lion','lion'],['Money Gun','money'],['Ice Cream','ice'],['Surpresa','energy']];
 for(const [gift,kind] of fixtures){const id='v34-browser-'+kind+'-'+Date.now();await post('event',{id,type:'gift',user:'Público de teste',gift:gift+' V34 visual',count:3});await page.waitForFunction(k=>window.linelWorld.giftSpectacle.active?.kind===k,kind);await page.waitForTimeout(350);const proof=await page.evaluate(()=>{const a=window.linelWorld.giftSpectacle.active;return {kind:a.kind,particles:a.parts.length,rings:a.rings.length,emblem:!!a.emblem,announcement:document.getElementById('omni-announcement-title').textContent,soundNodes:window.benLiveShow.audio.played};});assert.equal(proof.kind,kind);assert(proof.particles>=16);results.gifts.push(proof);if(['rose','heart','galaxy','lion'].includes(kind))await page.screenshot({path:'reports/v34/gift-'+kind+'.png'});await page.evaluate(()=>{const fx=window.linelWorld.giftSpectacle;for(let i=0;i<70;i++)fx.update(.12);});await page.waitForFunction(()=>!window.linelWorld.giftSpectacle.active);}
 const energyBefore=await page.evaluate(()=>window.benLiveShow.total);await post('event',{id:'v34-energy-'+Date.now(),type:'like',user:'Energia',count:500});await page.waitForFunction(before=>window.benLiveShow.total===before+500,energyBefore);results.energy=await page.evaluate(()=>({total:window.benLiveShow.total,level:window.benLiveShow.level,progress:document.getElementById('omni-meter').value}));assert(results.energy.level>=2);
 await page.locator('#show-train').click();await page.waitForFunction(()=>window.linelWorld.previewActive&&window.linelWorld.arena.dummy.isEnabled());await page.waitForFunction(()=>window.linelWorld.arena.trainingHP===35,{},{timeout:20000});results.training={hit:true,hp:35};await page.screenshot({path:'reports/v34/02-training-impact.png'});await page.waitForFunction(()=>!window.linelWorld.previewActive,{},{timeout:20000});
 await page.locator('#show-alien').click();await page.waitForFunction(()=>window.linelWorld.imported?.formId==='blaze'&&window.linelWorld.imported.root.isEnabled(),{},{timeout:20000});await page.waitForTimeout(1500);await page.screenshot({path:'reports/v34/03-chama.png'});
 const response=await post('event',{id:'v34-real-rule-'+Date.now(),type:'gift',gift:'Rose',user:'Apoiador',count:1});assert.equal(response.event.power,true);await page.waitForFunction(()=>window.linelWorld.questVisuals.effect?.form==='blaze',{},{timeout:20000});results.giftPower=true;
 await page.waitForTimeout(350);await page.screenshot({path:'reports/v34/04-rose-power.png'});
 await page.locator('#arena-toggle').click();await page.waitForFunction(()=>!window.linelWorld.arena.enabled);assert(await page.locator('body').evaluate(e=>!e.classList.contains('arena-mode')));results.cityToggle=true;
 await page.locator('#arena-toggle').click();await page.locator('#show-controls').click();assert(await page.locator('.bottom').isVisible());await page.locator('#show-controls').click();
 assert.equal(await page.locator('body').evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await page.setViewportSize({width:1280,height:720});await page.waitForTimeout(1200);await page.screenshot({path:'reports/v34/05-landscape.png'});results.landscape=true;
 await page.setViewportSize({width:360,height:800});await page.waitForTimeout(800);assert.equal(await page.locator('body').evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await page.locator('#show-controls').click();await page.locator('#show-controls').click();await page.screenshot({path:'reports/v34/06-mobile-360.png'});results.narrowMobile=true;
 results.audio=await page.evaluate(()=>({state:window.linelAudio.ctx.state,synthNodes:window.benLiveShow.audio.played}));assert(results.audio.synthNodes>10);results.reconnectEnergy=await page.evaluate(async()=>{const prior=window.benLiveShow.total;const restored=await new Promise(resolve=>{const stream=new EventSource('/events');stream.addEventListener('ready',e=>{const s=JSON.parse(e.data);stream.close();resolve(s.energy===prior);});});return {prior,restored};});assert.equal(results.reconnectEnergy.restored,true);
 assert.equal(results.errors.length,0,results.errors.join('\n'));console.log(JSON.stringify(results,null,2));
}finally{await writeFile('reports/v34/browser-results.json',JSON.stringify(results,null,2));await browser.close();}
