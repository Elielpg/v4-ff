// Run on the phone: node scripts/live-probe.js @seuusuario --seconds 45
// Receives events only; never posts chat or gifts and never prints message text.
import {parseArgs} from 'node:util';
import {mkdir,writeFile} from 'node:fs/promises';
import {LiveAdapter,normalizeUsername} from '../server/live.js';
const {values,positionals}=parseArgs({options:{seconds:{type:'string',default:'45'},endpoint:{type:'string',default:'auto'},provider:{type:'string',default:'auto'}},allowPositionals:true});
let username;try{username=normalizeUsername(positionals[0]||'');}catch(error){console.error(error.message+'\nUso: node scripts/live-probe.js @seuusuario --seconds 45 --endpoint auto');process.exit(1);}
const seconds=Number(values.seconds);if(!Number.isInteger(seconds)||seconds<10||seconds>180){console.error('--seconds precisa estar entre 10 e 180.');process.exit(1);}
const started=Date.now(),states=[],types={},report={username,connectors:['piratetok-live-js@0.3.0','tiktok-live-connector@2.5.0'],provider:values.provider,node:process.version,endpoint:values.endpoint,started:new Date().toISOString(),handshake:false,events:0};let finished=false,observeTimer;
const adapter=new LiveAdapter(event=>{report.events++;types[event.type]=(types[event.type]||0)+1;console.log('Evento real recebido: '+event.type+' · total '+report.events);},state=>{
 const entry={elapsedMs:Date.now()-started,status:state.status,provider:state.provider,stage:state.stage,endpoint:state.endpoint,attempt:state.attempt,roomId:state.roomId,error:state.error,detail:state.detail};states.push(entry);if(states.length>60)states.shift();console.log(JSON.stringify(entry));
 if(state.status==='websocket confirmado'){report.handshake=true;if(!observeTimer)observeTimer=setTimeout(()=>void finish(report.events?0:2),seconds*1000);}
 if(state.status==='erro')void finish(1);
},{maxAttempts:3,connectTimeoutMs:25000});
async function finish(code){if(finished)return;finished=true;clearTimeout(observeTimer);report.finished=new Date().toISOString();report.elapsedMs=Date.now()-started;report.types=types;report.final={...adapter.state};report.states=states;report.note=report.events?'Eventos reais recebidos. Confira também a resposta do jogo no navegador.':report.handshake?'Socket abriu, mas nenhum evento foi observado. Peça a um espectador para comentar durante o próximo teste.':'Sem confirmação de WebSocket. Consulte detail e a documentação LIVE_CELULAR.md.';await adapter.disconnect();await mkdir(new URL('../data/',import.meta.url),{recursive:true});await writeFile(new URL('../data/live-last-test.json',import.meta.url),JSON.stringify(report,null,2));console.log(report.note);console.log('Relatório local: data/live-last-test.json (sem chaves e sem textos dos espectadores).');process.exitCode=code;}
process.once('SIGINT',()=>void finish(report.events?0:report.handshake?2:1));process.once('SIGTERM',()=>void finish(1));
try{console.log('Iniciando recepção pública de @'+username+'. A conta precisa estar ao vivo.');await adapter.connect(username,values.provider,{endpoint:values.endpoint});if(!finished&&adapter.state.status==='erro')await finish(1);}catch(error){console.error(error.message);await finish(1);}
