import {chromium} from 'playwright-core';
import {writeFile} from 'node:fs/promises';
import {BUILD_ID} from '../public/release.js';
const base=process.env.REVIEW_URL||'http://127.0.0.1:3028',out='reports/v28';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const report={build:BUILD_ID,errors:[]};
try{
 const page=await browser.newPage({viewport:{width:430,height:932}});page.on('pageerror',e=>report.errors.push(e.message));
 await page.addInitScript(build=>localStorage.setItem('benWelcomeBuild',build),BUILD_ID);await page.goto(base);
 await page.waitForFunction(()=>window.linelWorld?.adventureState?.position);
 report.before=await page.evaluate(()=>window.linelWorld.getPlayerPosition());
 await page.evaluate(()=>{const recorder=new MediaRecorder(document.querySelector('#city').captureStream(12),{mimeType:'video/webm;codecs=vp9',videoBitsPerSecond:750000}),chunks=[];recorder.ondataavailable=e=>chunks.push(e.data);recorder.start(500);window.proofRecorder={recorder,chunks};});
 await page.locator('#open-missions').click();await page.locator('#mission-city-select').selectOption('coast');
 const card=page.locator('.mission-card').filter({has:page.locator('small',{hasText:'Entrega'})});
 await page.screenshot({path:out+'/cross-city-choice.png'});await card.locator('button').click();await page.locator('#close').click();
 await page.waitForFunction(()=>window.linelWorld.adventureState?.quest?.key==='coast:delivery');
 report.travel=await page.evaluate(()=>window.linelWorld.adventureState.quest.travel);
 if(report.travel.city!=='coast'||report.travel.requiredDistance<150)throw Error('Pedido não criou uma viagem para outra cidade');
 console.log('PASS: pedido distante cria viagem linear para Baía do Farol');
 await page.waitForFunction(()=>window.linelWorld.adventureState?.quest?.key==='coast:delivery'&&window.linelWorld.adventureState.quest.status==='complete',null,{timeout:120000});
 report.after=await page.evaluate(()=>({position:window.linelWorld.getPlayerPosition(),originZ:window.linelWorld.originZ,city:window.linelWorld.adventureState.city,quest:window.linelWorld.adventureState.quest,stream:window.linelWorld.endlessCity.stats()}));
 if(report.after.city!=='coast'||report.after.position[2]<400||report.after.originZ<256)throw Error('Cidade ou origem flutuante incorreta');
 await page.waitForTimeout(2200);await page.screenshot({path:out+'/coast-arrival.png'});console.log('PASS: atravessou400m, mudou de cidade e concluiu entrega');
 await page.locator('#open-training').click();await page.locator('[data-preview="rock"]').click();
 await page.waitForFunction(()=>window.linelWorld.previewActive&&window.linelWorld.questVisuals.effect?.form==='rock'&&window.linelWorld.questVisuals.effect.phase==='impact',null,{timeout:60000});
 report.preview=await page.evaluate(()=>{const w=window.linelWorld,e=w.questVisuals.effect;return {position:w.getPlayerPosition(),origin:w.originZ,start:e.start.asArray(),hero:w.avatar.root.position.asArray()};});
 if(Math.abs(report.preview.start[2]-report.preview.hero[2])>8)throw Error('Poder ficou longe do personagem após rebasing');
 await page.screenshot({path:out+'/crystals-after-journey.png'});await page.locator('#training-stop').click();
 const encoded=await page.evaluate(()=>new Promise(resolve=>{const {recorder,chunks}=window.proofRecorder;recorder.onstop=()=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.readAsDataURL(new Blob(chunks,{type:'video/webm'}));};recorder.stop();}));
 await writeFile(out+'/city-travel-v28.webm',Buffer.from(encoded,'base64'));if(report.errors.length)throw Error(report.errors.join('; '));
 console.log('PASS: poder continua junto ao personagem após a troca de origem');
}catch(error){report.failure=error.stack;throw error;}
finally{await browser.close();await writeFile(out+'/cross-city-integration.json',JSON.stringify(report,null,2));}
