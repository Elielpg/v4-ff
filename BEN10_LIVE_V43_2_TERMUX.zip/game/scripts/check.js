import {readdir} from 'node:fs/promises';import {spawnSync} from 'node:child_process';
async function check(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const name=dir+'/'+entry.name;if(entry.isDirectory()){if(entry.name!=='vendor')await check(name);}else if(entry.name.endsWith('.js')){const r=spawnSync(process.execPath,['--check',name],{stdio:'inherit'});if(r.status)process.exit(r.status);}}}
for(const dir of ['server','public','scripts','tests'])await check(dir);console.log('Sintaxe JavaScript válida');
