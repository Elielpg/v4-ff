#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

node_supported() {
  command -v node >/dev/null 2>&1 && node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<19))process.exit(1)' >/dev/null 2>&1
}
has_python() {
  command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1
}

# Updating the game must not refresh unrelated Termux repositories when the
# necessary runtime is already installed (for example an optional glibc repo).
required_packages=()
if ! node_supported || ! command -v npm >/dev/null 2>&1; then
  required_packages+=(nodejs-lts)
fi
if ! has_python; then
  required_packages+=(python)
fi
if ((${#required_packages[@]})); then
  if ! command -v pkg >/dev/null 2>&1; then
    printf 'Instale Node >=22.19, npm e Python 3 antes de continuar.\n' >&2
    exit 1
  fi
  printf 'Instalando ferramentas necessárias: %s\n' "${required_packages[*]}"
  if ! pkg install -y "${required_packages[@]}"; then
    printf 'Não foi possível instalar as ferramentas. Verifique os repositórios e as assinaturas do Termux; a instalação do jogo não prosseguiu.\n' >&2
    exit 1
  fi
else
  printf 'Node, npm e Python já disponíveis. Usando as ferramentas instaladas, sem consultar pkg/apt.\n'
fi
node_supported || { printf 'Node >=22.19 necessário.\n' >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { printf 'npm não encontrado.\n' >&2; exit 1; }
has_python || { printf 'Python 3 não encontrado.\n' >&2; exit 1; }
npm ci --omit=dev --no-audit --no-fund
mkdir -p data/models
node scripts/check.js
npm test
npm run build
printf 'Instalação concluída. Configure IA e voz no painel e execute bash start.sh\n'
