import {createPowerEffect,updatePowerEffect,disposePowerEffect} from './power-effects.js';
import {MissionVisuals} from './mission-visuals.js';
export class QuestVisuals{
 constructor(world){this.world=world;this.state=null;this.id=null;this.root=null;this.effect=null;this.visual=null;this.helper=null;this.objects=[];this.lastPower=null;}
 local(position){return this.world.toLocalPosition?this.world.toLocalPosition(position):new BABYLON.Vector3(...position);}
 clearMission(){this.visual?.dispose();this.visual=null;this.helper?.label?.remove();this.helper?.root.dispose();this.helper=null;this.root?.dispose();this.root=null;this.objects=[];}
 sync(state){this.state=state;const q=state.quest;
  if(q&&q.id!==this.id){this.clearMission();this.id=q.id;this.root=new BABYLON.TransformNode('mission-'+q.id,this.world.scene);this.root.position.copyFrom(this.local(q.position));this.visual=new MissionVisuals(this.world,q,this.root);this.objects=this.visual.meshes;this.helper=this.world.makeActor(-1,q.npc||'Gwen Tennyson');this.helper.root.scaling.setAll(q.speaker==='max'?1:.85);const label=document.createElement('span');label.className='visitor-label npc-label';label.textContent=q.npc||'Pedido de ajuda';this.world.labels.append(label);this.helper.label=label;
  }else if(!q&&this.id!==null){this.clearMission();this.id=null;}
  if(q&&this.root)this.root.position.copyFrom(this.local(q.position));
  if(state.power&&state.power.id!==this.lastPower){this.lastPower=state.power.id;if(Date.now()-state.power.at<4500)this.spawnPower(state.power,q);}
 }
 spawnPower(power,quest,targetOverride=null){this.disposeEffect();const near=quest&&this.root&&BABYLON.Vector3.Distance(this.world.avatar.root.position,this.root.position)<18;this.effect=createPowerEffect(this.world,power,targetOverride||(near?this.root.position:null));}
 disposeEffect(){disposePowerEffect(this.effect);this.effect=null;}
 rebase(delta){if(this.effect){this.effect.start.z-=delta;this.effect.end.z-=delta;}if(this.state?.quest&&this.root)this.root.position.copyFrom(this.local(this.state.quest.position));}
 update(dt){const q=this.state?.quest,w=this.world;
  if(q&&this.root){this.root.position.copyFrom(this.local(q.position));const distance=BABYLON.Vector3.Distance(this.root.position,w.avatar.root.position),visible=!w.previewActive&&!['cancelled','abandoned','failed'].includes(q.status)&&distance<125;this.root.setEnabled(visible);this.visual?.update(q,dt);if(this.helper){this.helper.root.setEnabled(visible&&distance<85);this.helper.root.position.copyFrom(this.root.position).addInPlace(new BABYLON.Vector3(2.8,0,0));const delta=w.avatar.root.position.subtract(this.helper.root.position);this.helper.root.rotation.y=Math.atan2(delta.x,delta.z)+Math.PI;this.helper.animationState=q.status==='complete'?'wave':distance<9?'point':'idle';this.helper.walkSpeed=0;w.animateActor(this.helper,dt,performance.now()/250,true);w.projectLabel(this.helper,visible&&distance<20);}}
  if(this.effect&&updatePowerEffect(w,this.effect,dt))this.disposeEffect();
 }
}
