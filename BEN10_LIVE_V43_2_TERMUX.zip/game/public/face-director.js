// Runtime morphs for the bundled Ben only. Original model and watch are untouched.
export class FaceDirector{
 constructor(meshes,scene){const B=globalThis.BABYLON;this.time=0;this.targets=[];this.managers=[];
 for(const mesh of meshes){const eye=/^Eye-[LR]_/.test(mesh.name),brow=/brows_DIFF/.test(mesh.material?.name||mesh.name),face=/^Face$|Mesh_Face_/.test(mesh.material?.name||mesh.name);if(!eye&&!brow&&!face)continue;
  const p=mesh.getVerticesData(B.VertexBuffer.PositionKind);if(!p?.length)continue;const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<p.length;i+=3)for(let j=0;j<3;j++){min[j]=Math.min(min[j],p[i+j]);max[j]=Math.max(max[j],p[i+j]);}const cy=(min[1]+max[1])/2,h=max[1]-min[1],cx=(min[0]+max[0])/2,w=max[0]-min[0];
  const manager=new B.MorphTargetManager(scene);manager.enableNormalMorphing=false;manager.enableTangentMorphing=false;manager.enableUVMorphing=false;mesh.morphTargetManager=manager;this.managers.push(manager);
  const add=(name,edit)=>{const q=new Float32Array(p);for(let i=0;i<q.length;i+=3)edit(q,i,p);const t=new B.MorphTarget('ben-face-'+name,0,scene);t.setPositions(q);manager.addTarget(t);this.targets.push({kind:name,target:t});};
  if(eye){add('blink',(q,i)=>{q[i+1]=cy+(p[i+1]-cy)*.17;});add('happy-eye',(q,i)=>{q[i+1]=cy+(p[i+1]-cy)*.78;});}
  if(brow){add('happy-brow',(q,i)=>{q[i+1]+=.025+Math.abs(p[i])*.012;});add('curious-brow',(q,i)=>{q[i+1]+=p[i]<0?.046:-.01;});add('surprised-brow',(q,i)=>{q[i+1]+=.06;});}
  if(face){add('jaw',(q,i)=>{const y=(p[i+1]-min[1])/h,x=Math.abs((p[i]-cx)/w)*2,front=p[i+2]<(min[2]+max[2])/2;const weight=front?Math.max(0,1-Math.abs(y-.3)/.23)*Math.max(0,1-x*1.6):0;q[i+1]-=.022*weight;q[i+2]-=.006*weight;});}
 }
 }
 update(dt,{expression='neutral',mouth=0}={}){this.time+=dt;const phase=this.time%4.7,blink=phase>4.42?Math.sin((phase-4.42)/.28*Math.PI):0,blend=1-Math.exp(-dt*15);for(const {kind,target} of this.targets){const desired=kind==='blink'?blink:kind==='happy-eye'?Number(expression==='happy'):kind==='happy-brow'?Number(expression==='happy'||expression==='confident'):kind==='curious-brow'?Number(expression==='curious'):kind==='surprised-brow'?Number(expression==='surprised'):kind==='jaw'?Math.max(0,Math.min(1,mouth)):0;target.influence+=(desired-target.influence)*blend;}this.expression=expression;}
 dispose(){for(const manager of this.managers)manager.dispose();this.managers=[];}
}
export class CampSeat{
 constructor(parent,scene){const B=globalThis.BABYLON;this.root=new B.TransformNode('ben-camp-seat',scene);this.root.parent=parent;this.materials=[];const material=(name,color)=>{const m=new B.StandardMaterial(name,scene);m.diffuseColor=B.Color3.FromHexString(color);m.specularColor.set(.12,.12,.12);this.materials.push(m);return m;},fabric=material('camp-seat-green','#3f6b39'),metal=material('camp-seat-frame','#5e6966');this.seat=B.MeshBuilder.CreateBox('camp-stool-seat',{width:.66,height:.07,depth:.52},scene);this.seat.material=fabric;this.seat.parent=this.root;this.legs=[];for(const x of [-.25,.25])for(const z of [-.18,.18]){const leg=B.MeshBuilder.CreateCylinder('camp-stool-leg',{height:.6,diameter:.045,tessellation:6},scene);leg.material=metal;leg.parent=this.root;leg.position.set(x,-.32,z);this.legs.push(leg);}for(const mesh of this.root.getChildMeshes())mesh.isPickable=false;this.root.setEnabled(false);this.amount=0;}
 update(dt,sitting,rig){this.amount+=(Number(sitting)-this.amount)*(1-Math.exp(-dt*10));this.root.setEnabled(this.amount>.02);if(!this.root.isEnabled())return;this.root.scaling.setAll(Math.max(.001,this.amount));const hip=rig.bones.torso.getAbsolutePosition();this.root.position.set(0,Math.max(.15,hip.y+rig.root.position.y-.09),.06);}
 dispose(){this.root.dispose();for(const m of this.materials)m.dispose();}
}
