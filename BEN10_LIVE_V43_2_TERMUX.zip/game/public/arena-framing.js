// Frame the widest alien as well as its height. Fractions refer to the whole
// viewport, leaving the upper HUD and lower toolbar clear on a portrait phone.
export function arenaFraming({width=1.6,height=2.6,aspect=.5625,casting=false}={}){
 width=Math.max(.5,Number(width)||1.6);height=Math.max(1,Number(height)||2.6);aspect=Math.max(.3,Number(aspect)||.5625);
 const fov=.82,portrait=aspect<1,verticalFraction=portrait?.34:.48,horizontalFraction=portrait?.68:.48;
 const radius=Math.max(portrait?9.2:7.8,height/(2*Math.tan(fov/2)*verticalFraction),width/(2*Math.tan(fov/2)*aspect*horizontalFraction));
 return {radius:radius*(casting?1.08:1),fov,targetHeight:height*(portrait?.95:.68),cameraHeight:height*(portrait?.95:.68)+1.1,verticalFraction,horizontalFraction};
}
