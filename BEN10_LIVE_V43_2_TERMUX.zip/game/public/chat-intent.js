// Incidental action words in a conversation must not consume the question.
export function isConversation(text){
 const q=String(text).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 return /[?？]/.test(q)||/\b(quem|qual|quais|como|onde|quando|quanto|quantos|quantas|porque|por que|o que)\b/.test(q)||/\b(me (conta|conte|fala|fale|explica|explique|diz|diga)|conte (sobre|uma)|fala sobre|fale sobre|voce (acha|gosta|prefere|lembra|sabe|conhece|consegue|pode|tem)|vc (acha|gosta|sabe|pode|tem)|lembra (da|do|de)|sabe (se|sobre)|eu (acho|gosto|quero saber)|sera que)\b/.test(q);
}
