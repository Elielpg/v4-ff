// Absolute coordinates: x is lane offset, y altitude, z forward progress in metres.
// Rendering may rebase chunks; server positions always remain absolute.
export const CITY_LENGTH=400;
export const CHUNK_LENGTH=80;
export const WALK_SPEED=1.65;
export const CITIES=[
 {id:'bellwood',name:'Bellwood',palette:{sky:[.65,.80,.85],fog:[.65,.80,.85],accent:[.31,.52,.38],ground:[.62,.63,.51]}},
 {id:'coast',name:'Baía do Farol',palette:{sky:[.48,.78,.94],fog:[.52,.80,.89],accent:[.27,.62,.72],ground:[.73,.69,.51]}},
 {id:'canyon',name:'Serra dos Cristais',palette:{sky:[.79,.69,.54],fog:[.75,.62,.49],accent:[.65,.39,.26],ground:[.65,.48,.34]}},
 {id:'industry',name:'Distrito Industrial',palette:{sky:[.61,.66,.73],fog:[.59,.63,.70],accent:[.64,.44,.23],ground:[.47,.49,.47]}}
];
export const CITIES_BY_ID=Object.fromEntries(CITIES.map(city=>[city.id,city]));
export const MOVEMENT_PRESETS={run:{speed:5.6,duration:2600,distance:14.56,cooldown:4000},dash:{speed:24,duration:850,distance:20.4,cooldown:4500},fly:{speed:8,duration:3200,distance:25.6,cooldown:6500}};
export const canMove=(form,mode)=>mode==='run'||mode==='dash'&&form==='volt'||mode==='fly'&&['blaze','shade','nova'].includes(form);
export const routePosition=(distance,height=0,lane=0)=>[lane,height,Math.max(0,distance)];
export const cityForDistance=distance=>CITIES[Math.floor(Math.max(0,Number(distance)||0)/CITY_LENGTH)%CITIES.length];
export const cityBandStart=distance=>Math.floor(Math.max(0,distance)/CITY_LENGTH)*CITY_LENGTH;
export function nextCityDistance(distance,cityId){const index=CITIES.findIndex(city=>city.id===cityId);if(index<0)throw Error('Cidade inválida');let band=Math.floor(Math.max(0,distance)/CITY_LENGTH);while(band%CITIES.length!==index)band++;return Math.max(distance,band*CITY_LENGTH);}
