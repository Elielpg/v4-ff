// Shared timing for anticipation, emission, contact and recovery. Values are seconds.
export const POWER_TIMINGS={base:[.28,.85,.45,.4],blaze:[.38,.95,.7,.42],volt:[.24,.72,.32,.35],rock:[.42,.60,.8,.45],shade:[.4,.95,.5,.4],tide:[.4,1.05,.55,.45],nova:[.6,1.1,.75,.45],beast:[.25,.9,.45,.35],fourarms:[.5,.35,.85,.48],cannon:[.35,.9,.6,.4],wildvine:[.38,.95,.65,.45]};
export const clamp01=value=>Math.max(0,Math.min(1,value));
export const ease=value=>{const t=clamp01(value);return t*t*(3-2*t);};
export function powerFrame(form,time){const [anticipation,cast,impact,recover]=POWER_TIMINGS[form]||POWER_TIMINGS.base;const duration=anticipation+cast+impact+recover,charge=ease(time/anticipation),release=clamp01((time-anticipation)/cast),contact=clamp01((time-anticipation-cast)/impact),fade=1-ease((time-anticipation-cast-impact)/recover);return {duration,phase:time<anticipation?'anticipation':time<anticipation+cast?'cast':time<anticipation+cast+impact?'impact':'recovery',charge,release,contact,fade,done:time>=duration};}

// Rendering can be throttled on a phone; power phases still share the server clock rate.
// Explicit simulation steps can run ahead for previews/tests and never move backwards.
export function advancePowerTime(effect,dt,now=Date.now()){return Math.max(effect.time+Math.max(0,dt),(now-effect.startedAt)/1000);}
