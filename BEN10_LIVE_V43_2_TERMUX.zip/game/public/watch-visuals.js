// Keep the authored Omnitrix geometry, strap, bezel and original texture.
// Only green texels in its own material receive the red timeout variant.
export function redWatchPixels(pixels){const out=new Uint8Array(pixels.length);let changed=0;for(let i=0;i<pixels.length;i+=4){const r=pixels[i],g=pixels[i+1],b=pixels[i+2];if(g>r*1.18&&g>b*1.12&&g>65){out[i]=g;out[i+1]=Math.min(80,Math.round(r*.55));out[i+2]=Math.min(55,Math.round(b*.35));changed++;}else{out[i]=r;out[i+1]=g;out[i+2]=b;}out[i+3]=pixels[i+3];}return {pixels:out,changed};}
export class WatchVisuals{
 constructor(world){const B=BABYLON;this.world=world;this.root=new B.TransformNode('original-omnitrix-controller',world.scene);this.color={emissiveColor:new B.Color3(.5,1,.12)};this.binding=null;this.originalMesh=null;this.changedPixels=0;}
 update(state){const w=this.world,rig=w.imported?.root.isEnabled()?w.imported.motionRig:null,mesh=state?.form==='base'?rig?.meshes.find(m=>/omnitrix/i.test(m.name)||/omnitrix/i.test(m.material?.name||'')):null;
  this.root.setEnabled(!!mesh);this.originalMesh=mesh||null;const red=state?.watch.phase==='recharging';this.color.emissiveColor.set(red?1:.5,red?.12:1,red?.08:.12);
  if(!mesh)return;
  const material=mesh.material,texture=material?.albedoTexture||material?.diffuseTexture;if(!texture)return;
  if(this.binding?.mesh!==mesh){this.binding?.redTexture?.dispose();this.binding={mesh,material,source:texture,redTexture:null,pending:false};this.changedPixels=0;}
  const binding=this.binding;
  if(!binding.pending&&!binding.redTexture&&binding.source.isReady()){binding.pending=true;binding.source.readPixels().then(data=>{if(!data)return;const bytes=data instanceof Uint8Array?data:Uint8Array.from(data,n=>Math.round(Math.max(0,Math.min(1,n))*255)),variant=redWatchPixels(bytes),size=binding.source.getSize(),B=BABYLON;
    const t=B.RawTexture.CreateRGBATexture(variant.pixels,size.width,size.height,w.scene,true,false,B.Texture.TRILINEAR_SAMPLINGMODE);t.name='original-omnitrix-red-variant';for(const key of ['uScale','vScale','uOffset','vOffset','coordinatesIndex','wrapU','wrapV','gammaSpace'])t[key]=binding.source[key];
    if(this.binding!==binding||mesh.isDisposed()){t.dispose();return;}binding.redTexture=t;this.changedPixels=variant.changed;
   }).catch(()=>{binding.pending=false;});}
  const desired=red&&binding.redTexture?binding.redTexture:binding.source;if('albedoTexture'in material){if(material.albedoTexture!==desired)material.albedoTexture=desired;}else if(material.diffuseTexture!==desired)material.diffuseTexture=desired;
 }
}
