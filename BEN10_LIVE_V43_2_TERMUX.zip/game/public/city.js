// Deterministic street sections. The same seed always rebuilds the same block;
// only nearby sections are rendered, so a long journey does not grow memory.
export const CHUNK_LENGTH=64;
const COLORS={
 bellwood:{walls:[[.72,.49,.32],[.49,.65,.58],[.83,.64,.37],[.56,.58,.71]],ground:[.35,.44,.32],paving:[.69,.67,.59],road:[.31,.33,.32],trim:[.91,.86,.72],glass:[.18,.43,.46]},
 coast:{walls:[[.72,.85,.86],[.88,.89,.77],[.37,.67,.74],[.67,.78,.83]],ground:[.66,.65,.45],paving:[.83,.79,.64],road:[.37,.45,.48],trim:[.94,.95,.86],glass:[.15,.53,.62]},
 canyon:{walls:[[.67,.39,.23],[.75,.49,.29],[.58,.34,.25],[.82,.61,.36]],ground:[.58,.39,.24],paving:[.71,.53,.34],road:[.46,.36,.27],trim:[.89,.74,.49],glass:[.24,.41,.35]},
 industry:{walls:[[.37,.45,.48],[.48,.51,.48],[.39,.49,.47],[.56,.58,.52]],ground:[.28,.36,.34],paving:[.57,.59,.53],road:[.24,.29,.29],trim:[.74,.78,.68],glass:[.14,.35,.38]}
};
export const cityPalette=id=>COLORS[id]||COLORS.bellwood;
function random(seed){let value=(Math.imul(seed+101,747796405)+2891336453)>>>0;return ()=>{value=(Math.imul(value,1664525)+1013904223)>>>0;return value/4294967296;};}
export function chunkObjects(index,city='bellwood'){
 const rng=random(index),p=cityPalette(city),out=[],add=(pos,size,color,kind='box',rotation)=>out.push({p:pos,s:size,c:color,kind,rotation});
 const wood=[.35,.21,.12],metal=[.14,.22,.23],leaf=[.19,.39,.19];
 add([0,-.28,32],[180,.4,64],p.ground);add([0,-.055,32],[11,.12,64],p.road);for(const side of [-1,1]){add([side*8,.015,32],[5,.20,64],p.paving);add([side*5.45,.10,32],[.18,.28,64],p.trim);}
 for(let z=4;z<64;z+=8){add([0,.015,z],[.12,.02,3.6],[.84,.82,.66]);for(const side of [-1,1])add([side*5.08,.016,z],[.10,.02,4.8],p.trim);}
 for(let z=0;z<64;z+=4)for(const x of [-9,-7,7,9])add([x,.121,z],[.025,.015,3.96],[p.paving[0]*.86,p.paving[1]*.86,p.paving[2]*.86]);
 for(const side of [-1,1])for(let lot=0;lot<2;lot++){
  const z=15+lot*32+(rng()-.5)*3,width=7.6+rng()*1.8,height=city==='industry'?6+rng()*5:city==='canyon'?3.8+rng()*3:4.8+rng()*5,x=side*(13.6+width*.2),wall=p.walls[Math.floor(rng()*p.walls.length)],face=x-side*(width/2+.03);
  add([x,height/2,z],[width,height,12],wall);add([x,.23,z],[width+.16,.4,12.2],p.trim);add([x,height+.15,z],[width+.45,.3,12.45],p.trim);add([x,height+.35,z],[width+.1,.12,12.1],metal);
  const rows=Math.max(1,Math.floor((height-2.8)/1.65));for(let row=0;row<rows;row++)for(const dz of [-3.8,0,3.8]){const y=3.5+row*1.65;add([face,y,z+dz],[.12,1.15,1.5],p.trim);add([face-side*.075,y,z+dz],[.035,.95,1.28],p.glass);add([face-side*.10,y,z+dz],[.025,.96,.045],p.trim);add([face-side*.10,y-.08,z+dz],[.025,.045,1.3],p.trim);}
  add([face-side*.06,1.15,z],[.1,2.3,1.5],metal);add([face-side*.12,1.40,z],[.04,1.35,1.18],p.glass);for(const dz of [-3.6,3.6]){add([face-side*.06,1.35,z+dz],[.12,1.8,2.6],p.glass);add([face-side*.13,1.35,z+dz],[.04,1.85,.055],p.trim);}
  if(city!=='industry')for(let stripe=0;stripe<9;stripe++)add([face-side*.75,2.55,z-5.4+stripe*1.2],[1.6,.13,1.2],stripe%2?p.trim:wall,'box',[0,0,side*.08]);
  else {for(const dz of [-3.5,0,3.5])add([face-side*.08,1.6,z+dz],[.16,3.0,2.6],[.27,.34,.34]);add([x,height+1.8,z+2],[.7,3.3,.7],metal,'cylinder');for(let stripe=0;stripe<5;stripe++)add([face-side*.14,.42,z-4.8+stripe*2.1],[.06,.12,1.1],stripe%2?[.83,.66,.19]:metal);}
 }
 // Tree/bench/lighting line helps the viewer read forward motion instead of orbiting.
 for(const side of [-1,1])for(let n=0;n<3;n++){
  const z=7+n*23+(rng()-.5)*2,x=side*7.0;
  if(city==='coast'){add([x,1.8,z],[.22,3.6,.22],wood,'cylinder');for(let k=0;k<5;k++){const a=k/5*Math.PI*2;add([x+Math.cos(a)*.8,3.6,z+Math.sin(a)*.8],[1.7,.16,.5],[.20,.47,.25],'sphere',[0,-a,.2]);}}
  else if(city==='canyon'){add([x,.45,z],[.95,.9,.95],[.51,.37,.26],'crystal');if(n===1)for(let k=0;k<3;k++)add([x+(k-1)*.4,.8+k%2*.3,z],[.28,1.5,.35],[.30,.80,.77],'crystal');}
  else {add([x,1.3,z],[.22,2.6,.22],wood,'cylinder');add([x,3.0,z],[2,2.25,2],leaf,'sphere');add([x+.6,2.65,z-.3],[1.6,1.8,1.6],[.21,.43,.22],'sphere');}
  const lampX=side*9.8;add([lampX,1.65,z+8],[.09,3.3,.09],metal,'cylinder');add([lampX,3.45,z+8],[.47,.56,.47],[.94,.85,.53]);add([lampX,3.76,z+8],[.66,.10,.66],metal);
  if(n===1){add([side*8.3,.49,z+5],[.55,.15,2],wood);add([side*8.55,.85,z+5],[.12,.65,2],wood);for(const dz of [-.7,.7])add([side*8.3,.22,z+5+dz],[.5,.45,.09],metal);}
 }
 if(city==='coast'){add([34,-.08,32],[42,.09,64],[.10,.46,.65]);add([17.5,.18,32],[1,.20,64],p.trim);for(let z=2;z<64;z+=8){add([17.5,.65,z],[.12,.95,.12],metal);if(z<58)add([17.5,.91,z+4],[.10,.10,8],metal);}}
 if(city==='canyon')for(let i=0;i<7;i++){const side=i%2?-1:1;add([side*(29+rng()*12),3+rng()*2,5+i*8],[6+rng()*7,8+rng()*9,8+rng()*7],[.56+i%3*.04,.35,.23],'crystal');}
 if(city==='industry')for(let i=0;i<4;i++){const side=i%2?-1:1;add([side*25,2,8+i*15],[5,4,5],[.37,.43,.43],'cylinder');add([side*22,4,8+i*15],[.5,7,.5],metal,'cylinder');}
 return out;
}
// Compatibility exports; the live world uses streamed chunks rather than a fixed scene.
export function cityObjects(){return chunkObjects(0,'bellwood');}
export function decorateCity(){}
