// Original stylized geometry, informed by the classic 2005 costume.
// Meshes are grouped under articulated joints; no third-party model is redistributed.
export function heroParts(){
 const parts=[];const skin=[.88,.65,.43],hair=[.20,.095,.045],white=[.94,.94,.86],black=[.045,.055,.05],green=[.29,.39,.19],lime=[.46,1,.12];
 const add=(p,s,c,kind='sphere',joint='torso',rotation)=>parts.push({p,s,c,kind,joint,rotation});
 // torso: rounded white shirt, black front/back panels and a proper neck
 add([0,1.53,0],[.68,.83,.37],white);add([0,1.52,-.187],[.25,.76,.025],black,'box');add([0,1.52,.187],[.25,.76,.025],black,'box');
 add([0,1.91,0],[.25,.21,.25],skin);add([0,1.85,0],[.28,.065,.29],black,'cylinder');
 add([0,1.13,0],[.61,.18,.35],green);add([0,1.2,-.02],[.62,.075,.36],black,'box');add([0,1.2,-.208],[.11,.07,.02],[.65,.66,.6],'box');
 // shaped face, ears, nose, eyebrows, irises, highlights and smile
 add([0,2.22,0],[.60,.67,.52],skin,'sphere','head');add([0,2.06,-.055],[.45,.28,.4],skin,'sphere','head');parts.at(-1).role='jaw';
 for(const side of [-1,1]){
  add([side*.30,2.23,.015],[.13,.21,.14],skin,'sphere','head');add([side*.315,2.23,-.02],[.07,.12,.05],[.69,.42,.30],'sphere','head');
  add([side*.126,2.27,-.241],[.19,.115,.045],white,'sphere','head');add([side*.115,2.267,-.265],[.079,.092,.02],[.22,.48,.16],'sphere','head');add([side*.113,2.267,-.277],[.038,.067,.012],black,'sphere','head');add([side*.105,2.285,-.285],[.018,.022,.009],white,'sphere','head');
  add([side*.126,2.365,-.225],[.21,.038,.045],hair,'sphere','head',[0,0,side*.10]);
 }
 add([0,2.18,-.276],[.08,.13,.10],skin,'sphere','head');add([0,2.076,-.231],[.17,.025,.025],[.22,.075,.055],'sphere','head');parts.at(-1).role='mouth';add([0,2.065,-.24],[.11,.009,.01],white,'box','head');parts.at(-1).role='teeth';
 // fitted hair cap plus swept spikes, avoiding the previous floating slab
 add([0,2.46,.04],[.62,.29,.53],hair,'sphere','head');add([0,2.29,.22],[.56,.32,.16],hair,'sphere','head');
 for(let i=0;i<4;i++)add([-.22+i*.14,2.48-i*.015,.035],[.23,.17,.43],i%2?hair:[.25,.12,.055],'crystal','head',[0,0,-.35]);
 add([.02,2.425,-.205],[.51,.14,.12],hair,'sphere','head',[0,0,-.16]);
 add([-.19,2.385,-.218],[.18,.22,.10],hair,'sphere','head',[0,0,-.6]);
 for(const side of [-1,1]){
  const suffix=side<0?'L':'R';const upper='arm'+suffix,lower='forearm'+suffix,leg='leg'+suffix,shin='shin'+suffix;
  add([side*.415,1.72,0],[.27,.31,.34],white,'sphere',upper);add([side*.422,1.71,-.16],[.27,.045,.02],black,'box',upper);
  add([side*.45,1.47,0],[.17,.36,.18],skin,'cylinder',upper);add([side*.46,1.29,0],[.19,.18,.20],skin,'sphere',lower);add([side*.465,1.12,0],[.16,.29,.17],skin,'cylinder',lower);
  add([side*.47,.92,-.01],[.18,.22,.15],skin,'sphere',lower);for(let f=0;f<4;f++)add([side*.414+f*.035,.84,-.025],[.032,.105,.07],skin,'sphere',lower);
  add([side*.38,.94,-.025],[.065,.12,.08],skin,'sphere',lower);
  add([side*.18,.90,0],[.27,.48,.31],green,'cylinder',leg);add([side*.29,.90,-.01],[.07,.22,.22],[.24,.33,.15],'box',leg);add([side*.30,.98,-.01],[.075,.045,.23],[.34,.43,.23],'box',leg);
  add([side*.18,.56,0],[.26,.23,.3],green,'sphere',shin);add([side*.18,.36,0],[.24,.36,.28],green,'cylinder',shin);
  add([side*.18,.13,-.075],[.29,.23,.45],black,'sphere',shin);add([side*.18,.06,-.09],[.30,.065,.47],white,'box',shin);add([side*.18,.15,-.21],[.27,.1,.16],white,'sphere',shin);for(let k=0;k<3;k++)add([side*.18,.23-k*.02,-.14-k*.025],[.15,.012,.014],white,'box',shin);
 }
 // Omnitrix: strap, bezel, green dial and black hourglass on LEFT wrist
 add([-.468,1.05,0],[.25,.17,.24],black,'sphere','forearmL');add([-.468,1.055,-.13],[.23,.23,.07],[.55,.59,.51],'cylinder','forearmL',[Math.PI/2,0,0]);add([-.468,1.055,-.177],[.17,.17,.025],lime,'cylinder','forearmL',[Math.PI/2,0,0]);
 add([-.468,1.095,-.194],[.11,.065,.013],black,'box','forearmL',[0,0,Math.PI/4]);add([-.468,1.015,-.194],[.11,.065,.013],black,'box','forearmL',[0,0,-Math.PI/4]);
 return parts;
}
export const heroJoints={torso:{origin:[0,0,0]},head:{origin:[0,1.91,0]},armL:{origin:[-.38,1.79,0]},armR:{origin:[.38,1.79,0]},forearmL:{origin:[-.46,1.3,0],parent:'armL'},forearmR:{origin:[.46,1.3,0],parent:'armR'},legL:{origin:[-.18,1.1,0]},legR:{origin:[.18,1.1,0]},shinL:{origin:[-.18,.56,0],parent:'legL'},shinR:{origin:[.18,.56,0],parent:'legR'}};
