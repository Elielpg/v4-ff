// Web Speech uses the voices installed/provided by the user's device; no API key.
export function speechChunks(text,max=170){
 const words=String(text||'').replace(/[*_#`]/g,'').replace(/\s+/g,' ').trim().split(' '),chunks=[];let current='';
 for(const word of words){if(current&&current.length+word.length+1>max){chunks.push(current);current='';}if(word.length>max){if(current){chunks.push(current);current='';}for(let i=0;i<word.length;i+=max)chunks.push(word.slice(i,i+max));}else current+=(current?' ':'')+word;}if(current)chunks.push(current);return chunks;
}
export function chooseVoice(voices,uri=''){const portuguese=voices.filter(v=>/^pt(?:-|_)/i.test(v.lang));return portuguese.find(v=>v.voiceURI===uri)||portuguese.find(v=>/^pt[-_]BR$/i.test(v.lang)&&v.localService)||portuguese.find(v=>/^pt[-_]BR$/i.test(v.lang))||portuguese[0]||null;}
export async function readyVoices(synth=globalThis.speechSynthesis){if(!synth)throw Error('Este navegador não oferece voz. Abra no Chrome e instale uma voz Português (Brasil) no Android.');let voices=synth.getVoices();for(let i=0;!voices.length&&i<12;i++){await new Promise(r=>setTimeout(r,100));voices=synth.getVoices();}return voices;}
export async function speakBrowser(text,{synth=globalThis.speechSynthesis,Utterance=globalThis.SpeechSynthesisUtterance,profile={},volume=1,voiceURI='',onStart=()=>{},onLevel=()=>{}}={}){
 const voice=chooseVoice(await readyVoices(synth),voiceURI);if(!voice)throw Error('Nenhuma voz em português disponível. No Android, instale Português (Brasil) em Configurações › Texto para voz e reabra o Chrome.');
 let started=false;for(const chunk of speechChunks(text))await new Promise((resolve,reject)=>{
  const u=new Utterance(chunk);u.lang=voice.lang;u.voice=voice;u.rate=profile.rate||1.08;u.pitch=profile.pitch||1.08;u.volume=volume;let done=false,mouthTimer,startTimer,endTimer;
  const finish=e=>{if(done)return;done=true;clearTimeout(startTimer);clearTimeout(endTimer);clearInterval(mouthTimer);onLevel(0);e?reject(e):resolve();};
  u.onstart=()=>{clearTimeout(startTimer);if(!started){started=true;onStart();}mouthTimer=setInterval(()=>onLevel(synth.speaking?.1+Math.abs(Math.sin(performance.now()/90))*.38:0),80);endTimer=setTimeout(()=>{finish(Error('A voz do aparelho parou durante a fala. Teste outra voz PT-BR.'));synth.cancel();},30000);};
  u.onend=()=>finish();u.onerror=e=>finish(Error('Voz do aparelho: '+e.error+'. Teste outra voz PT-BR.'));startTimer=setTimeout(()=>{finish(Error('A voz não iniciou. Ative o som e confira o mecanismo de texto para voz do aparelho.'));synth.cancel();},8000);synth.speak(u);
 });return voice.name;
}
