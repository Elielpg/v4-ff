import {CITIES_BY_ID} from './traversal.js';
// Landmarks and water are streamed with the street. This class only handles the
// short transition cue and palette; it never creates a circular landscape.
export class CityBackdrops{
 constructor(world){this.world=world;this.id=null;this.roots={};}
 set(id){if(this.id===id)return;this.id=id;const city=CITIES_BY_ID[id]||CITIES_BY_ID.bellwood;this.world.scene.fogColor=new BABYLON.Color3(...city.palette.fog);this.world.flash=Math.max(this.world.flash,.24);}
}
