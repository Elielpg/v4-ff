export const CHAT_GOALS=Object.freeze([
 {id:'like',icon:'♥',title:'TAP TAP OMNITRIX',action:'curtidas',target:500,reward:'Explosão Omnitrix',effect:'omni',color:'#bbff62'},
 {id:'comment',icon:'💬',title:'VOZ DOS HERÓIS',action:'comentários',target:20,reward:'Cristais de Diamante',effect:'crystal',color:'#75edff'},
 {id:'share',icon:'↗',title:'CHAMAR REFORÇOS',action:'compartilhamentos',target:3,reward:'Túnel de velocidade',effect:'speed',color:'#6eccff'},
 {id:'follow',icon:'★',title:'EQUIPE DO BEN',action:'novos seguidores',target:3,reward:'Sinal dos heróis',effect:'signal',color:'#ffd76c'}
]);
export const DEFAULT_GOAL_SETTINGS=Object.freeze({enabled:true,like:500,comment:20,share:3,follow:3});
export function normalizeGoalSettings(value={}){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Metas do chat inválidas');const next={...DEFAULT_GOAL_SETTINGS};if(value.enabled!==undefined){if(typeof value.enabled!=='boolean')throw Error('Estado das metas inválido');next.enabled=value.enabled;}for(const goal of CHAT_GOALS)if(value[goal.id]!==undefined){const n=value[goal.id];if(!Number.isInteger(n)||n<1||n>(goal.id==='like'?1000000:10000))throw Error('Meta de '+goal.action+' fora do intervalo');next[goal.id]=n;}return next;}
