const STORAGE_KEY='ben10LiveWidgetLayoutV29';
export const LIVE_WIDGETS=[
 {id:'route-hud',label:'Progresso da viagem'},
 {id:'place',label:'Nome do bairro'},
 {id:'side',label:'Atalhos laterais'},
 {id:'mission-hud',label:'Pedido de ajuda'},
 {id:'interaction-banner',label:'Dica de interação'},
 {id:'training-menu',label:'Campo de treino'},
 {id:'bottom',label:'Controles inferiores'},
 {id:'live-ranking',label:'Ranking da LIVE'}
];

export class WidgetLayout{
 constructor({onChange=()=>{}}={}){
  this.onChange=onChange;this.editing=false;this.widgets=new Map(LIVE_WIDGETS.map(item=>[item.id,item]));this.elements=new Map();this.checkboxes=new Map();
  this.load();this.bind();
 }
 load(){
  try{const value=JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}');this.positions=value.positions||{};this.hidden=new Set(value.hidden||[]);}catch{this.positions={};this.hidden=new Set();}
 }
 bind(){
  const list=document.getElementById('layout-list');
  for(const item of LIVE_WIDGETS){
   const element=document.getElementById(item.id)||document.querySelector('.'+item.id);
   if(!element)continue;
   this.elements.set(item.id,element);
   const grip=element.querySelector('.widget-grip');
   grip?.addEventListener('pointerdown',event=>this.startDrag(event,item.id,element,grip));
   const label=document.createElement('label');label.className='widget-toggle';
   const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=!this.hidden.has(item.id);checkbox.addEventListener('change',()=>this.setVisible(item.id,checkbox.checked));
   label.append(checkbox,document.createTextNode(item.label));list?.append(label);this.checkboxes.set(item.id,checkbox);
   if(this.positions[item.id])this.applyPosition(item.id,element,this.positions[item.id]);
   element.classList.toggle('widget-hidden',this.hidden.has(item.id));
  }
  document.getElementById('layout-edit')?.addEventListener('click',()=>this.setEditing(!this.editing));
  document.getElementById('layout-reset')?.addEventListener('click',()=>this.reset());
  document.getElementById('rank-hide')?.addEventListener('click',()=>this.setVisible('live-ranking',false));
  document.getElementById('rank-collapse')?.addEventListener('click',event=>{
   const widget=this.elements.get('live-ranking'),collapsed=widget.classList.toggle('rank-collapsed');
   event.currentTarget.textContent=collapsed?'+':'−';event.currentTarget.setAttribute('aria-expanded',String(!collapsed));
  });
  this.onChange(this.editing);
 }
 persist(){
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify({positions:this.positions,hidden:[...this.hidden]}));}catch{}
 }
 setVisible(id,visible){
  const element=this.elements.get(id);if(!element)return;
  element.classList.toggle('widget-hidden',!visible);
  this.checkboxes.get(id).checked=visible;
  if(visible)this.hidden.delete(id);else this.hidden.add(id);
  this.persist();
 }
 setEditing(editing){
  this.editing=!!editing;document.body.classList.toggle('layout-editing',this.editing);
  const button=document.getElementById('layout-edit'),status=document.getElementById('layout-status');
  if(button)button.textContent=this.editing?'Concluir organização':'Mover painéis';
  if(status)status.textContent=this.editing?'Arraste pelo ícone ⠿ de cada painel. Toque em “Concluir organização” para salvar.':'Posições e painéis ocultos são salvos neste aparelho.';
  this.onChange(this.editing);
 }
 startDrag(event,id,element,grip){
  if(!this.editing||event.button!==0)return;
  event.preventDefault();event.stopPropagation();
  const rect=element.getBoundingClientRect(),pointerX=event.clientX,pointerY=event.clientY;
  element.style.position='fixed';element.style.left=rect.left+'px';element.style.top=rect.top+'px';element.style.right='auto';element.style.bottom='auto';element.style.transform='none';element.style.width=rect.width+'px';element.style.zIndex='30';
  grip.setPointerCapture?.(event.pointerId);
  const move=next=>{
   const maxLeft=Math.max(0,window.innerWidth-element.offsetWidth),maxTop=Math.max(0,window.innerHeight-element.offsetHeight);
   const left=Math.min(maxLeft,Math.max(0,rect.left+next.clientX-pointerX)),top=Math.min(maxTop,Math.max(0,rect.top+next.clientY-pointerY));
   element.style.left=left+'px';element.style.top=top+'px';
  };
  const end=()=>{
   grip.removeEventListener('pointermove',move);grip.removeEventListener('pointerup',end);grip.removeEventListener('pointercancel',end);
   const moved=element.getBoundingClientRect();this.positions[id]={left:Math.round(moved.left),top:Math.round(moved.top)};this.persist();
  };
  grip.addEventListener('pointermove',move);grip.addEventListener('pointerup',end,{once:true});grip.addEventListener('pointercancel',end,{once:true});
 }
 applyPosition(id,element,position){
  const left=Math.min(Math.max(0,Number(position.left)||0),Math.max(0,window.innerWidth-element.offsetWidth));
  const top=Math.min(Math.max(0,Number(position.top)||0),Math.max(0,window.innerHeight-element.offsetHeight));
  element.style.position='fixed';element.style.left=left+'px';element.style.top=top+'px';element.style.right='auto';element.style.bottom='auto';element.style.transform='none';
 }
 reset(){
  this.setEditing(false);this.positions={};this.hidden.clear();
  for(const [id,element] of this.elements){
   element.classList.remove('widget-hidden','rank-collapsed');
   for(const property of ['position','left','top','right','bottom','transform','width','zIndex'])element.style.removeProperty(property.replace(/[A-Z]/g,letter=>'-'+letter.toLowerCase()));
   const checkbox=this.checkboxes.get(id);if(checkbox)checkbox.checked=true;
  }
  this.persist();const status=document.getElementById('layout-status');if(status)status.textContent='Tela restaurada para a posição padrão.';
 }
}
