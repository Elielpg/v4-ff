import {DEFAULT_COMMAND_RULES,DEFAULT_GIFT_RULES,ruleActionLabel} from './audience.js';

const ASSETS={
 rose:'/interaction-rose.svg',
 gift:'/interaction-gift.svg',
 power:'/interaction-power.svg',
 chat:'/interaction-chat.svg',
 mission:'/interaction-mission.svg',
 alien:'/interaction-alien.svg',
 run:'/interaction-run.svg'
};

const safeText=value=>String(value||'').replace(/[<>\x00-\x1f]/g,'').slice(0,120);
const iconForGift=name=>/rose|rosa/i.test(name||'')?'rose':'gift';
const commandFor=(rules,predicate,fallback)=>rules.find(predicate)?.command||fallback;

export function buildInteractionCards(config={},names={}){
 const gifts=Array.isArray(config.giftRules)?config.giftRules:DEFAULT_GIFT_RULES;
 const commands=Array.isArray(config.commandRules)?config.commandRules:DEFAULT_COMMAND_RULES;
 const gift=gifts.find(rule=>/^(rose|rosa)$/i.test(String(rule.name||'').trim()))||gifts.find(rule=>rule.power)||gifts[0];
 const giftAction=gift?ruleActionLabel(gift,names)||'uma ação especial':'configure um presente no Laboratório';
 const powerCommand=commandFor(commands,rule=>rule.power,'/poder');
 const missionCommand=commandFor(commands,rule=>rule.mission||rule.missionKind,'/missao');
 return [
  {id:'gift',source:gift?.name||'Presente',detail:gift?giftAction:'configure um presente',sourceIcon:gift?iconForGift(gift.name):'gift',targetIcon:gift?.power?'power':gift?.mission||gift?.missionKind?'mission':gift?.movement==='run'||gift?.movement==='dash'||gift?.movement==='fly'?'run':'alien',hint:'Envie o presente configurado'},
  {id:'power',source:powerCommand,detail:'poder da forma atual',sourceIcon:'chat',targetIcon:'power',hint:'Escreva no chat'},
  {id:'mission',source:missionCommand,detail:'novo pedido de ajuda',sourceIcon:'chat',targetIcon:'mission',hint:'Peça uma missão'},
  {id:'transform',source:'Nome de um alien',detail:'transformar o Ben',sourceIcon:'chat',targetIcon:'alien',hint:'Ex.: Chama, XLR8 ou Diamante'}
 ];
}

function image(icon,alt,className){
 const node=document.createElement('img');
 node.src=ASSETS[icon]||ASSETS.gift;node.alt=alt;node.className=className;node.decoding='async';
 return node;
}

export class LiveInteractionPanel{
 constructor(parent){
  this.cards=buildInteractionCards();this.index=0;
  this.element=document.createElement('aside');this.element.id='live-interactions';this.element.className='live-interactions';
  this.element.setAttribute('aria-label','Ações visuais para o público da LIVE');
  const header=document.createElement('div');header.className='live-interactions-head';
  const title=document.createElement('small');title.textContent='O PÚBLICO PODE FAZER';
  const live=document.createElement('span');live.className='interaction-live-dot';live.setAttribute('aria-hidden','true');
  header.append(title,live);
  this.card=document.createElement('div');this.card.className='live-interaction-card';this.card.setAttribute('aria-live','polite');
  this.latest=document.createElement('div');this.latest.className='live-interaction-event';this.latest.hidden=true;this.latest.setAttribute('aria-live','polite');
  this.element.append(header,this.card,this.latest);parent.append(this.element);
  this.renderCard(false);
  this.timer=setInterval(()=>this.advance(),4800);
 }
 setConfig(config,names={}){
  this.cards=buildInteractionCards(config,names);
  this.index%=this.cards.length;
  this.renderCard(false);
 }
 renderCard(animate=true){
  const item=this.cards[this.index];if(!item)return;
  const card=document.createElement('div');card.className='live-interaction-card'+(animate?' interaction-rise':'');
  const source=image(item.sourceIcon,item.source,'interaction-source-icon');
  const sourceLabel=document.createElement('strong');sourceLabel.textContent=item.source;
  const sourceHint=document.createElement('small');sourceHint.textContent=item.hint;
  const sourceText=document.createElement('span');sourceText.className='interaction-source-text';sourceText.append(sourceLabel,sourceHint);
  const arrow=document.createElement('span');arrow.className='interaction-arrow';arrow.textContent='→';arrow.setAttribute('aria-hidden','true');
  const target=image(item.targetIcon,item.detail,'interaction-target-icon');
  const targetText=document.createElement('strong');targetText.className='interaction-target-text';targetText.textContent=item.detail;
  card.append(source,sourceText,arrow,target,targetText);
  this.card.replaceWith(card);this.card=card;
 }
 advance(){
  if(!this.cards.length||document.hidden)return;
  this.index=(this.index+1)%this.cards.length;this.renderCard(true);
 }
 noteEvent(event,presentation){
  const type=event?.type||'event';
  const giftName=safeText(event?.gift||'Presente');
  const isRose=type==='gift'&&/rose|rosa/i.test(giftName);
  const icon=type==='gift'?(isRose?'rose':'gift'):type==='comment'?'chat':type==='follow'?'power':type==='share'?'mission':'alien';
  const title=document.createElement('strong');
  title.textContent=type==='gift'?giftName+' · '+safeText(event?.user||'Público'):safeText(presentation?.title||'Nova interação');
  const detail=document.createElement('small');
  detail.textContent=type==='gift'
   ?safeText(event?.reaction?.text||((event?.power?'Poder ativado':'Presente recebido')+(event?.count>1?' · '+event.count+'×':'')))
   :safeText(presentation?.detail||'O público participou da LIVE');
  const art=image(icon,type==='gift'?(isRose?'Rosa':'Presente'):'Interação do público','interaction-event-icon');
  const row=document.createElement('div');row.className='live-interaction-event-row interaction-rise';row.append(art,document.createElement('span'));
  row.lastElementChild.append(title,detail);
  this.latest.replaceChildren(row);this.latest.hidden=false;
 }
}
