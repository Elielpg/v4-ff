import {CHUNK_LENGTH,chunkObjects,cityPalette} from './city.js';
import {cityForDistance,CITIES_BY_ID} from './traversal.js';
export class EndlessCity{
 constructor(world){this.world=world;this.chunks=new Map();this.lastOrigin=null;this.built=0;this.disposed=0;}
 build(index){
  const B=BABYLON,w=this.world,city=cityForDistance(Math.max(0,index*CHUNK_LENGTH)),id=typeof city==='string'?city:city.id,root=new B.TransformNode('street-chunk-'+index,w.scene),groups=new Map();
  for(const [i,o] of chunkObjects(index,id).entries()){const mesh=w.mesh(o,'chunk-'+index+'-'+i),collision=Math.abs(o.p[0])>10&&o.p[1]>1;mesh.isPickable=collision;mesh.checkCollisions=collision;mesh.receiveShadows=true;const key=mesh.material.uniqueId+':'+collision;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(mesh);}
  const meshes=[];for(const group of groups.values()){const collision=group[0].checkCollisions,mesh=group.length>1?B.Mesh.MergeMeshes(group,true,true):group[0];if(!mesh)continue;mesh.parent=root;mesh.isPickable=collision;mesh.checkCollisions=collision;mesh.receiveShadows=true;meshes.push(mesh);if(collision)w.shadow.addShadowCaster(mesh);}
  const theme=CITIES_BY_ID[id]||CITIES_BY_ID.bellwood,texture=new B.DynamicTexture('block-sign-'+index,{width:512,height:96},w.scene,false);texture.drawText(theme.name.toUpperCase(),null,62,'bold 34px sans-serif','#f4f5df','#193a33',true);const material=new B.StandardMaterial('block-sign-material-'+index,w.scene);material.diffuseTexture=texture;material.emissiveColor=new B.Color3(.2,.2,.16);const sign=B.MeshBuilder.CreatePlane('block-sign-'+index,{width:5.1,height:.96,sideOrientation:B.Mesh.DOUBLESIDE},w.scene);sign.position.set(-9.8,3.25,14);sign.rotation.y=Math.PI/2;sign.material=material;sign.parent=root;sign.isPickable=false;meshes.push(sign);
  root.position.z=index*CHUNK_LENGTH-(w.originZ||0);const chunk={index,root,meshes,material,texture,city:id};this.chunks.set(index,chunk);this.built++;return chunk;
 }
 remove(index){const chunk=this.chunks.get(index);if(!chunk)return;for(const mesh of chunk.meshes)this.world.shadow.removeShadowCaster(mesh);chunk.root.dispose(false,false);chunk.material.dispose(false,true);this.chunks.delete(index);this.disposed++;}
 update(distance,origin=0,quality='balanced'){
  const index=Math.floor(Math.max(0,distance)/CHUNK_LENGTH),behind=quality==='economy'?1:quality==='high'?3:2,ahead=quality==='economy'?2:quality==='high'?4:3,min=index-behind,max=index+ahead;
  for(const key of [...this.chunks.keys()])if(key<min||key>max)this.remove(key);
  for(let n=min;n<=max;n++)if(!this.chunks.has(n))this.build(n);
  if(this.lastOrigin!==origin||this.lastIndex!==index){for(const chunk of this.chunks.values())chunk.root.position.z=chunk.index*CHUNK_LENGTH-origin;this.lastOrigin=origin;this.lastIndex=index;}
 }
 stats(){return {resident:this.chunks.size,built:this.built,disposed:this.disposed,indices:[...this.chunks.keys()].sort((a,b)=>a-b),length:CHUNK_LENGTH};}
 dispose(){for(const key of [...this.chunks.keys()])this.remove(key);}
}
