import {constrainArena} from './arena-commands.js';
export const CAMP_OBSTACLES=[{type:'box',minX:-5.8,maxX:-1.6,minZ:4.5,maxZ:11.5},...[[ -8,6,1.2],[-10,-7,1],[7,-7,1.1],[-4,3,.85]].map(([x,z,r])=>({type:'circle',x,z,r}))];
export function blockedInCamp(x,z){return CAMP_OBSTACLES.some(o=>o.type==='box'?x>o.minX&&x<o.maxX&&z>o.minZ&&z<o.maxZ:Math.hypot(x-o.x,z-o.z)<o.r);}
export function moveInCamp(from,x,z,flying=false){const next=constrainArena(x,z);if(flying||!blockedInCamp(...next))return next;if(!blockedInCamp(next[0],from[1]))return [next[0],from[1]];if(!blockedInCamp(from[0],next[1]))return [from[0],next[1]];return from;}
