import {clean} from './transformations.js';
// Original in-game interpretations, not copies of TikTok's proprietary animations.
export const GIFT_SHOWS={
 rose:{icon:'🌹',title:'TEMPESTADE DE ROSAS',color:[1,.18,.42],duration:5.2},
 heart:{icon:'💗',title:'CORAÇÃO OMNITRIX',color:[1,.24,.65],duration:5.5},
 galaxy:{icon:'🌌',title:'GALÁXIA ALIENÍGENA',color:[.58,.28,1],duration:7},
 confetti:{icon:'🎉',title:'FESTA DOS HERÓIS',color:[1,.72,.12],duration:5},
 lightning:{icon:'⚡',title:'SOBRECARGA XLR8',color:[.12,.8,1],duration:4.8},
 lion:{icon:'🦁',title:'RUGIDO TITÂNICO',color:[1,.58,.12],duration:6},
 money:{icon:'💸',title:'CHUVA DE RECOMPENSAS',color:[.32,1,.45],duration:5.5},
 ice:{icon:'❄',title:'VÓRTICE CRISTALINO',color:[.2,.92,1],duration:5},
 rocket:{icon:'🚀',title:'DECOLAGEM OMNITRIX',color:[.25,.75,1],duration:6},
 meteor:{icon:'☄️',title:'CHUVA DE METEOROS',color:[1,.38,.1],duration:6},
 dragon:{icon:'🐉',title:'DRAGÃO DE PLASMA',color:[.4,1,.3],duration:6.5},
 crown:{icon:'👑',title:'COROA DOS HERÓIS',color:[1,.76,.2],duration:5.5},
 butterfly:{icon:'🦋',title:'ASAS DA AVENTURA',color:[.5,.55,1],duration:5.5},
 fireworks:{icon:'🎆',title:'FESTIVAL OMNITRIX',color:[1,.3,.7],duration:6},
 energy:{icon:'🎁',title:'PRESENTE DE OUTRO MUNDO',color:[.5,1,.2],duration:4.5}
};
export function giftShowKind(name){const s=clean(name);if(/rocket|foguete/.test(s))return 'rocket';if(/meteor|cometa/.test(s))return 'meteor';if(/dragon|dragao/.test(s))return 'dragon';if(/crown|coroa/.test(s))return 'crown';if(/butterfl|borboleta/.test(s))return 'butterfly';if(/firework|fogos/.test(s))return 'fireworks';if(/univers|galax|planet/.test(s))return 'galaxy';if(/rose|rosa/.test(s))return 'rose';if(/heart|coracao|amor/.test(s))return 'heart';if(/confet|party|festa/.test(s))return 'confetti';if(/lightning|raio|tiktok|gg/.test(s))return 'lightning';if(/lion|leao/.test(s))return 'lion';if(/money|dinheiro/.test(s))return 'money';if(/ice|sorvet|gelo|snow/.test(s))return 'ice';return 'energy';}
export const ENERGY_LEVELS=[{at:0,name:'PORTADOR'},{at:250,name:'HERÓI'},{at:1000,name:'GUARDIÃO'},{at:3000,name:'SUPERCARGA'},{at:7000,name:'OMNI MASTER'},{at:15000,name:'PODER MÁXIMO'}];
export function energyLevel(total){total=Math.max(0,Number(total)||0);let index=0;while(index<ENERGY_LEVELS.length-1&&total>=ENERGY_LEVELS[index+1].at)index++;const current=ENERGY_LEVELS[index],next=ENERGY_LEVELS[index+1];return {level:index+1,name:current.name,total,current:total-current.at,required:next?next.at-current.at:null,percent:next?Math.min(100,(total-current.at)/(next.at-current.at)*100):100,next:next?.name||'MAX'};}
