// Stance/swing timing is shared by the skin rig and the articulated pedestrians.
// The foot remains level through support, then rolls off and clears the ground.
const TAU=Math.PI*2;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const ease=v=>{const t=clamp(v);return t*t*(3-2*t);};
const cycle=v=>((v%1)+1)%1;
export function gaitStep(phase,{running=false,quadruped=false,skating=false}={}){
 const t=cycle(phase/TAU),duty=running?.43:.62,stance=t<duty,part=stance?t/duty:(t-duty)/(1-duty),reach=skating?.18:running?.55:.39;
 const z=stance?-reach+reach*2*part:reach*(1-2*ease(part));
 const lift=stance?0:Math.sin(Math.PI*part)**1.35*(running?.26:.17);
 // Solve a symmetric two-link leg. Normalized length is one, root grounding
 // handles authored meshes with different ankle/toe thicknesses.
 const down=(running?.81:.90)-lift,dist=clamp(Math.hypot(down,z),.1,.995),knee=Math.acos(clamp((dist*dist-.5)/.5,-1,1)),hip=Math.atan2(-z,down)+knee*.5;
 const heel=stance?(1-ease(part/.18))*.12-ease((part-.76)/.24)*.18:Math.sin(Math.PI*part)*.10;
 return {phase:t,stance,hip,knee,ankle:-hip+knee+heel,lift,z,heel};
}
export function gaitCycle(phase,options={}){
 const left=gaitStep(phase,options),right=gaitStep(phase+Math.PI,options),running=!!options.running;
 return {left,right,pelvisY:running?Math.sin(phase*2)*.014:Math.cos(phase*2)*.010,hipYaw:Math.sin(phase)*(running?.06:.038),hipRoll:Math.cos(phase)*(running?.028:.021),shoulderYaw:-Math.sin(phase)*(running?.10:.062)};
}
function installAnkles(actor){
 if(actor._anklesInstalled)return;actor._anklesInstalled=true;
 const B=globalThis.BABYLON;if(!B||!actor.parts)return;
 for(const side of ['L','R']){const shin=actor.rig?.['shin'+side];if(!shin?.getScene)continue;const foot=new B.TransformNode(actor.name+'-ankle'+side,shin.getScene());foot.parent=shin;foot.position.set(0,-.43,-.06);actor.rig['foot'+side]=foot;
  for(const part of actor.parts){const mesh=part.m;if(mesh.parent!==shin||!mesh.getBoundingInfo)continue;const box=mesh.getBoundingInfo().boundingBox;if(box.maximum.y<-.29&&box.minimum.y<-.4){mesh.computeWorldMatrix(true);foot.computeWorldMatrix(true);mesh.setParent(foot);}}
 }
}
export function animatePedestrian(actor,dt,{state='walk',speed=1,phase}={}){
 const r=actor?.rig;if(!r)return false;installAnkles(actor);
 actor._pedestrianTime=(actor._pedestrianTime||0)+Math.max(0,dt);const time=actor._pedestrianTime;
 const gesture=['wave','cheer','jump','spin'].includes(state),moving=state==='walk'||state==='run',running=state==='run',p=gesture?time*5:Number.isFinite(phase)?phase:time*(running?8:5)*Math.max(.35,speed),gait=gaitCycle(p,{running});
 const alpha=dt>0?1-Math.exp(-Math.min(.12,dt)*14):1,turn=(node,key,value)=>{if(node)node.rotation[key]+=(value-node.rotation[key])*alpha;};
 const gesturing=['greet','wave','talk','point','cheer'].includes(state),breath=Math.sin(time*1.7)*.012;
 turn(r.torso,'x',running?.12:breath);turn(r.torso,'y',moving?gait.shoulderYaw:Math.sin(time*.9)*.018);turn(r.torso,'z',moving?gait.hipRoll*.5:0);
 turn(r.head,'x',state==='talk'?Math.sin(time*4)*.035:-breath*.45);turn(r.head,'y',gesturing?Math.sin(time*1.4)*.07:Math.sin(time*.8)*.025);
 for(const side of ['L','R']){
  const physical=side==='L'?-1:1,leg=side==='L'?gait.left:gait.right,armSide=side==='L'?gait.right:gait.left;
  turn(r['leg'+side],'x',moving?leg.hip:0);turn(r['shin'+side],'x',moving?-leg.knee:0);turn(r['foot'+side],'x',moving?leg.ankle:0);
  let armX=moving?-armSide.hip*(running?.85:.65):-.025,armZ=physical*.045,elbowX=moving?(running?-.75:-.18)-Math.max(0,-armSide.hip)*.28:-.13,foreZ=0;
  if((state==='greet'||state==='wave')&&side==='R'){armX=-.13;armZ=2.2;elbowX=-.25;foreZ=Math.sin(time*5)*.32;}
  else if(state==='cheer'){armX=-.95;armZ=physical*.85;elbowX=-.65;}
  else if(state==='point'&&side==='R'){armX=1.18;armZ=.10;elbowX=-.18;}
  else if(state==='talk'){armX=.18+Math.sin(time*2.1+physical)*.11;armZ=physical*(.12+Math.sin(time*1.4)*.04);elbowX=-.48-Math.sin(time*2+physical)*.15;}
  turn(r['arm'+side],'x',armX);turn(r['arm'+side],'z',armZ);turn(r['forearm'+side],'x',elbowX);turn(r['forearm'+side],'z',foreZ);
 }
 if(state==='spin')turn(r.torso,'y',Math.sin(time*2.8)*.9);
 actor.gaitOffset=moving?gait.pelvisY:state==='jump'?Math.max(0,Math.sin(time*7))*.48:0;
 for(const part of actor.parts||[])if(part.role==='blink'){const closed=Math.sin(time/1.8+actor.root.uniqueId)>.992;part.m.scaling.y=part.baseScale.y*(closed?.1:1);}
 return true;
}
