import {ruleActionLabel} from './audience.js';
export function interactionTips(config={}){const tips=[
 'Escreva o nome de um alien: Chama, XLR8, Diamante, Quatro Braços…',
 'Comente “dash” para uma arrancada do XLR8, “correr” ou “voar” para viajar.',
 'Peça um gesto: “acene”, “comemore” ou “pule” (também valem /acenar, /comemorar e /pular).',
 'Chame “Gwen, …” ou “Vô Max, …” para conversar com eles.',
 'Comente “poder” para usar a habilidade da forma atual.',
 'Escolha uma missão: “missão resgate”, “missão entrega”, “missão corrida” ou “missão busca”.',
 'Pergunte sobre Ben 10 clássico ou puxe qualquer outro assunto!',
 'Curtidas, compartilhamentos e follows somam pontos no ranking.'
 ];for(const rule of config.giftRules||[])tips.push(`Presente ${rule.name} → ${ruleActionLabel(rule,config.names)} · ${rule.points} pontos por unidade`);for(const rule of config.commandRules||[])tips.push(`Comente ${rule.command} → ${ruleActionLabel(rule,config.names)}`);return tips;}
