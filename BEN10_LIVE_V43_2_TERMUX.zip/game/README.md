# Ben 10 · Clareira LIVE · V43.2

Reparo do SIGILL ocorrido ao carregar/executar o clonador no Termux. Os modelos já foram convertidos e devem ser mantidos.

A compilação remove -mcpu=native/-march=native e usa ARMv8-A, com GGML_NATIVE, KleidiAI e variantes automáticas desativados. O CMake é reconfigurado com --fresh para não reutilizar as opções antigas. As opções anteriores ficam guardadas em cloning/native-before-repair-*.

Na instalação existente, depois de aplicar BEN10_REPARO_SIGILL_V43_2.zip:

```sh
cd ~/ben10-v34/game
bash local-ai.sh clone setup
bash local-ai.sh start
```

Setup reconhece os GGUF e reconstrói apenas o motor, sem consultar catálogos, baixar pesos ou repetir a conversão. Também existe bash local-ai.sh clone repair-native para reconstruir explicitamente. Pare a sessão com Ctrl+C antes de preparar a voz.

Se houver nova falha, o diagnóstico fica em ~/.local/share/ben10-local-ai/logs/clonagem-preview.log. A referência e a seleção anteriores são restauradas.

O perfil básico pode ser mais lento. A correção foi testada por compilação nativa Linux e testes de opções/fluxo; ainda precisa ser executada no GT3 para confirmar o desaparecimento do SIGILL.

[Guia](docs/V43_2_SIGILL.md)
