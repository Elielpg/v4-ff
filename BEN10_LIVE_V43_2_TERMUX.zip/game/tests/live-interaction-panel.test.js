import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildInteractionCards} from '../public/live-interaction-panel.js';

test('o painel mostra a imagem de rosa ligada ao poder',()=>{
 const rose=buildInteractionCards().find(item=>item.id==='gift');
 assert.equal(rose.source,'Rose');
 assert.equal(rose.sourceIcon,'rose');
 assert.equal(rose.targetIcon,'power');
 assert.match(rose.detail,/Chama/i);
 assert.match(rose.detail,/calor/i);
});

test('o painel acompanha presentes e comandos personalizados',()=>{
 const cards=buildInteractionCards({
  giftRules:[{name:'Rosa Azul',action:'tide',power:true}],
  commandRules:[{command:'/energia',power:true},{command:'/salvar',missionKind:'rescue'}]
 },{tide:'Aquático'});
 assert.equal(cards[0].source,'Rosa Azul');
 assert.equal(cards[0].detail,'Aquático + Jato de água');
 assert.equal(cards[1].source,'/energia');
 assert.equal(cards[2].source,'/salvar');
});
