import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,copyFile,chmod,symlink,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
const shellQuote=value=>"'"+value.replaceAll("'","'\\''")+"'";
const binary=command=>{const result=spawnSync('/bin/bash',['-c','command -v "$1"','installer-test',command],{encoding:'utf8'});if(result.status!==0)throw Error('Ferramenta de teste ausente: '+command);return result.stdout.trim();};
async function program(filename,content){await writeFile(filename,'#!/bin/bash\nset -eu\n'+content+'\n');await chmod(filename,0o755);}
async function fixture(options,run){
 const root=await mkdtemp(path.join(os.tmpdir(),'ben-install-test-')),bin=path.join(root,'bin'),templates=path.join(root,'templates'),trace=path.join(root,'trace');
 try{
  await mkdir(bin);await mkdir(templates);await mkdir(path.join(root,'scripts'));await copyFile('install.sh',path.join(root,'install.sh'));await writeFile(path.join(root,'scripts/check.js'),'console.log("Sintaxe simulada no teste do instalador");');await writeFile(trace,'');
  for(const command of ['dirname','mkdir','cp'])await symlink(binary(command),path.join(bin,command));
  const nodeTrace='printf "%s\\n" "node $*" >> "$INSTALL_TEST_TRACE"\n';
  await program(path.join(templates,'node'),nodeTrace+'exec '+shellQuote(process.execPath)+' "$@"');
  await program(path.join(templates,'npm'),'printf "%s\\n" "npm $*" >> "$INSTALL_TEST_TRACE"\nexit 0');
  await program(path.join(templates,'python'),'printf "%s\\n" "python $*" >> "$INSTALL_TEST_TRACE"\nprintf "Python 3.12.0\\n"');
  await program(path.join(bin,'pkg'),String.raw`printf '%s\n' "pkg $*" >> "$INSTALL_TEST_TRACE"
if [[ "$INSTALL_TEST_PKG_FAIL" != 0 ]]; then
 printf 'NO_PUBKEY 5A897D96E57CF20C: falha simulada no repositório extra termux-glibc\n' >&2
 exit 100
fi
for package in "$@"; do
 case "$package" in
  nodejs-lts) cp "$INSTALL_TEST_TEMPLATES/node" "$INSTALL_TEST_BIN/node"; cp "$INSTALL_TEST_TEMPLATES/npm" "$INSTALL_TEST_BIN/npm" ;;
  python) cp "$INSTALL_TEST_TEMPLATES/python" "$INSTALL_TEST_BIN/python3"; cp "$INSTALL_TEST_TEMPLATES/python" "$INSTALL_TEST_BIN/python" ;;
 esac
done`);
  if(options.node!=='missing'){
   if(options.node==='old')await program(path.join(bin,'node'),nodeTrace+String.raw`if [[ "$1" == --version || "$1" == -v ]]; then printf 'v22.18.0\n'; exit 0; fi
if [[ "$1" == -e ]]; then
 exec `+shellQuote(process.execPath)+String.raw` -e 'Object.defineProperty(process.versions,"node",{value:"22.18.0"});eval(process.argv[1]);' "$2"
fi
exec `+shellQuote(process.execPath)+' "$@"');
   else await copyFile(path.join(templates,'node'),path.join(bin,'node'));
  }
  if(!options.npmMissing)await copyFile(path.join(templates,'npm'),path.join(bin,'npm'));
  if(options.python!=='missing')await copyFile(path.join(templates,'python'),path.join(bin,options.python==='python'?'python':'python3'));
  await run({root,bin,trace,templates});
 }finally{await rm(root,{recursive:true,force:true});}
}
async function install(context,{pkgFail=false}={}){const result=spawnSync('/bin/bash',['install.sh'],{cwd:context.root,encoding:'utf8',timeout:15000,env:{...process.env,PATH:context.bin,INSTALL_TEST_TRACE:context.trace,INSTALL_TEST_TEMPLATES:context.templates,INSTALL_TEST_BIN:context.bin,INSTALL_TEST_PKG_FAIL:pkgFail?'1':'0'}});if(result.error)throw result.error;const calls=(await readFile(context.trace,'utf8')).trim().split('\n').filter(Boolean);return {...result,calls,pkg:calls.filter(line=>line.startsWith('pkg ')),npm:calls.filter(line=>line.startsWith('npm '))};}
const packages=result=>result.pkg.flatMap(line=>line.split(/\s+/).filter(value=>!['pkg','install','-y','--yes'].includes(value))).sort();
function completed(result){assert.equal(result.status,0,result.stderr);assert.deepEqual(result.npm,['npm ci --omit=dev --no-audit --no-fund','npm test','npm run build']);assert(result.calls.includes('node scripts/check.js'));}
for(const python of ['python3','python'])test('ferramentas prontas ('+python+') não consultam pkg nem repositório extra quebrado',()=>fixture({python},async context=>{const result=await install(context,{pkgFail:true});completed(result);assert.deepEqual(result.pkg,[]);}));
test('Python ausente instala somente python e prossegue com npm',()=>fixture({python:'missing'},async context=>{const result=await install(context);completed(result);assert.deepEqual(packages(result),['python']);assert.equal(result.pkg.length,1);}));
test('Node22.18 incompatível instala somente nodejs-lts e valida o runtime novo',()=>fixture({node:'old'},async context=>{const result=await install(context);completed(result);assert.deepEqual(packages(result),['nodejs-lts']);assert.equal(result.pkg.length,1);}));
test('npm ausente reinstala somente o pacote Node que fornece npm',()=>fixture({npmMissing:true},async context=>{const result=await install(context);completed(result);assert.deepEqual(packages(result),['nodejs-lts']);}));
test('Node/npm e Python ausentes pedem somente os dois pacotes necessários',()=>fixture({node:'missing',npmMissing:true,python:'missing'},async context=>{const result=await install(context);completed(result);assert.deepEqual(packages(result),['nodejs-lts','python']);assert.equal(result.pkg.length,1);}));
test('falha de assinatura com ferramenta necessária interrompe antes de qualquer npm',()=>fixture({python:'missing'},async context=>{const result=await install(context,{pkgFail:true});assert.notEqual(result.status,0);assert.deepEqual(packages(result),['python']);assert.deepEqual(result.npm,[]);assert.match(result.stdout+result.stderr,/reposit[oó]rio/i);assert.match(result.stdout+result.stderr,/assinatura/i);assert(!result.calls.some(line=>/trusted=yes|allow-unauthenticated|no-check-gpg|insecure/i.test(line)));}));
