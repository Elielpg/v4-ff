import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
test('reparo SIGILL recompila com ARMv8-A, limpa opções antigas e preserva modelos',()=>{
 const r=spawnSync('python3',['-m','unittest','discover','-s','tests','-p','clone_native_py_test.py'],{encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);
});
