import {test} from 'node:test';
import assert from 'node:assert/strict';
import {liveEventPresentation,rankPresentation} from '../public/live-engagement.js';
import {liveRankForPoints} from '../server/core.js';

test('live alerts have distinct, safe copy for arrivals, follows, gifts, shares and likes',()=>{
 const join=liveEventPresentation({type:'join',user:'<Ana>'});assert.match(join.title,/Ana/);assert.match(join.detail,/bem-vindo/i);
 const follow=liveEventPresentation({type:'follow',user:'Bia'});assert.match(follow.title,/Valeu por seguir/);assert(follow.voiceText);
 const gift=liveEventPresentation({type:'gift',user:'Caio',gift:'Rose',count:2,points:20,reaction:{text:'Caio ativou chama'}});assert.match(gift.title,/×2/);assert.match(gift.detail,/Caio ativou chama/);assert.match(gift.voiceText,/Obrigado/);
 assert.match(liveEventPresentation({type:'share',user:'Dani',points:1}).title,/compartilhar/i);
 assert.match(liveEventPresentation({type:'like',user:'Eli',count:10,points:10}).title,/10 curtidas/);
 const comment=liveEventPresentation({type:'comment',user:'<svg>',text:'<script>teste</script>'});assert.equal(comment.title,'@svg entrou na conversa');assert.equal(comment.detail,'scriptteste/script');
});

test('nível e progresso do ranking seguem os pontos do servidor',()=>{
 for(const points of [0,24,25,99,100,299,300,749,750,1999,2000,10000])assert.deepEqual(rankPresentation(points),liveRankForPoints(points));
 assert.equal(rankPresentation(50).rankName,'Fã');assert.equal(rankPresentation(50).rankProgress,33);
});
