import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,cp,symlink,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
test('HTTP: oi e olá em sequência respondem; pergunta completa usa IA e informa progresso',{timeout:15000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben43-delivery-'));let child;
 const port=42000+Math.floor(Math.random()*10000),base='http://127.0.0.1:'+port;
 const get=route=>fetch(base+'/api/'+route).then(r=>r.json());
 const post=async(route,data)=>{const r=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});const body=await r.json();assert(r.ok,JSON.stringify(body));return body;};
 try{
  await cp('server',path.join(temp,'server'),{recursive:true});await cp('public',path.join(temp,'public'),{recursive:true});await symlink(path.resolve('node_modules'),path.join(temp,'node_modules'),'dir');await writeFile(path.join(temp,'package.json'),'{"type":"module"}');
  child=spawn(process.execPath,['--import',path.resolve('tests/fixtures/gemini-preload.js'),'server/index.js'],{cwd:temp,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw Error('Servidor não iniciou');})]);
  await post('config',{hostSpeech:false});
  for(const text of ['oi','olá']){await post('event',{type:'comment',user:'Ana',text});const item=(await get('health')).queue.active;assert(item);assert.equal(item.prompt,text);const answer=await post('answer',{id:item.id});assert.equal(answer.mode,'social');assert(answer.text.startsWith('Ana,'));await post('ack',{id:item.id});}
  await post('event',{type:'comment',user:'Ana',text:'Oi, quanto é 5 mais 7?'});const item=(await get('health')).queue.active;assert.equal(item.prompt,'Oi, quanto é 5 mais 7?');
  await post('keys',{action:'add',label:'Fixture',key:'fixture_GEMINI_VALID_A_123456789',activate:true});const answer=await post('answer',{id:item.id});assert.equal(answer.mode,'gemini');assert(answer.text.includes('Doze'));
  await post('speech-progress',{id:item.id,state:'voice'});assert.equal((await get('health')).speech.state,'voice');assert.equal((await get('health')).queue.active.id,item.id);
 }finally{if(child?.exitCode===null){child.kill();await once(child,'exit');}await rm(temp,{recursive:true,force:true});}
});
