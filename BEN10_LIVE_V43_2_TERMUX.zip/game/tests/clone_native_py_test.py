import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, str(Path("scripts/local-ai").resolve()))
import clone_native
import clone_setup


class NativeTests(unittest.TestCase):
    def test_arm_profile_does_not_rely_on_native_or_optional_extensions(self):
        machine, flags = clone_native.cpu_profile("aarch64")
        self.assertEqual(machine, "aarch64"); self.assertEqual(flags, "-march=armv8-a")
        commands = clone_native.build_commands(Path("/fixture/qwen3-tts.cpp"), flags)
        text = json.dumps(commands)
        self.assertIn("-DGGML_NATIVE=OFF", text); self.assertIn("-DGGML_CPU_ARM_ARCH=armv8-a", text)
        self.assertIn("-DGGML_CPU_KLEIDIAI=OFF", text); self.assertIn("-DGGML_CPU_ALL_VARIANTS=OFF", text)
        self.assertEqual(sum("--fresh" in command for command in commands), 2)
        self.assertNotIn("=native", text); self.assertNotIn("+sve", text); self.assertNotIn("+i8mm", text)
        for old in ["-march=native", "-mcpu=native", "-mtune=native"]:
            self.assertNotIn(old, clone_native.patch_native_flags('set(CMAKE_CXX_FLAGS_RELEASE "-O3 '+old+'")'))

    def test_rebuild_only_changes_native_code_and_preserves_model_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); source=root/"qwen3-tts.cpp"; (source/"ggml").mkdir(parents=True)
            (source/"CMakeLists.txt").write_text('set(CMAKE_CXX_FLAGS_RELEASE "-O3 -mcpu=native")')
            (source/"ggml/CMakeLists.txt").write_text("project(fixture)")
            model=root/"cloning/models/model.gguf"; model.parent.mkdir(parents=True); model.write_bytes(b"GGUF-preserve")
            manifest=root/"install.json"; manifest.write_bytes(b'{"voiceEngine":"piper"}')
            calls=[]
            def run(command, **kwargs):
                calls.append(command)
                if "--build" in command:
                    build=Path(command[command.index("--build")+1]); build.mkdir(parents=True,exist_ok=True)
                    (build/"compile_commands.json").write_text(json.dumps([{"command":"clang++ -march=armv8-a -O3 -c fixture.cpp"}]))
                    output=build/"src/libggml.so" if build.parent.name=="ggml" else build/"libqwen3tts.so"
                    output.parent.mkdir(parents=True,exist_ok=True); output.write_bytes(b"ELF-fixture")
            record=clone_native.rebuild(root,run=run,machine="aarch64",verify_source=False)
            self.assertEqual(len(calls),4); self.assertEqual(record["profile"],clone_native.PROFILE)
            self.assertEqual(model.read_bytes(),b"GGUF-preserve"); self.assertEqual(manifest.read_bytes(),b'{"voiceEngine":"piper"}')
            self.assertNotIn("native",(source/"CMakeLists.txt").read_text())
            with mock.patch.object(clone_native.platform,"machine",return_value="aarch64"):
                self.assertTrue(clone_native.portable_ready(root))
                (source/"build/libqwen3tts.so").write_bytes(b"changed-binary")
                self.assertFalse(clone_native.portable_ready(root))

    def test_cached_native_flags_are_rejected_before_profile_is_marked_ready(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)
            for sub in ["build","ggml/build"]:
                (source/sub).mkdir(parents=True)
                (source/sub/"compile_commands.json").write_text(json.dumps([{"command":"clang++ -march=armv8-a -mcpu=native -c f.cpp"}]))
            with self.assertRaises(ValueError): clone_native.check_compile_commands(source,"aarch64")

    def test_setup_rebuilds_only_engine_when_converted_models_are_present(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); (root/"install.json").write_text('{"voiceModel":"piper.onnx"}')
            folder=root/"cloning/models"; folder.mkdir(parents=True)
            for name in ["qwen3-tts-0.6b-f16.gguf","qwen3-tts-tokenizer-f16.gguf"]:(folder/name).write_bytes(b"GGUF fixture")
            calls=[]
            def run(command,**kwargs):
                calls.append(command)
                if "--preview" in command: raise subprocess.CalledProcessError(-4,command)
            with mock.patch.object(clone_setup,"installed",return_value=False),self.assertRaisesRegex(RuntimeError,"SIGILL"):
                clone_setup.setup(root,Path.cwd(),run=run,probe=lambda:None)
            self.assertEqual(calls[0][-1],"repair-native"); self.assertTrue((root/"logs/clonagem-preview.log").is_file())
            for name in ["qwen3-tts-0.6b-f16.gguf","qwen3-tts-tokenizer-f16.gguf"]:self.assertEqual((folder/name).read_bytes(),b"GGUF fixture")
            self.assertEqual(json.loads((root/"install.json").read_text()),{"voiceModel":"piper.onnx"})


if __name__=="__main__": unittest.main()
