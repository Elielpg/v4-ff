import hashlib
import http.client
import importlib.util
import io
import json
import tempfile
import threading
import unittest
import wave
import urllib.error
from unittest import mock
from pathlib import Path


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


worker = module("worker", "scripts/local-ai/tts_server.py")
downloads = module("downloads", "scripts/local-ai/download_models.py")


class LocalTests(unittest.TestCase):
    def test_voice_bridge_literal_text_and_origin_guard(self):
        spoken = []

        class Voice:
            def synthesize_wav(self, text, output):
                spoken.append(text)
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(22050)
                output.writeframes(b"\0" * 220)

        server = worker.make_server(Voice(), 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            connection = http.client.HTTPConnection("127.0.0.1", server.server_port)
            connection.request("POST", "/synthesize", json.dumps({"text": "E aí, Ana!"}), {"Content-Type": "application/json"})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            with wave.open(io.BytesIO(response.read())) as wav_file:
                self.assertEqual(wav_file.getframerate(), 22050)
            self.assertEqual(spoken, ["E aí, Ana!"])
            connection.request("POST", "/synthesize", json.dumps({"text": "não falar"}), {"Content-Type": "application/json", "Origin": "https://external.example"})
            self.assertEqual(connection.getresponse().status, 403)
            self.assertEqual(spoken, ["E aí, Ana!"])
            connection.close()
        finally:
            server.shutdown()
            server.server_close()

    def test_voice_only_switch_does_not_download_text_and_commits_last(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            manifest = {"textModel": "/installed/model.gguf", "textRepo": "existing/model", "voiceModel": str(root / "voices/pt_BR-faber-medium.onnx")}
            (root / "install.json").write_text(json.dumps(manifest))
            info = {"sha": "a" * 40, "siblings": [{"rfilename": "pt/pt_BR/cadu/medium/" + name, "blobId": "b" * 40} for name in ["pt_BR-cadu-medium.onnx", "pt_BR-cadu-medium.onnx.json", "MODEL_CARD"]]}
            fetched = []

            def fetch(repo, revision, record, dest):
                fetched.append(record["rfilename"])
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(json.dumps({"espeak": {"voice": "pt-br"}}) if dest.name.endswith(".json") else "fixture")

            with mock.patch.object(downloads, "metadata", return_value=info), mock.patch.object(downloads, "download", side_effect=fetch):
                downloads.switch_voice(root, "cadu")
            selected = json.loads((root / "install.json").read_text())
            self.assertEqual(selected["textModel"], manifest["textModel"])
            self.assertEqual(selected["textRepo"], manifest["textRepo"])
            self.assertTrue(selected["voiceModel"].endswith("cadu/pt_BR-cadu-medium.onnx"))
            self.assertEqual(len(fetched), 3)
            self.assertFalse(any("gguf" in f for f in fetched))
            saved = (root / "install.json").read_bytes()
            with mock.patch.object(downloads, "metadata", return_value=info), mock.patch.object(downloads, "download", side_effect=ValueError("hash inválido")):
                with self.assertRaises(ValueError):
                    downloads.switch_voice(root, "cadu")
            self.assertEqual((root / "install.json").read_bytes(), saved)
            with self.assertRaises(ValueError):
                downloads.switch_voice(root, "../outra")

    def test_model_hashes_and_quant_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            model = Path(directory) / "model.gguf"
            model.write_bytes(b"GGUF fixture")
            entry = {"rfilename": "model-Q4_K_M.gguf", "lfs": {"size": model.stat().st_size, "sha256": hashlib.sha256(model.read_bytes()).hexdigest()}}
            self.assertTrue(downloads.verify(model, entry))
            model.write_bytes(b"corrupt")
            self.assertFalse(downloads.verify(model, entry))
            self.assertEqual(downloads.choose_quant({"siblings": [entry]}), entry)
            with self.assertRaises(ValueError):
                downloads.choose_quant({"siblings": [{"rfilename": "../bad-Q4_K_M.gguf"}]})
            card = Path(directory) / "MODEL_CARD"
            card.write_bytes(b"creditos")
            oid = hashlib.sha1(b"blob 8\0creditos").hexdigest()
            self.assertTrue(downloads.verify(card, {"size": 8, "blobId": oid, "lfs": None}))
            downloads.check_record({"rfilename":"MODEL_CARD", "size":8, "blobId":oid, "lfs":None})

    def test_default_uses_public_catalog_confirmed_on_device(self):
        info = {"id": "unsloth/Qwen3-4B-Instruct-2507-GGUF", "sha": "a" * 40, "private": False, "gated": False, "siblings": [{"rfilename": "Qwen3-4B-Instruct-2507-Q4_K_M.gguf"}]}
        requested = []

        def fetch(url, **kwargs):
            requested.append(url)
            if "api/models/unsloth/" not in url:
                raise urllib.error.HTTPError(url, 401, "Unauthorized", None, None)
            return io.BytesIO(json.dumps(info).encode())

        with mock.patch.object(downloads.urllib.request, "urlopen", side_effect=fetch):
            repo, _, record = downloads.choose_model("gt3")
        self.assertEqual(repo, info["id"])
        self.assertEqual(record["rfilename"], "Qwen3-4B-Instruct-2507-Q4_K_M.gguf")
        self.assertEqual(len(requested), 1)
        self.assertTrue(requested[0].endswith("?blobs=true"))

    def test_unavailable_catalog_401_can_try_another_configured_public_repo(self):
        info = {"sha": "a" * 40, "siblings": [{"rfilename": "model-Q4_K_M.gguf"}]}
        with mock.patch.dict(downloads.MODELS, {"gt3": ["unavailable/model", "public/model"]}), mock.patch.object(downloads, "metadata", side_effect=[downloads.CatalogError("unavailable/model", 401, "indisponível"), info]) as get:
            self.assertEqual(downloads.choose_model("gt3")[0], "public/model")
            self.assertEqual(get.call_count, 2)

    def test_rate_limit_does_not_rotate_catalogs(self):
        with mock.patch.dict(downloads.MODELS, {"gt3": ["one/model", "two/model"]}), mock.patch.object(downloads, "metadata", side_effect=downloads.CatalogError("one/model", 429, "limite")) as get:
            with self.assertRaises(downloads.CatalogError) as error:
                downloads.choose_model("gt3")
            self.assertEqual(error.exception.status, 429)
            self.assertEqual(get.call_count, 1)

    def test_private_or_gated_catalogs_are_not_used(self):
        for flags in [{"private": True}, {"gated": "manual"}]:
            info = {"sha": "a" * 40, **flags}
            with mock.patch.object(downloads.urllib.request, "urlopen", return_value=io.BytesIO(json.dumps(info).encode())):
                with self.assertRaises(downloads.CatalogError) as error:
                    downloads.metadata("fixture/restricted")
                self.assertEqual(error.exception.status, 403)

    def test_voice_catalog_failure_happens_before_any_model_download(self):
        record = {"rfilename": "model-Q4_K_M.gguf", "lfs": {"size": 100, "sha256": "a" * 64}}
        info = {"sha": "a" * 40, "siblings": [record]}
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(downloads.shutil, "disk_usage", return_value=mock.Mock(free=10 * 1024**3)), mock.patch.object(downloads, "metadata", side_effect=[info, downloads.CatalogError(downloads.VOICE_REPO, 401, "indisponível")]), mock.patch.object(downloads, "download") as fetch:
            with self.assertRaises(downloads.CatalogError):
                downloads.install(Path(folder), "gt3")
            fetch.assert_not_called()
            self.assertFalse((Path(folder) / "install.json").exists())

    def test_partial_download_resumes_and_checksum_is_verified(self):
        data = b"GGUF fixture for a resumed download"
        record = {"rfilename": "model.gguf", "lfs": {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}}

        class Response(io.BytesIO):
            status = 206

        with tempfile.TemporaryDirectory() as folder:
            dest = Path(folder) / "model.gguf"
            partial = Path(str(dest) + ".part")
            partial.write_bytes(data[:7])

            def fetch(request, **kwargs):
                self.assertEqual(request.get_header("Range"), "bytes=7-")
                self.assertIsNone(request.get_header("Authorization"))
                return Response(data[7:])

            with mock.patch.object(downloads.urllib.request, "urlopen", side_effect=fetch) as get:
                downloads.download("public/model", "a" * 40, record, dest)
                downloads.download("public/model", "a" * 40, record, dest)
                self.assertEqual(get.call_count, 1)
            self.assertEqual(dest.read_bytes(), data)
            self.assertFalse(partial.exists())

    def test_file_auth_error_keeps_partial_and_reports_only_public_path(self):
        data = b"GGUF fixture"
        record = {"rfilename": "model.gguf", "lfs": {"size": len(data), "sha256": hashlib.sha256(data).hexdigest()}}
        with tempfile.TemporaryDirectory() as folder:
            dest = Path(folder) / "model.gguf"
            partial = Path(str(dest) + ".part")
            partial.write_bytes(data[:4])
            with mock.patch.object(downloads.urllib.request, "urlopen", side_effect=urllib.error.HTTPError("https://cdn.invalid/?signature=do-not-print", 401, "Unauthorized", None, None)):
                with self.assertRaisesRegex(ValueError, "public/model/model.gguf.*HTTP 401") as error:
                    downloads.download("public/model", "a" * 40, record, dest)
            self.assertNotIn("do-not-print", str(error.exception))
            self.assertEqual(partial.read_bytes(), data[:4])

if __name__ == "__main__":
    unittest.main()
