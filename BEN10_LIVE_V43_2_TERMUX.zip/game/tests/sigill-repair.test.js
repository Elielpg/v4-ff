import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,copyFile,rm,readdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import os from 'node:os';
test('reparo pequeno instala o motor compatível sem escrever nos modelos ou selecionar outra voz',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben432-small-')),game=path.join(temp,'game'),local=path.join(temp,'local');
 try{
  await mkdir(path.join(game,'scripts/local-ai'),{recursive:true});await mkdir(path.join(local,'cloning/models'),{recursive:true});
  await writeFile(path.join(game,'package.json'),'{"name":"linel-live-city","version":"43.1.0","type":"module"}');await copyFile('scripts/phone-update.js',path.join(game,'scripts/phone-update.js'));
  const original=Buffer.from('GGUF-modelo-convertido-preservado');const model=path.join(local,'cloning/models/qwen3-tts-0.6b-f16.gguf');await writeFile(model,original);await writeFile(path.join(local,'install.json'),'{"voiceEngine":"piper","fixture":true}');
  const r=spawnSync('bash',[path.resolve('REPARAR_SIGILL_V43_2.sh')],{cwd:game,env:{...process.env,TMPDIR:temp,BEN10_LOCAL_ROOT:local},encoding:'utf8'});assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Reparo SIGILL aplicado/);
  for(const name of ['clone_native.py','clone_setup.py','clone_voice.py','clone.sh'])assert.deepEqual(await readFile(path.join(game,'scripts/local-ai',name)),await readFile(path.join('scripts/local-ai',name)));
  assert.deepEqual(await readFile(model),original);assert.equal(await readFile(path.join(local,'install.json'),'utf8'),'{"voiceEngine":"piper","fixture":true}');assert.equal(JSON.parse(await readFile(path.join(game,'package.json'),'utf8')).version,'43.2.0');assert.equal((await readdir(path.join(game,'data/installer-backups'))).length,1);
 }finally{await rm(temp,{recursive:true,force:true});}
});
