import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
test('ponte nativa de clonagem valida amostra, português e ABI sem baixar pesos',()=>{
 const r=spawnSync('python3',['-m','unittest','discover','-s','tests','-p','clone_voice_py_test.py'],{encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);
});
