import {test} from 'node:test';
import assert from 'node:assert/strict';
import {gemini} from '../server/core.js';
import {answerComment} from '../server/conversation.js';

test('regressão: instruções e características nunca são concatenadas à frase enviada ao TTS',async()=>{
 const phrase='E aí, Ana! É hora de virar herói!';let request;
 await gemini(phrase,{key:'fixture',tts:true,speaker:'fourarms',voiceName:'Puck',voiceDirection:'Voz grave, heroica e animada.',fetcher:async(url,options)=>{
  request=JSON.parse(options.body);
  return Response.json({candidates:[{content:{parts:[{inlineData:{mimeType:'audio/L16',data:'AAAAAA=='}}]}}]});
 }});
 assert.deepEqual(request.contents,[{parts:[{text:phrase}]}]);
 assert.equal(request.systemInstruction,undefined);
 assert.equal(request.generationConfig.speechConfig.voiceConfig.prebuiltVoiceConfig.voiceName,'Puck');
 assert(!JSON.stringify(request).includes('Voz grave'));
});

test('na clareira só Ben clássico conversa, mesmo transformado ou quando chamam outro personagem',async()=>{
 let context;
 const answer=await answerComment({prompt:'Gwen, quem é você?',user:'Ana',speaker:'gwen'},{key:'fixture',context:{arena:true,form:'blaze'},generate:async(text,options)=>{context=options.context;return {text:'Sou o Ben Tennyson! A Gwen tá com o vô Max.',model:'fixture'};}});
 assert.equal(context.speaker,'base');assert.equal(context.form,'blaze');
 assert.equal(answer.speaker,'blaze','a animação continua na forma real');
 assert.match(answer.text,/Ben Tennyson/);
 const fallback=await answerComment({prompt:'Gwen, quem é você?',user:'Ana',speaker:'gwen'},{context:{arena:true,form:'blaze'}});
 assert.match(fallback.text,/Ben Tennyson/);assert(!fallback.text.includes('Eu sou Gwen'));
});

test('instruções do texto mantêm o clássico e proíbem narrar voz ou atuação antes da resposta',async()=>{
 let request;
 const answer=await gemini('Gwen, qual seu nome?',{key:'fixture',context:{arena:true,form:'fourarms',speaker:'gwen'},fetcher:async(url,options)=>{
  request=JSON.parse(options.body);
  return Response.json({candidates:[{content:{parts:[{text:'Eu sou Linel.exe!'}]}}]});
 }});
 const system=request.systemInstruction.parts[0].text;
 assert.match(system,/Ben Tennyson de dez anos/);
 assert.match(system,/somente a fala/);assert.match(system,/Não escreva descrições de voz/);
 assert.match(system,/personalidade continuam sempre|A forma muda os poderes e a aparência/);
 assert(!system.includes('Você interpreta exclusivamente Gwen'));
 assert.match(answer.text,/Ben Tennyson/);assert(!answer.text.includes('Linel'));
});
