import {test} from 'node:test';
import assert from 'node:assert/strict';
import B from 'babylonjs';
import {createPowerEffect,updatePowerEffect,disposePowerEffect} from '../public/power-effects.js';
globalThis.BABYLON=B;

function fixture(){
 const engine=new B.NullEngine(),scene=new B.Scene(engine),materials=new Map(),world={scene,quality:'balanced',previewActive:false,form:0,avatar:{root:new B.TransformNode('hero',scene)},powerUntil:0,powerAction:null};
 world.material=color=>{const key=color.join(',');if(!materials.has(key)){const material=new B.StandardMaterial('fixture-'+key,scene);material.diffuseColor=new B.Color3(...color);materials.set(key,material);}return materials.get(key);};
 world.mesh=({p,s,c},name)=>{const mesh=B.MeshBuilder.CreateSphere(name,{segments:6},scene);mesh.position.set(...p);mesh.scaling.set(...s);mesh.material=world.material(c);return mesh;};
 world.toLocalPosition=position=>new B.Vector3(position[0],position[1],position[2]);
 world.triggerLocomotion=()=>true;
 return {world,scene,engine};
}

test('efeitos novos dos poderes são válidos e a força cresce sem quebrar a geometria',()=>{
 const {world,scene,engine}=fixture();
 try{
  for(const [form,key] of [['base','scan'],['volt','bolts'],['beast','pulses'],['cannon','waves']]){
   const effect=createPowerEffect(world,{id:form.length,form,strength:5,position:[0,0,0]},new B.Vector3(0,0,-5));
   assert.equal(effect.strength,5);assert(effect.timeScale<1);assert(effect.sculpture[key].length>0);
   for(const dt of [.3,.6,.8])updatePowerEffect(world,effect,dt);
   assert(effect.sculpture.meshes.every(mesh=>[mesh.position.x,mesh.position.y,mesh.position.z,...mesh.scaling.asArray()].every(Number.isFinite)));
   assert(world.powerUntil>Date.now());disposePowerEffect(effect);
  }
 }finally{scene.dispose();engine.dispose();}
});

test('onze formas oferecem três poderes animados; Chama acende a boca no sopro',()=>{
 const {world,scene,engine}=fixture();
 try{
  for(const form of ['base','blaze','volt','rock','shade','tide','nova','beast','fourarms','cannon','wildvine'])for(let variant=0;variant<3;variant++){
   const effect=createPowerEffect(world,{id:form.length+variant,form,variant,strength:3,position:[0,0,0]},new B.Vector3(0,0,-5));
   assert.equal(effect.variant,variant);assert(effect.ability);if(form==='blaze'&&variant===0)assert(effect.sculpture.mouthGlow);
   for(const dt of [.2,.45,.65])updatePowerEffect(world,effect,dt);
   assert(effect.sculpture.meshes.every(mesh=>[mesh.position.x,mesh.position.y,mesh.position.z,...mesh.scaling.asArray()].every(Number.isFinite)),form+' variação '+variant);
   disposePowerEffect(effect);
  }
 }finally{scene.dispose();engine.dispose();}
});
