import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,copyFile,chmod,symlink,rm,readdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import os from 'node:os';

const binary=name=>{const r=spawnSync('/bin/bash',['-c','command -v "$1"','test',name],{encoding:'utf8'});assert.equal(r.status,0);return r.stdout.trim();};
const packages=['git','cmake','ninja','clang','python','curl','libandroid-spawn','proot-distro'];
const tools=['git','cmake','ninja','clang','clang++','python3','curl','proot-distro'];
async function fixture({missing=[],fail=false,deb822=null,mainSource='deb https://termux.net stable main\n'}={},run){
 const root=await mkdtemp(path.join(os.tmpdir(),'ben42 tools ')),bin=path.join(root,'bin'),prefix=path.join(root,'prefix'),tmp=path.join(root,'tmp'),trace=path.join(root,'trace.jsonl');
 try{
  for(const dir of [bin,tmp,path.join(prefix,'etc/apt/sources.list.d'),path.join(prefix,'var/lib/apt/lists')])await mkdir(dir,{recursive:true});
  await writeFile(path.join(prefix,'etc/apt/sources.list'),mainSource);if(deb822!==null)await writeFile(path.join(prefix,'etc/apt/sources.list.d/termux.sources'),deb822);
  const extra=path.join(prefix,'etc/apt/sources.list.d/glibc.list'),oldLists=path.join(prefix,'var/lib/apt/lists/original');
  await writeFile(extra,'deb https://packages-cf.termux.dev/apt/termux-glibc glibc main\n');await writeFile(oldLists,'lista anterior intacta');
  for(const command of ['mkdir','mktemp','rm','bash','cp'])await symlink(binary(command),path.join(bin,command));
  for(const tool of tools)if(!missing.includes(tool))await symlink('/bin/true',path.join(bin,tool));
  await writeFile(path.join(bin,'dpkg-query'),'#!/bin/bash\nprintf "install ok installed"\n');await chmod(path.join(bin,'dpkg-query'),0o755);
  const apt=`#!${binary('python3')}
import json,os,sys,pathlib
args=sys.argv[1:];options={}
for i,a in enumerate(args[:-1]):
 if a=='-o':
  key,value=args[i+1].split('=',1);options[key]=value
source=options.get('Dir::Etc::sourcelist');parts=options.get('Dir::Etc::sourceparts')
if not source or not parts:
 print('NO_PUBKEY 5A897D96E57CF20C: repositório extra termux-glibc',file=sys.stderr);sys.exit(100)
text=pathlib.Path(source).read_text()
assert text==os.environ['TERMUX_TEST_EXPECTED_SOURCE']
assert not list(pathlib.Path(parts).iterdir())
for key in ['Acquire::AllowInsecureRepositories','Acquire::AllowDowngradeToInsecureRepositories','APT::Get::AllowUnauthenticated']:assert options[key]=='false'
with open(os.environ['TERMUX_TEST_TRACE'],'a') as out:out.write(json.dumps({'args':args,'source':text,'options':options})+'\\n')
if os.environ['TERMUX_TEST_FAIL']=='1':
 print('NO_PUBKEY: falha simulada no repositório oficial',file=sys.stderr);sys.exit(100)
if 'install' in args:
 for name in ['ninja']:
  if name in args:
   target=pathlib.Path(os.environ['TERMUX_TEST_BIN'])/name
   if not target.exists():target.symlink_to('/bin/true')
`;
  await writeFile(path.join(bin,'apt-get'),apt);await chmod(path.join(bin,'apt-get'),0o755);
  const env={...process.env,PATH:bin,PREFIX:prefix,TMPDIR:tmp,TERMUX_TEST_TRACE:trace,TERMUX_TEST_FAIL:fail?'1':'0',TERMUX_TEST_BIN:bin,TERMUX_TEST_EXPECTED_SOURCE:deb822===null?mainSource:deb822};
  const execute=args=>spawnSync('/bin/bash',['scripts/termux-packages.sh',...args],{env,encoding:'utf8',timeout:10000});
  await run({root,bin,prefix,tmp,trace,execute,extra,oldLists,env});
  assert.equal(await readFile(path.join(prefix,'etc/apt/sources.list'),'utf8'),mainSource);
  if(deb822!==null)assert.equal(await readFile(path.join(prefix,'etc/apt/sources.list.d/termux.sources'),'utf8'),deb822);
  assert.equal(await readFile(extra,'utf8'),'deb https://packages-cf.termux.dev/apt/termux-glibc glibc main\n');
  assert.equal(await readFile(oldLists,'utf8'),'lista anterior intacta');assert.deepEqual(await readdir(tmp),[]);
 }finally{await rm(root,{recursive:true,force:true});}
}

test('ferramentas locais prontas não consultam APT, mesmo com glibc sem chave',()=>fixture({},async f=>{
 const r=f.execute(packages);assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Sem consultar pkg\/apt/);await assert.rejects(()=>readFile(f.trace),e=>e.code==='ENOENT');
}));

test('ferramenta ausente usa somente termux-main, conserva fontes/listas e mantém assinaturas',()=>fixture({missing:['ninja']},async f=>{
 const r=f.execute(packages);assert.equal(r.status,0,r.stderr);const calls=(await readFile(f.trace,'utf8')).trim().split('\n').map(s=>JSON.parse(s));assert.equal(calls.length,2);assert(calls[0].args.includes('update'));assert(calls[1].args.includes('install'));assert.equal(calls[1].args.at(-1),'ninja');assert(!calls[1].args.includes('clang'));assert(!calls[1].args.includes('git'));assert(calls.every(c=>c.options['Dir::State::lists'].startsWith(f.tmp+path.sep)));
}));

test('termux-main mantém Signed-By da configuração oficial sem copiar os extras',()=>fixture({missing:['ninja'],mainSource:'deb [signed-by=/keyrings/termux.gpg] https://packages.termux.dev/apt/termux-main stable main\n'},async f=>{const r=f.execute(packages);assert.equal(r.status,0,r.stderr);const call=JSON.parse((await readFile(f.trace,'utf8')).split('\n')[0]);assert(call.source.includes('signed-by=/keyrings/termux.gpg'));assert(!call.source.includes('glibc'));}));

test('assinatura inválida no oficial interrompe sem instalar e sem aceitar pacote não autenticado',()=>fixture({missing:['ninja'],fail:true},async f=>{
 const r=f.execute(packages);assert.notEqual(r.status,0);assert.match(r.stderr,/nenhuma assinatura foi ignorada/);const calls=(await readFile(f.trace,'utf8')).trim().split('\n').map(s=>JSON.parse(s));assert.equal(calls.length,1);assert(!calls[0].args.includes('install'));assert(!calls[0].args.includes('--allow-unauthenticated'));assert.equal(calls[0].options['APT::Get::AllowUnauthenticated'],'false');
}));

test('o comando geral antigo reproduz NO_PUBKEY, o novo avança até o download dos modelos',()=>fixture({missing:['ninja']},async f=>{
 const old=spawnSync(path.join(f.bin,'apt-get'),['update'],{env:f.env,encoding:'utf8'});assert.equal(old.status,100);assert.match(old.stderr,/5A897D96E57CF20C/);
 const game=path.join(f.root,'game');await mkdir(path.join(game,'scripts/local-ai'),{recursive:true});
 for(const name of ['scripts/termux-packages.sh','scripts/local-ai/install.sh'])await copyFile(name,path.join(game,name));
 for(const [name,body] of Object.entries({'node':'exit 0','pkg':'echo "pkg geral não deve ser chamado" >&2; exit 100','uname':'echo aarch64','dirname':'exec '+binary('dirname')+' "$@"'})){await writeFile(path.join(f.bin,name),'#!/bin/bash\n'+body+'\n');await chmod(path.join(f.bin,name),0o755);}
  await rm(path.join(f.bin,'python3'));await writeFile(path.join(f.bin,'python3'),'#!/bin/bash\ncase "$1" in */download_models.py) echo "DOWNLOAD_DE_MODELOS_ALCANCADO"; exit 77 ;; esac\nexit 0\n');await chmod(path.join(f.bin,'python3'),0o755);
 const r=spawnSync('/bin/bash',[path.join(game,'scripts/local-ai/install.sh')],{env:{...f.env,BEN10_LOCAL_ROOT:path.join(f.root,'models')},encoding:'utf8',timeout:10000});assert.equal(r.status,77,r.stderr);assert.match(r.stdout,/DOWNLOAD_DE_MODELOS_ALCANCADO/);
}));

test('iniciar/status não avisa .env ausente e continua carregando um .env existente',async()=>{
 const root=await mkdtemp(path.join(os.tmpdir(),'ben42-env-'));
 try{await mkdir(path.join(root,'scripts/local-ai'),{recursive:true});await copyFile('local-ai.sh',path.join(root,'local-ai.sh'));await writeFile(path.join(root,'package.json'),'{"type":"module"}');await writeFile(path.join(root,'scripts/local-ai/run.js'),'console.log(JSON.stringify({args:process.execArgv,value:process.env.BEN_FIXTURE_ONLY||null}));');
  const run=()=>spawnSync('/bin/bash',['local-ai.sh','status'],{cwd:root,encoding:'utf8'});let r=run();assert.equal(r.status,0,r.stderr);assert(!r.stderr.includes('.env not found'));assert(r.stdout,JSON.stringify(r));assert.deepEqual(JSON.parse(r.stdout).args,[]);
  await writeFile(path.join(root,'.env'),'BEN_FIXTURE_ONLY=teste_local\n');r=run();assert.equal(r.status,0,r.stderr);assert.equal(JSON.parse(r.stdout).value,'teste_local');assert(JSON.parse(r.stdout).args.some(a=>a.startsWith('--env-file=')));
 }finally{await rm(root,{recursive:true,force:true});}
});

const deb822Main='Types: deb\nURIs: https://termux.net\nSuites: stable\nComponents: main\nSigned-By: /keyrings/play-store-main.gpg\n';
test('regressão real do log: termux.sources tem prioridade sobre listas antigas e conserva Signed-By',()=>fixture({missing:['ninja'],mainSource:'deb https://packages.termux.dev/apt/termux-main stable main\n',deb822:deb822Main},async f=>{const r=f.execute(packages);assert.equal(r.status,0,r.stderr);assert.match(r.stdout,/Deb822/);const calls=(await readFile(f.trace,'utf8')).trim().split('\n').map(JSON.parse);assert(calls.every(c=>c.source===deb822Main));assert(calls.every(c=>c.options['Dir::Etc::sourcelist'].endsWith('.sources')));assert(!calls[0].source.includes('packages.termux.dev'));}));
test('Deb822 com chave pública inline é copiado sem perder linhas ou ponto de continuação',()=>fixture({missing:['ninja'],mainSource:'',deb822:deb822Main.replace('Signed-By: /keyrings/play-store-main.gpg','Signed-By: \n -----BEGIN PGP PUBLIC KEY BLOCK-----\n .\n ZmljdGljaW8=\n -----END PGP PUBLIC KEY BLOCK-----')},async f=>{const r=f.execute(packages);assert.equal(r.status,0,r.stderr);}));
test('sem fonte principal reconhecida não inventa endereço de outra edição',()=>fixture({missing:['ninja'],mainSource:'# configuração vazia\n'},async f=>{const r=f.execute(packages);assert.notEqual(r.status,0);assert.match(r.stderr,/Nenhum endereço alternativo/);await assert.rejects(()=>readFile(f.trace),e=>e.code==='ENOENT');}));
test('Deb822 que pede Trusted yes não é aceito como atalho de assinatura',()=>fixture({missing:['ninja'],deb822:deb822Main+'Trusted: yes\n'},async f=>{const r=f.execute(packages);assert.notEqual(r.status,0);assert.match(r.stderr,/dispensa autenticação/);await assert.rejects(()=>readFile(f.trace),e=>e.code==='ENOENT');}));
