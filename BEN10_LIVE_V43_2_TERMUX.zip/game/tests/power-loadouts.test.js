import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FORM_IDS,POWER_LOADOUTS,powerAbility} from '../public/transformations.js';

test('cada forma mantém três poderes nomeados e selecionáveis',()=>{
 assert.deepEqual(Object.keys(POWER_LOADOUTS),FORM_IDS);
 for(const form of FORM_IDS){
  const choices=POWER_LOADOUTS[form];
  assert.equal(choices.length,3,form);
  assert.equal(new Set(choices.map(choice=>choice.id)).size,3,form);
  assert.equal(new Set(choices.map(choice=>choice.name)).size,3,form);
  for(let variant=0;variant<3;variant++)assert.equal(powerAbility(form,variant).id,choices[variant].id);
 }
 assert.equal(powerAbility('blaze',0).id,'fire-breath');
 assert.equal(powerAbility('blaze',1).id,'fireball');
 assert.equal(powerAbility('blaze',2).id,'flame-burst');
});
