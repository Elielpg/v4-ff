import {test} from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,copyFile,mkdir,rm} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';import os from 'node:os';import path from 'node:path';

test('correção curta para a V42 antiga remove o endereço inacessível e mantém backup e sintaxe',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben42-model-fix-'));
 try{
  await mkdir(path.join(temp,'scripts/local-ai'),{recursive:true});
  const file=path.join(temp,'scripts/local-ai/download_models.py');
  await writeFile(file,'MODELS = {"gt3": ["Qwen/Qwen3-4B-Instruct-2507-GGUF", "unsloth/Qwen3-4B-Instruct-2507-GGUF"], "light": ["Qwen/Qwen2.5-1.5B-Instruct-GGUF"]}\n');
  const old=await readFile(file,'utf8');await copyFile(file,file+'.bak');
  const edited=spawnSync('sed',['-i','s@"Qwen/Qwen3-4B-Instruct-2507-GGUF", @@',file],{encoding:'utf8'});assert.equal(edited.status,0,edited.stderr);
  const check=spawnSync('python3',['-c','import runpy,sys;print(runpy.run_path(sys.argv[1])["MODELS"]["gt3"][0])',file],{encoding:'utf8'});assert.equal(check.status,0,check.stderr);assert.equal(check.stdout.trim(),'unsloth/Qwen3-4B-Instruct-2507-GGUF');assert.equal(await readFile(file+'.bak','utf8'),old);
  assert((await readFile(file,'utf8')).includes('Qwen2.5-1.5B'));
 }finally{await rm(temp,{recursive:true,force:true});}
});
