# Etapas locais V25

1. Auditoria: repositório original contém README e ZIP de .gitignore; kit ausente, prosseguimento autorizado pelo usuário. Concluída.
2. Motor/câmera: Babylon local, passeio frontal, seis zonas, construções e iluminação. Concluído em versão procedural básica.
3. Eventos/servidor: SSE, fila serial, regras, ranking e configuração. Implementado/testado localmente.
4. Voz/IA: REST Gemini, PCM/WAV, fallback e ducking implementados. Provedor real e Android não validados.
5. LIVE: PirateTok implementado e contrato testado com transporte controlado. LIVE real pendente.
6. Assets: onze formas geométricas e importação GLB disponíveis; modelagem fiel/rigging e animações avançadas pendentes.
7. Entrega: scripts Termux, pacote, relatório e evidências locais. Não equivale à aceitação visual final nem ao teste no dispositivo.
