import test from "node:test";
import assert from "node:assert/strict";
import { ArenaEngine, RULES } from "../server/engine.mjs";
function fixture() {
  let t = 100000;
  const actions = [],
    e = new ArenaEngine({ now: () => t, onAction: (a) => actions.push(a) });
  return {
    e,
    actions,
    advance: (n) => {
      t += n;
      e.tick();
    },
    get t() {
      return t;
    },
  };
}
const rose = (user, id = "") => ({
  type: "gift",
  user,
  name: user,
  gift: "Rosa",
  count: 1,
  repeatEnd: true,
  id,
});
function duel(f) {
  f.e.ingest(rose("ana"));
  f.e.ingest(rose("bia"));
  f.advance(1200);
  f.advance(1100);
  assert.equal(f.e.phase, "fighting");
}
test("likes in audience bank HP and entry consumes it once", () => {
  const f = fixture(),
    e = f.e;
  e.ingest({ type: "like", user: "ana", count: 250 });
  assert.equal(e.players.get("ana").reserveHp, 150);
  e.ingest(rose("ana"));
  assert.equal(e.champion, "ana");
  assert.equal(e.players.get("ana").hp, 150);
  assert.equal(e.players.get("ana").reserveHp, 100);
  assert.equal(e.players.get("ana").wins, 0);
});
test("one rose opens duel and entry kick occurs once", () => {
  const f = fixture();
  f.e.ingest(rose("ana"));
  f.e.ingest(rose("bia"));
  assert.equal(f.e.phase, "entrance");
  f.advance(1200);
  assert.equal(f.e.players.get("ana").hp, 90);
  f.advance(100);
  assert.equal(f.e.players.get("ana").hp, 90);
  f.advance(1100);
  assert.equal(f.e.phase, "fighting");
});
test("gift streak final and duplicate message are counted once", () => {
  const f = fixture(),
    e = f.e;
  assert.equal(
    e.ingest({ ...rose("ana", "msg-1"), repeatEnd: false }).accepted,
    false,
  );
  e.ingest(rose("ana", "msg-1"));
  assert.equal(e.ingest(rose("ana", "msg-1")).accepted, false);
  e.ingest(rose("bia", "msg-2"));
  e.ingest(rose("caio", "msg-3"));
  e.ingest(rose("caio", "msg-4"));
  assert.deepEqual(e.queue, ["caio"]);
  assert.equal(e.players.get("caio").roses, 2);
});
test("wrong gift never creates rose entry", () => {
  const f = fixture();
  f.e.ingest({ ...rose("ana"), gift: "Rose Bear", giftId: 999 });
  assert.equal(f.e.champion, null);
});
test("anonymous like totals never become fake personal HP", () => {
  const f = fixture();
  f.e.ingest({ type: "like", count: 80 });
  assert.equal(f.e.players.size, 0);
  assert.equal(f.e.totals.unattributedLikes, 80);
});
test("healing during battle is rate limited despite a large like batch", () => {
  const f = fixture();
  duel(f);
  const p = f.e.players.get("ana");
  p.hp = 50;
  f.e.ingest({ type: "like", user: "ana", count: 5000 });
  f.e.nextBeat = f.t + 100000;
  for (let i = 0; i < 20; i++) f.advance(50);
  assert.equal(p.hp, 53);
  assert.equal(p.healPool, 27);
});
test("cheering uses exact handles, has cooldown and a cap", () => {
  const f = fixture(),
    e = f.e;
  e.player("ana", "Ana");
  e.player("ana2", "Ana");
  e.ingest({ type: "comment", user: "bia", text: "Ana" });
  assert.equal(e.players.get("ana").cheer, 0);
  e.ingest({ type: "comment", user: "bia", text: "@ana" });
  assert.equal(e.players.get("ana").cheer, 2);
  e.ingest({ type: "comment", user: "bia", text: "@ana" });
  assert.equal(e.players.get("ana").cheer, 2);
  for (let i = 0; i < 20; i++) {
    f.advance(5100);
    e.ingest({ type: "comment", user: "bia", text: "@ana" });
  }
  assert.equal(e.players.get("ana").cheer, RULES.maxCheer);
});
test("shares strengthen their sender with cooldown", () => {
  const f = fixture();
  f.e.ingest({ type: "share", user: "ana" });
  f.e.ingest({ type: "share", user: "ana" });
  assert.equal(f.e.players.get("ana").cheer, 4);
  f.advance(16000);
  f.e.ingest({ type: "share", user: "ana" });
  assert.equal(f.e.players.get("ana").cheer, 8);
});
test("paused track stops normal combat and round timer", () => {
  const f = fixture();
  duel(f);
  f.e.setMusic({ source: "paused" });
  const hp = f.e.players.get("ana").hp,
    elapsed = f.e.boutElapsed;
  for (let i = 0; i < 100; i++) f.advance(50);
  assert.equal(f.e.players.get("ana").hp, hp);
  assert.equal(f.e.boutElapsed, elapsed);
});
test("estimated rhythm remains periodic when file onsets stop", () => {
  const f = fixture();
  duel(f);
  f.e.setMusic({ source: "file", bpm: 120 });
  for (let i = 0; i < 80; i++) f.advance(50);
  const beats = f.actions.filter(
    (a) => a.kind === "beat" && a.source === "estimated",
  );
  assert.ok(beats.length >= 4);
});
test("special, victory and ranking do not duplicate a win", () => {
  const f = fixture();
  duel(f);
  const a = f.e.players.get("ana"),
    b = f.e.players.get("bia");
  a.energy = 100;
  b.hp = 1;
  f.advance(600);
  assert.equal(f.e.phase, "victory");
  assert.equal(a.wins, 1);
  assert.equal(f.e.public().ranking[0].id, "ana");
  f.advance(100);
  assert.equal(a.wins, 1);
  assert.ok(f.actions.some((a) => a.special));
});
test("saved match restores HP, queue, wins and gift de-duplication", () => {
  const f = fixture();
  duel(f);
  f.e.ingest(rose("caio", "queue-1"));
  const s = f.e.save(),
    e = new ArenaEngine({
      now: () => f.t + 30000,
      saved: JSON.parse(JSON.stringify(s)),
    });
  assert.equal(e.phase, "fighting");
  assert.equal(
    e.players.get("ana").hp,
    s.players.find((p) => p.id === "ana").hp,
  );
  assert.deepEqual(e.queue, ["caio"]);
  assert.equal(e.ingest(rose("caio", "queue-1")).accepted, false);
});
test("long audience roster always exposes active fighters", () => {
  const f = fixture();
  f.e.ingest(rose("first"));
  for (let i = 0; i < 300; i++) f.e.player("viewer" + i);
  assert.ok(f.e.public().players.some((p) => p.id === "first"));
  assert.equal(f.e.public().totalPlayers, 301);
});
test("invalid or zero like batches do not grant health", () => {
  const f = fixture();
  assert.equal(
    f.e.ingest({ type: "like", user: "ana", count: 0 }).accepted,
    false,
  );
  assert.equal(
    f.e.ingest({ type: "like", user: "ana", count: -5 }).accepted,
    false,
  );
});
