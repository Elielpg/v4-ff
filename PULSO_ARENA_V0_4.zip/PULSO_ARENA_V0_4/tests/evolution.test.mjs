import test from "node:test";
import assert from "node:assert/strict";
import { ArenaEngine } from "../server/engine.mjs";
import { RhythmBridge } from "../server/rhythm.mjs";
import { orbitPose, fightFootwork, strikeEnvelope } from "../public/choreo.js";

function setup() {
  let t = 100000;
  const actions = [];
  const e = new ArenaEngine({ now: () => t, onAction: (a) => actions.push(a) });
  return {
    e,
    actions,
    now: () => t,
    advance: (ms) => {
      t += ms;
      e.tick();
    },
  };
}
function duel(f) {
  for (const user of ["ana", "bia"])
    f.e.ingest({ type: "gift", user, gift: "Rosa", repeatEnd: true });
  f.advance(1200);
  f.advance(1100);
}
test("comments remain on their owner and survive a missed action through snapshots", () => {
  const f = setup();
  f.e.ingest({ type: "comment", user: "ana", text: "Bora <b>lutar</b>!" });
  const p = f.e.public().players.find((p) => p.id === "ana");
  assert.equal(p.chat.text, "Bora blutar/b!");
  assert.ok(p.chat.until > f.now());
  for (let i = 0; i < 150; i++) f.e.player("new" + i);
  assert.ok(f.e.public().players.some((p) => p.id === "ana"));
  f.advance(7000);
  assert.ok(f.e.players.get("ana").chat.until < f.now());
});
test("DEFESA consumes a guard and reduces actual damage", () => {
  const f = setup();
  duel(f);
  f.e.ingest({ type: "comment", user: "bia", text: "DEFESA" });
  f.e.beat();
  const a = f.actions.findLast((a) => a.kind === "attack");
  assert.equal(a.defense, "block");
  assert.ok(a.damage < a.rawDamage);
  assert.equal(f.e.players.get("bia").guardUntil, 0);
});
test("ESQUIVA avoids one normal hit; dance is bounded and does not disable combat", () => {
  const f = setup();
  duel(f);
  f.e.ingest({ type: "comment", user: "bia", text: "esquiva" });
  f.e.beat();
  const a = f.actions.findLast((a) => a.kind === "attack");
  assert.equal(a.defense, "dodge");
  assert.equal(a.damage, 0);
  f.e.ingest({ type: "comment", user: "ana", text: "dançar" });
  assert.equal(f.e.players.get("ana").danceUntil, f.now() + 12000);
  assert.equal(f.e.phase, "fighting");
});
test("orbit covers all quadrants and returns after 360 degrees; reduced motion stays fixed", () => {
  const ps = [0, Math.PI / 2, Math.PI, Math.PI * 1.5].map((a) => orbitPose(a));
  assert.ok(ps[0].z > 0 && ps[1].x > 0 && ps[2].z < 0 && ps[3].x < 0);
  const a = orbitPose(0),
    b = orbitPose(Math.PI * 2);
  assert.ok(Math.hypot(a.x - b.x, a.z - b.z) < 1e-9);
  assert.deepEqual(
    orbitPose(1, { reduceMotion: true }),
    orbitPose(6, { reduceMotion: true }),
  );
});
test("footwork keeps opponents facing each other inside the ring and strikes recover", () => {
  for (let i = 0; i < 40; i++) {
    const a = fightFootwork(i * 0.17, 0, 140),
      b = fightFootwork(i * 0.17, 1, 140);
    assert.ok(Math.abs(a.x + b.x) < 1e-8 && Math.abs(a.z + b.z) < 1e-8);
    assert.ok(Math.hypot(a.x, a.z) < 1.3);
    assert.ok(Math.sin(a.yaw) * -a.x + Math.cos(a.yaw) * -a.z > 0);
  }
  assert.equal(strikeEnvelope(0), 0);
  assert.equal(strikeEnvelope(1), 0);
  assert.equal(strikeEnvelope(0.22), 1);
});
test("external rhythm never invents attacks after capture stops", () => {
  const f = setup();
  duel(f);
  f.e.setMusic({ source: "external" });
  f.e.beat({ source: "external", interval: 500 });
  const attacks = f.actions.filter((a) => a.kind === "attack").length;
  for (let i = 0; i < 120; i++) f.advance(50);
  assert.equal(f.actions.filter((a) => a.kind === "attack").length, attacks);
  const elapsed = f.e.boutElapsed;
  f.advance(1000);
  assert.equal(f.e.boutElapsed, elapsed);
});
test("pair codes expire and lock after five failed attempts", () => {
  let now = 100000;
  const b = new RhythmBridge({ now: () => now });
  const { code } = b.issue();
  for (let i = 0; i < 5; i++) assert.throws(() => b.pair("000000"));
  assert.throws(() => b.pair(code));
  const next = b.issue();
  now += 120001;
  assert.throws(() => b.pair(next.code));
});
test("local audio frames require a token, valid timestamps and increasing sequence", () => {
  let now = 100000;
  const b = new RhythmBridge({ now: () => now }),
    { code } = b.issue(),
    { token } = b.pair(code);
  const frame = { energy: 0.1, level: 0.1, seq: 0, at: now };
  assert.throws(() => b.frame("Bearer " + "x".repeat(64), frame));
  assert.throws(() => b.frame("Bearer " + "é".repeat(64), frame));
  assert.equal(b.frame("Bearer " + token, frame).accepted, true);
  assert.equal(b.frame("Bearer " + token, frame).accepted, false);
  assert.throws(() =>
    b.frame("Bearer " + token, { ...frame, seq: 1, at: now - 7000 }),
  );
  b.revoke();
  assert.throws(() => b.frame("Bearer " + token, frame));
});
test("numeric external energy at 120 BPM produces measured beats and silent status", () => {
  let now = 100000;
  const b = new RhythmBridge({ now: () => now }),
    { code } = b.issue(),
    { token } = b.pair(code);
  const hits = [];
  for (let i = 0; i < 130; i++) {
    now = 100000 + i * 50;
    const energy = i % 10 === 0 ? 0.18 : 0.0001;
    const r = b.frame("Bearer " + token, {
      energy,
      level: energy,
      seq: i,
      at: now,
    });
    if (r.hit) hits.push(r.interval);
  }
  assert.ok(hits.length >= 10);
  assert.ok(hits.at(-1) >= 490 && hits.at(-1) <= 510);
  now += 6000;
  b.frame("Bearer " + token, { energy: 0, level: 0, seq: 131, at: now });
  assert.equal(b.status().state, "silent");
});
