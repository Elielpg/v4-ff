import test from "node:test";
import assert from "node:assert/strict";
import { segmentHitsBox } from "../public/visibility.js";
import { orbitPose } from "../public/choreo.js";
import { attackPose, celebrationPose } from "../public/combat-poses.js";
import { celebrationFor } from "../server/celebrations.mjs";
import { ArenaEngine } from "../server/engine.mjs";
const point = (x, y, z) => ({ x, y, z });
test("camera slab regression reproduces old wall and clears the relocated backdrop", () => {
  const eye = point(0, 5.1, -11.6),
    target = point(0, 1.5, 0);
  assert.equal(
    segmentHitsBox(eye, target, point(-5, 1.1, -8.6), point(5, 4.9, -8.4)),
    true,
  );
  assert.equal(
    segmentHitsBox(eye, target, point(-5, 1.1, -15.6), point(5, 4.9, -15.4)),
    false,
  );
});
test("visibility handles parallel rays, eye inside geometry and walls behind a fighter", () => {
  assert.equal(
    segmentHitsBox(
      point(0, 2, -3),
      point(0, 2, 0),
      point(2, 0, -2),
      point(3, 4, -1),
    ),
    false,
  );
  assert.equal(
    segmentHitsBox(
      point(0, 2, -3),
      point(0, 2, 0),
      point(-1, 0, -4),
      point(1, 4, -2),
    ),
    true,
  );
  assert.equal(
    segmentHitsBox(
      point(0, 2, -3),
      point(0, 2, 0),
      point(-1, 0, 1),
      point(1, 4, 2),
    ),
    false,
  );
});
test("relocated backdrop stays outside lines of sight for a full 360 orbit", () => {
  for (let i = 0; i < 72; i++)
    for (const x of [-1.1, 1.1])
      assert.equal(
        segmentHitsBox(
          orbitPose((i * Math.PI) / 36),
          point(x, 1.7, 0),
          point(-5, 1.1, -15.6),
          point(5, 4.9, -15.4),
        ),
        false,
      );
});
test("every mascot gets its own playful line and avoids immediate repetition", () => {
  const texts = new Set();
  for (const type of ["fox", "hippo", "raccoon", "ram"]) {
    const a = celebrationFor(type, () => 0),
      b = celebrationFor(type, () => 0, a.id);
    assert.notEqual(a.id, b.id);
    assert.ok(a.emoji && a.dance && a.text.length < 100);
    texts.add(a.text);
  }
  assert.equal(texts.size, 4);
});
function fixture() {
  let now = 100000;
  const actions = [],
    e = new ArenaEngine({ now: () => now, onAction: (a) => actions.push(a) });
  return {
    e,
    actions,
    now: () => now,
    advance: (dt) => {
      now += dt;
      e.tick();
    },
  };
}
test("victory party preserves a queued challenger and resumes combat after 6.5 seconds", () => {
  const f = fixture();
  for (const user of ["ana", "bia", "caio"])
    f.e.ingest({ type: "gift", user, gift: "Rosa" });
  f.advance(2300);
  f.e.players.get("bia").hp = 1;
  f.e.players.get("ana").energy = 100;
  f.advance(600);
  assert.equal(f.e.phase, "victory");
  const winner = f.e.players.get(f.e.champion),
    hp = winner.hp;
  assert.equal(winner.wins, 1);
  assert.ok(winner.celebration.text);
  assert.equal(winner.celebration.until, f.now() + 6500);
  assert.deepEqual(f.e.queue, ["caio"]);
  f.advance(6000);
  assert.equal(f.e.phase, "victory");
  assert.equal(winner.hp, hp);
  f.advance(501);
  assert.equal(f.e.challenger, "caio");
  assert.equal(winner.wins, 1);
});
test("winner and loser are exposed for a refreshed victory view even with a large audience", () => {
  const f = fixture();
  for (const user of ["ana", "bia"])
    f.e.ingest({ type: "gift", user, gift: "Rosa" });
  f.e.win("ana", "bia", "nocaute");
  for (let i = 0; i < 160; i++) f.e.player("viewer" + i);
  const s = f.e.public();
  assert.ok(s.players.some((p) => p.id === "bia"));
  assert.deepEqual(s.players.find((p) => p.id === "ana").celebration.order, [
    "ana",
    "bia",
  ]);
});
test("PULAR is a bounded pose command and does not grant defensive invulnerability", () => {
  const f = fixture();
  for (const user of ["ana", "bia"])
    f.e.ingest({ type: "gift", user, gift: "Rosa" });
  f.advance(2300);
  f.e.ingest({ type: "comment", user: "bia", text: "PULAR" });
  assert.equal(f.e.players.get("bia").jumpUntil, f.now() + 1000);
  f.e.beat();
  assert.ok(f.actions.findLast((a) => a.kind === "attack").damage > 0);
});
test("new combat and victory poses stay finite, bounded and visibly distinct", () => {
  for (const move of [
    "jab",
    "cross",
    "hook",
    "uppercut",
    "kick",
    "jumpKick",
    "spin",
  ])
    for (let i = 0; i <= 20; i++) {
      const p = attackPose(move, i / 20);
      assert.ok(p.force >= 0 && p.force <= 1);
      assert.ok(p.jump >= 0 && p.jump < 0.8);
      for (const v of [...p.arm.hand, ...p.knee, ...p.foot])
        assert.ok(Number.isFinite(v) && Math.abs(v) < 2);
    }
  assert.ok(attackPose("jumpKick", 0.5).jump > 0.6);
  assert.notDeepEqual(
    attackPose("hook", 0.4).arm.hand,
    attackPose("uppercut", 0.4).arm.hand,
  );
  const styles = ["shuffle", "spin", "robot", "bounce"].map((x) =>
    JSON.stringify(celebrationPose(x, 1.2, 1)),
  );
  assert.equal(new Set(styles).size, 4);
});
