import test from "node:test";
import assert from "node:assert/strict";
import { OnsetDetector } from "../public/onset.js";
test("onset detector responds to kick envelopes without firing on every sample", () => {
  const d = new OnsetDetector();
  let hits = [];
  for (let i = 0; i < 500; i++) {
    const t = i * 0.016,
      phase = t % 0.5,
      level = 0.001 + (phase < 0.064 ? 0.22 * Math.exp(-phase * 24) : 0);
    if (d.sample(level, t)) hits.push(t);
  }
  assert.ok(hits.length >= 12 && hits.length <= 17, JSON.stringify(hits));
  for (let i = 1; i < hits.length; i++) assert.ok(hits[i] - hits[i - 1] > 0.27);
});
test("steady loud bass is not treated as repeated beats", () => {
  const d = new OnsetDetector();
  let n = 0;
  for (let i = 0; i < 500; i++) if (d.sample(0.12, i * 0.016)) n++;
  assert.ok(n <= 1);
});
test("silence and low background noise do not create beats", () => {
  const d = new OnsetDetector();
  let n = 0;
  for (let i = 0; i < 400; i++)
    if (d.sample(0.0002 + Math.sin(i) * 0.0001, i * 0.016)) n++;
  assert.equal(n, 0);
});
