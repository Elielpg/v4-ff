import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { Store } from "../server/storage.mjs";
test("rapid saves are coalesced and the latest state is atomic", async () => {
  const dir = await mkdtemp(path.join(tmpdir(), "pulso-save-"));
  try {
    const s = new Store(dir);
    const writes = [];
    for (let i = 0; i < 100; i++) writes.push(s.save("live", { i }));
    await Promise.all(writes);
    assert.deepEqual(await s.read("live"), { i: 99 });
    assert.equal(s.latest.size, 0);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
test("corrupt snapshot recovers previous good backup", async () => {
  const dir = await mkdtemp(path.join(tmpdir(), "pulso-backup-"));
  try {
    const s = new Store(dir);
    await s.save("live", { wins: 2 });
    await s.save("live", { wins: 3 });
    await writeFile(path.join(dir, "live.json"), "{broken");
    assert.deepEqual(await s.read("live"), { wins: 2 });
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});
