import test from "node:test";
import assert from "node:assert/strict";
import { normalize, TikTokAdapter } from "../server/live.mjs";
test("likes use individual increments and not room totals", () => {
  const e = normalize(
    {
      msgId: "9007199254740993123",
      user: { uniqueId: "ana", nickname: "Ana" },
      likeCount: 23,
      totalLikeCount: 40000,
    },
    "like",
  );
  assert.equal(e.count, 23);
  assert.equal(e.user, "ana");
  assert.equal(e.id, "9007199254740993123");
});
test("gift streak final state is normalized conservatively", () => {
  assert.equal(
    normalize(
      { gift: { name: "Rose", id: 5655, type: 1 }, repeatEnd: 0 },
      "gift",
    ).repeatEnd,
    false,
  );
  assert.equal(
    normalize(
      { gift: { name: "Rose", id: 5655, type: 1 }, repeatEnd: 1 },
      "gift",
    ).repeatEnd,
    true,
  );
});
test("public account validation refuses links", async () => {
  const a = new TikTokAdapter(
    () => {},
    () => {},
  );
  await assert.rejects(a.connect("https://tiktok.com/@ana"), /somente/);
});
import { EventEmitter } from "node:events";
test("late old connection cannot replace a newer confirmed stream", async () => {
  const clients = [];
  class Fake extends EventEmitter {
    constructor(name) {
      super();
      this.name = name;
      clients.push(this);
    }
    timeout() {
      return this;
    }
    maxRetries() {
      return this;
    }
    connect() {
      return new Promise((r) => (this.resolve = r));
    }
    disconnect() {
      this.closed = true;
      return Promise.resolve();
    }
  }
  const a = new TikTokAdapter(
    () => {},
    () => {},
    { load: async () => ({ TikTokLiveClient: Fake }) },
  );
  const first = a.connect("primeira");
  await new Promise((r) => setTimeout(r, 0));
  const second = a.connect("segunda");
  await new Promise((r) => setTimeout(r, 0));
  clients[1].resolve("room-2");
  await second;
  clients[0].resolve("room-1");
  await first;
  await new Promise((r) => setTimeout(r, 0));
  assert.equal(a.state.username, "segunda");
  assert.equal(a.state.status, "connected");
  assert.ok(clients[0].closed);
  await a.disconnect();
});
