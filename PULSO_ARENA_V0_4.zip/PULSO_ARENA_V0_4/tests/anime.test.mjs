import test from "node:test";
import assert from "node:assert/strict";
import { ArenaEngine } from "../server/engine.mjs";
import { COMBOS, animeStrike } from "../server/combat.mjs";
import { blinkPosition, teleportDestination, editCamera, pairRadius } from "../public/anime-motion.js";
import { attackPose } from "../public/combat-poses.js";

function duel(style = "anime") {
  let now = 100000;
  const actions = [];
  const e = new ArenaEngine({ now: () => now, onAction: a => actions.push(a) });
  for (const id of ["ana", "bia"]) {
    e.ingest({ type: "gift", user: id, gift: "Rosa" });
    e.players.get(id).archetype = "fox";
  }
  now += 2300; e.tick();
  e.setMusic({ source: "external", combatStyle: style });
  actions.length = 0;
  return { e, actions, pulse(ms = 125) { now += ms; return e.beat({ source: "external", interval: 500, pulseInterval: ms, at: now }); } };
}
test("Anime delivers every real 125ms accent as a short contact while Classic keeps the principal pulse", () => {
  const anime = duel(), classic = duel("classic");
  for (let i = 0; i < 16; i++) { assert.equal(anime.pulse(), true); classic.pulse(); }
  const a = anime.actions.filter(a => a.kind === "attack"), c = classic.actions.filter(a => a.kind === "attack");
  assert.equal(a.length, 16); assert.equal(c.length, 4);
  assert.ok(a.every(a => a.duration <= 0.125 && a.duration >= 0.07));
  const damageA = a.reduce((sum, a) => sum + a.damage, 0), damageC = c.reduce((sum, a) => sum + a.damage, 0);
  assert.ok(damageA < damageC * 1.6, `${damageA} vs ${damageC}`);
  assert.equal(anime.e.phase, "fighting");
  assert.ok([...anime.e.players.values()].every(p => p.energy < 100));
});
test("combos retain initiative, change after defense and include real teleport metadata", () => {
  const f = duel();
  f.pulse(); f.pulse(); f.pulse();
  let hits = f.actions.filter(a => a.kind === "attack");
  assert.deepEqual(hits.map(a => a.player), ["ana", "ana", "ana"]);
  assert.deepEqual(hits.map(a => a.combo), [1, 2, 3]);
  assert.equal(hits[2].teleport, true);
  f.e.ingest({ type: "comment", user: "bia", text: "DEFESA" });
  f.pulse(); f.pulse();
  hits = f.actions.filter(a => a.kind === "attack");
  assert.equal(hits[3].defense, "block");
  assert.equal(hits[4].player, "bia");
  assert.equal(hits[4].combo, 1);
});
test("speed follows accepted accent cadence, without quadrupling energy or damage", () => {
  const fast = animeStrike("fox", 1, 125, 500), slow = animeStrike("fox", 1, 500, 500);
  assert.equal(fast.damageScale * 4, slow.damageScale);
  assert.equal(fast.energyScale * 4, slow.energyScale);
  assert.ok(fast.duration < slow.duration / 3);
  for (const type of Object.keys(COMBOS)) {
    const sequence = Array.from({ length: 4 }, (_, step) => animeStrike(type, step, 125, 500));
    assert.equal(sequence[3].finisher, true);
    assert.ok(sequence.every(a => a.comboTotal === 4));
  }
});
test("saved host style and existing HP, likes, queue and ranking survive the update", () => {
  const f = duel("classic");
  f.e.ingest({ type: "like", user: "caio", count: 250 });
  f.e.ingest({ type: "gift", user: "caio", gift: "Rosa" });
  const restored = new ArenaEngine({ saved: f.e.save() });
  assert.equal(restored.combatStyle, "classic");
  assert.deepEqual(restored.queue, ["caio"]);
  assert.equal(restored.players.get("caio").reserveHp, 150);
  const old = f.e.save(); delete old.combatStyle;
  assert.equal(new ArenaEngine({ saved: old }).combatStyle, "anime");
});
test("teleports go behind the rival and stay inside the ring through departure and recovery", () => {
  const engineVector = Object.defineProperties({}, { x: { get: () => 1 }, z: { get: () => 2 } });
  assert.deepEqual(blinkPosition(null, engineVector, 2), { x: 1, z: 2, scale: 1 });
  for (let i = 0; i < 72; i++) {
    const angle = i / 72 * Math.PI * 2;
    const from = { x: -Math.cos(angle), z: -Math.sin(angle) }, target = { x: Math.cos(angle), z: Math.sin(angle) };
    const to = teleportDestination(from, target);
    assert.ok((to.x - target.x) * (target.x - from.x) + (to.z - target.z) * (target.z - from.z) > 0);
    for (let age = 0; age <= 1.2; age += 0.01) {
      const p = blinkPosition({ from, to }, from, age);
      assert.ok(Math.hypot(p.x, p.z) <= 2.351);
      assert.ok(p.scale >= 0.45 && p.scale <= 1);
    }
    assert.deepEqual(blinkPosition({ from, to }, from, 1.2), { ...from, scale: 1 });
  }
});
test("new strike poses remain bounded and flurries visibly alternate hands", () => {
  for (const move of new Set(Object.values(COMBOS).flat()))
    for (let i = 0; i <= 100; i++) {
      const p = attackPose(move, i / 100);
      assert.ok(p.force >= 0 && p.force <= 1);
      assert.ok(p.jump >= 0 && p.jump <= 0.73);
      for (const v of [...p.arm.elbow, ...p.arm.hand, ...p.foot]) assert.ok(Number.isFinite(v) && Math.abs(v) < 2);
    }
  assert.notEqual(attackPose("flurry", 0.1).arm.side, attackPose("flurry", 0.45).arm.side);
  assert.equal(attackPose("flurry", 1).force, 0);
});
test("anime camera accents recover and never create unlimited zoom or roll", () => {
  for (let i = 0; i < 200; i++) {
    const c = editCamera(i / 100, 0.11, true);
    assert.ok(c.zoom >= 0 && c.zoom <= 0.09);
    assert.ok(Math.abs(c.roll) <= 0.035);
  }
  assert.ok(editCamera(1, 0.11).zoom < 0.000001);
});
test("portrait camera backs away enough to fit teleported fighters at every angle", () => {
  const points = [{ x: -2.35, z: 0 }, { x: 1.4, z: 1.5 }];
  for (let i = 0; i < 72; i++) {
    const a = i * Math.PI / 36, r = pairRadius(points, a, 0.45, 0.7);
    assert.ok(Number.isFinite(r) && r >= 11.6 && r < 30);
    for (const p of points) {
      const side = p.x * Math.cos(a) - p.z * Math.sin(a), depth = p.x * Math.sin(a) + p.z * Math.cos(a);
      assert.ok((Math.abs(side) + 0.85) / (r - depth) <= Math.tan(0.35) * 0.45 + 1e-10);
    }
  }
});
