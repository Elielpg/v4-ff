#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
python3 scripts/update.py "${1:-$HOME/PULSO_ARENA_V0_1}"
