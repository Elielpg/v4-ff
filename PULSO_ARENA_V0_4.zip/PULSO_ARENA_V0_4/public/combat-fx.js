const B = BABYLON,
  V = B.Vector3;
export class CombatFX {
  constructor(world) {
    this.w = world;
    this.pool = [];
    this.budget = 16;
    const tx = new B.DynamicTexture(
        "estrela-impacto",
        { width: 128, height: 128 },
        world.scene,
        false,
      ),
      c = tx.getContext();
    tx.hasAlpha = true;
    c.clearRect(0, 0, 128, 128);
    c.fillStyle = "#fff8d6";
    c.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2,
        r = i % 2 ? 23 : 59,
        x = 64 + Math.cos(a) * r,
        y = 64 + Math.sin(a) * r;
      if (i) c.lineTo(x, y);
      else c.moveTo(x, y);
    }
    c.closePath();
    c.fill();
    tx.update();
    const starMat = new B.StandardMaterial("estrela-mat", world.scene);
    starMat.diffuseTexture = tx;
    starMat.emissiveTexture = tx;
    starMat.disableLighting = true;
    starMat.useAlphaFromDiffuseTexture = true;
    starMat.backFaceCulling = false;
    this.colors = ["#ffe49b", "#65e4ff", "#bdf66d", "#ff8fae"];
    this.ghosts = [];
    this.ghostMats = {};
    for (const [type, hue] of Object.entries({ fox: "#ffd47d", hippo: "#e4a3ff", raccoon: "#67e7ff", ram: "#c9ff83" })) {
      const texture = new B.DynamicTexture("silhueta-" + type, { width: 256, height: 384 }, world.scene, false);
      texture.hasAlpha = true;
      const c = texture.getContext();
      c.clearRect(0, 0, 256, 384); c.fillStyle = c.strokeStyle = hue;
      c.lineCap = "round"; c.lineWidth = 35;
      c.beginPath(); c.moveTo(103, 215); c.lineTo(88, 338); c.moveTo(145, 215); c.lineTo(177, 322);
      c.moveTo(92, 172); c.lineTo(42, 215); c.moveTo(159, 170); c.lineTo(215, 133); c.stroke();
      c.beginPath(); c.ellipse(128, 188, 44, 65, 0, 0, Math.PI * 2); c.fill();
      c.beginPath(); c.arc(128, 100, type === "hippo" ? 53 : 45, 0, Math.PI * 2); c.fill();
      if (type === "fox") {
        for (const s of [-1, 1]) { c.beginPath(); c.moveTo(128 + s * 42, 89); c.lineTo(128 + s * 34, 20); c.lineTo(128 + s * 4, 70); c.fill(); }
      } else for (const s of [-1, 1]) { c.beginPath(); c.arc(128 + s * 43, 68, type === "ram" ? 23 : 16, 0, Math.PI * 2); c.fill(); }
      texture.update();
      const m = new B.StandardMaterial("silhueta-" + type, world.scene);
      m.diffuseTexture = m.emissiveTexture = texture;
      m.disableLighting = true; m.useAlphaFromDiffuseTexture = true; m.backFaceCulling = false;
      m.alphaMode = B.Engine.ALPHA_ADD;
      this.ghostMats[type] = m;
    }
    for (let i = 0; i < 8; i++) {
      const mesh = B.MeshBuilder.CreatePlane("eco-anime", { width: 1.25, height: 2.1 }, world.scene);
      mesh.billboardMode = B.Mesh.BILLBOARDMODE_ALL; mesh.isPickable = false; mesh.setEnabled(false);
      this.ghosts.push({ mesh, at: -100, life: 0.25 });
      world.glow.addIncludedOnlyMesh(mesh);
    }
    this.mats = this.colors.map((hex, i) => {
      const m = world.mat("rastro-" + i, hex, 1);
      m.disableLighting = true;
      return m;
    });
    for (let i = 0; i < 8; i++)
      for (const kind of ["arc", "ring", "star", "line"]) {
        let mesh;
        if (kind === "star") {
          mesh = B.MeshBuilder.CreatePlane(
            "estrela",
            { size: 0.55 },
            world.scene,
          );
          mesh.material = starMat;
          mesh.billboardMode = B.Mesh.BILLBOARDMODE_ALL;
        } else if (kind === "line")
          mesh = B.MeshBuilder.CreateCylinder(
            "linha-golpe",
            { height: 1, diameter: 0.027, tessellation: 6 },
            world.scene,
          );
        else
          mesh = B.MeshBuilder.CreateTorus(
            "rastro-" + kind,
            {
              diameter: 1,
              thickness: kind === "arc" ? 0.045 : 0.025,
              tessellation: 24,
              arc: kind === "arc" ? 0.5 : 1,
            },
            world.scene,
          );
        mesh.isPickable = false;
        mesh.setEnabled(false);
        world.glow.addIncludedOnlyMesh(mesh);
        this.pool.push({ kind, mesh, at: -100, life: 0.3 });
      }
  }
  clear() {
    for (const g of this.ghosts) { g.at = -100; g.mesh.setEnabled(false); }
    for (const f of this.pool) {
      f.at = -100;
      f.mesh.setEnabled(false);
    }
  }
  ghost(pos, type, delay = 0) {
    const available = this.ghosts.slice(0, this.w.profile === "low" ? 2 : 8);
    const g = available.reduce((a, b) => a.at < b.at ? a : b);
    g.at = performance.now() / 1000 + delay;
    g.life = 0.24;
    g.mesh.material = this.ghostMats[type] || this.ghostMats.fox;
    g.mesh.position.copyFrom(pos.add(new V(0, 0.95, 0)));
  }
  teleport(from, to, type) {
    if (this.w.reduceMotion) return;
    this.emit("ring", from.add(new V(0, 0.7, 0)), { color: 1, scale: 0.9, rotation: [Math.PI / 2, 0, 0], life: 0.18 });
    this.emit("ring", to.add(new V(0, 0.7, 0)), { color: 1, scale: 1.2, rotation: [Math.PI / 2, 0, 0], life: 0.22, delay: 0.045 });
    for (let i = 0; i < 3; i++) this.ghost(V.Lerp(from, to, i / 3), type, i * 0.018);
  }
  emit(
    kind,
    pos,
    {
      delay = 0,
      life = 0.28,
      scale = 1,
      color = 0,
      rotation = [0, 0, 0],
      direction,
    } = {},
  ) {
    const slots = this.pool
      .slice(0, this.budget)
      .filter((x) => x.kind === kind);
    if (!slots.length) return;
    const f = slots.reduce((a, b) => (a.at + a.life < b.at + b.life ? a : b));
    f.at = performance.now() / 1000 + delay;
    f.life = life;
    f.scale = scale;
    f.mesh.position.copyFrom(pos);
    f.mesh.rotationQuaternion = null;
    f.mesh.rotation.set(...rotation);
    f.spin = kind === "arc" ? 5 : 0;
    f.baseYaw = rotation[1];
    if (kind !== "star") f.mesh.material = this.mats[color % this.mats.length];
    if (kind === "line") {
      const d = direction || new V(0, 0, 1);
      this.w.link(f.mesh, pos.asArray(), pos.add(d.scale(scale)).asArray());
      f.scale = 1;
    }
  }
  jump(pos, duration = 1) {
    this.emit("ring", pos, { scale: 0.6, life: 0.35, color: 1 });
    this.emit("ring", pos, {
      scale: 0.7,
      life: 0.3,
      color: 0,
      delay: duration * 0.9,
    });
  }
  attack(action, actors) {
    const a = actors.get(action.player),
      b = actors.get(action.target);
    if (!a || !b) return;
    const blink = action.teleport ? this.w.blinks.get(action.player) : null;
    const from = blink ? new V(blink.to.x, 0.4, blink.to.z) : a.root.position.clone(),
      to = b.root.position.clone(),
      d = to.subtract(from);
    d.y = 0;
    d.normalize();
    const side = new V(d.z, 0, -d.x),
      impact = to.add(new V(0, action.move === "uppercut" ? 1.6 : 1.15, 0)),
      delay = (action.duration || 0.5) * 0.18;
    const color =
      a.type === "hippo"
        ? 3
        : a.type === "raccoon"
          ? 1
          : a.type === "ram"
            ? 2
            : 0;
    if (["dashJab", "flurry", "airCombo"].includes(action.move) && !this.w.reduceMotion) {
      this.ghost(from.subtract(d.scale(0.3)), a.type);
      this.ghost(from.subtract(d.scale(0.65)), a.type, 0.025);
    }
    if (action.defense === "dodge") {
      for (let i = 0; i < 3; i++)
        this.emit(
          "arc",
          to.add(side.scale(i * 0.2 - 0.1)).add(new V(0, 1.0, 0)),
          {
            rotation: [Math.PI / 2, Math.atan2(d.x, d.z), i * 0.4],
            scale: 0.65,
            delay: delay + i * 0.04,
            color: 1,
            life: 0.28,
          },
        );
      return;
    }
    if (action.defense === "block")
      this.emit("ring", impact, {
        rotation: [Math.PI / 2, Math.atan2(d.x, d.z), 0],
        scale: 0.7,
        delay,
        color: 1,
        life: 0.3,
      });
    else
      this.emit("star", impact, {
        scale: action.special ? 1.4 : action.finisher ? 1.05 : 0.7,
        delay,
        life: 0.2,
      });
    if (["flurry", "airCombo"].includes(action.move))
      for (let i = 1; i < 3; i++) this.emit("star", impact.add(side.scale((i - 1.5) * 0.25)), { scale: 0.42, delay: (action.duration || 0.3) * (i / 3), life: 0.09 });
    const kick = ["kick", "jumpKick", "entryKick", "spin", "spinKick", "teleportKick", "quakeKick"].includes(
      action.move,
    );
    if (kick || ["uppercut", "hook", "special"].includes(action.move))
      this.emit(
        "arc",
        from.add(d.scale(0.5)).add(new V(0, kick ? 0.9 : 1.2, 0)),
        {
          rotation: [
            action.move === "hook" ? 0 : Math.PI / 2,
            Math.atan2(d.x, d.z),
            action.move === "uppercut" ? Math.PI / 2 : 0.25,
          ],
          scale: action.special ? 1.8 : 1.15,
          delay,
          color,
          life: 0.3,
        },
      );
    else
      for (let i = 0; i < 3; i++)
        this.emit(
          "line",
          from
            .add(d.scale(0.35))
            .add(side.scale((i - 1) * 0.12))
            .add(new V(0, 1.25 + (i - 1) * 0.07, 0)),
          {
            direction: d,
            scale: 0.9,
            delay: delay + i * 0.015,
            color,
            life: 0.16,
          },
        );
    if (["jumpKick", "entryKick"].includes(action.move))
      this.jump(from.add(new V(0, 0.015, 0)), action.duration || 0.5);
    if (action.finisher && action.defense === "none") this.emit("ring", to.add(new V(0, 0.02, 0)), { color, scale: 1.4, life: 0.3, delay });
  }
  update(t, calm) {
    for (const [i, g] of this.ghosts.entries()) {
      const age = t - g.at;
      const active = !calm && i < (this.w.profile === "low" ? 2 : 8) && age >= 0 && age < g.life;
      g.mesh.setEnabled(active);
      if (active) g.mesh.visibility = (1 - age / g.life) * 0.32;
    }
    for (const [i, f] of this.pool.entries()) {
      const age = t - f.at,
        active = i < this.budget && age >= 0 && age < f.life;
      f.mesh.setEnabled(active);
      if (!active) continue;
      const p = age / f.life;
      f.mesh.visibility = (calm ? 0.35 : 0.8) * (1 - p);
      if (f.kind !== "line")
        f.mesh.scaling.setAll(
          f.scale *
            (f.kind === "star"
              ? 0.6 + Math.sin(p * Math.PI) * 0.8
              : 1 + p * 0.8),
        );
      if (f.spin) f.mesh.rotation.y = f.baseYaw + (calm ? 0 : f.spin * age);
    }
  }
  get active() {
    return this.pool.filter((f) => f.mesh.isEnabled()).length;
  }
}
