import { OnsetDetector, DETECTION_MODES } from "./onset.js";
class PulsoMeter extends AudioWorkletProcessor {
  constructor() {
    super();
    this.bass = new OnsetDetector();
    this.detail = new OnsetDetector();
    this.reset();
    this.port.onmessage = ({ data }) => {
      if (data.mode) {
        this.bass.setMode(data.mode);
        this.detail.setMode(data.mode);
      }
      if (data.reset) this.reset();
    };
  }
  reset() {
    this.sum = 0;
    this.high = 0;
    this.n = 0;
    this.last = -Infinity;
    this.lastReport = -Infinity;
    this.hits = 0;
    this.bass.reset();
    this.detail.reset();
  }
  process(inputs) {
    const a = inputs[0]?.[0],
      b = inputs[1]?.[0];
    if (!a) return true;
    for (let i = 0; i < a.length; i++) {
      this.sum += a[i] * a[i];
      this.high += (b?.[i] || 0) ** 2;
      if (++this.n >= 768) {
        const level = Math.sqrt(this.sum / this.n),
          detail = Math.sqrt(this.high / this.n),
          at = currentTime + i / sampleRate;
        const lowHit = this.bass.sample(level, at),
          highHit = this.detail.sample(detail, at);
        const hit =
          (lowHit || highHit) &&
          at - this.last >= DETECTION_MODES[this.bass.mode].gap;
        const strength = Math.max(
          lowHit ? this.bass.strength : 0,
          highHit ? this.detail.strength : 0,
        );
        if (hit) {
          this.last = at;
          this.hits++;
        }
        if (hit || at - this.lastReport > 0.04) {
          this.port.postMessage({
            level: Math.max(level, detail),
            hit,
            strength,
            at,
            hits: this.hits,
          });
          this.lastReport = at;
        }
        this.sum = 0;
        this.high = 0;
        this.n = 0;
      }
    }
    return true;
  }
}
registerProcessor("pulso-meter", PulsoMeter);
