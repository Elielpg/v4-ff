import { ArenaWorld } from "./world.js";
import { ArenaAudio } from "./audio.js";
const $ = (id) => document.getElementById(id),
  world = new ArenaWorld($("arena"));
let state = null,
  lastMode = null,
  cursor = 0,
  toastTimer,
  connection = "connecting",
  manualMusic = false;
const api = async (path, data = {}) => {
  const r = await fetch("/api/" + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  const j = await r.json();
  if (!r.ok) throw Error(j.error || "Falha no comando");
  return j;
};
function toast(text) {
  $("toast").textContent = text;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($("toast").textContent = ""), 4500);
}
const audio = new ArenaAudio($("music"), {
  onBeat: (pulse) => {
    if (manualMusic || state?.rhythm.source === "external") return;
    api("beat", { source: "file", ...pulse }).catch(() => {});
  },
  onLevel: (level) =>
    ($("beat-meter").firstElementChild.style.width =
      Math.round(level * 100) + "%"),
  onStatus: toast,
});
function setMode(mode) {
  if (mode === lastMode) return;
  lastMode = mode;
  cursor = 0;
  world.lastSeenAction = 0;
  world.latestAttack = world.latestVictory = world.welcomeFocus = null;
  world.slots = [];
  world.combatFX?.clear();
  world.transientPoses?.clear();
  world.attackTracks.clear();
  world.hitTracks.clear();
  world.blinks.clear();
}
function action(a) {
  if (a.mode) setMode(a.mode);
  if (a.id <= cursor) return;
  cursor = a.id;
  world.action(a);
  if (a.kind === "attack")
    audio.sfx(
      a.defense === "block"
        ? "block"
        : a.defense === "dodge"
          ? "dodge"
          : a.special
            ? "special"
            : a.teleport ? "teleport" : ["kick", "jumpKick", "entryKick", "spin", "spinKick", "teleportKick", "quakeKick"].includes(a.move)
              ? "kick"
              : ["hook", "uppercut"].includes(a.move)
                ? "hook"
                : "attack",
    );
  else audio.sfx(a.kind);
  const p = state?.players.find((p) => p.id === a.player),
    target = state?.players.find((p) => p.id === a.target);
  if (a.kind === "welcome") {
    const box = $("welcome");
    box.textContent = `CHEGOU, ${p?.name || a.player}! Seu mascote está na plateia.`;
    box.classList.remove("hidden");
    clearTimeout(window.welcomeTimer);
    window.welcomeTimer = setTimeout(() => box.classList.add("hidden"), 3200);
  }
  if (a.kind === "queued") toast("@" + a.player + " entrou na fila!");
  if (a.kind === "attack") {
    const caption =
      a.defense === "block"
        ? "DEFESA!"
        : a.defense === "dodge"
          ? "ESQUIVA!"
          : a.special
            ? "PULSO FINAL!"
            : a.teleport
              ? "TELEPORTE! · COMBO " + a.combo + "/4"
              : a.finisher ? "FINALIZADOR!" : a.combo > 1
              ? "COMBO " + a.combo + (a.comboTotal ? "/" + a.comboTotal : "")
              : "";
    if (caption) {
      $("callout").textContent = caption;
      window.actionCaptionUntil = performance.now() + 550;
    }
  }
  if (a.kind === "victory")
    $("callout").textContent = `${p?.name || a.player} FICOU COM A COROA!`;
}
function renderState(s) {
  setMode(s.mode);
  state = s;
  $("combat-style").value = s.combatStyle || "anime";
  world.update(s);
  $("network").textContent = "JOGO CONECTADO";
  connection = "connected";
  const live = s.connection?.status === "connected";
  $("mode").textContent =
    s.mode === "demo"
      ? "TESTE LOCAL · SIMULAÇÃO"
      : live
        ? "LIVE · CONECTADA"
        : "LIVE · SEM CONEXÃO";
  $("mode").style.color = s.mode === "live" && !live ? "#ff8a99" : "#bdf66d";
  $("live-detail").textContent = s.connection?.message || "LIVE não conectada";
  const source =
    s.rhythm.source === "paused"
      ? "PAUSADO"
      : s.rhythm.source === "manual"
        ? "MANUAL"
        : s.rhythm.effective === "estimated"
          ? "ESTIMADO"
          : s.rhythm.source === "external"
            ? "ANDROID"
            : "ARQUIVO";
  $("rhythm").textContent = s.rhythm.bpm + " BPM · " + source;
  const native = s.audio?.state || "offline";
  $("native-status").textContent = {
    listening: "Captador conectado · energia de áudio recebida",
    silent: "Conectado, mas sem sinal. Teste outra saída ou arquivo local.",
    waiting: "Aguardando o captador Android…",
    pairing: "Código válido por dois minutos. Digite no APK.",
    offline: "Captador não conectado.",
  }[native];
  if (s.rhythm.source === "external")
    $("beat-meter").firstElementChild.style.width =
      Math.round((s.audio?.level || 0) * 100) + "%";
  $("demo-start").classList.toggle("hidden", s.mode === "live");
  const a = s.players.find((p) => p.id === s.champion),
    b = s.players.find((p) => p.id === s.challenger);
  for (const [key, p, fallback] of [
    ["a", a, "A COROA ESTÁ LIVRE"],
    ["b", b, "QUEM DESAFIA?"],
  ]) {
    $("name-" + key).textContent = p ? "@" + p.id : fallback;
    $("hp-" + key).style.width = p
      ? Math.max(0, (p.hp / s.rules.maxHp) * 100) + "%"
      : "0%";
    $("info-" + key).textContent = p
      ? `${Math.round(p.hp)} HP · FORÇA +${p.cheer}% · ESPECIAL ${Math.round(p.energy)}%`
      : "Uma rosa para entrar";
  }
  $("champion").textContent = a
    ? `♛ ${a.name} · ${a.streak} VITÓRIA${a.streak === 1 ? "" : "S"} SEGUIDA${a.streak === 1 ? "" : "S"}`
    : "♛ COROA LIVRE · QUEM VAI ENTRAR?";
  $("queue-label").textContent =
    `PLATEIA ${s.totalPlayers ?? s.players.length} · FILA ${s.queue.length} · ${s.totals.likes} CURTIDAS`;
  if (
    s.phase !== "victory" &&
    performance.now() > (window.actionCaptionUntil || 0) &&
    !(
      world.latestAttack?.special &&
      performance.now() / 1000 - world.latestAttack.time < 1.1
    )
  )
    $("callout").textContent =
      s.phase === "waiting"
        ? a
          ? "UMA ROSA PARA DESAFIAR O CAMPEÃO"
          : "UMA ROSA. SEU MASCOTE NO RINGUE."
        : s.phase === "entrance"
          ? "CHEGOU DESAFIANTE!"
          : `TORÇA COM @NOME · ${Math.max(0, Math.ceil((s.roundMs - s.boutElapsed) / 1000))}s`;
  $("ranking").replaceChildren(
    ...s.ranking.slice(0, 5).map((p, i) => {
      const li = document.createElement("li");
      li.textContent = `${p.name} · ${p.wins} vitórias · ${p.score} pontos`;
      return li;
    }),
  );
  document
    .querySelectorAll("[data-event]")
    .forEach((q) => (q.disabled = s.mode !== "demo"));
}
const es = new EventSource("/api/events");
es.addEventListener("state", (e) => {
  const s = JSON.parse(e.data);
  renderState(s);
});
es.addEventListener("action", (e) => action(JSON.parse(e.data)));
es.addEventListener("connection", (e) => {
  const s = JSON.parse(e.data);
  $("live-detail").textContent = s.message;
});
es.onerror = () => {
  connection = "offline";
  $("network").textContent = "SERVIDOR · RECONECTANDO";
  toast("Servidor indisponível. Aguardando recuperação…");
};
$("menu").onclick = () => $("drawer").classList.remove("hidden");
$("close").onclick = () => $("drawer").classList.add("hidden");
$("demo-start").onclick = async () => {
  try {
    await audio.unlock();
    await api("demo/start");
    toast("Demonstração iniciada. Todos os eventos são simulados.");
  } catch (e) {
    toast(e.message);
  }
};
$("demo-stop").onclick = () =>
  api("demo/stop")
    .then(() => toast("Eventos automáticos pausados."))
    .catch((e) => toast(e.message));
$("sound").onclick = () =>
  audio
    .unlock()
    .then(() => toast("Áudio ativado. Carregue sua música nos controles."))
    .catch((e) => toast(e.message));
$("fullscreen").onclick = () => {
  if (document.fullscreenElement) document.exitFullscreen?.();
  else
    document.documentElement
      .requestFullscreen?.()
      .catch(() => toast("Tela cheia indisponível neste navegador."));
};
$("connect").onclick = () =>
  api("live/connect", { username: $("username").value }).catch((e) =>
    toast(e.message),
  );
$("disconnect").onclick = () =>
  api("live/disconnect").catch((e) => toast(e.message));
document.querySelectorAll("[data-event]").forEach(
  (button) =>
    (button.onclick = async () => {
      try {
        const type = button.dataset.event;
        await audio.unlock();
        const out = await api("demo/event", {
          type,
          user: $("test-user").value,
          name: $("test-user").value,
          count: type === "like" ? 50 : 1,
          gift: "Rosa",
          repeatEnd: true,
          id: crypto.randomUUID(),
        });
        toast(out.result || "Interação recebida.");
      } catch (e) {
        toast(e.message);
      }
    }),
);
$("cheer-send").onclick = () =>
  api("demo/event", {
    type: "comment",
    user: $("test-user").value,
    text: $("cheer-target").value,
    id: crypto.randomUUID(),
  }).catch((e) => toast(e.message));
$("manual-beat").onclick = () =>
  api("beat", { source: "manual" }).catch((e) => toast(e.message));
$("music-file").onchange = async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    $("music-name").textContent = await audio.load(file);
    manualMusic = false;
    await $("music").play();
    await api("music", { source: "file" });
  } catch (err) {
    toast(err.message);
  }
};
$("music").onplay = () => {
  manualMusic = false;
  audio
    .unlock()
    .then(() => api("music", { source: "file" }))
    .catch((e) => toast(e.message));
};
$("music").onpause = () => {
  audio.cancelPending();
  if (manualMusic) return;
  api("music", { source: "paused" }).catch(() => {});
};
$("bpm").oninput = (e) => {
  $("bpm-value").textContent = e.target.value;
};
$("combat-style").onchange = e => api("music", { combatStyle: e.target.value })
  .then(() => toast(e.target.value === "anime" ? "Combate Anime: combos nos acentos do phonk." : "Combate Clássico selecionado."))
  .catch(e => toast(e.message));
$("bpm").onchange = (e) => {
  manualMusic = true;
  api("music", { source: "manual", bpm: Number(e.target.value) }).catch((err) =>
    toast(err.message),
  );
};
$("offset").oninput = (e) => {
  audio.offset = Number(e.target.value);
  $("offset-value").textContent = audio.offset + " ms";
  api("rhythm/offset", { offset: audio.offset }).catch(() => {});
};
let taps = [];
$("tap-tempo").onclick = () => {
  const t = performance.now();
  taps = taps.filter((x) => t - x < 4000);
  taps.push(t);
  if (taps.length > 1) {
    manualMusic = true;
    const delta = (taps.at(-1) - taps[0]) / (taps.length - 1),
      bpm = Math.round(60000 / delta);
    $("bpm").value = Math.min(240, Math.max(50, bpm));
    $("bpm-value").textContent = $("bpm").value;
    api("music", { source: "manual", bpm: Number($("bpm").value) }).catch(
      () => {},
    );
  }
};
$("quality").onchange = (e) => world.setQuality(e.target.value);
$("cinematic").onchange = (e) => (world.cinematic = e.target.checked);
$("reduce-motion").onchange = (e) => {
  world.reduceMotion = e.target.checked;
  $("ranking-look").disabled = e.target.checked;
  $("ranking-look").textContent = e.target.checked
    ? "Ranking no menu · câmera fixa"
    : "Mostrar ranking na câmera";
};
setInterval(() => {
  const m = world.metrics();
  $("metrics").textContent =
    `${m.fps} FPS neste navegador · ${m.visible} mascotes desenhados · ${m.particles} partículas`;
  $("metrics").dataset.fps = m.fps;
}, 1000);
window.PULSO = {
  world,
  audio,
  api,
  get state() {
    return state;
  },
  get connection() {
    return connection;
  },
};

$("auto-beat").onclick = async () => {
  if (!$("music").src) {
    toast("Carregue um arquivo de música primeiro.");
    return;
  }
  manualMusic = false;
  await audio.unlock();
  await $("music").play();
  await api("music", { source: "file" });
  toast("Detector do arquivo ativado.");
};

$("orbit-speed").oninput = (e) => {
  $("orbit-value").textContent = e.target.value + " s";
  world.orbitSeconds = Number(e.target.value);
};
const sendChat = (text) =>
  api("demo/event", {
    type: "comment",
    user: $("test-user").value,
    text,
    id: crypto.randomUUID(),
  }).catch((e) => toast(e.message));
$("chat-send").onclick = () => sendChat($("chat-text").value);
document
  .querySelectorAll("[data-chat]")
  .forEach((b) => (b.onclick = () => sendChat(b.dataset.chat)));
$("pair-generate").onclick = async () => {
  try {
    manualMusic = true;
    audio.pause();
    const r = await api("rhythm/code");
    $("pair-code").textContent = r.code;
    toast("Digite este código no Pulso Batida. Porta " + r.port + ".");
  } catch (e) {
    toast(e.message);
  }
};
$("native-select").onclick = async () => {
  manualMusic = true;
  audio.pause();
  await api("music", { source: "external" }).catch((e) => toast(e.message));
};
$("pair-disconnect").onclick = () =>
  api("rhythm/disconnect")
    .then(() => {
      $("pair-code").textContent = "— — — — — —";
      toast("Captador desconectado.");
    })
    .catch((e) => toast(e.message));

$("detection-mode").onchange = (e) => {
  audio.setMode(e.target.value);
  api("rhythm/mode", { mode: e.target.value }).catch((err) =>
    toast(err.message),
  );
};

$("ranking-scene").onchange = (e) => (world.showRanking = e.target.checked);
$("ranking-look").onclick = () => {
  world.showRanking = true;
  $("ranking-scene").checked = true;
  world.rankFocusUntil = performance.now() / 1000 + 3.5;
  $("drawer").classList.add("hidden");
};
