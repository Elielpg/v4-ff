import { clamp, smooth } from "./choreo.js";
export function ringPoint(p, radius = 2.35) {
  const n = Math.hypot(p.x, p.z), s = n > radius ? radius / n : 1;
  return { x: p.x * s, z: p.z * s };
}
export function teleportDestination(from, opponent) {
  const dx = opponent.x - from.x, dz = opponent.z - from.z;
  const n = Math.hypot(dx, dz) || 1;
  return ringPoint({ x: opponent.x + dx / n * 1.3, z: opponent.z + dz / n * 1.3 });
}
export function blinkPosition(blink, base, age, calm = false) {
  if (!blink || age < 0 || age > 1.05) return { x: base.x, z: base.z, scale: 1 };
  const travel = smooth(age / (calm ? 0.2 : 0.055));
  const hold = 0.38, back = smooth((age - hold) / 0.67);
  const side = Math.sin(back * Math.PI) * 0.65;
  return {
    ...ringPoint({
      x: (blink.from.x + (blink.to.x - blink.from.x) * travel) * (1 - back) + base.x * back + side,
      z: (blink.from.z + (blink.to.z - blink.from.z) * travel) * (1 - back) + base.z * back - side,
    }),
    scale: calm ? 1 : 1 - Math.sin(travel * Math.PI) * 0.55,
  };
}
export function editCamera(age, duration, finisher = false) {
  const p = clamp(age / Math.max(0.07, duration));
  const hit = Math.exp(-Math.max(0, age) * 18);
  return {
    zoom: hit * (finisher ? 0.09 : 0.035),
    roll: Math.sin(p * Math.PI * 2) * hit * (finisher ? 0.035 : 0.018),
    whip: Math.sin(p * Math.PI) * hit * (finisher ? 0.35 : 0.14),
  };
}
export function pairRadius(points, angle, aspect, fov, center = { x: 0, z: 0 }) {
  const tangent = Math.tan(fov / 2) * Math.max(0.3, aspect);
  const right = { x: Math.cos(angle), z: -Math.sin(angle) };
  const front = { x: Math.sin(angle), z: Math.cos(angle) };
  return Math.max(11.6, ...points.map(p => {
    const x = p.x - center.x, z = p.z - center.z;
    return (Math.abs(x * right.x + z * right.z) + 0.85) / tangent + x * front.x + z * front.z;
  }));
}
