export const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const smooth = (x) => {
  x = clamp(x);
  return x * x * (3 - 2 * x);
};
export function orbitPose(
  angle,
  { special = false, reduceMotion = false } = {},
) {
  const a = reduceMotion ? 0.63 : angle,
    r = special ? 8.6 : 11.6;
  return {
    x: Math.sin(a) * r,
    z: Math.cos(a) * r,
    y: special ? 3.6 : 5.1 + (reduceMotion ? 0 : Math.sin(a * 2) * 0.35),
  };
}
export function fightFootwork(t, slot, bpm = 110, dancePhase) {
  const phase = dancePhase ?? ((t * bpm) / 60) * Math.PI * 2,
    angle = t * 0.21 + 0.1 * Math.sin(phase * 0.25),
    side = slot === 0 ? -1 : 1;
  return {
    x: side * Math.cos(angle) * (1.02 + 0.06 * Math.sin(phase)),
    z: side * Math.sin(angle) * 1.02,
    yaw: Math.atan2(-side * Math.cos(angle), -side * Math.sin(angle)),
    step: Math.sin(phase) * 0.055,
  };
}
export function strikeEnvelope(progress) {
  const p = clamp(progress);
  return p < 0.22 ? smooth(p / 0.22) : 1 - smooth((p - 0.22) / 0.78);
}

export function advanceDancePhase(phase, dt, bpm, error = 0) {
  const base = (Math.max(0, dt) * Math.PI * 2 * bpm) / 60;
  return (
    phase + base + Math.max(-base * 0.35, Math.min(base * 0.35, error * dt * 3))
  );
}
