const B = BABYLON;
// Small offline shader: three lighting bands, camera fill and a restrained rim.
B.Effect.ShadersStore.pulsoToonVertexShader = `
precision highp float;
attribute vec3 position;
attribute vec3 normal;
uniform mat4 world;
uniform mat4 worldViewProjection;
varying vec3 vNormal;
varying vec3 vPosition;
void main() {
  vNormal = normalize(mat3(world) * normal);
  vPosition = (world * vec4(position, 1.0)).xyz;
  gl_Position = worldViewProjection * vec4(position, 1.0);
}`;
B.Effect.ShadersStore.pulsoToonFragmentShader = `
precision highp float;
uniform vec3 baseColor;
uniform vec3 lightDirection;
uniform vec3 eyePosition;
uniform float pulse;
varying vec3 vNormal;
varying vec3 vPosition;
void main() {
  vec3 n = normalize(vNormal);
  vec3 view = normalize(eyePosition - vPosition);
  float d = max(0.0, dot(n, normalize(lightDirection)));
  float shade = mix(0.57, 0.87, step(0.18, d));
  shade = mix(shade, 1.08, step(0.67, d));
  float rim = pow(1.0 - max(0.0, dot(n, view)), 3.0) * 0.16;
  gl_FragColor = vec4(baseColor * shade + rim * vec3(0.5, 0.85, 1.0) + baseColor * pulse * 0.06, 1.0);
}`;
export function toonMaterial(world, name, color) {
  const m = new B.ShaderMaterial(name, world.scene, "pulsoToon", {
    attributes: ["position", "normal"],
    uniforms: ["world", "worldViewProjection", "baseColor", "lightDirection", "eyePosition", "pulse"],
  });
  m.setColor3("baseColor", typeof color === "string" ? B.Color3.FromHexString(color) : color);
  m.setVector3("lightDirection", new B.Vector3(0.4, 0.9, 0.5));
  m.setVector3("eyePosition", world.camera.position);
  m.setFloat("pulse", 0);
  world.toonMaterials.add(m);
  m.onDisposeObservable.add(() => {
    world.toonMaterials.delete(m);
    m.fallbackMaterial?.dispose();
  });
  // A failed GPU shader keeps the game usable with ordinary materials.
  m.onError = () => {
    if (m.fallbackMaterial) return;
    const fallback = new B.StandardMaterial(name + "-compatível", world.scene);
    fallback.diffuseColor = typeof color === "string" ? B.Color3.FromHexString(color) : color;
    fallback.specularColor = B.Color3.Black();
    m.fallbackMaterial = fallback;
    for (const mesh of world.scene.meshes) if (mesh.material === m) mesh.material = fallback;
  };
  return m;
}
