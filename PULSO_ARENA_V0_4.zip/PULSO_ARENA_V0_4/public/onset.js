export const DETECTION_MODES = {
  phonk: { gap: 0.095, threshold: 1 },
  sensitive: { gap: 0.085, threshold: 0.65 },
  soft: { gap: 0.15, threshold: 1.65 },
};
export class OnsetDetector {
  constructor(mode = "phonk") {
    this.setMode(mode);
    this.reset();
  }
  setMode(mode) {
    this.mode = DETECTION_MODES[mode] ? mode : "phonk";
  }
  reset() {
    this.avg = 0;
    this.flux = 0;
    this.prev = 0;
    this.last = -Infinity;
    this.at = null;
    this.peak = 0;
    this.strength = 0;
    this.samples = 0;
  }
  sample(value, at) {
    if (!Number.isFinite(value) || !Number.isFinite(at) || value < 0)
      return false;
    const dt =
      this.at === null ? 0.016 : Math.max(0.001, Math.min(0.1, at - this.at));
    if (this.at !== null && at < this.at) {
      this.reset();
    }
    this.at = at;
    const rise = Math.max(0, value - this.prev),
      cfg = DETECTION_MODES[this.mode];
    // Positive spectral/envelope flux detects a quiet attack after a strong kick.
    // Its threshold follows the local change/noise, not 1.6x the previous bass peak.
    const threshold =
      Math.max(0.0005, this.avg * 0.045, this.flux * 2.2) * cfg.threshold;
    const hit =
      this.samples > 3 &&
      rise > threshold &&
      value > this.prev * (1 + 0.08 * cfg.threshold) &&
      at - this.last >= cfg.gap;
    this.avg += (value - this.avg) * (1 - Math.exp(-dt / 0.6));
    this.flux += (rise - this.flux) * (1 - Math.exp(-dt / 0.7));
    this.peak = Math.max(value, this.peak * Math.exp(-dt / 0.55));
    this.prev = value;
    this.samples++;
    if (hit) {
      this.last = at;
      this.strength = Math.max(
        0.12,
        Math.min(1, value / Math.max(0.00001, this.peak)),
      );
    }
    return hit;
  }
}
// Musical tempo and fast accents are separate. Equal rapid accents are octave-folded
// into 50–240 BPM; consistent strong accents take precedence over subdivisions.
export class PulseTracker {
  constructor() {
    this.reset();
  }
  reset() {
    this.last = null;
    this.anchor = null;
    this.anchorEvidence = -Infinity;
    this.intervals = [];
    this.anchors = [];
    this.anchorVotes = [];
    this.interval = 545;
  }
  note(at, strength = 1) {
    if (this.last !== null && at - this.last < 80) return null;
    if (this.last !== null && at - this.last > 2500) this.reset();
    const delta = this.last === null ? null : at - this.last;
    this.last = at;
    if (delta !== null && delta >= 80 && delta <= 1500) {
      this.intervals.push(delta);
      this.intervals = this.intervals.slice(-12);
    }
    if (strength >= 0.65) {
      const d = this.anchor === null ? null : at - this.anchor;
      this.anchor = at;
      if (d !== null) {
        this.anchorVotes.push(d >= 250 && d <= 1200);
        this.anchorVotes = this.anchorVotes.slice(-12);
      }
      if (d >= 250 && d <= 1200) {
        this.anchors.push(d);
        this.anchors = this.anchors.slice(-6);
        this.anchorEvidence = at;
      }
    }
    const median = (a) => {
      const s = [...a].sort((x, y) => x - y);
      return s[Math.floor(s.length / 2)];
    };
    const center = (a) => {
      const m = median(a);
      const xs = a.filter((x) => Math.abs(x - m) <= m * 0.4);
      return xs.reduce((a, b) => a + b, 0) / (xs.length || 1) || 545;
    };
    let period = center(this.intervals),
      anchored = false;
    if (
      this.anchors.length >= 2 &&
      at - this.anchorEvidence < 1500 &&
      this.anchorVotes.filter(Boolean).length >=
        Math.ceil(this.anchorVotes.length * 0.7)
    ) {
      const anchor = center(this.anchors),
        stable =
          this.anchors.filter((x) => Math.abs(x - anchor) < anchor * 0.18)
            .length >= Math.ceil(this.anchors.length * 0.7);
      if (stable) {
        period = anchor;
        anchored = true;
      }
    }
    if (!anchored && period < 250) {
      const choices = [2, 4, 8, 16]
        .map((n) => period * n)
        .filter((x) => x >= 250 && x <= 1200);
      period =
        choices.sort(
          (a, b) =>
            Math.abs(Math.log(a / this.interval)) -
            Math.abs(Math.log(b / this.interval)),
        )[0] || 500;
    }
    while (period > 1200) period /= 2;
    this.interval = period;
    return {
      interval: period,
      pulseInterval: delta || period,
      strength,
      confidence: this.intervals.length >= 4,
    };
  }
}
