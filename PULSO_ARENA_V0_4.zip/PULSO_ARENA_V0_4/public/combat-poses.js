import { clamp, strikeEnvelope } from "./choreo.js";
export function attackPose(move, progress) {
  const p = clamp(progress),
    rapid = ["flurry", "airCombo"].includes(move),
    contact = rapid ? (p >= 1 ? 1 : (p * 3) % 1) : p,
    f = strikeEnvelope(contact),
    kick = ["kick", "jumpKick", "entryKick", "spin", "spinKick", "teleportKick", "quakeKick"].includes(move),
    side = rapid ? (Math.floor(p * 3) % 2 ? -1 : 1) : ["cross", "teleportCross"].includes(move) ? -1 : 1;
  const arm = {
    side,
    elbow: [side * 0.28, 1.12, 0.28 + f * 0.3],
    hand: [side * 0.12, 1.27, 0.4 + f * 0.92],
  };
  if (move === "hook") {
    arm.elbow = [side * 0.5, 1.2, 0.2 + f * 0.35];
    arm.hand = [side * (0.5 - 0.78 * f), 1.32, 0.3 + f * 0.82];
  }
  if (move === "uppercut") {
    arm.elbow = [side * 0.32, 0.94 + f * 0.3, 0.22 + f * 0.28];
    arm.hand = [side * 0.15, 0.97 + f * 0.83, 0.3 + f * 0.72];
  }
  return {
    force: f,
    kick,
    arm,
    twist: (side * (rapid ? 0.22 : move === "hook" ? 0.3 : 0.17)) * f,
    spin: ["spin", "spinKick", "teleportKick"].includes(move) ? smoothSpin(p) : 0,
    jump:
      ["jumpKick", "entryKick", "teleportKick", "airCombo"].includes(move)
        ? Math.sin(Math.PI * p) * 0.72
        : 0,
    crouch: ["uppercut", "quakeKick"].includes(move) ? Math.sin(Math.PI * p) * 0.07 : 0,
    rapid,
    dash: move === "dashJab" ? 0.42 * f : 0,
    knee: [0.18, 0.43 + f * 0.54, 0.08 + f * 0.52],
    foot: [0.18, 0.1 + f * 0.98, 0.1 + f * 1.24],
  };
}
function smoothSpin(p) {
  return (p * p * (3 - 2 * p)) * Math.PI * 2;
}
export function celebrationPose(kind, beat, t) {
  const s = Math.sin(beat),
    c = Math.cos(beat),
    hop = Math.max(0, Math.sin(beat * 2));
  if (kind === "shuffle")
    return {
      x: s * 0.18,
      z: c * 0.1,
      jump: hop * 0.07,
      yaw: s * 0.18,
      arm: Math.sin(beat + 1) * 0.32,
      step: 0.25,
    };
  if (kind === "spin")
    return {
      x: s * 0.07,
      z: 0,
      jump: hop * 0.16,
      yaw: t * 0.95,
      arm: 0.3 + Math.sin(beat) * 0.15,
      step: 0.16,
    };
  if (kind === "robot")
    return {
      x: Math.sin(Math.floor(beat / 1.4) * 1.4) * 0.09,
      z: 0,
      jump: hop * 0.03,
      yaw: Math.sin(Math.floor(beat / 1.4)) * 0.3,
      arm: Math.sin(Math.floor(beat / 1.4)) * 0.3,
      step: 0.12,
    };
  return {
    x: s * 0.08,
    z: 0,
    jump: hop * 0.2,
    yaw: s * 0.11,
    arm: 0.25 + Math.cos(beat) * 0.2,
    step: 0.18,
  };
}
