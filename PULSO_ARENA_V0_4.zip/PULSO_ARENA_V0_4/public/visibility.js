// Slab test for a finite camera-to-fighter segment. Objects behind the subject
// are never faded, and an eye inside an object is handled without a division by 0.
export function segmentHitsBox(eye, target, min, max) {
  let lo = 0,
    hi = 1;
  for (const key of ["x", "y", "z"]) {
    const d = target[key] - eye[key];
    if (Math.abs(d) < 1e-8) {
      if (eye[key] < min[key] || eye[key] > max[key]) return false;
      continue;
    }
    let a = (min[key] - eye[key]) / d,
      b = (max[key] - eye[key]) / d;
    if (a > b) [a, b] = [b, a];
    lo = Math.max(lo, a);
    hi = Math.min(hi, b);
    if (lo > hi) return false;
  }
  return hi > 0.005 && lo < 0.97;
}
