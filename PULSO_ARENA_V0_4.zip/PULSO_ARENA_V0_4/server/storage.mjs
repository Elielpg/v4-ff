import {
  mkdir,
  readFile,
  writeFile,
  rename,
  copyFile,
  stat,
} from "node:fs/promises";
import path from "node:path";
export class Store {
  constructor(dir) {
    this.dir = dir;
    this.pending = Promise.resolve();
    this.latest = new Map();
    this.running = false;
    this.error = null;
    this.corrupt = new Set();
  }
  async read(name) {
    for (const suffix of [".json", ".json.bak"]) {
      try {
        const f = path.join(this.dir, name + suffix);
        if ((await stat(f)).size > 8e6) throw Error("Estado excede limite");
        const data = JSON.parse(await readFile(f, "utf8"));
        if (suffix.endsWith(".bak"))
          console.error("Estado recuperado do backup:", name);
        return data;
      } catch (e) {
        if (e.code !== "ENOENT") {
          if (suffix === ".json") this.corrupt.add(name);
          console.error("Estado indisponível:", name, e.message);
        }
      }
    }
    return null;
  }
  save(name, value) {
    const text = JSON.stringify(value);
    if (Buffer.byteLength(text) > 8e6)
      return Promise.reject(Error("Estado excede limite"));
    this.latest.set(name, text);
    if (!this.running) {
      this.running = true;
      this.pending = this.drain();
    }
    return this.pending;
  }
  async drain() {
    try {
      await mkdir(this.dir, { recursive: true, mode: 0o700 });
      while (this.latest.size) {
        const [name, text] = this.latest.entries().next().value;
        this.latest.delete(name);
        const f = path.join(this.dir, name + ".json"),
          tmp = f + ".tmp";
        await writeFile(tmp, text, { mode: 0o600 });
        if (!this.corrupt.has(name))
          await copyFile(f, f + ".bak").catch((e) => {
            if (e.code !== "ENOENT") throw e;
          });
        await rename(tmp, f);
        this.corrupt.delete(name);
      }
      this.error = null;
    } catch (e) {
      this.error = e.message;
      throw e;
    } finally {
      this.running = false;
    }
  }
  flush() {
    return this.pending.catch((e) =>
      console.error("Falha ao salvar:", e.message),
    );
  }
}
