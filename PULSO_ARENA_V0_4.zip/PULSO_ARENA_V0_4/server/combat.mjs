const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const COMBOS = Object.freeze({
  fox: ["dashJab", "flurry", "teleportCross", "spinKick"],
  hippo: ["hook", "flurry", "uppercut", "quakeKick"],
  raccoon: ["flurry", "teleportCross", "airCombo", "teleportKick"],
  ram: ["dashJab", "uppercut", "airCombo", "jumpKick"],
});
export function animeStrike(type, step, pulseMs, beatMs) {
  const cadence = clamp(Number(pulseMs) || beatMs, 80, beatMs);
  const moves = COMBOS[type] || COMBOS.fox;
  const index = Math.max(0, Math.floor(step)) % moves.length;
  return {
    move: moves[index],
    combo: index + 1,
    comboTotal: moves.length,
    finisher: index === moves.length - 1,
    teleport: moves[index].startsWith("teleport"),
    cadenceMs: cadence,
    // Contacts become faster; total damage and special charge stay musical.
    energyScale: cadence / beatMs,
    damageScale: cadence / beatMs,
    duration: clamp(cadence * 0.88 / 1000, 0.07, 0.44),
    style: "anime",
  };
}
