const CATALOG = {
  fox: [
    ["A raposa chegou… e a coroa ficou!", "😏", "shuffle"],
    ["Pisca não: meu passinho muda o placar!", "🦊", "spin"],
    ["Pé ligeiro, coroa firme!", "⚡", "shuffle"],
    ["Esse combo veio com malandragem de raposa!", "👑", "bounce"],
  ],
  hippo: [
    ["Pesadão no passo, levinho na vitória!", "🦛", "bounce"],
    ["O ringue tremeu. Eu só tava dançando!", "😎", "bounce"],
    ["Quem disse que hipopótamo não tem swing?", "🕺", "shuffle"],
    ["A coroa ficou confortável. Vou ficando!", "👑", "robot"],
  ],
  raccoon: [
    ["Peguei a coroa! Devolução só no próximo round!", "🦝", "robot"],
    ["Sumiu o golpe… apareceu a vitória!", "💨", "shuffle"],
    ["Esse combo veio com nota fiscal?", "🧾", "robot"],
    ["Eu vim pelo beat. Saí com o troféu!", "🏆", "spin"],
  ],
  ram: [
    ["Deu bode pra quem me desafiou!", "🐏", "spin"],
    ["Esse passinho tem assinatura!", "😎", "shuffle"],
    ["A torcida pediu show. Entreguei a coroa!", "👑", "bounce"],
    ["Pode chamar o próximo: ainda tem dança!", "🔥", "spin"],
  ],
};
export function celebrationFor(archetype, random = Math.random, previous = -1) {
  const lines = CATALOG[archetype] || CATALOG.fox;
  let id = Math.min(
    lines.length - 1,
    Math.max(0, Math.floor(random() * lines.length)),
  );
  if (id === previous) id = (id + 1) % lines.length;
  const [text, emoji, dance] = lines[id];
  return { id, text, emoji, dance };
}
