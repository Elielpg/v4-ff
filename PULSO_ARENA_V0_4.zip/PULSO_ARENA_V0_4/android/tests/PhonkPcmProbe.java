import br.pulso.rhythm.BeatMeter;
import java.io.*;
import java.util.Locale;
// Fixed 48 kHz mono PCM16 fixture produced for this regression test, not a WAV parser.
public class PhonkPcmProbe {
 public static void main(String[] args)throws Exception{
  BeatMeter meter=new BeatMeter(48000);
  try(InputStream in=new BufferedInputStream(new FileInputStream(args[0]))){
   for(int i=0;i<44;i++)if(in.read()<0)throw new EOFException();
   int lo,hi;long n=0;
   while((lo=in.read())>=0&&(hi=in.read())>=0){short value=(short)(lo|(hi<<8));double energy=meter.push(value/32768.0);n++;if(energy>=0)System.out.printf(Locale.US,"%.7f %.7f %.7f %.3f%n",energy,meter.detail,meter.level,n/48.0);}
  }
 }
}
