# PULSO ARENA · 0.4.0

Atualização do ringue interativo original: câmera 360°, comentários sobre os mascotes, defesa/esquiva e iluminação de festa, além de mascotes 3D, plateia de espectadores, entrada por rosa, torcida, HP por curtidas e luta na batida. Projeto independente, pensado para navegador e Termux. Não altera a instalação do Ben 10.

## Novidades 0.4 — combate Anime / Phonk

O estilo **Anime** é o padrão: os acentos rápidos aceitos pelo detector agora
acionam golpes curtos, com combos de quatro etapas, rajadas de socos alternados,
arrancadas, ganchos, chutes aéreos e teleporte. A velocidade acompanha as
subdivisões; o dano e a carga do especial são proporcionais à cadência para
preservar a participação da torcida. Bloqueios e esquivas interrompem o combo.

As quatro espécies originais ganharam luz em três faixas, contornos, bandanas e
equipamento de luta. Há ecos de silhueta no teleporte, rastros e impactos em pool
limitado. A câmera acompanha o centro da dupla, reage aos finalizadores e ajusta
a distância para caber no retrato. O controle **Reduzir movimentos e luzes**
continua disponível.

Em **Música e batida → Estilo da luta**, é possível selecionar **Clássico**,
mantendo o ritmo anterior. A preferência é salva por modo (demo/LIVE). O APK
Pulso Batida **0.2.1** permanece compatível: não precisa reinstalá-lo.

Instalação, evidências, limites e reversão: `docs/ATUALIZACAO_V0_4.md`.
As prévias atuais são capturas reais do renderer com participantes fictícios.

## Preservado da 0.3 — câmera livre, golpes e comemorações

O painel de fundo foi reposicionado para fora da órbita. Postes, cordas e o novo placar ficam transparentes quando cruzam a linha de visão dos lutadores. A luz próxima à câmera mantém os mascotes legíveis de diferentes ângulos.

A luta ganhou gancho lateral e chute saltando, além de rastros, estrelas de impacto, efeito de bloqueio, esquiva e anéis de saída/aterrissagem. O comando **PULAR** faz um salto visual; não dá invulnerabilidade.

Cada mascote tem quatro farpas leves próprias, sorteadas sem repetir imediatamente a anterior. Ao vencer, mostra emoji e frase no balão e executa uma dança de comemoração. A pausa da vitória dura 6,5 s e preserva a fila; a câmera pode enquadrar o placar ao final. Não há narração falada dessas frases.

O **Top do Ringue** fica em um painel 3D acima da plateia e mostra os três primeiros. O ranking do menu continua disponível. Em **Qualidade**, é possível ocultar o painel ou tocar **Mostrar ranking na câmera**. O enquadramento automático respeita a opção de reduzir movimentos.

As melhorias de batida da 0.2.1 foram mantidas. Se você já usa o captador **Pulso Batida 0.2.1**, não precisa reinstalá-lo para esta atualização.

Relatório: `docs/ATUALIZACAO_V0_3.md`. Prévias: `docs/previas/`.

## Ajuste phonk 0.2.1 preservado

O detector analisa graves e percussão em faixas separadas e aceita acentos rápidos sem reiniciar a dança a cada nota. O andamento musical e as subdivisões são tratados separadamente; no estilo Anime, os golpes também seguem esses acentos, com dano proporcional. O captador envia pequenos lotes com timestamps, preservando amostras que antes eram descartadas.

Em **Música e batida → Detecção de batidas**, use **Phonk** por padrão, **Sensível** para trechos fracos ou **Suave** se houver reações demais. O BPM manual vai até 240. A compensação Bluetooth continua necessária conforme o fone/caixa; sensibilidade não corrige atraso físico da saída.

Se usar GreenTube ou outro aplicativo, instale também o APK 0.2.1 sobre a edição anterior e gere outro código de pareamento. A assinatura do captador foi mantida. O modo Visualizer continua dependendo do sinal disponibilizado pelo aparelho.

Resultados e limites em `docs/CORRECAO_PHONK_0_2_1.md`. O relatório visual da versão anterior foi mantido em `docs/arquivo/RELATORIO_0_2.pdf`.

## Instalar no Termux

Use Termux atualizado e Node **22.19 ou mais recente**. A instalação inicial das dependências precisa de internet. O teste local funciona depois sem conexão ao TikTok.

Se necessário, libere o acesso à pasta Downloads com `termux-setup-storage`. Com o ZIP em Downloads:

```bash
cd ~
python3 -m zipfile -e ~/storage/downloads/PULSO_ARENA_V0_4.zip .
cd ~/PULSO_ARENA_V0_4
bash install.sh
bash start.sh
```

Se Python ainda não estiver instalado: `pkg install python`.

Abra **http://127.0.0.1:3100** no Chrome do mesmo celular. Toque em **Testar arena** para iniciar uma demonstração com participantes fictícios. O botão também libera o áudio exigido pelo navegador.

Para iniciar nas próximas vezes:

```bash
cd ~/PULSO_ARENA_V0_4 && bash start.sh
```

Para parar, use **Ctrl+C** no terminal original ou `bash stop.sh` em outra sessão dentro da pasta. Para reiniciar, pare primeiro e execute `bash start.sh`. O programa usa a porta 3100; se outro serviço já estiver nela, informa o conflito e não entra em um ciclo de reinicialização.

## Experimentar as interações

Abra o menu **☰ → Teste de interações**. Escolha um nome de usuário e teste entrada, curtidas, rosa, compartilhamento, seguidor e torcida. Esses botões não enviam presentes nem interagem com a conta real do TikTok.

1. Quem entra recebe um mascote e uma identificação na plateia.
2. **5 curtidas do próprio usuário = +1 HP**, até 250 HP. Quem está na plateia guarda vida para a próxima entrada.
3. **1 rosa coloca o usuário na fila**. A primeira pessoa ocupa a coroa provisória, sem receber vitória automática.
4. O próximo desafiante entra com um chute de 10 de dano. A luta segue a batida, com socos, chutes, giros e especial.
5. Comentar **@usuario** fortalece aquele jogador. Nome de exibição exato também funciona se identificar apenas uma pessoa. A força extra tem limite de 30%.
6. Compartilhar fortalece o próprio mascote. O vencedor fica no ringue com o HP restante e soma vitória no ranking.

Cada pessoa ocupa uma única posição na fila. Rosas adicionais não duplicam posições e não interrompem uma luta em andamento. A fila tem limite de 100 pessoas; uma nova rosa durante a luta do próprio usuário carrega o especial. Há 15 segundos de recuperação após uma derrota. Curtidas sem identificação individual somam no total da arena, sem inventar HP para alguém.

Durante o combate, a cura chega gradualmente: até 3 HP por segundo, com reserva de cura de até 30. A rodada dura até 45 segundos ativos e termina por nocaute ou decisão de HP. Os valores ficam em `server/engine.mjs`.

## Música e sincronia

No menu **Música e batida**, carregue MP3, M4A ou WAV. O áudio toca pelo player do navegador, e a análise dos graves controla a batida, os golpes e as luzes. O arquivo é aberto por URL local; o código não decodifica uma hora inteira de música em um grande buffer na RAM.

Para caixa ou fone Bluetooth, ajuste **Compensação Bluetooth** de 0 a 400 ms até os movimentos coincidirem com o som. A latência varia por aparelho. O detector pode interpretar a metade ou o dobro do andamento em algumas músicas; use BPM manual ou **Marcar batida (TAP)** para corrigir. **Usar detector do arquivo** retorna ao modo automático.

**GreenTube e outros aplicativos:** instale o APK **Pulso Batida** incluído no ZIP, em `public/downloads/PULSO_BATIDA_V0_2_1.apk`, ou baixe pelo botão no menu do jogo. Requer Android 10+. O navegador sozinho não recebe o áudio desses aplicativos.

1. Com o Termux ligado, abra **☰ → Música e batida → Gerar código**.
2. Abra o aplicativo Pulso Batida, digite os seis números e mantenha a porta **3100**.
3. Deixe **Captura compartilhada avançada** desmarcada e toque em **Conectar e captar a batida**. Permita o acesso de áudio solicitado pelo Android.
4. Toque sua música no GreenTube e volte ao jogo. O painel deve indicar **Captador conectado · energia de áudio recebida**; o ritmo aparece como **ANDROID**.
5. Ajuste a compensação Bluetooth no jogo. Para encerrar, use **Desconectar** no jogo ou **Parar** no APK/notificação.

O modo padrão usa o Visualizer da saída de áudio, sem iniciar outra captura de tela e sem abrir a entrada do microfone. Só envia níveis numéricos ao Termux no próprio celular. Alguns aparelhos, rotas Bluetooth e aplicativos não disponibilizam esse sinal. Nesses casos o jogo informa ausência de sinal; arquivo local e BPM/TAP continuam disponíveis. O APK foi compilado e teve assinatura verificada, mas a captura no Realme GT3 ainda não foi testada.

A opção avançada do APK usa AudioPlaybackCapture e depende de o aplicativo da música permitir a captura. Ela pede consentimento de compartilhamento e pode interromper outra captura de tela já usada para transmitir a LIVE. Por isso fica desligada por padrão e tem confirmação própria; prefira o modo padrão durante a transmissão. Não existe troca automática para esse modo. Mais detalhes em `android/README.md`.

Pausar a música no player pausa os golpes da luta. Selecionar um BPM manual permite continuar o combate nesse andamento. Toque em **♫** para liberar áudio se o navegador estiver bloqueando o som. O pacote inclui uma batida sintética de teste em `tests/fixtures/batida-120.wav`; não inclui músicas comerciais.

## TikTok LIVE

Inicie sua transmissão pelo aplicativo que costuma usar. No jogo, abra **☰ → Conectar à LIVE**, informe somente o @ e toque em **Conectar**. Aguarde **LIVE · CONECTADA**. A leitura usa o conector `piratetok-live-js`, sem senha da conta.

O conector e a tradução de eventos estão implementados; a conexão a uma LIVE pública real **ainda precisa ser validada no seu aparelho e conta**. O TikTok pode alterar esse protocolo. Os testes de integração foram locais, com eventos simulados e conexões controladas. Valide a leitura dos presentes em uma sessão de teste.

Demo e LIVE possuem estados separados. A demonstração se identifica na tela; os botões de eventos fictícios são recusados no modo LIVE. Sem conexão, os ataques da LIVE ficam suspensos. A reconexão ao TikTok é manual pelo painel.

## Qualidade e estabilidade

- **Leve:** até 8 mascotes visíveis na plateia, menor resolução, sem sombras dinâmicas e brilho adicional.
- **Equilibrado:** até 16 lugares visíveis, sombras de 512 pixels e brilho.
- **Detalhado:** até 24 lugares visíveis e resolução maior.

O restante dos participantes continua registrado, embora nem todos sejam desenhados simultaneamente. O cadastro é limitado a 5.000 usuários e a fila a 100. Partículas e efeitos também possuem limites. O contador de FPS aparece no menu. Comece no perfil Leve no GT3 e ajuste após uma sessão real.

O supervisor acompanha o servidor em um processo separado. Se o servidor encerrar inesperadamente, tenta recuperá-lo até **4 vezes em 15 minutos**, com espera crescente; depois para e registra a falha. Um segundo início verifica se esta instalação já está aberta. O script solicita `termux-wake-lock` quando disponível.

O supervisor **não consegue se recuperar quando o Android encerra todo o Termux**, incluindo o próprio supervisor. Permita atividade em segundo plano e configure a bateria do Realme para não restringir o Termux. Temperatura, memória e duração de uma LIVE no aparelho ainda precisam de medição; não há promessa de execução ilimitada.

## Câmera, comentários, dança e defesa

A câmera completa uma volta em 18 segundos por padrão, com ajuste de 12 a 40 segundos em **Qualidade**. É possível desligar a câmera 360° ou usar **Reduzir movimentos e luzes** para manter um enquadramento fixo e efeitos mais suaves.

Os mascotes circulam pelo ringue, fazem passos laterais e usam socos diretos, cruzados, uppercuts, chutes, giros e especiais, com duração ajustada à batida. Há bloqueios e esquivas automáticas e comandos do próprio participante:

- **DEFESA / DEFENDER:** prepara uma defesa para o próximo golpe comum, válida por até 4,5 s. O bloqueio reduz o dano em cerca de 70%.
- **ESQUIVA / ESQUIVAR:** prepara uma esquiva para um golpe comum, válida por 2,5 s, evitando seu dano.
- **DANÇAR / DANÇA:** ativa os passos por 12 s; o personagem continua participando da luta.
- **LUTAR:** encerra a preferência de dança. Especiais atravessam a defesa comum.

Há intervalo mínimo de 2,5 s entre esses comandos de pose da mesma pessoa. Comentários comuns também aparecem sobre a cabeça do mascote por até 6,5 s, limitados a 140 caracteres e até seis balões simultâneos. A prioridade da plateia visível considera quem acabou de comentar. Mensagens não são interpretadas como HTML ou comandos de computador.

O guia inferior mostra a rosa com ilustração própria, a regra de vida, compartilhamento e os comandos de torcida, defesa e dança. Feixes móveis, luzes, piso LED e equalizador reagem às batidas. O controle para reduzir movimentos suaviza os efeitos.

## Atualizar uma instalação anterior preservando o progresso

Extraia o ZIP novo numa pasta separada e execute:

```bash
cd ~
python3 -m zipfile -e ~/storage/downloads/PULSO_ARENA_V0_4.zip .
bash ~/PULSO_ARENA_V0_4/ATUALIZAR.sh ~/PULSO_ARENA_V0_1
cd ~/PULSO_ARENA_V0_1 && bash start.sh
```

Se sua instalação estiver em outra pasta, substitua o último argumento. O atualizador valida os arquivos, para somente o supervisor da instalação indicada, espera o encerramento, cria um ZIP em `backups/`, copia o código e instala as dependências. Dados e logs existentes são mantidos. Após atualizar, a pasta antiga pode continuar se chamando V0_1, mas a versão retornada pelo servidor será 0.4.0.

Para uma instalação nova, use os comandos do início deste documento. O backup automático da atualização contém o código e o estado anterior. Para reverter, pare a arena, extraia esse backup na instalação, execute `bash install.sh` e depois `bash start.sh`. O formato de progresso permanece schema 1; a atualização não reinicia HP, fila ou ranking.

## Dados, backup e diagnóstico

O progresso é salvo localmente a cada segundo e em transições importantes. `data/live.json` guarda a LIVE e `data/demo.json` guarda a simulação. Cada arquivo tem uma cópia `.bak`. São persistidos HP, fila, ranking e identificadores recentes para deduplicação. Uma interrupção abrupta pode perder o último segundo ou uma gravação que não chegou ao armazenamento.

Antes de trocar arquivos, pare a arena e guarde as pastas **data** e **logs**, além do ZIP desta versão. Para reverter uma atualização futura, restaure o código anterior junto de um backup de dados compatível. O atualizador é específico da Pulso Arena; não modifica o projeto Ben 10.

Logs úteis:

```bash
cd ~/PULSO_ARENA_V0_4
tail -n 30 logs/supervisor.jsonl
tail -n 30 logs/server.jsonl
```

O log do servidor registra início, fim, estado de conexão e, a cada minuto, uso de memória do Node. O supervisor registra código de saída e sinal. Se o aplicativo inteiro for morto, os últimos logs ajudam a localizar onde a sessão parou, mas podem não registrar a causa do Android.

## Estrutura e validação

```text
server/engine.mjs       regras, HP, fila, golpes e ranking
server/combat.mjs       combos por mascote e escala de cadência/dano
server/live.mjs         normalização e conexão TikTok
server/storage.mjs      gravação atômica e recuperação do backup
server/index.mjs        HTTP, eventos SSE, modos e persistência
public/world.js         mascotes, arena, animação, efeitos e câmera
public/audio.js         player, análise e efeitos sonoros
public/onset.js         detector de transientes testável
public/beat-meter.js    processamento AudioWorklet
public/app.js           interface e eventos
public/choreo.js        curvas de golpe, trajetória e câmera
public/combat-poses.js  poses de golpe e estilos de dança
public/combat-fx.js     efeitos em pool limitado
public/anime-motion.js teleporte, limites do ringue e enquadramento
public/toon.js          shader local de três faixas para mascotes
public/visibility.js    interseção da linha de visão
server/celebrations.mjs farpas e identidade de comemoração
server/rhythm.mjs       pareamento e análise da ponte Android
android/app/            fonte do captador de áudio e recursos
scripts/supervisor.mjs  recuperação limitada do servidor
scripts/instance.mjs    identificação e parada desta instalação
tests/                 regras, áudio, armazenamento, conector e HTTP
docs/                  projeto, limitações e evidências
```

Execute `npm test`. Consulte `docs/PROJETO.md`, `docs/PROBLEMAS_PENDENTES.md` e `docs/evidencias/` para resultados e limites dos testes.

O visual entregue usa quatro bases de mascotes geométricos originais. A imagem `docs/CONCEITO_VISUAL.png` é uma **arte de direção visual**; `docs/PULSO_ARENA_PREVIA.png` é uma **captura real do protótipo**. O jogo usa animação procedural, sem alegar um conjunto final de animações desenhadas ou capturadas. As boas-vindas atuais são texto e efeito sonoro; não há narrador de IA nesta versão.

## Dependências

Babylon.js 9.32.1 está incluído localmente, com licença Apache-2.0. O conector `piratetok-live-js` 0.3.0 tem licença 0BSD e é instalado pelo npm com versões transitivas fixadas em `package-lock.json`. Créditos em `docs/TERCEIROS.md`. O frontend não depende de CDN.
