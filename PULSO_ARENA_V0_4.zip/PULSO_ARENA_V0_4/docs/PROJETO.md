# Atualização atual — Pulso Arena 0.3.0

Câmera desobstruída, novos golpes/efeitos, comemorações e ranking no cenário. Relatório e evidências atuais: ATUALIZACAO_V0_3.md e evidencias/v0_3/. As seções abaixo preservam a arquitetura e o histórico das versões anteriores.

# Pulso Arena 0.2.1

A arquitetura visual abaixo foi preservada da 0.2; correção atual de áudio, evidências e limites em [CORRECAO_PHONK_0_2_1.md](CORRECAO_PHONK_0_2_1.md).

# Pulso Arena 0.2.0 — evolução da arena existente

Esta versão evolui a 0.1.0 preservando os quatro mascotes, regras de rosa, curtidas, fila, ranking, conexão LIVE e formato de progresso schema 1. A implementação foi feita sobre o código existente, após backup e execução dos 24 testes de referência.

## O que mudou

| Pedido | Implementação | Arquivos |
|---|---|---|
| Câmera girando 360° na luta | Órbita contínua, volta padrão em 18 s, ajuste de 12–40 s; aproximação no especial; opção fixa | public/world.js, public/choreo.js, public/app.js |
| Comentários na cabeça de cada usuário | Balões ancorados pela projeção da posição 3D; prioridade para quem comenta; até 6 balões, 140 caracteres e 6,5 s | server/engine.mjs, public/world.js, public/style.css |
| Movimentos de luta melhores | Circulação pelo ringue, passos laterais, base e recuperação; jab, cruzado, uppercut, chute, giro e especial com curvas distintas | public/choreo.js, public/world.js |
| Defesa, esquiva, dança e combos | Defesas automáticas e comandos DEFESA, ESQUIVA, DANÇAR e LUTAR; combo até 3; bloqueio reduz dano e esquiva evita um golpe comum | server/engine.mjs, public/world.js, public/audio.js |
| Festa na batida | Quatro feixes móveis, duas luzes, 16 placas LED, equalizador, anéis de impacto e partículas limitadas | public/world.js |
| Som de outros aplicativos | APK Pulso Batida, pareamento por código temporário, envio local de energia e detector no Node | android/app/, server/rhythm.mjs, server/index.mjs |
| Guia mais visível | Rosa ilustrada, chamada de entrada, vida por curtidas, compartilhamento e três comandos sempre à vista | public/index.html, public/style.css, public/assets/rose.svg |
| Atualização reversível | Validação de hashes, parada da própria instância, ZIP anterior com dados e cópia de código sem reset de progresso | ATUALIZAR.sh, scripts/update.py |

## Arquitetura

```text
TikTok → adaptador LIVE → regras no Node → SSE → Babylon + HUD + balões
Arquivos → player + AudioWorklet → POST de batida → regras + luz + golpes
Apps Android → Visualizer / captura opcional → energia numérica local
                                               ↓
                                  RhythmBridge → regras + SSE
Estado → JSON atômico + .bak; supervisor → servidor com recuperação limitada
```

O servidor continua decidindo dano, HP e resultado. O navegador anima o estado recebido. Os comentários não executam comandos arbitrários: apenas nomes e a lista fixa de ações de jogo são interpretados. Nenhum LLM é necessário para lutar ou sincronizar música.

## Captador Android e limites reais

O modo padrão usa Visualizer na saída global e não inicia MediaProjection. Essa escolha permite tentar acompanhar música de outro aplicativo sem abrir uma nova captura de tela durante uma LIVE. A disponibilidade depende do Android, da rota de áudio e do player. Não é possível garantir sinal do GreenTube/Bluetooth sem testar no Realme GT3.

A alternativa avançada usa AudioPlaybackCapture/MediaProjection, filtra o aplicativo escolhido e pede consentimento próprio. Pode disputar a captura de tela usada pela transmissão; fica desligada por padrão. Não há troca automática para ela. O programa não tenta contornar a política de captura de aplicativos.

O APK envia apenas energia dos graves, nível geral, instante e sequência para 127.0.0.1. Não envia música, voz, PCM ou imagens. O pareamento usa código de seis dígitos, prazo de dois minutos e bloqueio após cinco erros. Um token local aleatório autoriza os quadros; sequências repetidas, dados inválidos e timestamps antigos são recusados. O token não aparece nos snapshots públicos e perde validade ao desconectar/reiniciar.

O envio mantém somente o quadro pendente mais recente; após cinco falhas de conexão o captador para. Quando a ponte externa deixa de produzir batidas, o servidor não inventa novos ataques; o relógio da rodada pausa após a tolerância de 2,5 s. A compensação Bluetooth é ajustável e não foi medida no telefone.

## Defesa e animação

DEFESA vale por 4,5 s para o próximo golpe comum; reduz o dano para aproximadamente 30% do original. ESQUIVA vale 2,5 s e evita um golpe comum. O intervalo entre comandos de pose é 2,5 s por pessoa. Especiais atravessam a defesa comum. DANÇAR dura 12 s e altera os passos sem tirar o mascote da luta. LUTAR encerra essa preferência. Há bloqueios/esquivas automáticas e um bônus de combo pequeno limitado a três ataques.

O movimento é procedural por articulações, com envelope de golpe e deslocamento lateral; não é animação capturada de um estúdio. O perfil Leve mantém o limite de 8 corpos da plateia; Equilibrado 16 e Detalhado 24. Partículas continuam limitadas a 80. As luzes extras são desativadas no perfil Leve. Reduzir movimentos fixa a câmera e suaviza luzes/oscilações.

## Validação e trabalho seguinte

Registros em `docs/evidencias/v0_2/`: 33 testes Node aprovados; navegador com volta completa de 360°, balão visível, defesa, arquivo de 120 BPM medido em 119 BPM e ponte com energia sintética produzindo oito batidas externas. O APK foi compilado, alinhado e assinado, e o filtro Java passou no teste numérico de FFT/graves/agudos/silêncio.

A atualização de uma cópia 0.1 também foi testada: backup criado e progresso mantido. Após SIGKILL no servidor filho da cópia atualizada, o supervisor recuperou o serviço em 2.148 ms, preservando 250 likes, HP 150 e a fila observada.

Essas evidências não são uma captura real do Android, uma LIVE pública nem um benchmark do GT3. Validações pendentes: eventos reais da conta, GreenTube com fone/caixa, ajuste do atraso e sessões de 30/60 min com medição térmica. O supervisor não sobrevive ao Android encerrar todo o aplicativo Termux; esse limite permanece explícito.

O atualizador preserva os dados. Antes de copiar qualquer código, cria um ZIP da instalação anterior em backups/. O README contém os comandos de instalação, atualização e reversão.
