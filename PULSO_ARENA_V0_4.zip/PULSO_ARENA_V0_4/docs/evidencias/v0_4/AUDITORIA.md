# Auditoria antes da alteração — 0.3.0 → 0.4.0

Base recuperada do commit 6b7fc56e1d7ab6588aad9a202b3fd2edd9c6c05c.
Backup integral: /workspace/PULSO_ARENA_V0_3_BASE.zip, sem alterações.
Os 50 testes existentes passaram com acesso HTTP local. O primeiro ensaio no
sandbox falhou apenas na inicialização HTTP; o registro BASELINE.txt contém a
execução completa bem-sucedida.

- server/engine.mjs filtra golpes em max(180ms, 82% do período principal),
  descartando subdivisões de 125ms já aceitas pelo detector. Separar cadência
  visual e dano, com perfil Anime e perfil Clássico preservado.
- public/world.js guarda somente latestAttack. Trocas rápidas cancelam a pose
  de ambos os atores. Usar trilhas por ator e deslocamento limitado ao ringue.
- public/combat-poses.js possui sete golpes individuais; acrescentar sequências,
  ataques alternados, aproximação, teleporte e finalizadores.
- public/combat-fx.js já usa pool finito; expandir com rastros de silhueta e
  cortes, mantendo limites por qualidade e redução de movimento.
- Mascotes procedurais preservam quatro espécies e sementes. Refinar olhos,
  equipamento, silhueta e contornos sem trocar suas identidades.
- Manter detector, protocolo do APK 0.2.1, TikTok, supervisor, atualização e
  formato de progresso. Adicionar regressões de cadência, dano, teleporte,
  persistência, shaders e visibilidade da câmera.

Riscos: custo gráfico de efeitos; descontinuidade no teleporte; câmera cortar
lutadores; dano excessivo em músicas rápidas; incompatibilidade de shader.
Verificação: testes existentes + novas regressões e navegador Chromium. FPS,
temperatura e estabilidade no Realme GT3 exigem teste físico; não serão inferidos
do renderizador de software da nuvem.
