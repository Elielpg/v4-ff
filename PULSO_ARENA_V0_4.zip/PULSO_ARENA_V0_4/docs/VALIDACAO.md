# Validação atual — Pulso Arena 0.4.0

58 testes passaram. O arquivo phonk sintético entregou 64 acentos ao jogo e
gerou 58 ataques (54 rápidos), a 120 BPM. Shaders prontos no Chromium,
teleporte com coordenadas finitas, 36 ângulos de câmera e controle de estilo
verificados. Registros: evidencias/v0_4/; escopo e limites: ATUALIZACAO_V0_4.md.
Essas medições são locais na nuvem e não caracterizam a GPU/áudio do GT3.

# Validação anterior — Pulso Arena 0.3.0

Câmera desobstruída, novos golpes/efeitos, comemorações e ranking no cenário. Relatório e evidências atuais: ATUALIZACAO_V0_3.md e evidencias/v0_3/. As seções abaixo preservam a arquitetura e o histórico das versões anteriores.

# Validação atual — 0.2.1

41 testes Node, comparação A/B de áudio, jogo no navegador e filtros Java aprovados. Consulte CORRECAO_PHONK_0_2_1.md e evidencias/v0_2_1/. Os registros abaixo pertencem à entrega visual anterior.

# Validação 0.2.0

## Evidências

- **33 testes Node passaram**: os 24 anteriores e nove novos de comentários, defesa/esquiva/dança, órbita, trajetória, captura sem batidas artificiais, pareamento, autorização e análise de energia. O teste HTTP também foi ampliado para pareamento, token oculto e revogação.
- **Chromium/SwiftShader**: câmera completou 360° na sessão; balão “Bora lutar e dançar!” ficou visível sobre o dono; cinco defesas observadas; quatro feixes e 16 placas LED presentes. Sem erros JavaScript ou overflow em 540×1080 e 360×800.
- **Arquivo real no player**: fixture de 8 s/120 BPM, AudioWorklet ativo, estimativa de 119 BPM.
- **Ponte externa simulada**: energia numérica periódica enviada à API local, oito batidas externas, andamento 119 BPM. Não é captura de um aplicativo Android.
- **APK**: compilação Android API 35, mínimo Android 10, assinatura verificada. Teste JVM dos filtros passou para FFT, graves, rejeição de agudos e silêncio.

JSONs, log dos testes e manifesto do APK estão em evidencias/v0_2/. Resultados da base anterior ficam em evidencias/v0_1/ e não devem ser confundidos com medições novas.

- **Atualização e recuperação**: cópia temporária da 0.1 foi atualizada para 0.2, com backup criado. Após SIGKILL somente no servidor filho de teste, voltou em 2.148 ms, mantendo 250 likes, HP 150 e o usuário na fila. Não simula Android fechando todo o Termux.

## Conferir no aparelho

1. Atualizar usando ATUALIZAR.sh e conferir que fila, HP e ranking continuam presentes.
2. Em teste local, comentar com dois usuários diferentes e conferir cada balão sobre o mascote correto.
3. Enviar DEFESA, ESQUIVA e DANÇAR; conferir redução/evitação de dano e mudança de pose.
4. Observar a câmera por uma volta e ajustar velocidade ou desligar. Conferir opção de reduzir movimentos.
5. Carregar a música real e comparar batidas, luzes, pés e golpes.
6. Instalar Pulso Batida, parear por código e tocar GreenTube com a saída usada na LIVE. Confirmar energia recebida, andamento e ausência de sinal quando a música parar. Não usar captura compartilhada avançada durante outra captura de tela.
7. Testar os eventos de uma LIVE pública e depois sessões de 30 e 60 minutos, registrando FPS, temperatura, memória, bateria e logs.

Medições de FPS de SwiftShader são da renderização por software no computador, sem equivalência com a GPU do GT3. O limite do Android encerrar todo o Termux não é resolvido por um supervisor interno.
