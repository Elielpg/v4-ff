# Problemas conhecidos e validações pendentes

Estado em 17/11/2026, versão 0.4.0.

| ID | Situação | Impacto / próximo passo |
|---|---|---|
| PULSO-001 | Conector LIVE sem teste com transmissão real | Validar abertura WebSocket, entrada, rosa, comentário, likes e share na conta do usuário. A compatibilidade pode mudar no TikTok. |
| PULSO-002 | Android pode matar todo o Termux | Supervisor cobre o servidor filho. Colher logs e medir segundo plano/bateria/temperatura do GT3; não há recuperação fora de um Termux encerrado. |
| PULSO-003 | Performance e duração no GT3 não medidas | Começar perfil Leve, gravar FPS e logs por 30/60 min. A medição SwiftShader do computador não prevê desempenho no telefone. |
| PULSO-004 | Detector pode errar meia/dobra de batida | Usar BPM/TAP e testar biblioteca real de phonk. Há evidência com batida sintética de 120 BPM, não com todas as músicas. |
| PULSO-005 | Captura Android implementada, ainda sem teste no telefone | APK e ponte incluídos; testar sinal Visualizer em GreenTube/Bluetooth. Arquivo e BPM/TAP continuam disponíveis se a saída não expuser sinal. |
| PULSO-006 | Animação procedural e geometria estilizada | A 0.4 adiciona visual em três faixas, equipamento, combos e teleporte. Ainda não é animação desenhada quadro a quadro ou mocap. Validar poses/transições e nitidez no GT3. |
| PULSO-007 | Apenas parte da plateia é desenhada | Perfis exibem 8/16/24 corpos; registros permanecem no servidor. Fila tem 100 pessoas e cadastro tem limite de 5.000. |
| PULSO-008 | Queda pode perder eventos ainda não salvos/recebidos | Snapshot periódico e backup reduzem perda local; protocolo não garante replay de eventos perdidos do TikTok. |
| PULSO-009 | Fila ainda não mostra todos os nomes no HUD | Há contagem e avisos locais. Evoluir painel para próximo desafiante, fila cheia e recuperação após derrota. |
| PULSO-010 | Boas-vindas sem narração falada | Texto e ding implementados. Narrador é opcional futuro e não participa do motor de luta. |

## Falhas encontradas e corrigidas durante a implementação

- Sombras tentavam usar TransformNode como Mesh: corrigido para registrar somente meshes compatíveis; teste visual com sombras passou.
- Plateia ficava fora do enquadramento: posições ajustadas para trás do ringue.
- Demonstração mostrava corpos iguais: personagens de teste agora usam bases e cores diferentes, com reconstrução do ator quando o tipo muda.
- Torcida por @ perdia o prefixo durante a interpretação: menções agora são reconhecidas antes de comparar nomes.
- Batidas estimadas podiam cessar após interrupção no detector: o relógio da última batida externa foi separado do relógio geral.
- Arquivo corrompido podia substituir um backup bom: a gravação identifica recuperação e preserva a cópia anterior.
- Conexão antiga da LIVE podia terminar depois de outra conexão: geração e cancelamento impedem substituição da sessão atual.
- Batidas enviadas pelo player podiam acionar combate mesmo com a LIVE desconectada: rota de batida agora exige conexão ativa no modo LIVE; regressão HTTP passou.

## Limites adicionais da 0.2

- A captura compartilhada avançada pode interromper outra captura de tela; manter desligada durante esse tipo de LIVE.
- Balões têm teto de seis, duração de 6,5 s e podem ficar fora do enquadramento enquanto a câmera gira.
- Visualizer global pode perceber sons do próprio jogo. Se interferirem no ritmo, reduzir efeitos ou usar arquivo local.
- O código de pareamento expira em dois minutos. Ao reiniciar o servidor, parear o APK novamente.

## Ajuste 0.2.1 de áudio

Os limites fixos que descartavam subdivisões foram corrigidos e testados. A análise por duas faixas melhora ataques fracos, mas a taxa de acerto em músicas arbitrárias não foi medida. Contagem de referência e resultados sintéticos estão no relatório da correção. BPM pode ser ambíguo entre metade e dobro; TAP/BPM manual continuam disponíveis.

## Versão 0.3 — limites visuais

O painel que bloqueava o ringue foi corrigido. Foram testados 36 ângulos e 216 linhas de visão contra estruturas do cenário. Os lutadores ainda podem se sobrepor naturalmente em alguns enquadramentos; a proteção não torna outros personagens transparentes. Placar e estruturas ficam translúcidos quando passam na frente da luta. O perfil Leve reduz nitidez e efeitos para poupar renderização. FPS e temperatura no GT3 continuam sem medição.
