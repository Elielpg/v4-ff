"""Loopback-only Piper bridge. The model is loaded once; no network or API keys."""
import argparse
import io
import json
import re
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from voice_jobs import VoiceJobs, VoiceBusy


def make_server(voice, port=8082, model_name="pt_BR-faber-medium", syn_config=None, preview_path=None, cache_dir=None, namespace=""):
    def synthesize(text):
        output = io.BytesIO()
        with wave.open(output, "wb") as wav_file:
            if syn_config is None:
                voice.synthesize_wav(text, wav_file)
            else:
                voice.synthesize_wav(text, wav_file, syn_config=syn_config)
        return output.getvalue()
    jobs = VoiceJobs(synthesize, model_name, namespace=namespace, cache_dir=cache_dir)
    preview = None
    if preview_path:
        try:
            data = Path(preview_path).read_bytes()
            if not 44 <= len(data) <= 4 * 1024 * 1024:
                raise ValueError("Preview inválido")
            with wave.open(io.BytesIO(data)) as wav:
                if wav.getnframes() < 1:
                    raise ValueError("Preview vazio")
            preview = data
        except (OSError, ValueError, EOFError, wave.Error):
            pass

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, fmt, *args):
            return

        def reply(self, status, body, content_type="application/json"):
            if isinstance(body, dict):
                body = json.dumps(body, ensure_ascii=False).encode()
            try:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("X-Ben10-Voice", model_name)
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass  # Finished jobs remain cached when a client disconnects.

        def allowed(self):
            expected = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
            return self.headers.get("Host") in expected and not self.headers.get("Origin")

        def do_GET(self):
            if not self.allowed():
                return self.reply(403, {"error": "Acesso local apenas"})
            if self.path == "/preview":
                return self.reply(200, preview, "audio/wav") if preview else self.reply(404, {"error": "Teste salvo indisponível"})
            match = re.fullmatch(r"/jobs/([a-f0-9]{64})(/audio)?", self.path)
            if match:
                try:
                    return self.reply(200, jobs.audio(match[1]), "audio/wav") if match[2] else self.reply(200, jobs.status(match[1]))
                except KeyError:
                    return self.reply(404, {"error": "Fala não encontrada"})
                except VoiceBusy:
                    return self.reply(409, {"error": "Fala em geração"})
            if self.path != "/health":
                return self.reply(404, {"error": "Rota inexistente"})
            self.reply(200, {"ready": True, "provider": "qwen3-clone" if model_name.startswith("Qwen3-TTS-") else "piper", "model": model_name, "previewReady": preview is not None, **jobs.health()})

        def do_POST(self):
            if not self.allowed():
                return self.reply(403, {"error": "Acesso local apenas"})
            if self.path not in ("/synthesize", "/jobs"):
                return self.reply(404, {"error": "Rota inexistente"})
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 1 <= size <= 8192 or self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                    raise ValueError()
                payload = json.loads(self.rfile.read(size))
                text = payload.get("text")
                if not isinstance(text, str) or not text.strip() or len(text) > 1000:
                    raise ValueError()
            except (ValueError, TypeError, AttributeError):
                return self.reply(400, {"error": "Fala inválida"})
            try:
                job = jobs.start(text)
            except VoiceBusy:
                return self.reply(409, {"error": "Voz ocupada; aguarde a fala atual"})
            if self.path == "/jobs":
                return self.reply(202, job)
            try:
                self.reply(200, jobs.wait(job["id"]), "audio/wav")
            except VoiceBusy:
                self.reply(500, {"error": "Falha na síntese local. Confira logs/voz.log."})

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--port", type=int, default=8082)
    parser.add_argument("--cache-dir", type=Path)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Porta inválida")
    import onnxruntime
    from piper import PiperVoice, SynthesisConfig
    from piper.config import PiperConfig

    model = Path(args.model)
    config = json.loads(Path(str(model) + ".json").read_text())
    if config.get("phoneme_type", "espeak") != "espeak" or config.get("espeak", {}).get("voice", "").lower() != "pt-br":
        raise ValueError("Use o modelo Piper pt_BR instalado pelo projeto")
    options = onnxruntime.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    voice = PiperVoice(config=PiperConfig.from_dict(config), session=onnxruntime.InferenceSession(str(model), sess_options=options, providers=["CPUExecutionProvider"]))
    server = make_server(voice, args.port, model_name=model.stem, syn_config=SynthesisConfig(length_scale=1.0), cache_dir=args.cache_dir, namespace=str(model.stat().st_mtime_ns))
    print(f"Piper pronto em 127.0.0.1:{args.port}", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
