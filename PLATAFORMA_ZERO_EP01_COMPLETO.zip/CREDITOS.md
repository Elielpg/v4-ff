# Plataforma Zero — Episódio 1 de 9

Animação original de suspense e ficção, criada para este projeto. A estação técnica, o trem, Lia, Davi e a máquina Trio foram construídos como modelos volumétricos 3D e animados com rigs procedurais. Renderização com Babylon.js em Chromium, edição e codificação com FFmpeg.

O vídeo de referência enviado pelo usuário orientou o formato: suspense em terceira pessoa, ação visual, cortes e legendas amarelas curtas. Nenhuma imagem, modelo, trilha ou voz desse vídeo foi reaproveitada.

Narração: voz sintética padrão Kokoro `pm_alex`, português brasileiro. Não é clonagem nem imitação de um ator. Música de suspense e efeitos de trem, mecanismos, passos e impactos sintetizados para este episódio. Fonte Barlow Condensed sob SIL Open Font License; licença incluída. DejaVu: licença incluída.

Entrega: episódio 1 com 77,23 segundos, 1080 × 1920, 30 fps, H.264, AAC estéreo. Legendas já aparecem no vídeo; o SRT separado é opcional e não precisa ser aplicado novamente.

Esta entrega contém um episódio de demonstração. Os episódios 2 a 9 têm roteiro, mas seus vídeos ainda não foram produzidos. Não foi feita postagem em rede social nem medição de alcance. Os modelos são estilizados e procedurais; não há captura de movimento nem sincronização labial por fonemas.
