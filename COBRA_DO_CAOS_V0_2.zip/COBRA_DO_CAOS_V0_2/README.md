# Cobra do Caos · Gaiola 3D · V0.2.0

Evolução da Cobra do Caos para LIVE no Termux: câmera 3D automática, gaiola de espectadores, três missões de fuga, banquete de 50 avatares no centro, compartilhamento com cor animada, playlist de várias músicas e ciclo de dia/noite. O piloto, presentes, ranking, voz local, estúdio RTMP e reparo de APT da versão anterior continuam disponíveis.

## Atualizar sua pasta atual e preservar progresso

Baixe `COBRA_DO_CAOS_V0_2.zip` em Downloads. Termine sua transmissão antes de atualizar. O atualizador encerra somente o jogo da pasta indicada, confere o manifesto e faz backup de código e estados antes de copiar os arquivos novos.

```bash
cd ~/COBRA_DO_CAOS_V0_1 &&
python3 -m zipfile -e ~/storage/downloads/COBRA_DO_CAOS_V0_2.zip "$TMPDIR/cobra-v02" &&
bash "$TMPDIR/cobra-v02/COBRA_DO_CAOS_V0_2/ATUALIZAR_V0_2.sh" "$PWD" &&
bash install.sh &&
bash start.sh
```

**A pasta continua sendo `~/COBRA_DO_CAOS_V0_1`, com o jogo na V0.2.0.** Abra **http://127.0.0.1:3500/?v=0.2.0** e confira V0.2.0 no topo.

Para iniciar nas próximas vezes:

```bash
cd ~/COBRA_DO_CAOS_V0_1 && bash start.sh
```

O progresso, ranking, configurações de IA, `.env`, cache privado e modelos existentes são preservados. O instalador continua usando somente a fonte principal configurada do Termux, com assinaturas exigidas. Se o FFmpeg estiver pendente, o jogo abre e o estúdio RTMP informa essa pendência. Para instalar apenas ele: `bash scripts/termux-packages.sh ffmpeg`.

## Instalação nova

Com Python disponível e o ZIP em Downloads:

```bash
cd ~ &&
python3 -m zipfile -e ~/storage/downloads/COBRA_DO_CAOS_V0_2.zip . &&
cd ~/COBRA_DO_CAOS_V0_2 &&
bash install.sh &&
bash start.sh
```

Use Node 22.19 ou mais recente. Pare outra instalação que esteja usando a porta 3500 antes de iniciar essa cópia. A primeira instalação das dependências usa internet; imagens locais, falas prontas e trilha incluída funcionam sem CDN, chave ou modelo de IA.

## Gaiola e missões

Cada espectador identificado é cadastrado na gaiola quando chega à LIVE. Se o evento de entrada não vier, a primeira interação identificada também cria esse cadastro. Entradas repetidas da mesma pessoa não ocupam duas vagas.

Antes de completar **50 presos**, o espectador pode cumprir **qualquer uma** destas missões:

| Missão | O que conta |
|---|---|
| **500 curtidas próprias** | Deltas de curtidas identificados com o usuário, desde a entrada na gaiola |
| **1 rosa** | A primeira rosa confirmada já abre a porta, inclusive durante um combo |
| **10 comentários** | Comentários não vazios desde a entrada; o mesmo texto pode ser enviado novamente, mas o mesmo ID de evento não é contado duas vezes |

As três missões são alternativas completas, sem somar partes de uma com outra. **Comente STATUS** para destacar seus contadores na tela. A câmera mostra a gaiola, a porta abre e o avatar de quem escapou vai para o lado livre. O fugitivo fica protegido de nova captura nesta sessão, inclusive ao reconectar ou reiniciar o servidor. Os registros visuais são limitados a 1.500 perfis e a proteção de fuga mantém até 50 mil marcas de identificação por sessão.

Ao atingir **50 pessoas ainda presas**, os avatares saem da gaiola, se transformam em comida e caem no meio do tabuleiro. A gaiola fica disponível para os próximos espectadores. O banquete só pode ser consumido depois da queda; quando a cabeça da cobra passa pelo centro, ele gera créditos de crescimento com os donos correspondentes. Esses créditos continuam nas rodadas seguintes até serem usados.

A fuga precisa ocorrer **antes** de o banquete daquele grupo ser disparado. O avatar já despachado como comida não volta à gaiola ao enviar uma missão depois. Isso não impede a pessoa de comentar, ajudar ou sabotar o jogo.

O número da gaiola representa avatares cadastrados no jogo; não é o número de pessoas simultaneamente assistindo no TikTok. A disponibilidade dos eventos de entrada e da identificação nas curtidas depende do conector. Curtidas sem usuário alimentam o total coletivo, sem serem atribuídas a uma pessoa. O operador pode conferir isso em **LIVE → Gaiola e missões individuais**.

## Compartilhar, presentes e regras anteriores

**Compartilhar muda a cor da cobra e faz sua aura pulsar por nove segundos. Não liberta da gaiola.** Mantém o bônus de comida e o intervalo individual de 20 segundos da versão anterior.

| Interação | Efeito do jogo |
|---|---|
| HERÓI no chat | 1 comida grátis a cada 6,5 s por pessoa |
| VILÃO no chat | 1 bomba grátis a cada 11 s por pessoa |
| 20 curtidas coletivas | 1 comida |
| 100 curtidas coletivas | 1 carga de escudo |
| Seguir pela primeira vez reconhecida | 3 comidas |
| Compartilhar | 2 comidas e efeito de cor |
| Rosa | Fuga, se ainda estiver preso; também mantém 1 bomba |
| GG | 3 comidas |
| Heart Me | 3 cargas de escudo |
| Galáxia | Limpa as bombas e agenda crescimento de 8 segmentos |
| Confete | 8 bombas |
| Leão | Mordida de 8 segmentos, limitada a 12 por evento agrupado |

A cobra tenta preencher 216 casas. Com três segmentos após dano, a rodada termina em queda; há revanche automática. O piloto evita paredes e o próprio corpo, sem evitar as bombas. Presentes e missões não garantem resultados monetários. As imagens e nomes dos presentes podem variar por região; valide os eventos reais da conta antes da transmissão.

## Câmera, luz e som

O botão **CINEMA** alterna entre percurso automático, acompanhamento da cobra, visão do tabuleiro inteiro e foco na gaiola. A câmera faz transições suaves e reage a entradas, fugas e banquetes. O menu LIVE oferece os mesmos controles e a opção de reduzir movimento/luzes.

O botão de período alterna entre **automático, dia fixo e noite fixa**. O ciclo automático dura oito minutos e muda o céu e a iluminação gradualmente. O efeito de compartilhamento colore o material da cobra; com movimento reduzido, o brilho deixa de pulsar e a câmera fica na visão geral.

Em **Música**, selecione vários arquivos de uma vez. Até 32 faixas ficam na playlist local. A ordem aleatória usa todas as faixas antes de refazer o ciclo, evitando repetir imediatamente a última música. Há seleção manual, remoção e botão Próxima. Com uma faixa, ela se repete; sem arquivos pessoais, toca a trilha original incluída.

Os arquivos selecionados ficam no navegador do aparelho; selecione-os novamente ao recarregar a página. A cobra continua mesmo com música e voz pausadas. O captador Android Pulso Batida continua disponível para batidas de outro aplicativo, quando o Android/app permitem captura. O captador envia características das batidas, sem encaminhar a música para o RTMP; para transmitir música, carregue o arquivo no painel.

## LIVE, RTMP e IA local

A conexão do chat e o envio de vídeo são separados. Inicie o RTMP em **Transmitir** ou use seu aplicativo habitual; depois conecte o @ ao vivo na aba LIVE e aguarde a confirmação de eventos. A demonstração é identificada como fictícia e seus participantes, ranking, gaiola e missões ficam separados da LIVE. Botões de simulação são recusados no servidor em modo LIVE.

O estúdio RTMP inclui a cena 3D, contagem da gaiola, missões, presentes, legendas, música, efeitos e voz. Sua conta precisa ter endereço RTMP e chave liberados pela plataforma. Preencha a chave somente no painel local; ela não vai para o vídeo, backup de configuração ou logs. Mantenha o Chrome visível durante o envio. Uma amostra WEBM de dez segundos pode ser gravada sem chave.

Há perfis de saída 540p/24 FPS, 720p/30 FPS e 1080p/30 FPS. A renderização usa limite de 24 FPS no perfil Leve e 30 nos demais, sem prometer que o aparelho alcance esses valores. Bitrate, rede e hardware determinam o resultado; há recodificação de vídeo. O teste RTMP desta entrega foi para um receptor local, sem publicar LIVE real no TikTok.

Inclui 16 falas neurais PT-BR prontas, com explicações das novas regras. Para perguntas livres, reaproveite seu Qwen/Piper existente em outra sessão do Termux:

```bash
cd ~/COBRA_DO_CAOS_V0_1 && bash ia-local.sh
```

Em instalação nova, use a pasta V0_2. O comando reaproveita a instalação anterior de IA sem baixar modelos ou ativar o clonador. A identidade da conversa é Zig; `ben-classico-local` é apenas o alias técnico do servidor anterior. A IA não controla o piloto nem executa comandos do sistema.

## Backup, reversão e estabilidade

O atualizador mostra o backup em `data/update-backups/v0.2.0-*`. Para reverter, encerre a transmissão e execute **o `REVERTER.sh` daquele backup**. Ele restaura o código e os estados do instante anterior à atualização; o progresso obtido depois será substituído. `.env`, modelos externos e arquivos do operador fora do manifesto ficam preservados.

O supervisor recupera falhas do servidor no máximo quatro vezes em 15 minutos. Logs em `logs/`. Isso não recupera o encerramento de todo o Termux pelo Android. No GT3, mantenha as permissões de segundo plano e confira bateria/temperatura em uma sessão real. A retomada do servidor preserva gaiola e missões salvas, mas a conexão TikTok e o RTMP precisam ser conferidos/reabertos manualmente.

## Arquitetura e validação

`server/cage.mjs` cuida de missões, imunidade, grupos de comida e créditos persistentes. `server/identity.mjs` concilia IDs e @. `public/cinematic-world.js` e `cage-stage.js` criam câmera, cena e avatares. `public/playlist.js` cuida das faixas. O piloto, integração e estúdio anteriores continuam nos módulos existentes.

Babylon.js foi mantido para aproveitar o WebGL e a captura do jogo no navegador/Termux. Uma migração para Godot exigiria exportação Web ou APK e adaptação do caminho de transmissão, sem necessidade para estas funções.

Execute `npm test`. Evidências em `docs/`: testes, simulação acelerada, navegador, avatares e RTMP. A simulação não equivale a duas horas reais no Android. Os testes da integração TikTok, foto real do perfil, latência de IA e duração no GT3 continuam pendentes no aparelho. Limites e detalhes técnicos em [docs/ARQUITETURA_V0_2.md](docs/ARQUITETURA_V0_2.md).
