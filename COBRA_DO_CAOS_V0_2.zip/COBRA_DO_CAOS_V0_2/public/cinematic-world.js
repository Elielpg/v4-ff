import {SnakeWorld} from './world.js';
import {CageStage} from './cage-stage.js';
const B=window.BABYLON;
export class CinematicWorld extends SnakeWorld{
 constructor(canvas,labels){super(canvas,labels);this.camera.dispose();this.camera=new B.ArcRotateCamera('camera-cinema',Math.PI/2,.5,33,new B.Vector3(0,.45,-3.05),this.scene);this.camera.fov=.82;this.camera.minZ=.15;this.camera.maxZ=120;this.scene.activeCamera=this.camera;this.cameraMode=localStorage.getItem('cobra-camera')||'cinematic';this.dayMode=localStorage.getItem('cobra-day')||'auto';this.directorAt=performance.now();this.focusUntil=0;this.focusKind=null;this.cageStage=new CageStage(this);this.setCameraMode(this.cameraMode);this.resize();}
 setQuality(q){super.setQuality(q);this.engine.maxFPS=this.quality==='low'?24:30;}
 setCameraMode(mode){this.cameraMode=['cinematic','follow','overview','cage'].includes(mode)?mode:'cinematic';localStorage.setItem('cobra-camera',this.cameraMode);}
 setDayMode(mode){this.dayMode=['auto','day','night'].includes(mode)?mode:'auto';localStorage.setItem('cobra-day',this.dayMode);}
 update(s){super.update(s);this.stateAt=performance.now();this.cageStage?.update(s);}
 action(a){super.action(a);this.cageStage?.action(a);const now=performance.now();if(a.kind==='cageStatus'){this.focusKind='cage';this.focusUntil=now+4500;}else if(a.kind==='cageBanquet'){this.focusKind='banquet';this.focusUntil=now+5200;}else if(a.kind==='cageEscape'){this.focusKind='cage';this.focusUntil=now+3000;}else if(a.kind==='cageEnter'&&(this.lastCageFocus===undefined||now-this.lastCageFocus>12000)){this.lastCageFocus=now;this.focusKind='cage';this.focusUntil=now+2200;}else if(a.kind==='banquetEat'){this.focusKind='banquet';this.focusUntil=now+2000;}}
 frame(dt,now){super.frame(dt,now);if(!this.cageStage||!this.state)return;const clock=this.state.serverTime+Math.max(0,now-(this.stateAt||now)),elapsed=(now-this.directorAt)/1000;let mode=this.cameraMode;if(this.reduceMotion)mode='overview';if(this.cameraMode==='cinematic'&&!this.reduceMotion){if(now<this.focusUntil)mode=this.focusKind;else{const phase=elapsed%32;mode=phase<10?'orbit':phase<23?'follow':this.state.cage?.count?'cage':'orbit';}}
  let alpha=mode==='overview'?Math.PI/2:Math.PI/2+elapsed*.075,beta=.5,target=new B.Vector3(0,.45,-3.05),radius=33;
  if(mode==='orbit'){const ratio=this.canvas.clientWidth/Math.max(1,this.canvas.clientHeight),width=17*Math.abs(Math.sin(alpha))+25*Math.abs(Math.cos(alpha));radius=Math.max(32,width/(2*Math.tan(this.camera.fov/2)*ratio)*1.1);beta=.46+.07*Math.sin(elapsed*.15);}
  else if(mode==='follow'){const head=this.display[0]||B.Vector3.Zero();target=new B.Vector3(Math.max(-3,Math.min(3,head.x)),.2,Math.max(-6,Math.min(6,head.z)));radius=18.5;beta=.62;}
  else if(mode==='cage'){target=new B.Vector3(0,1,-12.5);radius=16;beta=.76;alpha=Math.PI/2+Math.sin(elapsed*.14)*.55;}
  else if(mode==='banquet'){target=new B.Vector3(0,1,-1);radius=23;beta=.65;}
  const f=1-Math.exp(-dt*1.4);this.camera.target.copyFrom(B.Vector3.Lerp(this.camera.target,target,f));this.camera.alpha+=Math.atan2(Math.sin(alpha-this.camera.alpha),Math.cos(alpha-this.camera.alpha))*f;this.camera.beta+=(beta-this.camera.beta)*f;this.camera.radius+=(radius-this.camera.radius)*f;this.cageStage.frame(dt,now,clock,mode);this.cinematicState={mode,day:this.cageStage.dayLabel,daylight:this.cageStage.daylight,alpha:this.camera.alpha,radius:this.camera.radius};
 }
}
