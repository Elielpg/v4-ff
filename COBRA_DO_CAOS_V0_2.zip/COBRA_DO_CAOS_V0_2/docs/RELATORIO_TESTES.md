# Registro de validação · V0.2.0

Testes executados em Linux Cloud e Chromium com WebGL por software em 22/11/2026. Os resultados abaixo não são medições do Realme GT3 nem uma transmissão pública no TikTok.

## Lógica, integração e regressão

**51 testes aprovados, sem falhas** em `npm test`, incluindo os testes anteriores. Saída completa: `unit-tests.log`.

- Piloto, colisão/crescimento da cauda, recargas, bombas, escudo, presentes no intervalo entre rodadas, contagem/deduplicação, recuperação de JSON, memória/contexto social e fila ordenada de vídeo.
- Gaiola: 49 → 50 pessoas; cada uma das três fugas; missão da quinquagésima pessoa processada antes do banquete; primeira rosa durante combo; curtidas anônimas; comentários repetidos com IDs diferentes; compartilhamento sem fuga; aliases de ID numérico/@; persistência de missões e comida entre reinícios/rodadas; perfis e imunidade limitados; ciclo de iluminação.
- Playlist: ordem aleatória sem repetição imediata entre ciclos, ordem sequencial, seleção de arquivos e limites.
- Instalador Termux: fonte Deb822 informada, isolamento do APT, conservação das fontes/listas e Signed-By, recusa de assinatura inválida e jogo disponível quando apenas o FFmpeg está pendente. APT simulado, sem comprovar instalação no telefone.
- Atualizador: validação antes de alterar arquivos, backup, preservação do estado/configuração e reversão de código/estado.
- Supervisor: recuperação com limite, sem reinício infinito. Uma queda de voz não deve interromper a lógica do jogo.

## Navegador, avatares e música

`CAGE_BROWSER_CHECK.json`: sessão com as três fugas, porta e avatar livre, compartilhamento colorindo a cobra, queda de 50 avatares e pilha de comida no centro. O consumo deixou 49 créditos após o primeiro segmento e aumentou o corpo. Foram verificadas transições da câmera, iluminação de dia/noite, execução contínua, duas faixas alternando automaticamente e ausência de overflow horizontal em 360 × 800. Os três endpoints de simulação recusaram uso no modo LIVE (403); a LIVE permaneceu separada da demonstração. Não ocorreram erros JavaScript nem falhas de recursos nesse teste.

`AVATAR_CHECK.json`: foto recebida depois do cadastro atualizou o mesmo slot do atlas, sem duplicar pessoa. Pixels e captura do canvas foram conferidos. A imagem era uma referência sintética com CORS permitido; fotos reais do TikTok podem exigir fallback para iniciais. O limitador de renderização foi consultado em 30 FPS, sem afirmar que a GPU alcance esse valor.

Imagens reais da execução: `PREVIA_INICIO.png`, `PREVIA_GAIOLA_DIA.png`, `PREVIA_GAIOLA_NOITE.png`, `PREVIA_FUGA.png`, `PREVIA_COMPARTILHAR.png`, `PREVIA_QUEDA.png`, `PREVIA_BANQUETE.png`, `PREVIA_PLAYLIST.png`, `PREVIA_CELULAR.png` e `PREVIA_CONTROLES.png`.

## Áudio e transmissão

**16 falas Piper PT-BR** geradas e verificadas quanto a cabeçalho WAV, duração e sinal não silencioso: `AUDIO_CHECK.json`. A normalização/voz local anterior foi preservada. Não há clonagem de voz de personagem. A evidência herdada de resposta controlada → Piper real → reprodução com legenda está identificada como `BASE_V0_1_VOICE_FLOW.json`; não é uma nova avaliação do Qwen.

`STUDIO_CHECK.json`: transmissão real para receptor RTMP local, com **H.264 720 × 1280, AAC, 9,294 s recebidos**, 3.264.533 bytes e áudio RMS **−20,917 dBFS**. A saída informou 30/1 FPS; isso não mede quadros únicos da renderização por software. Confirmados progresso de quadros, indicador TRANSMITINDO, encerramento do codificador com jogo continuando e amostra WEBM de dez segundos. A gaiola estava ativa durante a captura. A chave de teste permaneceu ausente do estado público. Quadro do vídeo recebido: `PREVIA_TRANSMISSAO.png`.

## Simulação acelerada

`SOAK_ENGINE.json`: **7.200 segundos simulados**, 110 rodadas iniciadas, 105 vitórias e quatro derrotas, 37.017 ações, 54 banquetes e 479 fugas. Restava uma rodada em andamento. Os registros ficaram em 1.500 perfis e 1.500 missões, com deduplicação limitada a 3.000 entradas. Execução em **18,085 s**; RSS de 32.579.584 para 82.251.776 bytes. É teste da lógica Node acelerada, sem GPU/IA/RTMP concorrentes; não equivale a duas horas reais de LIVE no Android.

## Pacote, atualização e reversão

O teste do ZIP extraído é separado para poder vincular o resultado ao SHA-256 exato do arquivo: **`COBRA_DO_CAOS_V0_2_RELEASE_CHECK.json`**, ao lado do download. O verificador reproduz instalação nova, atualização de uma V0.1 ativa, conservação de outra instalação, migração de progresso/configuração, falha forçada do servidor e restauração por `REVERTER.sh`. Não se deve considerar esse teste concluído sem o relatório com `ok: true` e hash correspondente ao ZIP baixado.

## Pendências no aparelho

Conexão real ao TikTok, identificação de curtidas por pessoa, imagens de perfil com CORS real, catálogo regional de presentes, RTMP para a conta, latência de Qwen/Piper e sessão prolongada com temperatura/rede móvel continuam pendentes no GT3. O supervisor não recupera o encerramento de todo o aplicativo Termux pelo Android. Não foi atribuído a esse problema um motivo sem logs do aparelho.
