import {readFile,readdir,realpath,stat} from 'node:fs/promises';
import path from 'node:path';
import {nodeServerEntry} from '../phone-update.js';
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const canonical=async value=>realpath(value).catch(()=>path.resolve(value));

async function processInfo(pid){
 if(!Number.isInteger(pid)||pid<2)return null;
 try{
  const root='/proc/'+pid,owner=await stat(root);
  if(process.getuid&&owner.uid!==process.getuid())return null;
  const raw=await readFile(root+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).trim().split(/\s+/);
  return {pid,parent:Number(fields[1]),start:fields[19],cwd:await realpath(root+'/cwd'),exe:await realpath(root+'/exe'),argv:(await readFile(root+'/cmdline')).toString().split('\0').filter(Boolean)};
 }catch{return null;}
}
export async function protectedPids(){
 const protectedSet=new Set();let pid=process.pid;
 for(let i=0;i<80&&pid>1&&!protectedSet.has(pid);i++){protectedSet.add(pid);const info=await processInfo(pid);if(!info)break;pid=info.parent;}
 return protectedSet;
}
export async function projectProcesses(gameRoot,localRoot,{exclude=new Set([process.pid]),textPort=8081}={}){
 gameRoot=await canonical(gameRoot);localRoot=await canonical(localRoot);
 const result=[],names=await readdir('/proc').catch(()=>[]);
 for(const name of names){
  if(!/^\d+$/.test(name)||exclude.has(Number(name)))continue;
  const info=await processInfo(Number(name));if(!info||info.cwd!==gameRoot)continue;
  let kind=null;
  const entry=nodeServerEntry(info.argv,info.cwd),resolved=entry?await canonical(entry):null;
  if(resolved===path.join(gameRoot,'server/index.js'))kind='jogo';
  else if(['scripts/local-ai/run.js','scripts/start-game.js'].some(file=>resolved===path.join(gameRoot,file)))kind='inicializador';
  else if(/^python(?:\d+(?:\.\d+)?)?$/.test(path.basename(info.argv[0]||''))&&info.argv[1]&&!info.argv.includes('--preview')){
   const rootIndex=info.argv.indexOf('--root');
   if(await canonical(path.resolve(info.cwd,info.argv[1]))===path.join(gameRoot,'scripts/local-ai/clone_voice.py')&&rootIndex>=0&&info.argv[rootIndex+1]&&await canonical(info.argv[rootIndex+1])===localRoot)kind='voz';
  }else if(info.exe===await canonical(path.join(localRoot,'llama.cpp/build/bin/llama-server'))){
   const portIndex=info.argv.indexOf('--port'),hostIndex=info.argv.indexOf('--host');
   if(info.argv[portIndex+1]===String(textPort)&&info.argv[hostIndex+1]==='127.0.0.1')kind='conversa';
  }
  if(kind)result.push({...info,kind});
 }
 return result;
}
export async function stopProject(gameRoot,localRoot,{textPort=8081,timeoutMs=20000,onStop=()=>{}}={}){
 const exclude=await protectedPids(),stopped=new Set(),until=Date.now()+timeoutMs;
 while(Date.now()<until){
  const matches=await projectProcesses(gameRoot,localRoot,{exclude,textPort});
  if(!matches.length)return [...stopped];
  matches.sort((a,b)=>Number(b.kind==='inicializador')-Number(a.kind==='inicializador'));
  for(const item of matches){
   const key=item.pid+':'+item.start;if(stopped.has(key))continue;
   const fresh=await processInfo(item.pid);
   if(!fresh||fresh.start!==item.start)continue;
   try{process.kill(item.pid,'SIGTERM');stopped.add(key);onStop(item.kind,item.pid);}catch(error){if(error.code!=='ESRCH')throw error;}
  }
  await pause(150);
 }
 throw Error('Um processo desta instalação não encerrou. Pare a sessão original com Ctrl+C. Nenhum processo externo foi encerrado.');
}
