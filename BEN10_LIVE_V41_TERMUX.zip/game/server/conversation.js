import {localGoalReply} from './chat-goals.js';
import {gemini,localReply} from './core.js';
import {identityQuestion,localPersonaReply} from './personas.js';
import {addressBenReply} from '../public/ben-dialogue.js';
import {replyReaction} from '../public/ben-behavior.js';
// Text generation and voice are independent. Never silently call local dialogue Gemini.
export async function answerComment(item,{key,keyLabel=null,model,context={},generate=gemini}={}){
 const speaker=item.speaker||context.form||'base';let warning='Cadastre e selecione uma chave Gemini para conversar com IA.',code='missing_key';
 if(key)try{const answer=await generate(item.prompt,{key,model,context:{...context,speaker}});const text=addressBenReply(answer.text,item.user);return {...answer,text,speaker,mode:'gemini',keyLabel,reaction:replyReaction(text,item.prompt)};}catch(e){warning=e.message;code=e.code||'provider_error';}
 let basic=localReply(item.prompt);if(key&&basic.startsWith('Essa aí eu ainda não sei! Meu comunicador está sem conexão.'))basic='Meu comunicador engasgou nessa! Repete a pergunta daqui a pouquinho?';
 const text=addressBenReply(identityQuestion(item.prompt,speaker)||localGoalReply(item.prompt,context.chatGoals)||localPersonaReply(item.prompt,speaker,basic),item.user);return {text,speaker,mode:'local',warning,code,keyLabel,keyConfigured:!!key,reaction:replyReaction(text,item.prompt)};
}
