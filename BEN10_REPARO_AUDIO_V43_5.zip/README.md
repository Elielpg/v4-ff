# Ben 10 · Clareira LIVE · V43.5

Corrige a inicialização quando arquivos novos convivem com Node/Python antigos ainda em execução. A versão da página não garante que o servidor tenha sido reiniciado.

A falha foi reproduzida com a interface V43.4 e o servidor V43.3: a página carregava, mas POST /api/tts-jobs retornava 404. A falha de voz segura a fila e pode impedir as respostas seguintes. Os reparos anteriores copiavam arquivos sem reiniciar necessariamente todos os processos; o inicializador aceitava reutilizar um servidor da mesma pasta sem conferir sua versão.

O novo início compara versões de interface, servidor e worker de voz. Quando necessário, encerra somente processos confirmados desta instalação pelo UID, pasta, entrada do programa e identidade em /proc, então inicia os serviços novos. Não usa pkill nem encerramento forçado. Uma porta ocupada por processo externo bloqueia o reinício, preservando esse processo. Uma sessão já saudável é reutilizada.

A interface exibe um aviso persistente quando o servidor estiver em outra versão e não tenta enviar falas a uma API incompatível. Copiar diagnóstico de voz agora mostra versões da interface, servidor e worker, estado da fila e conexão da LIVE, sem chaves.

## Aplicar

Em outra sessão do Termux, mantendo os arquivos no diretório habitual:

```bash
cd ~/ben10-v34/game &&
python3 -m zipfile -e ~/storage/downloads/BEN10_REPARO_AUDIO_V43_5.zip "$TMPDIR/ben10-audio-43-5" &&
bash "$TMPDIR/ben10-audio-43-5/REPARAR_AUDIO_V43_5.sh" &&
bash restart.sh
```

Abra http://127.0.0.1:3000/?v=43.5.0 e toque em Entrar ou ♫. O reinício é feito pelo script, sem exigir que o usuário descubra em qual sessão ficou cada processo. Não recompila nem baixa modelos. Preserva referência, GGUF/ONNX, chaves, .env, progresso e fontes APT. Guarda arquivos substituídos em data/installer-backups.

`bash local-ai.sh start` agora usa a mesma verificação. `bash restart.sh` solicita reinício dos processos confirmados; deixe essa sessão aberta após a inicialização.

## Verificação real da voz

Além dos testes de tarefas e navegador, foi carregado o modelo oficial Qwen/Qwen3-TTS-12Hz-0.6B-Base com a amostra fornecida pelo usuário. O C API nativo gerou a frase de teste “Oi, Ana!” pelo worker HTTP. O WAV real foi entregue pelo servidor Node e reproduzido pelo AudioManager do jogo no Chromium com autoplay restrito.

Medição nesta máquina Linux com compilação CPU básica: 29,13 s de geração, 1,657 s de áudio, PCM16 mono 24 kHz, RMS -16,37 dBFS e pico -4,17 dBFS. Isso verifica que o motor entrega áudio não silencioso; não mede a saída física do celular nem garante resposta instantânea. A lentidão é uma limitação separada. Resultados em reports/v43_5/real-model.json.

## Limite do diagnóstico

O teste comprova a falha de atualização/inicialização no código e a geração/reprodução do modelo real no ambiente de desenvolvimento. Sem o diagnóstico atual do aparelho, não se afirma que toda ocorrência de silêncio no telefone tenha exclusivamente essa causa. O painel passa a distinguir claramente versões antigas, serviços parados, síntese em andamento e falha de reprodução.
