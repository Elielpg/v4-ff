# Independent, optional runtime layer. Uses only the public Godot API.
# Original pack, scripts, models, logic, camera, voices and collisions stay intact.
extends SceneTree

var config: Dictionary = {}
var viewport_3d: Viewport
var installed := false
var elapsed := 0.0
var check_elapsed := 0.0
var report_elapsed := 0.0
var started_us := 0
var previous_us := 0
var current_scale := 1.0
var slow_windows := 0
var good_windows := 0
var scale_changes := 0
var probe_windows := 0
var probe_total_ms := 0.0
var probe_baseline_ms := 0.0
var probe_previous_scale := 1.0
var adaptive_cooldown_until := 0.0
var no_gain_reverts := 0
var frame_times: Array[float] = []
var audit := {"decor_batches":0,"decor_instances":0,"materials_filtered":0,"terrain_textures_mipmapped":0,"terrain_textures_reused":0,"terrain_textures_skipped":0}
var scan_nodes: Array[Node] = []
var seen_materials: Dictionary = {}
var texture_cache: Dictionary = {}
var scan_finished := false
var detail_root: Node3D


func _initialize() -> void:
    started_us=Time.get_ticks_usec()
    var path := OS.get_environment("SNAKE_SCENE_GRAPHICS_CONFIG")
    if FileAccess.file_exists(path):
        var value = JSON.parse_string(FileAccess.get_file_as_string(path))
        if value is Dictionary:config=value
    var main := str(ProjectSettings.get_setting("application/run/main_scene",""))
    if main.is_empty():
        push_error("TERMUX_GRAPHICS: original main scene is not configured")
        quit(2)
        return
    call_deferred("_load_original",main)


func _load_original(main: String) -> void:
    var error := change_scene_to_file(main)
    if error != OK:
        push_error("TERMUX_GRAPHICS: original scene did not load")
        quit(2)


func _process(_delta: float) -> bool:
    var now := Time.get_ticks_usec()
    var wall_delta := float(now-previous_us)/1000000.0 if previous_us>0 else 0.0
    previous_us=now
    elapsed=float(now-started_us)/1000000.0
    check_elapsed+=wall_delta
    report_elapsed+=wall_delta
    if installed and not is_instance_valid(viewport_3d):installed=false
    if not installed and check_elapsed>=.5:
        check_elapsed=0.0
        _try_install()
    if installed:
        if wall_delta>0.0 and frame_times.size()<600:frame_times.append(wall_delta*1000.0)
        if not scan_finished:_filter_terrain_slice()
        if report_elapsed>=2.0:
            report_elapsed=0.0
            _report_and_adapt()
    return false


func _try_install() -> void:
    # The original launcher can change from a menu to the arena asynchronously.
    # Wait for a real camera; never assume that the first current_scene is the game.
    if root.get_camera_3d()!=null:
        viewport_3d=root
    else:
        var pending: Array[Node]=[root]
        while not pending.is_empty():
            var node: Node=pending.pop_back()
            if node is Viewport and node.get_camera_3d()!=null and node.get_visible_rect().size.x>=256:
                viewport_3d=node
                break
            for child in node.get_children():pending.append(child)
    if not is_instance_valid(viewport_3d):return
    installed=true
    if not config.get("enabled",true):
        current_scale=viewport_3d.scaling_3d_scale
        scan_finished=true
        return
    current_scale=float(config.get("scale",.82))
    viewport_3d.scaling_3d_mode=Viewport.SCALING_3D_MODE_BILINEAR
    viewport_3d.scaling_3d_scale=current_scale
    var mobile := RenderingServer.get_current_rendering_method()!="gl_compatibility"
    viewport_3d.msaa_3d=0 if config.get("stable_render",false) else (int(config.get("msaa",0)) if mobile else maxi(1,int(config.get("msaa",0))))
    viewport_3d.screen_space_aa=Viewport.SCREEN_SPACE_AA_FXAA if mobile else Viewport.SCREEN_SPACE_AA_DISABLED
    viewport_3d.positional_shadow_atlas_size=int(config.get("shadow_size",1024))
    RenderingServer.directional_shadow_atlas_set_size(int(config.get("shadow_size",1024)),false)
    # LOD is an existing engine feature; the models are not replaced or simplified.
    viewport_3d.mesh_lod_threshold=2.0
    if config.get("decorations",true):_build_decorations()
    if config.get("terrain_filtering",true) or config.get("terrain_colors",true):scan_nodes=[root]
    else:scan_finished=true
    print("TERMUX_GRAPHICS_READY "+JSON.stringify({"scale":current_scale,"decor_batches":audit.decor_batches,"method":RenderingServer.get_current_rendering_method()}))


func _filter_terrain_slice() -> void:
    # Bounded startup work. No image is exported; only already-loaded terrain
    # textures are mipmapped in RAM. Avatar, text and animated textures are skipped.
    var budget := 96
    while budget>0 and not scan_nodes.is_empty():
        var node: Node=scan_nodes.pop_back()
        budget-=1
        if not is_instance_valid(node):continue
        for child in node.get_children():scan_nodes.append(child)
        if not node is MeshInstance3D or node.mesh==null:continue
        for surface in range(node.mesh.get_surface_count()):
            var material: Material=node.get_active_material(surface)
            if not material is BaseMaterial3D or seen_materials.has(material.get_instance_id()):continue
            seen_materials[material.get_instance_id()]=true
            var texture: Texture2D=material.albedo_texture
            if texture==null or texture is ViewportTexture:continue
            var path := texture.resource_path
            var terrain := false
            for category in ["piso","parede","grama","elevacao"]:
                if path.begins_with("res://assets/textures/"+category+"/"):
                    terrain=true
                    # Keep category when a filtered ImageTexture has no path.
                    material.set_meta("termux_terrain_category",category)
            if not terrain:continue
            if config.get("terrain_colors",true) and path.begins_with("res://assets/textures/grama/"):
                material.albedo_color=material.albedo_color*Color(.68,.78,.76)
            if not config.get("terrain_filtering",true):continue
            material.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
            audit.materials_filtered+=1
            # Avoid synchronous GPU readback/new texture allocation on the
            # Android rendering path. Existing mipmaps/filtering are retained.
            if config.get("stable_render",false):continue
            var key := texture.get_instance_id()
            if texture_cache.has(key):
                if texture_cache[key]!=null:material.albedo_texture=texture_cache[key]
                continue
            # Limit added texture memory/startup work, regardless of scene size.
            if texture_cache.size()>=8:
                audit.terrain_textures_skipped+=1
                continue
            texture_cache[key]=null
            if not texture.get_rid().is_valid():continue
            var image: Image=texture.get_image()
            if image==null or image.is_empty() or image.get_width()>2048 or image.get_height()>2048:
                audit.terrain_textures_skipped+=1
                continue
            if image.has_mipmaps():
                audit.terrain_textures_reused+=1
                continue
            if image.is_compressed() and image.decompress()!=OK:
                audit.terrain_textures_skipped+=1
                continue
            if image.generate_mipmaps()!=OK:
                audit.terrain_textures_skipped+=1
                continue
            var filtered := ImageTexture.create_from_image(image)
            texture_cache[key]=filtered
            material.albedo_texture=filtered
            audit.terrain_textures_mipmapped+=1
            # At most one new image per frame, not all terrain images at once.
            return
    if scan_nodes.is_empty():
        scan_finished=true
        seen_materials.clear()
        print("TERMUX_TERRAIN_FILTER_READY "+JSON.stringify(audit))


func _material(color: Color, luminous: bool=false) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color=color
    material.roughness=.78
    material.vertex_color_use_as_albedo=true
    if luminous:
        material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
    return material


func _batch(mesh: Mesh, transforms: Array[Transform3D], colors: Array[Color], material: Material) -> void:
    var multi := MultiMesh.new()
    multi.transform_format=MultiMesh.TRANSFORM_3D
    multi.use_colors=true
    multi.mesh=mesh
    multi.instance_count=transforms.size()
    for index in range(transforms.size()):
        multi.set_instance_transform(index,transforms[index])
        multi.set_instance_color(index,colors[index])
    var instance := MultiMeshInstance3D.new()
    instance.multimesh=multi
    instance.material_override=material
    instance.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    detail_root.add_child(instance)
    audit.decor_batches+=1
    audit.decor_instances+=transforms.size()


func _build_decorations() -> void:
    detail_root=Node3D.new()
    detail_root.name="TermuxArenaDetails"
    viewport_3d.add_child(detail_root)
    var dark := _material(Color("263643"))
    var light := _material(Color.WHITE,true)
    var cyan := Color("48e4dd")
    var amber := Color("ffb653")
    var transforms: Array[Transform3D]=[]
    var colors: Array[Color]=[]
    var positions: Array[Vector3]=[]
    for side in [-1.0,1.0]:
        for index in range(9):positions.append(Vector3(side*13.4,.0,-11.6+index*2.9))
    var post := CylinderMesh.new()
    post.top_radius=.10;post.bottom_radius=.15;post.height=.72;post.radial_segments=8;post.rings=1
    for position in positions:
        transforms.append(Transform3D(Basis.IDENTITY,position+Vector3(0,.36,0)));colors.append(Color.WHITE)
    _batch(post,transforms,colors,dark)
    transforms.clear();colors.clear()
    var cap := SphereMesh.new()
    cap.radius=.15;cap.height=.30;cap.radial_segments=8;cap.rings=4
    for index in range(positions.size()):
        transforms.append(Transform3D(Basis.IDENTITY,positions[index]+Vector3(0,.79,0)));colors.append(cyan if index%2==0 else amber)
    _batch(cap,transforms,colors,light)
    transforms.clear();colors.clear()
    var foundation := CylinderMesh.new()
    foundation.top_radius=.36;foundation.bottom_radius=.42;foundation.height=.06;foundation.radial_segments=10;foundation.rings=1
    for position in positions:
        transforms.append(Transform3D(Basis.IDENTITY,position+Vector3(0,.03,0)));colors.append(Color.WHITE)
    _batch(foundation,transforms,colors,dark)
    transforms.clear();colors.clear()
    var lane := BoxMesh.new();lane.size=Vector3(.12,.035,.72)
    for side in [-1.0,1.0]:
        for index in range(24):
            transforms.append(Transform3D(Basis.IDENTITY,Vector3(side*12.7,.035,-11.5+index)));colors.append(cyan if index%3!=0 else amber)
    _batch(lane,transforms,colors,light)
    transforms.clear();colors.clear()
    var crystal := CylinderMesh.new()
    crystal.top_radius=0.0;crystal.bottom_radius=.32;crystal.height=1.0;crystal.radial_segments=5;crystal.rings=1
    for side in [-1.0,1.0]:
        for index in range(6):
            var height := .7+float(index%3)*.28
            transforms.append(Transform3D(Basis.IDENTITY.scaled(Vector3(.85,height,.85)),Vector3(side*15.0,height*.5,-10.0+index*4.0)))
            colors.append(cyan.darkened(.28) if index%2==0 else amber.darkened(.26))
    _batch(crystal,transforms,colors,light)
    if config.get("welcome_garden",false):_build_welcome_garden()
    # These details have no physics, animation workers, particles or shadow maps.


func _build_welcome_garden() -> void:
    # Borders only: the playable map (-11..11) and original collisions stay intact.
    var wood := _material(Color("624432"))
    var leaves := _material(Color("316a42"))
    var flowers := _material(Color.WHITE)
    var transforms: Array[Transform3D]=[]
    var colors: Array[Color]=[]
    var planter := CylinderMesh.new()
    planter.top_radius=.66;planter.bottom_radius=.5;planter.height=.45;planter.radial_segments=8;planter.rings=1
    for side in [-1.0,1.0]:
        for z in [-9.0,-3.0,3.0,9.0]:
            transforms.append(Transform3D(Basis.IDENTITY,Vector3(side*12.6,.225,z)));colors.append(Color.WHITE)
    _batch(planter,transforms,colors,wood)
    transforms.clear();colors.clear()
    var shrub := SphereMesh.new()
    shrub.radius=.66;shrub.height=.84;shrub.radial_segments=8;shrub.rings=4
    for side in [-1.0,1.0]:
        for z in [-9.0,-3.0,3.0,9.0]:
            transforms.append(Transform3D(Basis.IDENTITY,Vector3(side*12.6,.73,z)));colors.append(Color.WHITE)
    _batch(shrub,transforms,colors,leaves)
    transforms.clear();colors.clear()
    var bloom := SphereMesh.new()
    bloom.radius=.10;bloom.height=.15;bloom.radial_segments=6;bloom.rings=3
    for side in [-1.0,1.0]:
        for z in [-9.0,-3.0,3.0,9.0]:
            for index in range(5):
                var angle := float(index)*TAU/5.0
                transforms.append(Transform3D(Basis.IDENTITY,Vector3(side*12.6+cos(angle)*.40,1.01,z+sin(angle)*.40)))
                colors.append(Color("ffc85b") if index%2==0 else Color("ee8793"))
    _batch(bloom,transforms,colors,flowers)
    transforms.clear();colors.clear()
    var beam := BoxMesh.new();beam.size=Vector3.ONE
    for x in [-2.8,2.8]:
        transforms.append(Transform3D(Basis.IDENTITY.scaled(Vector3(.16,2.8,.16)),Vector3(x,1.4,15.7)));colors.append(Color.WHITE)
    transforms.append(Transform3D(Basis.IDENTITY.scaled(Vector3(6.0,.16,.16)),Vector3(0,2.85,15.7)));colors.append(Color.WHITE)
    _batch(beam,transforms,colors,wood)
    var welcome := Label3D.new()
    welcome.name="GardenWelcome";welcome.text="CHEGA MAIS!";welcome.font_size=96;welcome.pixel_size=.0035
    welcome.position=Vector3(0,2.36,15.65);welcome.modulate=Color("fff0c4")
    welcome.outline_modulate=Color("283b2b");welcome.outline_size=12
    detail_root.add_child(welcome)


func _report_and_adapt() -> void:
    if frame_times.is_empty():return
    var sorted := frame_times.duplicate()
    sorted.sort()
    var average := 0.0
    for value in frame_times:average+=value
    average/=float(frame_times.size())
    var p95: float=sorted[mini(sorted.size()-1,int(sorted.size()*.95))]
    var observed_scale := current_scale
    var probing := probe_windows>0
    if probing:
        probe_windows+=1
        probe_total_ms+=average
        if probe_windows>=3:
            if probe_total_ms/2.0>=probe_baseline_ms*.97:
                # Lower resolution cannot cure a CPU/scheduling stall. Restore
                # detail if this short probe showed no useful interval reduction.
                current_scale=probe_previous_scale
                viewport_3d.scaling_3d_scale=current_scale
                scale_changes+=1;no_gain_reverts+=1
                adaptive_cooldown_until=elapsed+30.0
            probe_windows=0;slow_windows=0;good_windows=0
    if config.get("adaptive_resolution",true) and elapsed>15.0 and elapsed>=adaptive_cooldown_until and not probing:
        var target_fps := float(config.get("target_fps",30))
        if Engine.max_fps>0:target_fps=minf(target_fps,float(Engine.max_fps))
        var target_ms := 1000.0/target_fps
        if average>target_ms*1.30:
            slow_windows+=1;good_windows=0
        elif average<target_ms*1.08:
            good_windows+=1;slow_windows=0
        else:
            slow_windows=0;good_windows=0
        var next := current_scale
        if slow_windows>=3:
            next=maxf(float(config.get("minimum_scale",.65)),current_scale-.05);slow_windows=0
        elif good_windows>=5:
            next=minf(float(config.get("maximum_scale",.90)),current_scale+.025);good_windows=0
        if absf(next-current_scale)>.001:
            if next<current_scale:
                probe_baseline_ms=average;probe_previous_scale=current_scale
                probe_windows=1;probe_total_ms=0.0
            current_scale=next;viewport_3d.scaling_3d_scale=current_scale;scale_changes+=1
    var report := {"at":Time.get_unix_time_from_system(),"pid":OS.get_process_id(),"preset":config.get("preset","fluid"),
        "renderer":RenderingServer.get_current_rendering_method(),"scale_observed":observed_scale,"scale_next":current_scale,"scale_changes":scale_changes,
        "fps_engine":Engine.get_frames_per_second(),"frame_ms_average":snappedf(average,.01),"frame_ms_p95":snappedf(p95,.01),"frame_samples":frame_times.size(),
        "no_gain_reverts":no_gain_reverts,"adaptive_pause_seconds":maxf(0.0,adaptive_cooldown_until-elapsed),
        "draw_calls":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"rendered_objects":Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME),
        "primitives":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),"nodes":Performance.get_monitor(Performance.OBJECT_NODE_COUNT),
        "texture_memory_mb":snappedf(Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED)/1048576.0,.1),"audit":audit,"terrain_scan_finished":scan_finished,
        "scope":"Engine intervals, not Android presentation or a GT3 benchmark. Startup/AI/camera stalls can affect the samples."}
    report.merge({"stable_render":config.get("stable_render",false),"stable_render_applied":config.get("stable_render",false) and config.get("enabled",false),"adaptive_enabled":config.get("adaptive_resolution",false),"msaa_actual":viewport_3d.msaa_3d,"texture_readbacks_allowed":not config.get("stable_render",false)})
    var path := OS.get_environment("SNAKE_SCENE_GRAPHICS_STATUS")
    if not path.is_empty():
        var file := FileAccess.open(path+".part",FileAccess.WRITE)
        if file!=null:
            file.store_string(JSON.stringify(report));file.close()
            DirAccess.rename_absolute(path+".part",path)
    frame_times.clear()
