"""Rebuild self-contained repair payloads from the independent adapter sources."""
from pathlib import Path
import base64
import hashlib
import textwrap

root = Path(__file__).resolve().parents[1]

def refresh(path, relative, tag):
    body = path.read_text()
    marker = f'cat >"$repair_stage/{relative}" <<\'{tag}\'\n'
    begin = body.index(marker) + len(marker)
    end = body.index(tag + '\n', begin)
    path.write_text(body[:begin] + (root / relative).read_text() + body[end:])

refresh(root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh', 'snake_termux/native.py', 'SNAKE_NATIVE_V022')
refresh(root / 'SNAKE_REYERS_REPARAR_GODOT_V022.sh', 'start.sh', 'SNAKE_START_V022')
for name in ('SNAKE_REYERS_REPARAR_X11_V021.sh', 'SNAKE_REYERS_REPARAR_JANELA_V023.sh'):
    path = root / name
    content = path.read_text()
    tag = 'SNAKE_X11_LAUNCHER_V021'
    marker = f'cat >"$repair_temp" <<\'{tag}\'\n'
    begin = content.index(marker) + len(marker)
    end = content.index(tag + '\n', begin)
    path.write_text(content[:begin] + (root / 'start.sh').read_text() + content[end:])
old = root / 'SNAKE_REYERS_REPARAR_GPU_AUDIO_V024.sh'
files = ['start.sh', 'snake_termux/native.py', 'snake_termux/__main__.py', 'snake_termux/device_runtime.py', 'snake_termux/ui.js', 'install-termux.sh']
for index, relative in enumerate(files):
    refresh(old, relative, f'SNAKE_DEVICE_V024_FILE_{index}')
# Keep the older, GPU-only repair usable when the new optional module is absent.
# Its UI checks the endpoint and hides unsupported profile controls.

body = old.read_text()
header = body[:body.index('cat >"$repair_stage/start.sh"')]
header = header.replace('gpu-audio-v024', 'display-music-v025')
extra = ['snake_termux/presentation.py', 'assets/music/Neon Garden.ogg', 'assets/music/CREDITS.md', 'snake_termux/audio_service.py', 'snake_termux/integration.py', 'snake_termux/live_tuning.py', 'snake_termux/music_library.py', 'snake_termux/piper_worker.py', 'snake_termux/voice.py', 'snake_termux/reuse_ai.py', 'snake_termux/cloud_ai.py', 'snake_termux/cloud_settings.py', 'snake_termux/cloud_ui.js', 'snake_termux/live_load.py', 'snake_termux/speech_names.py', 'snake_termux/director.py', 'snake_termux/director.html', 'snake_termux/client.py', 'snake_termux/local_social.py', 'snake_termux/performance.py', 'snake_termux/studio_audio.py', 'snake_termux/responsive.py', 'tools/restore_adapter.py', 'SNAKE_REYERS_INVESTIGAR_GT3.py', 'snake_termux/scene_graphics.py', 'snake_termux/godot/scene_graphics.gd']
extra += ['snake_termux/phonk.py','snake_termux/phonk_ui.js','snake_termux/godot/phonk_scene.gd','snake_termux/godot/phonk_runtime.gd','snake_termux/godot/phonk_beat.gd','snake_termux/godot/phonk_skin.gdshader','snake_termux/godot/phonk_floor.gdshader','snake_termux/godot/phonk_aura.gdshader']
extra += ['snake_termux/live_queue.py','snake_termux/live_policy.py','snake_termux/original_update.py']
files += extra
array = 'repair_files=(' + ' '.join("'" + item + "'" for item in files) + ')'
start = header.index('repair_files=(')
end = header.index('\n', start)
header = header[:start] + array + header[end:]
blocks = []
for index, relative in enumerate(files):
    tag = f'SNAKE_DISPLAY_V025_FILE_{index}'
    if relative.endswith('.ogg'):
        data = (root / relative).read_bytes()
        encoded = '\n'.join(textwrap.wrap(base64.b64encode(data).decode(), 96))
        blocks.append('cat >"$repair_stage/track.b64" <<\'' + tag + "'\n" + encoded + '\n' + tag + '\n')
        blocks.append('"$repair_python" - "$repair_stage" <<\'SNAKE_DECODE_TRACK\'\n'
                      'import base64, hashlib, pathlib, sys\n'
                      'root = pathlib.Path(sys.argv[1])\n'
                      'data = base64.b64decode((root/"track.b64").read_bytes())\n'
                      'if hashlib.sha256(data).hexdigest() != ' + repr(hashlib.sha256(data).hexdigest()) + ':\n'
                      '    sys.exit("Falha de integridade na trilha instrumental.")\n'
                      '(root/"assets/music/Neon Garden.ogg").write_bytes(data)\n'
                      'SNAKE_DECODE_TRACK\n')
    else:
        blocks.append('cat >"$repair_stage/' + relative + '" <<\'' + tag + "'\n" + (root / relative).read_text() + tag + '\n')
footer = body[body.index('"$repair_python" - "$repair_stage" <<\'SNAKE_CHECK_FILES\''):]
footer = footer[:footer.index("printf 'Arquivos GPU/")]
footer = footer.replace('do mv -f -- "$repair_stage/$relative" "$repair_target/$relative"; done',
                        'do mkdir -p -- "$repair_target/$(dirname -- "$relative")"; mv -f -- "$repair_stage/$relative" "$repair_target/$relative"; done')
footer += '''printf 'Tela limpa, perfis e trilha preparados. Backup: %s\\n' "$repair_backup"
printf 'Não foram reinstalados drivers, voz ou IA. A trilha entra somente se a biblioteca estiver vazia.\\n'
printf 'Para iniciar: cd "%s" && bash start.sh\\n' "$repair_target"
'''
(root / 'SNAKE_REYERS_TELA_MUSICA_V025.sh').write_text(header + ''.join(blocks) + footer)
repair_audio = (header + ''.join(blocks) + footer).replace('display-music-v025', 'audio-launch-v026')
repair_audio = repair_audio.replace('Tela limpa, perfis e trilha preparados.', 'Preparação de áudio Android e detecção de driver Dummy atualizadas.')
(root / 'SNAKE_REYERS_REPARAR_SOM_V026.sh').write_text(repair_audio)
repair_private = repair_audio.replace('audio-launch-v026', 'private-audio-v027')
repair_private = repair_private.replace('Preparação de áudio Android e detecção de driver Dummy atualizadas.', 'Áudio privado do jogo e proteção da abertura da imagem preparados.')
(root / 'SNAKE_REYERS_RECUPERAR_IMAGEM_SOM_V027.sh').write_text(repair_private)
repair_pacing = repair_private.replace('private-audio-v027', 'live-pacing-v028')
repair_pacing = repair_pacing.replace('Áudio privado do jogo e proteção da abertura da imagem preparados.', 'Modo de resposta direta, avatares leves e perfil LIVE preparados.')
(root / 'SNAKE_REYERS_RITMO_LIVE_V028.sh').write_text(repair_pacing)

repair_music = repair_pacing.replace('live-pacing-v028', 'music-library-v029')
repair_music = repair_music.replace('Modo de resposta direta, avatares leves e perfil LIVE preparados.', 'Biblioteca musical, conversão de áudio e seleção automática preparadas.')
repair_music = repair_music.replace('Não foram reinstalados drivers, voz ou IA. A trilha entra somente se a biblioteca estiver vazia.', 'Não foram reinstalados drivers, voz ou IA. No painel, escolha sua faixa em Biblioteca de músicas e toque em Tocar / salvar seleção.')
(root / 'SNAKE_REYERS_BIBLIOTECA_MUSICAS_V029.sh').write_text(repair_music)

repair_stable = repair_music.replace('music-library-v029', 'stable-playback-v030')
repair_stable = repair_stable.replace('Biblioteca musical, conversão de áudio e seleção automática preparadas.', 'Limite de CPU da voz, preparação musical com prioridade reduzida e áudio privado com mais margem preparados.')
repair_stable = repair_stable.replace('Não foram reinstalados drivers, voz ou IA. No painel, escolha sua faixa em Biblioteca de músicas e toque em Tocar / salvar seleção.', 'Não foram reinstalados drivers ou modelos. Se ainda houver travadas, selecione o perfil Estável no painel e feche/abra a janela para aplicar. Serviços de voz externos já abertos não foram encerrados.')
(root / 'SNAKE_REYERS_ESTABILIDADE_V030.sh').write_text(repair_stable)

repair_cloud = repair_stable.replace('stable-playback-v030', 'cloud-ai-v031')
repair_cloud = repair_cloud.replace('Limite de CPU da voz, preparação musical com prioridade reduzida e áudio privado com mais margem preparados.', 'Painel OpenAI/Gemini, múltiplas chaves Gemini e voz OpenAI preparados. As opções locais foram mantidas.')
repair_cloud = repair_cloud.replace('Não foram reinstalados drivers ou modelos. Se ainda houver travadas, selecione o perfil Estável no painel e feche/abra a janela para aplicar. Serviços de voz externos já abertos não foram encerrados.', 'Nenhuma chave foi incluída ou ativada. Configure o provedor no painel; API OpenAI tem cobrança separada e Gemini depende da cota do projeto.')
(root / 'SNAKE_REYERS_IA_NUVEM_V031.sh').write_text(repair_cloud)

repair_load = repair_cloud.replace('cloud-ai-v031', 'live-load-v032')
repair_load = repair_load.replace('Painel OpenAI/Gemini, múltiplas chaves Gemini e voz OpenAI preparados. As opções locais foram mantidas.', 'Fila para LIVE movimentada, nomes falados, seleção da IA e painel de espectadores/FPS preparados.')
repair_load = repair_load.replace('Nenhuma chave foi incluída ou ativada. Configure o provedor no painel; API OpenAI tem cobrança separada e Gemini depende da cota do projeto.', 'No painel, confira IA ATIVA e clique em Usar Gemini para responder se essa for sua escolha. Verificar uma chave não troca o provedor. RTMP/RTMPS requer URL/chave e captura compatível; nenhuma transmissão foi iniciada.')
(root / 'SNAKE_REYERS_LIVE_FLUIDA_V032.sh').write_text(repair_load)

repair_local = repair_load.replace('live-load-v032', 'local-social-v033')
repair_local = repair_local.replace('No painel, confira IA ATIVA e clique em Usar Gemini para responder se essa for sua escolha. Verificar uma chave não troca o provedor. RTMP/RTMPS requer URL/chave e captura compatível; nenhuma transmissão foi iniciada.', 'Conversa Qwen local com contexto e sarcasmo, ritmo do Piper selecionável e vozes atuais preservadas. Nenhum modelo foi reinstalado.')
repair_local += '''
if [[ "$repair_files_only" == 0 && -f "$repair_target/state/project-path.txt" ]]; then
  (cd -- "$repair_target" && "$repair_python" -m snake_termux.local_social --select-local "$repair_target")
fi
printf 'Conversa local atualizada. A seleção da voz foi preservada. Confira Termux 0.3.3 no painel.\\n'
'''
(root / 'SNAKE_REYERS_CONVERSA_LOCAL_V033.sh').write_text(repair_local)

repair_studio=repair_load.replace('live-load-v032','gt3-studio-v034')
repair_studio=repair_studio.replace('No painel, confira IA ATIVA e clique em Usar Gemini para responder se essa for sua escolha. Verificar uma chave não troca o provedor. RTMP/RTMPS requer URL/chave e captura compatível; nenhuma transmissão foi iniciada.', 'Provedor de respostas e voz preservados. O novo APK é separado e exige teste local e autorização para transmitir.')
repair_studio += r"""
if [[ "$repair_files_only" == 0 ]]; then
  "$repair_python" - "$repair_target" "$repair_backup" <<'SNAKE_GT3_CONFIG'
from pathlib import Path
import json,sys,time
root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from snake_termux.device_runtime import atomic_json
backup=Path(sys.argv[2]);state=root/'state'
marker=state/'gt3-v034-applied.json'
if not marker.exists():
    snapshots={}
    for name in ('presentation-config.json','performance-config.json'):
        path=state/name
        snapshots[name]=path.read_bytes() if path.exists() else None
        if snapshots[name] is not None:(backup/name).write_bytes(snapshots[name])
    (backup/'gt3-config-presence.json').write_text(json.dumps({k:v is not None for k,v in snapshots.items()}))
    try:
        old={}
        if snapshots['presentation-config.json']:
            try:old=json.loads(snapshots['presentation-config.json'])
            except ValueError:pass
        if not isinstance(old,dict):old={}
        atomic_json(state/'presentation-config.json',{**old,'profile':'gt3_live'})
        atomic_json(state/'performance-config.json',{'text_threads':3,'text_batch_threads':3,'voice_threads':2,'text_nice':3})
        atomic_json(marker,{'applied_at':time.time(),'settings_backup':str(backup),'note':'Perfil inicial de teste; FPS real e voz devem ser medidos no GT3.'})
    except Exception:
        for name,data in snapshots.items():
            path=state/name
            if data is None:path.unlink(missing_ok=True)
            else:path.write_bytes(data)
        raise
SNAKE_GT3_CONFIG
fi
printf 'Termux 0.3.4: perfil GT3 LIVE (720p/30), diagnóstico e ponte de áudio preparados.\n'
printf 'Não foi comprovado ganho no celular. Confira o FPS e faça o teste de áudio. Vulkan direto é opcional no painel.\n'
printf 'Cofra Studio é um APK independente. A transmissão exige autorização no Android e sua chave inserida somente no app.\n'
"""
(root/'SNAKE_REYERS_GT3_STUDIO_V034.sh').write_text(repair_studio)

repair_response=repair_load.replace('live-load-v032','responsive-v035')
repair_response=repair_response.replace('Fila para LIVE movimentada, nomes falados, seleção da IA e painel de espectadores/FPS preparados.', 'Termux 0.3.5: geração local limitada à fala, personagem antecipado e tempos por etapa preparados.')
repair_response=repair_response.replace('No painel, confira IA ATIVA e clique em Usar Gemini para responder se essa for sua escolha. Verificar uma chave não troca o provedor. RTMP/RTMPS requer URL/chave e captura compatível; nenhuma transmissão foi iniciada.', 'Modelo, provedor de voz, chaves, músicas, progresso e perfil gráfico preservados. Confira Tempo de resposta no painel.')
repair_response+='''
"$repair_python" - "$repair_target" "$repair_backup" "${repair_files[@]}" <<'SNAKE_RESPONSE_ROLLBACK'
import json,pathlib,shutil,sys
root=pathlib.Path(sys.argv[1]);backup=pathlib.Path(sys.argv[2])
manifest={'root':str(root),'files':{relative:(backup/relative).is_file() for relative in sys.argv[3:]}}
(backup/'restore-manifest.json').write_text(json.dumps(manifest,indent=2))
shutil.copy2(root/'tools/restore_adapter.py',backup/'REVERTER.py')
print('Para reverter, pare o jogo e execute: python3 "'+str(backup/'REVERTER.py')+'"')
SNAKE_RESPONSE_ROLLBACK
'''
(root/'SNAKE_REYERS_RESPOSTA_RAPIDA_V035.sh').write_text(repair_response)

repair_graphics=repair_response.replace('responsive-v035','graphics-v036')
repair_graphics=repair_graphics.replace('Termux 0.3.5: geração local limitada à fala, personagem antecipado e tempos por etapa preparados.', 'Termux 0.3.6: detalhe 3D, terreno filtrado, decoração em lotes e medição gráfica preparados.')
repair_graphics+=r"""
if [[ "$repair_files_only" == 0 ]]; then
  "$repair_python" - "$repair_target" "$repair_backup" <<'SNAKE_GRAPHICS_CONFIG'
import json,pathlib,shutil,sys,time
root=pathlib.Path(sys.argv[1]);backup=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(root))
from snake_termux.scene_graphics import save
from snake_termux.device_runtime import atomic_json
manifest_path=backup/'restore-manifest.json';manifest=json.loads(manifest_path.read_text())
names=('state/scene-graphics-config.json','state/scene-graphics-v036-applied.json')
for name in names:
    path=root/name;manifest['files'][name]=path.is_file()
    if path.is_file():
        (backup/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup/name)
manifest_path.write_text(json.dumps(manifest,indent=2))
marker=root/names[1]
try:
    if not marker.exists():
        if not (root/names[0]).exists():save(root/'state',{'enabled':True,'preset':'fluid'})
        atomic_json(marker,{'applied_at':time.time(),'backup':str(backup),'note':'Complemento independente; ganho no GT3 ainda precisa ser medido.'})
except Exception:
    for name in names:
        path=root/name
        if manifest['files'][name]:shutil.copy2(backup/name,path)
        else:path.unlink(missing_ok=True)
    raise
print('Perfil gráfico preservado ou criado como GT3 fluido. Voz, IA, músicas e motor Vulkan/OpenGL preservados.')
SNAKE_GRAPHICS_CONFIG
fi
printf 'Recarregue o painel e confira Termux 0.3.6. Use Arena 3D para comparar ou desativar o complemento.\n'
printf 'O ganho real de FPS no celular ainda precisa ser medido. O arquivo original do jogo foi preservado.\n'
"""
(root/'SNAKE_REYERS_GRAFICOS_GT3_V036.sh').write_text(repair_graphics)

repair_phonk=repair_response.replace('responsive-v035','phonk-v037')
repair_phonk=repair_phonk.replace('Termux 0.3.5: geração local limitada à fala, personagem antecipado e tempos por etapa preparados.', 'Termux 0.3.7: Cobra do PHONK, visual reversível e cores por batida ou faixa preparados.')
repair_phonk+=r"""
if [[ "$repair_files_only" == 0 ]]; then
  "$repair_python" - "$repair_target" "$repair_backup" <<'SNAKE_PHONK_CONFIG'
import json,pathlib,shutil,sys,time
root=pathlib.Path(sys.argv[1]);backup=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(root))
from snake_termux.phonk import save
from snake_termux.device_runtime import atomic_json
manifest_path=backup/'restore-manifest.json';manifest=json.loads(manifest_path.read_text())
names=('state/phonk-config.json','state/phonk-v037-applied.json')
for name in names:
    path=root/name;manifest['files'][name]=path.is_file()
    if path.is_file():
        (backup/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,backup/name)
manifest_path.write_text(json.dumps(manifest,indent=2))
marker=root/names[1]
try:
    if not marker.exists():
        if not (root/names[0]).exists():save(root/'state',{'enabled':True})
        atomic_json(marker,{'applied_at':time.time(),'backup':str(backup)})
except Exception:
    for name in names:
        path=root/name
        if manifest['files'][name]:shutil.copy2(backup/name,path)
        else:path.unlink(missing_ok=True)
    raise
print('Tema PHONK preservado ou ativado na primeira aplicação. IA, voz, músicas e perfil gráfico preservados.')
SNAKE_PHONK_CONFIG
fi
printf 'Confira Termux 0.3.7 e Cobra do PHONK no painel. Abra o jogo para carregar o tema.\n'
printf 'Detecção automática: música tocada pelo jogo. Outros aplicativos: BPM manual, sem captura de áudio externa.\n'
"""
(root/'SNAKE_REYERS_PHONK_V037.sh').write_text(repair_phonk)

# New effect setup is applied once; backup includes the prior theme preferences.
repair_neon=repair_phonk.replace('phonk-v037','neon-v038').replace('phonk-v037-applied','phonk-v038-applied').replace('0.3.7','0.3.8')
repair_neon=repair_neon.replace("if not (root/names[0]).exists():save(root/'state',{'enabled':True})", "save(root/'state',{'enabled':True,'lightning':True,'lightning_strength':1.2,'floor_reactive':True,'floor_strength':.8,'aura':True,'aura_strength':.35,'color_mode':'random','color_every':2})")
repair_neon=repair_neon.replace('Cobra do PHONK, visual reversível e cores por batida ou faixa preparados.', 'Cobra do PHONK com raios móveis, chão reativo e limpeza periódica dos registros visuais.')
(root/'SNAKE_REYERS_NEON_FLUIDEZ_V038.sh').write_text(repair_neon)

repair_chrome=repair_neon.replace('neon-v038','chrome-v039').replace('0.3.8','0.3.9')
repair_chrome=repair_chrome.replace("'color_mode':'random','color_every':2}","'color_mode':'random','color_every':2,'style':'chrome','stable_render':True,'accent_strength':.16,'base_color':'#030407'}")
repair_chrome=repair_chrome.replace('Cobra do PHONK com raios móveis, chão reativo e limpeza periódica dos registros visuais.', 'Chrome preto/prata, aura branca e renderização estável preparados; congelamento no GT3 ainda requer diagnóstico.')
(root/'SNAKE_REYERS_CHROME_ESTAVEL_V039.sh').write_text(repair_chrome)

repair_original=repair_response.replace('responsive-v035','original-live-v040')
repair_original=repair_original.replace('Termux 0.3.5: geração local limitada à fala, personagem antecipado e tempos por etapa preparados.', 'Termux 0.4.0: visual original, jardim nas bordas e filas de presentes/comentários preparados.')
repair_original+='''
if [[ "$repair_files_only" == 0 && -f "$repair_target/state/project-path.txt" ]]; then
  (cd -- "$repair_target" && "$repair_python" -m snake_termux.original_update "$repair_target" --backup "$repair_backup")
fi
printf 'Presentes: prioridade e ordem de chegada. Comentários: até 3 esperando, sem guardar excedentes.\\n'
printf 'Boas-vindas agrupadas. IA, voz, músicas, modelos e regras originais preservados.\\n'
printf 'RTMP e APK de transmissão ficam para outra etapa; nenhuma transmissão foi iniciada.\\n'
'''
(root/'SNAKE_REYERS_ORIGINAL_FILAS_V040.sh').write_text(repair_original)
