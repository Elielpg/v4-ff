"""Qwen3-TTS C API bridge. Native inference, local reference, no Python ML runtime."""
import argparse
import array
import ctypes as c
import json
import math
import sys
import wave
import hashlib
import faulthandler
import os
from pathlib import Path
from tts_server import make_server


class Params(c.Structure):
    _fields_ = [("max_audio_tokens", c.c_int32), ("temperature", c.c_float),
                ("top_p", c.c_float), ("top_k", c.c_int32), ("n_threads", c.c_int32),
                ("repetition_penalty", c.c_float), ("language_id", c.c_int32)]


class Audio(c.Structure):
    _fields_ = [("samples", c.POINTER(c.c_float)), ("n_samples", c.c_int32), ("sample_rate", c.c_int32)]


def configure_reference(source, target):
    """Accept PCM16 WAV; downmix/resample locally, without external decoders."""
    source, target = Path(source), Path(target)
    if source.stat().st_size > 16 * 1024**2:
        raise ValueError("Use um WAV de até 30 segundos e 16 MB")
    with wave.open(str(source), "rb") as wav:
        channels, rate, frames = wav.getnchannels(), wav.getframerate(), wav.getnframes()
        if wav.getsampwidth() != 2 or channels not in (1, 2) or not 8000 <= rate <= 96000 or not 3 <= frames / rate <= 30:
            raise ValueError("Amostra: WAV PCM16, mono/estéreo, 3 a 30 segundos")
        data = array.array("h", wav.readframes(frames))
    if sys.byteorder != "little":
        data.byteswap()
    if len(data) != frames * channels:
        raise ValueError("WAV incompleto")
    mono = data if channels == 1 else array.array("h", ((data[i] + data[i + 1]) // 2 for i in range(0, len(data), 2)))
    if max(abs(v) for v in mono) < 120:
        raise ValueError("A amostra está silenciosa ou muito baixa")
    output = array.array("h")
    for i in range(round(len(mono) * 24000 / rate)):
        position = i * rate / 24000
        a = min(int(position), len(mono) - 1)
        b = min(a + 1, len(mono) - 1)
        output.append(round(mono[a] + (mono[b] - mono[a]) * (position - a)))
    if sys.byteorder != "little":
        output.byteswap()
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(".tmp.wav")
    with wave.open(str(temp), "wb") as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(24000); wav.writeframes(output.tobytes())
    temp.replace(target)
    return {"seconds": frames / rate, "sampleRate": 24000, "channels": 1}


class CloneVoice:
    def __init__(self, library, models, reference, threads=4, loader=c.CDLL, progress=None):
        self.progress = progress or (lambda message: None)
        self.progress("Carregando biblioteca nativa")
        self.lib = loader(str(library))
        self.handle = None
        api = self.lib
        signatures = {
            "qwen3_tts_create": ([c.c_char_p, c.c_int32], c.c_void_p),
            "qwen3_tts_destroy": ([c.c_void_p], None),
            "qwen3_tts_default_params": ([c.POINTER(Params)], None),
            "qwen3_tts_extract_embedding_file": ([c.c_void_p, c.c_char_p, c.POINTER(c.c_float), c.c_int32], c.c_int32),
            "qwen3_tts_synthesize_with_embedding": ([c.c_void_p, c.c_char_p, c.POINTER(c.c_float), c.c_int32, c.POINTER(Params)], c.POINTER(Audio)),
            "qwen3_tts_free_audio": ([c.POINTER(Audio)], None),
            "qwen3_tts_get_error": ([c.c_void_p], c.c_char_p),
        }
        for name, (args, result) in signatures.items():
            fn = getattr(api, name); fn.argtypes = args; fn.restype = result
        self.progress("Carregando os modelos GGUF")
        self.handle = api.qwen3_tts_create(str(models).encode(), threads)
        if not self.handle:
            raise ValueError("Qwen3-TTS não carregou os GGUF. Consulte logs/voz.log")
        self.embedding = (c.c_float * 4096)()
        self.progress("Extraindo a voz da referência")
        self.embedding_size = api.qwen3_tts_extract_embedding_file(self.handle, str(reference).encode(), self.embedding, 4096)
        if not 1 <= self.embedding_size <= 4096:
            self.close()
            raise ValueError("Não foi possível extrair a voz da amostra")
        self.params = Params(); api.qwen3_tts_default_params(c.byref(self.params))
        self.params.language_id = 2071  # Portuguese; never leave the default English token.
        self.params.n_threads = threads
        self.params.max_audio_tokens = 384
        self.params.temperature = 0.6

    def close(self):
        if self.handle:
            self.lib.qwen3_tts_destroy(self.handle); self.handle = None

    def synthesize_wav(self, text, output):
        self.progress("Gerando áudio em português")
        result = self.lib.qwen3_tts_synthesize_with_embedding(self.handle, text.encode(), self.embedding, self.embedding_size, c.byref(self.params))
        if not result:
            raise ValueError("A clonagem não gerou áudio")
        try:
            audio = result.contents
            if audio.sample_rate != 24000 or not 240 <= audio.n_samples <= 24000 * 35 or not audio.samples:
                raise ValueError("Áudio clonado inválido ou longo demais")
            pcm = array.array("h")
            for i in range(audio.n_samples):
                value = audio.samples[i]
                if not math.isfinite(value):
                    raise ValueError("Áudio clonado inválido")
                pcm.append(round(max(-1, min(1, value)) * 32767))
            if not any(abs(v) > 20 for v in pcm):
                raise ValueError("A clonagem gerou silêncio")
            if sys.byteorder != "little":
                pcm.byteswap()
            output.setnchannels(1); output.setsampwidth(2); output.setframerate(24000); output.writeframes(pcm.tobytes())
        finally:
            self.lib.qwen3_tts_free_audio(result)


def main():
    faulthandler.enable(all_threads=True)
    os.environ["QWEN3_TTS_BACKEND"] = "cpu"
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--port", type=int, default=8082)
    parser.add_argument("--preview", type=Path)
    parser.add_argument("--build-id")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Porta inválida")
    root = args.root.resolve()
    config = json.loads((root / "cloning/config.json").read_text())
    voice = CloneVoice(root / "qwen3-tts.cpp/build/libqwen3tts.so", root / "cloning/models", root / "cloning/reference.wav", progress=lambda message: print(message, file=sys.stderr, flush=True))
    try:
        if args.preview:
            import time
            started = time.monotonic()
            preview_temp = args.preview.with_suffix(".tmp.wav")
            try:
                with wave.open(str(preview_temp), "wb") as wav:
                    voice.synthesize_wav("E aí, pessoal! Agora o relógio está pronto. Quatro Braços corre rápido!", wav)
                preview_temp.replace(args.preview)
            finally:
                preview_temp.unlink(missing_ok=True)
            latency = round(time.monotonic() - started, 2)
            result = {"preview": str(args.preview), "secondsToGenerate": latency, "reference": config.get("seconds"), "referenceSha256": hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest(), "language": "Portuguese"}
            (root / "cloning/preview.json").write_text(json.dumps(result))
            print(json.dumps(result))
            return
        preview = None
        try:
            info = json.loads((root / "cloning/preview.json").read_text())
            if info.get("referenceSha256") == hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest():
                preview = root / "cloning/preview.wav"
        except (OSError, ValueError):
            pass
        server = make_server(voice, args.port, model_name="Qwen3-TTS-0.6B-clone-pt", preview_path=preview, cache_dir=root / "cloning/audio-cache", build_id=args.build_id, namespace=hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest())
        print(f"Clonagem pronta em 127.0.0.1:{args.port}; referência local carregada", flush=True)
        try:
            server.serve_forever()
        finally:
            server.server_close()
    finally:
        voice.close()


if __name__ == "__main__":
    main()
