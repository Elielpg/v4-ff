"""One native synthesis at a time; finished WAVs survive HTTP timeouts."""
import hashlib
import io
import json
from pathlib import Path
import re
import threading
import time
import traceback
import wave


class VoiceBusy(Exception):
    pass


def validate_wav(data):
    if not 44 <= len(data) <= 4 * 1024 * 1024:
        raise ValueError("Áudio inválido ou grande demais")
    with wave.open(io.BytesIO(data)) as wav:
        if wav.getnframes() < 1 or wav.getsampwidth() != 2:
            raise ValueError("Áudio vazio ou formato inválido")
        return round(wav.getnframes() / wav.getframerate(), 3)


class VoiceJobs:
    def __init__(self, synthesize, model, namespace="", cache_dir=None):
        self.synthesize = synthesize
        self.model = model
        self.namespace = hashlib.sha256((model + "\0" + namespace).encode()).hexdigest()
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.jobs = {}
        self.active = None
        self.last_seconds = None

    def _cached(self, identifier):
        if not self.cache_dir:
            return None
        try:
            info = json.loads((self.cache_dir / (identifier + ".json")).read_text())
            if info["namespace"] != self.namespace or time.time() - info["created"] > 1800:
                return None
            data = (self.cache_dir / (identifier + ".wav")).read_bytes()
            validate_wav(data)
            if hashlib.sha256(data).hexdigest() != info["sha256"]:
                return None
            return {**info, "id": identifier, "state": "ready", "audio": data, "cached": True}
        except (OSError, ValueError, KeyError, TypeError, EOFError, wave.Error):
            return None

    def start(self, text):
        identifier = hashlib.sha256((self.namespace + "\0" + text).encode()).hexdigest()
        with self.lock:
            current = self.jobs.get(identifier)
            if current and (current["state"] == "generating" or current["state"] == "ready" and time.time() - current["created"] <= 1800):
                return self.status(identifier)
            cached = self._cached(identifier)
            if cached:
                self.jobs[identifier] = cached
                self._trim(identifier)
                return self.status(identifier)
            if self.active:
                raise VoiceBusy()
            self.jobs[identifier] = {"id": identifier, "state": "generating", "started": time.monotonic(), "created": time.time(), "event": threading.Event()}
            self.active = identifier
            threading.Thread(target=self._generate, args=(identifier, text), daemon=True).start()
            return self.status(identifier)

    def _generate(self, identifier, text):
        try:
            data = self.synthesize(text)
            seconds = validate_wav(data)
            with self.lock:
                job = self.jobs[identifier]
                elapsed = round(time.monotonic() - job["started"], 2)
                info = {"namespace": self.namespace, "created": time.time(), "generationSeconds": elapsed, "audioSeconds": seconds, "sha256": hashlib.sha256(data).hexdigest()}
                if self.cache_dir:
                    try:
                        for suffix, content in [("wav", data), ("json", json.dumps(info).encode())]:
                            path = self.cache_dir / (identifier + "." + suffix)
                            temporary = path.with_suffix(path.suffix + ".tmp")
                            temporary.write_bytes(content)
                            temporary.replace(path)
                    except OSError:
                        print("Não foi possível guardar a voz em disco; áudio mantido em memória.", flush=True)
                job.update(info, state="ready", audio=data)
                self.last_seconds = elapsed
        except Exception:
            traceback.print_exc()
            with self.lock:
                self.jobs[identifier].update(state="failed", message="O clonador não gerou uma fala válida. Veja logs/voz.log.")
        finally:
            with self.lock:
                self.active = None
                self.jobs[identifier]["event"].set()
                self._trim(identifier)

    def status(self, identifier):
        if not re.fullmatch(r"[a-f0-9]{64}", identifier):
            raise KeyError(identifier)
        with self.lock:
            if identifier not in self.jobs:
                cached = self._cached(identifier)
                if not cached:
                    raise KeyError(identifier)
                self.jobs[identifier] = cached
                self._trim(identifier)
            job = self.jobs[identifier]
            elapsed = round(time.monotonic() - job["started"], 1) if job["state"] == "generating" else job.get("generationSeconds", 0)
            return {"id": identifier, "state": job["state"], "model": self.model, "elapsedSeconds": elapsed, **{key: job[key] for key in ("generationSeconds", "audioSeconds", "cached", "message") if key in job}}

    def audio(self, identifier):
        with self.lock:
            if self.status(identifier)["state"] != "ready":
                raise VoiceBusy()
            return self.jobs[identifier]["audio"]

    def wait(self, identifier):
        with self.lock:
            event = self.jobs[identifier].get("event")
        if event:
            event.wait()
        return self.audio(identifier)

    def health(self):
        with self.lock:
            return {"jobsSupported": True, "busy": self.active is not None, "activeJob": self.status(self.active) if self.active else None, "lastGenerationSeconds": self.last_seconds}

    def _trim(self, keep=None):
        ready = sorted(((key, job) for key, job in self.jobs.items() if key not in (self.active, keep)), key=lambda item: item[1].get("created", 0))
        total = sum(len(job.get("audio", b"")) for job in self.jobs.values())
        for key, job in ready:
            if len(self.jobs) <= 32 and total <= 24 * 1024 * 1024:
                break
            total -= len(job.get("audio", b""))
            del self.jobs[key]
        if self.cache_dir:
            files = sorted((p for p in self.cache_dir.glob("*.wav") if re.fullmatch(r"[a-f0-9]{64}\.wav", p.name)), key=lambda p: p.stat().st_mtime, reverse=True)
            total = 0
            for index, path in enumerate(files):
                total += path.stat().st_size
                if index >= 32 or total > 24 * 1024 * 1024 or time.time() - path.stat().st_mtime > 1800:
                    path.unlink(missing_ok=True)
                    path.with_suffix(".json").unlink(missing_ok=True)
