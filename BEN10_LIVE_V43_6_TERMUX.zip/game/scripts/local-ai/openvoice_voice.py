"""Offline Brazilian speech followed by reference-based OpenVoice V2 conversion.

Piper supplies pronunciation, not the final speaker. Every utterance passes
through the reference converter; conversion failures never fall back to Piper.
"""
import argparse
import hashlib
import io
import json
import sys
import time
import wave
from pathlib import Path

from tts_server import make_server

sys.path.insert(0, str(Path(__file__).parent / "vendor"))


class ReferenceVoice:
    def __init__(self, root):
        import numpy as np
        import torch
        import onnxruntime as ort
        from piper import PiperVoice
        from piper.config import PiperConfig
        from openvoice.models import SynthesizerTrn

        self.np, self.torch = np, torch
        torch.set_num_threads(2)
        torch.set_num_interop_threads(1)
        ort.disable_telemetry_events()
        root = Path(root)
        config = json.loads((root / "openvoice/config.json").read_text())
        self.data = config["data"]
        self.rate = self.data["sampling_rate"]
        self.model = SynthesizerTrn(0, self.data["filter_length"] // 2 + 1,
                                    n_speakers=self.data["n_speakers"], **config["model"]).eval()
        weights = torch.load(root / "openvoice/checkpoint.pth", map_location="cpu", weights_only=True)
        self.model.load_state_dict(weights["model"], strict=True)
        base = root / "voices/cadu/pt_BR-cadu-medium.onnx"
        base_config = json.loads(Path(str(base) + ".json").read_text())
        if base_config.get("espeak", {}).get("voice") != "pt-br":
            raise ValueError("O pronunciador precisa ser português brasileiro")
        options = ort.SessionOptions()
        options.intra_op_num_threads, options.inter_op_num_threads = 2, 1
        self.piper = PiperVoice(config=PiperConfig.from_dict(base_config), session=ort.InferenceSession(
            str(base), sess_options=options, providers=["CPUExecutionProvider"]))
        self.window = torch.hann_window(self.data["win_length"])
        reference = (root / "cloning/reference.wav").read_bytes()
        self.target = self.embed(self.read_pcm(reference))
        self.source = self.embed(self.read_pcm(self.base_audio(
            "O relógio está pronto. Quatro Braços corre rápido e protege a cidade.")))
        # Include both the reference and models in the persistent WAV cache key.
        digest = hashlib.sha256(reference)
        for file in [root / "openvoice/config.json", root / "openvoice/checkpoint.pth", base, Path(str(base) + ".json")]:
            with file.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
        self.namespace = digest.hexdigest()

    def read_pcm(self, data):
        np = self.np
        with wave.open(io.BytesIO(data), "rb") as wav:
            rate, channels = wav.getframerate(), wav.getnchannels()
            if wav.getsampwidth() != 2 or channels not in (1, 2):
                raise ValueError("Áudio precisa ser PCM16 mono ou estéreo")
            signal = np.frombuffer(wav.readframes(wav.getnframes()), dtype="<i2").astype(np.float32) / 32768
        if channels == 2:
            signal = signal.reshape(-1, 2).mean(1)
        if rate != self.rate:
            signal = np.interp(np.arange(round(len(signal) * self.rate / rate)) * rate / self.rate,
                               np.arange(len(signal)), signal).astype(np.float32)
        if len(signal) < 1024 or not np.isfinite(signal).all():
            raise ValueError("Áudio de entrada incompleto")
        return self.torch.from_numpy(signal.copy())[None]

    def spectrum(self, signal):
        t, d = self.torch, self.data
        pad = (d["filter_length"] - d["hop_length"]) // 2
        signal = t.nn.functional.pad(signal[:, None], (pad, pad), mode="reflect")[:, 0]
        value = t.stft(signal, d["filter_length"], hop_length=d["hop_length"],
                       win_length=d["win_length"], window=self.window, center=False,
                       normalized=False, onesided=True, return_complex=True)
        return t.sqrt(value.real.square() + value.imag.square() + 1e-6)

    def embed(self, signal):
        with self.torch.inference_mode():
            return self.model.ref_enc(self.spectrum(signal).transpose(1, 2)).unsqueeze(-1)

    def base_audio(self, text):
        output = io.BytesIO()
        with wave.open(output, "wb") as wav:
            self.piper.synthesize_wav(text, wav)
        return output.getvalue()

    def synthesize_wav(self, text, wav):
        started = time.monotonic()
        t, np = self.torch, self.np
        spectrum = self.spectrum(self.read_pcm(self.base_audio(text)))
        with t.inference_mode():
            converted = self.model.voice_conversion(spectrum, t.LongTensor([spectrum.size(-1)]),
                        sid_src=self.source, sid_tgt=self.target, tau=0.3)[0][0, 0].numpy()
        if not np.isfinite(converted).all() or not len(converted) or np.max(np.abs(converted)) < 0.003:
            raise ValueError("Clonador produziu áudio vazio ou silencioso")
        pcm = (np.clip(converted, -1, 1) * 32767).astype("<i2")
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(self.rate)
        wav.writeframes(pcm.tobytes())
        print(json.dumps({"engine": "openvoice", "generationSeconds": round(time.monotonic() - started, 3),
                          "audioSeconds": round(len(converted) / self.rate, 3)}, ensure_ascii=False), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--port", type=int, default=8082)
    parser.add_argument("--build-id")
    parser.add_argument("--preview", type=Path)
    parser.add_argument("--text", default="Oi, equipe! Quatro Braços corre rápido. O relógio está carregado.")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Porta inválida")
    voice = ReferenceVoice(args.root)
    if args.preview:
        with wave.open(str(args.preview), "wb") as wav:
            voice.synthesize_wav(args.text, wav)
        return
    server = make_server(voice, args.port, model_name="OpenVoiceV2-Ben-pt_BR", build_id=args.build_id,
                         preview_path=args.root / "openvoice/preview.wav", cache_dir=args.root / "voice-cache",
                         namespace=voice.namespace)
    print(f"Clone leve pronto em 127.0.0.1:{args.port}; mesma referência do Ben", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
