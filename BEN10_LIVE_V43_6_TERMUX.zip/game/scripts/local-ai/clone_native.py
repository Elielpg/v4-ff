"""Rebuild only the native clone engine with portable CPU instructions."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import shlex
import subprocess
import tempfile

PROFILE = "ben10-capabilities-v2"
REVISION = "b3ba14077cf1b3e11b86e5f84aa9184605c89b28"
GGML_REVISION = "3af5f5760e19a96427f5f7a93b79cbdf3d4b265b"


def arm_hwcap():
    if platform.machine().lower() not in ("aarch64", "arm64"):
        return 0
    try:
        getauxval = ctypes.CDLL(None).getauxval
        getauxval.argtypes = [ctypes.c_ulong]
        getauxval.restype = ctypes.c_ulong
        return int(getauxval(16))  # AT_HWCAP, reported by the Android/Linux loader.
    except (OSError, AttributeError):
        return 0


def cpu_profile(machine=None, hwcap=None):
    machine = (machine or platform.machine()).lower()
    if machine in ("aarch64", "arm64"):
        caps = arm_hwcap() if hwcap is None else hwcap
        if os.environ.get("BEN10_CLONE_BASELINE") != "1" and caps & (1 << 9) and caps & (1 << 10):
            return "aarch64", "-march=armv8-a+fp16" + ("+dotprod" if caps & (1 << 20) else "")
        return "aarch64", "-march=armv8-a"
    if machine in ("x86_64", "amd64"):
        return "x86_64", "-march=x86-64 -mtune=generic"
    raise ValueError("Arquitetura não suportada pelo perfil de reparo: " + machine)


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def portable_ready(root):
    root = Path(root)
    try:
        record = json.loads((root / "cloning/native-build.json").read_text())
        machine, flags = cpu_profile()
        if record.get("profile") != PROFILE or record.get("machine") != machine or record.get("flags") != flags:
            return False
        files = record.get("files", {})
        if "qwen3-tts.cpp/build/libqwen3tts.so" not in files:
            return False
        for name, expected in files.items():
            relative = Path(name)
            if relative.is_absolute() or ".." in relative.parts or not (root / relative).is_file() or digest(root / relative) != expected:
                return False
        return True
    except (OSError, ValueError, TypeError, AttributeError):
        return False


def patch_native_flags(text):
    # Upstream appends these even when CMAKE_CXX_FLAGS was explicitly supplied.
    return re.sub(r"-(?:march|mcpu|mtune)=native\b", "", text)


def build_commands(source, flags, cmake="cmake"):
    source = Path(source)
    common = ["-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
              "-DCMAKE_C_FLAGS=" + flags, "-DCMAKE_CXX_FLAGS=" + flags,
              "-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG", "-DCMAKE_CXX_FLAGS_RELEASE=-O3 -DNDEBUG"]
    x86 = ["-DGGML_AVX=OFF", "-DGGML_AVX2=OFF", "-DGGML_AVX512=OFF", "-DGGML_FMA=OFF", "-DGGML_F16C=OFF", "-DGGML_SSSE3=OFF"] if flags.startswith("-march=x86-64") else []
    return [
        [cmake, "--fresh", "-S", str(source / "ggml"), "-B", str(source / "ggml/build"), *common,
         "-DGGML_NATIVE=OFF", "-DGGML_CPU_ARM_ARCH=" + flags.split()[0].split("=", 1)[1], "-DGGML_CPU_KLEIDIAI=OFF",
         "-DGGML_CPU_ALL_VARIANTS=OFF", "-DGGML_BACKEND_DL=OFF", "-DGGML_METAL=OFF",
         "-DGGML_OPENMP=OFF", "-DGGML_BUILD_TESTS=OFF", "-DGGML_BUILD_EXAMPLES=OFF", *x86],
        [cmake, "--build", str(source / "ggml/build"), "--parallel", "4"],
        [cmake, "--fresh", "-S", str(source), "-B", str(source / "build"), *common,
         "-DQWEN3_TTS_COREML=OFF"],
        [cmake, "--build", str(source / "build"), "--target", "qwen3tts_shared", "--parallel", "4"],
    ]


def check_compile_commands(source, machine, flags=None):
    expected_flags = flags or cpu_profile(machine)[1]
    expected_arch = expected_flags.split()[0]
    commands = []
    for directory in [Path(source) / "build", Path(source) / "ggml/build"]:
        records = json.loads((directory / "compile_commands.json").read_text())
        for record in records:
            command = record.get("command") or " ".join(record.get("arguments", []))
            if re.search(r"-(?:march|mcpu|mtune)=native\b", command):
                raise ValueError("A compilação ainda contém otimização nativa")
            if machine == "aarch64":
                tokens = shlex.split(command)
                architectures = [token for token in tokens if token.startswith("-march=")]
                if not architectures or any(token != expected_arch for token in architectures) or any(token.startswith("-mcpu=") for token in tokens):
                    raise ValueError("A compilação ARM contém instruções fora do perfil confirmado pelo Android")
            commands.append(command)
    if not commands:
        raise ValueError("Não foi possível conferir os comandos da compilação")
    return len(commands)


def rebuild(root, run=subprocess.run, machine=None, cmake="cmake", verify_source=True):
    root = Path(root).resolve(); source = root / "qwen3-tts.cpp"
    machine, flags = cpu_profile(machine)
    if not (source / "CMakeLists.txt").is_file() or not (source / "ggml/CMakeLists.txt").is_file():
        raise ValueError("Fontes nativas ausentes. Complete bash local-ai.sh clone install")
    if verify_source:
        for directory, expected in [(source, REVISION), (source / "ggml", GGML_REVISION)]:
            actual = subprocess.check_output(["git", "-C", str(directory), "rev-parse", "HEAD"], text=True).strip()
            if actual != expected:
                raise ValueError("A revisão das fontes mudou; nenhum arquivo foi recompilado")
    folder = root / "cloning"; folder.mkdir(parents=True, exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix="native-before-repair-", dir=folder))
    cmake_file = source / "CMakeLists.txt"
    shutil.copyfile(cmake_file, backup / "CMakeLists.txt")
    for label, directory in [("engine", source / "build"), ("ggml", source / "ggml/build")]:
        for name in ["CMakeCache.txt", "compile_commands.json"]:
            if (directory / name).is_file():
                shutil.copyfile(directory / name, backup / (label + "-" + name))
    cmake_file.write_text(patch_native_flags(cmake_file.read_text()))
    print("Reconstruindo somente o motor da voz:", flags, flush=True)
    print("Modelos GGUF, referência, chaves e motor de conversa serão preservados.", flush=True)
    environment = {**os.environ, "QWEN3_TTS_BACKEND": "cpu"}
    for command in build_commands(source, flags, cmake):
        run(command, check=True, env=environment)
    checked = check_compile_commands(source, machine, flags)
    binaries = [source / "build/libqwen3tts.so"]
    binaries += sorted((source / "ggml/build/src").glob("lib*.so*"))
    if any(not binary.is_file() for binary in binaries):
        raise ValueError("A reconstrução não gerou todas as bibliotecas")
    record = {"profile": PROFILE, "machine": machine, "flags": flags,
              "revision": REVISION, "ggmlRevision": GGML_REVISION, "commandsChecked": checked,
              "files": {str(file.relative_to(root)): digest(file) for file in binaries}}
    temp = folder / "native-build.json.tmp"; temp.write_text(json.dumps(record, indent=2))
    os.replace(temp, folder / "native-build.json")
    print("Motor portátil reconstruído. Opções antigas guardadas em", backup, flush=True)
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    args = parser.parse_args()
    try:
        rebuild(args.root)
    except Exception as error:
        raise SystemExit("Motor não reparado: " + str(error))
