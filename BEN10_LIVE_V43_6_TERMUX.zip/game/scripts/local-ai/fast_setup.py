"""Prepare and measure the light reference clone before changing selection."""
import argparse
import array
import hashlib
import json
import math
import os
import subprocess
import time
import wave
from pathlib import Path

from clone_voice import configure_reference
from download_models import download, voice_plan, VOICE_REPO

REPO = "myshell-ai/OpenVoiceV2"
REVISION = "f36e7edfe1684461a8343844af60babc2efbb727"
FILES = [
    {"rfilename": "converter/checkpoint.pth", "size": 131320490,
     "lfs": {"size": 131320490, "sha256": "9652c27e92b6b2a91632590ac9962ef7ae2b712e5c5b7f4c34ec55ee2b37ab9e"}},
    {"rfilename": "converter/config.json", "size": 838,
     "blobId": "3e33566b0d976167bd5f15801ef7005d59143e2f"},
]


def validate_preview(file):
    with wave.open(str(file), "rb") as wav:
        if wav.getsampwidth() != 2 or wav.getnchannels() != 1 or not 8000 <= wav.getframerate() <= 48000:
            raise ValueError("Formato inválido no teste real do clonador")
        duration = wav.getnframes() / wav.getframerate()
        pcm = array.array("h", wav.readframes(wav.getnframes()))
    if not 1 <= duration <= 30 or not pcm or max(map(abs, pcm)) < 120:
        raise ValueError("O teste do clone ficou silencioso ou incompleto")
    return {"audioSeconds": duration, "rmsDb": 20 * math.log10(max(1e-12,
            math.sqrt(sum(x*x for x in pcm) / len(pcm)) / 32768)),
            "sha256": hashlib.sha256(Path(file).read_bytes()).hexdigest()}


def select_after_preview(root, previous, preview, elapsed, python=None):
    details = validate_preview(preview)
    if elapsed > 60:
        raise ValueError("O clone leve levou mais de 60 segundos no teste. A seleção anterior foi mantida")
    file = root / "install.json"
    if file.read_bytes() != previous:
        raise ValueError("A configuração mudou durante o teste; nenhuma seleção foi sobrescrita")
    manifest = json.loads(previous)
    manifest.update(voiceEngine="openvoice", voiceModel=str((root / "voices/cadu/pt_BR-cadu-medium.onnx").resolve()),
                    cloneRepo=REPO, cloneRevision=REVISION)
    if python:
        manifest["openvoicePython"] = str(Path(python).absolute())
    else:
        manifest.pop("openvoicePython", None)
    details.update(engine="openvoice", measuredSeconds=round(elapsed, 3),
                   referenceSha256=hashlib.sha256((root / "cloning/reference.wav").read_bytes()).hexdigest())
    backup = root / "openvoice" / ("selection-before-" + str(time.time_ns()) + ".json")
    backup.write_bytes(previous)
    (root / "openvoice/preview.json").write_text(json.dumps(details, indent=2))
    temp = file.with_suffix(".json.tmp")
    temp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    os.replace(temp, file)
    return details


def prepare(root, game, python=None):
    root, game = root.resolve(), game.resolve()
    file = root / "install.json"
    if not file.is_file():
        raise ValueError("Instale primeiro a IA: bash local-ai.sh install")
    previous = file.read_bytes()
    (root / "openvoice").mkdir(parents=True, exist_ok=True)
    print("Preparando clone leve OpenVoice V2 + pronúncia pt-BR. A voz final usa a amostra do Ben.", flush=True)
    for record in FILES:
        download(REPO, REVISION, record, root / "openvoice" / Path(record["rfilename"]).name)
    info, files = voice_plan("cadu")
    for name, record in files:
        download(VOICE_REPO, info["sha"], record, root / "voices/cadu" / name)
    reference = root / "cloning/reference.wav"
    if not reference.is_file():
        reference.parent.mkdir(parents=True, exist_ok=True)
        details = configure_reference(game / "assets/voice/ben-classico-reference.wav", reference)
        (root / "cloning/config.json").write_text(json.dumps(details))
    # These dependencies already exist after the original Qwen conversion.
    # Reuse that venv; never install a second copy of PyTorch on the phone.
    common = ["proot-distro", "login", "--bind", str(root) + ":/ben10-data", "--bind",
              str(game / "scripts/local-ai") + ":/opt/ben10-worker", "ben10-ai", "--"]
    if python:
        worker = [str(python), str(game / "scripts/local-ai/openvoice_voice.py"), "--root", str(root)]
        preview_arg = str(root / "openvoice/preview.wav")
    else:
        subprocess.run(common + ["/bin/bash", "-lc", "set -euo pipefail\n"
            "test -x /opt/ben10-clone-convert/bin/python || python3 -m venv /opt/ben10-clone-convert\n"
            "/opt/ben10-clone-convert/bin/pip install --disable-pip-version-check --only-binary=:all: "
            "-r /opt/ben10-worker/fast-voice-requirements.txt"], check=True)
        worker = common + ["/opt/ben10-clone-convert/bin/python", "/opt/ben10-worker/openvoice_voice.py", "--root", "/ben10-data"]
        preview_arg = "/ben10-data/openvoice/preview.wav"
    subprocess.run(["node", str(game / "scripts/local-ai/restart.js"), "--stop"],
                   cwd=game, env={**os.environ, "BEN10_LOCAL_ROOT": str(root)}, check=True)
    print("Gerando uma fala real. A troca só será feita se o teste terminar com áudio válido.", flush=True)
    preview = root / "openvoice/preview.wav"
    preview.unlink(missing_ok=True)
    started = time.monotonic()
    subprocess.run(worker + ["--preview", preview_arg], check=True, timeout=120)
    details = select_after_preview(root, previous, preview, time.monotonic() - started, python)
    print("Clone leve selecionado. Teste:", json.dumps(details, ensure_ascii=False), flush=True)
    print("Os modelos Qwen e a referência foram preservados. Inicie: bash restart.sh", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--game", type=Path, required=True)
    parser.add_argument("--python", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        prepare(args.root, args.game, args.python)
    except Exception as error:
        raise SystemExit("Clone leve não selecionado; seleção anterior preservada: " + str(error))
