import {chromium} from 'playwright-core';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,cp,symlink,writeFile,readFile,rm,mkdir} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {wav} from '../server/core.js';
const temp=await mkdtemp(path.join(os.tmpdir(),'ben433-audio-')),report={version:'43.5.0',errors:[],limits:'Worker HTTP Python de produção com síntese de tom simulada de 12s, acima do timeout legado de 10s. Verifica a entrega Python→Node→Chrome, retomada após conexão perdida e reprodução WebAudio com autoplay restrito; não mede timbre ou inferência real no Android.'};
let game,browser,voiceWorker,voiceUp=true,previews=0;const voiceCache=path.join(temp,'voice-cache');
const pcm=Buffer.alloc(48000);for(let i=0;i<24000;i++)pcm.writeInt16LE(Math.round(Math.sin(i/24000*440*Math.PI*2)*4000),i*2);const audio=wav(pcm);
const llm=http.createServer((req,res)=>res.end(JSON.stringify({status:'ok'})));
const bind=server=>new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));await bind(llm);
voiceWorker=spawn('python3',[path.resolve('tests/fixtures/slow-local-voice.py'),'--worker-dir',path.resolve('scripts/local-ai'),'--cache-dir',voiceCache,'--delay','12'],{stdio:['ignore','pipe','pipe']});
const ready=await Promise.race([once(voiceWorker.stdout,'data'),once(voiceWorker,'exit').then(()=>{throw Error('Voice fixture failed');})]);const voicePort=JSON.parse(ready[0].toString()).port;
const synthesisCount=async()=>{try{return (await readFile(path.join(voiceCache,'calls.jsonl'),'utf8')).trim().split('\n').filter(Boolean).length;}catch{return 0;}};

try{
 await cp('server',path.join(temp,'server'),{recursive:true});await cp('public',path.join(temp,'public'),{recursive:true});await symlink(path.resolve('node_modules'),path.join(temp,'node_modules'),'dir');await writeFile(path.join(temp,'package.json'),'{"type":"module"}');
 const port=45000+Math.floor(Math.random()*8000),base='http://127.0.0.1:'+port;
 game=spawn(process.execPath,['server/index.js'],{cwd:temp,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await Promise.race([once(game.stdout,'data'),once(game,'exit').then(()=>{throw Error('Game failed to start');})]);
 const post=async(route,body)=>{const res=await fetch(base+'/api/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});assert(res.ok);return res.json();};
 await post('config',{conversationProvider:'local',voiceProvider:'local',hostSpeech:false,quality:'economy',localAi:{textPort:llm.address().port,voicePort,voiceTimeoutSeconds:10}});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=document-user-activation-required']});
 const page=await browser.newPage({viewport:{width:412,height:915}});let dropped=false;await page.route('**/api/tts-jobs/*',async route=>{if(!dropped){dropped=true;await route.abort('connectionreset');}else await route.continue();});await page.route('**/api/local-ai/health',async route=>{if(!voiceUp)await route.fulfill({contentType:'application/json',body:JSON.stringify({text:{state:'ready'},voice:{state:'offline'}})});else await route.continue();});page.on('pageerror',e=>report.errors.push(e.message));
 await page.addInitScript(()=>{window.deviceVoiceCalls=0;if('speechSynthesis'in window)speechSynthesis.speak=()=>{window.deviceVoiceCalls++;throw Error('Device TTS forbidden');};});
 await page.goto(base);await page.waitForFunction(()=>window.benArena);await page.locator('#enter-game').click();await page.waitForFunction(()=>window.linelAudio.enabled&&window.linelAudio.ctx.state==='running');report.entryTapUnlocks=true;assert.equal(await page.locator('#build-version').textContent(),'V43.5');
 await page.evaluate(()=>{window.peakMouth=0;const world=window.linelWorld;const original=world.setMouthOpen.bind(world);world.setMouthOpen=value=>{window.peakMouth=Math.max(window.peakMouth,value);original(value);};});
 await post('event',{type:'comment',user:'Ana',text:'oi'});await page.waitForFunction(()=>document.querySelector('#subtitles').textContent.includes('Ana'));
 await page.locator('#panel-toggle').click();await page.locator('[data-tab="audio"]').click();await page.locator('#test-saved-voice').click();await page.waitForFunction(()=>document.querySelector('#voice-diagnostic').textContent.includes('Teste salvo reproduzido'),null,{timeout:6000});report.savedPreviewWorksDuringPendingSynthesis=true;assert.equal(await synthesisCount(),1);await page.locator('#close').click();
 await page.waitForFunction(()=>window.linelAudio.speaking,null,{timeout:20000});assert((await fetch(base+'/api/health').then(r=>r.json())).queue.active);await page.waitForFunction(()=>!window.linelAudio.speaking);await page.waitForTimeout(400);assert((await page.evaluate(()=>window.peakMouth))>.05);assert.equal((await fetch(base+'/api/health').then(r=>r.json())).queue.active,null);report.delayedSpeechPlaysWithRestrictedAutoplay=true;report.generationLongerThanLegacyTimeout=true;report.interruptedPollResumed=dropped;assert.equal(await synthesisCount(),1);report.ackAfterAudioEnds=true;
 await page.evaluate(()=>window.linelAudio.ctx.suspend());await page.locator('#sound').click();await page.waitForFunction(()=>window.linelAudio.ctx.state==='running');report.suspendedContextResumesOnTap=true;
 await page.locator('#panel-toggle').click();await page.locator('[data-tab="audio"]').click();const before=await synthesisCount();await page.locator('#test-saved-voice').click();await page.waitForFunction(()=>document.querySelector('#voice-diagnostic').textContent.includes('Teste salvo reproduzido'));assert.equal(await synthesisCount(),before);report.preparedPreviewNeedsNoSynthesis=true;await page.locator('#close').click();
 voiceUp=false;await page.waitForFunction(()=>!document.querySelector('#voice-service-status').hidden,null,{timeout:15000});assert((await page.locator('#voice-service-status').textContent()).includes('bash local-ai.sh start'));report.offlineServiceIsVisible=true;
 voiceUp=true;await page.waitForFunction(()=>document.querySelector('#voice-service-status').hidden,null,{timeout:15000});assert.equal(await page.evaluate(()=>window.deviceVoiceCalls),0);report.noDeviceVoiceFallback=true;
 await mkdir('reports/v43_5',{recursive:true});await page.screenshot({path:'reports/v43_5/audio-412.png'});assert.deepEqual(report.errors,[]);report.synthesisRequests=await synthesisCount();const direct=await fetch(base+'/api/local-ai/preview-audio');assert.equal(direct.status,200);assert.equal(Buffer.from(await direct.arrayBuffer()).toString('ascii',0,4),'RIFF');report.inGameDirectPlayerHasWav=true;assert.equal(await synthesisCount(),1);console.log(JSON.stringify(report,null,2));
}finally{await mkdir('reports/v43_5',{recursive:true});await writeFile('reports/v43_5/audio-results.json',JSON.stringify(report,null,2));await browser?.close();if(game?.exitCode===null){game.kill();await once(game,'exit');}if(voiceWorker?.exitCode===null){voiceWorker.kill();await once(voiceWorker,'exit');}llm.closeAllConnections();llm.close();await rm(temp,{recursive:true,force:true});}
