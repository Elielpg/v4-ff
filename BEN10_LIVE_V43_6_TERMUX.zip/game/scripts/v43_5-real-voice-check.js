import {chromium} from 'playwright-core';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtemp,cp,symlink,writeFile,readFile,mkdir,rm} from 'node:fs/promises';
import path from 'node:path';import os from 'node:os';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {BUILD_ID} from '../public/release.js';
const temp=await mkdtemp(path.join(os.tmpdir(),'ben-real-game-')),port=58130,base='http://127.0.0.1:'+port;let server,browser;
const report={version:BUILD_ID,realModel:'Qwen/Qwen3-TTS-12Hz-0.6B-Base',reference:'Áudio fornecido pelo usuário',voicePort:58082,limits:'Inferência CPU e reprodução automatizada no Chromium Linux; não mede saída física nem desempenho no Android.'};
try{
 for(const folder of ['server','public'])await cp(folder,path.join(temp,folder),{recursive:true});await symlink(path.resolve('node_modules'),path.join(temp,'node_modules'),'dir');await writeFile(path.join(temp,'package.json'),'{"type":"module"}');
 server=spawn(process.execPath,['server/index.js'],{cwd:temp,env:{...process.env,PORT:String(port),GEMINI_API_KEY:'',GOOGLE_API_KEY:'',ELEVENLABS_API_KEY:''},stdio:['ignore','pipe','pipe']});await Promise.race([once(server.stdout,'data'),once(server,'exit').then(()=>{throw Error('Game failed');})]);
 await fetch(base+'/api/config',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({voiceProvider:'local',conversationProvider:'gemini',hostSpeech:false,quality:'economy',localAi:{voicePort:58082,textPort:58081}})});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=document-user-activation-required']});const page=await browser.newPage({viewport:{width:412,height:915}});
 await page.goto(base);await page.waitForFunction(()=>window.linelWorld?.imported?.formId==='base'&&document.querySelector('#voice-provider').value==='local');await page.locator('#enter-game').click();
 const playback=await page.evaluate(async()=>{let peak=0;const w=window.linelWorld,original=w.setMouthOpen.bind(w);w.setMouthOpen=v=>{peak=Math.max(peak,v);original(v);};await window.linelAudio.speak('Oi, Ana!','base');return {peak,context:window.linelAudio.ctx.state,diagnostic:document.querySelector('#voice-diagnostic').textContent};});
 assert(playback.peak>.05,JSON.stringify(playback));assert.equal(playback.context,'running');assert(playback.diagnostic.includes('Qwen3-TTS-0.6B-clone-pt'));
 report.realCloneReproducedInGame=true;report.playback=playback;report.inference=JSON.parse(await readFile('/tmp/ben-real-clone/verified-result.json','utf8'));report.audioSha256=createHash('sha256').update(await readFile('/tmp/ben-real-clone/real-oi-ana.wav')).digest('hex');
 await mkdir('reports/v43_5',{recursive:true});await page.screenshot({path:'reports/v43_5/real-clone-412.png'});console.log(JSON.stringify(report,null,2));
}finally{await mkdir('reports/v43_5',{recursive:true});await writeFile('reports/v43_5/real-model.json',JSON.stringify(report,null,2));await browser?.close();if(server?.exitCode===null){server.kill();await once(server,'exit');}await rm(temp,{recursive:true,force:true});}
