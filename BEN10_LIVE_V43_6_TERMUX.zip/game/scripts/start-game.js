import {readFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';
import {localHealth} from '../server/local-ai.js';

export function startupTarget(config,installed,health) {
 return installed&&config.conversationProvider==='local'&&config.voiceProvider==='local'?'local-ai':'game';
}

async function main(){
 const root=fileURLToPath(new URL('../',import.meta.url));let config={};
 try{config=JSON.parse(await readFile(path.join(root,'data/config.json'),'utf8'));}catch{}
 const installed=existsSync(path.join(process.env.BEN10_LOCAL_ROOT||path.join(os.homedir(),'.local/share/ben10-local-ai'),'install.json'));
 const health=installed&&config.conversationProvider==='local'&&config.voiceProvider==='local'?await localHealth(config.localAi):null;
 const target=startupTarget(config,installed,health);
 if(target==='local-ai')console.log('IA local selecionada: iniciando conversa, voz e jogo. Mantenha esta sessão aberta.');
 const args=[...(existsSync(path.join(root,'.env'))?['--env-file=.env']:[]),...(target==='local-ai'?['scripts/local-ai/restart.js','--ensure','--local']:['server/index.js'])];
 const child=spawn(process.execPath,args,{cwd:root,stdio:'inherit',env:process.env});
 for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>child.kill(signal));
 child.once('error',error=>{console.error(error.message);process.exitCode=1;});
 child.once('exit',(code,signal)=>{process.exitCode=code??(signal==='SIGINT'?0:1);});
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error(error.message);process.exitCode=1;});
