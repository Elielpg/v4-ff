import {chromium} from 'playwright-core';
import assert from 'node:assert/strict';
import {writeFile,mkdir} from 'node:fs/promises';
import {BUILD_ID} from '../public/release.js';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--autoplay-policy=document-user-activation-required']});
const report={version:BUILD_ID,limits:'Teste funcional da página de diagnóstico com worker real. A captura da saída do jogo é verificada separadamente em full-audio.json e captured-speech-asr.json.'};
try{
 const page=await browser.newPage({viewport:{width:412,height:915},isMobile:true,hasTouch:true}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:58500/sound-test.html');await page.waitForFunction(()=>document.querySelector('#status').textContent.includes('Servidor'));
 const saved=await page.request.get('http://127.0.0.1:58500/audio-test/ben-test.wav');assert.equal(saved.headers()['content-type'],'audio/wav');assert.equal((await saved.body()).toString('ascii',0,4),'RIFF');
 await page.locator('#play-known').tap();await page.waitForFunction(()=>document.querySelector('#known-audio').ended);await page.locator('#heard-known').tap();report.savedPlayerCompleted=true;
 await page.locator('#phrase').fill('Quatro Braços corre rápido. O relógio está carregado.');await page.locator('#generate').tap();await page.waitForFunction(()=>!document.querySelector('#play-generated').disabled,null,{timeout:60000});
 assert(await page.locator('#generated-audio').isVisible());assert(await page.locator('#generated-audio').evaluate(a=>a.paused));report.manualPlayWaitsForGesture=true;
 await page.locator('#play-generated').tap();await page.waitForFunction(()=>document.querySelector('#generated-audio').ended,null,{timeout:20000});
 const result=JSON.parse(await page.locator('#report').inputValue());assert.equal(result.voice.ended,true);assert.equal(result.voice.model,'OpenVoiceV2-Ben-pt_BR');assert.equal(result.providers.voice,'local');assert.deepEqual(errors,[]);report.actualCloneResult=result;report.errors=errors;
 await page.screenshot({path:'reports/v43_6/diagnostic-412.png',fullPage:true});console.log(JSON.stringify(report,null,2));
}finally{await mkdir('reports/v43_6',{recursive:true});await writeFile('reports/v43_6/diagnostic.json',JSON.stringify(report,null,2));await browser.close();}
