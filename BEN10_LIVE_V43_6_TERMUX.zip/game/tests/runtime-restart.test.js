import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,symlink,writeFile,mkdir,chmod,rm} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import http from 'node:http';
import path from 'node:path';
import os from 'node:os';
import {BUILD_ID} from '../public/release.js';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function port(){const s=http.createServer();await new Promise(r=>s.listen(0,'127.0.0.1',r));const p=s.address().port;await new Promise(r=>s.close(r));return p;}

test('reinício substitui servidor e voz antigos, preserva processos externos e não duplica sessão saudável',{timeout:30000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben-stale-runtime-')),game=path.join(temp,'game'),local=path.join(temp,'local');let first,next,outsider;
 const ports=[await port(),await port(),await port()],base='http://127.0.0.1:'+ports[2];let log='';
 try{
  await mkdir(game,{recursive:true});for(const folder of ['public','server','scripts'])await cp(folder,path.join(game,folder),{recursive:true});for(const file of ['start.sh','local-ai.sh'])await cp(file,path.join(game,file));await symlink(path.resolve('node_modules'),path.join(game,'node_modules'),'dir');await writeFile(path.join(game,'package.json'),'{"type":"module"}');
  await writeFile(path.join(game,'public/release.js'),"export const BUILD_ID='43.3.0';export const BUILD_LABEL='old fixture';");
  await mkdir(path.join(game,'data'),{recursive:true});await writeFile(path.join(game,'data/config.json'),JSON.stringify({conversationProvider:'local',voiceProvider:'local',hostSpeech:false,localAi:{textPort:ports[0],voicePort:ports[1]}}));
  for(const folder of ['llama.cpp/build/bin','qwen3-tts.cpp/build','cloning'])await mkdir(path.join(local,folder),{recursive:true});
  await writeFile(path.join(local,'install.json'),JSON.stringify({textModel:path.join(local,'text.gguf'),voiceModel:path.join(local,'voice.onnx'),voiceEngine:'qwen3-clone'}));for(const file of ['text.gguf','cloning/config.json','cloning/reference.wav','qwen3-tts.cpp/build/libqwen3tts.so'])await writeFile(path.join(local,file),'fixture');
  const llama=path.join(local,'llama.cpp/build/bin/llama-server');await writeFile(llama,`#!/usr/bin/env node\nconst http=require('node:http');const port=Number(process.argv[process.argv.indexOf('--port')+1]);http.createServer((q,s)=>s.end(JSON.stringify({status:'ok'}))).listen(port,'127.0.0.1');`);await chmod(llama,0o755);
  await writeFile(path.join(game,'scripts/local-ai/clone_voice.py'),`import argparse,json\nfrom http.server import BaseHTTPRequestHandler,HTTPServer\np=argparse.ArgumentParser();p.add_argument('--root');p.add_argument('--port',type=int);p.add_argument('--build-id');a=p.parse_args()\nclass H(BaseHTTPRequestHandler):\n def do_GET(self):\n  self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'ready':True,'model':'Qwen3-TTS-fixture','provider':'qwen3-clone','jobsSupported':True,'build':a.build_id}).encode())\nHTTPServer(('127.0.0.1',a.port),H).serve_forever()\n`);
  // Same UID and cwd, but a different entry point: the restart must leave it alive.
  await writeFile(path.join(game,'unrelated.js'),'setInterval(()=>{},1000);');outsider=spawn(process.execPath,['unrelated.js'],{cwd:game,stdio:'ignore'});
  const env={...process.env,BEN10_LOCAL_ROOT:local,PORT:String(ports[2])};
  const start=()=>{const p=spawn('bash',['local-ai.sh','start'],{cwd:game,env,stdio:['ignore','pipe','pipe']});for(const stream of [p.stdout,p.stderr])stream.on('data',b=>log+=b);return p;};
  const ready=async build=>{for(let i=0;i<120;i++){try{const h=await fetch(base+'/api/health').then(r=>r.json()),v=await fetch('http://127.0.0.1:'+ports[1]+'/health').then(r=>r.json());if(h.build===build&&v.build===build&&log.includes('Conversa e voz locais prontas'))return h;}catch{}await pause(100);}throw Error(log);};
  first=start();const old=await ready('43.3.0');await cp('public/release.js',path.join(game,'public/release.js'));
  next=start();const current=await ready(BUILD_ID);assert.notEqual(current.runtime.pid,old.runtime.pid);assert.equal(current.build,BUILD_ID);assert(log.includes('Servidor antigo detectado'));process.kill(outsider.pid,0);
  for(let i=0;i<30&&first.exitCode===null;i++)await pause(50);assert.notEqual(first.exitCode,null);
  const unchangedPid=current.runtime.pid;const duplicate=start();const [exit]=await once(duplicate,'exit');assert.equal(exit,0,log);assert.equal((await fetch(base+'/api/health').then(r=>r.json())).runtime.pid,unchangedPid);process.kill(outsider.pid,0);
 }finally{
  for(const child of [first,next])if(child?.exitCode===null){child.kill('SIGTERM');await once(child,'exit');}
  if(outsider?.exitCode===null){outsider.kill();await once(outsider,'exit');}await rm(temp,{recursive:true,force:true});
 }
});

test('porta ocupada por programa externo é preservada e bloqueia o reinício local',{timeout:15000},async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'ben-unknown-port-')),game=path.join(temp,'game'),local=path.join(temp,'local'),voicePort=await port();let external,restart;
 try{
  await mkdir(game,{recursive:true});for(const folder of ['public','server','scripts'])await cp(folder,path.join(game,folder),{recursive:true});await writeFile(path.join(game,'package.json'),'{"type":"module"}');await mkdir(path.join(game,'data'),{recursive:true});await writeFile(path.join(game,'data/config.json'),JSON.stringify({conversationProvider:'local',voiceProvider:'local',localAi:{textPort:await port(),voicePort}}));await mkdir(local,{recursive:true});await writeFile(path.join(local,'install.json'),'{}');
  await writeFile(path.join(game,'external-service.js'),`import http from 'node:http';http.createServer((q,s)=>s.end('{}')).listen(${voicePort},'127.0.0.1',()=>console.log('ready'));`);external=spawn(process.execPath,['external-service.js'],{cwd:game,stdio:['ignore','pipe','pipe']});await once(external.stdout,'data');
  restart=spawn(process.execPath,['scripts/local-ai/restart.js','--local'],{cwd:game,env:{...process.env,BEN10_LOCAL_ROOT:local,PORT:String(await port())},stdio:['ignore','pipe','pipe']});let output='';for(const stream of [restart.stdout,restart.stderr])stream.on('data',b=>output+=b);const [code]=await once(restart,'exit');assert.equal(code,1,output);assert(output.includes('serviço não confirmado'),output);process.kill(external.pid,0);assert.equal((await fetch('http://127.0.0.1:'+voicePort).then(r=>r.text())),'{}');
 }finally{if(restart?.exitCode===null){restart.kill();await once(restart,'exit');}if(external?.exitCode===null){external.kill();await once(external,'exit');}await rm(temp,{recursive:true,force:true});}
});
