import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';

test('clone leve só troca a seleção após áudio real válido; falha e lentidão preservam a seleção',()=>{
 const r=spawnSync('python3',['tests/fast_clone_py_test.py'],{encoding:'utf8',timeout:10000});
 assert.equal(r.status,0,r.stdout+r.stderr);
});
