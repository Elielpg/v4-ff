import http.client
import io
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
import wave
sys.path.insert(0, str(Path('scripts/local-ai').resolve()))
from tts_server import make_server
from voice_jobs import VoiceJobs


def audio_bytes():
    out=io.BytesIO()
    with wave.open(out,'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(24000);wav.writeframes(b'\x20\x00'*2400)
    return out.getvalue()


class JobsTests(unittest.TestCase):
    def test_http_job_survives_disconnected_client_and_restart_without_second_synthesis(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);preview=root/'preview.wav';preview.write_bytes(audio_bytes())
            started=threading.Event();release=threading.Event();calls=[]
            class Voice:
                def synthesize_wav(self,text,out):
                    calls.append(text);started.set();release.wait(3)
                    out.setnchannels(1);out.setsampwidth(2);out.setframerate(24000);out.writeframes(b'\x20\x00'*2400)
            server=make_server(Voice(),0,model_name='Qwen3-TTS-fixture',cache_dir=root/'cache',namespace='reference-A',preview_path=preview)
            threading.Thread(target=server.serve_forever,daemon=True).start()
            def req(method,route,text=None,headers=None):
                c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=2)
                c.request(method,route,json.dumps({'text':text}) if text else None,headers or ({'Content-Type':'application/json'} if text else {}))
                response=c.getresponse();result=response.status,response.read();c.close();return result
            try:
                status,data=req('POST','/jobs','Oi, Ana!');self.assertEqual(status,202);identifier=json.loads(data)['id'];self.assertTrue(started.wait(1))
                self.assertEqual(json.loads(req('GET','/health')[1])['busy'],True)
                self.assertEqual(req('GET','/preview'),(200,preview.read_bytes()))
                self.assertEqual(json.loads(req('POST','/jobs','Oi, Ana!')[1])['id'],identifier)
                self.assertEqual(req('POST','/jobs','outra fala')[0],409)
                self.assertEqual(req('GET','/jobs/'+identifier+'/audio')[0],409)
                release.set()
                for _ in range(100):
                    if json.loads(req('GET','/jobs/'+identifier)[1])['state']=='ready':break
                    time.sleep(.01)
                self.assertEqual(req('GET','/jobs/'+identifier+'/audio'),(200,preview.read_bytes()))
                self.assertEqual(calls,['Oi, Ana!'])
                self.assertEqual(req('POST','/jobs','bloqueada',{'Content-Type':'application/json','Origin':'https://outside.example'})[0],403)
            finally:
                release.set();server.shutdown();server.server_close()
            class NoSynthesis:
                def synthesize_wav(self,*args):raise AssertionError('Cached reply must survive restart')
            server=make_server(NoSynthesis(),0,model_name='Qwen3-TTS-fixture',cache_dir=root/'cache',namespace='reference-A')
            threading.Thread(target=server.serve_forever,daemon=True).start()
            try:
                status,data=req('POST','/jobs','Oi, Ana!');job=json.loads(data)
                self.assertEqual(status,202);self.assertEqual(job['state'],'ready');self.assertTrue(job['cached']);self.assertEqual(job['id'],identifier)
                self.assertEqual(req('GET','/jobs/'+identifier+'/audio'),(200,preview.read_bytes()))
            finally:server.shutdown();server.server_close()

    def test_legacy_timeout_keeps_generated_audio_instead_of_generating_twice(self):
        calls=[]
        class Voice:
            def synthesize_wav(self,text,out):
                calls.append(text);time.sleep(.15);out.setnchannels(1);out.setsampwidth(2);out.setframerate(24000);out.writeframes(b'\x20\x00'*2400)
        server=make_server(Voice(),0);threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=.02);c.request('POST','/synthesize',json.dumps({'text':'olá'}),{'Content-Type':'application/json'})
            with self.assertRaises(TimeoutError):c.getresponse()
            c.close();time.sleep(.2)
            c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=2);c.request('POST','/synthesize',json.dumps({'text':'olá'}),{'Content-Type':'application/json'})
            r=c.getresponse();self.assertEqual(r.status,200);self.assertEqual(r.read(),audio_bytes());c.close();self.assertEqual(calls,['olá'])
        finally:server.shutdown();server.server_close()

    def test_cache_is_scoped_to_reference_and_rejects_corruption_and_path_traversal(self):
        with tempfile.TemporaryDirectory() as folder:
            calls=[]
            def synthesize(text):calls.append(text);return audio_bytes()
            a=VoiceJobs(synthesize,'model',namespace='A',cache_dir=folder);identifier=a.start('oi')['id'];a.wait(identifier)
            b=VoiceJobs(synthesize,'model',namespace='B',cache_dir=folder);other=b.start('oi')['id'];b.wait(other);self.assertNotEqual(identifier,other)
            (Path(folder)/(identifier+'.wav')).write_bytes(b'corrupt')
            c=VoiceJobs(synthesize,'model',namespace='A',cache_dir=folder);c.wait(c.start('oi')['id']);self.assertEqual(len(calls),3)
            with self.assertRaises(KeyError):c.status('../install.json')

    def test_failure_is_reported_and_cache_remains_bounded(self):
        with tempfile.TemporaryDirectory() as folder:
            jobs=VoiceJobs(lambda text:audio_bytes(),'fixture',cache_dir=folder)
            for i in range(36):jobs.wait(jobs.start('fala '+str(i))['id'])
            self.assertLessEqual(len(jobs.jobs),32);self.assertLessEqual(len(list(Path(folder).glob('*.wav'))),32)
            class Bad:
                def __call__(self,text):return b'not wav'
            bad=VoiceJobs(Bad(),'fixture');identifier=bad.start('oi')['id']
            for _ in range(50):
                if bad.status(identifier)['state']=='failed':break
                time.sleep(.01)
            self.assertEqual(bad.status(identifier)['state'],'failed')
            self.assertFalse(bad.health()['busy'])

if __name__=='__main__':unittest.main()
