"""Test fixture only: a delayed tone generator with the production HTTP worker."""
import argparse,io,json,math,sys,time,wave
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--worker-dir',required=True);p.add_argument('--cache-dir',required=True);p.add_argument('--delay',type=float,default=12);a=p.parse_args();sys.path.insert(0,a.worker_dir)
from tts_server import make_server
root=Path(a.cache_dir);root.mkdir(parents=True,exist_ok=True)
pcm=b''.join(int(math.sin(i/24000*440*math.pi*2)*4000).to_bytes(2,'little',signed=True) for i in range(24000))
def write_wav(w):w.setnchannels(1);w.setsampwidth(2);w.setframerate(24000);w.writeframes(pcm)
preview=root/'preview.wav'
with wave.open(str(preview),'wb') as w:write_wav(w)
class Voice:
 def synthesize_wav(self,text,w):
  with (root/'calls.jsonl').open('a') as f:f.write(json.dumps({'text':text})+'\n')
  time.sleep(a.delay);write_wav(w)
server=make_server(Voice(),0,model_name='Qwen3-TTS-fixture',preview_path=preview,cache_dir=root/'audio-cache',namespace='browser-test')
print(json.dumps({'port':server.server_port}),flush=True)
server.serve_forever()
