import array
import json
import math
import tempfile
import unittest
import wave
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts/local-ai"))
from fast_setup import select_after_preview, validate_preview


class CloneSelectionTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "openvoice").mkdir()
        (self.root / "cloning").mkdir()
        (self.root / "cloning/reference.wav").write_bytes(b"original reference")
        self.previous = b'{"voiceEngine":"qwen3-clone","textModel":"preserve.gguf","private":"preserve"}'
        (self.root / "install.json").write_bytes(self.previous)
        self.preview = self.root / "openvoice/preview.wav"
        self.write_audio()

    def write_audio(self, silent=False):
        pcm = array.array("h", (0 if silent else round(5000 * math.sin(i * 0.08)) for i in range(24000)))
        with wave.open(str(self.preview), "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(16000)
            wav.writeframes(pcm.tobytes())

    def test_real_preview_required_and_silent_output_keeps_selection(self):
        self.write_audio(silent=True)
        with self.assertRaisesRegex(ValueError, "silencioso"):
            select_after_preview(self.root, self.previous, self.preview, 1)
        self.assertEqual((self.root / "install.json").read_bytes(), self.previous)

    def test_slow_converter_keeps_original_engine(self):
        with self.assertRaisesRegex(ValueError, "60 segundos"):
            select_after_preview(self.root, self.previous, self.preview, 61)
        self.assertEqual((self.root / "install.json").read_bytes(), self.previous)

    def test_concurrent_setting_change_is_preserved(self):
        (self.root / "install.json").write_text('{"voiceEngine":"other"}')
        with self.assertRaisesRegex(ValueError, "mudou"):
            select_after_preview(self.root, self.previous, self.preview, 3)
        self.assertEqual(json.loads((self.root / "install.json").read_text())["voiceEngine"], "other")

    def test_valid_clone_retains_text_settings_reference_and_backup(self):
        details = select_after_preview(self.root, self.previous, self.preview, 3.2, "/tmp/example-venv/bin/python")
        manifest = json.loads((self.root / "install.json").read_text())
        self.assertEqual(manifest["voiceEngine"], "openvoice")
        self.assertEqual(manifest["textModel"], "preserve.gguf")
        self.assertEqual(manifest["private"], "preserve")
        self.assertEqual(manifest["openvoicePython"], "/tmp/example-venv/bin/python")
        self.assertEqual((self.root / "cloning/reference.wav").read_bytes(), b"original reference")
        self.assertEqual(next((self.root / "openvoice").glob("selection-before-*.json")).read_bytes(), self.previous)
        self.assertGreater(details["rmsDb"], -30)
        self.assertAlmostEqual(validate_preview(self.preview)["audioSeconds"], 1.5)


if __name__ == "__main__":
    unittest.main()
