import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {localVoiceAudio} from '../public/local-voice-jobs.js';
import {LiveHost} from '../server/live-host.js';

test('voz lenta sobrevive a falha de uma consulta sem repetir a geração ou confirmar áudio antes de pronto',async()=>{
 let now=0,starts=0,polls=0;const stages=[];
 const result=await localVoiceAudio('oi',{now:()=>now,wait:async ms=>now+=ms,pollMs:20000,maxWaitMs:100000,onProgress:s=>stages.push(s.state),request:async(route)=>{
  if(route==='tts-jobs'){starts++;return {id:'a'.repeat(64)};}
  polls++;if(polls===2)throw Object.assign(Error('rede'),{name:'TypeError'});
  return polls<5?{state:'generating',elapsedSeconds:now/1000}:{state:'ready',audio:'fixture',model:'clone'};
 }});
 assert.equal(starts,1);assert.equal(result.audio,'fixture');assert(now>60000);assert(stages.includes('reconnecting'));
});
test('timeout de uma consulta curta retoma a mesma tarefa de voz',async()=>{
 let starts=0,polls=0;
 const result=await localVoiceAudio('oi',{wait:async()=>{},request:async route=>{if(route==='tts-jobs'){starts++;return {id:'a'.repeat(64)};}if(++polls===1)throw Object.assign(Error('timeout'),{name:'TimeoutError'});return {state:'ready',audio:'fixture'};}});
 assert.equal(starts,1);assert.equal(polls,2);assert.equal(result.audio,'fixture');
});
test('troca de fila cancela reprodução, e síntese inválida não vira fala pronta',async()=>{
 let current=true;
 await assert.rejects(()=>localVoiceAudio('oi',{isCurrent:()=>current,wait:async()=>{current=false;},request:async route=>route==='tts-jobs'?{id:'a'.repeat(64)}:{state:'generating'}}),e=>e.code==='speech_cancelled');
 await assert.rejects(()=>localVoiceAudio('oi',{request:async route=>route==='tts-jobs'?{id:'a'.repeat(64)}:{state:'failed',message:'Falha real'}}),e=>e.code==='local_synthesis_failed');
});
test('conversas e chegadas continuam ativas enquanto falas espontâneas aguardam um clonador rápido',()=>{
 const queued=[];let now=0;const host=new LiveHost({queue:{active:null,items:[],enqueue:item=>queued.push(item)},now:()=>now,getConfig:()=>({hostSpeech:true,hostAmbientReady:false})});now=50000;host.tick('demo');assert.equal(queued.length,0);host.event({type:'join',user:'Ana',displayName:'Ana',source:'demo'});assert.equal(queued.length,1);assert.equal(queued[0].user,'Ana');
});
test('worker real preserva WAV após timeout e reinício e serve preview durante geração',()=>{
 const r=spawnSync('python3',['-m','unittest','discover','-s','tests','-p','voice_jobs_py_test.py'],{encoding:'utf8'});assert.equal(r.status,0,r.stderr||r.stdout);
});
