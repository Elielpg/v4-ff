#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node --input-type=module -e 'const {BUILD_ID,BUILD_LABEL}=await import("./public/release.js");console.log("Pasta da instalação: "+process.cwd());console.log("Versão dos arquivos: "+BUILD_ID+" · "+BUILD_LABEL);'
exec node --env-file-if-exists=.env scripts/start-game.js
