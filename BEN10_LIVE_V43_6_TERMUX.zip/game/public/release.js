export const BUILD_ID='43.6.0';
export const BUILD_LABEL='Ben 10 · Clareira LIVE · 43.6.0';
