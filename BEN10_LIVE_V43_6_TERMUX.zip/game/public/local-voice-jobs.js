// Each HTTP call is short; native generation continues independently.
export async function localVoiceAudio(text,{request,onProgress=()=>{},isCurrent=()=>true,wait=ms=>new Promise(resolve=>setTimeout(resolve,ms)),now=Date.now,pollMs=900,maxWaitMs=600000}={}) {
 const deadline=now()+maxWaitMs;let identifier=null,failures=0;
 while(now()<deadline){
  if(!isCurrent())throw Object.assign(Error('A fala foi cancelada pela troca da fila.'),{status:409,code:'speech_cancelled'});
  try{
   if(!identifier){const job=await request('tts-jobs',{text});identifier=job.id;}
   const job=await request('tts-jobs/'+identifier);
   if(job.state==='failed')throw Object.assign(Error(job.message||'O clonador não gerou áudio válido.'),{code:'local_synthesis_failed'});
   onProgress(job);failures=0;
   if(job.state==='ready'){
    if(!job.audio)throw Object.assign(Error('O clonador terminou sem entregar áudio.'),{code:'local_voice_response'});
    if(!isCurrent())throw Object.assign(Error('A fala saiu da fila.'),{status:409,code:'speech_cancelled'});
    return job;
   }
  }catch(error){
   if(error.code==='local_voice_busy')onProgress({state:'waiting',elapsedSeconds:0});
   else if(error.code==='local_voice_job_missing'){identifier=null;onProgress({state:'reconnecting',elapsedSeconds:0});}
   else if(['local_voice_offline','AbortError','TimeoutError','TypeError'].includes(error.code||error.name)&&++failures<4)onProgress({state:'reconnecting',elapsedSeconds:0});
   else throw error;
  }
  await wait(pollMs);
 }
 throw Object.assign(Error('A clonagem ultrapassou 10 minutos. O resultado será mantido; confira o diagnóstico de voz no painel.'),{code:'local_voice_slow'});
}
