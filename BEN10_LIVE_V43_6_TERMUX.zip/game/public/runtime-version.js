export function runtimeVersionError(expected,actual){
 return Object.assign(Error('Servidor na V'+(actual||'desconhecida')+' e interface na V'+expected+'. No Termux, execute bash restart.sh para carregar a mesma versão.'),{code:'runtime_version_mismatch',expected,actual});
}
