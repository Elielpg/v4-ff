import { OnsetDetector, PulseTracker, DETECTION_MODES } from "./onset.js";
export class ArenaAudio {
  constructor(
    element,
    { onBeat = () => {}, onLevel = () => {}, onStatus = () => {} } = {},
  ) {
    this.element = element;
    Object.assign(this, { onBeat, onLevel, onStatus });
    this.offset = 120;
    this.mode = "phonk";
    this.tracker = new PulseTracker();
    this.pending = new Set();
    this.detected = 0;
    this.intervals = [];
    this.lastHit = 0;
    this.objectURL = null;
    this.generation = 0;
    this.enabled = false;
  }
  async unlock() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.7;
      this.musicGain.connect(this.ctx.destination);
      this.effects = this.ctx.createGain();
      this.effects.gain.value = 0.2;
      this.effects.connect(this.ctx.destination);
    }
    await this.ctx.resume();
    this.enabled = this.ctx.state === "running";
    return this.enabled;
  }
  async load(file) {
    await this.unlock();
    if (this.objectURL) URL.revokeObjectURL(this.objectURL);
    this.element.pause();
    this.objectURL = URL.createObjectURL(file);
    this.element.src = this.objectURL;
    this.intervals = [];
    this.lastHit = 0;
    this.tracker.reset();
    this.detected = 0;
    this.cancelPending();
    this.meter?.port.postMessage({ reset: true });
    this.fallbackLow?.reset();
    this.fallbackHigh?.reset();
    if (!this.source) {
      this.source = this.ctx.createMediaElementSource(this.element);
      this.source.connect(this.musicGain);
      this.band = this.ctx.createBiquadFilter();
      this.band.type = "bandpass";
      this.band.frequency.value = 110;
      this.band.Q.value = 0.6;
      this.detailBand = this.ctx.createBiquadFilter();
      this.detailBand.type = "bandpass";
      this.detailBand.frequency.value = 1800;
      this.detailBand.Q.value = 0.6;
      this.source.connect(this.detailBand);
      this.source.connect(this.band);
      this.silent = this.ctx.createGain();
      this.silent.gain.value = 0;
      this.silent.connect(this.ctx.destination);
      try {
        await this.ctx.audioWorklet.addModule("/beat-meter.js");
        this.meter = new AudioWorkletNode(this.ctx, "pulso-meter", {
          numberOfInputs: 2,
          channelCount: 1,
          channelCountMode: "explicit",
        });
        this.meter.port.postMessage({ mode: this.mode });
        this.band.connect(this.meter, 0, 0);
        this.detailBand.connect(this.meter, 0, 1);
        this.meter.connect(this.silent);
        this.meter.port.onmessage = (e) => {
          this.onLevel(Math.min(1, e.data.level * 4));
          if (e.data.hit && !this.element.paused)
            this.hit(e.data.at * 1000, e.data.strength);
        };
        this.onStatus("Análise de batida ativa");
      } catch {
        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 1024;
        this.band.connect(this.analyser);
        this.analyser.connect(this.silent);
        this.data = new Float32Array(1024);
        this.detailAnalyser = this.ctx.createAnalyser();
        this.detailAnalyser.fftSize = 1024;
        this.detailBand.connect(this.detailAnalyser);
        this.detailAnalyser.connect(this.silent);
        this.detailData = new Float32Array(1024);
        this.fallbackLow = new OnsetDetector(this.mode);
        this.fallbackHigh = new OnsetDetector(this.mode);
        this.poll = setInterval(() => {
          if (this.element.paused) return;
          this.analyser.getFloatTimeDomainData(this.data);
          this.detailAnalyser.getFloatTimeDomainData(this.detailData);
          const rms = (a) =>
              Math.sqrt(a.reduce((sum, x) => sum + x * x, 0) / a.length),
            low = rms(this.data),
            high = rms(this.detailData),
            at = this.ctx.currentTime;
          const a = this.fallbackLow.sample(low, at),
            b = this.fallbackHigh.sample(high, at);
          this.onLevel(Math.min(1, Math.max(low, high) * 4));
          if (a || b)
            this.hit(
              at * 1000,
              Math.max(
                a ? this.fallbackLow.strength : 0,
                b ? this.fallbackHigh.strength : 0,
              ),
            );
        }, 12);
        this.onStatus("Análise de áudio básica ativa");
      }
    }
    return file.name;
  }
  setMode(mode) {
    this.mode = mode;
    this.meter?.port.postMessage({ mode });
    this.fallbackLow?.setMode(mode);
    this.fallbackHigh?.setMode(mode);
  }
  cancelPending() {
    this.generation++;
    for (const t of this.pending) clearTimeout(t);
    this.pending.clear();
  }
  hit(at, strength = 1) {
    if(at-this.lastHit<DETECTION_MODES[this.mode].gap*1000)return;
    const pulse = this.tracker.note(at, strength);
    if (!pulse) return;
    this.detected++;
    this.lastHit = at;
    this.intervals = [...this.tracker.intervals];
    const ticket = this.generation,
      age = Math.max(0, this.ctx.currentTime * 1000 - at);
    if (age > 400 || this.pending.size >= 12) return;
    const target = Date.now() - age + this.offset;
    const timer = setTimeout(
      () => {
        this.pending.delete(timer);
        if (ticket !== this.generation || this.element.paused) return;
        this.onBeat({ ...pulse, at: target });
      },
      Math.max(0, this.offset - age),
    );
    this.pending.add(timer);
  }
  tone(f, d = 0.1, type = "sine", volume = 0.25) {
    if (!this.enabled) return;
    const t = this.ctx.currentTime,
      o = this.ctx.createOscillator(),
      g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(35, f * 0.35), t + d);
    g.gain.setValueAtTime(volume, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g);
    g.connect(this.effects);
    o.start(t);
    o.stop(t + d + 0.02);
  }
  sfx(kind) {
    if (!this.enabled) return;
    if (kind === "welcome" || kind === "follow") {
      this.tone(660, 0.12, "sine", 0.25);
      setTimeout(() => this.tone(990, 0.14, "sine", 0.22), 90);
    } else if (kind === "victory") {
      for (let i = 0; i < 3; i++)
        setTimeout(
          () => this.tone([440, 554, 659][i], 0.25, "triangle", 0.3),
          i * 100,
        );
    } else if (kind === "special") {
      this.tone(180, 0.36, "sawtooth", 0.22);
      this.tone(65, 0.4, "sine", 0.55);
    } else if (kind === "block") {
      this.tone(640, 0.1, "triangle", 0.3);
    } else if (kind === "dodge") {
      this.tone(350, 0.08, "sine", 0.13);
    } else if (kind === "attack") {
      this.tone(115, 0.13, "triangle", 0.5);
    } else if (kind === "entrance") {
      this.tone(240, 0.26, "sawtooth", 0.2);
    }
  }
  pause() {
    this.cancelPending();
    this.element.pause();
  }
}
