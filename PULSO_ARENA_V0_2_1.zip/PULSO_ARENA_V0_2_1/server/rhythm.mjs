import { randomInt, randomBytes, timingSafeEqual } from "node:crypto";
import { OnsetDetector, PulseTracker, DETECTION_MODES } from "../public/onset.js";

// Only numeric audio features cross the local bridge; never PCM, files or URLs.
export class RhythmBridge {
  constructor({ now = Date.now } = {}) {
    this.now = now;
    this.offset = 120;
    this.mode = "phonk";
    this.revoke();
  }
  revoke() {
    this.token = null;
    this.code = null;
    this.expires = 0;
    this.failures = 0;
    this.lastFrame = 0;
    this.lastSound = 0;
    this.level = 0;
    this.lastSeq = -1;
    this.lastHit = 0;
    this.intervals = [];
    this.meter = new OnsetDetector(this.mode);
    this.highMeter = new OnsetDetector(this.mode);
    this.tracker = new PulseTracker();
    this.lastAt = -Infinity;
    this.pulses = 0;
    this.generation = (this.generation || 0) + 1;
  }
  setMode(mode) {
    this.meter.setMode(mode);
    this.highMeter.setMode(mode);
    this.mode = this.meter.mode;
  }
  issue() {
    this.revoke();
    this.code = String(randomInt(100000, 1000000));
    this.expires = this.now() + 120000;
    return { code: this.code, expires: this.expires };
  }
  pair(code) {
    if (!this.code || this.now() > this.expires || this.failures >= 5)
      throw Object.assign(Error("Código expirado. Gere outro no jogo."), {
        status: 403,
      });
    if (String(code) !== this.code) {
      this.failures++;
      throw Object.assign(Error("Código incorreto."), { status: 403 });
    }
    this.code = null;
    this.token = randomBytes(32).toString("hex");
    return { token: this.token };
  }
  frame(auth, data) {
    const input = String(auth || "").replace(/^Bearer /, "");
    if (
      !this.token ||
      !/^[a-f0-9]{64}$/.test(input) ||
      !timingSafeEqual(Buffer.from(input), Buffer.from(this.token))
    )
      throw Object.assign(Error("Pareamento necessário."), { status: 401 });
    const { energy, level, seq, at } = data;
    const detail = data.detail ?? 0;
    if (
      ![energy, detail, level, seq, at].every(Number.isFinite) ||
      energy < 0 ||
      energy > 2 ||
      detail < 0 ||
      detail > 2 ||
      level < 0 ||
      level > 2 ||
      !Number.isSafeInteger(seq) ||
      seq < 0 ||
      Math.abs(at - this.now()) > 5000
    )
      throw Object.assign(Error("Quadro de áudio inválido ou antigo."), {
        status: 400,
      });
    if (seq <= this.lastSeq) return { accepted: false };
    if (at - this.lastAt < 8) return { accepted: false };
    this.lastSeq = seq;
    this.lastAt = at;
    this.lastFrame = this.now();
    this.level = Math.min(1, level * 4);
    if (level > 0.0005) this.lastSound = this.now();
    const low = this.meter.sample(energy, at / 1000),
      high = this.highMeter.sample(detail, at / 1000);
    const strength = Math.max(
      low ? this.meter.strength : 0,
      high ? this.highMeter.strength : 0,
    );
    const pulse = (low || high) && at-this.lastHit>=DETECTION_MODES[this.mode].gap*1000 ? this.tracker.note(at, strength) : null;
    if (pulse) {this.pulses++;this.lastHit=at;}
    return {
      accepted: true,
      hit: !!pulse && this.now() - at < 400,
      at,
      ...pulse,
    };
  }
  status() {
    const connected = !!this.token && this.now() - this.lastFrame < 3000;
    return {
      state: connected
        ? this.now() - this.lastSound < 5000
          ? "listening"
          : "silent"
        : this.token
          ? "waiting"
          : this.code && this.now() < this.expires
            ? "pairing"
            : "offline",
      level: connected ? this.level : 0,
      offset: this.offset,
      mode: this.mode,
      pulses: this.pulses,
    };
  }
}
