# Ben 10 · Clareira LIVE · V43.1

O áudio enviado do Ben clássico já está incluído em assets/voice/ben-classico-reference.wav: PCM16, mono, 24 kHz, aproximadamente 13 segundos. A integridade é conferida por SHA-256. Não é necessário renomear o MP3 nem converter arquivos no celular.

## Atualizar e preparar

Pare a sessão atual com Ctrl+C. Para o pacote completo:

```sh
cd ~/ben10-v34/game
bash update.sh --archive ~/storage/downloads/BEN10_LIVE_V43_1_TERMUX.zip
bash local-ai.sh clone setup
bash local-ai.sh start
```

O reparo pequeno BEN10_REPARO_V43_1.zip é uma alternativa ao ZIP completo. Ele atualiza os arquivos e inclui a referência, com backup e preservação de chaves, progresso e modelos. Não precisa aplicar os dois pacotes.

O comando clone setup instala os modelos/motor se estiverem ausentes, aplica a referência incluída, gera um teste de síntese real e seleciona o clone somente se esse teste produzir um WAV válido dentro do limite de tempo. Em falha, restaura a seleção e a referência anteriores. A primeira preparação usa internet e vários GB; o modelo de conversa não é reinstalado.

Abra http://127.0.0.1:3000/?v=43.1.0 e ative ♫. O diagnóstico mostra Qwen3-TTS-0.6B-clone-pt quando essa voz está em uso. Preview: ~/.local/share/ben10-local-ai/cloning/preview.wav.

## Voltar à voz anterior

```sh
bash local-ai.sh clone piper
bash local-ai.sh start
```

Pare a sessão antes de trocar. Não apaga a referência nem os modelos. O jogo continua com saudações rápidas, perguntas pela IA, fila de presentes, ranking e Omnitrix da V43.

[Guia completo, testes e limites](docs/V43_1_AUDIO_INCLUIDO.md).
