#!/usr/bin/env bash
set -euo pipefail
task_game_root="$(cd -- "$(dirname -- "$0")/../.." && pwd)"
task_local_root="${BEN10_LOCAL_ROOT:-$HOME/.local/share/ben10-local-ai}"
task_command="${1:-help}"; shift || true
case "$task_command" in
 setup)
  exec python3 "$task_game_root/scripts/local-ai/clone_setup.py" --root "$task_local_root" --game "$task_game_root"
  ;;
 install)
  [[ -f "$task_local_root/install.json" ]] || { printf 'Instale primeiro a IA existente: bash local-ai.sh install\n' >&2; exit 1; }
  command -v pkg >/dev/null && [[ "$(uname -m)" == aarch64 ]] || { printf 'Este instalador é para Termux ARM64.\n' >&2; exit 1; }
  printf 'Clonagem experimental Qwen3-TTS 0.6B. A instalação inicial usa internet e vários GB; a velocidade precisa ser medida no aparelho.\n'
  bash "$task_game_root/scripts/termux-packages.sh" git cmake ninja clang python proot-distro
  python3 "$task_game_root/scripts/local-ai/clone_models.py" --root "$task_local_root/cloning"
  task_clone_source="$task_local_root/qwen3-tts.cpp"
  task_clone_revision=b3ba14077cf1b3e11b86e5f84aa9184605c89b28
  if [[ ! -d "$task_clone_source/.git" ]]; then
    git init "$task_clone_source"
    git -C "$task_clone_source" remote add origin https://github.com/predict-woo/qwen3-tts.cpp.git
  fi
  git -C "$task_clone_source" fetch --depth 1 origin "$task_clone_revision"
  git -C "$task_clone_source" checkout --detach "$task_clone_revision"
  git -C "$task_clone_source" submodule update --init --depth 1 --recursive
  # Clang on aarch64 accepts -mcpu=native; upstream's x86 -march=native does not.
  python3 - "$task_clone_source/CMakeLists.txt" <<'BEN_CLONE_ARCH'
from pathlib import Path
import sys
p=Path(sys.argv[1]); text=p.read_text()
p.write_text(text.replace("-march=native", "-mcpu=native"))
BEN_CLONE_ARCH
  cmake -S "$task_clone_source/ggml" -B "$task_clone_source/ggml/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DGGML_METAL=OFF -DGGML_OPENMP=OFF -DGGML_BUILD_TESTS=OFF -DGGML_BUILD_EXAMPLES=OFF
  cmake --build "$task_clone_source/ggml/build" --parallel 4
  cmake -S "$task_clone_source" -B "$task_clone_source/build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DQWEN3_TTS_COREML=OFF
  cmake --build "$task_clone_source/build" --target qwen3tts_shared --parallel 4
  # CPU PyTorch is used only for the one-time source-weight conversion in Debian.
  proot-distro login --bind "$task_local_root:/ben10-data" --bind "$task_game_root/scripts/local-ai:/opt/ben10-clone-worker" ben10-ai -- /bin/bash -lc '
set -euo pipefail
python3 -m venv /opt/ben10-clone-convert
/opt/ben10-clone-convert/bin/pip install --disable-pip-version-check --only-binary=:all: -r /opt/ben10-clone-worker/clone-convert-requirements.txt
mkdir -p /ben10-data/cloning/models
/opt/ben10-clone-convert/bin/python /ben10-data/qwen3-tts.cpp/scripts/convert_tts_to_gguf.py --input /ben10-data/cloning/source --output /ben10-data/cloning/models/qwen3-tts-0.6b-f16.gguf.part --type f16
/opt/ben10-clone-convert/bin/python /ben10-data/qwen3-tts.cpp/scripts/convert_tokenizer_to_gguf.py --input /ben10-data/cloning/source/speech_tokenizer --output /ben10-data/cloning/models/qwen3-tts-tokenizer-f16.gguf.part --type f16
mv /ben10-data/cloning/models/qwen3-tts-0.6b-f16.gguf.part /ben10-data/cloning/models/qwen3-tts-0.6b-f16.gguf
mv /ben10-data/cloning/models/qwen3-tts-tokenizer-f16.gguf.part /ben10-data/cloning/models/qwen3-tts-tokenizer-f16.gguf
'
  printf 'Motor nativo preparado. A voz atual foi mantida. Falta a amostra: bash local-ai.sh clone reference caminho/ben.wav\n'
  ;;
 reference|use|piper|status)
  exec python3 "$task_game_root/scripts/local-ai/clone_config.py" --root "$task_local_root" "$task_command" "$@"
  ;;
 preview)
  exec python3 "$task_game_root/scripts/local-ai/clone_voice.py" --root "$task_local_root" --preview "$task_local_root/cloning/preview.wav"
  ;;
 *) printf 'Preparar com áudio do Ben incluído: bash local-ai.sh clone setup\nInstalar somente o motor: bash local-ai.sh clone install\nOutra amostra: bash local-ai.sh clone reference caminho/ben.wav\nOuvir teste: bash local-ai.sh clone preview\nUsar clone: bash local-ai.sh clone use\nVoltar ao Piper: bash local-ai.sh clone piper\nEstado: bash local-ai.sh clone status\n' ;;
esac
