"""Install, register the bundled reference, test real synthesis and select atomically."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import wave
from clone_config import configure

OWNED = ("reference.wav", "config.json", "preview.wav", "preview.json")


def check_bundle(game):
    folder = Path(game) / "assets/voice"
    metadata = json.loads((folder / "ben-classico-reference.json").read_text())
    reference = folder / "ben-classico-reference.wav"
    if metadata.get("file") != reference.name or hashlib.sha256(reference.read_bytes()).hexdigest() != metadata.get("sha256"):
        raise ValueError("A referência de voz do pacote não passou na conferência de integridade")
    with wave.open(str(reference)) as wav:
        if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (24000, 1, 2) or not 3 <= wav.getnframes() / wav.getframerate() <= 30:
            raise ValueError("Referência de voz inválida")
    return reference


def installed(root):
    root = Path(root)
    if not (root / "qwen3-tts.cpp/build/libqwen3tts.so").is_file():
        return False
    for filename in ["qwen3-tts-0.6b-f16.gguf", "qwen3-tts-tokenizer-f16.gguf"]:
        file = root / "cloning/models" / filename
        if not file.is_file():
            return False
        with file.open("rb") as source:
            if source.read(4) != b"GGUF":
                return False
    return True


def check_ports():
    for port in (8081, 8082):
        with socket.socket() as connection:
            connection.settimeout(.5)
            if connection.connect_ex(("127.0.0.1", port)) == 0:
                raise ValueError("Pare a sessão da IA com Ctrl+C antes de preparar a clonagem")


def setup(root, game, run=subprocess.run, probe=check_ports):
    root, game = Path(root).resolve(), Path(game).resolve()
    reference = check_bundle(game)  # Fail before downloads, conversion or selection.
    manifest_file = root / "install.json"
    manifest_bytes = manifest_file.read_bytes()
    json.loads(manifest_bytes)
    probe()
    folder = root / "cloning"
    folder.mkdir(parents=True, exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix="setup-", dir=folder))
    previous = {}
    child_environment = {**os.environ, "BEN10_LOCAL_ROOT": str(root)}
    for name in OWNED:
        path = folder / name
        previous[name] = path.is_file()
        if path.is_file():
            shutil.copyfile(path, backup / name)
    try:
        if not installed(root):
            print("Preparando o motor e os modelos da clonagem…", flush=True)
            run(["bash", str(game / "scripts/local-ai/clone.sh"), "install"], check=True, env=child_environment)
        else:
            print("Motor já instalado. Sem reinstalar ou consultar catálogos.", flush=True)
        configure(root, "reference", reference)
        print("Gerando um teste real com a referência do Ben. O tempo depende do aparelho…", flush=True)
        run([sys.executable, str(game / "scripts/local-ai/clone_voice.py"), "--root", str(root), "--preview", str(folder / "preview.wav")], check=True, timeout=600, env=child_environment)
        # A partial file or an old preview cannot qualify as a successful setup.
        preview = json.loads((folder / "preview.json").read_text())
        if preview.get("referenceSha256") != hashlib.sha256((folder / "reference.wav").read_bytes()).hexdigest():
            raise ValueError("O teste não corresponde à referência atual")
        elapsed = preview.get("secondsToGenerate")
        if not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed <= 0 or elapsed > 150:
            raise ValueError("A geração excedeu o tempo permitido para esse perfil; a voz anterior será mantida")
        with wave.open(str(folder / "preview.wav")) as wav:
            if wav.getframerate() != 24000 or wav.getnchannels() != 1 or wav.getnframes() < 240:
                raise ValueError("O teste de voz não gerou um WAV válido")
        configure(root, "use")
        print("Clonagem selecionada após síntese real. Preview:", folder / "preview.wav", flush=True)
        print("Tempo para gerar a frase:", elapsed, "s. Agora execute bash local-ai.sh start", flush=True)
        return {"selected": True, "secondsToGenerate": elapsed, "preview": str(folder / "preview.wav")}
    except BaseException:
        temp = manifest_file.with_suffix(".restore.tmp")
        temp.write_bytes(manifest_bytes); os.replace(temp, manifest_file)
        for name, existed in previous.items():
            destination = folder / name
            if existed:
                shutil.copyfile(backup / name, destination)
            else:
                destination.unlink(missing_ok=True)
        print("A preparação não terminou. A seleção e a referência anteriores foram restauradas.", flush=True)
        raise
    finally:
        shutil.rmtree(backup)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--game", required=True, type=Path)
    args = parser.parse_args()
    try:
        setup(args.root, args.game)
    except Exception as error:
        raise SystemExit("Clonagem não ativada: " + str(error))
