import subprocess,sys,tarfile
from pathlib import Path
R=Path(__file__).parent

def test_patch_backups_known_source_and_preserves_private_config(tmp_path):
    target=tmp_path/'snake_termux';target.mkdir()
    with tarfile.open('/workspace/snake-reyers-adaptation-tools/backups/adapter-before-investigation-20261126.tar.gz') as t:old=t.extractfile('snake_termux/native.py').read()
    (target/'native.py').write_bytes(old);(target/'presentation.py').write_text('# fixture')
    (tmp_path/'private.json').write_text('preserve config')
    cmd=[sys.executable,str(R/'SNAKE_REYERS_CORRIGIR_LIMITE_WRAPPER.py'),'--pasta',str(tmp_path)]
    r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
    assert (target/'native.py').read_bytes()==Path('/workspace/snake-reyers-termux-adapter/snake_termux/native.py').read_bytes()
    backups=list((tmp_path/'state/launcher-backups').glob('*/native-before.py'));assert len(backups)==1 and backups[0].read_bytes()==old
    assert (tmp_path/'private.json').read_text()=='preserve config'
    r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0 and len(list((tmp_path/'state/launcher-backups').glob('*')))==1


def test_unrecognized_user_changes_are_not_overwritten(tmp_path):
    target=tmp_path/'snake_termux';target.mkdir();(target/'native.py').write_text('my edited adapter');(target/'presentation.py').write_text('# fixture')
    r=subprocess.run([sys.executable,str(R/'SNAKE_REYERS_CORRIGIR_LIMITE_WRAPPER.py'),'--pasta',str(tmp_path)],capture_output=True,text=True)
    assert r.returncode!=0 and (target/'native.py').read_text()=='my edited adapter'
    assert not (tmp_path/'state').exists()
