import importlib.util,json,os,sys,time
from pathlib import Path
spec=importlib.util.spec_from_file_location('collector',Path(__file__).with_name('SNAKE_REYERS_INVESTIGAR_GT3.py'));c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def test_flags_are_filtered_and_user_args_are_not_read():
    flags=c.selected_flags(['/linker64','/bin/godot','--max-fps','30','--url','SECRET','--resolution','720x1280','--','--token','SECRET','--fixed-fps','200'])
    assert flags=={'--max-fps':'30','--resolution':'720x1280'} and 'SECRET' not in json.dumps(flags)


def test_flags_reject_values_that_look_like_private_paths_or_url_keys():
    assert c.selected_flags(['godot','--rendering-method','https://secret/path','--max-fps','30'])=={'--max-fps':'30'}


def test_package_uid_recognition_is_explicit():
    values=c.package_uids('package:com.termux uid:10218\npackage:com.termux.x11 uid:10401\npackage:com.other uid:10000\n')
    assert values=={'com.termux':10218,'com.termux.x11':10401}
    assert c.package_uids('Permission denied')=={}


def test_selected_panel_state_excludes_private_data():
    data={'running':True,'pid':2,'secret':'SECRET','device':{'graphics':{'profile':'gt3_live','max_fps':30,'secret':'SECRET'},'audio':{'api_key':'SECRET'}},'performance':{'fps':37},'audio_runtime':{'state':'playback-requested','api_key':'SECRET'}}
    state=c.render_state(data)
    assert state['graphics']['max_fps']==30 and state['project_fps']==37
    assert 'SECRET' not in json.dumps(state)
    assert c.render_state(None)=={'available':False}


def test_game_discovery_handles_android_linker_and_no_other_process(tmp_path):
    a=tmp_path/'10';a.mkdir();(a/'cmdline').write_bytes(b'/system/bin/linker64\0/data/bin/godot\0--main-pack\0/x/SnakeReyers.exe\0--max-fps\030\0')
    b=tmp_path/'20';b.mkdir();(b/'cmdline').write_bytes(b'python\0some.py\0')
    assert c.game_pids(tmp_path)==[10]


def test_cgroup_read_is_bounded_to_safe_groups(tmp_path):
    (tmp_path/'background').mkdir();(tmp_path/'background/cpu.shares').write_text('52')
    values=c.cgroup_controls('2:cpu:/background\n0::/../../secret',[tmp_path])
    assert len(values)==1 and values[0]['controls']['cpu.shares']=='52'


def test_system_reports_missing_files_without_inventing_zero(tmp_path):
    s=c.system(tmp_path,tmp_path)
    assert s['cpu_online'] is None and s['cpu_freq_khz']==[] and s['thermal']==[]
    assert s['gpu_raw']['gpuclk'] is None and s['memory']=={}


def test_raw_thermal_units_and_policy_caps_are_preserved(tmp_path):
    p=tmp_path/'devices/system/cpu/cpufreq/policy0';p.mkdir(parents=True)
    (p/'scaling_max_freq').write_text('1800000');(p/'cpuinfo_max_freq').write_text('3200000')
    z=tmp_path/'class/thermal/thermal_zone0';z.mkdir(parents=True);(z/'type').write_text('socd');(z/'temp').write_text('86')
    s=c.system(tmp_path,tmp_path)
    assert s['cpu_freq_khz'][0]['scaling_max_freq']=='1800000'
    assert s['thermal'][0]['raw']==86 and s['thermal'][0]['unit_warning']
    (z/'temp').write_text('86000');s=c.system(tmp_path,tmp_path)
    assert s['thermal'][0]['celsius_from_linux_millidegree_abi']==86 and s['thermal'][0]['unit_warning'] is None


def test_live_owned_process_thread_identity_and_deltas():
    p=c.Probe();a=p.process(os.getpid(),time.monotonic());time.sleep(.12);b=p.process(os.getpid(),time.monotonic())
    assert a['main_and_hot_threads'][0]['main_thread']
    main=next(t for t in b['main_and_hot_threads'] if t['main_thread'])
    assert main['tid']==os.getpid() and main['cpu_percent_one_core'] is not None
    assert 'launch_flags' in b


def test_missing_process_never_raises_or_assumes_access(tmp_path):
    p=c.Probe(tmp_path,tmp_path);assert p.process(12345,time.monotonic()) is None
    assert c.stat_file(tmp_path/'none') is None
